; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 7 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 72
       lea      rbp, [rsp+0x70]
       mov      rsi, rcx
       mov      rdi, rdx
       mov      rbx, r8
 
G_M000_IG02:                ;; offset=0x001A
       mov      r14, gword ptr [rsi+0x08]
       test     r14, r14
       je       G_M000_IG13
       test     rbx, rbx
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x002C
       mov      rcx, 0x7FFA02A81FA0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
 
G_M000_IG04:                ;; offset=0x003E
       mov      r15, gword ptr [rbx+0x38]
       test     r15, r15
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0047
       mov      r15, gword ptr [rsi+0x20]
       test     r15, r15
       jne      SHORT G_M000_IG06
       mov      rcx, 0x7FFA02925BD8
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      byte  ptr [rbp-0x38], 0
       xor      edx, edx
       mov      qword ptr [rbp-0x30], rdx
       lea      rdx, [rbp-0x38]
       mov      rcx, r15
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
 
G_M000_IG06:                ;; offset=0x0079
       mov      rcx, r15
       mov      r11, 0x7FFA02611CD0
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG07:                ;; offset=0x008D
       mov      rcx, gword ptr [rbx+0x40]
       test     rcx, rcx
       cmove    rcx, r15
       mov      r11, 0x7FFA02611CD8
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      r9, rax
       mov      gword ptr [rbp-0x48], r9
 
G_M000_IG08:                ;; offset=0x00AC
       mov      rdx, gword ptr [rbx+0x60]
       mov      rcx, rbx
       mov      r8, gword ptr [rbp-0x40]
       call     [Lokad.Lython.LythonRunOptions:Copy(System.Threading.CancellationToken,Lokad.Lython.ILythonMemoryBudget,Lokad.Lython.ILythonMemoryBudget):Lokad.Lython.LythonRunOptions:this]
       mov      r8, rax
       mov      rdx, rdi
       mov      rcx, gword ptr [r14+0x10]
       call     [r14+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      rbx, rax
       lea      rcx, bword ptr [rbx+0x28]
       mov      rdx, gword ptr [rbp-0x48]
       call     CORINFO_HELP_ASSIGN_REF
       nop      
 
G_M000_IG09:                ;; offset=0x00DC
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00E3
       mov      rcx, gword ptr [rbp-0x40]
       mov      r11, 0x7FFA02611CE8
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG11:                ;; offset=0x00F4
       mov      rax, rbx
 
G_M000_IG12:                ;; offset=0x00F7
       add      rsp, 72
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x0104
       mov      rcx, 0x7FFA02A5A5F0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x18B4A14C950
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG14:                ;; offset=0x0132
       sub      rsp, 40
 
G_M000_IG15:                ;; offset=0x0136
       mov      rcx, gword ptr [rbp-0x48]
       mov      r11, 0x7FFA02611CE0
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG16:                ;; offset=0x014D
       sub      rsp, 40
 
G_M000_IG17:                ;; offset=0x0151
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG18
       mov      rcx, gword ptr [rbp-0x40]
       mov      r11, 0x7FFA02611CE8
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG18:                ;; offset=0x0169
       nop      
 
G_M000_IG19:                ;; offset=0x016A
       add      rsp, 40
       ret      
 
; Total bytes of code 367

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 2 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 152
       lea      rbp, [rsp+0xD0]
       xor      eax, eax
       mov      qword ptr [rbp-0x68], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r9
       mov      r14, bword ptr [rbp+0x50]
 
G_M000_IG02:                ;; offset=0x003B
       mov      r15, bword ptr [r8]
       mov      r13d, dword ptr [r8+0x08]
       cmp      dword ptr [r14+0x08], 2
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0049
       xor      r8d, r8d
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x004E
       mov      r8, gword ptr [rbx+0x40]
       movzx    r8, byte  ptr [r8+0xF1]
 
G_M000_IG05:                ;; offset=0x005A
       movzx    r12, byte  ptr [rbp+0x48]
       test     r8d, r12d
       je       SHORT G_M000_IG11
 
G_M000_IG06:                ;; offset=0x0064
       test     rsi, rsi
       jne      SHORT G_M000_IG11
       cmp      r13d, 1
       jne      SHORT G_M000_IG11
 
G_M000_IG07:                ;; offset=0x006F
       vmovdqu  xmm0, xmmword ptr [r15]
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
 
G_M000_IG08:                ;; offset=0x0079
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x20], rax
 
G_M000_IG09:                ;; offset=0x0082
       vmovdqu  xmm0, xmmword ptr [r14]
       vmovdqu  xmmword ptr [rbp-0x58], xmm0
 
G_M000_IG10:                ;; offset=0x008C
       lea      r8, [rbp-0x58]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0x48]
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x38]
       xor      rdx, rdx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x00AC
       mov      bword ptr [rbp-0x68], r15
       mov      dword ptr [rbp-0x60], r13d
       mov      r15, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], r15
       mov      r15, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x28], r15
       movzx    r8, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x30], r8d
       mov      dword ptr [rsp+0x38], r12d
       mov      bword ptr [rsp+0x40], r14
       mov      r14, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x48], r14
       mov      r14, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x50], r14
       mov      r14, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x58], r14
       lea      r8, [rbp-0x68]
       mov      rdx, rdi
       mov      rcx, rbx
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeWorkspace(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       jmp      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x010A
       mov      rbx, bword ptr [rbp+0x58]
       mov      byte  ptr [rbx], 1
       xor      rax, rax
       mov      r14, bword ptr [rbp+0x68]
       mov      gword ptr [r14], rax
 
G_M000_IG13:                ;; offset=0x011A
       add      rsp, 152
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
; Total bytes of code 302

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeWorkspace(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 11 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 440
       lea      rbp, [rsp+0x1E0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x190], xmm4
       mov      rax, -336
 
G_M000_IG16:                ;; offset=0x002D
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG16
       mov      qword ptr [rbp-0x30], rax
       mov      rbx, rcx
       mov      rdi, gword ptr [rbp+0x38]
       mov      rsi, bword ptr [rbp+0x50]
 
G_M000_IG02:                ;; offset=0x0054
       mov      rax, bword ptr [r8]
       mov      r14d, dword ptr [r8+0x08]
       mov      rcx, gword ptr [rbx+0x40]
       mov      r15d, dword ptr [rcx+0xE8]
       cmp      r15d, 16
       ja       G_M000_IG11
       cmp      byte  ptr [rbp+0x48], 0
       jne      G_M000_IG07
 
G_M000_IG03:                ;; offset=0x007A
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      ecx, r15d
       ja       G_M000_IG11
       lea      r8, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x170], r8
       mov      dword ptr [rbp-0x168], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x180], rcx
 
G_M000_IG04:                ;; offset=0x00AB
       mov      dword ptr [rbp-0x178], ecx
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], r9
       mov      gword ptr [rsp+0x38], rdx
       mov      bword ptr [rbp-0x190], rax
       mov      dword ptr [rbp-0x188], r14d
       lea      rcx, [rbp-0x170]
       lea      rdx, [rbp-0x180]
       lea      r9, [rbp-0x190]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, rbx
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG05:                ;; offset=0x00FE
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
       lea      rdx, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x170], rdx
       mov      dword ptr [rbp-0x168], r15d
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      bword ptr [rsp+0x28], rsi
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rsi
       mov      rsi, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rsi
       mov      rsi, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rsi
       lea      rdx, [rbp-0x140]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x170]
       lea      r8, [rbp-0x160]
       mov      rcx, rbx
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG06:                ;; offset=0x016E
       add      rsp, 440
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x017E
       xor      ecx, ecx
       test     r9, r9
       je       SHORT G_M000_IG08
       mov      ecx, 1
       test     r15d, r15d
       je       G_M000_IG15
       mov      gword ptr [rbp-0x128], r9
       xor      edx, edx
       mov      qword ptr [rbp-0x120], rdx
 
G_M000_IG08:                ;; offset=0x01A3
       cmp      ecx, r15d
       ja       SHORT G_M000_IG11
       lea      rdx, bword ptr [rbp-0x128]
       mov      r8d, ecx
       shl      r8, 4
       add      r8, rdx
       mov      edx, r15d
       sub      edx, ecx
       cmp      r14d, edx
       ja       SHORT G_M000_IG14
 
G_M000_IG09:                ;; offset=0x01C3
       mov      ecx, r14d
       shl      rcx, 4
       mov      r10, rcx
       cmp      r10, 0x4000
       ja       SHORT G_M000_IG13
 
G_M000_IG10:                ;; offset=0x01D6
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa62612aa8)], 0
       je       G_M000_IG05
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x01F3
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG12:                ;; offset=0x01FA
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG05
 
G_M000_IG13:                ;; offset=0x0204
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG05
 
G_M000_IG14:                ;; offset=0x0218
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG15:                ;; offset=0x021F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 549

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 4 inlinees with PGO data; 29 single block inlinees; 7 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 216
       lea      rbp, [rsp+0x110]
       xor      eax, eax
       mov      qword ptr [rbp-0xC8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xC0], ymm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x28], r9
       mov      rbx, rdx
       mov      rsi, r8
       mov      r14, bword ptr [rbp+0x38]
       mov      r12, bword ptr [rbp+0x40]
       mov      r15, bword ptr [rbp+0x48]
       mov      r13, bword ptr [rbp+0x50]
       mov      rdi, bword ptr [rbp+0x58]
 
G_M000_IG02:                ;; offset=0x0068
       mov      byte  ptr [r12], 0
       mov      rdx, 0x18B798012A0
       mov      rdx, gword ptr [rdx]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      r8d, r8d
       mov      qword ptr [r15+0x08], r8
 
G_M000_IG03:                ;; offset=0x0089
       mov      gword ptr [r13], r8
 
G_M000_IG04:                ;; offset=0x008D
       mov      qword ptr [rdi], r8
       mov      qword ptr [rdi+0x08], r8
       mov      qword ptr [rdi+0x10], r8
 
G_M000_IG05:                ;; offset=0x0098
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG06:                ;; offset=0x00A4
       mov      r8d, dword ptr [r14+0x08]
       mov      dword ptr [rsp+0x20], r8d
       lea      r8, [rbp-0xC8]
       movzx    rax, byte  ptr [rbp+0x30]
       mov      dword ptr [rbp-0xCC], eax
       mov      r9d, eax
       lea      rcx, [rbp-0x98]
       mov      rdx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:.ctor(Lokad.Lython.Runtime.PyExecutableFunction,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,int):this]
 
G_M000_IG07:                ;; offset=0x00D2
       vmovdqu  xmm0, xmmword ptr [rsi+0x08]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
       mov      rcx, qword ptr [rsi+0x18]
       mov      qword ptr [rbp-0xA0], rcx
 
G_M000_IG08:                ;; offset=0x00EA
       xor      ecx, ecx
       mov      dword ptr [rbp-0xB4], ecx
 
G_M000_IG09:                ;; offset=0x00F2
       lea      rcx, [rbp-0x98]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r8, r15
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Run(Lokad.Lython.LythonSourceSpan,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool:this]
       test     eax, eax
       jne      G_M000_IG19
       mov      rcx, bword ptr [rbp-0x50]
       mov      edx, dword ptr [rbp-0x48]
       mov      eax, dword ptr [rbp-0x5C]
       cmp      eax, edx
       ja       G_M000_IG20
       mov      r8d, eax
       shl      r8, 4
       add      rcx, r8
       sub      edx, eax
       add      rdx, rdx
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
       cmp      byte  ptr [rsi], 0
       jne      G_M000_IG18
 
G_M000_IG10:                ;; offset=0x0141
       mov      rdx, gword ptr [rbp+0x10]
       mov      r12, gword ptr [rdx+0x28]
       mov      rcx, gword ptr [rdx+0x40]
       mov      r8d, dword ptr [rcx+0xE8]
       mov      rcx, gword ptr [r12+0xA0]
       mov      rsi, gword ptr [rcx+0x88]
       mov      rcx, gword ptr [rdx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      r14d, dword ptr [rcx+0x08]
       cmp      r8d, r14d
       jge      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x0174
       mov      ecx, r8d
       mov      edx, r14d
       mov      r8, 0x18B4A146878
       call     [System.ArgumentOutOfRangeException:ThrowLess[int](int,int,System.String)]
       int3     
 
G_M000_IG12:                ;; offset=0x018B
       cmp      byte  ptr [rsi], sil
       mov      gword ptr [rsp+0x20], r12
       lea      rcx, bword ptr [rsi+0x50]
       mov      rdx, rsi
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.MemoryGovernor+WorkspaceCache:Rent(Lokad.Lython.Runtime.MemoryGovernor,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      gword ptr [rbp-0xA8], rsi
       mov      dword ptr [rbp-0xA0], r14d
       mov      dword ptr [rbp-0xB4], 1
       mov      esi, dword ptr [rbp-0x5C]
       cmp      esi, dword ptr [rbx+0x08]
       ja       G_M000_IG20
 
G_M000_IG13:                ;; offset=0x01CF
       mov      rdx, bword ptr [rbx]
       mov      rax, gword ptr [rbp-0xB0]
       test     rax, rax
       je       SHORT G_M000_IG14
       lea      rcx, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x01E7
       xor      rcx, rcx
       xor      eax, eax
 
G_M000_IG15:                ;; offset=0x01EB
       cmp      esi, eax
       ja       G_M000_IG23
 
G_M000_IG16:                ;; offset=0x01F3
       mov      r8d, esi
       shl      r8, 4
       cmp      r8, 0x4000
       ja       G_M000_IG22
 
G_M000_IG17:                ;; offset=0x0207
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa62612aa8)], 0
       jne      G_M000_IG21
 
G_M000_IG18:                ;; offset=0x0219
       mov      edx, dword ptr [rbp-0x5C]
       mov      dword ptr [rsp+0x20], edx
       mov      ebx, dword ptr [rbp-0xCC]
       mov      dword ptr [rsp+0x28], ebx
       mov      rdx, gword ptr [rbp-0x70]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0xB0]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateNativeContinuation(Lokad.Lython.Runtime.PyExecutableFunction,byref,Lokad.Lython.LythonSourceSpan,int,int,bool,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      rdx, rax
       mov      rcx, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, gword ptr [r13]
       lea      rcx, [rbp-0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TransferOwnership(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):this]
       mov      rdx, gword ptr [rbp-0xB0]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       lea      rcx, bword ptr [rdi+0x08]
       mov      rdx, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      eax, dword ptr [rbp-0xA0]
       mov      dword ptr [rdi+0x10], eax
       jmp      SHORT G_M000_IG24
 
G_M000_IG19:                ;; offset=0x0292
       cmp      dword ptr [rbp-0x64], 0
       setge    cl
       mov      byte  ptr [r12], cl
       jmp      SHORT G_M000_IG24
 
G_M000_IG20:                ;; offset=0x029F
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG21:                ;; offset=0x02A6
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG18
 
G_M000_IG22:                ;; offset=0x02B0
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG18
 
G_M000_IG23:                ;; offset=0x02BB
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG24:                ;; offset=0x02C2
       call     G_M000_IG33
       nop      
 
G_M000_IG25:                ;; offset=0x02C8
       add      rsp, 216
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x02DC
       sub      rsp, 56
 
G_M000_IG27:                ;; offset=0x02E0
       mov      rbx, rcx
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rsi, rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Name():System.String:this]
       mov      r8, rax
       mov      rdx, rsi
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyFunctionBinding:AnnotateException(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,Lokad.Lython.LythonSourceSpan)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG28:                ;; offset=0x0313
       sub      rsp, 56
 
G_M000_IG29:                ;; offset=0x0317
       cmp      dword ptr [rbp-0xB4], 0
       je       SHORT G_M000_IG31
       cmp      byte  ptr [rbp-0x56], 0
       jne      SHORT G_M000_IG31
       mov      r8, gword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rbp-0xA8]
       mov      rcx, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rcx+0x40]
       mov      r9d, dword ptr [rcx+0xE8]
       test     rdx, rdx
       je       SHORT G_M000_IG30
       lea      rcx, bword ptr [rdx+0x50]
       call     [Lokad.Lython.Runtime.MemoryGovernor+WorkspaceCache:Return(Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):this]
       jmp      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x0354
       mov      rcx, r8
       call     [System.Array:Clear(System.Array)]
 
G_M000_IG31:                ;; offset=0x035D
       nop      
 
G_M000_IG32:                ;; offset=0x035E
       add      rsp, 56
       ret      
 
G_M000_IG33:                ;; offset=0x0363
       sub      rsp, 56
 
G_M000_IG34:                ;; offset=0x0367
       lea      rcx, [rbp-0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Dispose():this]
       nop      
 
G_M000_IG35:                ;; offset=0x0375
       call     G_M000_IG28
       nop      
 
G_M000_IG36:                ;; offset=0x037B
       add      rsp, 56
       ret      
 
; Total bytes of code 896

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 168 single block inlinees; 46 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 224
       xor      eax, eax
       mov      qword ptr [rsp+0x38], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x40], ymm4
       vmovdqu  ymmword ptr [rsp+0x60], ymm4
       vmovdqu  ymmword ptr [rsp+0x80], ymm4
       vmovdqu  ymmword ptr [rsp+0xA0], ymm4
       vmovdqu  ymmword ptr [rsp+0xC0], ymm4
       mov      rbx, rcx
       mov      rsi, rdx
 
G_M000_IG02:                ;; offset=0x0049
       mov      rcx, 0x18B798012A0
       mov      rdx, gword ptr [rcx]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rsi+0x08], rcx
       mov      ecx, dword ptr [rbx+0x38]
       mov      rax, gword ptr [rbx+0x08]
       cmp      ecx, dword ptr [rax+0xEC]
       jge      G_M000_IG147
 
G_M000_IG03:                ;; offset=0x0077
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [rbx+0x38]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       shl      rax, 5
       lea      rdi, bword ptr [rcx+rax+0x10]
       mov      rcx, gword ptr [rbx+0x10]
       mov      rbp, gword ptr [rcx+0xA0]
       mov      r14, gword ptr [rdi]
       cmp      byte  ptr [rbp], bpl
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00B6
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG05:                ;; offset=0x00C2
       mov      ebp, dword ptr [rdi+0x1C]
       lea      ecx, [rbp-0x01]
       cmp      ecx, 76
       ja       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00CD
       mov      ecx, ecx
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*rcx]
       lea      rax, G_M000_IG02
       add      rdx, rax
       jmp      rdx
 
G_M000_IG07:                ;; offset=0x00E5
       xor      eax, eax
 
G_M000_IG08:                ;; offset=0x00E7
       add      rsp, 224
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG09:                ;; offset=0x00F9
       mov      rdx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rdx+0xEC]
       mov      rax, gword ptr [rdx+0x98]
       cmp      ecx, dword ptr [rax+0x08]
       jne      SHORT G_M000_IG07
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       G_M000_IG66
       mov      edx, dword ptr [rbx+0x3C]
       dec      edx
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG66
 
G_M000_IG10:                ;; offset=0x0133
       lea      r8, [rsp+0x78]
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerComparison(byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG17
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG11:                ;; offset=0x0150
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG12:                ;; offset=0x015B
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbp, rax
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG13:                ;; offset=0x018D
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG14:                ;; offset=0x0198
       mov      dword ptr [rsp+0x20], 1
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x0C]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r8, rax
       cmp      dword ptr [rdi+0x1C], 51
       jne      SHORT G_M000_IG15
       mov      ecx, dword ptr [rdi+0x14]
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x01D3
       mov      ecx, dword ptr [rdi+0x08]
       and      ecx, 0x7FFFFFFF
 
G_M000_IG16:                ;; offset=0x01DC
       mov      r9, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], r9
       lea      r9, [rsp+0x78]
       mov      qword ptr [rsp+0x28], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG07
 
G_M000_IG17:                ;; offset=0x0203
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG18
       not      edx
 
G_M000_IG18:                ;; offset=0x020C
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rcx, gword ptr [rbx+0x10]
       mov      rbp, gword ptr [rdi]
       mov      r14, gword ptr [rcx+0xA0]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG19
       mov      rcx, r14
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG19:                ;; offset=0x023F
       cmp      byte  ptr [rsp+0x78], 0
       jne      G_M000_IG145
       jmp      G_M000_IG66
 
G_M000_IG20:                ;; offset=0x024F
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG21:                ;; offset=0x0256
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG22:                ;; offset=0x0261
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbp, rax
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG07
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      r8, gword ptr [rdi]
       mov      rdx, gword ptr [rbx+0x10]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG66
 
G_M000_IG23:                ;; offset=0x02C9
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerOperation():bool:this]
       test     eax, eax
       jne      G_M000_IG145
 
G_M000_IG24:                ;; offset=0x02DA
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG25:                ;; offset=0x02DE
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG26:                ;; offset=0x02E9
       lea      rdx, [rsp+0xA8]
       mov      qword ptr [rsp+0x20], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rbx+0x38]
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateBuiltinArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):bool]
       test     eax, eax
       je       G_M000_IG07
 
G_M000_IG27:                ;; offset=0x031A
       vmovdqu  xmm0, xmmword ptr [rsp+0xA8]
       vmovdqu  xmmword ptr [rsp+0x38], xmm0
 
G_M000_IG28:                ;; offset=0x0329
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG29:                ;; offset=0x033F
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG30:                ;; offset=0x0346
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG31:                ;; offset=0x0351
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbp, rax
       mov      rcx, gword ptr [rbx+0x08]
       mov      r14, bword ptr [rbx+0x48]
       mov      r15d, dword ptr [rbx+0x50]
       mov      r13d, dword ptr [rdi+0x0C]
       mov      r8, gword ptr [rbx+0x10]
       xor      r9d, r9d
       mov      gword ptr [rsp+0x58], r9
 
G_M000_IG32:                ;; offset=0x039B
       mov      gword ptr [rsp+0x60], r9
       test     r13d, r13d
       jge      SHORT G_M000_IG35
       mov      r15d, r13d
       not      r15d
       mov      r13, gword ptr [rcx+0x30]
       mov      edx, r15d
       sub      edx, dword ptr [r13+0x08]
       js       SHORT G_M000_IG34
       mov      r13, gword ptr [rcx+0x38]
       cmp      dword ptr [r13+0x08], edx
       jle      SHORT G_M000_IG33
       lea      r9, [rsp+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       lea      rdx, [rsp+0x98]
       mov      rcx, gword ptr [rsp+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG36
 
G_M000_IG33:                ;; offset=0x03E2
       sub      edx, dword ptr [r13+0x08]
       lea      rcx, [rsp+0x58]
       lea      r8, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:TryReadInteger(int,byref):bool:this]
       jmp      SHORT G_M000_IG36
 
G_M000_IG34:                ;; offset=0x03FB
       cmp      r15d, dword ptr [r13+0x08]
       jae      G_M000_IG225
       mov      ecx, r15d
       mov      rcx, gword ptr [r13+8*rcx+0x10]
       lea      rdx, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x041D
       cmp      r13d, r15d
       jae      G_M000_IG225
       mov      ecx, r13d
       shl      rcx, 4
       add      rcx, r14
       lea      rdx, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
 
G_M000_IG36:                ;; offset=0x043E
       xor      r9, r9
       mov      gword ptr [rsp+0x60], r9
       test     eax, eax
       je       SHORT G_M000_IG37
       mov      rdx, qword ptr [rsp+0x98]
       lea      r9, [rsp+0x88]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIndexing:TryReadSequenceIndex(System.Object,long,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG50
 
G_M000_IG37:                ;; offset=0x0477
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG38:                ;; offset=0x047B
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG39:                ;; offset=0x0486
       mov      dword ptr [rsp+0x20], 1
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x0C]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r14, rax
       test     rbp, rbp
       je       G_M000_IG07
 
G_M000_IG40:                ;; offset=0x04BF
       mov      rcx, 0x7FFA02BC48D8
       cmp      qword ptr [rbp], rcx
       jne      G_M000_IG07
 
G_M000_IG41:                ;; offset=0x04D3
       cmp      gword ptr [rbp+0x28], 0
       jne      SHORT G_M000_IG42
       mov      rcx, gword ptr [rbp+0x08]
       mov      r11, 0x7FFA02612070
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       jne      G_M000_IG07
       jmp      SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x04F5
       cmp      dword ptr [rbp+0x50], 0
       jne      G_M000_IG07
 
G_M000_IG43:                ;; offset=0x04FF
       test     r14, r14
       je       G_M000_IG07
 
G_M000_IG44:                ;; offset=0x0508
       mov      rcx, 0x7FFA02B1DAA0
       cmp      qword ptr [r14], rcx
       jne      G_M000_IG07
 
G_M000_IG45:                ;; offset=0x051B
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       test     eax, eax
       jl       SHORT G_M000_IG46
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG46
       mov      rcx, gword ptr [rbx]
       mov      rdx, gword ptr [rdi]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:GetLookupCaches(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntime+ExecutableLookupCache[]:this]
       mov      r15, rax
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       cmp      eax, dword ptr [r15+0x08]
       jae      G_M000_IG225
       mov      r8d, eax
       lea      r8, [r8+2*r8]
       lea      r8, bword ptr [r15+8*r8+0x10]
       mov      r9, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], r9
       lea      r9, [rsp+0x80]
       mov      qword ptr [rsp+0x28], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      rdx, r14
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyDict:TryReadRecordValue(Lokad.Lython.Runtime.Text.PyString,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG49
 
G_M000_IG46:                ;; offset=0x0588
       cmp      gword ptr [rbp+0x28], 0
       jne      SHORT G_M000_IG47
       mov      rcx, gword ptr [rbp+0x08]
       mov      r11, 0x7FFA02612078
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       jne      G_M000_IG07
       jmp      SHORT G_M000_IG48
 
G_M000_IG47:                ;; offset=0x05AA
       cmp      dword ptr [rbp+0x50], 0
       jne      G_M000_IG07
 
G_M000_IG48:                ;; offset=0x05B4
       mov      r8, gword ptr [rdi]
       mov      r9, gword ptr [rbx+0x10]
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rsp+0x38], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG49:                ;; offset=0x05EA
       mov      r8, gword ptr [rsp+0x80]
       mov      gword ptr [rsp+0x38], r8
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG50:                ;; offset=0x0615
       vmovdqu  xmm0, xmmword ptr [rsp+0x88]
       vmovdqu  xmmword ptr [rsp+0x38], xmm0
 
G_M000_IG51:                ;; offset=0x0624
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG52:                ;; offset=0x063A
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG53:                ;; offset=0x0653
       lea      rcx, bword ptr [rbx+0x48]
       mov      eax, dword ptr [rdi+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       shl      rax, 4
       add      rax, bword ptr [rcx]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FFA02CC7D70
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rcx, rax
       test     rcx, rcx
       je       SHORT G_M000_IG56
 
G_M000_IG54:                ;; offset=0x068E
       mov      rdx, 0x7FFA02D95A60
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG56
 
G_M000_IG55:                ;; offset=0x069D
       lea      rdx, [rsp+0x68]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG62
 
G_M000_IG56:                ;; offset=0x06AA
       test     rcx, rcx
       je       SHORT G_M000_IG59
 
G_M000_IG57:                ;; offset=0x06AF
       mov      rdx, 0x7FFA02D972F8
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x06BE
       lea      rdx, [rsp+0x68]
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG62
 
G_M000_IG59:                ;; offset=0x06CB
       mov      rbp, rcx
       test     rbp, rbp
       je       SHORT G_M000_IG61
 
G_M000_IG60:                ;; offset=0x06D3
       mov      rax, 0x7FFA02CC78D8
       cmp      qword ptr [rbp], rax
       jne      G_M000_IG221
 
G_M000_IG61:                ;; offset=0x06E7
       cmp      byte  ptr [rbp], bpl
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:CheckExecution():this]
       lea      rdx, [rsp+0x68]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextCore():Lokad.Lython.Runtime.PyIterationResult:this]
 
G_M000_IG62:                ;; offset=0x0702
       cmp      gword ptr [rsp+0x68], 0
       je       SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x070A
       vmovdqu  xmm0, xmmword ptr [rsp+0x68]
       vmovdqu  xmmword ptr [rsp+0x38], xmm0
 
G_M000_IG64:                ;; offset=0x0716
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG65:                ;; offset=0x072C
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG66:                ;; offset=0x0738
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [rbx+0x38], eax
       jmp      G_M000_IG146
 
G_M000_IG67:                ;; offset=0x0749
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG68:                ;; offset=0x0750
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG69:                ;; offset=0x075B
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbp, rax
       test     rbp, rbp
       je       G_M000_IG74
 
G_M000_IG70:                ;; offset=0x0792
       mov      r8, 0x7FFA02D95A60
       cmp      qword ptr [rbp], r8
       jne      SHORT G_M000_IG72
 
G_M000_IG71:                ;; offset=0x07A2
       mov      gword ptr [rsp+0x38], rbp
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG72:                ;; offset=0x07C5
       mov      rcx, 0x7FFA02CF6490
       cmp      qword ptr [rbp], rcx
       jne      SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x07D5
       mov      rcx, 0x7FFA02D972F8
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rcx, r14
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:.ctor(Lokad.Lython.Runtime.PyRange):this]
       mov      gword ptr [rsp+0x38], r14
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG74:                ;; offset=0x0816
       test     rbp, rbp
       je       SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x081B
       mov      rdx, 0x7FFA02CCE030
       cmp      qword ptr [rbp], rdx
       je       SHORT G_M000_IG78
 
G_M000_IG76:                ;; offset=0x082B
       mov      rdx, rbp
       mov      rcx, 0x7FFA02C28AB0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG78
       test     rbp, rbp
       je       G_M000_IG07
 
G_M000_IG77:                ;; offset=0x084B
       mov      r8, 0x7FFA02BE3E60
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG78
       mov      r8, 0x7FFA02B1DAA0
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG78
       mov      r8, 0x7FFA02BC48D8
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG78
       mov      r8, 0x7FFA02CED920
       cmp      qword ptr [rbp], r8
       jne      G_M000_IG07
 
G_M000_IG78:                ;; offset=0x088F
       mov      r8, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rdi]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      gword ptr [rsp+0x38], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG79:                ;; offset=0x08C2
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ConstructContainer(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG80:                ;; offset=0x08DB
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG160
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       jne      SHORT G_M000_IG81
       mov      rcx, 0x18B798015F0
       mov      rbp, gword ptr [rcx]
       jmp      SHORT G_M000_IG82
 
G_M000_IG81:                ;; offset=0x090B
       lea      rbp, bword ptr [rbx+0x48]
       mov      r14d, dword ptr [rdi+0x10]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      ecx, r14d
       mov      edx, eax
       add      rcx, rdx
       mov      edx, dword ptr [rbp+0x08]
       cmp      rcx, rdx
       ja       G_M000_IG224
       mov      ecx, r14d
       shl      rcx, 4
       add      rcx, bword ptr [rbp]
       mov      bword ptr [rsp+0x48], rcx
       mov      dword ptr [rsp+0x50], eax
       lea      rcx, [rsp+0x48]
       mov      rdx, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.PyTuple:FromSlots(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rbp, rax
 
G_M000_IG82:                ;; offset=0x0959
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rsp+0x38], rbp
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG83:                ;; offset=0x0988
       lea      rbp, bword ptr [rbx+0x48]
       mov      r14d, dword ptr [rdi+0x10]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      ecx, r14d
       mov      edx, eax
       add      rcx, rdx
       mov      edx, dword ptr [rbp+0x08]
       cmp      rcx, rdx
       ja       G_M000_IG224
       mov      ecx, r14d
       shl      rcx, 4
       add      rcx, bword ptr [rbp]
       mov      bword ptr [rsp+0x48], rcx
       mov      dword ptr [rsp+0x50], eax
       lea      rcx, [rsp+0x48]
       mov      rdx, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateSlotList(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      rbp, rax
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rsp+0x38], rbp
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG84:                ;; offset=0x0A05
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG85:                ;; offset=0x0A0C
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG86:                ;; offset=0x0A17
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG87
       not      edx
 
G_M000_IG87:                ;; offset=0x0A4B
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG145
 
G_M000_IG88:                ;; offset=0x0A59
       mov      ecx, ebp
       cmp      ecx, 51
       ja       SHORT G_M000_IG93
 
G_M000_IG89:                ;; offset=0x0A60
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG93
 
G_M000_IG90:                ;; offset=0x0A70
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG91
       mov      r14d, ebp
       not      r14d
       jmp      SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x0A7F
       mov      r14d, ebp
 
G_M000_IG92:                ;; offset=0x0A82
       jmp      SHORT G_M000_IG94
 
G_M000_IG93:                ;; offset=0x0A84
       mov      r14d, dword ptr [rdi+0x14]
 
G_M000_IG94:                ;; offset=0x0A88
       inc      r14d
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG95
       mov      r15d, ebp
       not      r15d
       jmp      SHORT G_M000_IG96
 
G_M000_IG95:                ;; offset=0x0A9A
       mov      r15d, ebp
 
G_M000_IG96:                ;; offset=0x0A9D
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG97:                ;; offset=0x0AA4
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG98:                ;; offset=0x0AAF
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rdi, rax
       cmp      r15d, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG99
       mov      rcx, rbx
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG99:                ;; offset=0x0AEF
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       mov      ebp, r14d
       shl      rbp, 4
       add      rbp, bword ptr [rcx]
       mov      rcx, rbp
       mov      rdx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      edx, edx
       mov      qword ptr [rbp+0x08], rdx
       mov      dword ptr [rbx+0x3C], r15d
       jmp      G_M000_IG145
 
G_M000_IG100:                ;; offset=0x0B21
       lea      rcx, bword ptr [rbx+0x58]
       mov      edx, ebp
       cmp      edx, 3
       je       SHORT G_M000_IG101
       cmp      edx, 26
       jne      G_M000_IG223
 
G_M000_IG101:                ;; offset=0x0B35
       mov      edx, dword ptr [rdi+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:GetCell(int):Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:this]
       mov      rbp, rax
       test     rbp, rbp
       je       G_M000_IG07
       mov      rcx, gword ptr [rbp+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG102
       cmp      gword ptr [rbp+0x18], 0
       je       G_M000_IG07
       cmp      gword ptr [rcx+0x88], 0
       jne      G_M000_IG07
 
G_M000_IG102:                ;; offset=0x0B6C
       mov      r8d, dword ptr [rdi+0x10]
       test     r8d, r8d
       jl       SHORT G_M000_IG106
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       mov      edx, r8d
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       mov      r14, gword ptr [rdx]
       mov      r15, qword ptr [rdx+0x08]
       test     r14, r14
       jne      SHORT G_M000_IG105
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG103:                ;; offset=0x0B9D
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG104:                ;; offset=0x0BA8
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
 
G_M000_IG105:                ;; offset=0x0BCF
       jmp      SHORT G_M000_IG109
 
G_M000_IG106:                ;; offset=0x0BD1
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG107:                ;; offset=0x0BD5
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG108:                ;; offset=0x0BE0
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r14, rax
       xor      r15d, r15d
 
G_M000_IG109:                ;; offset=0x0C0D
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x10]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       mov      rcx, bword ptr [rcx]
       shl      rdx, 4
       xor      eax, eax
       mov      qword ptr [rcx+rdx], rax
       mov      qword ptr [rcx+rdx+0x08], rax
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG110
       not      edx
 
G_M000_IG110:                ;; offset=0x0C38
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rsp+0x38], r14
       mov      qword ptr [rsp+0x40], r15
       lea      rdx, [rsp+0x38]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:StoreSlot(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG111:                ;; offset=0x0C5E
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StoreLocal(byref):this]
       jmp      G_M000_IG145
 
G_M000_IG112:                ;; offset=0x0C6F
       mov      r8, 0x7FFA02CCD5C0
       cmp      qword ptr [rbp], r8
       jne      G_M000_IG166
 
G_M000_IG113:                ;; offset=0x0C83
       lea      r8, [rsp+0xA0]
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.PyAttributeLookup:TryResolveInstanceFunctionForCall(Lokad.Lython.Runtime.PyInstance,System.String,byref):bool]
       test     eax, eax
       je       G_M000_IG166
       mov      r15, gword ptr [rsp+0xA0]
 
G_M000_IG114:                ;; offset=0x0CA7
       test     r15, r15
       je       G_M000_IG07
       mov      ecx, dword ptr [rdi+0x1C]
       mov      edx, ecx
       cmp      edx, 51
       ja       SHORT G_M000_IG118
 
G_M000_IG115:                ;; offset=0x0CBA
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG118
 
G_M000_IG116:                ;; offset=0x0CCA
       mov      r14d, dword ptr [rdi+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG117
       not      r14d
 
G_M000_IG117:                ;; offset=0x0CD6
       jmp      SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x0CD8
       mov      r14d, dword ptr [rdi+0x14]
 
G_M000_IG119:                ;; offset=0x0CDC
       cmp      ecx, 51
       ja       SHORT G_M000_IG124
 
G_M000_IG120:                ;; offset=0x0CE1
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG124
 
G_M000_IG121:                ;; offset=0x0CF1
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG122
       mov      r13d, ecx
       not      r13d
       jmp      SHORT G_M000_IG123
 
G_M000_IG122:                ;; offset=0x0D00
       mov      r13d, ecx
 
G_M000_IG123:                ;; offset=0x0D03
       jmp      SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x0D05
       mov      r13d, dword ptr [rdi+0x14]
 
G_M000_IG125:                ;; offset=0x0D09
       inc      r13d
       cmp      r13d, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG126
       mov      rcx, rbx
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG126:                ;; offset=0x0D1E
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       mov      r14d, r14d
       shl      r14, 4
       add      r14, bword ptr [rcx]
       mov      rcx, r14
       mov      rdx, rbp
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
       mov      dword ptr [rbx+0x3C], r13d
       mov      ecx, dword ptr [rdi+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG130
 
G_M000_IG127:                ;; offset=0x0D53
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG130
 
G_M000_IG128:                ;; offset=0x0D63
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG129
       not      ebp
 
G_M000_IG129:                ;; offset=0x0D6C
       jmp      SHORT G_M000_IG131
 
G_M000_IG130:                ;; offset=0x0D6E
       mov      ebp, dword ptr [rdi+0x14]
 
G_M000_IG131:                ;; offset=0x0D71
       inc      ebp
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG132
       mov      edi, ecx
       not      edi
       jmp      SHORT G_M000_IG133
 
G_M000_IG132:                ;; offset=0x0D80
       mov      edi, ecx
 
G_M000_IG133:                ;; offset=0x0D82
       cmp      edi, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG134
       mov      rcx, rbx
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG134:                ;; offset=0x0D92
       lea      rcx, bword ptr [rbx+0x48]
       cmp      ebp, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       mov      ebp, ebp
       shl      rbp, 4
       add      rbp, bword ptr [rcx]
       mov      rcx, rbp
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbp+0x08], rcx
       mov      dword ptr [rbx+0x3C], edi
       jmp      G_M000_IG145
 
G_M000_IG135:                ;; offset=0x0DC1
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StoreSubscript(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG136:                ;; offset=0x0DDA
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ApplyDefinition(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG137:                ;; offset=0x0DF3
       mov      rdx, gword ptr [rbx+0x08]
       mov      rbp, rdx
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rbp
       mov      r8, gword ptr [rdi]
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rsp+0x38], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG138:                ;; offset=0x0E38
       mov      rcx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x20], rcx
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      r8d, dword ptr [rbx+0x38]
       mov      r9d, dword ptr [rbx+0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      SHORT G_M000_IG140
       lea      rcx, bword ptr [rbx+0x58]
       mov      edx, dword ptr [rdi+0x1C]
       cmp      edx, 3
       je       SHORT G_M000_IG139
       cmp      edx, 26
       jne      G_M000_IG223
 
G_M000_IG139:                ;; offset=0x0E73
       mov      edx, dword ptr [rdi+0x08]
       lea      r8, [rsp+0xC8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:TryRead(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG07
       cmp      gword ptr [rsp+0xC8], 0
       je       G_M000_IG07
       mov      r8, gword ptr [rsp+0xC8]
       mov      gword ptr [rsp+0x38], r8
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG140:                ;; offset=0x0EC6
       add      dword ptr [rbx+0x38], 2
       jmp      G_M000_IG145
 
G_M000_IG141:                ;; offset=0x0ECF
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      r8d, eax
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG142:                ;; offset=0x0EDF
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG143:                ;; offset=0x0EEA
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      gword ptr [rsp+0x38], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      SHORT G_M000_IG145
 
G_M000_IG144:                ;; offset=0x0F31
       mov      rdx, gword ptr [rbx+0x08]
       mov      rbp, gword ptr [rdx+0x30]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbp+0x08]
       jae      G_M000_IG225
       mov      ecx, eax
       mov      rcx, gword ptr [rbp+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rsp+0x38], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG145:                ;; offset=0x0F76
       inc      dword ptr [rbx+0x38]
 
G_M000_IG146:                ;; offset=0x0F79
       mov      ecx, dword ptr [rbx+0x38]
       mov      rax, gword ptr [rbx+0x08]
       cmp      ecx, dword ptr [rax+0xEC]
       jl       G_M000_IG03
 
G_M000_IG147:                ;; offset=0x0F8C
       mov      eax, dword ptr [rbx+0x38]
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       cmp      eax, dword ptr [rcx+0x08]
       setge    al
       movzx    rax, al
 
G_M000_IG148:                ;; offset=0x0FA3
       add      rsp, 224
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG149:                ;; offset=0x0FB5
       mov      rdx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rdx+0xEC]
       mov      rdx, gword ptr [rdx+0x98]
       cmp      ecx, dword ptr [rdx+0x08]
       jne      G_M000_IG07
       jmp      G_M000_IG159
 
G_M000_IG150:                ;; offset=0x0FD4
       mov      rdx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rdx+0xEC]
       mov      r9, gword ptr [rdx+0x98]
       cmp      ecx, dword ptr [r9+0x08]
       jne      G_M000_IG07
       mov      r8d, dword ptr [rdi+0x10]
       test     r8d, r8d
       jl       SHORT G_M000_IG154
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       mov      r9d, r8d
       shl      r9, 4
       add      r9, bword ptr [rcx]
       mov      rbp, gword ptr [r9]
       mov      r14, qword ptr [r9+0x08]
       test     rbp, rbp
       jne      SHORT G_M000_IG153
       mov      rcx, rdx
 
G_M000_IG151:                ;; offset=0x101F
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG152:                ;; offset=0x102A
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
 
G_M000_IG153:                ;; offset=0x1051
       jmp      SHORT G_M000_IG157
 
G_M000_IG154:                ;; offset=0x1053
       mov      rcx, rdx
 
G_M000_IG155:                ;; offset=0x1056
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG156:                ;; offset=0x1061
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbp, rax
       xor      r14d, r14d
 
G_M000_IG157:                ;; offset=0x108E
       mov      rcx, rsi
       mov      rdx, rbp
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [rsi+0x08], r14
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      edx, dword ptr [rcx+0xD8]
       jl       SHORT G_M000_IG159
       lea      rcx, bword ptr [rbx+0x48]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       xor      rcx, rcx
       mov      gword ptr [rdx], rcx
 
G_M000_IG158:                ;; offset=0x10C5
       mov      qword ptr [rdx+0x08], rcx
 
G_M000_IG159:                ;; offset=0x10C9
       mov      rdx, gword ptr [rbx+0x08]
       mov      edx, dword ptr [rdx+0xD8]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG160:                ;; offset=0x10DC
       mov      eax, 1
 
G_M000_IG161:                ;; offset=0x10E1
       add      rsp, 224
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG162:                ;; offset=0x10F3
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryExecuteCasedSplitMember(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
 
G_M000_IG163:                ;; offset=0x1107
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG164:                ;; offset=0x110B
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG165:                ;; offset=0x1116
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbp, rax
       mov      rcx, gword ptr [rbx+0x08]
       mov      r14, gword ptr [rcx+0x38]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG225
       mov      r8d, eax
       mov      r14, gword ptr [r14+8*r8+0x10]
       test     rbp, rbp
       jne      G_M000_IG112
 
G_M000_IG166:                ;; offset=0x1170
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveBuiltinReceiverMethod(System.Object,System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      r15, rax
       jmp      G_M000_IG114
 
G_M000_IG167:                ;; offset=0x1184
       mov      rcx, gword ptr [rbx+0x08]
       mov      edx, dword ptr [rcx+0xEC]
       mov      r9, gword ptr [rcx+0x98]
       cmp      edx, dword ptr [r9+0x08]
       jne      G_M000_IG141
 
G_M000_IG168:                ;; offset=0x119F
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG169:                ;; offset=0x11AA
       mov      edx, dword ptr [rbx+0x30]
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x3C]
       lea      r8, bword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryPrepareFixedTupleReturn(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       G_M000_IG141
 
G_M000_IG170:                ;; offset=0x11D5
       mov      ecx, dword ptr [rbx+0x3C]
       mov      dword ptr [rbx+0x34], ecx
       mov      ecx, dword ptr [rbx+0x30]
       add      dword ptr [rbx+0x3C], ecx
       jmp      G_M000_IG160
 
G_M000_IG171:                ;; offset=0x11E6
       mov      ecx, dword ptr [rdi+0x0C]
       add      ecx, 2
       mov      rdx, gword ptr [rbx+0x08]
       cmp      ecx, dword ptr [rdx+0xEC]
       jge      SHORT G_M000_IG174
       mov      rcx, gword ptr [rbx+0x10]
       mov      rcx, gword ptr [rcx+0xA0]
       cmp      qword ptr [rcx+0x158], 8
       jge      SHORT G_M000_IG174
       mov      rcx, rdx
 
G_M000_IG172:                ;; offset=0x1210
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG173:                ;; offset=0x121B
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0xD0]
       mov      qword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x3C]
       lea      r8, bword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateIntegerCallUpdate(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG183
 
G_M000_IG174:                ;; offset=0x1248
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG175
       mov      r8d, edx
       not      r8d
       jmp      SHORT G_M000_IG176
 
G_M000_IG175:                ;; offset=0x1257
       mov      r8d, edx
 
G_M000_IG176:                ;; offset=0x125A
       mov      ecx, dword ptr [rdi+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG180
 
G_M000_IG177:                ;; offset=0x1262
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG180
 
G_M000_IG178:                ;; offset=0x1272
       test     edx, edx
       jge      SHORT G_M000_IG179
       not      edx
 
G_M000_IG179:                ;; offset=0x1278
       jmp      SHORT G_M000_IG181
 
G_M000_IG180:                ;; offset=0x127A
       mov      edx, dword ptr [rdi+0x14]
 
G_M000_IG181:                ;; offset=0x127D
       cmp      r8d, edx
       jne      G_M000_IG141
 
G_M000_IG182:                ;; offset=0x1286
       lea      rbp, bword ptr [rbx+0x48]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbp+0x08]
       jae      G_M000_IG225
       mov      rcx, bword ptr [rbp]
       mov      eax, eax
       shl      rax, 4
       cmp      gword ptr [rcx+rax], 0
       jne      G_M000_IG145
       jmp      G_M000_IG222
 
G_M000_IG183:                ;; offset=0x12B6
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdx, gword ptr [rdx+0x98]
       mov      r8d, dword ptr [rbx+0x38]
       cmp      r8d, dword ptr [rdx+0x08]
       jae      G_M000_IG225
       shl      r8, 5
       lea      rdx, bword ptr [rdx+r8+0x10]
 
G_M000_IG184:                ;; offset=0x12D8
       vmovdqu  xmm0, xmmword ptr [rsp+0xD0]
       vmovdqu  xmmword ptr [rsp+0x38], xmm0
 
G_M000_IG185:                ;; offset=0x12E7
       lea      r8, [rsp+0x38]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG186:                ;; offset=0x12FA
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x10]
       mov      r8d, dword ptr [rdi+0x08]
       mov      eax, edx
       mov      r10d, r8d
       add      rax, r10
       mov      r10d, dword ptr [rcx+0x08]
       cmp      rax, r10
       ja       G_M000_IG224
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       mov      bword ptr [rsp+0x48], rdx
       mov      dword ptr [rsp+0x50], r8d
       lea      rcx, [rsp+0x48]
       mov      rdx, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rdx+0xA0]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReverseAssignmentValues(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.ExecutionState,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG145
 
G_M000_IG187:                ;; offset=0x1349
       lea      rcx, bword ptr [rbx+0x48]
       cmp      ebp, 51
       ja       SHORT G_M000_IG191
 
G_M000_IG188:                ;; offset=0x1352
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rbp
       jb       SHORT G_M000_IG191
 
G_M000_IG189:                ;; offset=0x1362
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG190
       not      ebp
 
G_M000_IG190:                ;; offset=0x136B
       jmp      SHORT G_M000_IG192
 
G_M000_IG191:                ;; offset=0x136D
       mov      ebp, dword ptr [rdi+0x14]
 
G_M000_IG192:                ;; offset=0x1370
       cmp      ebp, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       mov      rcx, bword ptr [rcx]
       mov      eax, ebp
       shl      rax, 4
 
G_M000_IG193:                ;; offset=0x1382
       vmovdqu  xmm0, xmmword ptr [rcx+rax]
       vmovdqu  xmmword ptr [rsp+0xB8], xmm0
 
G_M000_IG194:                ;; offset=0x1390
       cmp      gword ptr [rsp+0xB8], 0
       jne      SHORT G_M000_IG195
       lea      rcx, [rsp+0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FFA02CC7D70
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
 
G_M000_IG195:                ;; offset=0x13BC
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG199
 
G_M000_IG196:                ;; offset=0x13C8
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG199
 
G_M000_IG197:                ;; offset=0x13D8
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG198
       not      edx
 
G_M000_IG198:                ;; offset=0x13E1
       jmp      SHORT G_M000_IG200
 
G_M000_IG199:                ;; offset=0x13E3
       mov      edx, dword ptr [rdi+0x14]
 
G_M000_IG200:                ;; offset=0x13E6
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       mov      rcx, bword ptr [rcx]
       mov      edx, edx
       shl      rdx, 4
       xor      eax, eax
       mov      qword ptr [rcx+rdx], rax
       mov      qword ptr [rcx+rdx+0x08], rax
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG201
       not      edx
 
G_M000_IG201:                ;; offset=0x140C
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rcx, bword ptr [rbx+0x48]
       mov      r8d, dword ptr [rbx+0x50]
       mov      rdx, gword ptr [rsp+0xB8]
       mov      r9, qword ptr [rsp+0xC0]
       mov      rax, gword ptr [rbx+0x10]
       mov      rax, gword ptr [rax+0xA0]
       mov      r10d, dword ptr [rdi+0x10]
       cmp      r10d, r8d
       jae      G_M000_IG225
       mov      r8d, r10d
       shl      r8, 4
       add      rcx, r8
       mov      gword ptr [rsp+0x38], rdx
       mov      qword ptr [rsp+0x40], r9
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      r9, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG145
 
G_M000_IG202:                ;; offset=0x146F
       mov      rdx, gword ptr [rbx+0x08]
       mov      rbp, gword ptr [rdx+0x30]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbp+0x08]
       jae      G_M000_IG225
       mov      edx, eax
       mov      rdx, gword ptr [rbp+8*rdx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG204
 
G_M000_IG203:                ;; offset=0x1498
       mov      rax, 0x7FFA02B1ABA8
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG220
 
G_M000_IG204:                ;; offset=0x14AB
       lea      rdx, bword ptr [rbx+0x48]
       mov      r8d, dword ptr [rdi+0x1C]
       mov      r9d, r8d
       cmp      r9d, 51
       ja       SHORT G_M000_IG208
 
G_M000_IG205:                ;; offset=0x14BC
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, r9
       jb       SHORT G_M000_IG208
 
G_M000_IG206:                ;; offset=0x14CC
       mov      r9d, dword ptr [rdi+0x18]
       test     r9d, r9d
       jge      SHORT G_M000_IG207
       not      r9d
 
G_M000_IG207:                ;; offset=0x14D8
       jmp      SHORT G_M000_IG209
 
G_M000_IG208:                ;; offset=0x14DA
       mov      r9d, dword ptr [rdi+0x14]
 
G_M000_IG209:                ;; offset=0x14DE
       mov      eax, dword ptr [rdi+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG210
       mov      r10d, eax
       not      r10d
       jmp      SHORT G_M000_IG211
 
G_M000_IG210:                ;; offset=0x14ED
       mov      r10d, eax
 
G_M000_IG211:                ;; offset=0x14F0
       cmp      r8d, 51
       ja       SHORT G_M000_IG216
 
G_M000_IG212:                ;; offset=0x14F6
       mov      r11, 0x7FFFFFFFFF9FF
       bt       r11, r8
       jb       SHORT G_M000_IG216
 
G_M000_IG213:                ;; offset=0x1506
       test     eax, eax
       jge      SHORT G_M000_IG214
       mov      r8d, eax
       not      r8d
       jmp      SHORT G_M000_IG215
 
G_M000_IG214:                ;; offset=0x1512
       mov      r8d, eax
 
G_M000_IG215:                ;; offset=0x1515
       jmp      SHORT G_M000_IG217
 
G_M000_IG216:                ;; offset=0x1517
       mov      r8d, dword ptr [rdi+0x14]
 
G_M000_IG217:                ;; offset=0x151B
       sub      r10d, r8d
       mov      r8d, r9d
       mov      eax, r10d
       add      r8, rax
       mov      eax, dword ptr [rdx+0x08]
       cmp      r8, rax
       ja       G_M000_IG224
       mov      r8d, r9d
       shl      r8, 4
       add      r8, bword ptr [rdx]
       mov      bword ptr [rsp+0x48], r8
       mov      dword ptr [rsp+0x50], r10d
       mov      rdx, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x48]
       cmp      dword ptr [rdi+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG218
       not      ecx
 
G_M000_IG218:                ;; offset=0x1573
       mov      dword ptr [rbx+0x3C], ecx
       jmp      G_M000_IG145
 
G_M000_IG219:                ;; offset=0x157B
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG220:                ;; offset=0x1594
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG221:                ;; offset=0x159D
       mov      rdx, rcx
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG222:                ;; offset=0x15A9
       mov      rcx, gword ptr [rbx+0x08]
       mov      rbx, gword ptr [rcx+0x68]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r11, 0x7FFA02612068
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG223:                ;; offset=0x15E1
       mov      rcx, rdi
       mov      rdx, 0x18B4A14C1B8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG224:                ;; offset=0x15FD
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG225:                ;; offset=0x1604
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000EE8h ; case G_M000_IG144
       	dd	00000E86h ; case G_M000_IG141
       	dd	00000DEFh ; case G_M000_IG138
       	dd	00000DAAh ; case G_M000_IG137
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000D91h ; case G_M000_IG136
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000D78h ; case G_M000_IG135
       	dd	00000D78h ; case G_M000_IG135
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	000010BEh ; case G_M000_IG163
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000C15h ; case G_M000_IG111
       	dd	00000AD8h ; case G_M000_IG100
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000A10h ; case G_M000_IG88
       	dd	000009BCh ; case G_M000_IG84
       	dd	0000093Fh ; case G_M000_IG83
       	dd	00000892h ; case G_M000_IG80
       	dd	00000879h ; case G_M000_IG79
       	dd	00000879h ; case G_M000_IG79
       	dd	00000879h ; case G_M000_IG79
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000700h ; case G_M000_IG67
       	dd	0000060Ah ; case G_M000_IG53
       	dd	000005F1h ; case G_M000_IG52
       	dd	000002F6h ; case G_M000_IG29
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000280h ; case G_M000_IG23
       	dd	00000280h ; case G_M000_IG23
       	dd	00000291h ; case G_M000_IG24
       	dd	000006EFh ; case G_M000_IG66
       	dd	00000206h ; case G_M000_IG20
       	dd	000000EAh ; case G_M000_IG10
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000F8Bh ; case G_M000_IG150
       	dd	00000F6Ch ; case G_M000_IG149
       	dd	00000F6Ch ; case G_M000_IG149
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	000000B0h ; case G_M000_IG09
       	dd	00001532h ; case G_M000_IG219
       	dd	00001532h ; case G_M000_IG219
       	dd	00001532h ; case G_M000_IG219
       	dd	00001532h ; case G_M000_IG219
       	dd	00001532h ; case G_M000_IG219
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000060Ah ; case G_M000_IG53
       	dd	00001426h ; case G_M000_IG202
       	dd	00001300h ; case G_M000_IG187
       	dd	0000123Dh ; case G_M000_IG182
       	dd	000012B1h ; case G_M000_IG186
       	dd	0000119Dh ; case G_M000_IG171
       	dd	0000113Bh ; case G_M000_IG167
       	dd	000010AAh ; case G_M000_IG162
       	dd	00000E86h ; case G_M000_IG141

; Total bytes of code 5642

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ApplyDefinition(byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 27 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 136
       lea      rbp, [rsp+0xC0]
       xor      eax, eax
       mov      qword ptr [rbp-0x58], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      rsi, rdx
 
G_M000_IG02:                ;; offset=0x0034
       mov      rdi, gword ptr [rsi]
       mov      rcx, gword ptr [rbx+0x08]
       mov      r14, gword ptr [rcx+0x30]
       mov      rcx, rsi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG17
       mov      edx, eax
       mov      r14, gword ptr [r14+8*rdx+0x10]
       test     r14, r14
       je       G_M000_IG07
 
G_M000_IG03:                ;; offset=0x0062
       mov      rdx, 0x7FFA02BC5160
       cmp      qword ptr [r14], rdx
       jne      G_M000_IG07
 
G_M000_IG04:                ;; offset=0x0075
       mov      rdx, gword ptr [rbx+0x10]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:NeedsDefinitionContext(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG15
       mov      r15, gword ptr [r14+0x08]
       mov      r13, gword ptr [rbx+0x08]
       mov      r12, gword ptr [rbx+0x58]
       mov      rax, gword ptr [rbx+0x10]
       mov      gword ptr [rbp-0x60], rax
       xor      rcx, rcx
       mov      gword ptr [rbp-0x40], rcx
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:CanDefineLexically(Lokad.Lython.Frontend.ExecutableCodeObject):bool]
       test     eax, eax
       je       G_M000_IG15
       mov      rcx, gword ptr [r15+0x80]
       mov      r11, 0x7FFA02612080
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      gword ptr [rsp+0x20], rdi
       lea      rcx, [rbp-0x40]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, r12
       mov      r9, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryGetStandaloneCaptures(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG15
 
G_M000_IG05:                ;; offset=0x00F6
       mov      r8d, dword ptr [rsi+0x0C]
       cmp      r8d, 0x7FFFFFFF
       je       SHORT G_M000_IG06
       mov      rdx, gword ptr [r14+0x08]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCompleteImmediatelyCalledDefinition(Lokad.Lython.Frontend.ExecutableCodeObject,int):bool:this]
       test     eax, eax
       jne      G_M000_IG13
 
G_M000_IG06:                ;; offset=0x0118
       mov      rdi, gword ptr [r14+0x08]
       mov      r15, gword ptr [r14+0x10]
       movzx    r13, byte  ptr [r14+0x40]
       mov      rcx, r14
       call     [Lokad.Lython.Frontend.ExecutableCreateFunction:get_InputCount():int:this]
       mov      rcx, gword ptr [rbp-0x40]
       mov      dword ptr [rsp+0x20], r13d
       mov      dword ptr [rsp+0x28], eax
       mov      gword ptr [rsp+0x30], rcx
       mov      rcx, gword ptr [r14+0x28]
       mov      gword ptr [rsp+0x38], rcx
       mov      rcx, gword ptr [r14+0x30]
       mov      gword ptr [rsp+0x40], rcx
       movzx    rcx, byte  ptr [r14+0x41]
       mov      dword ptr [rsp+0x48], ecx
       mov      rcx, rbx
       mov      rdx, rsi
       mov      r8, rdi
       mov      r9, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CreateInlineDefinition(byref,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.FunctionParameterLayout,bool,int,int[],Lokad.Lython.Runtime.Text.PyString[],Lokad.Lython.Frontend.ExecutableInstruction[],bool):Lokad.Lython.Runtime.PyFunctionBase:this]
       mov      gword ptr [rbp-0x58], rax
       xor      r8d, r8d
       mov      qword ptr [rbp-0x50], r8
       lea      r8, [rbp-0x58]
       mov      rdx, rsi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG13
 
G_M000_IG07:                ;; offset=0x018D
       test     r14, r14
       je       G_M000_IG15
 
G_M000_IG08:                ;; offset=0x0196
       mov      rcx, 0x7FFA02BE6700
       cmp      qword ptr [r14], rcx
       jne      G_M000_IG15
 
G_M000_IG09:                ;; offset=0x01A9
       movzx    rcx, byte  ptr [r14+0x19]
       test     ecx, ecx
       jne      G_M000_IG15
       mov      r15, gword ptr [r14+0x08]
       mov      r13, gword ptr [rbx+0x08]
       mov      r12, gword ptr [rbx+0x58]
       mov      rax, gword ptr [rbx+0x10]
       mov      gword ptr [rbp-0x68], rax
       xor      rcx, rcx
       mov      gword ptr [rbp-0x48], rcx
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:CanDefineLexically(Lokad.Lython.Frontend.ExecutableCodeObject):bool]
       test     eax, eax
       je       G_M000_IG15
       mov      rcx, gword ptr [r15+0x80]
       mov      r11, 0x7FFA02612088
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       je       SHORT G_M000_IG10
       mov      gword ptr [rsp+0x20], rdi
       lea      rcx, [rbp-0x48]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, r12
       mov      r9, gword ptr [rbp-0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryGetStandaloneCaptures(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG15
 
G_M000_IG10:                ;; offset=0x0222
       mov      rdi, gword ptr [r14+0x08]
       mov      r15, gword ptr [r14+0x10]
       movzx    r13, byte  ptr [r14+0x18]
       mov      rcx, r14
       call     [Lokad.Lython.Frontend.ExecutableCreateLambda:get_InputCount():int:this]
       mov      rdx, gword ptr [rbp-0x48]
       mov      gword ptr [rsp+0x30], rdx
       xor      rdx, rdx
       mov      gword ptr [rsp+0x38], rdx
 
G_M000_IG11:                ;; offset=0x0248
       mov      gword ptr [rsp+0x40], rdx
 
G_M000_IG12:                ;; offset=0x024D
       mov      dword ptr [rsp+0x48], edx
       mov      dword ptr [rsp+0x28], eax
       mov      rdx, rsi
       mov      r8, rdi
       mov      r9, r15
       mov      dword ptr [rsp+0x20], r13d
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CreateInlineDefinition(byref,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.FunctionParameterLayout,bool,int,int[],Lokad.Lython.Runtime.Text.PyString[],Lokad.Lython.Frontend.ExecutableInstruction[],bool):Lokad.Lython.Runtime.PyFunctionBase:this]
       mov      gword ptr [rbp-0x58], rax
       xor      r8d, r8d
       mov      qword ptr [rbp-0x50], r8
       lea      r8, [rbp-0x58]
       mov      rdx, rsi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG13:                ;; offset=0x0287
       mov      eax, 1
 
G_M000_IG14:                ;; offset=0x028C
       add      rsp, 136
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG15:                ;; offset=0x02A0
       xor      eax, eax
 
G_M000_IG16:                ;; offset=0x02A2
       add      rsp, 136
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG17:                ;; offset=0x02B6
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 700

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CreateInlineDefinition(byref,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.FunctionParameterLayout,bool,int,int[],Lokad.Lython.Runtime.Text.PyString[],Lokad.Lython.Frontend.ExecutableInstruction[],bool):Lokad.Lython.Runtime.PyFunctionBase:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 19 single block inlinees; 6 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 280
       lea      rbp, [rsp+0x150]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xC0], ymm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       mov      bword ptr [rbp+0x10], rcx
       mov      rbx, rdx
       mov      rsi, r8
       mov      rdi, r9
       mov      r13d, dword ptr [rbp+0x38]
       mov      r14, gword ptr [rbp+0x40]
       mov      r15, gword ptr [rbp+0x50]
 
G_M000_IG02:                ;; offset=0x0052
       mov      edx, dword ptr [rbx+0x10]
       mov      dword ptr [rbp-0x3C], edx
       xor      r8, r8
       mov      gword ptr [rbp-0xE0], r8
 
G_M000_IG03:                ;; offset=0x0062
       mov      dword ptr [rbp-0x80], r8d
 
G_M000_IG04:                ;; offset=0x0066
       xor      r12d, r12d
 
G_M000_IG05:                ;; offset=0x0069
       test     r15, r15
       je       SHORT G_M000_IG06
       mov      r8, gword ptr [rcx+0x10]
       mov      gword ptr [rsp+0x20], r8
       mov      r8, gword ptr [rbx]
       mov      gword ptr [rsp+0x28], r8
       mov      r8, gword ptr [rcx+0x08]
       lea      rcx, [rbp-0x50]
       mov      rdx, r15
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadEagerFunctionAnnotations(Lokad.Lython.Frontend.ExecutableInstruction[],Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.ValueTuple`3[System.Object,int,bool]]
       mov      rdx, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0xE0], rdx
       mov      edx, dword ptr [rbp-0x48]
       mov      dword ptr [rbp-0x80], edx
       movzx    r12, byte  ptr [rbp-0x44]
       mov      rcx, bword ptr [rbp+0x10]
 
G_M000_IG06:                ;; offset=0x00AD
       xor      rax, rax
       xor      r10d, r10d
       test     r15, r15
       jne      SHORT G_M000_IG09
       test     r14, r14
       je       SHORT G_M000_IG09
       mov      r8d, dword ptr [r14+0x08]
       cmp      r8d, 1
       jne      SHORT G_M000_IG09
       mov      r8d, dword ptr [r14+0x10]
       test     r8d, r8d
       jl       SHORT G_M000_IG09
       mov      r9d, r8d
       lea      r11, bword ptr [rcx+0x48]
       mov      r15d, dword ptr [r11+0x08]
       cmp      r9d, r15d
       jae      G_M000_IG20
       mov      r11, bword ptr [r11]
       shl      r9, 4
       mov      r9, gword ptr [r11+r9]
       test     r9, r9
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x00F3
       mov      rdx, 0x7FFA02CC6C78
       cmp      qword ptr [r9], rdx
       je       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x0102
       mov      eax, r8d
       inc      rax
       mov      r10d, r15d
       cmp      rax, r10
       ja       G_M000_IG19
       mov      eax, r8d
       shl      rax, 4
       add      rax, r11
       mov      bword ptr [rbp-0xD0], rax
       mov      r10d, 1
       mov      rax, bword ptr [rbp-0xD0]
 
G_M000_IG09:                ;; offset=0x0132
       test     r14, r14
       jne      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0137
       mov      dword ptr [rbp-0x7C], r10d
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x013D
       mov      dword ptr [rbp-0x7C], r10d
       test     r10d, r10d
       je       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x0146
       xor      r15, r15
       mov      bword ptr [rbp-0xD0], rax
       jmp      SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0152
       mov      bword ptr [rbp-0xD0], rax
       mov      r8, gword ptr [rcx+0x10]
       mov      r9, gword ptr [rbx]
 
G_M000_IG14:                ;; offset=0x0160
       vmovdqu  xmm0, xmmword ptr [rcx+0x48]
       vmovdqu  xmmword ptr [rbp-0x90], xmm0
 
G_M000_IG15:                ;; offset=0x016D
       mov      r11, gword ptr [rcx+0x58]
       mov      gword ptr [rsp+0x20], r11
       mov      gword ptr [rsp+0x28], r14
       lea      r11, [rbp-0x58]
       mov      qword ptr [rsp+0x30], r11
       xor      r11, r11
       mov      gword ptr [rsp+0x38], r11
       mov      dword ptr [rsp+0x40], 1
       mov      rdx, r8
       mov      r8, r9
       lea      r9, [rbp-0x90]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:CaptureExecutableCells(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int[],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures]
       mov      r15, rax
 
G_M000_IG16:                ;; offset=0x01AD
       mov      rcx, bword ptr [rbp+0x10]
       mov      r14, gword ptr [rcx+0x10]
       mov      rbx, gword ptr [rbx]
       lea      rax, bword ptr [rcx+0x48]
       mov      edx, dword ptr [rbp-0x3C]
       mov      r8d, edx
       mov      r10d, r13d
       add      r8, r10
       mov      r10d, dword ptr [rax+0x08]
       cmp      r8, r10
       ja       G_M000_IG19
       mov      r8d, edx
       shl      r8, 4
       add      r8, bword ptr [rax]
       mov      bword ptr [rbp-0xD8], r8
       mov      rcx, rdi
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_DefaultStorageCount():int:this]
       mov      dword ptr [rbp-0x5C], eax
       cmp      eax, r13d
       ja       G_M000_IG19
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      gword ptr [rbp-0xC8], rax
       mov      r10, bword ptr [rbp-0xD8]
       mov      bword ptr [rbp-0xA0], r10
       mov      r11d, dword ptr [rbp-0x5C]
       mov      dword ptr [rbp-0x98], r11d
       lea      r8, [rbp-0xA0]
       movzx    rdx, byte  ptr [rbp+0x58]
       mov      dword ptr [rbp-0xB4], edx
       mov      r9d, edx
       lea      rcx, [rbp-0x78]
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool):Lokad.Lython.Runtime.FunctionDefaults]
       mov      eax, dword ptr [rbp-0x5C]
       mov      r9d, eax
       shl      r9, 4
       add      r9, bword ptr [rbp-0xD8]
       sub      r13d, eax
       lea      rcx, [rbp-0x78]
       mov      qword ptr [rsp+0x20], rcx
       movzx    rcx, byte  ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], r14
       mov      gword ptr [rsp+0x38], rbx
       mov      bword ptr [rbp-0xA0], r9
       mov      dword ptr [rbp-0x98], r13d
       mov      rbx, gword ptr [rbp+0x48]
       mov      gword ptr [rsp+0x48], rbx
       mov      r9, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0xB0], r9
       mov      r9d, dword ptr [rbp-0x80]
       mov      dword ptr [rbp-0xA8], r9d
 
G_M000_IG17:                ;; offset=0x02A6
       mov      byte  ptr [rbp-0xA4], r12b
       mov      ebx, dword ptr [rbp-0xB4]
       mov      dword ptr [rsp+0x58], ebx
       mov      rbx, bword ptr [rbp-0xD0]
       mov      bword ptr [rbp-0x90], rbx
       mov      ebx, dword ptr [rbp-0x7C]
       mov      dword ptr [rbp-0x88], ebx
       lea      r9, [rbp-0xA0]
       mov      qword ptr [rsp+0x40], r9
       lea      r9, [rbp-0xB0]
       mov      qword ptr [rsp+0x50], r9
       lea      r9, [rbp-0x90]
       mov      qword ptr [rsp+0x60], r9
       mov      r9, r15
       mov      rcx, rdi
       mov      rdx, rsi
       mov      r8, gword ptr [rbp-0xC8]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rbx, rax
       mov      edx, dword ptr [rbp-0x5C]
       add      rdx, rdx
       mov      rcx, bword ptr [rbp-0xD8]
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
       xor      rax, rax
       mov      gword ptr [rbp-0xE0], rax
 
G_M000_IG18:                ;; offset=0x0327
       mov      dword ptr [rbp-0x80], eax
       mov      gword ptr [rbp-0xC0], rbx
       jmp      SHORT G_M000_IG21
 
G_M000_IG19:                ;; offset=0x0333
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG20:                ;; offset=0x033A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG21:                ;; offset=0x0340
       call     G_M000_IG27
       nop      
 
G_M000_IG22:                ;; offset=0x0346
       mov      rax, gword ptr [rbp-0xC0]
 
G_M000_IG23:                ;; offset=0x034D
       add      rsp, 280
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG24:                ;; offset=0x0361
       sub      rsp, 104
 
G_M000_IG25:                ;; offset=0x0365
       mov      rcx, bword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp-0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       nop      
 
G_M000_IG26:                ;; offset=0x0373
       add      rsp, 104
       ret      
 
G_M000_IG27:                ;; offset=0x0378
       sub      rsp, 104
 
G_M000_IG28:                ;; offset=0x037C
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x10]
       cmp      gword ptr [rbp-0xE0], 0
       je       SHORT G_M000_IG30
       mov      rax, gword ptr [rax+0xA0]
       mov      rbx, gword ptr [rax+0x88]
       mov      ecx, dword ptr [rbp-0x80]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:RecordBytes(int):long]
       mov      rdx, rax
       add      rdx, 160
       jo       SHORT G_M000_IG29
       mov      rcx, rbx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReleaseReserved(long):this]
       jmp      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x03BE
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG30:                ;; offset=0x03C4
       call     G_M000_IG24
       nop      
 
G_M000_IG31:                ;; offset=0x03CA
       add      rsp, 104
       ret      
 
; Total bytes of code 975

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCompleteImmediatelyCalledDefinition(Lokad.Lython.Frontend.ExecutableCodeObject,int):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 55 single block inlinees; 9 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 240
       lea      rbp, [rsp+0x120]
       xor      eax, eax
       mov      qword ptr [rbp-0xA8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       vmovdqa  xmmword ptr [rbp-0x40], xmm4
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
 
G_M000_IG02:                ;; offset=0x0045
       mov      rdx, gword ptr [rcx+0x10]
       mov      rdx, gword ptr [rdx+0xA0]
       cmp      qword ptr [rdx+0x158], 8
       jge      SHORT G_M000_IG06
 
G_M000_IG03:                ;; offset=0x005A
       lea      rdx, bword ptr [rcx+0x48]
       cmp      r8d, dword ptr [rdx+0x08]
       jae      G_M000_IG42
       mov      r8d, r8d
       shl      r8, 4
       add      r8, bword ptr [rdx]
       mov      rbx, gword ptr [r8]
       mov      rsi, qword ptr [r8+0x08]
       test     rbx, rbx
       je       SHORT G_M000_IG08
 
G_M000_IG04:                ;; offset=0x007E
       mov      rdx, 0x7FFA02CC6C78
       cmp      qword ptr [rbx], rdx
       jne      SHORT G_M000_IG08
 
G_M000_IG05:                ;; offset=0x008D
       lea      rdx, [rbp-0x38]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:TryReadInteger(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG13
 
G_M000_IG06:                ;; offset=0x009E
       xor      eax, eax
 
G_M000_IG07:                ;; offset=0x00A0
       add      rsp, 240
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x00B2
       mov      rdx, 0x18B79801CF0
       cmp      rbx, gword ptr [rdx]
       je       SHORT G_M000_IG12
       test     rsi, rsi
       jle      SHORT G_M000_IG09
       mov      rdx, rbx
       mov      rcx, 0x7FFA02C28AB0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x00DD
       lea      rdx, [rbp-0x38]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00EC
       mov      r10, rax
       lea      edx, [rsi-0x01]
       lea      r8, [rbp-0x38]
       mov      rcx, r10
       call     [Lokad.Lython.Runtime.PyTuple:TryReadInteger(int,byref):bool:this]
 
G_M000_IG11:                ;; offset=0x00FF
       test     eax, eax
       jne      SHORT G_M000_IG13
       jmp      SHORT G_M000_IG06
 
G_M000_IG12:                ;; offset=0x0105
       mov      qword ptr [rbp-0x38], rsi
 
G_M000_IG13:                ;; offset=0x0109
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x08]
       mov      rbx, gword ptr [rdx+0x98]
       mov      rdx, gword ptr [rcx+0x10]
       mov      r8d, dword ptr [rcx+0x38]
       inc      r8d
       cmp      r8d, dword ptr [rbx+0x08]
       jae      G_M000_IG42
       shl      r8, 5
       mov      rsi, gword ptr [rbx+r8+0x10]
       mov      rdi, gword ptr [rdx+0xA0]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG14
       mov      rcx, rdi
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG14:                ;; offset=0x0159
       mov      rcx, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rcx+0x38]
       add      eax, 2
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG42
       shl      rax, 5
       lea      rsi, bword ptr [rbx+rax+0x10]
       mov      rax, gword ptr [rcx+0x10]
       mov      rdi, gword ptr [rsi]
       mov      r14, gword ptr [rax+0xA0]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG15
       mov      rcx, r14
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG15:                ;; offset=0x019F
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdi, bword ptr [rcx+0x48]
       mov      rcx, rsi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG42
       mov      r8, bword ptr [rdi]
       mov      edx, eax
       shl      rdx, 4
 
G_M000_IG16:                ;; offset=0x01C2
       vmovdqu  xmm0, xmmword ptr [r8+rdx]
       vmovdqu  xmmword ptr [rbp-0x60], xmm0
 
G_M000_IG17:                ;; offset=0x01CD
       lea      r8, [rbp-0x60]
       mov      rdx, rsi
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x10]
       mov      edx, dword ptr [rcx+0x38]
       add      edx, 3
       cmp      edx, dword ptr [rbx+0x08]
       jae      G_M000_IG42
       shl      rdx, 5
       mov      rsi, gword ptr [rbx+rdx+0x10]
       mov      rdi, gword ptr [rax+0xA0]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG18
       mov      rcx, rdi
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG18:                ;; offset=0x0221
       mov      rcx, bword ptr [rbp+0x10]
       add      dword ptr [rcx+0x38], 4
       mov      edx, dword ptr [rcx+0x38]
       cmp      edx, dword ptr [rbx+0x08]
       jae      G_M000_IG42
       shl      rdx, 5
       lea      rbx, bword ptr [rbx+rdx+0x10]
       mov      rdx, gword ptr [rcx+0x08]
       mov      r11, gword ptr [rdx+0xB0]
       cmp      dword ptr [rbx+0x1C], 42
       jne      G_M000_IG41
       mov      edx, dword ptr [rbx+0x08]
       mov      rcx, r11
       mov      r11, 0x7FFA02612100
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xB0], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x10]
       mov      rsi, gword ptr [rbx]
       mov      rdi, gword ptr [rdx+0xA0]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG19
       mov      rcx, rdi
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG19:                ;; offset=0x029B
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x10]
       mov      rax, gword ptr [rbp-0xB0]
       mov      r8, gword ptr [rax+0x18]
       mov      rcx, gword ptr [rdx+0xA0]
       mov      rdx, r8
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG20:                ;; offset=0x02C1
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x10]
       mov      rdx, gword ptr [rdx+0xA0]
       mov      rax, gword ptr [rdx+0x148]
       mov      gword ptr [rbp-0xB8], rax
 
G_M000_IG21:                ;; offset=0x02DE
       mov      r8, gword ptr [rbp-0xB0]
       mov      r10, gword ptr [r8+0x18]
       mov      rcx, rdx
       mov      rdx, r10
       call     [Lokad.Lython.Runtime.ExecutionState:EnterFunctionCall(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG22:                ;; offset=0x02F6
       xor      r9d, r9d
       mov      dword ptr [rbp-0x40], r9d
       lea      r9, [rbp-0x40]
       mov      qword ptr [rsp+0x20], r9
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx+0x10]
       lea      rcx, [rbp-0x50]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, qword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateClosedIntegerSequence[Lokad.Lython.Runtime.LythonRuntime+CaptureIntegerSource](Lokad.Lython.Frontend.ExecutableCodeObject,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rdx+0x98]
       mov      r10d, dword ptr [rbp-0x40]
       mov      r9d, dword ptr [rbp-0x40]
       inc      r9d
       mov      dword ptr [rbp-0x40], r9d
       cmp      r10d, dword ptr [r8+0x08]
       jae      G_M000_IG36
       shl      r10, 5
       mov      rsi, gword ptr [r8+r10+0x10]
       mov      rdi, gword ptr [rax+0xA0]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG23
       mov      rcx, rdi
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG23:                ;; offset=0x0378
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rdx+0x98]
       mov      eax, dword ptr [rcx+0x08]
       cmp      dword ptr [rbp-0x40], eax
       jae      G_M000_IG36
       mov      eax, dword ptr [rbp-0x40]
       shl      rax, 5
       lea      rsi, bword ptr [rcx+rax+0x10]
       mov      rdi, gword ptr [rdx+0x30]
       mov      rcx, rsi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG36
       mov      ecx, eax
       mov      rdx, gword ptr [rdi+8*rcx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x03C0
       mov      rax, 0x7FFA02BE6700
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG35
 
G_M000_IG25:                ;; offset=0x03D3
       mov      rdi, gword ptr [rcx+0x08]
       mov      r14, gword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x10]
       mov      r15, gword ptr [rsi]
       mov      r13, gword ptr [rax+0xA0]
       cmp      byte  ptr [r13], r13b
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rcx, r13
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG26:                ;; offset=0x040A
       mov      rcx, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      r8, rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x10]
       mov      r9, gword ptr [rsi]
       xor      rax, rax
       mov      gword ptr [rbp-0x78], rax
 
G_M000_IG27:                ;; offset=0x042C
       mov      gword ptr [rbp-0x70], rax
       mov      byte  ptr [rbp-0x68], 0
 
G_M000_IG28:                ;; offset=0x0434
       mov      dword ptr [rsp+0x28], eax
       mov      gword ptr [rsp+0x30], rdx
       mov      gword ptr [rsp+0x38], r9
 
G_M000_IG29:                ;; offset=0x0442
       mov      bword ptr [rbp-0x88], rax
 
G_M000_IG30:                ;; offset=0x0449
       mov      dword ptr [rbp-0x80], eax
 
G_M000_IG31:                ;; offset=0x044C
       mov      gword ptr [rsp+0x48], rax
 
G_M000_IG32:                ;; offset=0x0451
       mov      gword ptr [rbp-0x98], rax
 
G_M000_IG33:                ;; offset=0x0458
       mov      dword ptr [rbp-0x90], eax
       mov      byte  ptr [rbp-0x8C], 0
 
G_M000_IG34:                ;; offset=0x0465
       mov      dword ptr [rsp+0x58], eax
       lea      rdx, bword ptr [rbp-0x50]
       mov      bword ptr [rbp-0xA8], rdx
       mov      dword ptr [rbp-0xA0], 1
       lea      rdx, [rbp-0xA8]
       mov      qword ptr [rsp+0x60], rdx
       lea      rdx, [rbp-0x78]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x98]
       mov      qword ptr [rsp+0x50], rdx
       lea      rdx, [rbp-0x88]
       mov      qword ptr [rsp+0x40], rdx
       mov      rdx, rdi
       mov      rcx, r14
       xor      r9, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rsi, rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rdx+0x98]
       mov      r10d, dword ptr [r8+0x08]
       dec      r10d
       cmp      r10d, dword ptr [r8+0x08]
       jae      SHORT G_M000_IG36
       shl      r10, 5
       mov      rdi, gword ptr [r8+r10+0x10]
       mov      r14, gword ptr [rax+0xA0]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG37
       mov      rcx, r14
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      SHORT G_M000_IG37
 
G_M000_IG35:                ;; offset=0x050B
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG36:                ;; offset=0x0514
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG37:                ;; offset=0x051A
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x10]
       mov      rdi, gword ptr [rdx+0xA0]
       lea      rcx, bword ptr [rdi+0x148]
       mov      rdx, gword ptr [rbp-0xB8]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x10]
       mov      r14, gword ptr [rcx+0x10]
       mov      rcx, gword ptr [r14+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveFunctionCall():this]
       nop      
 
G_M000_IG38:                ;; offset=0x0554
       mov      gword ptr [rbp-0x60], rsi
       xor      r8d, r8d
       mov      qword ptr [rbp-0x58], r8
       lea      r8, [rbp-0x60]
       mov      rdx, rbx
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       nop      
 
G_M000_IG39:                ;; offset=0x0571
       mov      rcx, bword ptr [rbp+0x10]
       mov      rbx, gword ptr [rcx+0x10]
       mov      rcx, gword ptr [rbx+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       mov      eax, 1
 
G_M000_IG40:                ;; offset=0x058D
       add      rsp, 240
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG41:                ;; offset=0x059F
       mov      rcx, rbx
       mov      rdx, 0x18B4A14BFF0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG42:                ;; offset=0x05BB
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG43:                ;; offset=0x05C1
       sub      rsp, 104
 
G_M000_IG44:                ;; offset=0x05C5
       mov      rdi, rcx
       cmp      gword ptr [rbp-0xB8], 0
       je       SHORT G_M000_IG45
       mov      rcx, rdi
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_OriginalPythonException():Lokad.Lython.Runtime.PyException:this]
       cmp      rax, gword ptr [rbp-0xB8]
       je       SHORT G_M000_IG45
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_PythonContext():Lokad.Lython.Runtime.PyException:this]
       test     rax, rax
       jne      SHORT G_M000_IG45
       mov      rcx, rdi
       mov      rdx, gword ptr [rbp-0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntimeException:set_PythonContext(Lokad.Lython.Runtime.PyException):this]
 
G_M000_IG45:                ;; offset=0x0604
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG46:                ;; offset=0x060A
       sub      rsp, 104
 
G_M000_IG47:                ;; offset=0x060E
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x10]
       mov      rdi, gword ptr [rdx+0xA0]
       lea      rcx, bword ptr [rdi+0x148]
       mov      rdx, gword ptr [rbp-0xB8]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x10]
       mov      r14, gword ptr [rcx+0x10]
       mov      rcx, gword ptr [r14+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveFunctionCall():this]
       nop      
 
G_M000_IG48:                ;; offset=0x0648
       add      rsp, 104
       ret      
 
G_M000_IG49:                ;; offset=0x064D
       sub      rsp, 104
 
G_M000_IG50:                ;; offset=0x0651
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rcx+0x10]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Name():System.String:this]
       mov      rdi, rax
       mov      rcx, gword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      r9, rax
       mov      r8, rdi
       mov      rdx, rsi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.PyFunctionBinding:AnnotateException(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,Lokad.Lython.LythonSourceSpan)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG51:                ;; offset=0x0690
       sub      rsp, 104
 
G_M000_IG52:                ;; offset=0x0694
       mov      rcx, bword ptr [rbp+0x10]
       mov      rbx, gword ptr [rcx+0x10]
       mov      rcx, gword ptr [rbx+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG53:                ;; offset=0x06AC
       add      rsp, 104
       ret      
 
; Total bytes of code 1713

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:EvaluateClosedIntegerSequence[Lokad.Lython.Runtime.LythonRuntime+CaptureIntegerSource](Lokad.Lython.Frontend.ExecutableCodeObject,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 23 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 168
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x30], ymm4
       vmovdqu  ymmword ptr [rsp+0x50], ymm4
       vmovdqu  ymmword ptr [rsp+0x70], ymm4
       vmovdqa  xmmword ptr [rsp+0x90], xmm4
       xor      eax, eax
       mov      qword ptr [rsp+0xA0], rax
       mov      rdi, rcx
       mov      rsi, r9
       mov      rbx, bword ptr [rsp+0x110]
 
G_M000_IG02:                ;; offset=0x004A
       mov      gword ptr [rsp+0x98], rdx
       mov      qword ptr [rsp+0xA0], r8
       jmp      G_M000_IG24
 
G_M000_IG03:                ;; offset=0x005F
       mov      r14d, dword ptr [rbp+0x08]
       and      r14d, 0x7FFFFFFF
 
G_M000_IG04:                ;; offset=0x006A
       mov      ecx, dword ptr [rbp+0x10]
       lea      rdx, [rsp+0x88]
       lea      r8, [rsp+0x80]
       lea      r9, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime:<EvaluateClosedIntegerSequence>g__TryReadInteger|827_0[Lokad.Lython.Runtime.LythonRuntime+CaptureIntegerSource](int,byref,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x008F
       mov      ecx, dword ptr [rbp+0x0C]
       lea      rdx, [rsp+0x88]
       lea      r8, [rsp+0x78]
       lea      r9, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime:<EvaluateClosedIntegerSequence>g__TryReadInteger|827_0[Lokad.Lython.Runtime.LythonRuntime+CaptureIntegerSource](int,byref,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG06
       lea      r9, [rsp+0x70]
       mov      ecx, r14d
       mov      rdx, qword ptr [rsp+0x80]
       mov      r8, qword ptr [rsp+0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineBinary(int,long,long,byref):bool]
       test     eax, eax
       jne      G_M000_IG37
       lea      ecx, [r14-0x0F]
       cmp      ecx, 5
       jbe      G_M000_IG29
 
G_M000_IG06:                ;; offset=0x00E1
       mov      r15d, dword ptr [rbp+0x10]
 
G_M000_IG07:                ;; offset=0x00E5
       vmovdqu  xmm0, xmmword ptr [rsp+0x88]
       vmovdqu  xmmword ptr [rsp+0x60], xmm0
 
G_M000_IG08:                ;; offset=0x00F4
       mov      rcx, gword ptr [rsp+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CaptureOperandBase():int:this]
       mov      ecx, eax
       not      ecx
       cmp      ecx, r15d
       jne      SHORT G_M000_IG09
       mov      rcx, 0x7FFA02AAFD50
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rdx, qword ptr [rsp+0xA0]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
       lea      rcx, [rsp+0x50]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r13+0x08]
       mov      rdx, gword ptr [rsp+0x50]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rsp+0x58]
       mov      dword ptr [r13+0x10], ecx
       jmp      G_M000_IG14
 
G_M000_IG09:                ;; offset=0x0157
       test     r15d, r15d
       jge      SHORT G_M000_IG10
       mov      rcx, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [rcx+0x30]
       mov      eax, r15d
       not      eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG40
       mov      eax, r15d
       not      eax
       mov      r13, gword ptr [rcx+8*rax+0x10]
       jmp      G_M000_IG14
 
G_M000_IG10:                ;; offset=0x0185
       mov      rcx, gword ptr [rsp+0x60]
       mov      rax, 0x18B79801CF0
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG13
       mov      rcx, gword ptr [rsp+0x60]
       mov      rax, 0x18B79801CF8
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG12
       cmp      qword ptr [rsp+0x68], 0
       jne      SHORT G_M000_IG11
       mov      r13, gword ptr [rsp+0x60]
       jmp      SHORT G_M000_IG14
 
G_M000_IG11:                ;; offset=0x01BC
       lea      rcx, [rsp+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      r13, rax
       jmp      SHORT G_M000_IG14
 
G_M000_IG12:                ;; offset=0x01CC
       mov      rcx, 0x7FFA02706488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rsp+0x68]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      r13, rax
       mov      gword ptr [rsp+0x60], r13
       xor      ecx, ecx
       mov      qword ptr [rsp+0x68], rcx
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x01F7
       lea      rcx, [rsp+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r13, rax
 
G_M000_IG14:                ;; offset=0x0205
       mov      r15d, dword ptr [rbp+0x0C]
 
G_M000_IG15:                ;; offset=0x0209
       vmovdqu  xmm0, xmmword ptr [rsp+0x88]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG16:                ;; offset=0x0218
       mov      rcx, gword ptr [rsp+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CaptureOperandBase():int:this]
       mov      ecx, eax
       not      ecx
       cmp      ecx, r15d
       jne      SHORT G_M000_IG17
       mov      rcx, 0x7FFA02AAFD50
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       mov      rdx, qword ptr [rsp+0xA0]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
       lea      rcx, [rsp+0x30]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, gword ptr [rsp+0x30]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rsp+0x38]
       mov      dword ptr [r12+0x10], ecx
       mov      r8, r12
       jmp      G_M000_IG22
 
G_M000_IG17:                ;; offset=0x0280
       test     r15d, r15d
       jge      SHORT G_M000_IG18
       mov      r8, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [r8+0x30]
       mov      eax, r15d
       not      eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG40
       mov      eax, r15d
       not      eax
       mov      r8, gword ptr [rcx+8*rax+0x10]
       jmp      G_M000_IG22
 
G_M000_IG18:                ;; offset=0x02AE
       mov      rcx, gword ptr [rsp+0x40]
       mov      rax, 0x18B79801CF0
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG21
       mov      rcx, gword ptr [rsp+0x40]
       mov      rax, 0x18B79801CF8
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG20
       cmp      qword ptr [rsp+0x48], 0
       jne      SHORT G_M000_IG19
       mov      r8, gword ptr [rsp+0x40]
       jmp      SHORT G_M000_IG22
 
G_M000_IG19:                ;; offset=0x02E5
       lea      rcx, [rsp+0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      r8, rax
       jmp      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x02F5
       mov      rcx, 0x7FFA02706488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rsp+0x48]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      r8, rax
       mov      gword ptr [rsp+0x40], r8
       xor      ecx, ecx
       mov      qword ptr [rsp+0x48], rcx
       jmp      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x0320
       lea      rcx, [rsp+0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r8, rax
 
G_M000_IG22:                ;; offset=0x032E
       mov      rcx, gword ptr [rbp]
       mov      gword ptr [rsp+0x20], rcx
       mov      ecx, r14d
       mov      rdx, r13
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rsp+0x88], rax
 
G_M000_IG23:                ;; offset=0x034E
       xor      eax, eax
       mov      qword ptr [rsp+0x90], rax
 
G_M000_IG24:                ;; offset=0x0358
       mov      rcx, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [rbx]
       mov      edx, eax
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG40
       shl      rdx, 5
       lea      rbp, bword ptr [rcx+rdx+0x10]
       cmp      dword ptr [rbp+0x1C], 46
       jne      G_M000_IG38
 
G_M000_IG25:                ;; offset=0x0387
       inc      eax
       mov      dword ptr [rbx], eax
       mov      r14, gword ptr [rbp]
       mov      r15, gword ptr [rsi+0xA0]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x03A6
       mov      rcx, r15
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG27:                ;; offset=0x03B2
       cmp      dword ptr [rbp+0x1C], 51
       jne      G_M000_IG03
 
G_M000_IG28:                ;; offset=0x03BC
       mov      r14d, dword ptr [rbp+0x14]
       jmp      G_M000_IG04
 
G_M000_IG29:                ;; offset=0x03C5
       mov      rcx, qword ptr [rsp+0x78]
       cmp      qword ptr [rsp+0x80], rcx
       jge      SHORT G_M000_IG32
 
G_M000_IG30:                ;; offset=0x03D4
       mov      edx, -1
 
G_M000_IG31:                ;; offset=0x03D9
       mov      ecx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime:CompareOrderedResult(int,int):bool]
       test     eax, eax
       jne      SHORT G_M000_IG35
       mov      rax, 0x18B798013C8
       mov      rax, gword ptr [rax]
       jmp      SHORT G_M000_IG36
 
G_M000_IG32:                ;; offset=0x03F5
       cmp      qword ptr [rsp+0x80], rcx
       jle      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x03FF
       mov      edx, 1
       jmp      SHORT G_M000_IG31
 
G_M000_IG34:                ;; offset=0x0406
       xor      edx, edx
       jmp      SHORT G_M000_IG31
 
G_M000_IG35:                ;; offset=0x040A
       mov      rax, 0x18B798013C0
       mov      rax, gword ptr [rax]
 
G_M000_IG36:                ;; offset=0x0417
       mov      gword ptr [rsp+0x88], rax
       jmp      G_M000_IG23
 
G_M000_IG37:                ;; offset=0x0424
       mov      rax, qword ptr [rsp+0x70]
       mov      rcx, 0x18B79801CF0
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rsp+0x88], rcx
       mov      qword ptr [rsp+0x90], rax
       jmp      G_M000_IG24
 
G_M000_IG38:                ;; offset=0x044B
       mov      rax, gword ptr [rsp+0x88]
       mov      gword ptr [rdi], rax
       mov      rax, qword ptr [rsp+0x90]
       mov      qword ptr [rdi+0x08], rax
       mov      rax, rdi
 
G_M000_IG39:                ;; offset=0x0465
       add      rsp, 168
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG40:                ;; offset=0x0479
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1151

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 31 single block inlinees; 3 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 80
       lea      rbp, [rsp+0x80]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  xmmword ptr [rbp-0x48], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x38], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x28], r9
       mov      rbx, rdx
       mov      rsi, bword ptr [rbp+0x30]
 
G_M000_IG02:                ;; offset=0x0034
       mov      rdi, gword ptr [r8]
       mov      r14, qword ptr [r8+0x08]
       xor      eax, eax
       mov      qword ptr [rsi], rax
       mov      qword ptr [rsi+0x08], rax
 
G_M000_IG03:                ;; offset=0x0044
       xor      r15, r15
       test     rbx, rbx
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x004C
       xor      r13d, r13d
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0051
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableCreateFunction:get_InputCount():int:this]
       test     eax, eax
       sete     r13b
       movzx    r13, r13b
 
G_M000_IG06:                ;; offset=0x0064
       test     r13d, r13d
       jne      G_M000_IG22
 
G_M000_IG07:                ;; offset=0x006D
       mov      rdx, 0x18B79801CF0
       cmp      rdi, gword ptr [rdx]
       je       SHORT G_M000_IG13
       test     r14, r14
       jle      SHORT G_M000_IG08
       mov      rdx, rdi
       mov      rcx, 0x7FFA02C28AB0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x0098
       lea      rdx, [rbp-0x38]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x00A7
       lea      edx, [r14-0x01]
       lea      r8, [rbp-0x38]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.PyTuple:TryReadInteger(int,byref):bool:this]
 
G_M000_IG10:                ;; offset=0x00B8
       test     eax, eax
       jne      SHORT G_M000_IG14
 
G_M000_IG11:                ;; offset=0x00BC
       xor      eax, eax
 
G_M000_IG12:                ;; offset=0x00BE
       add      rsp, 80
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x00CD
       mov      qword ptr [rbp-0x38], r14
 
G_M000_IG14:                ;; offset=0x00D1
       mov      rcx, gword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx+0x40]
       mov      rcx, gword ptr [r11+0x80]
       mov      r11, 0x7FFA026121A0
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       je       SHORT G_M000_IG22
       mov      rcx, gword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x58]
       mov      rax, gword ptr [rdx]
       test     rax, rax
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0101
       mov      r8, 0x7FFA02CC6C78
       cmp      qword ptr [rax], r8
       je       SHORT G_M000_IG19
 
G_M000_IG16:                ;; offset=0x0110
       test     rax, rax
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0115
       mov      r8, 0x7FFA02CF4B30
       xor      r10, r10
       cmp      qword ptr [rax], r8
       cmovne   rax, r10
 
G_M000_IG18:                ;; offset=0x0129
       test     rax, rax
       je       SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x012E
       xor      r15, r15
       jmp      SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x0133
       mov      r15, gword ptr [rdx]
 
G_M000_IG21:                ;; offset=0x0136
       test     r15, r15
       je       SHORT G_M000_IG11
 
G_M000_IG22:                ;; offset=0x013B
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rcx, gword ptr [rdx+0xA0]
       mov      rdx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterFunctionCall(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      r8, gword ptr [rdx+0xA0]
       mov      r8, gword ptr [r8+0x148]
       mov      gword ptr [rbp-0x50], r8
 
G_M000_IG23:                ;; offset=0x0170
       test     rbx, rbx
       je       G_M000_IG27
       test     r13d, r13d
       je       SHORT G_M000_IG24
       mov      gword ptr [rbp-0x48], rdi
       mov      qword ptr [rbp-0x40], r14
       mov      r8, gword ptr [rcx+0x40]
       mov      r8, gword ptr [r8+0x98]
       cmp      dword ptr [r8+0x08], 0
       jbe      G_M000_IG28
       mov      r9, gword ptr [r8+0x10]
       lea      r8, [rbp-0x48]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedFunctionDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rdi, rax
       jmp      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x01B2
       mov      gword ptr [rsp+0x20], r15
       mov      r8, rdx
       mov      rdx, gword ptr [rcx+0x40]
       mov      rcx, rbx
       mov      r9, qword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedComputedDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Object):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rdi, rax
 
G_M000_IG25:                ;; offset=0x01CE
       mov      rcx, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x28]
       mov      rdx, gword ptr [rcx+0x40]
       mov      rdx, gword ptr [rdx+0x98]
       mov      r8d, dword ptr [rdx+0x08]
       lea      r10d, [r8-0x01]
       cmp      r10d, r8d
       jae      SHORT G_M000_IG28
       mov      r8d, r10d
       shl      r8, 5
       mov      rbx, gword ptr [rdx+r8+0x10]
       mov      r14, gword ptr [rax+0xA0]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rcx, r14
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG26:                ;; offset=0x021D
       mov      rcx, rsi
       mov      rdx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rsi+0x08], rcx
       jmp      SHORT G_M000_IG29
 
G_M000_IG27:                ;; offset=0x0230
       mov      rcx, gword ptr [rcx+0x40]
       mov      r8, qword ptr [rbp-0x38]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:CompleteClosedDefinitionPair(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       jmp      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0244
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG29:                ;; offset=0x024A
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rsi, gword ptr [rdx+0xA0]
       mov      rbx, rsi
       lea      rcx, bword ptr [rbx+0x148]
       mov      rdx, gword ptr [rbp-0x50]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveFunctionCall():this]
       nop      
 
G_M000_IG30:                ;; offset=0x0276
       mov      eax, 1
 
G_M000_IG31:                ;; offset=0x027B
       add      rsp, 80
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG32:                ;; offset=0x028A
       sub      rsp, 40
 
G_M000_IG33:                ;; offset=0x028E
       mov      rbx, rcx
       cmp      gword ptr [rbp-0x50], 0
       je       SHORT G_M000_IG34
       mov      rcx, rbx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_OriginalPythonException():Lokad.Lython.Runtime.PyException:this]
       cmp      rax, gword ptr [rbp-0x50]
       je       SHORT G_M000_IG34
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_PythonContext():Lokad.Lython.Runtime.PyException:this]
       test     rax, rax
       jne      SHORT G_M000_IG34
       mov      rcx, rbx
       mov      rdx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntimeException:set_PythonContext(Lokad.Lython.Runtime.PyException):this]
 
G_M000_IG34:                ;; offset=0x02C4
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG35:                ;; offset=0x02CA
       sub      rsp, 40
 
G_M000_IG36:                ;; offset=0x02CE
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rbx, gword ptr [rdx+0xA0]
       lea      rcx, bword ptr [rbx+0x148]
       mov      rdx, gword ptr [rbp-0x50]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x28]
       mov      rcx, gword ptr [rax+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveFunctionCall():this]
       nop      
 
G_M000_IG37:                ;; offset=0x0305
       add      rsp, 40
       ret      
 
G_M000_IG38:                ;; offset=0x030A
       sub      rsp, 40
 
G_M000_IG39:                ;; offset=0x030E
       mov      rbx, rcx
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rsi, rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Name():System.String:this]
       mov      r8, rax
       mov      rdx, rsi
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyFunctionBinding:AnnotateException(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,Lokad.Lython.LythonSourceSpan)]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 833

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:EvaluateClosedIntegerSequence[Lokad.Lython.Runtime.LythonRuntime+ParameterIntegerSource](Lokad.Lython.Frontend.ExecutableCodeObject,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 23 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 168
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x30], ymm4
       vmovdqu  ymmword ptr [rsp+0x50], ymm4
       vmovdqu  ymmword ptr [rsp+0x70], ymm4
       vmovdqa  xmmword ptr [rsp+0x90], xmm4
       xor      eax, eax
       mov      qword ptr [rsp+0xA0], rax
       mov      rdi, rcx
       mov      rsi, r9
       mov      rbx, bword ptr [rsp+0x110]
 
G_M000_IG02:                ;; offset=0x004A
       mov      gword ptr [rsp+0x98], rdx
       mov      qword ptr [rsp+0xA0], r8
       jmp      G_M000_IG24
 
G_M000_IG03:                ;; offset=0x005F
       mov      r14d, dword ptr [rbp+0x08]
       and      r14d, 0x7FFFFFFF
 
G_M000_IG04:                ;; offset=0x006A
       mov      ecx, dword ptr [rbp+0x10]
       lea      rdx, [rsp+0x88]
       lea      r8, [rsp+0x80]
       lea      r9, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime:<EvaluateClosedIntegerSequence>g__TryReadInteger|827_0[Lokad.Lython.Runtime.LythonRuntime+ParameterIntegerSource](int,byref,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x008F
       mov      ecx, dword ptr [rbp+0x0C]
       lea      rdx, [rsp+0x88]
       lea      r8, [rsp+0x78]
       lea      r9, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime:<EvaluateClosedIntegerSequence>g__TryReadInteger|827_0[Lokad.Lython.Runtime.LythonRuntime+ParameterIntegerSource](int,byref,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG06
       lea      r9, [rsp+0x70]
       mov      ecx, r14d
       mov      rdx, qword ptr [rsp+0x80]
       mov      r8, qword ptr [rsp+0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineBinary(int,long,long,byref):bool]
       test     eax, eax
       jne      G_M000_IG37
       lea      ecx, [r14-0x0F]
       cmp      ecx, 5
       jbe      G_M000_IG29
 
G_M000_IG06:                ;; offset=0x00E1
       mov      r15d, dword ptr [rbp+0x10]
 
G_M000_IG07:                ;; offset=0x00E5
       vmovdqu  xmm0, xmmword ptr [rsp+0x88]
       vmovdqu  xmmword ptr [rsp+0x60], xmm0
 
G_M000_IG08:                ;; offset=0x00F4
       test     r15d, r15d
       jne      SHORT G_M000_IG09
       mov      rcx, 0x7FFA02AAFD50
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rdx, qword ptr [rsp+0xA0]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
       lea      rcx, [rsp+0x50]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r13+0x08]
       mov      rdx, gword ptr [rsp+0x50]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rsp+0x58]
       mov      dword ptr [r13+0x10], ecx
       jmp      G_M000_IG14
 
G_M000_IG09:                ;; offset=0x0143
       test     r15d, r15d
       jge      SHORT G_M000_IG10
       mov      rcx, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [rcx+0x30]
       mov      eax, r15d
       not      eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG40
       mov      eax, r15d
       not      eax
       mov      r13, gword ptr [rcx+8*rax+0x10]
       jmp      G_M000_IG14
 
G_M000_IG10:                ;; offset=0x0171
       mov      rcx, gword ptr [rsp+0x60]
       mov      rax, 0x18B79801CF0
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG13
       mov      rcx, gword ptr [rsp+0x60]
       mov      rax, 0x18B79801CF8
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG12
       cmp      qword ptr [rsp+0x68], 0
       jne      SHORT G_M000_IG11
       mov      r13, gword ptr [rsp+0x60]
       jmp      SHORT G_M000_IG14
 
G_M000_IG11:                ;; offset=0x01A8
       lea      rcx, [rsp+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      r13, rax
       jmp      SHORT G_M000_IG14
 
G_M000_IG12:                ;; offset=0x01B8
       mov      rcx, 0x7FFA02706488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rsp+0x68]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      r13, rax
       mov      gword ptr [rsp+0x60], r13
       xor      ecx, ecx
       mov      qword ptr [rsp+0x68], rcx
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x01E3
       lea      rcx, [rsp+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r13, rax
 
G_M000_IG14:                ;; offset=0x01F1
       mov      r15d, dword ptr [rbp+0x0C]
 
G_M000_IG15:                ;; offset=0x01F5
       vmovdqu  xmm0, xmmword ptr [rsp+0x88]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG16:                ;; offset=0x0204
       test     r15d, r15d
       jne      SHORT G_M000_IG17
       mov      rcx, 0x7FFA02AAFD50
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       mov      rdx, qword ptr [rsp+0xA0]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
       lea      rcx, [rsp+0x30]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, gword ptr [rsp+0x30]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rsp+0x38]
       mov      dword ptr [r12+0x10], ecx
       mov      r8, r12
       jmp      G_M000_IG22
 
G_M000_IG17:                ;; offset=0x0258
       test     r15d, r15d
       jge      SHORT G_M000_IG18
       mov      r8, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [r8+0x30]
       mov      eax, r15d
       not      eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG40
       mov      eax, r15d
       not      eax
       mov      r8, gword ptr [rcx+8*rax+0x10]
       jmp      G_M000_IG22
 
G_M000_IG18:                ;; offset=0x0286
       mov      rcx, gword ptr [rsp+0x40]
       mov      rax, 0x18B79801CF0
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG21
       mov      rcx, gword ptr [rsp+0x40]
       mov      rax, 0x18B79801CF8
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG20
       cmp      qword ptr [rsp+0x48], 0
       jne      SHORT G_M000_IG19
       mov      r8, gword ptr [rsp+0x40]
       jmp      SHORT G_M000_IG22
 
G_M000_IG19:                ;; offset=0x02BD
       lea      rcx, [rsp+0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      r8, rax
       jmp      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x02CD
       mov      rcx, 0x7FFA02706488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rsp+0x48]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      r8, rax
       mov      gword ptr [rsp+0x40], r8
       xor      ecx, ecx
       mov      qword ptr [rsp+0x48], rcx
       jmp      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x02F8
       lea      rcx, [rsp+0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r8, rax
 
G_M000_IG22:                ;; offset=0x0306
       mov      rcx, gword ptr [rbp]
       mov      gword ptr [rsp+0x20], rcx
       mov      ecx, r14d
       mov      rdx, r13
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rsp+0x88], rax
 
G_M000_IG23:                ;; offset=0x0326
       xor      eax, eax
       mov      qword ptr [rsp+0x90], rax
 
G_M000_IG24:                ;; offset=0x0330
       mov      rcx, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [rbx]
       mov      edx, eax
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG40
       shl      rdx, 5
       lea      rbp, bword ptr [rcx+rdx+0x10]
       cmp      dword ptr [rbp+0x1C], 46
       jne      G_M000_IG38
 
G_M000_IG25:                ;; offset=0x035F
       inc      eax
       mov      dword ptr [rbx], eax
       mov      r14, gword ptr [rbp]
       mov      r15, gword ptr [rsi+0xA0]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x037E
       mov      rcx, r15
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG27:                ;; offset=0x038A
       cmp      dword ptr [rbp+0x1C], 51
       jne      G_M000_IG03
 
G_M000_IG28:                ;; offset=0x0394
       mov      r14d, dword ptr [rbp+0x14]
       jmp      G_M000_IG04
 
G_M000_IG29:                ;; offset=0x039D
       mov      rcx, qword ptr [rsp+0x78]
       cmp      qword ptr [rsp+0x80], rcx
       jge      SHORT G_M000_IG32
 
G_M000_IG30:                ;; offset=0x03AC
       mov      edx, -1
 
G_M000_IG31:                ;; offset=0x03B1
       mov      ecx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime:CompareOrderedResult(int,int):bool]
       test     eax, eax
       jne      SHORT G_M000_IG35
       mov      rax, 0x18B798013C8
       mov      rax, gword ptr [rax]
       jmp      SHORT G_M000_IG36
 
G_M000_IG32:                ;; offset=0x03CD
       cmp      qword ptr [rsp+0x80], rcx
       jle      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x03D7
       mov      edx, 1
       jmp      SHORT G_M000_IG31
 
G_M000_IG34:                ;; offset=0x03DE
       xor      edx, edx
       jmp      SHORT G_M000_IG31
 
G_M000_IG35:                ;; offset=0x03E2
       mov      rax, 0x18B798013C0
       mov      rax, gword ptr [rax]
 
G_M000_IG36:                ;; offset=0x03EF
       mov      gword ptr [rsp+0x88], rax
       jmp      G_M000_IG23
 
G_M000_IG37:                ;; offset=0x03FC
       mov      rax, qword ptr [rsp+0x70]
       mov      rcx, 0x18B79801CF0
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rsp+0x88], rcx
       mov      qword ptr [rsp+0x90], rax
       jmp      G_M000_IG24
 
G_M000_IG38:                ;; offset=0x0423
       mov      rax, gword ptr [rsp+0x88]
       mov      gword ptr [rdi], rax
       mov      rax, qword ptr [rsp+0x90]
       mov      qword ptr [rdi+0x08], rax
       mov      rax, rdi
 
G_M000_IG39:                ;; offset=0x043D
       add      rsp, 168
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG40:                ;; offset=0x0451
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1111

