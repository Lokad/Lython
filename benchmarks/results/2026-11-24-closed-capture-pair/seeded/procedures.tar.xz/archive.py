from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
parent=lab.with_name('closed-capture-pair-20261124')
comparison=lab/'comparison';quiet=comparison/'quiet'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda payload:hashlib.sha256(payload).hexdigest()
digest=lambda p:sha(p.read_bytes())
meta=read(comparison/'identity.json')
terminal=read(quiet/'terminal-status.json')
summary=read(quiet/'summary.json')
receipt=terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert digest(quiet/'observations.tar.xz')==receipt['archiveSHA256']
assert summary['timedBatches']==196 and len(summary['rows'])==7
assert summary['source']==meta['sourceRevision'] and summary['candidate']==meta['candidate']
assert [(r['case'],r['lane']) for r in summary['rows']]==[tuple(job) for job in read(comparison/'jobs.json')['warm']]
for role,files in meta['imageFiles'].items():
    verify=read(comparison/(role+'-verify.json'))
    assert verify['state']=='Completed' and verify['caseCount']==6
    assert verify['launched']['library']['sha256']==files['Lokad.Lython.dll']==meta['coreSHA256'][role]
    assert len(files)==32 and {p.name:digest(p) for p in (lab/role).iterdir()}==files
    oracle=[json.loads(line) for line in (lab/('captured-'+role+'-oracle.jsonl')).read_text(encoding='utf-8').splitlines()]
    assert len(oracle)==6 and all(row['Matches'] and row['Compared'] and row['Lython']['Success'] for row in oracle)
    assert all(x['sharedBudgetBaselineRestored'] for x in read(lab/'allocation'/(role+'-allocation-six.json'))['rows'])
for prefix in ('windows','ubuntu'):
    for key,count in (('white',47),('public',59)):
        assert f'Passed: {count:5d}' in (parent/(prefix+'-'+key+'-seeded.log')).read_text(encoding='utf-8-sig')
jit=read(lab/'jit-summary.json')
assert all(jit[role]['core']==meta['coreSHA256'][role] for role in meta['imageFiles'])
for mode,bytes_ in [('ParameterIntegerSource',1111),('CaptureIntegerSource',1151)]:
    for role in ('candidate','reference'):
        method,=(v for k,v in jit[role]['methods'].items() if 'EvaluateClosedIntegerSequence' in k and mode in k)
        assert method==dict(bytes=bytes_,frameBytes=168)
base=root/'benchmarks/results/2026-11-24-closed-capture-pair'
assert sha(gzip.decompress((base/'reference-core.dll.gz').read_bytes()))==meta['coreSHA256']['reference']
out=base/'seeded';out.mkdir(exist_ok=True)
core=(lab/'candidate/Lokad.Lython.dll').read_bytes()
archive=out/'candidate-core.dll.gz';archive.write_bytes(gzip.compress(core,mtime=0))
assert sha(gzip.decompress(archive.read_bytes()))==meta['coreSHA256']['candidate']
for source,name in {comparison/'identity.json':'identity.json',quiet/'terminal-status.json':'terminal-status.json',quiet/'summary.json':'summary.json',
                    quiet/'observations.tar.xz':'observations.tar.xz',lab/'allocation-summary-six.json':'allocation-summary.json',
                    lab/'jit-summary.json':'jit-summary.json',quiet/'storage-custody.json':'storage-custody.json'}.items():
    shutil.copyfile(source,out/name)
(lab/'measured.patch').write_bytes(subprocess.check_output(['git','diff','--binary',meta['sourceRevision'],meta['candidate'],'--','src','tests'],cwd=root))
(lab/'seed.patch').write_bytes(subprocess.check_output(['git','diff','--binary','97313e53b',meta['candidate'],'--','src'],cwd=root))
procedures={name:lab/name for name in ('prepare.py','stage.py','quiet.py','summarize.py','archive.py','measured.patch','seed.patch','prepare-allocation.py',
    'comparison/reference-verify.json','comparison/candidate-verify.json','comparison/quiet/launch.log','verified-raw-replicas.json',
    'allocation/reference-allocation-six.json','allocation/candidate-allocation-six.json','allocation/allocations.py','inspect-jit.py',
    'reference-runtime.asm','candidate-runtime.asm','captured-oracle.py','captured-oracle-input.json','captured-reference-oracle.jsonl','captured-candidate-oracle.jsonl')}
procedures.update({name:parent/name for name in ('test-ubuntu-seeded.sh','windows-white-seeded.log','windows-public-seeded.log',
    'ubuntu-white-seeded.log','ubuntu-public-seeded.log')})
with tarfile.open(out/'procedures.tar.xz','w:xz',preset=4) as tar:
    for name,source in procedures.items():tar.add(source,arcname=name)
with tarfile.open(out/'procedures.tar.xz') as tar:
    assert all(sha(tar.extractfile(name).read())==digest(source) for name,source in procedures.items())
print('Archived B1603 with 196 checked batches and restored shared evaluators')
