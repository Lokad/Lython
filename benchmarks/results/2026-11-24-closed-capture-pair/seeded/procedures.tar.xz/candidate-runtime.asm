; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 7 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 72
       lea      rbp, [rsp+0x70]
       mov      rsi, rcx
       mov      rdi, rdx
       mov      rbx, r8
 
G_M000_IG02:                ;; offset=0x001A
       mov      r14, gword ptr [rsi+0x08]
       test     r14, r14
       je       G_M000_IG13
       test     rbx, rbx
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x002C
       mov      rcx, 0x7FFA02A91FA0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
 
G_M000_IG04:                ;; offset=0x003E
       mov      r15, gword ptr [rbx+0x38]
       test     r15, r15
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0047
       mov      r15, gword ptr [rsi+0x20]
       test     r15, r15
       jne      SHORT G_M000_IG06
       mov      rcx, 0x7FFA02935BD8
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      byte  ptr [rbp-0x38], 0
       xor      edx, edx
       mov      qword ptr [rbp-0x30], rdx
       lea      rdx, [rbp-0x38]
       mov      rcx, r15
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
 
G_M000_IG06:                ;; offset=0x0079
       mov      rcx, r15
       mov      r11, 0x7FFA02621D30
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG07:                ;; offset=0x008D
       mov      rcx, gword ptr [rbx+0x40]
       test     rcx, rcx
       cmove    rcx, r15
       mov      r11, 0x7FFA02621D38
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      r9, rax
       mov      gword ptr [rbp-0x48], r9
 
G_M000_IG08:                ;; offset=0x00AC
       mov      rdx, gword ptr [rbx+0x60]
       mov      rcx, rbx
       mov      r8, gword ptr [rbp-0x40]
       call     [Lokad.Lython.LythonRunOptions:Copy(System.Threading.CancellationToken,Lokad.Lython.ILythonMemoryBudget,Lokad.Lython.ILythonMemoryBudget):Lokad.Lython.LythonRunOptions:this]
       mov      r8, rax
       mov      rdx, rdi
       mov      rcx, gword ptr [r14+0x10]
       call     [r14+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      rbx, rax
       lea      rcx, bword ptr [rbx+0x28]
       mov      rdx, gword ptr [rbp-0x48]
       call     CORINFO_HELP_ASSIGN_REF
       nop      
 
G_M000_IG09:                ;; offset=0x00DC
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00E3
       mov      rcx, gword ptr [rbp-0x40]
       mov      r11, 0x7FFA02621D48
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG11:                ;; offset=0x00F4
       mov      rax, rbx
 
G_M000_IG12:                ;; offset=0x00F7
       add      rsp, 72
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x0104
       mov      rcx, 0x7FFA02A6A5F0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x20B508D0398
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG14:                ;; offset=0x0132
       sub      rsp, 40
 
G_M000_IG15:                ;; offset=0x0136
       mov      rcx, gword ptr [rbp-0x48]
       mov      r11, 0x7FFA02621D40
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG16:                ;; offset=0x014D
       sub      rsp, 40
 
G_M000_IG17:                ;; offset=0x0151
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG18
       mov      rcx, gword ptr [rbp-0x40]
       mov      r11, 0x7FFA02621D48
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG18:                ;; offset=0x0169
       nop      
 
G_M000_IG19:                ;; offset=0x016A
       add      rsp, 40
       ret      
 
; Total bytes of code 367

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 3 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 152
       lea      rbp, [rsp+0xD0]
       xor      eax, eax
       mov      qword ptr [rbp-0x68], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r9
       mov      r14, bword ptr [rbp+0x50]
 
G_M000_IG02:                ;; offset=0x003B
       mov      r15, bword ptr [r8]
       mov      r13d, dword ptr [r8+0x08]
       cmp      dword ptr [r14+0x08], 2
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0049
       xor      r8d, r8d
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x004E
       mov      r8, gword ptr [rbx+0x40]
       cmp      byte  ptr [r8+0xF1], 0
       setne    r8b
       movzx    r8, r8b
 
G_M000_IG05:                ;; offset=0x0062
       movzx    r12, byte  ptr [rbp+0x48]
       test     r8d, r12d
       je       SHORT G_M000_IG11
 
G_M000_IG06:                ;; offset=0x006C
       test     rsi, rsi
       jne      SHORT G_M000_IG11
       cmp      r13d, 1
       jne      SHORT G_M000_IG11
 
G_M000_IG07:                ;; offset=0x0077
       vmovdqu  xmm0, xmmword ptr [r15]
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
 
G_M000_IG08:                ;; offset=0x0081
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x20], rax
 
G_M000_IG09:                ;; offset=0x008A
       vmovdqu  xmm0, xmmword ptr [r14]
       vmovdqu  xmmword ptr [rbp-0x58], xmm0
 
G_M000_IG10:                ;; offset=0x0094
       lea      r8, [rbp-0x58]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0x48]
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x38]
       xor      rdx, rdx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x00B4
       mov      bword ptr [rbp-0x68], r15
       mov      dword ptr [rbp-0x60], r13d
       mov      r15, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], r15
       mov      r15, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x28], r15
       movzx    r8, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x30], r8d
       mov      dword ptr [rsp+0x38], r12d
       mov      bword ptr [rsp+0x40], r14
       mov      r14, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x48], r14
       mov      r14, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x50], r14
       mov      r14, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x58], r14
       lea      r8, [rbp-0x68]
       mov      rdx, rdi
       mov      rcx, rbx
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeWorkspace(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       jmp      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x0112
       mov      rbx, bword ptr [rbp+0x58]
       mov      byte  ptr [rbx], 1
       xor      rax, rax
       mov      r14, bword ptr [rbp+0x68]
       mov      gword ptr [r14], rax
 
G_M000_IG13:                ;; offset=0x0122
       add      rsp, 152
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
; Total bytes of code 310

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 35 single block inlinees; 3 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 72
       lea      rbp, [rsp+0x80]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x28], r9
       mov      rbx, rdx
       mov      rsi, bword ptr [rbp+0x30]
       mov      rdi, bword ptr [rbp+0x38]
 
G_M000_IG02:                ;; offset=0x003A
       mov      r14, gword ptr [r8]
       mov      r15, qword ptr [r8+0x08]
       xor      eax, eax
       mov      qword ptr [rsi], rax
       mov      qword ptr [rsi+0x08], rax
 
G_M000_IG03:                ;; offset=0x004A
       xor      r13, r13
       test     rbx, rbx
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0052
       xor      r12d, r12d
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0057
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableCreateFunction:get_InputCount():int:this]
       test     eax, eax
       sete     r12b
       movzx    r12, r12b
 
G_M000_IG06:                ;; offset=0x006A
       test     r12d, r12d
       jne      G_M000_IG22
 
G_M000_IG07:                ;; offset=0x0073
       mov      rdx, 0x1EB29C01CF0
       cmp      r14, gword ptr [rdx]
       je       SHORT G_M000_IG13
       test     r15, r15
       jle      SHORT G_M000_IG08
       mov      rdx, r14
       mov      rcx, 0x7FFA02C38AC8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x009E
       lea      rdx, [rbp-0x40]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x00AD
       lea      edx, [r15-0x01]
       lea      r8, [rbp-0x40]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.PyTuple:TryReadInteger(int,byref):bool:this]
 
G_M000_IG10:                ;; offset=0x00BE
       test     eax, eax
       jne      SHORT G_M000_IG14
 
G_M000_IG11:                ;; offset=0x00C2
       xor      eax, eax
 
G_M000_IG12:                ;; offset=0x00C4
       add      rsp, 72
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x00D5
       mov      qword ptr [rbp-0x40], r15
 
G_M000_IG14:                ;; offset=0x00D9
       mov      rcx, gword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx+0x40]
       mov      rcx, gword ptr [r11+0x80]
       mov      r11, 0x7FFA02622068
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       je       SHORT G_M000_IG22
       mov      rcx, gword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x58]
       mov      rax, gword ptr [rdx]
       test     rax, rax
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0109
       mov      r8, 0x7FFA02CE7468
       cmp      qword ptr [rax], r8
       je       SHORT G_M000_IG19
 
G_M000_IG16:                ;; offset=0x0118
       test     rax, rax
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x011D
       mov      r8, 0x7FFA02D050D8
       xor      r10, r10
       cmp      qword ptr [rax], r8
       cmovne   rax, r10
 
G_M000_IG18:                ;; offset=0x0131
       test     rax, rax
       je       SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x0136
       xor      r13, r13
       jmp      SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x013B
       mov      r13, gword ptr [rdx]
 
G_M000_IG21:                ;; offset=0x013E
       test     r13, r13
       je       G_M000_IG11
 
G_M000_IG22:                ;; offset=0x0147
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rcx, gword ptr [rdx+0xA0]
       mov      rdx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterFunctionCall(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      r8, gword ptr [rdx+0xA0]
       mov      r8, gword ptr [r8+0x148]
       mov      gword ptr [rbp-0x58], r8
 
G_M000_IG23:                ;; offset=0x017C
       test     rbx, rbx
       je       G_M000_IG27
       test     r12d, r12d
       je       SHORT G_M000_IG24
       mov      gword ptr [rbp-0x50], r14
       mov      qword ptr [rbp-0x48], r15
       mov      rax, gword ptr [rcx+0x40]
       mov      r8, gword ptr [rax+0x98]
       cmp      dword ptr [r8+0x08], 0
       jbe      G_M000_IG29
       mov      r9, gword ptr [r8+0x10]
       lea      r8, [rbp-0x50]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedFunctionDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rdi, rax
       jmp      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x01BE
       mov      gword ptr [rsp+0x20], r13
       mov      r8, rdx
       mov      rax, gword ptr [rcx+0x40]
       mov      rdx, rax
       mov      rcx, rbx
       mov      r9, qword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedComputedDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Object):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rdi, rax
 
G_M000_IG25:                ;; offset=0x01DD
       mov      rcx, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x28]
       mov      rdx, gword ptr [rcx+0x40]
       mov      rdx, gword ptr [rdx+0x98]
       mov      r8d, dword ptr [rdx+0x08]
       lea      r10d, [r8-0x01]
       cmp      r10d, r8d
       jae      SHORT G_M000_IG29
       mov      r8d, r10d
       shl      r8, 5
       mov      rbx, gword ptr [rdx+r8+0x10]
       mov      r14, gword ptr [rax+0xA0]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rcx, r14
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG26:                ;; offset=0x022C
       mov      rcx, rsi
       mov      rdx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rsi+0x08], rcx
       jmp      SHORT G_M000_IG30
 
G_M000_IG27:                ;; offset=0x023F
       mov      rax, gword ptr [rcx+0x40]
       cmp      byte  ptr [rax+0xF1], 2
       je       SHORT G_M000_IG28
       mov      rcx, rax
       mov      r8, qword ptr [rbp-0x40]
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:CompleteClosedDefinitionPair(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       jmp      SHORT G_M000_IG30
 
G_M000_IG28:                ;; offset=0x025E
       mov      rcx, rax
       mov      r8, qword ptr [rbp-0x40]
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:CompleteClosedCapturedPair(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       jmp      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x0270
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG30:                ;; offset=0x0276
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rsi, gword ptr [rdx+0xA0]
       mov      rbx, rsi
       lea      rcx, bword ptr [rbx+0x148]
       mov      rdx, gword ptr [rbp-0x58]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveFunctionCall():this]
       nop      
 
G_M000_IG31:                ;; offset=0x02A2
       mov      eax, 1
 
G_M000_IG32:                ;; offset=0x02A7
       add      rsp, 72
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG33:                ;; offset=0x02B8
       sub      rsp, 40
 
G_M000_IG34:                ;; offset=0x02BC
       mov      rbx, rcx
       cmp      gword ptr [rbp-0x58], 0
       je       SHORT G_M000_IG35
       mov      rcx, rbx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_OriginalPythonException():Lokad.Lython.Runtime.PyException:this]
       cmp      rax, gword ptr [rbp-0x58]
       je       SHORT G_M000_IG35
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_PythonContext():Lokad.Lython.Runtime.PyException:this]
       test     rax, rax
       jne      SHORT G_M000_IG35
       mov      rcx, rbx
       mov      rdx, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntimeException:set_PythonContext(Lokad.Lython.Runtime.PyException):this]
 
G_M000_IG35:                ;; offset=0x02F2
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG36:                ;; offset=0x02F8
       sub      rsp, 40
 
G_M000_IG37:                ;; offset=0x02FC
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rbx, gword ptr [rdx+0xA0]
       lea      rcx, bword ptr [rbx+0x148]
       mov      rdx, gword ptr [rbp-0x58]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x28]
       mov      rcx, gword ptr [rax+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveFunctionCall():this]
       nop      
 
G_M000_IG38:                ;; offset=0x0333
       add      rsp, 40
       ret      
 
G_M000_IG39:                ;; offset=0x0338
       sub      rsp, 40
 
G_M000_IG40:                ;; offset=0x033C
       mov      rbx, rcx
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rsi, rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Name():System.String:this]
       mov      r8, rax
       mov      rdx, rsi
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyFunctionBinding:AnnotateException(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,Lokad.Lython.LythonSourceSpan)]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 879

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CompleteClosedCapturedPair(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]) (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 54 single block inlinees; 12 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 568
       lea      rbp, [rsp+0x270]
       xor      eax, eax
       mov      qword ptr [rbp-0xE8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xE0], ymm4
       vmovdqu  ymmword ptr [rbp-0xC0], ymm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       mov      qword ptr [rbp-0x40], rax
       mov      rsi, rcx
       mov      rbx, rdx
       mov      rdi, r8
 
G_M000_IG02:                ;; offset=0x0057
       mov      r14, bword ptr [r9]
       mov      r15d, dword ptr [r9+0x08]
       mov      dword ptr [rbp-0x9C], r15d
       mov      r13, gword ptr [rsi+0x98]
       mov      r12d, dword ptr [r13+0x08]
       cmp      dword ptr [rbp-0x80], r12d
       jae      G_M000_IG52
       mov      ecx, dword ptr [rbp-0x80]
       shl      rcx, 5
       cmp      dword ptr [r13+rcx+0x2C], 2
       jne      G_M000_IG08
 
G_M000_IG03:                ;; offset=0x008D
       mov      ecx, dword ptr [rbp-0x80]
       mov      eax, dword ptr [rbp-0x80]
       inc      eax
       mov      dword ptr [rbp-0x80], eax
       cmp      ecx, r12d
       jae      G_M000_IG52
       shl      rcx, 5
       mov      rax, gword ptr [r13+rcx+0x10]
       mov      gword ptr [rbp-0x148], rax
       mov      rdx, gword ptr [rbx+0xA0]
       mov      gword ptr [rbp-0x150], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00CE
       mov      rcx, gword ptr [rbp-0x150]
       mov      rdx, gword ptr [rbp-0x148]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG05:                ;; offset=0x00E2
       lea      rcx, [rbp-0x80]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0x90]
       mov      rdx, rsi
       mov      r8, rdi
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateClosedIntegerSequence[Lokad.Lython.Runtime.LythonRuntime+FactoryBindingIntegerSource](Lokad.Lython.Frontend.ExecutableCodeObject,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      ecx, dword ptr [rbp-0x80]
       mov      eax, dword ptr [rbp-0x80]
       inc      eax
       mov      dword ptr [rbp-0x80], eax
       cmp      ecx, r12d
       jae      G_M000_IG52
       shl      rcx, 5
       lea      rax, bword ptr [r13+rcx+0x10]
       mov      bword ptr [rbp-0x118], rax
       mov      rdx, gword ptr [rax]
       mov      gword ptr [rbp-0x158], rdx
       mov      r8, gword ptr [rbx+0xA0]
       mov      gword ptr [rbp-0x160], r8
       cmp      byte  ptr [r8], r8b
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x014D
       mov      rcx, gword ptr [rbp-0x160]
       mov      rdx, gword ptr [rbp-0x158]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG07:                ;; offset=0x0161
       mov      rcx, bword ptr [rbp-0x118]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, 4
       jae      G_M000_IG52
       lea      r8, bword ptr [rbp-0x78]
       mov      eax, eax
       shl      rax, 4
       add      rax, r8
       mov      bword ptr [rbp-0x200], rax
       mov      rdx, gword ptr [rbp-0x90]
       mov      rcx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x88]
       mov      rax, bword ptr [rbp-0x200]
       mov      qword ptr [rax+0x08], rcx
       cmp      dword ptr [rbp-0x80], r12d
       jae      G_M000_IG52
       mov      ecx, dword ptr [rbp-0x80]
       shl      rcx, 5
       cmp      dword ptr [r13+rcx+0x2C], 2
       je       G_M000_IG03
 
G_M000_IG08:                ;; offset=0x01C9
       mov      ecx, dword ptr [rbp-0x80]
       mov      eax, dword ptr [rbp-0x80]
       inc      eax
       mov      dword ptr [rbp-0x80], eax
       cmp      ecx, r12d
       jae      G_M000_IG52
       shl      rcx, 5
       lea      rax, bword ptr [r13+rcx+0x10]
       mov      bword ptr [rbp-0xF0], rax
       mov      rdx, gword ptr [rax]
       mov      gword ptr [rbp-0x168], rdx
       mov      r8, gword ptr [rbx+0xA0]
       mov      gword ptr [rbp-0x170], r8
       cmp      byte  ptr [r8], r8b
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x0215
       mov      rcx, gword ptr [rbp-0x170]
       mov      rdx, gword ptr [rbp-0x168]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG10:                ;; offset=0x0229
       mov      rax, gword ptr [rsi+0x30]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rcx, bword ptr [rbp-0xF0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      r9, gword ptr [rbp-0x1F0]
       cmp      eax, dword ptr [r9+0x08]
       jae      G_M000_IG52
       mov      edx, eax
       mov      rdx, gword ptr [r9+8*rdx+0x10]
       mov      rax, rdx
       test     rax, rax
       je       SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x0261
       mov      rcx, 0x7FFA02BD5398
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG48
 
G_M000_IG12:                ;; offset=0x0274
       mov      gword ptr [rbp-0xF8], rax
       mov      r9, gword ptr [rax+0x08]
       mov      r9, gword ptr [r9+0x50]
       mov      r9, gword ptr [r9+0x10]
       test     r9, r9
       je       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x028C
       cmp      dword ptr [r9+0x08], 1
       je       SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x0293
       xor      r10, r10
       xor      r11d, r11d
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x029B
       mov      r10d, dword ptr [r9+0x10]
       lea      r11, [r10+0x01]
       cmp      r11, 4
       ja       G_M000_IG49
       lea      rdx, bword ptr [rbp-0x78]
       shl      r10, 4
       add      r10, rdx
       mov      bword ptr [rbp-0x1E0], r10
       mov      r11d, 1
       mov      r10, bword ptr [rbp-0x1E0]
 
G_M000_IG16:                ;; offset=0x02CC
       mov      dword ptr [rbp-0xA0], r11d
       test     r11d, r11d
       jne      G_M000_IG19
 
G_M000_IG17:                ;; offset=0x02DC
       mov      bword ptr [rbp-0x1E0], r10
       mov      rcx, gword ptr [rax+0x08]
       mov      r8, bword ptr [rbp-0xF0]
       mov      rdx, gword ptr [r8]
       mov      gword ptr [rbp-0x120], rdx
       lea      r15, bword ptr [rbp-0x78]
       mov      bword ptr [rbp-0xB0], r15
       mov      dword ptr [rbp-0xA8], 4
       xor      r15, r15
       mov      gword ptr [rsp+0x20], r15
       mov      gword ptr [rsp+0x28], r9
       lea      r9, [rbp-0x98]
       mov      qword ptr [rsp+0x30], r9
 
G_M000_IG18:                ;; offset=0x0326
       mov      gword ptr [rsp+0x38], r15
       mov      dword ptr [rsp+0x40], 1
       lea      r9, [rbp-0xB0]
       mov      rdx, rbx
       mov      r8, gword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime:CaptureExecutableCells(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int[],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures]
       mov      r15, rax
       mov      gword ptr [rbp-0x1E8], r15
       mov      rax, gword ptr [rbp-0xF8]
       jmp      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x035D
       xor      rcx, rcx
       mov      gword ptr [rbp-0x1E8], rcx
       mov      bword ptr [rbp-0x1E0], r10
 
G_M000_IG20:                ;; offset=0x036D
       mov      r8, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x128], r8
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x130], rax
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      r8, rax
       mov      rcx, bword ptr [rbp-0xF0]
       mov      rcx, gword ptr [rcx]
       xor      rdx, rdx
       mov      gword ptr [rbp-0xC8], rdx
 
G_M000_IG21:                ;; offset=0x03A2
       mov      gword ptr [rbp-0xC0], rdx
       mov      byte  ptr [rbp-0xB8], 0
 
G_M000_IG22:                ;; offset=0x03B0
       mov      dword ptr [rsp+0x28], edx
       mov      gword ptr [rsp+0x30], rbx
       mov      gword ptr [rsp+0x38], rcx
 
G_M000_IG23:                ;; offset=0x03BE
       mov      bword ptr [rbp-0xD8], rdx
 
G_M000_IG24:                ;; offset=0x03C5
       mov      dword ptr [rbp-0xD0], edx
 
G_M000_IG25:                ;; offset=0x03CB
       mov      gword ptr [rsp+0x48], rdx
 
G_M000_IG26:                ;; offset=0x03D0
       mov      gword ptr [rbp-0xE8], rdx
 
G_M000_IG27:                ;; offset=0x03D7
       mov      dword ptr [rbp-0xE0], edx
       mov      byte  ptr [rbp-0xDC], 0
 
G_M000_IG28:                ;; offset=0x03E4
       mov      dword ptr [rsp+0x58], edx
       mov      rcx, bword ptr [rbp-0x1E0]
       mov      bword ptr [rbp-0xB0], rcx
       mov      ecx, dword ptr [rbp-0xA0]
       mov      dword ptr [rbp-0xA8], ecx
       lea      rcx, [rbp-0xC8]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xE8]
       mov      qword ptr [rsp+0x50], rcx
       lea      rcx, [rbp-0xD8]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xB0]
       mov      qword ptr [rsp+0x60], rcx
       mov      rcx, gword ptr [rbp-0x128]
       mov      rdx, gword ptr [rbp-0x130]
       mov      r9, gword ptr [rbp-0x1E8]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
       mov      gword ptr [rbp-0x100], rax
       mov      ecx, dword ptr [rbp-0x80]
       mov      edx, dword ptr [rbp-0x80]
       inc      edx
       mov      dword ptr [rbp-0x80], edx
       cmp      ecx, r12d
       jae      G_M000_IG52
       shl      rcx, 5
       mov      rdx, gword ptr [r13+rcx+0x10]
       mov      gword ptr [rbp-0x178], rdx
       mov      r8, gword ptr [rbx+0xA0]
       mov      gword ptr [rbp-0x180], r8
       cmp      byte  ptr [r8], r8b
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x0496
       mov      rcx, gword ptr [rbp-0x180]
       mov      rdx, gword ptr [rbp-0x178]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG30:                ;; offset=0x04AA
       mov      ecx, dword ptr [rbp-0x80]
       mov      eax, dword ptr [rbp-0x80]
       inc      eax
       mov      dword ptr [rbp-0x80], eax
       cmp      ecx, r12d
       jae      G_M000_IG52
       shl      rcx, 5
       lea      rax, bword ptr [r13+rcx+0x10]
       mov      bword ptr [rbp-0x108], rax
       mov      rdx, gword ptr [rsi+0x30]
       mov      gword ptr [rbp-0x1F8], rdx
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x1F8]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG52
       mov      eax, eax
       mov      rdx, gword ptr [rcx+8*rax+0x10]
       mov      rax, rdx
       test     rax, rax
       je       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x0501
       mov      rcx, 0x7FFA02BD5398
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG50
 
G_M000_IG32:                ;; offset=0x0514
       mov      gword ptr [rbp-0x138], rax
       mov      rcx, bword ptr [rbp-0x108]
       mov      rdx, gword ptr [rcx]
       mov      gword ptr [rbp-0x188], rdx
       mov      r8, gword ptr [rbx+0xA0]
       mov      gword ptr [rbp-0x190], r8
       cmp      byte  ptr [r8], r8b
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x054A
       mov      rcx, gword ptr [rbp-0x190]
       mov      rdx, gword ptr [rbp-0x188]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG34:                ;; offset=0x055E
       mov      ecx, dword ptr [rbp-0x80]
       mov      eax, dword ptr [rbp-0x80]
       inc      eax
       mov      dword ptr [rbp-0x80], eax
       cmp      ecx, r12d
       jae      G_M000_IG52
       shl      rcx, 5
       mov      rax, gword ptr [r13+rcx+0x10]
       mov      gword ptr [rbp-0x198], rax
       mov      rdx, gword ptr [rbx+0xA0]
       mov      gword ptr [rbp-0x1A0], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x059F
       mov      rcx, gword ptr [rbp-0x1A0]
       mov      rdx, gword ptr [rbp-0x198]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG36:                ;; offset=0x05B3
       mov      ecx, dword ptr [rbp-0x80]
       mov      eax, dword ptr [rbp-0x80]
       inc      eax
       mov      dword ptr [rbp-0x80], eax
       cmp      ecx, r12d
       jae      G_M000_IG52
       shl      rcx, 5
       mov      rax, gword ptr [r13+rcx+0x10]
       mov      gword ptr [rbp-0x1A8], rax
       mov      rdx, gword ptr [rbx+0xA0]
       mov      gword ptr [rbp-0x1B0], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x05F4
       mov      rcx, gword ptr [rbp-0x1B0]
       mov      rdx, gword ptr [rbp-0x1A8]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG38:                ;; offset=0x0608
       mov      ecx, dword ptr [rbp-0x80]
       mov      eax, dword ptr [rbp-0x80]
       inc      eax
       mov      dword ptr [rbp-0x80], eax
       cmp      ecx, r12d
       jae      G_M000_IG52
       shl      rcx, 5
       mov      rax, gword ptr [r13+rcx+0x10]
       mov      gword ptr [rbp-0x1B8], rax
       mov      rdx, gword ptr [rbx+0xA0]
       mov      gword ptr [rbp-0x1C0], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x0649
       mov      rcx, gword ptr [rbp-0x1C0]
       mov      rdx, gword ptr [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG40:                ;; offset=0x065D
       mov      ecx, dword ptr [rbp-0x80]
       mov      eax, dword ptr [rbp-0x80]
       inc      eax
       mov      dword ptr [rbp-0x80], eax
       cmp      ecx, r12d
       jae      G_M000_IG52
       shl      rcx, 5
       lea      rax, bword ptr [r13+rcx+0x10]
       mov      bword ptr [rbp-0x110], rax
       mov      rdx, gword ptr [rax]
       mov      gword ptr [rbp-0x1C8], rdx
       mov      r8, gword ptr [rbx+0xA0]
       mov      gword ptr [rbp-0x1D0], r8
       cmp      byte  ptr [r8], r8b
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x06A9
       mov      rcx, gword ptr [rbp-0x1D0]
       mov      rdx, gword ptr [rbp-0x1C8]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG42:                ;; offset=0x06BD
       mov      rdx, gword ptr [rbp-0x138]
       mov      rax, gword ptr [rdx+0x08]
       mov      gword ptr [rbp-0x140], rax
       mov      rcx, gword ptr [rsi+0xB0]
       mov      rsi, bword ptr [rbp-0x110]
       cmp      dword ptr [rsi+0x1C], 42
       jne      G_M000_IG51
       mov      edx, dword ptr [rsi+0x08]
       mov      r11, 0x7FFA02622070
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r9, gword ptr [rax+0x18]
       mov      rdx, rdi
       mov      r8, rbx
       mov      rcx, gword ptr [rbp-0x140]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateImmediatelyCalledLambda(Lokad.Lython.Frontend.ExecutableCodeObject,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rsi, rax
       cmp      dword ptr [rbp-0x80], r12d
       jge      SHORT G_M000_IG46
 
G_M000_IG43:                ;; offset=0x0717
       cmp      dword ptr [rbp-0x80], r12d
       jae      G_M000_IG52
       mov      ecx, dword ptr [rbp-0x80]
       shl      rcx, 5
       mov      rdi, gword ptr [r13+rcx+0x10]
       mov      rax, gword ptr [rbx+0xA0]
       mov      gword ptr [rbp-0x1D8], rax
       cmp      byte  ptr [rax], al
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG45
 
G_M000_IG44:                ;; offset=0x074A
       mov      rcx, gword ptr [rbp-0x1D8]
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG45:                ;; offset=0x075A
       mov      ecx, dword ptr [rbp-0x80]
       inc      ecx
       mov      dword ptr [rbp-0x80], ecx
       cmp      dword ptr [rbp-0x80], r12d
       jl       SHORT G_M000_IG43
 
G_M000_IG46:                ;; offset=0x0768
       cmp      dword ptr [rbp-0x9C], 1
       jbe      SHORT G_M000_IG52
       lea      rbx, bword ptr [r14+0x10]
       mov      rdx, gword ptr [rbp-0x100]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbx+0x08], rcx
       mov      rcx, r14
       mov      rdx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
 
G_M000_IG47:                ;; offset=0x079B
       add      rsp, 568
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG48:                ;; offset=0x07AF
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG49:                ;; offset=0x07B5
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG50:                ;; offset=0x07BC
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG51:                ;; offset=0x07C2
       mov      rcx, rsi
       mov      rdx, 0x20B508CBFF0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG52:                ;; offset=0x07DE
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 2020

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:EvaluateClosedIntegerSequence[Lokad.Lython.Runtime.LythonRuntime+FactoryBindingIntegerSource](Lokad.Lython.Frontend.ExecutableCodeObject,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 24 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 128
       xor      eax, eax
       mov      qword ptr [rsp+0x28], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x30], ymm4
       vmovdqu  ymmword ptr [rsp+0x50], ymm4
       vmovdqa  xmmword ptr [rsp+0x70], xmm4
       mov      rdi, rcx
       mov      rsi, r9
       mov      rbx, bword ptr [rsp+0xE0]
 
G_M000_IG02:                ;; offset=0x003C
       mov      gword ptr [rsp+0x70], rdx
       mov      qword ptr [rsp+0x78], r8
       mov      rcx, qword ptr [rsp+0x78]
       mov      rax, 0x1EB29C01CF0
       mov      rbp, gword ptr [rax]
       mov      gword ptr [rsp+0x60], rbp
       mov      qword ptr [rsp+0x68], rcx
       jmp      G_M000_IG22
 
G_M000_IG03:                ;; offset=0x0067
       mov      r15d, dword ptr [r14+0x08]
       and      r15d, 0x7FFFFFFF
 
G_M000_IG04:                ;; offset=0x0072
       mov      ecx, dword ptr [r14+0x10]
       lea      rdx, [rsp+0x60]
       lea      r8, [rsp+0x58]
       lea      r9, [rsp+0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime:<EvaluateClosedIntegerSequence>g__TryReadInteger|831_0[Lokad.Lython.Runtime.LythonRuntime+FactoryBindingIntegerSource](int,byref,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x008F
       mov      ecx, dword ptr [r14+0x0C]
       lea      rdx, [rsp+0x60]
       lea      r8, [rsp+0x50]
       lea      r9, [rsp+0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime:<EvaluateClosedIntegerSequence>g__TryReadInteger|831_0[Lokad.Lython.Runtime.LythonRuntime+FactoryBindingIntegerSource](int,byref,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG06
       lea      r9, [rsp+0x48]
       mov      ecx, r15d
       mov      rdx, qword ptr [rsp+0x58]
       mov      r8, qword ptr [rsp+0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineBinary(int,long,long,byref):bool]
       test     eax, eax
       jne      G_M000_IG35
       lea      ecx, [r15-0x0F]
       cmp      ecx, 5
       jbe      G_M000_IG27
 
G_M000_IG06:                ;; offset=0x00D9
       mov      ecx, dword ptr [r14+0x10]
 
G_M000_IG07:                ;; offset=0x00DD
       vmovdqu  xmm0, xmmword ptr [rsp+0x60]
       vmovdqu  xmmword ptr [rsp+0x38], xmm0
 
G_M000_IG08:                ;; offset=0x00E9
       test     ecx, ecx
       jge      SHORT G_M000_IG09
       mov      rax, gword ptr [rsp+0x70]
       mov      rax, gword ptr [rax+0x30]
       mov      edx, ecx
       not      edx
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG38
       not      ecx
       mov      r13, gword ptr [rax+8*rcx+0x10]
       jmp      SHORT G_M000_IG13
 
G_M000_IG09:                ;; offset=0x010C
       cmp      gword ptr [rsp+0x38], rbp
       je       SHORT G_M000_IG12
       mov      rcx, gword ptr [rsp+0x38]
       mov      rax, 0x1EB29C01CF8
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG11
       cmp      qword ptr [rsp+0x40], 0
       jne      SHORT G_M000_IG10
       mov      r13, gword ptr [rsp+0x38]
       jmp      SHORT G_M000_IG13
 
G_M000_IG10:                ;; offset=0x0136
       lea      rcx, [rsp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      r13, rax
       jmp      SHORT G_M000_IG13
 
G_M000_IG11:                ;; offset=0x0146
       mov      rcx, 0x7FFA02716488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rsp+0x40]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      r13, rax
       mov      gword ptr [rsp+0x38], r13
       xor      ecx, ecx
       mov      qword ptr [rsp+0x40], rcx
       jmp      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x0171
       lea      rcx, [rsp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r13, rax
 
G_M000_IG13:                ;; offset=0x017F
       mov      ecx, dword ptr [r14+0x0C]
 
G_M000_IG14:                ;; offset=0x0183
       vmovdqu  xmm0, xmmword ptr [rsp+0x60]
       vmovdqu  xmmword ptr [rsp+0x28], xmm0
 
G_M000_IG15:                ;; offset=0x018F
       test     ecx, ecx
       jge      SHORT G_M000_IG16
       mov      rax, gword ptr [rsp+0x70]
       mov      rax, gword ptr [rax+0x30]
       mov      edx, ecx
       not      edx
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG38
       not      ecx
       mov      r8, gword ptr [rax+8*rcx+0x10]
       jmp      SHORT G_M000_IG20
 
G_M000_IG16:                ;; offset=0x01B2
       cmp      gword ptr [rsp+0x28], rbp
       je       SHORT G_M000_IG19
       mov      rcx, gword ptr [rsp+0x28]
       mov      rax, 0x1EB29C01CF8
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG18
       cmp      qword ptr [rsp+0x30], 0
       jne      SHORT G_M000_IG17
       mov      r8, gword ptr [rsp+0x28]
       jmp      SHORT G_M000_IG20
 
G_M000_IG17:                ;; offset=0x01DC
       lea      rcx, [rsp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      r8, rax
       jmp      SHORT G_M000_IG20
 
G_M000_IG18:                ;; offset=0x01EC
       mov      rcx, 0x7FFA02716488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rsp+0x30]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      r8, rax
       mov      gword ptr [rsp+0x28], r8
       xor      ecx, ecx
       mov      qword ptr [rsp+0x30], rcx
       jmp      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x0217
       lea      rcx, [rsp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r8, rax
 
G_M000_IG20:                ;; offset=0x0225
       mov      rcx, gword ptr [r14]
       mov      gword ptr [rsp+0x20], rcx
       mov      ecx, r15d
       mov      rdx, r13
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rsp+0x60], rax
 
G_M000_IG21:                ;; offset=0x0241
       xor      eax, eax
       mov      qword ptr [rsp+0x68], rax
 
G_M000_IG22:                ;; offset=0x0248
       mov      rcx, gword ptr [rsp+0x70]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [rbx]
       mov      edx, eax
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG38
       shl      rdx, 5
       lea      r14, bword ptr [rcx+rdx+0x10]
       cmp      dword ptr [r14+0x1C], 46
       jne      G_M000_IG36
 
G_M000_IG23:                ;; offset=0x0275
       inc      eax
       mov      dword ptr [rbx], eax
       mov      r15, gword ptr [r14]
       mov      r13, gword ptr [rsi+0xA0]
       cmp      byte  ptr [r13], r13b
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0294
       mov      rcx, r13
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG25:                ;; offset=0x02A0
       cmp      dword ptr [r14+0x1C], 51
       jne      G_M000_IG03
 
G_M000_IG26:                ;; offset=0x02AB
       mov      r15d, dword ptr [r14+0x14]
       jmp      G_M000_IG04
 
G_M000_IG27:                ;; offset=0x02B4
       mov      rcx, qword ptr [rsp+0x50]
       cmp      qword ptr [rsp+0x58], rcx
       jge      SHORT G_M000_IG30
 
G_M000_IG28:                ;; offset=0x02C0
       mov      edx, -1
 
G_M000_IG29:                ;; offset=0x02C5
       mov      ecx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime:CompareOrderedResult(int,int):bool]
       test     eax, eax
       jne      SHORT G_M000_IG33
       mov      rax, 0x1EB29C013C8
       mov      rax, gword ptr [rax]
       jmp      SHORT G_M000_IG34
 
G_M000_IG30:                ;; offset=0x02E1
       cmp      qword ptr [rsp+0x58], rcx
       jle      SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x02E8
       mov      edx, 1
       jmp      SHORT G_M000_IG29
 
G_M000_IG32:                ;; offset=0x02EF
       xor      edx, edx
       jmp      SHORT G_M000_IG29
 
G_M000_IG33:                ;; offset=0x02F3
       mov      rax, 0x1EB29C013C0
       mov      rax, gword ptr [rax]
 
G_M000_IG34:                ;; offset=0x0300
       mov      gword ptr [rsp+0x60], rax
       jmp      G_M000_IG21
 
G_M000_IG35:                ;; offset=0x030A
       mov      rax, qword ptr [rsp+0x48]
       mov      gword ptr [rsp+0x60], rbp
       mov      qword ptr [rsp+0x68], rax
       jmp      G_M000_IG22
 
G_M000_IG36:                ;; offset=0x031E
       mov      rax, gword ptr [rsp+0x60]
       mov      gword ptr [rdi], rax
       mov      rax, qword ptr [rsp+0x68]
       mov      qword ptr [rdi+0x08], rax
       mov      rax, rdi
 
G_M000_IG37:                ;; offset=0x0332
       add      rsp, 128
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG38:                ;; offset=0x0344
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 842

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:EvaluateClosedIntegerSequence[Lokad.Lython.Runtime.LythonRuntime+CaptureIntegerSource](Lokad.Lython.Frontend.ExecutableCodeObject,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 23 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 168
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x30], ymm4
       vmovdqu  ymmword ptr [rsp+0x50], ymm4
       vmovdqu  ymmword ptr [rsp+0x70], ymm4
       vmovdqa  xmmword ptr [rsp+0x90], xmm4
       xor      eax, eax
       mov      qword ptr [rsp+0xA0], rax
       mov      rdi, rcx
       mov      rsi, r9
       mov      rbx, bword ptr [rsp+0x110]
 
G_M000_IG02:                ;; offset=0x004A
       mov      gword ptr [rsp+0x98], rdx
       mov      qword ptr [rsp+0xA0], r8
       jmp      G_M000_IG24
 
G_M000_IG03:                ;; offset=0x005F
       mov      r14d, dword ptr [rbp+0x08]
       and      r14d, 0x7FFFFFFF
 
G_M000_IG04:                ;; offset=0x006A
       mov      ecx, dword ptr [rbp+0x10]
       lea      rdx, [rsp+0x88]
       lea      r8, [rsp+0x80]
       lea      r9, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime:<EvaluateClosedIntegerSequence>g__TryReadInteger|831_0[Lokad.Lython.Runtime.LythonRuntime+CaptureIntegerSource](int,byref,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x008F
       mov      ecx, dword ptr [rbp+0x0C]
       lea      rdx, [rsp+0x88]
       lea      r8, [rsp+0x78]
       lea      r9, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime:<EvaluateClosedIntegerSequence>g__TryReadInteger|831_0[Lokad.Lython.Runtime.LythonRuntime+CaptureIntegerSource](int,byref,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG06
       lea      r9, [rsp+0x70]
       mov      ecx, r14d
       mov      rdx, qword ptr [rsp+0x80]
       mov      r8, qword ptr [rsp+0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineBinary(int,long,long,byref):bool]
       test     eax, eax
       jne      G_M000_IG37
       lea      ecx, [r14-0x0F]
       cmp      ecx, 5
       jbe      G_M000_IG29
 
G_M000_IG06:                ;; offset=0x00E1
       mov      r15d, dword ptr [rbp+0x10]
 
G_M000_IG07:                ;; offset=0x00E5
       vmovdqu  xmm0, xmmword ptr [rsp+0x88]
       vmovdqu  xmmword ptr [rsp+0x60], xmm0
 
G_M000_IG08:                ;; offset=0x00F4
       mov      rcx, gword ptr [rsp+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CaptureOperandBase():int:this]
       mov      ecx, eax
       not      ecx
       cmp      ecx, r15d
       jne      SHORT G_M000_IG09
       mov      rcx, 0x7FFA02ABFD50
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rdx, qword ptr [rsp+0xA0]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
       lea      rcx, [rsp+0x50]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r13+0x08]
       mov      rdx, gword ptr [rsp+0x50]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rsp+0x58]
       mov      dword ptr [r13+0x10], ecx
       jmp      G_M000_IG14
 
G_M000_IG09:                ;; offset=0x0157
       test     r15d, r15d
       jge      SHORT G_M000_IG10
       mov      rcx, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [rcx+0x30]
       mov      eax, r15d
       not      eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG40
       mov      eax, r15d
       not      eax
       mov      r13, gword ptr [rcx+8*rax+0x10]
       jmp      G_M000_IG14
 
G_M000_IG10:                ;; offset=0x0185
       mov      rcx, gword ptr [rsp+0x60]
       mov      rax, 0x1EB29C01CF0
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG13
       mov      rcx, gword ptr [rsp+0x60]
       mov      rax, 0x1EB29C01CF8
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG12
       cmp      qword ptr [rsp+0x68], 0
       jne      SHORT G_M000_IG11
       mov      r13, gword ptr [rsp+0x60]
       jmp      SHORT G_M000_IG14
 
G_M000_IG11:                ;; offset=0x01BC
       lea      rcx, [rsp+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      r13, rax
       jmp      SHORT G_M000_IG14
 
G_M000_IG12:                ;; offset=0x01CC
       mov      rcx, 0x7FFA02716488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rsp+0x68]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      r13, rax
       mov      gword ptr [rsp+0x60], r13
       xor      ecx, ecx
       mov      qword ptr [rsp+0x68], rcx
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x01F7
       lea      rcx, [rsp+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r13, rax
 
G_M000_IG14:                ;; offset=0x0205
       mov      r15d, dword ptr [rbp+0x0C]
 
G_M000_IG15:                ;; offset=0x0209
       vmovdqu  xmm0, xmmword ptr [rsp+0x88]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG16:                ;; offset=0x0218
       mov      rcx, gword ptr [rsp+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CaptureOperandBase():int:this]
       mov      ecx, eax
       not      ecx
       cmp      ecx, r15d
       jne      SHORT G_M000_IG17
       mov      rcx, 0x7FFA02ABFD50
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       mov      rdx, qword ptr [rsp+0xA0]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
       lea      rcx, [rsp+0x30]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, gword ptr [rsp+0x30]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rsp+0x38]
       mov      dword ptr [r12+0x10], ecx
       mov      r8, r12
       jmp      G_M000_IG22
 
G_M000_IG17:                ;; offset=0x0280
       test     r15d, r15d
       jge      SHORT G_M000_IG18
       mov      r8, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [r8+0x30]
       mov      eax, r15d
       not      eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG40
       mov      eax, r15d
       not      eax
       mov      r8, gword ptr [rcx+8*rax+0x10]
       jmp      G_M000_IG22
 
G_M000_IG18:                ;; offset=0x02AE
       mov      rcx, gword ptr [rsp+0x40]
       mov      rax, 0x1EB29C01CF0
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG21
       mov      rcx, gword ptr [rsp+0x40]
       mov      rax, 0x1EB29C01CF8
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG20
       cmp      qword ptr [rsp+0x48], 0
       jne      SHORT G_M000_IG19
       mov      r8, gword ptr [rsp+0x40]
       jmp      SHORT G_M000_IG22
 
G_M000_IG19:                ;; offset=0x02E5
       lea      rcx, [rsp+0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      r8, rax
       jmp      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x02F5
       mov      rcx, 0x7FFA02716488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rsp+0x48]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      r8, rax
       mov      gword ptr [rsp+0x40], r8
       xor      ecx, ecx
       mov      qword ptr [rsp+0x48], rcx
       jmp      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x0320
       lea      rcx, [rsp+0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r8, rax
 
G_M000_IG22:                ;; offset=0x032E
       mov      rcx, gword ptr [rbp]
       mov      gword ptr [rsp+0x20], rcx
       mov      ecx, r14d
       mov      rdx, r13
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rsp+0x88], rax
 
G_M000_IG23:                ;; offset=0x034E
       xor      eax, eax
       mov      qword ptr [rsp+0x90], rax
 
G_M000_IG24:                ;; offset=0x0358
       mov      rcx, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [rbx]
       mov      edx, eax
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG40
       shl      rdx, 5
       lea      rbp, bword ptr [rcx+rdx+0x10]
       cmp      dword ptr [rbp+0x1C], 46
       jne      G_M000_IG38
 
G_M000_IG25:                ;; offset=0x0387
       inc      eax
       mov      dword ptr [rbx], eax
       mov      r14, gword ptr [rbp]
       mov      r15, gword ptr [rsi+0xA0]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x03A6
       mov      rcx, r15
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG27:                ;; offset=0x03B2
       cmp      dword ptr [rbp+0x1C], 51
       jne      G_M000_IG03
 
G_M000_IG28:                ;; offset=0x03BC
       mov      r14d, dword ptr [rbp+0x14]
       jmp      G_M000_IG04
 
G_M000_IG29:                ;; offset=0x03C5
       mov      rcx, qword ptr [rsp+0x78]
       cmp      qword ptr [rsp+0x80], rcx
       jge      SHORT G_M000_IG32
 
G_M000_IG30:                ;; offset=0x03D4
       mov      edx, -1
 
G_M000_IG31:                ;; offset=0x03D9
       mov      ecx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime:CompareOrderedResult(int,int):bool]
       test     eax, eax
       jne      SHORT G_M000_IG35
       mov      rax, 0x1EB29C013C8
       mov      rax, gword ptr [rax]
       jmp      SHORT G_M000_IG36
 
G_M000_IG32:                ;; offset=0x03F5
       cmp      qword ptr [rsp+0x80], rcx
       jle      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x03FF
       mov      edx, 1
       jmp      SHORT G_M000_IG31
 
G_M000_IG34:                ;; offset=0x0406
       xor      edx, edx
       jmp      SHORT G_M000_IG31
 
G_M000_IG35:                ;; offset=0x040A
       mov      rax, 0x1EB29C013C0
       mov      rax, gword ptr [rax]
 
G_M000_IG36:                ;; offset=0x0417
       mov      gword ptr [rsp+0x88], rax
       jmp      G_M000_IG23
 
G_M000_IG37:                ;; offset=0x0424
       mov      rax, qword ptr [rsp+0x70]
       mov      rcx, 0x1EB29C01CF0
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rsp+0x88], rcx
       mov      qword ptr [rsp+0x90], rax
       jmp      G_M000_IG24
 
G_M000_IG38:                ;; offset=0x044B
       mov      rax, gword ptr [rsp+0x88]
       mov      gword ptr [rdi], rax
       mov      rax, qword ptr [rsp+0x90]
       mov      qword ptr [rdi+0x08], rax
       mov      rax, rdi
 
G_M000_IG39:                ;; offset=0x0465
       add      rsp, 168
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG40:                ;; offset=0x0479
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1151

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:EvaluateClosedIntegerSequence[Lokad.Lython.Runtime.LythonRuntime+ParameterIntegerSource](Lokad.Lython.Frontend.ExecutableCodeObject,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 23 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 168
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x30], ymm4
       vmovdqu  ymmword ptr [rsp+0x50], ymm4
       vmovdqu  ymmword ptr [rsp+0x70], ymm4
       vmovdqa  xmmword ptr [rsp+0x90], xmm4
       xor      eax, eax
       mov      qword ptr [rsp+0xA0], rax
       mov      rdi, rcx
       mov      rsi, r9
       mov      rbx, bword ptr [rsp+0x110]
 
G_M000_IG02:                ;; offset=0x004A
       mov      gword ptr [rsp+0x98], rdx
       mov      qword ptr [rsp+0xA0], r8
       jmp      G_M000_IG24
 
G_M000_IG03:                ;; offset=0x005F
       mov      r14d, dword ptr [rbp+0x08]
       and      r14d, 0x7FFFFFFF
 
G_M000_IG04:                ;; offset=0x006A
       mov      ecx, dword ptr [rbp+0x10]
       lea      rdx, [rsp+0x88]
       lea      r8, [rsp+0x80]
       lea      r9, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime:<EvaluateClosedIntegerSequence>g__TryReadInteger|831_0[Lokad.Lython.Runtime.LythonRuntime+ParameterIntegerSource](int,byref,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x008F
       mov      ecx, dword ptr [rbp+0x0C]
       lea      rdx, [rsp+0x88]
       lea      r8, [rsp+0x78]
       lea      r9, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime:<EvaluateClosedIntegerSequence>g__TryReadInteger|831_0[Lokad.Lython.Runtime.LythonRuntime+ParameterIntegerSource](int,byref,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG06
       lea      r9, [rsp+0x70]
       mov      ecx, r14d
       mov      rdx, qword ptr [rsp+0x80]
       mov      r8, qword ptr [rsp+0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineBinary(int,long,long,byref):bool]
       test     eax, eax
       jne      G_M000_IG37
       lea      ecx, [r14-0x0F]
       cmp      ecx, 5
       jbe      G_M000_IG29
 
G_M000_IG06:                ;; offset=0x00E1
       mov      r15d, dword ptr [rbp+0x10]
 
G_M000_IG07:                ;; offset=0x00E5
       vmovdqu  xmm0, xmmword ptr [rsp+0x88]
       vmovdqu  xmmword ptr [rsp+0x60], xmm0
 
G_M000_IG08:                ;; offset=0x00F4
       test     r15d, r15d
       jne      SHORT G_M000_IG09
       mov      rcx, 0x7FFA02ABFD50
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rdx, qword ptr [rsp+0xA0]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
       lea      rcx, [rsp+0x50]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r13+0x08]
       mov      rdx, gword ptr [rsp+0x50]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rsp+0x58]
       mov      dword ptr [r13+0x10], ecx
       jmp      G_M000_IG14
 
G_M000_IG09:                ;; offset=0x0143
       test     r15d, r15d
       jge      SHORT G_M000_IG10
       mov      rcx, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [rcx+0x30]
       mov      eax, r15d
       not      eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG40
       mov      eax, r15d
       not      eax
       mov      r13, gword ptr [rcx+8*rax+0x10]
       jmp      G_M000_IG14
 
G_M000_IG10:                ;; offset=0x0171
       mov      rcx, gword ptr [rsp+0x60]
       mov      rax, 0x1EB29C01CF0
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG13
       mov      rcx, gword ptr [rsp+0x60]
       mov      rax, 0x1EB29C01CF8
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG12
       cmp      qword ptr [rsp+0x68], 0
       jne      SHORT G_M000_IG11
       mov      r13, gword ptr [rsp+0x60]
       jmp      SHORT G_M000_IG14
 
G_M000_IG11:                ;; offset=0x01A8
       lea      rcx, [rsp+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      r13, rax
       jmp      SHORT G_M000_IG14
 
G_M000_IG12:                ;; offset=0x01B8
       mov      rcx, 0x7FFA02716488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rsp+0x68]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      r13, rax
       mov      gword ptr [rsp+0x60], r13
       xor      ecx, ecx
       mov      qword ptr [rsp+0x68], rcx
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x01E3
       lea      rcx, [rsp+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r13, rax
 
G_M000_IG14:                ;; offset=0x01F1
       mov      r15d, dword ptr [rbp+0x0C]
 
G_M000_IG15:                ;; offset=0x01F5
       vmovdqu  xmm0, xmmword ptr [rsp+0x88]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG16:                ;; offset=0x0204
       test     r15d, r15d
       jne      SHORT G_M000_IG17
       mov      rcx, 0x7FFA02ABFD50
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       mov      rdx, qword ptr [rsp+0xA0]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
       lea      rcx, [rsp+0x30]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, gword ptr [rsp+0x30]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rsp+0x38]
       mov      dword ptr [r12+0x10], ecx
       mov      r8, r12
       jmp      G_M000_IG22
 
G_M000_IG17:                ;; offset=0x0258
       test     r15d, r15d
       jge      SHORT G_M000_IG18
       mov      r8, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [r8+0x30]
       mov      eax, r15d
       not      eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG40
       mov      eax, r15d
       not      eax
       mov      r8, gword ptr [rcx+8*rax+0x10]
       jmp      G_M000_IG22
 
G_M000_IG18:                ;; offset=0x0286
       mov      rcx, gword ptr [rsp+0x40]
       mov      rax, 0x1EB29C01CF0
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG21
       mov      rcx, gword ptr [rsp+0x40]
       mov      rax, 0x1EB29C01CF8
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG20
       cmp      qword ptr [rsp+0x48], 0
       jne      SHORT G_M000_IG19
       mov      r8, gword ptr [rsp+0x40]
       jmp      SHORT G_M000_IG22
 
G_M000_IG19:                ;; offset=0x02BD
       lea      rcx, [rsp+0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      r8, rax
       jmp      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x02CD
       mov      rcx, 0x7FFA02716488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rsp+0x48]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      r8, rax
       mov      gword ptr [rsp+0x40], r8
       xor      ecx, ecx
       mov      qword ptr [rsp+0x48], rcx
       jmp      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x02F8
       lea      rcx, [rsp+0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r8, rax
 
G_M000_IG22:                ;; offset=0x0306
       mov      rcx, gword ptr [rbp]
       mov      gword ptr [rsp+0x20], rcx
       mov      ecx, r14d
       mov      rdx, r13
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rsp+0x88], rax
 
G_M000_IG23:                ;; offset=0x0326
       xor      eax, eax
       mov      qword ptr [rsp+0x90], rax
 
G_M000_IG24:                ;; offset=0x0330
       mov      rcx, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [rbx]
       mov      edx, eax
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG40
       shl      rdx, 5
       lea      rbp, bword ptr [rcx+rdx+0x10]
       cmp      dword ptr [rbp+0x1C], 46
       jne      G_M000_IG38
 
G_M000_IG25:                ;; offset=0x035F
       inc      eax
       mov      dword ptr [rbx], eax
       mov      r14, gword ptr [rbp]
       mov      r15, gword ptr [rsi+0xA0]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x037E
       mov      rcx, r15
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG27:                ;; offset=0x038A
       cmp      dword ptr [rbp+0x1C], 51
       jne      G_M000_IG03
 
G_M000_IG28:                ;; offset=0x0394
       mov      r14d, dword ptr [rbp+0x14]
       jmp      G_M000_IG04
 
G_M000_IG29:                ;; offset=0x039D
       mov      rcx, qword ptr [rsp+0x78]
       cmp      qword ptr [rsp+0x80], rcx
       jge      SHORT G_M000_IG32
 
G_M000_IG30:                ;; offset=0x03AC
       mov      edx, -1
 
G_M000_IG31:                ;; offset=0x03B1
       mov      ecx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime:CompareOrderedResult(int,int):bool]
       test     eax, eax
       jne      SHORT G_M000_IG35
       mov      rax, 0x1EB29C013C8
       mov      rax, gword ptr [rax]
       jmp      SHORT G_M000_IG36
 
G_M000_IG32:                ;; offset=0x03CD
       cmp      qword ptr [rsp+0x80], rcx
       jle      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x03D7
       mov      edx, 1
       jmp      SHORT G_M000_IG31
 
G_M000_IG34:                ;; offset=0x03DE
       xor      edx, edx
       jmp      SHORT G_M000_IG31
 
G_M000_IG35:                ;; offset=0x03E2
       mov      rax, 0x1EB29C013C0
       mov      rax, gword ptr [rax]
 
G_M000_IG36:                ;; offset=0x03EF
       mov      gword ptr [rsp+0x88], rax
       jmp      G_M000_IG23
 
G_M000_IG37:                ;; offset=0x03FC
       mov      rax, qword ptr [rsp+0x70]
       mov      rcx, 0x1EB29C01CF0
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rsp+0x88], rcx
       mov      qword ptr [rsp+0x90], rax
       jmp      G_M000_IG24
 
G_M000_IG38:                ;; offset=0x0423
       mov      rax, gword ptr [rsp+0x88]
       mov      gword ptr [rdi], rax
       mov      rax, qword ptr [rsp+0x90]
       mov      qword ptr [rdi+0x08], rax
       mov      rax, rdi
 
G_M000_IG39:                ;; offset=0x043D
       add      rsp, 168
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG40:                ;; offset=0x0451
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1111

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeWorkspace(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 11 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 440
       lea      rbp, [rsp+0x1E0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x190], xmm4
       mov      rax, -336
 
G_M000_IG16:                ;; offset=0x002D
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG16
       mov      qword ptr [rbp-0x30], rax
       mov      rbx, rcx
       mov      rdi, gword ptr [rbp+0x38]
       mov      rsi, bword ptr [rbp+0x50]
 
G_M000_IG02:                ;; offset=0x0054
       mov      rax, bword ptr [r8]
       mov      r14d, dword ptr [r8+0x08]
       mov      rcx, gword ptr [rbx+0x40]
       mov      r15d, dword ptr [rcx+0xE8]
       cmp      r15d, 16
       ja       G_M000_IG11
       cmp      byte  ptr [rbp+0x48], 0
       jne      G_M000_IG07
 
G_M000_IG03:                ;; offset=0x007A
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      ecx, r15d
       ja       G_M000_IG11
       lea      r8, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x170], r8
       mov      dword ptr [rbp-0x168], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x180], rcx
 
G_M000_IG04:                ;; offset=0x00AB
       mov      dword ptr [rbp-0x178], ecx
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], r9
       mov      gword ptr [rsp+0x38], rdx
       mov      bword ptr [rbp-0x190], rax
       mov      dword ptr [rbp-0x188], r14d
       lea      rcx, [rbp-0x170]
       lea      rdx, [rbp-0x180]
       lea      r9, [rbp-0x190]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, rbx
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG05:                ;; offset=0x00FE
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
       lea      rdx, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x170], rdx
       mov      dword ptr [rbp-0x168], r15d
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      bword ptr [rsp+0x28], rsi
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rsi
       mov      rsi, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rsi
       mov      rsi, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rsi
       lea      rdx, [rbp-0x140]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x170]
       lea      r8, [rbp-0x160]
       mov      rcx, rbx
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG06:                ;; offset=0x016E
       add      rsp, 440
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x017E
       xor      ecx, ecx
       test     r9, r9
       je       SHORT G_M000_IG08
       mov      ecx, 1
       test     r15d, r15d
       je       G_M000_IG15
       mov      gword ptr [rbp-0x128], r9
       xor      edx, edx
       mov      qword ptr [rbp-0x120], rdx
 
G_M000_IG08:                ;; offset=0x01A3
       cmp      ecx, r15d
       ja       SHORT G_M000_IG11
       lea      rdx, bword ptr [rbp-0x128]
       mov      r8d, ecx
       shl      r8, 4
       add      r8, rdx
       mov      edx, r15d
       sub      edx, ecx
       cmp      r14d, edx
       ja       SHORT G_M000_IG14
 
G_M000_IG09:                ;; offset=0x01C3
       mov      ecx, r14d
       shl      rcx, 4
       mov      r10, rcx
       cmp      r10, 0x4000
       ja       SHORT G_M000_IG13
 
G_M000_IG10:                ;; offset=0x01D6
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa62612aa8)], 0
       je       G_M000_IG05
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x01F3
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG12:                ;; offset=0x01FA
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG05
 
G_M000_IG13:                ;; offset=0x0204
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG05
 
G_M000_IG14:                ;; offset=0x0218
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG15:                ;; offset=0x021F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 549

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 4 inlinees with PGO data; 29 single block inlinees; 7 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 216
       lea      rbp, [rsp+0x110]
       xor      eax, eax
       mov      qword ptr [rbp-0xC8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xC0], ymm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x28], r9
       mov      rbx, rdx
       mov      rsi, r8
       mov      r14, bword ptr [rbp+0x38]
       mov      r12, bword ptr [rbp+0x40]
       mov      r15, bword ptr [rbp+0x48]
       mov      r13, bword ptr [rbp+0x50]
       mov      rdi, bword ptr [rbp+0x58]
 
G_M000_IG02:                ;; offset=0x0068
       mov      byte  ptr [r12], 0
       mov      rdx, 0x1EB29C012A0
       mov      rdx, gword ptr [rdx]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      r8d, r8d
       mov      qword ptr [r15+0x08], r8
 
G_M000_IG03:                ;; offset=0x0089
       mov      gword ptr [r13], r8
 
G_M000_IG04:                ;; offset=0x008D
       mov      qword ptr [rdi], r8
       mov      qword ptr [rdi+0x08], r8
       mov      qword ptr [rdi+0x10], r8
 
G_M000_IG05:                ;; offset=0x0098
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG06:                ;; offset=0x00A4
       mov      r8d, dword ptr [r14+0x08]
       mov      dword ptr [rsp+0x20], r8d
       lea      r8, [rbp-0xC8]
       movzx    rax, byte  ptr [rbp+0x30]
       mov      dword ptr [rbp-0xCC], eax
       mov      r9d, eax
       lea      rcx, [rbp-0x98]
       mov      rdx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:.ctor(Lokad.Lython.Runtime.PyExecutableFunction,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,int):this]
 
G_M000_IG07:                ;; offset=0x00D2
       vmovdqu  xmm0, xmmword ptr [rsi+0x08]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
       mov      rcx, qword ptr [rsi+0x18]
       mov      qword ptr [rbp-0xA0], rcx
 
G_M000_IG08:                ;; offset=0x00EA
       xor      ecx, ecx
       mov      dword ptr [rbp-0xB4], ecx
 
G_M000_IG09:                ;; offset=0x00F2
       lea      rcx, [rbp-0x98]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r8, r15
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Run(Lokad.Lython.LythonSourceSpan,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool:this]
       test     eax, eax
       jne      G_M000_IG19
       mov      rcx, bword ptr [rbp-0x50]
       mov      edx, dword ptr [rbp-0x48]
       mov      eax, dword ptr [rbp-0x5C]
       cmp      eax, edx
       ja       G_M000_IG20
       mov      r8d, eax
       shl      r8, 4
       add      rcx, r8
       sub      edx, eax
       add      rdx, rdx
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
       cmp      byte  ptr [rsi], 0
       jne      G_M000_IG18
 
G_M000_IG10:                ;; offset=0x0141
       mov      rdx, gword ptr [rbp+0x10]
       mov      r12, gword ptr [rdx+0x28]
       mov      rcx, gword ptr [rdx+0x40]
       mov      r8d, dword ptr [rcx+0xE8]
       mov      rcx, gword ptr [r12+0xA0]
       mov      rsi, gword ptr [rcx+0x88]
       mov      rcx, gword ptr [rdx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      r14d, dword ptr [rcx+0x08]
       cmp      r8d, r14d
       jge      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x0174
       mov      ecx, r8d
       mov      edx, r14d
       mov      r8, 0x20B508C6878
       call     [System.ArgumentOutOfRangeException:ThrowLess[int](int,int,System.String)]
       int3     
 
G_M000_IG12:                ;; offset=0x018B
       cmp      byte  ptr [rsi], sil
       mov      gword ptr [rsp+0x20], r12
       lea      rcx, bword ptr [rsi+0x50]
       mov      rdx, rsi
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.MemoryGovernor+WorkspaceCache:Rent(Lokad.Lython.Runtime.MemoryGovernor,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      gword ptr [rbp-0xA8], rsi
       mov      dword ptr [rbp-0xA0], r14d
       mov      dword ptr [rbp-0xB4], 1
       mov      esi, dword ptr [rbp-0x5C]
       cmp      esi, dword ptr [rbx+0x08]
       ja       G_M000_IG20
 
G_M000_IG13:                ;; offset=0x01CF
       mov      rdx, bword ptr [rbx]
       mov      rax, gword ptr [rbp-0xB0]
       test     rax, rax
       je       SHORT G_M000_IG14
       lea      rcx, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x01E7
       xor      rcx, rcx
       xor      eax, eax
 
G_M000_IG15:                ;; offset=0x01EB
       cmp      esi, eax
       ja       G_M000_IG23
 
G_M000_IG16:                ;; offset=0x01F3
       mov      r8d, esi
       shl      r8, 4
       cmp      r8, 0x4000
       ja       G_M000_IG22
 
G_M000_IG17:                ;; offset=0x0207
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa62612aa8)], 0
       jne      G_M000_IG21
 
G_M000_IG18:                ;; offset=0x0219
       mov      edx, dword ptr [rbp-0x5C]
       mov      dword ptr [rsp+0x20], edx
       mov      ebx, dword ptr [rbp-0xCC]
       mov      dword ptr [rsp+0x28], ebx
       mov      rdx, gword ptr [rbp-0x70]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0xB0]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateNativeContinuation(Lokad.Lython.Runtime.PyExecutableFunction,byref,Lokad.Lython.LythonSourceSpan,int,int,bool,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      rdx, rax
       mov      rcx, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, gword ptr [r13]
       lea      rcx, [rbp-0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TransferOwnership(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):this]
       mov      rdx, gword ptr [rbp-0xB0]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       lea      rcx, bword ptr [rdi+0x08]
       mov      rdx, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      eax, dword ptr [rbp-0xA0]
       mov      dword ptr [rdi+0x10], eax
       jmp      SHORT G_M000_IG24
 
G_M000_IG19:                ;; offset=0x0292
       cmp      dword ptr [rbp-0x64], 0
       setge    cl
       mov      byte  ptr [r12], cl
       jmp      SHORT G_M000_IG24
 
G_M000_IG20:                ;; offset=0x029F
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG21:                ;; offset=0x02A6
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG18
 
G_M000_IG22:                ;; offset=0x02B0
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG18
 
G_M000_IG23:                ;; offset=0x02BB
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG24:                ;; offset=0x02C2
       call     G_M000_IG33
       nop      
 
G_M000_IG25:                ;; offset=0x02C8
       add      rsp, 216
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x02DC
       sub      rsp, 56
 
G_M000_IG27:                ;; offset=0x02E0
       mov      rbx, rcx
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rsi, rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Name():System.String:this]
       mov      r8, rax
       mov      rdx, rsi
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyFunctionBinding:AnnotateException(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,Lokad.Lython.LythonSourceSpan)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG28:                ;; offset=0x0313
       sub      rsp, 56
 
G_M000_IG29:                ;; offset=0x0317
       cmp      dword ptr [rbp-0xB4], 0
       je       SHORT G_M000_IG31
       cmp      byte  ptr [rbp-0x56], 0
       jne      SHORT G_M000_IG31
       mov      r8, gword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rbp-0xA8]
       mov      rcx, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rcx+0x40]
       mov      r9d, dword ptr [rcx+0xE8]
       test     rdx, rdx
       je       SHORT G_M000_IG30
       lea      rcx, bword ptr [rdx+0x50]
       call     [Lokad.Lython.Runtime.MemoryGovernor+WorkspaceCache:Return(Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):this]
       jmp      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x0354
       mov      rcx, r8
       call     [System.Array:Clear(System.Array)]
 
G_M000_IG31:                ;; offset=0x035D
       nop      
 
G_M000_IG32:                ;; offset=0x035E
       add      rsp, 56
       ret      
 
G_M000_IG33:                ;; offset=0x0363
       sub      rsp, 56
 
G_M000_IG34:                ;; offset=0x0367
       lea      rcx, [rbp-0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Dispose():this]
       nop      
 
G_M000_IG35:                ;; offset=0x0375
       call     G_M000_IG28
       nop      
 
G_M000_IG36:                ;; offset=0x037B
       add      rsp, 56
       ret      
 
; Total bytes of code 896

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 168 single block inlinees; 46 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 224
       xor      eax, eax
       mov      qword ptr [rsp+0x38], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x40], ymm4
       vmovdqu  ymmword ptr [rsp+0x60], ymm4
       vmovdqu  ymmword ptr [rsp+0x80], ymm4
       vmovdqu  ymmword ptr [rsp+0xA0], ymm4
       vmovdqu  ymmword ptr [rsp+0xC0], ymm4
       mov      rbx, rcx
       mov      rsi, rdx
 
G_M000_IG02:                ;; offset=0x0049
       mov      rcx, 0x1EB29C012A0
       mov      rdx, gword ptr [rcx]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rsi+0x08], rcx
       mov      ecx, dword ptr [rbx+0x38]
       mov      rax, gword ptr [rbx+0x08]
       cmp      ecx, dword ptr [rax+0xEC]
       jge      G_M000_IG147
 
G_M000_IG03:                ;; offset=0x0077
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [rbx+0x38]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       shl      rax, 5
       lea      rdi, bword ptr [rcx+rax+0x10]
       mov      rcx, gword ptr [rbx+0x10]
       mov      rbp, gword ptr [rcx+0xA0]
       mov      r14, gword ptr [rdi]
       cmp      byte  ptr [rbp], bpl
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00B6
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG05:                ;; offset=0x00C2
       mov      ebp, dword ptr [rdi+0x1C]
       lea      ecx, [rbp-0x01]
       cmp      ecx, 76
       ja       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00CD
       mov      ecx, ecx
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*rcx]
       lea      rax, G_M000_IG02
       add      rdx, rax
       jmp      rdx
 
G_M000_IG07:                ;; offset=0x00E5
       xor      eax, eax
 
G_M000_IG08:                ;; offset=0x00E7
       add      rsp, 224
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG09:                ;; offset=0x00F9
       mov      rdx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rdx+0xEC]
       mov      rax, gword ptr [rdx+0x98]
       cmp      ecx, dword ptr [rax+0x08]
       jne      SHORT G_M000_IG07
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       G_M000_IG66
       mov      edx, dword ptr [rbx+0x3C]
       dec      edx
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG66
 
G_M000_IG10:                ;; offset=0x0133
       lea      r8, [rsp+0x78]
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerComparison(byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG17
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG11:                ;; offset=0x0150
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG12:                ;; offset=0x015B
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbp, rax
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG13:                ;; offset=0x018D
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG14:                ;; offset=0x0198
       mov      dword ptr [rsp+0x20], 1
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x0C]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r8, rax
       cmp      dword ptr [rdi+0x1C], 51
       jne      SHORT G_M000_IG15
       mov      ecx, dword ptr [rdi+0x14]
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x01D3
       mov      ecx, dword ptr [rdi+0x08]
       and      ecx, 0x7FFFFFFF
 
G_M000_IG16:                ;; offset=0x01DC
       mov      r9, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], r9
       lea      r9, [rsp+0x78]
       mov      qword ptr [rsp+0x28], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG07
 
G_M000_IG17:                ;; offset=0x0203
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG18
       not      edx
 
G_M000_IG18:                ;; offset=0x020C
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rcx, gword ptr [rbx+0x10]
       mov      rbp, gword ptr [rdi]
       mov      r14, gword ptr [rcx+0xA0]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG19
       mov      rcx, r14
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG19:                ;; offset=0x023F
       cmp      byte  ptr [rsp+0x78], 0
       jne      G_M000_IG145
       jmp      G_M000_IG66
 
G_M000_IG20:                ;; offset=0x024F
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG21:                ;; offset=0x0256
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG22:                ;; offset=0x0261
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbp, rax
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG07
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      r8, gword ptr [rdi]
       mov      rdx, gword ptr [rbx+0x10]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG66
 
G_M000_IG23:                ;; offset=0x02C9
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerOperation():bool:this]
       test     eax, eax
       jne      G_M000_IG145
 
G_M000_IG24:                ;; offset=0x02DA
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG25:                ;; offset=0x02DE
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG26:                ;; offset=0x02E9
       lea      rdx, [rsp+0xA8]
       mov      qword ptr [rsp+0x20], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rbx+0x38]
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateBuiltinArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):bool]
       test     eax, eax
       je       G_M000_IG07
 
G_M000_IG27:                ;; offset=0x031A
       vmovdqu  xmm0, xmmword ptr [rsp+0xA8]
       vmovdqu  xmmword ptr [rsp+0x38], xmm0
 
G_M000_IG28:                ;; offset=0x0329
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG29:                ;; offset=0x033F
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG30:                ;; offset=0x0346
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG31:                ;; offset=0x0351
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbp, rax
       mov      rcx, gword ptr [rbx+0x08]
       mov      r14, bword ptr [rbx+0x48]
       mov      r15d, dword ptr [rbx+0x50]
       mov      r13d, dword ptr [rdi+0x0C]
       mov      r8, gword ptr [rbx+0x10]
       xor      r9d, r9d
       mov      gword ptr [rsp+0x58], r9
 
G_M000_IG32:                ;; offset=0x039B
       mov      gword ptr [rsp+0x60], r9
       test     r13d, r13d
       jge      SHORT G_M000_IG35
       mov      r15d, r13d
       not      r15d
       mov      r13, gword ptr [rcx+0x30]
       mov      edx, r15d
       sub      edx, dword ptr [r13+0x08]
       js       SHORT G_M000_IG34
       mov      r13, gword ptr [rcx+0x38]
       cmp      dword ptr [r13+0x08], edx
       jle      SHORT G_M000_IG33
       lea      r9, [rsp+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       lea      rdx, [rsp+0x98]
       mov      rcx, gword ptr [rsp+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG36
 
G_M000_IG33:                ;; offset=0x03E2
       sub      edx, dword ptr [r13+0x08]
       lea      rcx, [rsp+0x58]
       lea      r8, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:TryReadInteger(int,byref):bool:this]
       jmp      SHORT G_M000_IG36
 
G_M000_IG34:                ;; offset=0x03FB
       cmp      r15d, dword ptr [r13+0x08]
       jae      G_M000_IG225
       mov      ecx, r15d
       mov      rcx, gword ptr [r13+8*rcx+0x10]
       lea      rdx, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x041D
       cmp      r13d, r15d
       jae      G_M000_IG225
       mov      ecx, r13d
       shl      rcx, 4
       add      rcx, r14
       lea      rdx, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
 
G_M000_IG36:                ;; offset=0x043E
       xor      r9, r9
       mov      gword ptr [rsp+0x60], r9
       test     eax, eax
       je       SHORT G_M000_IG37
       mov      rdx, qword ptr [rsp+0x98]
       lea      r9, [rsp+0x88]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIndexing:TryReadSequenceIndex(System.Object,long,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG50
 
G_M000_IG37:                ;; offset=0x0477
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG38:                ;; offset=0x047B
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG39:                ;; offset=0x0486
       mov      dword ptr [rsp+0x20], 1
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x0C]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r14, rax
       test     rbp, rbp
       je       G_M000_IG07
 
G_M000_IG40:                ;; offset=0x04BF
       mov      rcx, 0x7FFA02BD4B10
       cmp      qword ptr [rbp], rcx
       jne      G_M000_IG07
 
G_M000_IG41:                ;; offset=0x04D3
       cmp      gword ptr [rbp+0x28], 0
       jne      SHORT G_M000_IG42
       mov      rcx, gword ptr [rbp+0x08]
       mov      r11, 0x7FFA02622FA8
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       jne      G_M000_IG07
       jmp      SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x04F5
       cmp      dword ptr [rbp+0x50], 0
       jne      G_M000_IG07
 
G_M000_IG43:                ;; offset=0x04FF
       test     r14, r14
       je       G_M000_IG07
 
G_M000_IG44:                ;; offset=0x0508
       mov      rcx, 0x7FFA02B2DAA0
       cmp      qword ptr [r14], rcx
       jne      G_M000_IG07
 
G_M000_IG45:                ;; offset=0x051B
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       test     eax, eax
       jl       SHORT G_M000_IG46
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG46
       mov      rcx, gword ptr [rbx]
       mov      rdx, gword ptr [rdi]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:GetLookupCaches(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntime+ExecutableLookupCache[]:this]
       mov      r15, rax
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       cmp      eax, dword ptr [r15+0x08]
       jae      G_M000_IG225
       mov      r8d, eax
       lea      r8, [r8+2*r8]
       lea      r8, bword ptr [r15+8*r8+0x10]
       mov      r9, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], r9
       lea      r9, [rsp+0x80]
       mov      qword ptr [rsp+0x28], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      rdx, r14
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyDict:TryReadRecordValue(Lokad.Lython.Runtime.Text.PyString,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG49
 
G_M000_IG46:                ;; offset=0x0588
       cmp      gword ptr [rbp+0x28], 0
       jne      SHORT G_M000_IG47
       mov      rcx, gword ptr [rbp+0x08]
       mov      r11, 0x7FFA02622FB0
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       jne      G_M000_IG07
       jmp      SHORT G_M000_IG48
 
G_M000_IG47:                ;; offset=0x05AA
       cmp      dword ptr [rbp+0x50], 0
       jne      G_M000_IG07
 
G_M000_IG48:                ;; offset=0x05B4
       mov      r8, gword ptr [rdi]
       mov      r9, gword ptr [rbx+0x10]
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rsp+0x38], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG49:                ;; offset=0x05EA
       mov      r8, gword ptr [rsp+0x80]
       mov      gword ptr [rsp+0x38], r8
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG50:                ;; offset=0x0615
       vmovdqu  xmm0, xmmword ptr [rsp+0x88]
       vmovdqu  xmmword ptr [rsp+0x38], xmm0
 
G_M000_IG51:                ;; offset=0x0624
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG52:                ;; offset=0x063A
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG53:                ;; offset=0x0653
       lea      rcx, bword ptr [rbx+0x48]
       mov      eax, dword ptr [rdi+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       shl      rax, 4
       add      rax, bword ptr [rcx]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FFA02CE8560
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rcx, rax
       test     rcx, rcx
       je       SHORT G_M000_IG56
 
G_M000_IG54:                ;; offset=0x068E
       mov      rdx, 0x7FFA02DA6260
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG56
 
G_M000_IG55:                ;; offset=0x069D
       lea      rdx, [rsp+0x68]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG62
 
G_M000_IG56:                ;; offset=0x06AA
       test     rcx, rcx
       je       SHORT G_M000_IG59
 
G_M000_IG57:                ;; offset=0x06AF
       mov      rdx, 0x7FFA02DA7AF8
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x06BE
       lea      rdx, [rsp+0x68]
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG62
 
G_M000_IG59:                ;; offset=0x06CB
       mov      rbp, rcx
       test     rbp, rbp
       je       SHORT G_M000_IG61
 
G_M000_IG60:                ;; offset=0x06D3
       mov      rax, 0x7FFA02CE80C8
       cmp      qword ptr [rbp], rax
       jne      G_M000_IG221
 
G_M000_IG61:                ;; offset=0x06E7
       cmp      byte  ptr [rbp], bpl
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:CheckExecution():this]
       lea      rdx, [rsp+0x68]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextCore():Lokad.Lython.Runtime.PyIterationResult:this]
 
G_M000_IG62:                ;; offset=0x0702
       cmp      gword ptr [rsp+0x68], 0
       je       SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x070A
       vmovdqu  xmm0, xmmword ptr [rsp+0x68]
       vmovdqu  xmmword ptr [rsp+0x38], xmm0
 
G_M000_IG64:                ;; offset=0x0716
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG65:                ;; offset=0x072C
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG66:                ;; offset=0x0738
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [rbx+0x38], eax
       jmp      G_M000_IG146
 
G_M000_IG67:                ;; offset=0x0749
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG68:                ;; offset=0x0750
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG69:                ;; offset=0x075B
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbp, rax
       test     rbp, rbp
       je       G_M000_IG74
 
G_M000_IG70:                ;; offset=0x0792
       mov      r8, 0x7FFA02DA6260
       cmp      qword ptr [rbp], r8
       jne      SHORT G_M000_IG72
 
G_M000_IG71:                ;; offset=0x07A2
       mov      gword ptr [rsp+0x38], rbp
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG72:                ;; offset=0x07C5
       mov      rcx, 0x7FFA02D06A38
       cmp      qword ptr [rbp], rcx
       jne      SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x07D5
       mov      rcx, 0x7FFA02DA7AF8
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rcx, r14
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:.ctor(Lokad.Lython.Runtime.PyRange):this]
       mov      gword ptr [rsp+0x38], r14
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG74:                ;; offset=0x0816
       test     rbp, rbp
       je       SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x081B
       mov      rdx, 0x7FFA02CEE820
       cmp      qword ptr [rbp], rdx
       je       SHORT G_M000_IG78
 
G_M000_IG76:                ;; offset=0x082B
       mov      rdx, rbp
       mov      rcx, 0x7FFA02C38AC8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG78
       test     rbp, rbp
       je       G_M000_IG07
 
G_M000_IG77:                ;; offset=0x084B
       mov      r8, 0x7FFA02BF3E60
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG78
       mov      r8, 0x7FFA02B2DAA0
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG78
       mov      r8, 0x7FFA02BD4B10
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG78
       mov      r8, 0x7FFA02CFDEF0
       cmp      qword ptr [rbp], r8
       jne      G_M000_IG07
 
G_M000_IG78:                ;; offset=0x088F
       mov      r8, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rdi]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      gword ptr [rsp+0x38], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG79:                ;; offset=0x08C2
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ConstructContainer(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG80:                ;; offset=0x08DB
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG160
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       jne      SHORT G_M000_IG81
       mov      rcx, 0x1EB29C015F0
       mov      rbp, gword ptr [rcx]
       jmp      SHORT G_M000_IG82
 
G_M000_IG81:                ;; offset=0x090B
       lea      rbp, bword ptr [rbx+0x48]
       mov      r14d, dword ptr [rdi+0x10]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      ecx, r14d
       mov      edx, eax
       add      rcx, rdx
       mov      edx, dword ptr [rbp+0x08]
       cmp      rcx, rdx
       ja       G_M000_IG224
       mov      ecx, r14d
       shl      rcx, 4
       add      rcx, bword ptr [rbp]
       mov      bword ptr [rsp+0x48], rcx
       mov      dword ptr [rsp+0x50], eax
       lea      rcx, [rsp+0x48]
       mov      rdx, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.PyTuple:FromSlots(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rbp, rax
 
G_M000_IG82:                ;; offset=0x0959
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rsp+0x38], rbp
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG83:                ;; offset=0x0988
       lea      rbp, bword ptr [rbx+0x48]
       mov      r14d, dword ptr [rdi+0x10]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      ecx, r14d
       mov      edx, eax
       add      rcx, rdx
       mov      edx, dword ptr [rbp+0x08]
       cmp      rcx, rdx
       ja       G_M000_IG224
       mov      ecx, r14d
       shl      rcx, 4
       add      rcx, bword ptr [rbp]
       mov      bword ptr [rsp+0x48], rcx
       mov      dword ptr [rsp+0x50], eax
       lea      rcx, [rsp+0x48]
       mov      rdx, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateSlotList(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      rbp, rax
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rsp+0x38], rbp
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG84:                ;; offset=0x0A05
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG85:                ;; offset=0x0A0C
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG86:                ;; offset=0x0A17
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG87
       not      edx
 
G_M000_IG87:                ;; offset=0x0A4B
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG145
 
G_M000_IG88:                ;; offset=0x0A59
       mov      ecx, ebp
       cmp      ecx, 51
       ja       SHORT G_M000_IG93
 
G_M000_IG89:                ;; offset=0x0A60
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG93
 
G_M000_IG90:                ;; offset=0x0A70
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG91
       mov      r14d, ebp
       not      r14d
       jmp      SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x0A7F
       mov      r14d, ebp
 
G_M000_IG92:                ;; offset=0x0A82
       jmp      SHORT G_M000_IG94
 
G_M000_IG93:                ;; offset=0x0A84
       mov      r14d, dword ptr [rdi+0x14]
 
G_M000_IG94:                ;; offset=0x0A88
       inc      r14d
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG95
       mov      r15d, ebp
       not      r15d
       jmp      SHORT G_M000_IG96
 
G_M000_IG95:                ;; offset=0x0A9A
       mov      r15d, ebp
 
G_M000_IG96:                ;; offset=0x0A9D
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG97:                ;; offset=0x0AA4
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG98:                ;; offset=0x0AAF
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rdi, rax
       cmp      r15d, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG99
       mov      rcx, rbx
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG99:                ;; offset=0x0AEF
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       mov      ebp, r14d
       shl      rbp, 4
       add      rbp, bword ptr [rcx]
       mov      rcx, rbp
       mov      rdx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      edx, edx
       mov      qword ptr [rbp+0x08], rdx
       mov      dword ptr [rbx+0x3C], r15d
       jmp      G_M000_IG145
 
G_M000_IG100:                ;; offset=0x0B21
       lea      rcx, bword ptr [rbx+0x58]
       mov      edx, ebp
       cmp      edx, 3
       je       SHORT G_M000_IG101
       cmp      edx, 26
       jne      G_M000_IG223
 
G_M000_IG101:                ;; offset=0x0B35
       mov      edx, dword ptr [rdi+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:GetCell(int):Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:this]
       mov      rbp, rax
       test     rbp, rbp
       je       G_M000_IG07
       mov      rcx, gword ptr [rbp+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG102
       cmp      gword ptr [rbp+0x18], 0
       je       G_M000_IG07
       cmp      gword ptr [rcx+0x88], 0
       jne      G_M000_IG07
 
G_M000_IG102:                ;; offset=0x0B6C
       mov      r8d, dword ptr [rdi+0x10]
       test     r8d, r8d
       jl       SHORT G_M000_IG106
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       mov      edx, r8d
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       mov      r14, gword ptr [rdx]
       mov      r15, qword ptr [rdx+0x08]
       test     r14, r14
       jne      SHORT G_M000_IG105
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG103:                ;; offset=0x0B9D
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG104:                ;; offset=0x0BA8
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
 
G_M000_IG105:                ;; offset=0x0BCF
       jmp      SHORT G_M000_IG109
 
G_M000_IG106:                ;; offset=0x0BD1
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG107:                ;; offset=0x0BD5
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG108:                ;; offset=0x0BE0
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r14, rax
       xor      r15d, r15d
 
G_M000_IG109:                ;; offset=0x0C0D
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x10]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       mov      rcx, bword ptr [rcx]
       shl      rdx, 4
       xor      eax, eax
       mov      qword ptr [rcx+rdx], rax
       mov      qword ptr [rcx+rdx+0x08], rax
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG110
       not      edx
 
G_M000_IG110:                ;; offset=0x0C38
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rsp+0x38], r14
       mov      qword ptr [rsp+0x40], r15
       lea      rdx, [rsp+0x38]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:StoreSlot(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG111:                ;; offset=0x0C5E
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StoreLocal(byref):this]
       jmp      G_M000_IG145
 
G_M000_IG112:                ;; offset=0x0C6F
       mov      r8, 0x7FFA02CEDDB0
       cmp      qword ptr [rbp], r8
       jne      G_M000_IG166
 
G_M000_IG113:                ;; offset=0x0C83
       lea      r8, [rsp+0xA0]
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.PyAttributeLookup:TryResolveInstanceFunctionForCall(Lokad.Lython.Runtime.PyInstance,System.String,byref):bool]
       test     eax, eax
       je       G_M000_IG166
       mov      r15, gword ptr [rsp+0xA0]
 
G_M000_IG114:                ;; offset=0x0CA7
       test     r15, r15
       je       G_M000_IG07
       mov      ecx, dword ptr [rdi+0x1C]
       mov      edx, ecx
       cmp      edx, 51
       ja       SHORT G_M000_IG118
 
G_M000_IG115:                ;; offset=0x0CBA
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG118
 
G_M000_IG116:                ;; offset=0x0CCA
       mov      r14d, dword ptr [rdi+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG117
       not      r14d
 
G_M000_IG117:                ;; offset=0x0CD6
       jmp      SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x0CD8
       mov      r14d, dword ptr [rdi+0x14]
 
G_M000_IG119:                ;; offset=0x0CDC
       cmp      ecx, 51
       ja       SHORT G_M000_IG124
 
G_M000_IG120:                ;; offset=0x0CE1
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG124
 
G_M000_IG121:                ;; offset=0x0CF1
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG122
       mov      r13d, ecx
       not      r13d
       jmp      SHORT G_M000_IG123
 
G_M000_IG122:                ;; offset=0x0D00
       mov      r13d, ecx
 
G_M000_IG123:                ;; offset=0x0D03
       jmp      SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x0D05
       mov      r13d, dword ptr [rdi+0x14]
 
G_M000_IG125:                ;; offset=0x0D09
       inc      r13d
       cmp      r13d, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG126
       mov      rcx, rbx
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG126:                ;; offset=0x0D1E
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       mov      r14d, r14d
       shl      r14, 4
       add      r14, bword ptr [rcx]
       mov      rcx, r14
       mov      rdx, rbp
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
       mov      dword ptr [rbx+0x3C], r13d
       mov      ecx, dword ptr [rdi+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG130
 
G_M000_IG127:                ;; offset=0x0D53
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG130
 
G_M000_IG128:                ;; offset=0x0D63
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG129
       not      ebp
 
G_M000_IG129:                ;; offset=0x0D6C
       jmp      SHORT G_M000_IG131
 
G_M000_IG130:                ;; offset=0x0D6E
       mov      ebp, dword ptr [rdi+0x14]
 
G_M000_IG131:                ;; offset=0x0D71
       inc      ebp
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG132
       mov      edi, ecx
       not      edi
       jmp      SHORT G_M000_IG133
 
G_M000_IG132:                ;; offset=0x0D80
       mov      edi, ecx
 
G_M000_IG133:                ;; offset=0x0D82
       cmp      edi, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG134
       mov      rcx, rbx
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG134:                ;; offset=0x0D92
       lea      rcx, bword ptr [rbx+0x48]
       cmp      ebp, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       mov      ebp, ebp
       shl      rbp, 4
       add      rbp, bword ptr [rcx]
       mov      rcx, rbp
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbp+0x08], rcx
       mov      dword ptr [rbx+0x3C], edi
       jmp      G_M000_IG145
 
G_M000_IG135:                ;; offset=0x0DC1
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StoreSubscript(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG136:                ;; offset=0x0DDA
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ApplyDefinition(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG137:                ;; offset=0x0DF3
       mov      rdx, gword ptr [rbx+0x08]
       mov      rbp, rdx
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rbp
       mov      r8, gword ptr [rdi]
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rsp+0x38], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG138:                ;; offset=0x0E38
       mov      rcx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x20], rcx
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      r8d, dword ptr [rbx+0x38]
       mov      r9d, dword ptr [rbx+0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      SHORT G_M000_IG140
       lea      rcx, bword ptr [rbx+0x58]
       mov      edx, dword ptr [rdi+0x1C]
       cmp      edx, 3
       je       SHORT G_M000_IG139
       cmp      edx, 26
       jne      G_M000_IG223
 
G_M000_IG139:                ;; offset=0x0E73
       mov      edx, dword ptr [rdi+0x08]
       lea      r8, [rsp+0xC8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:TryRead(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG07
       cmp      gword ptr [rsp+0xC8], 0
       je       G_M000_IG07
       mov      r8, gword ptr [rsp+0xC8]
       mov      gword ptr [rsp+0x38], r8
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG140:                ;; offset=0x0EC6
       add      dword ptr [rbx+0x38], 2
       jmp      G_M000_IG145
 
G_M000_IG141:                ;; offset=0x0ECF
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      r8d, eax
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG142:                ;; offset=0x0EDF
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG143:                ;; offset=0x0EEA
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      gword ptr [rsp+0x38], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      SHORT G_M000_IG145
 
G_M000_IG144:                ;; offset=0x0F31
       mov      rdx, gword ptr [rbx+0x08]
       mov      rbp, gword ptr [rdx+0x30]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbp+0x08]
       jae      G_M000_IG225
       mov      ecx, eax
       mov      rcx, gword ptr [rbp+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rsp+0x38], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG145:                ;; offset=0x0F76
       inc      dword ptr [rbx+0x38]
 
G_M000_IG146:                ;; offset=0x0F79
       mov      ecx, dword ptr [rbx+0x38]
       mov      rax, gword ptr [rbx+0x08]
       cmp      ecx, dword ptr [rax+0xEC]
       jl       G_M000_IG03
 
G_M000_IG147:                ;; offset=0x0F8C
       mov      eax, dword ptr [rbx+0x38]
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       cmp      eax, dword ptr [rcx+0x08]
       setge    al
       movzx    rax, al
 
G_M000_IG148:                ;; offset=0x0FA3
       add      rsp, 224
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG149:                ;; offset=0x0FB5
       mov      rdx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rdx+0xEC]
       mov      rdx, gword ptr [rdx+0x98]
       cmp      ecx, dword ptr [rdx+0x08]
       jne      G_M000_IG07
       jmp      G_M000_IG159
 
G_M000_IG150:                ;; offset=0x0FD4
       mov      rdx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rdx+0xEC]
       mov      r9, gword ptr [rdx+0x98]
       cmp      ecx, dword ptr [r9+0x08]
       jne      G_M000_IG07
       mov      r8d, dword ptr [rdi+0x10]
       test     r8d, r8d
       jl       SHORT G_M000_IG154
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       mov      r9d, r8d
       shl      r9, 4
       add      r9, bword ptr [rcx]
       mov      rbp, gword ptr [r9]
       mov      r14, qword ptr [r9+0x08]
       test     rbp, rbp
       jne      SHORT G_M000_IG153
       mov      rcx, rdx
 
G_M000_IG151:                ;; offset=0x101F
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG152:                ;; offset=0x102A
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
 
G_M000_IG153:                ;; offset=0x1051
       jmp      SHORT G_M000_IG157
 
G_M000_IG154:                ;; offset=0x1053
       mov      rcx, rdx
 
G_M000_IG155:                ;; offset=0x1056
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG156:                ;; offset=0x1061
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbp, rax
       xor      r14d, r14d
 
G_M000_IG157:                ;; offset=0x108E
       mov      rcx, rsi
       mov      rdx, rbp
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [rsi+0x08], r14
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      edx, dword ptr [rcx+0xD8]
       jl       SHORT G_M000_IG159
       lea      rcx, bword ptr [rbx+0x48]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       xor      rcx, rcx
       mov      gword ptr [rdx], rcx
 
G_M000_IG158:                ;; offset=0x10C5
       mov      qword ptr [rdx+0x08], rcx
 
G_M000_IG159:                ;; offset=0x10C9
       mov      rdx, gword ptr [rbx+0x08]
       mov      edx, dword ptr [rdx+0xD8]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG160:                ;; offset=0x10DC
       mov      eax, 1
 
G_M000_IG161:                ;; offset=0x10E1
       add      rsp, 224
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG162:                ;; offset=0x10F3
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryExecuteCasedSplitMember(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
 
G_M000_IG163:                ;; offset=0x1107
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG164:                ;; offset=0x110B
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG165:                ;; offset=0x1116
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbp, rax
       mov      rcx, gword ptr [rbx+0x08]
       mov      r14, gword ptr [rcx+0x38]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG225
       mov      r8d, eax
       mov      r14, gword ptr [r14+8*r8+0x10]
       test     rbp, rbp
       jne      G_M000_IG112
 
G_M000_IG166:                ;; offset=0x1170
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveBuiltinReceiverMethod(System.Object,System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      r15, rax
       jmp      G_M000_IG114
 
G_M000_IG167:                ;; offset=0x1184
       mov      rcx, gword ptr [rbx+0x08]
       mov      edx, dword ptr [rcx+0xEC]
       mov      r9, gword ptr [rcx+0x98]
       cmp      edx, dword ptr [r9+0x08]
       jne      G_M000_IG141
 
G_M000_IG168:                ;; offset=0x119F
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG169:                ;; offset=0x11AA
       mov      edx, dword ptr [rbx+0x30]
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x3C]
       lea      r8, bword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryPrepareFixedTupleReturn(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       G_M000_IG141
 
G_M000_IG170:                ;; offset=0x11D5
       mov      ecx, dword ptr [rbx+0x3C]
       mov      dword ptr [rbx+0x34], ecx
       mov      ecx, dword ptr [rbx+0x30]
       add      dword ptr [rbx+0x3C], ecx
       jmp      G_M000_IG160
 
G_M000_IG171:                ;; offset=0x11E6
       mov      ecx, dword ptr [rdi+0x0C]
       add      ecx, 2
       mov      rdx, gword ptr [rbx+0x08]
       cmp      ecx, dword ptr [rdx+0xEC]
       jge      SHORT G_M000_IG174
       mov      rcx, gword ptr [rbx+0x10]
       mov      rcx, gword ptr [rcx+0xA0]
       cmp      qword ptr [rcx+0x158], 8
       jge      SHORT G_M000_IG174
       mov      rcx, rdx
 
G_M000_IG172:                ;; offset=0x1210
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG173:                ;; offset=0x121B
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0xD0]
       mov      qword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x3C]
       lea      r8, bword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateIntegerCallUpdate(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG183
 
G_M000_IG174:                ;; offset=0x1248
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG175
       mov      r8d, edx
       not      r8d
       jmp      SHORT G_M000_IG176
 
G_M000_IG175:                ;; offset=0x1257
       mov      r8d, edx
 
G_M000_IG176:                ;; offset=0x125A
       mov      ecx, dword ptr [rdi+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG180
 
G_M000_IG177:                ;; offset=0x1262
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG180
 
G_M000_IG178:                ;; offset=0x1272
       test     edx, edx
       jge      SHORT G_M000_IG179
       not      edx
 
G_M000_IG179:                ;; offset=0x1278
       jmp      SHORT G_M000_IG181
 
G_M000_IG180:                ;; offset=0x127A
       mov      edx, dword ptr [rdi+0x14]
 
G_M000_IG181:                ;; offset=0x127D
       cmp      r8d, edx
       jne      G_M000_IG141
 
G_M000_IG182:                ;; offset=0x1286
       lea      rbp, bword ptr [rbx+0x48]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbp+0x08]
       jae      G_M000_IG225
       mov      rcx, bword ptr [rbp]
       mov      eax, eax
       shl      rax, 4
       cmp      gword ptr [rcx+rax], 0
       jne      G_M000_IG145
       jmp      G_M000_IG222
 
G_M000_IG183:                ;; offset=0x12B6
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdx, gword ptr [rdx+0x98]
       mov      r8d, dword ptr [rbx+0x38]
       cmp      r8d, dword ptr [rdx+0x08]
       jae      G_M000_IG225
       shl      r8, 5
       lea      rdx, bword ptr [rdx+r8+0x10]
 
G_M000_IG184:                ;; offset=0x12D8
       vmovdqu  xmm0, xmmword ptr [rsp+0xD0]
       vmovdqu  xmmword ptr [rsp+0x38], xmm0
 
G_M000_IG185:                ;; offset=0x12E7
       lea      r8, [rsp+0x38]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG186:                ;; offset=0x12FA
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x10]
       mov      r8d, dword ptr [rdi+0x08]
       mov      eax, edx
       mov      r10d, r8d
       add      rax, r10
       mov      r10d, dword ptr [rcx+0x08]
       cmp      rax, r10
       ja       G_M000_IG224
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       mov      bword ptr [rsp+0x48], rdx
       mov      dword ptr [rsp+0x50], r8d
       lea      rcx, [rsp+0x48]
       mov      rdx, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rdx+0xA0]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReverseAssignmentValues(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.ExecutionState,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG145
 
G_M000_IG187:                ;; offset=0x1349
       lea      rcx, bword ptr [rbx+0x48]
       cmp      ebp, 51
       ja       SHORT G_M000_IG191
 
G_M000_IG188:                ;; offset=0x1352
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rbp
       jb       SHORT G_M000_IG191
 
G_M000_IG189:                ;; offset=0x1362
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG190
       not      ebp
 
G_M000_IG190:                ;; offset=0x136B
       jmp      SHORT G_M000_IG192
 
G_M000_IG191:                ;; offset=0x136D
       mov      ebp, dword ptr [rdi+0x14]
 
G_M000_IG192:                ;; offset=0x1370
       cmp      ebp, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       mov      rcx, bword ptr [rcx]
       mov      eax, ebp
       shl      rax, 4
 
G_M000_IG193:                ;; offset=0x1382
       vmovdqu  xmm0, xmmword ptr [rcx+rax]
       vmovdqu  xmmword ptr [rsp+0xB8], xmm0
 
G_M000_IG194:                ;; offset=0x1390
       cmp      gword ptr [rsp+0xB8], 0
       jne      SHORT G_M000_IG195
       lea      rcx, [rsp+0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FFA02CE8560
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
 
G_M000_IG195:                ;; offset=0x13BC
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG199
 
G_M000_IG196:                ;; offset=0x13C8
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG199
 
G_M000_IG197:                ;; offset=0x13D8
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG198
       not      edx
 
G_M000_IG198:                ;; offset=0x13E1
       jmp      SHORT G_M000_IG200
 
G_M000_IG199:                ;; offset=0x13E3
       mov      edx, dword ptr [rdi+0x14]
 
G_M000_IG200:                ;; offset=0x13E6
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG225
       mov      rcx, bword ptr [rcx]
       mov      edx, edx
       shl      rdx, 4
       xor      eax, eax
       mov      qword ptr [rcx+rdx], rax
       mov      qword ptr [rcx+rdx+0x08], rax
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG201
       not      edx
 
G_M000_IG201:                ;; offset=0x140C
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rcx, bword ptr [rbx+0x48]
       mov      r8d, dword ptr [rbx+0x50]
       mov      rdx, gword ptr [rsp+0xB8]
       mov      r9, qword ptr [rsp+0xC0]
       mov      rax, gword ptr [rbx+0x10]
       mov      rax, gword ptr [rax+0xA0]
       mov      r10d, dword ptr [rdi+0x10]
       cmp      r10d, r8d
       jae      G_M000_IG225
       mov      r8d, r10d
       shl      r8, 4
       add      rcx, r8
       mov      gword ptr [rsp+0x38], rdx
       mov      qword ptr [rsp+0x40], r9
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      r9, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG145
 
G_M000_IG202:                ;; offset=0x146F
       mov      rdx, gword ptr [rbx+0x08]
       mov      rbp, gword ptr [rdx+0x30]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbp+0x08]
       jae      G_M000_IG225
       mov      edx, eax
       mov      rdx, gword ptr [rbp+8*rdx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG204
 
G_M000_IG203:                ;; offset=0x1498
       mov      rax, 0x7FFA02B2ABA8
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG220
 
G_M000_IG204:                ;; offset=0x14AB
       lea      rdx, bword ptr [rbx+0x48]
       mov      r8d, dword ptr [rdi+0x1C]
       mov      r9d, r8d
       cmp      r9d, 51
       ja       SHORT G_M000_IG208
 
G_M000_IG205:                ;; offset=0x14BC
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, r9
       jb       SHORT G_M000_IG208
 
G_M000_IG206:                ;; offset=0x14CC
       mov      r9d, dword ptr [rdi+0x18]
       test     r9d, r9d
       jge      SHORT G_M000_IG207
       not      r9d
 
G_M000_IG207:                ;; offset=0x14D8
       jmp      SHORT G_M000_IG209
 
G_M000_IG208:                ;; offset=0x14DA
       mov      r9d, dword ptr [rdi+0x14]
 
G_M000_IG209:                ;; offset=0x14DE
       mov      eax, dword ptr [rdi+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG210
       mov      r10d, eax
       not      r10d
       jmp      SHORT G_M000_IG211
 
G_M000_IG210:                ;; offset=0x14ED
       mov      r10d, eax
 
G_M000_IG211:                ;; offset=0x14F0
       cmp      r8d, 51
       ja       SHORT G_M000_IG216
 
G_M000_IG212:                ;; offset=0x14F6
       mov      r11, 0x7FFFFFFFFF9FF
       bt       r11, r8
       jb       SHORT G_M000_IG216
 
G_M000_IG213:                ;; offset=0x1506
       test     eax, eax
       jge      SHORT G_M000_IG214
       mov      r8d, eax
       not      r8d
       jmp      SHORT G_M000_IG215
 
G_M000_IG214:                ;; offset=0x1512
       mov      r8d, eax
 
G_M000_IG215:                ;; offset=0x1515
       jmp      SHORT G_M000_IG217
 
G_M000_IG216:                ;; offset=0x1517
       mov      r8d, dword ptr [rdi+0x14]
 
G_M000_IG217:                ;; offset=0x151B
       sub      r10d, r8d
       mov      r8d, r9d
       mov      eax, r10d
       add      r8, rax
       mov      eax, dword ptr [rdx+0x08]
       cmp      r8, rax
       ja       G_M000_IG224
       mov      r8d, r9d
       shl      r8, 4
       add      r8, bword ptr [rdx]
       mov      bword ptr [rsp+0x48], r8
       mov      dword ptr [rsp+0x50], r10d
       mov      rdx, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x48]
       cmp      dword ptr [rdi+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG218
       not      ecx
 
G_M000_IG218:                ;; offset=0x1573
       mov      dword ptr [rbx+0x3C], ecx
       jmp      G_M000_IG145
 
G_M000_IG219:                ;; offset=0x157B
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG220:                ;; offset=0x1594
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG221:                ;; offset=0x159D
       mov      rdx, rcx
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG222:                ;; offset=0x15A9
       mov      rcx, gword ptr [rbx+0x08]
       mov      rbx, gword ptr [rcx+0x68]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r11, 0x7FFA02622FA0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG223:                ;; offset=0x15E1
       mov      rcx, rdi
       mov      rdx, 0x20B508CC1B8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG224:                ;; offset=0x15FD
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG225:                ;; offset=0x1604
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000EE8h ; case G_M000_IG144
       	dd	00000E86h ; case G_M000_IG141
       	dd	00000DEFh ; case G_M000_IG138
       	dd	00000DAAh ; case G_M000_IG137
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000D91h ; case G_M000_IG136
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000D78h ; case G_M000_IG135
       	dd	00000D78h ; case G_M000_IG135
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	000010BEh ; case G_M000_IG163
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000C15h ; case G_M000_IG111
       	dd	00000AD8h ; case G_M000_IG100
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000A10h ; case G_M000_IG88
       	dd	000009BCh ; case G_M000_IG84
       	dd	0000093Fh ; case G_M000_IG83
       	dd	00000892h ; case G_M000_IG80
       	dd	00000879h ; case G_M000_IG79
       	dd	00000879h ; case G_M000_IG79
       	dd	00000879h ; case G_M000_IG79
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000700h ; case G_M000_IG67
       	dd	0000060Ah ; case G_M000_IG53
       	dd	000005F1h ; case G_M000_IG52
       	dd	000002F6h ; case G_M000_IG29
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000280h ; case G_M000_IG23
       	dd	00000280h ; case G_M000_IG23
       	dd	00000291h ; case G_M000_IG24
       	dd	000006EFh ; case G_M000_IG66
       	dd	00000206h ; case G_M000_IG20
       	dd	000000EAh ; case G_M000_IG10
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000F8Bh ; case G_M000_IG150
       	dd	00000F6Ch ; case G_M000_IG149
       	dd	00000F6Ch ; case G_M000_IG149
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	000000B0h ; case G_M000_IG09
       	dd	00001532h ; case G_M000_IG219
       	dd	00001532h ; case G_M000_IG219
       	dd	00001532h ; case G_M000_IG219
       	dd	00001532h ; case G_M000_IG219
       	dd	00001532h ; case G_M000_IG219
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000060Ah ; case G_M000_IG53
       	dd	00001426h ; case G_M000_IG202
       	dd	00001300h ; case G_M000_IG187
       	dd	0000123Dh ; case G_M000_IG182
       	dd	000012B1h ; case G_M000_IG186
       	dd	0000119Dh ; case G_M000_IG171
       	dd	0000113Bh ; case G_M000_IG167
       	dd	000010AAh ; case G_M000_IG162
       	dd	00000E86h ; case G_M000_IG141

; Total bytes of code 5642

