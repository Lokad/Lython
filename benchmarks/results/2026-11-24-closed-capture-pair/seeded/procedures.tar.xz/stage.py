from pathlib import Path
import hashlib, json, shutil, tarfile

lab=Path(__file__).resolve().parent
parent=lab.with_name('closed-capture-pair-20261124')
comparison=lab/'comparison'
quiet=comparison/'quiet';quiet.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda path,value:path.write_text(value,encoding='utf-8',newline='\n')
meta=read(comparison/'identity.json')
assert meta['candidate'].startswith('d6437c26f') and meta['sourceRevision'].startswith('ad88474bb')
ref=read(parent/'comparison/identity.json')
old=read(parent/'comparison/quiet/terminal-status.json')['receipt']
assert old['complete'] and old['archivedAndVerifiedUnderLease']
assert sha(parent/'comparison/quiet/observations.tar.xz')==old['archiveSHA256']
assert meta['imageFiles']['reference']==ref['imageFiles']['reference'] and meta['catalogs']==ref['catalogs']
for role,files in meta['imageFiles'].items():
    assert len(files)==32 and {p.name:sha(p) for p in (lab/role).iterdir()}==files
    verify=read(comparison/(role+'-verify.json'))
    assert verify['state']=='Completed' and verify['caseCount']==6 and verify['launched']['library']['sha256']==files['Lokad.Lython.dll']
for prefix in ('windows','ubuntu'):
    for phase,count in [('white',47),('public',59)]:
        assert f'Passed: {count:5d}' in (parent/(prefix+'-'+phase+'-seeded.log')).read_text(encoding='utf-8-sig')
jit=read(lab/'jit-summary.json')
for role,files in meta['imageFiles'].items():assert jit[role]['core']==files['Lokad.Lython.dll']
for mode in ('ParameterIntegerSource','CaptureIntegerSource'):
    states=[next(result for method,result in jit[role]['methods'].items() if 'EvaluateClosedIntegerSequence' in method and mode in method)
        for role in ('reference','candidate')]
    assert states[0]==states[1],(mode,states)
collector=(parent/'comparison/quiet/collect.py').read_text(encoding='utf-8').replace('b1602-','b1603-')
compile(collector,'collect.py','exec');write(quiet/'collect.py',collector)
shutil.copyfile(parent/'comparison/quiet/run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as package:
    for name in ('identity.json','representative.json','jobs.json'):package.add(comparison/name,arcname=name)
    for name in ('run.sh','collect.py'):package.add(quiet/name,arcname=name)
    package.add(lab/'candidate/Lokad.Lython.dll',arcname='candidate-core.dll')
write(quiet/'upload.json',json.dumps(dict(root='closed-capture-seeded-b1603-20261124',reference='closed-capture-pair-b1602-20261124',
    payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size),indent=2)+'\n')
shutil.copyfile(parent/'verified-raw-replicas.json',lab/'verified-raw-replicas.json')
launcher=(parent/'quiet.py').read_text(encoding='utf-8').replace('b1602-closed-capture-pair','b1603-closed-capture-seeded').replace('b1602-','b1603-')
launcher=launcher.replace('17*1024*1024','11*1024*1024').replace("'candidate-core.dll','reference-core.dll'}", "'candidate-core.dll'}")
launcher=launcher.replace("if name=='Lokad.Lython.dll':", "if name=='Lokad.Lython.dll' and role=='candidate':")
launcher=launcher.replace("os.link(reference/'candidate'/name,image/name)", "os.link(reference/'reference'/name,image/name)")
compile(launcher,'quiet.py','exec');write(lab/'quiet.py',launcher)
shutil.copyfile(parent/'summarize.py',lab/'summarize.py')
print('Prepared B1603 with both original shared evaluator bodies restored.')
