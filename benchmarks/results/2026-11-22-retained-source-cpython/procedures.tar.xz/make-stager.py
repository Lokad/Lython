from pathlib import Path
import json

lab=Path(".git/agent-notes/review-20261031/current-cpython-checkpoint-20261122")
notes=lab.parent
prior=notes/"combined-default-storage-20261122"
previous=json.loads((prior/"comparison/images.json").read_text(encoding="utf-8"))
now=json.loads((lab/"images.json").read_text(encoding="utf-8"))
assert now["protocolSHA256"]==previous["protocolSHA256"]
compare=lab/"comparison"
compare.mkdir(exist_ok=True)
(compare/"images.json").write_text(json.dumps(dict(reference="c097d73db",candidate=now["revision"],
    imageFiles={**now["imageFiles"],"reference":previous["imageFiles"]["reference"]},
    catalogSHA256=now["catalogSHA256"],protocolSHA256=now["protocolSHA256"],sourcePatchSHA256=None),indent=2)+"\n",
    encoding="utf-8",newline="\n")
base=(prior/"stage-comparison.py").read_text(encoding="utf-8")
base=base.replace('past=lab.parent/"static-assignment-deltas-20261122/comparison"',
                  'past=lab.parent/"combined-default-storage-20261122/comparison"')
base=base.replace('2026-11-22-compiler-branch-edits','2026-11-22-compiled-default-admission')
base=base.replace('static-assignment-deltas-b1395-20261122','compiled-default-admission-b1396-20261122')
base=base.replace('root=base+"/compiled-default-admission-b1396-20261122"','root=base+"/retained-source-cpython-b1397-20261122"')
base=base.replace('unit="lython-b1396-compiled-default-admission-20261122"','unit="lython-b1397-retained-source-cpython-20261122"')
base=base.replace('out/"frozen-candidate"','lab/"frozen"')
base=base.replace('out/"catalog.json"','lab/"representative.json"')
base=base.replace('evidence=read(out/(role+"-verify.json"))','if role=="reference":continue\n    evidence=read(lab/"verify.json")')
base=base.replace('evidence["caseCount"]==4','evidence["caseCount"]==6')
base=base.replace('purpose="Admit executable positional and keyword default storage with one host resize",',
                  'purpose="Compare the retained 0.11.0 checkpoint against CPython 3.13.16",')
base=base.replace('coreSHA256={role+suffix:values[core]for role,values in files.items()for suffix in ("","-control")},',
                  'coreSHA256={label:files["candidate"][core] for label in ("candidate","candidate-control")},\n              cpythonWorkerSHA256=refs["protocolSHA256"],auxiliaryFiles={n:h for n,h in files["candidate"].items() if n!=core},')
start=base.index('ids=[row[')
end=base.index('assert b"\\r"',start)
base=base[:start]+'''jobs=[tuple(row) for row in read(lab/"jobs.json")]
assert len(jobs)==8
external=lab.parent/"direct-integer-return-cpython-20261122/quiet"
old=read(external/"config.json")
for name in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    data=(external/name).read_text(encoding="utf-8").replace(old["root"],root).replace(old["unit"],unit).replace("B1373","B1397")
    if name=="collect.py":
        start=data.index("    for case_id,lane in ")
        end=data.index("        assert time.monotonic()",start)
        data=data[:start]+f"    for case_id,lane in {jobs!r}:\\n"+data[end:]
        data=data.replace("started<230","started<480")
    elif name=="archive-owned.py":
        data=data.replace("len(raw['jobs'])==4","len(raw['jobs'])==8").replace("jobs=4,","jobs=8,")
    elif name=="retrieve.py":
        data=data.replace("['jobs']==4","['jobs']==8")
    write(quiet/name,data)
'''+base[end:]
base=base.replace('if path.stat().st_size<450000:', 'if path.stat().st_size<265000:')
base=base.replace('checked frozen cores and four complete source goldens','checked frozen core and six complete source goldens')
base=base.replace('replace("lython-b1395-fixtures","lython-b1396-fixtures")','replace("lython-b1396-fixtures","lython-b1397-fixtures").replace("RuntimeMaxSec=342","RuntimeMaxSec=525")')
base=base.replace('replace("Compiler branch assignment edits","Compiled default admission")','replace("Compiled default admission","Retained source vs CPython").replace("294","470")')
compile(base,"B1397 stager","exec")
(lab/"stage.py").write_text(base,encoding="utf-8",newline="\n")
