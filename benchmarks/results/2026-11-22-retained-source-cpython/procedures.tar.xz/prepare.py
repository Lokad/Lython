from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
base="benchmarks/results/"
def read(path):return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def command(*args):
    return subprocess.check_output(["git",*args],cwd=repo).strip().decode()
rev=(lab/"built-revision.txt").read_text(encoding="utf-8-sig").strip()
assert command("status","--porcelain")==""
assert command("rev-parse","HEAD")==rev==command("rev-parse","origin/master")
def archived(name):
    path=repo/base/name/"observations.tgz"
    receipt=read(path.with_name("archive-receipt.json"))
    assert receipt["complete"] and sha(path)==receipt["archiveSHA256"]
    with tarfile.open(path) as archive:
        if "representative.json" in archive.getnames():
            return json.load(archive.extractfile("representative.json"))
        expansion=json.load(archive.extractfile("expansion.json"))
        configuration=json.load(archive.extractfile("configuration.json"))
        return dict(expansion,cases=[*expansion["cases"],*configuration["cases"]])
archives=[
    "2026-11-22-compiler-branch-edits",
    "2026-11-22-unicode-decimal-cpython",
    "2026-11-22-json-delivery-cpython",
]
suites=[archived(name) for name in archives]
ids=[
    "scripts.config-generated-guards.medium.bad-0.sparse-lexical",
    "scripts.annotated-rule-closures.nested-factories.postponed",
    "scripts.csv-invoice.method-policy.quoted-control",
    "scripts.text-word-count.cased-width.nonlocal-helper",
    "scripts.json-lines-shipment.expanded-options.large",
    "scripts.config-transform",
]
available={row["id"]:row for suite in suites for row in suite["cases"]}
ids[3]=next(name for name in available if "nonlocal" in name)
ids[-1]=next(name for name in available if "config" in name and ("edit" in name or "transform" in name))
suite=dict(suites[0],cases=[available[id] for id in ids],performanceQualified=False)
def save(path,value):path.write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8",newline="\n")
catalog=lab/"representative.json"
save(catalog,suite)
save(lab/"jobs.json",[
    [ids[0],"compile"],[ids[0],"compile-run"],[ids[1],"warm"],[ids[1],"compile-run"],
    [ids[2],"warm"],[ids[3],"warm"],[ids[4],"warm"],[ids[5],"compile-run"],
])
prior_lab=lab.parent/"combined-default-storage-20261122/comparison"
previous=read(prior_lab/"images.json")
donor=prior_lab/"frozen-candidate"
expected=previous["imageFiles"]["candidate"]
assert len(expected)==32 and {name:sha(donor/name) for name in expected}==expected
image=lab/"frozen"
image.mkdir(exist_ok=True)
core="Lokad.Lython.dll"
binary=lab/"build/bin/Lokad.Lython/release_net11.0"/core
for name in expected:shutil.copyfile(binary if name==core else donor/name,image/name)
known={**expected,core:sha(binary)}
actual={p.name:sha(p) for p in image.iterdir() if p.is_file()}
assert actual==known
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
assert sha(protocol)==previous["protocolSHA256"]
report=lab/"verify.json"
subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",report],
    env=env,check=True,timeout=125)
receipt=read(report)
assert receipt["state"]=="Completed" and receipt["caseCount"]==len(ids) and receipt["catalogSha256"]==sha(catalog)
save(lab/"images.json",dict(revision=rev,imageFiles={"candidate":actual},catalogSHA256=sha(catalog),
    protocolSHA256=sha(protocol),catalogSources=archives,verifiedWorkloads=ids))
print(rev,ids)
