from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=r.parents[3]
out=repo/'benchmarks/results/2026-11-15-invoice-call-attribution';out.mkdir(exist_ok=False)
for name in ['attribution.json','archive-receipt.json','terminal-status.json']:
    shutil.copyfile(r/'capture'/name,out/name)
shutil.copyfile(r/'capture/identity.json',out/'identity.json')
shutil.copyfile(r/'capture/observations.tgz',out/'observations.tgz')
archive=out/'procedure-and-codegen.tar.xz'
with tarfile.open(archive,'x:xz') as a:
    for p in r.iterdir():
        if p.is_file():a.add(p,arcname=p.name,recursive=False)
    for p in (r/'capture').iterdir():
        if p.is_file() and p.name not in {'payload.tgz','observations.tgz'}:a.add(p,arcname='capture/'+p.name,recursive=False)
decision=dict(attributionClosed=True,newRuntimeSelected='R405 completed arithmetic/operand boundary; not yet measured or qualified',
    interpretation='No dominant general binding/workspace/namespace construction in the qualified capture. Resolved dispatch/value work guides the next coherent replacement; inclusive samples overlap useful work and are not exact removable fractions.',
    originalSetupFailuresRetained=True,allVMUsersJoined=True,allRAMDataArchivedAndVerifiedBeforeUnmount=True,
    procedureArchiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),performanceComparison=False)
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
print('Preserved the finite attribution/codegen gate; no unchanged capture or performance claim.')
