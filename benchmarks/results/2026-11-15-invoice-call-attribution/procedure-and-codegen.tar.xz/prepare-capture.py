from pathlib import Path
import hashlib,io,json,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=r.parents[3];q=r/'capture';q.mkdir(exist_ok=False)
old=r.parent/'search-attribution-r400';remote='/home/lokad/lython-bench-checks/invoice-attribution-b789-20261115'
identity=json.loads((r.parent/'activation-r403/quiet-retirement/identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='Qualified51e3c2c1/frozen22e5b72c versus withdrawn17b04146; R404 invoice construction/dispatch attribution',purpose='One complete-invoice CPU/source-pair capture; diagnostic perf-map override, not elapsed speedup or CPU-share-removability proof.')
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
profile=(old/'ops-profile.py').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/search-attribution-b785-20261115',remote)
profile=profile.replace("[('search','scripts.file-search.large.protected','warm')]", "[('reference','scripts.csv-invoice.large','warm'),('candidate','scripts.csv-invoice.large','warm')]")
profile=profile.replace('worker = tree / "candidate/Lokad.Lython.Benchmarks.dll"','worker = tree / (name + "/Lokad.Lython.Benchmarks.dll")')
profile=profile.replace('count = 512 #','count = 32 #')
profile=profile.replace("expected['coreSHA256']['candidate']", "expected['coreSHA256'][name]")
needle="            assert not record['identity']['serverGc']"
profile=profile.replace(needle,"""            for file,sha in expected['auxiliaryFiles'].items():
                loaded=next((v for v in record['identity']['libraries'] if pathlib.Path(v['path']).name==file),None)
                if loaded is not None:assert loaded['sha256'].lower()==sha
"""+needle)
(q/'ops-profile.py').write_text(profile,encoding='utf-8',newline='\n')
collect=(old/'collect.py').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/search-attribution-b785-20261115',remote)
collect=collect.replace("for name in ['search']", "for name in ['reference','candidate']")
collect=collect.replace("source='Committed51e3c2c1/frozen22e5b72c; R400 complete search CPU attribution'", "source='Qualified22e5 versus withdrawn17b; R404 complete invoice CPU/source-pair attribution'")
(q/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/search-attribution-b785-20261115',remote),encoding='utf-8',newline='\n')
sha=lambda b:hashlib.sha256(b).hexdigest();retire=[]
def tracked(p):
    name=p.relative_to(repo).as_posix();commit=subprocess.check_output(['git','log','-1','--format=%H','--',name],cwd=repo,text=True).strip()
    assert subprocess.check_output(['git','hash-object',str(p)],cwd=repo,text=True).strip()==subprocess.check_output(['git','rev-parse',f'{commit}:{name}'],cwd=repo,text=True).strip()
    return dict(commit=commit,archive=name,archiveSHA256=sha(p.read_bytes()))
p=repo/'benchmarks/results/2026-11-15-canonical-activation-prototype/refinement/sources-checks-and-observations.tar.xz';custody=tracked(p)
with tarfile.open(p) as a:
    blob=a.extractfile('quiet/observations.tgz').read()
    retire.append(dict(path='activation-b788-20261115/observations.tgz',bytes=len(blob),sha256=sha(blob),custody=dict(custody,member='quiet/observations.tgz')))
    with tarfile.open(fileobj=io.BytesIO(blob)) as b:
        raw=b.extractfile('confirmation/confirmation.json').read()
        retire.append(dict(path='activation-b788-20261115/confirmation/confirmation.json',bytes=len(raw),sha256=sha(raw),custody=dict(custody,member='quiet/observations.tgz',nestedMember='confirmation/confirmation.json')))
p=repo/'benchmarks/results/2026-11-15-csv-cpython-checkpoint/observations.tgz';custody=tracked(p);blob=p.read_bytes()
retire.append(dict(path='csv-cpython-b784-20261115/observations.tgz',bytes=len(blob),sha256=sha(blob),custody=custody))
with tarfile.open(p) as a:
    raw=a.extractfile('confirmation/confirmation.json').read()
    retire.append(dict(path='csv-cpython-b784-20261115/confirmation/confirmation.json',bytes=len(raw),sha256=sha(raw),custody=dict(custody,member='confirmation/confirmation.json')))
p=repo/'benchmarks/results/2026-11-15-tuple-operand-prototype/refined/confirmation/observations.tgz';custody=tracked(p);blob=p.read_bytes()
retire.append(dict(path='tuple-controls-b783-20261115/observations.tgz',bytes=len(blob),sha256=sha(blob),custody=custody))
with tarfile.open(q/'payload.tgz','w:gz') as a:
    for name in ['identity.json','ops-profile.py','collect.py','run.sh']:a.add(q/name,arcname=name)
with tarfile.open(q/'payload.tgz') as a:unpacked=sum(m.size for m in a if m.isfile())
config=dict(root=remote,sourceRoot='/home/lokad/lython-bench-checks/tuple-transport-b782-20261115',candidateSource='/home/lokad/lython-bench-checks/activation-b788-20261115',unit='lython-b789-invoice-attribution-20261115',identity=identity,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=unpacked,retire=retire)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
launch=(r.parent/'activation-r403/launch-quiet.py').read_text(encoding='utf-8')
launch=launch.replace("r=Path(__file__).resolve().parent/'quiet'", "r=Path(__file__).resolve().parent/'capture'")
launch=launch.replace("base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot']);", "base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot']);candidate=Path(config['candidateSource']);")
launch=launch.replace(" assert sha(source/'representative.json')", " assert candidate.parent==base and candidate.resolve()==candidate and sha(candidate/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']\n assert sha(source/'representative.json')")
launch=launch.replace('254*1024*1024+config[\'unpackedBytes\']+65536', "max(254*1024*1024+65536,252*1024*1024+2621440)+config['unpackedBytes']")
launch=launch.replace(" os.link(source/'candidate/Lokad.Lython.dll',root/'reference/Lokad.Lython.dll')", " os.link(source/'candidate/Lokad.Lython.dll',root/'reference/Lokad.Lython.dll')\n os.link(candidate/'candidate/Lokad.Lython.dll',root/'candidate/Lokad.Lython.dll')")
launch=launch.replace("root/'representative.json'", "root/'catalog.json'")
launch=launch.replace(" for name in ['collect.py','archive-owned.py']", " for name in ['collect.py','ops-profile.py']")
launch=launch.replace('RuntimeMaxSec=300','RuntimeMaxSec=120').replace('b787','b789')
launch=launch.replace('seconds=205','seconds=75')
(r/'launch-capture.py').write_text(launch,encoding='utf-8')
retrieve=(old/'retrieve.py').read_text(encoding='utf-8').replace("r=Path(__file__).parent;", "r=Path(__file__).parent/'capture';")
(r/'retrieve-capture.py').write_text(retrieve,encoding='utf-8')
print(dict(stagedBytes=unpacked,retirementBytes=sum(v['bytes']for v in retire),coreSHA256=identity['coreSHA256']))
