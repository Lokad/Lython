# R404 initial construction/code-generation gate

Production stays qualified6e276759; R403 is withdrawn and preserved by3c3eb130
andfb5b0e1d. No new runtime prototype, option, dependency or safety policy.

Managed metadata compares exact frozen45dd2da1 with withdrawn17b04146. The
ordinary prefix changes3004 to3135IL bytes; the old native loop is2446IL bytes.
The common prefix has three exception regions; NativeExecution.RunCore has none
(its outer Run owns exception routing). Local/field inventories are preserved
in reference-il.json/withdrawn-il.json. Counts are not CPU attribution.

One complete invoice JIT diagnostic uses the unchanged worker/catalog, Windows
.NET11RC3, normal tiering/GC and explicit JitDisasm/JitStdOutFile overrides. Each
source verifies goldens, warms for three full-request seconds, receives Closed,
joins and removes its owned fixture directory. Initial reference capture wrongly
asserted that the worker cwd contained no staged input/output after Closed; the
worker was already joined and TemporaryDirectory removed it. Preserve the original
dump. Corrected metadata/requests/dumps are in codegen.json and the two jit files.
No timing, CPU, portable-code or memory-performance result is claimed.

Observed optimized Windows Tier1 code is10626B for the old native loop and10305B
for the common replacement. Their prologues subtract744/792B respectively,
excluding saved registers and caller home space. Different shapes/PGO paths and
EH responsibilities prevent interpreting these sizes as equivalent work. The
reference ordinary prefix has OSR variants; do not select whichever size looks
favorable. A simplistic "the replacement emits a larger loop" explanation is not
supported by this capture. Actual instruction/state/entry/transport costs remain
unresolved; fewer allocations and fewer execution routes did not remove them.

Next bounded gate: one existing complete-invoice CPU/source-pair attribution
using the quiet VM's frozen qualified22e5 and withdrawn17b images, with ordinary
goldens/ownership/cleanup and explicit diagnostic overrides. Reuse the established
five-second capture procedure, preserving unresolved samples and inclusive overlap.
This is new attribution of a materially changed source, not an unchanged benchmark
or broad campaign. Stop with a demonstrated whole construction/operand/dispatch
cost to displace or a precise unresolved cost; a justified confirmation remains
eligible. No new runtime representation is selected from IL/code-size counts alone.
