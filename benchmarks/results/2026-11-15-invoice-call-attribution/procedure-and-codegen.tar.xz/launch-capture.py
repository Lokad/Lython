from pathlib import Path
import datetime,json,shlex,subprocess
r=Path(__file__).resolve().parent/'capture';config=json.loads((r/'config.json').read_text(encoding='utf-8'))
code='''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot']);candidate=Path(config['candidateSource']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and root.resolve()==root and not root.exists() and source.parent==base and source.resolve()==source
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 probe=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True)
 own={str(os.getpid()),str(os.getppid())}
 assert all(line.split(maxsplit=1)[0] in own for line in probe.stdout.splitlines()),probe.stdout
 assert not any(os.path.ismount(p)for p in base.glob('*/guest-fixtures'))
 state=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=LoadState,MainPID'],text=True)
 assert 'LoadState=not-found'in state and 'MainPID=0'in state
 assert sha(source/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['reference']
 for name,h in config['identity']['auxiliaryFiles'].items():assert sha(source/'candidate'/name)==h,name
 assert candidate.parent==base and candidate.resolve()==candidate and sha(candidate/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']
 assert sha(source/'representative.json')==config['identity']['catalogSHA256']
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes'] and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 before=shutil.disk_usage(base).free
 paths=[]
 for proof in config['retire']:
  p=base/proof['path'];m=p.lstat()
  assert p.resolve()==p and p.is_relative_to(base) and stat.S_ISREG(m.st_mode) and m.st_uid==os.getuid() and m.st_nlink==1 and m.st_size==proof['bytes'] and sha(p)==proof['sha256']
  assert proof['sha256']not in config['identity']['coreSHA256'].values()
  paths.append(p)
 assert before+sum(v['bytes']for v in config['retire'])>max(254*1024*1024+65536,252*1024*1024+2621440)+config['unpackedBytes']
 for p in paths:p.unlink()
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:a.extractall(root,filter='data')
 for role in ['candidate','reference']:
  (root/role).mkdir(exist_ok=True)
  for name in config['identity']['auxiliaryFiles']:os.link(source/'candidate'/name,root/role/name)
 os.link(source/'candidate/Lokad.Lython.dll',root/'reference/Lokad.Lython.dll')
 os.link(candidate/'candidate/Lokad.Lython.dll',root/'candidate/Lokad.Lython.dll')
 os.link(source/'representative.json',root/'catalog.json');os.link(source/'cpython-worker.py',root/'cpython-worker.py')
 assert sha(root/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']
 for name in ['collect.py','ops-profile.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 (root/'retirement-receipt.json').write_text(json.dumps(dict(retiredOnly=config['retire'],allHashesPathsLinksOwnershipVerified=True,incomingPayloadVerifiedBeforeRetirement=True,freshIdleLease=True,canonicalEvidenceAndQualifiedImagesPreserved=True,freeBeforeBytes=before,freeAfterBytes=shutil.disk_usage(base).free),indent=2)+'\\n')
 fixture=root/'guest-fixtures';fixture.mkdir();assert shutil.disk_usage(base).free>254*1024*1024
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b789-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(json.dumps(dict(launched=True,root=str(root),unit=config['unit'],freeBytes=shutil.disk_usage(base).free)))
'''.replace('CONFIG',repr(config))
(r/'remote-launch.py').write_text(code,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=(r/'payload.tgz').read_bytes(),capture_output=True,timeout=45)
(r/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(launchedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=75)).isoformat()),indent=2)+'\n',encoding='utf-8')
print(done.stdout.decode('utf-8'),flush=True)
