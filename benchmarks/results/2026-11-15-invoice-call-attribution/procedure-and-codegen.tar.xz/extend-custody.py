from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=r.parents[3];q=r/'capture'
shutil.copyfile(q/'config.json',q/'config-before-space-correction.json')
shutil.copyfile(q/'launch.log',q/'launch-space-preflight.log')
config=json.loads((q/'config.json').read_text(encoding='utf-8'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def custody(p):
    name=p.relative_to(repo).as_posix();commit=subprocess.check_output(['git','log','-1','--format=%H','--',name],cwd=repo,text=True).strip()
    assert subprocess.check_output(['git','hash-object',str(p)],cwd=repo,text=True).strip()==subprocess.check_output(['git','rev-parse',f'{commit}:{name}'],cwd=repo,text=True).strip()
    return dict(commit=commit,archive=name,archiveSHA256=sha(p.read_bytes()))
p=repo/'benchmarks/results/2026-11-15-tuple-operand-prototype/refined/confirmation/observations.tgz';proof=custody(p)
with tarfile.open(p) as a:raw=a.extractfile('confirmation/confirmation.json').read()
config['retire'].append(dict(path='tuple-controls-b783-20261115/confirmation/confirmation.json',bytes=len(raw),sha256=sha(raw),custody=dict(proof,member='confirmation/confirmation.json')))
p=repo/'benchmarks/results/2026-11-15-tuple-operand-prototype/vm/observations.tgz';raw=p.read_bytes()
config['retire'].append(dict(path='tuple-transport-b781-20261115/observations.tgz',bytes=len(raw),sha256=sha(raw),custody=custody(p)))
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
print('Fresh staging will validate seven exact archived working files before any deletion; total prospective reclamation',sum(v['bytes']for v in config['retire']))
