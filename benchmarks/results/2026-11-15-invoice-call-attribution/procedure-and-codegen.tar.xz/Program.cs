using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;

var path = Path.GetFullPath(args[0]);
var assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(path);
var selected = new Dictionary<string, string[]>
{
    ["NativeExecution"] = ["RunCore"],
    ["PyExecutableFunction"] = ["StartNativeCall", "StartInline"],
    ["ExecutableInvocation"] = ["CreateFunction", "Execute", "Retire"],
    ["ExecutionContext"] = ["ExecuteInstructionPrefix"],
    ["ExecutableValueStorage"] = ["RetireTo", "PublishSlot"],
    ["ExecutableWorkState"] = [],
};
const BindingFlags flags = BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.DeclaredOnly;
var types = assembly.GetTypes().Where(t => selected.ContainsKey(t.Name));
var rows = types.Select(t => new
{
    type = t.FullName,
    fields = t.GetFields(flags).Select(f => new { f.Name, type = f.FieldType.ToString(), f.IsInitOnly, f.IsStatic }),
    methods = t.GetMethods(flags).Where(m => selected[t.Name].Contains(m.Name)).Select(m =>
    {
        var body = m.GetMethodBody();
        return new
        {
            m.Name,
            ilBytes = body?.GetILAsByteArray()?.Length,
            exceptionRegions = body?.ExceptionHandlingClauses.Count,
            locals = body?.LocalVariables.Select(v => new { v.LocalIndex, type = v.LocalType.ToString() }),
        };
    }),
}).ToArray();
var result = new
{
    coreSHA256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(path))),
    interpretation = "Managed metadata and IL only; not native JIT size, inlining, dominant CPU attribution or a performance claim.",
    rows,
};
File.WriteAllText(args[1], JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }) + "\n", new System.Text.UTF8Encoding(false));
foreach (var t in rows)
    foreach (var m in t.methods) Console.WriteLine($"{t.type}.{m.Name}: IL {m.ilBytes} bytes, {m.exceptionRegions} exception regions, {m.locals?.Count()} locals");
