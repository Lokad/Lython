from pathlib import Path
r=Path(__file__).resolve().parent
s=(r.parent/'analyze-search-attribution-r400.py').read_text(encoding='utf-8')
s=s.replace("root = Path(__file__).parent / 'search-attribution-r400'", "root = Path(__file__).parent / 'capture'")
s=s.replace("for mode in ['search']:","for mode in ['reference','candidate']:")
a=s.index('    inclusive={label:');b=s.index("    calls=record",a)
s=s[:a]+'''    terms={
        'native-call-entry':['StartNativeCall','StartInline'],
        'native-loop':['NativeExecution'],
        'ordinary-prefix':['ExecuteInstructionPrefix'],
        'canonical-activation':['ExecutableInvocation'],
        'binding':['BindFunctionArguments','BindCallOperands'],
        'workspace':['WorkspaceCache','RentFunctionWorkspace','ReturnFunctionWorkspace','EndWorkspaceLoan'],
        'context-frame':['EnterInvocationFrame','MaterializeContext'],
        'operand-storage':['ExecutableValueStorage','PublishInstructionResult','CompleteLocalResult'],
        'admission':['MemoryGovernor','LythonMemoryBudget','OwnedMemory'],
        'stack-admission':['EnsureInterpreterStack','EnterInterpreterFrame','EnterFunctionCall','TryEnsureSufficientExecutionStack'],
        'CSV':['CsvModule','CsvReader','CsvDict','NativeCsv'],
        'numeric':['BigInteger','IntegerText','MachineBinary','IntegerInstruction','IntegerChain'],
        'tuple':['SlotTupleBytes','CreateTupleFromStack','TryReturnUnpackedTuple','PyTuple'],
    }
    inclusive={label:sum(any(any(term in n for term in needles)for n in sample['stack'])for sample in guest)for label,needles in terms.items()}
''' + s[b:]
s=s.replace("interpretation='Diagnostic CPU-clock/fp samples; inclusive frame counts overlap and include useful work. One complete-search capture is not a controlled elapsed source-pair comparison or exact removable CPU fraction.'", "inclusiveGuestCpuMicrosecondsPerInvocation={label:count/len(guest)*1e6*guest_cpu/calls for label,count in inclusive.items()},\n             interpretation='Diagnostic source-pair CPU-clock/fp samples. Inclusive frame counts overlap and include useful work; not exact removable shares or a controlled elapsed comparison. All unknown/ambiguous leaves stay explicit.'")
s=s.replace("source='51e3c2c1/frozen22e5b72c'", "source='qualified51e3c2c1/22e5b72c versus withdrawn17b04146'")
s=s.replace("row['topGuestLeaves'][:14]", "row['topGuestLeaves'][:25]")
(r/'analyze-capture.py').write_text(s,encoding='utf-8')
