# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored; never force-add. Publication and tagging postponed.
Objective: coherent design simplification and substantial complete-script performance.
An isolated experiment does not complete that objective. Historical narratives,
original failed conditions and raw measurements remain in benchmarks/EXPERIMENTS.md
and results; docs describe the current implementation.

## Delivery status

| Work | Actual status |
| --- | --- |
| Shared compiler facts, direct UTF-8 formatting/storage, native helper returns | Committed and fully qualified. Native-return allocation −19.92%/−19.31%; original elapsed diagnostic. Formatting allocation −8.67%; controlled B102 elapsed/CPU −5–8%, original adverse 15.125 ms preserved and unexplained. Do not repeat unchanged qualification. |
| R62 / 70267889 | Fully qualified CI42412531882, cached terminal green. |
| R65/R66 / 824fc6bb | Fully qualified CI42418518578: Windows/Ubuntu Release actual .NET 11/10, original Stress and installed core consumers. |
| R67 / 5076359c | Current CPython guide measures 824fc6bb/core15c04e2a, 23 jobs/478.32 s. Compile, warm and compile-to-result separate; I/O/validation/cleanup boundaries explicit. Original failed B406 and historical 55e510ff preserved. Not today's HEAD. |
| R68 / 5076359c | Exact immutable dev55/d6067925: 86 internal/514 public per actual 11/10, unchanged adapter bridge. Normal optional 0.4 pin/core unchanged. Development compatibility only. |
| R69 / fd5ab1c1 | Complete returned-record CSV script, independent goldens/CPython checks and current attribution committed; production unchanged. |
| R70 / 7a81a629 | Fully qualified CI42422556519: Windows/Ubuntu Release actual 11/10, original Stress and installed consumers. Cached terminal receipt; never requery. Immutable tuple unpacking removes iterator/list/copy/reservation work. Allocation −13.57% sync/−14.40% async; controlled affected elapsed −6.45–7.45% sync/−7.01–9.34% async. |
| R71 / f88191f7 + a34f56b5 | f88191f7 fully qualified CI42426106105, cached terminal green. Subsequent readonly transport correction: 1,366 internal/244 public per actual11/10, B427 complete; fully qualified with R72 by CI42428096630. B424/B425 adverse originals retained. |
| R72 / 68d5bffe | Committed/pushed. 1,729 internal/597 public per actual11/10, matching probes, 20 baseline cases. B428 complete/archived/verified: allocation −23.48% sync/−21.69% async; affected controlled elapsed −1.92–4.79% sync/−2.76–6.49% async. FULLY QUALIFIED CI42428096630: Windows/Ubuntu actual11/10, original Stress and installed core consumers; terminal cached, never requery. |
| R73 /21b0bc72 | Targeted current returned-record CPython baseline committed; source68/corea0, five jobs107.44s. Guide revision boundaries explicit; no wholesale replay. |
| R74 /33b6c191 | Fully qualified CI42431587731; controlled complete float report benefit, neutral allocation, original adverse controls retained. |
| R75 /79657355+c384956f | Text storage gate, missing current allocation capture; raw failures consolidated/verified, no storage prototype or timing claim. |
| R76 prerequisite /06651b11 | Unicode cache cancellation correction committed; reproduced failure,67internal/135public per actual11/10 pass. Full qualification batches with next retained milestone. |

## Fully qualified retained checkpoint

Latest fully qualified runtime33b6c191: cached green CI42431587731 includes
Windows/Ubuntu Release actual11/10, original Stress both targets and installed
core consumers. Earlier R71/R72 baseline receipts remain cached; never repeat
unchanged qualification. This does not qualify later06651b11 cache cancellation.
Publication/tagging remain postponed; the complete-script objective remains open.

B429/R73 is complete: five jobs/107.441s, source68d5bffe/corea0aef9ef, exact
source/Ready/reference/runtime/golden/quiet/join/fixture/archive gates pass.
Returned-record CSV compile1.07–1.10×, warm1.32–1.35×, compile-to-result1.31–1.34×
CPython3.13.16 (variable control/compilation IQR). Current ordinary CSV warm
1.16–1.19× variable, text1.67–1.68× diagnostic. Authoritative docs/BENCHMARKS.md
marks new revision/date, separates all three boundaries, and preserves valid older
source824fc6bb rows. No inferred source-pair ratio, wholesale replay or general CPU
gain. Histories/raw evidence stay under benchmarks/results and EXPERIMENTS.

R71/B425's large ordinary-CSV adverse observation is not reproduced after concrete
Linux transport correction; its full cause is unproven. R72 retains text mixed/
adverse coarse CPU up to+6.67%. Original conditions/results stay visible; no debt
repayment by unrelated improvements. Further release acceptance must decide any
remaining regression debt. The complete-script performance objective is still open.

## Retained R74 / completed R75 gate

R74 committed/pushed33b6c191 replaces the lexer-validated JSON float entry with
native UTF-8 conversion, removing general culture/format entry and no fallback.
2,191 CPython bit/consumption cases and257internal/1,160public pass per actual11/10.
Allocation neutral; B430 terminal/archived/verified: complete float report elapsed
−11.40–12.03% sync/−10.05–14.08% async, integer/text controls near baseline.
Original36.7% unchanged-control drift/new desktop integer+7.75–12.57% retained.
FULLY QUALIFIED CI42431587731: Windows/Ubuntu actual11/10, original Stress both
targets and installed core consumers PASS. Terminal receipt cached; never requery.
This qualifies33b6c191, not the subsequent Unicode-cache cancellation correction.

R75 closes with missing current attribution, no runtime prototype or timing result.
Original B431/B434 staging-floor failures, B432 Ready assumption and B433 Linux
socket-path failure are preserved in results/2026-11-08-text-storage-gate. All
started users joined/owned fixtures unmounted; failure archives locally verified.
No further capture launched. Correcting setup later is permitted, not a failed or
permanently closed design. Do not promote historical type percentages to current.

## Active R76 — complete token-storage design gate

Hypothesis: eliminate per-token byte-array/header storage and unnecessary string
metadata, rather than widening only operands while dict/closure/call boundaries
still require boxes. Historical D36 sampled PyString35.72%/byte[]18.44% vs boxed
BigInteger18.09%; R63 CPU leaves separately revision-labelled. Current factories
still build final wrappers/arrays. No predicted current allocation/CPU percentage.
Affected complete scripts: text helper aggregation, CSV records and JSON report;
ordinary configuration/search/manifest and long-string cases are controls.

Prototype0920236a passes162internal/415public per actual11/10. Allocation text−9.4%,CSV−8–9%; desktop sync text+14–15% adverse. B435 terminal/archived/verified: sync text+0.58–5.35%, CSV+0.75–3.14%, report mixed with6.19% old spread; no CPU benefit established. Preserve all original variation. One generated-code assessment and a semantic refinement are justified: a prepaid stable data view must remain available to native cleanup without introducing an origin-governor refusal/cancellation policy. Current execution/provider boundaries retain authority. No current-caller token is cached.

The generated Tier1 hash bodies already inline the getter; no attribute selected. Refinement writes casing/split/CSV directly into factory-private final capacity, removing added stack copies and per-caller storage branches. Commit before publication; no new writer/owner/pool. Prepaid native memory borrows keep cleanup access, with current execution/provider refusal/cancellation authority. Repeat focused checks and one final controlled pair, preserve092/B435. Then retain or withdraw the completed representation and decide debt.

1. Source/representation gate: assess a fully managed short UTF-8 representation
   and distinction between synchronous spans and retained ReadOnlyMemory borrows.
   Eliminate an entire construction phase. Keep native ordinary storage, lazy
   Unicode indexing/hash caches and returned-memory lifetimes coherent; measure
   total wrapper/capacity/cache/overlap, not just removed byte arrays. No unsafe
   APIs/layout tricks, general views, new owner/ledger/pool/public option or
   revival of R54/R60 without addressing their general-path costs. Selected prototype: safe C# inline8 storage plus existing array adoption.
   A new inline field/flag can grow ordinary wrappers; retain current caches,
   native span/byte-length readers and one lazy stable tiny memory borrow. Existing
   128B metadata headroom funds that borrow before initial allocation. No storage
   unions/new sidecars/owners. Frozen baseline/selected-plan in inline-text-r76;
   no timing claim. Complete factories and casing/split construction before timing. Stop at a concrete representation or
   insufficient evidence, then choose the next substantive boundary.
2. Committed correctness prerequisite06651b11, focused-qualified: GetRuneByteOffsets used to
   allocate/scan/publish after admission could cancel. It now checks the active
   context before allocation, through scanning and before publication. Failed cache
   construction stays unpublished and refunds only working storage. The tiny cancellation case failed on33b (no exception); refusal control passed.
   After correction67internal/135public pass per actual11/10. Input/first refusal/
   reserved balance/reuse survive. No clock/fuel counters, enlarged fixtures or
   new cancellation policy; full delivery batches with retained storage work.
3. If a representation is selected, finish constructors plus affected native span
   consumers before timing. Displace old short-token allocation paths; no dormant
   alternatives. Preserve Unicode/surrogates, hash/equality/identity, indexing/
   slicing/formatting, original regex windows, callback/reentry and real suspended
   I/O. Keep aliases/caches/results/borrows funded and first admission refusal
   terminal; all cleanup awaited. Existing coarse headroom is not a hidden cap.
4. Focused Release actual11/10 string/protocol/cancellation/ownership checks, then
   existing short five-script allocation diagnostic with old/current/old controls.
   One bounded whole-script VM pair only after staging/socket preflight is fixed;
   no dependence on that VM for implementation/correctness. Preserve adverse
   controls and decide retained/withdrawn source plus remaining regression debt.
   Temporary setbacks allowed within this explicit completion milestone; no fixed
   percentage veto or allocation-to-CPU inference. Batch full delivery when retained.

## Following substantial redesign boundaries

| Boundary | Evidence / eliminated work / acceptance |
| --- | --- |
| Complete calls/frames and operand transport | Indexed operands/native returns/final slots/deferred contexts already exist. R63 text attribution includes useful arithmetic/dispatch; inclusive calls are not removable CPU. Select a complete remaining transport/activation phase, remove its displaced path. Preserve callbacks, exception state, exact integer promotion/identity, aliases and public projection. No universal tagged-value or arena rewrite without dominant-cost evidence. |
| Per-record storage | R20/R25 shared CSV keys/array transfer/direct JSON slots and R70 tuple borrow supersede the rigidly rejected bulk-CSV attempt. Its 6–8% benefit and adverse control remain historical. Reassess a real remaining construction/copy/capacity phase; no automatic revival. Preserve row mutation/reentry/hooks/order/retained aliases. |
| Bulk text/JSON | Direct UTF-8 casing/lower-split/formatting/native parsing, completed JSON loop and shared line scanner delivered. R61 measured ordinary JSON has no escaped tokens. Select a demonstrated whole conversion/storage phase, preserve Unicode/context/hooks/async I/O; no succession of narrow special cases. |
| Frontend facts | R55/R58/R62/R65 remove repeated lexical/graph/validity/module work. Remaining class/function demands have distinct scope/annotation rules. Require concrete repeated-walk deletion with exact diagnostics; no speculative visitor/cache/parser migration. |

For each selected milestone record the hypothesis, work/storage eliminated, affected
complete scripts, semantic/cancellation/admission acceptance and old implementation
removed. One bounded source/generated-code assessment; focused attribution only if
existing evidence cannot select. Stop at a concrete phase or insufficient evidence,
then choose another boundary. Prior call-arena/call-control slowdowns remain lessons,
not dormant alternatives. Architectural simplification, allocation reduction, elapsed
and CPU are distinct. Fixed improvement percentages inform judgment, never automatic
vetoes. A timeout or unstable unchanged control establishes uncertainty. Allow bounded
confirmation/refinement/measurement correction when justified, retaining all original
adverse and failed conditions. No blanket one-attempt/no-retiming/permanent closure.

At the next combined retained checkpoint refresh representative CPython comparisons:
compilation, warm execution and compile-to-result separately; identical full scripts/
goldens, explicit I/O/validation/cleanup and startup boundaries. Current R67 guide
remains accurate for its named source; do not rerun unchanged qualification after
every experiment or imply that its tables describe today's HEAD.

## Independent regex track

Core owns Python/native UTF-8 semantics, byte ranges/scalar positions/original-subject
windows, flags/captures/replacements/errors, cache ownership/current tokens and one
provider through frontend/runtime/imports. No Utf8Regex core dependency. Optional
adapter stays nonpackable, normal 0.4 pin. Contract tests, semantic compatibility and
actual backend performance are separate. Development producers/adapter-local bridges
support implementation; missing publication defers only affected final qualification.

Precise dev55 gaps: DetailedData has no separate preparation/working-owner input;
native name lookup lacks enumeration; cursor creation retains its token despite
current-move overloads. Existing bridges remain justified. No sibling edits/builds,
producer-CI replay, dialect fallback, quotas, memory subsystem or abandoned matching.
Released-package/managed-safety/backend-performance qualification remains outstanding;
it must not stop independent core development or performance work.

## Lasting validation and ownership constraints

AGENTS.md governs fully managed/memory-safe code and managed stack admission: no
unsafe/Unsafe/PInvoke/raw pointers/native probes. Preserve host capabilities, effective
cancellation, checked representation bounds, XML depth and bounded I/O chunks.
Borrow the shared allowance for coarse preflights, capacity/replacement overlap,
retained aliases and escaping caches/results. Scope creation reserves nothing; no
hidden allowances/caps/fuel/quotas/tracing/weak reclamation/forced GC. Initial long
streams use bounded host-driven executions. First structured refusal is terminal
through guest suppression/finally returns; native refunds/cleanup remain awaited.
Never retry admission or skip optional storage to recover.

Focused Release checks during iteration; build matching probes, exclude Stress
explicitly when a custom filter is supplied. No overlapping local builds/tests/
measurements. Force nonincremental builds after timestamp-preserving source restores.
Batch full Windows/Ubuntu actual 11/10, original Stress and installed core consumers
at coherent retained boundaries. Use explicit UTF-8. Only core Release pack via
tools/pack.ps1 into artifacts/nuget; no adapter packages/publication/tag promotion.

VM lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. B385–B430 terminal,
archived/locally verified; never requery. B431–B434 stopped as above; no active
collector or owned fixture mount. Persistent storage is near its256MiB staging
floor. B435 normal source-pair comparison complete; no allocation collector/socket needed. Its setup reserves staged bytes plus12MiB evidence headroom and240MiB OSfree floor; earlier256MiB failures remain unchanged. Reclaim only
archive-verified redundant extracts/core links, retaining immutable VM/local proof.
Keep workers/records separate from RAM fixtures; join/unmount/archive under lease
and verify locally. No sole RAM evidence. GitHub observations at least5minutes
apart; cached terminal runs never requeried or duplicate-dispatched. Continue
independent implementation while CI runs. Publication/tagging remain postponed.
