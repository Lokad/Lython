from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;old=r.parent.parent/'json-float-entry-r74'
identity=json.loads((r/'identity.json').read_text());prior=json.loads((old/'vm-identity.json').read_text())
jobs=[['scripts.text-summary-helpers.large', 'warm'], ['scripts.text-summary-helpers.large', 'warm-async'], ['scripts.csv-summary-functions.large', 'warm'], ['scripts.report-render.large', 'warm'], ['scripts.numeric-report.float.large', 'warm-async']]
vm=dict(sourceRevision=identity['sourceRevision'],baselineSource=identity['baseline']['sourceRevision'],baselineRuntime='06651b11, focused67internal/135public per actual11/10; preceding33b full CI42431587731.',coreSHA256={role:identity['coreSHA256']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles=prior['auxiliaryFiles'],productionSources=identity['productionSources'],jobs=jobs,included=prior['included'],operationalSpace='Reserve staged files plus8MiB maximum evidence overhead and240MiB OS free floor. Earlier256MiB staging failures remain original; this is a bounded setup refinement, not a runtime-resource policy change.')
(r/'vm-identity.json').write_text(json.dumps(vm,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(r/'images/before/Lokad.Lython.dll',r/'baseline-core.dll')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','assess-vm.py']:
 s=(old/name).read_text().replace('json-float-entry-b430-20261108','inline-text-b436-20261108').replace('lython-b430-json-float-entry-20261108','lython-b436-inline-text-20261108')
 if name=='collect.py':
  a=s.index('jobs=');b=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[b:]
 if name=='archive-owned.py':
  s=s.replace("with tarfile.open(root/'observations.tgz'","with tarfile.open(root/'observations.tgz'")
  s=s.replace("for n in ['confirmation'","for n in ['retired-initial-core.json', 'confirmation'")
  s=s.replace("if (root/'reclaimed-prototype-links.json').exists():t.add(root/'reclaimed-prototype-links.json',arcname='reclaimed-prototype-links.json')","t.add(root/'reclaimed-extracts.json',arcname='reclaimed-extracts.json')\n t.add(root/'reclaimed-report-extracts.json',arcname='reclaimed-report-extracts.json')")
  s=s.replace("result=dict(complete=True", "assert __import__('shutil').disk_usage(root).free>240*1024*1024\nresult=dict(complete=True")
 if name.endswith('.py'):compile(s,name,'exec')
 (r/name).write_text(s,encoding='utf-8',newline='\n')
contract='''R76 whole-token construction source pair. Correctness162internal/415public per actual11/10, including memory borrows, Unicode, original-subject regex offsets, real delayed I/O/callbacks, cancellation/terminal refusal/ownership cleanup. Initial two post-refusal test-inspection failures preserved; preborrow retained view strengthens alias coverage. Allocation−9.43%text/−8.03–9.03%CSV; adverse sync text+13.97–15.20%desktop and all other observations preserved, no CPU inference. Controlled4jobs: textwarm/textwarm-async affected, ordinaryCSVwarm affected, JSONreportwarm general-path control. Two old/two current processes;5s warmup/role/job,7rotated150ms, normalGC/tiering/quietF4as_v7. Same frozenworker7cf37ca5/optional0.4/fullscripts/fixtures/goldens. Warm invocation/RAMmediatedI/O/fullvalidation/priorcleanup included;compile/startup/staging/reset/protocol/finalcachedteardown excluded. Observe150+30+30s, no early service request or timeout restart. Source/core/allaux/actualReady/runtime/golden/quiet/Closed/exit/join/fixture/archive gates. Persistent workers/records separate owned128MiB RAMfixtures; archive underlease/localverification. Exact payload plus8MiB evidence allowance and240MiB OSfree floor; previous256MiB stagingfailures unchanged. No allocation-tick collection, forcedGC, quotas, new benchmark framework or publication. Decide retained/withdrawn/refined representation with explicit regression debt; whole-script objective remains active.'''
(r/'contract.md').write_text(contract+'\n',encoding='utf-8')
(r/'setup-contract.json').write_text(json.dumps(dict(jobs=jobs,ownerSeconds=150,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=8,previousFailedConditionsPreserved=True),indent=2)+'\n',encoding='utf-8')
(r/'pre-measurement-plan.md').write_text(Path('PLAN.md').read_text(),encoding='utf-8')
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for name in ['collect.py','archive-owned.py','run.sh','current-core.dll','representative.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','reclaimed-extracts.json','reclaimed-report-extracts.json']:a.add(r/name,arcname=name)
 a.add(r/'vm-identity.json',arcname='identity.json')
print('Four-job source pair prepared; original adverse conditions retained.',(r/'payload.tgz').stat().st_size)
