from pathlib import Path
import datetime,hashlib,json,shlex,subprocess
r=Path(__file__).resolve().parent;payload=(r/'payload.tgz').read_bytes()
remote=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'inline-text-b436-20261108'
reference=base/'inline-text-b435-20261108/reference'
with (base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(SIZE+1);assert len(payload)==SIZE and hashlib.sha256(payload).hexdigest()=='DIGEST'
 prior=base/'inline-text-b435-20261108';digest='3667e5951fa22141fd4d01fc0866c74318e4b362910dae8da4f08a1838b50c9e'
 receipt=json.loads((prior/'archive-receipt.json').read_text());assert receipt['complete'] and receipt['archiveSHA256']==digest and hashlib.sha256((prior/'observations.tgz').read_bytes()).hexdigest()==digest
 expected=json.loads((prior/'identity.json').read_text())['coreSHA256']['candidate']
 with tarfile.open(prior/'observations.tgz')as old:assert hashlib.sha256(old.extractfile('current-core.dll').read()).hexdigest()==expected
 targets=[prior/'current-core.dll',prior/'candidate/Lokad.Lython.dll']
 for p in targets:assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(base.resolve()) and hashlib.sha256(p.read_bytes()).hexdigest()==expected
 before=shutil.disk_usage(base).free
 for p in targets:p.unlink()
 retired=dict(paths=[str(p)for p in targets],coreSHA256=expected,archiveSHA256=digest,beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,allOriginalBytesRetainedInImmutableVmAndVerifiedLocalArchives=True)
 retirement=base/'inline-text-b436-retired-initial-core.json';assert not retirement.exists();retirement.write_text(json.dumps(retired,indent=2)+'\n')
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:
  required=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+(240+8)*1024*1024
  assert shutil.disk_usage(base).free>required,(shutil.disk_usage(base).free,required)
  root.mkdir();a.extractall(root,filter='data')
 shutil.copyfile(retirement,root/'retired-initial-core.json')
 os.link(reference/'Lokad.Lython.dll',root/'baseline-core.dll')
 for role,core in [('reference','baseline-core.dll'),('candidate','current-core.dll')]:
  target=root/role;shutil.copytree(reference,target,copy_function=os.link)
  (target/'Lokad.Lython.dll').unlink();os.link(root/core,target/'Lokad.Lython.dll')
 (root/'cpython-worker.py').symlink_to(base/'prepared-call-layout-b384-20261107/cpython-worker.py')
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b436-fixtures',str(fixture)],check=True)
 identity=json.loads((root/'identity.json').read_text())
 for role in ['reference','candidate']:
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
  for name,digest in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 assert 'assert len(jobs)==5 'in(root/'collect.py').read_text() and "len(r['jobs'])==5"in(root/'archive-owned.py').read_text()
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndEveryAuxiliaryVerifiedInBothRoles=True,allFiveJobsValidated=True,ownerSeconds=180,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=8)
 assert setup['freeBytes']>(240+8)*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b436-inline-text-20261108','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=180','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''.replace('SIZE',str(len(payload))).replace('DIGEST',hashlib.sha256(payload).hexdigest())
(r/'launch-command.py').write_text(remote,encoding='utf-8',newline='\n');compile(remote,'launch','exec')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/inline-text-b436-launch.py'
command='from pathlib import Path; import sys; p=Path('+repr(stage)+'); assert not p.exists(); p.write_bytes(sys.stdin.buffer.read())'
done=subprocess.run(ssh+['python3 -c '+shlex.quote(command)],input=remote.encode(),capture_output=True);assert done.returncode==0,done.stderr
done=subprocess.run(ssh+['python3 '+stage],input=payload,capture_output=True);(r/'launch.log').write_bytes(done.stdout+b'\n'+done.stderr);print((done.stdout+done.stderr).decode(),flush=True)
assert done.returncode==0
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=240)).isoformat(),ownerSeconds=180,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8')
print('Observe after '+(now+datetime.timedelta(seconds=240)).isoformat(),flush=True)
