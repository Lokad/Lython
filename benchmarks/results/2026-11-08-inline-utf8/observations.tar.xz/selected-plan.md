# R76 selected representation

Sourcec384956f/runtime06651b11 baseline. Remove per-token final byte arrays using
fully managed C# inline storage for up to8 UTF-8 bytes. Keep adopted arrays and
their full retained capacities; do not copy transferred builders into inline data.
Use one new physical inline field and a flag, retaining current index/hash caches;
do not introduce storage unions, sidecars, new owners or special guest syntax.
Wrapper growth is an explicit possible cost on every ordinary/adopted string.
Native synchronous readers use a span/byte length. ReadOnlyMemory borrows lazily
materialize one stable immutable tiny array, funded by existing128B metadata
headroom from initial admission; preserve concurrent users and current-token
checks. No caller token retained, unsafe/layout assumptions or new allowance.
Update short copy/string/concat/slice/index factories and complete casing/split
construction, including expansion-capacity rollback. Displace prior short payload
arrays; transferred/large storage remains ordinary necessary representation.
Check Unicode/equality/hash/identity, offsets, all memory consumers, real suspension,
terminal refusal, cancellation-after-admission, input/result/alias funding and reuse.
Existing focused tests plus a few real storage/borrow/rollback regressions on
actual11/10; matching probes if invoked. Existing five full-script normal allocation
diagnostic with old/current/old controls only after semantic acceptance. Complete
text affected; CSV/JSON/report/long-string controls expose general wrapper cost.
One bounded controlled VM source pair after disk/socket setup preflight correction;
no new capture framework or blocked implementation. Stop with retained/withdrawn
source, explicit regression disposition and removed displaced paths. Allocation,
normal elapsed and CPU are distinct; no universal gain or fixed percentage veto.
