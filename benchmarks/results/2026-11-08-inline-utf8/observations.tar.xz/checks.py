from pathlib import Path
import hashlib,json,os,re,subprocess
r=Path(__file__).resolve().parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
internal=['ShortTextStorageTests','StringIndexCacheCancellationTests','TerminalStringStorageTests','StringWindowOwnershipTests','CasingStorageLifetimeTests','DirectStringSplitTests','DirectStringUpperTests','Utf8CasingTests','Utf8ScalarWidthTests','CsvRecordValueOwnershipTests','CsvParserCancellationTests','CsvDenialOwnershipTests','NativeCsvRowConversionTests','JsonStringTokenStorageTests']
public=['Unicode','JsonDecodedTextInteropTests','DirectStringSplitExecutionTests','RegexProviderContractTests','RegexScalarCursorTests','TextFileWriteCallTests','TextFileScopeLifetimeTests','JsonTextStreamTests','CsvTextStreamTests','CsvDelayedHostTests','DelayedHostCompositionTests']
results={}
for target in ['net11.0','net10.0']:
 for label,project,names in [('internal','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj',internal),('public','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj',public)]:
  key=label+'-'+target;assert not (r/(key+'.log')).exists()
  arguments=[env['DOTNET_HOST_PATH'],'test',project,'-c','Release','-f',target,'--filter','('+'|'.join('FullyQualifiedName~'+name for name in names)+')&Category!=Stress','--logger','console;verbosity=minimal']
  with (r/(key+'.log')).open('w',encoding='utf-8')as log:done=subprocess.run(arguments,env=env,stdout=log,stderr=subprocess.STDOUT)
  text=(r/(key+'.log')).read_text(encoding='utf-8');print(key,text[-550:],flush=True)
  assert done.returncode==0,key
  match=re.search(r'Passed:\s*(\d+)',text);assert match
  results[key]=dict(passed=int(match[1]),command=arguments)
 p=Path('src/Lokad.Lython/bin/Release')/target/'Lokad.Lython.dll';results[target+'-coreSHA256']=hashlib.sha256(p.read_bytes()).hexdigest()
 (r/'focused.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print('Focused semantic/cancellation/ownership checks complete for both actual targets.',flush=True)
