using Lokad.Lython.Runtime.Text;
using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal static partial class StringMembers
    {
        private static readonly Func<PyString, LythonSourceSpan, ExecutionContext, object>[] NoArgumentsOperations =
        [
            StripWhitespace,
            Lower,
            Upper,
            static (receiver, span, context) => PyStringOps.IsLower(receiver, context, span),
            static (receiver, span, context) => PyStringOps.IsUpper(receiver, context, span),
            static (receiver, span, context) => PyStringOps.IsTitle(receiver, context, span),
            static (receiver, span, context) => PyStringOps.IsAlpha(receiver, context, span),
            static (receiver, span, context) => PyStringOps.IsDigit(receiver, context, span),
            static (receiver, span, context) => PyStringOps.IsAlnum(receiver, context, span),
            static (receiver, span, context) => PyStringOps.IsAscii(receiver, context, span),
            static (receiver, span, context) => PyStringOps.IsDecimal(receiver, context, span),
            static (receiver, span, context) => PyStringOps.IsIdentifier(receiver, context, span),
            static (receiver, span, context) => PyStringOps.IsNumeric(receiver, context, span),
            static (receiver, span, context) => PyStringOps.IsPrintable(receiver, context, span),
            static (receiver, span, context) => PyStringOps.IsSpace(receiver, context, span),
        ];

        internal static NativeReturnOperation? GetNoArgumentsKind(string name)
            => name switch
            {
                "strip" => NativeReturnOperation.Strip,
                "lower" => NativeReturnOperation.Lower,
                "upper" => NativeReturnOperation.Upper,
                "islower" => NativeReturnOperation.IsLower,
                "isupper" => NativeReturnOperation.IsUpper,
                "istitle" => NativeReturnOperation.IsTitle,
                "isalpha" => NativeReturnOperation.IsAlpha,
                "isdigit" => NativeReturnOperation.IsDigit,
                "isalnum" => NativeReturnOperation.IsAlnum,
                "isascii" => NativeReturnOperation.IsAscii,
                "isdecimal" => NativeReturnOperation.IsDecimal,
                "isidentifier" => NativeReturnOperation.IsIdentifier,
                "isnumeric" => NativeReturnOperation.IsNumeric,
                "isprintable" => NativeReturnOperation.IsPrintable,
                "isspace" => NativeReturnOperation.IsSpace,
                _ => null
            };

        internal static Func<PyString, LythonSourceSpan, ExecutionContext, object>? GetNoArgumentsOperation(string name)
            => GetNoArgumentsKind(name) is { } kind ? GetNoArgumentsOperation(kind) : null;

        internal static Func<PyString, LythonSourceSpan, ExecutionContext, object> GetNoArgumentsOperation(NativeReturnOperation kind)
            => NoArgumentsOperations[(int)kind - (int)NativeReturnOperation.Strip];

        internal static PyString Lower(PyString receiver, LythonSourceSpan span, ExecutionContext context)
            => PyStringOps.Lower(receiver, context, span);

        internal static PyString Upper(PyString receiver, LythonSourceSpan span, ExecutionContext context)
            => PyStringOps.Upper(receiver, context, span);

        internal static PyString Replace(PyString receiver, object oldArgument, object newArgument, object? countArgument,
            LythonSourceSpan span, ExecutionContext context)
        {
            if (!PyStringOps.TryAsString(oldArgument, out var oldValue))
            {
                // CPython numbers the bad argument, spelling a None value bare.
                var oldType = oldArgument is PyNone ? "None" : RuntimeErrors.OperandTypeName(oldArgument);
                throw new LythonRuntimeException("TypeError", $"replace() argument 1 must be str, not {oldType}", span);
            }

            if (!PyStringOps.TryAsString(newArgument, out var newValue))
            {
                var newType = newArgument is PyNone ? "None" : RuntimeErrors.OperandTypeName(newArgument);
                throw new LythonRuntimeException("TypeError", $"replace() argument 2 must be str, not {newType}", span);
            }

            // Null is internal omission; an explicitly supplied Python None
            // still reaches the existing count validation, after both strings.
            var count = countArgument is null ? -1 : NormalizeSequenceCount(CoerceIoIntegerAsync(countArgument, span, context, false).GetAwaiter().GetResult());
            return receiver.Replace(oldValue, newValue, count, context, span);
        }

        private sealed class TextSemanticsMemberProvider : IStringMemberProvider
        {
            // N17: hot fixed signatures hoisted per family.
            private static readonly LythonCallableSignature StrEncodeSignature = LythonCallableSignature.Create("str.encode", ["encoding", "errors"], 0);
            public static readonly TextSemanticsMemberProvider Instance = new();

            public bool TryGetMember(PyString text, string name, [MaybeNullWhen(false)] out object value)
            {
                value = name switch
                {
                    "encode" => BoundCallable.Create((arguments, span, context) =>
                    {
                        if (arguments.Length > 2)
                        {
                            throw new LythonRuntimeException("TypeError", "str.encode([encoding][, errors]) expects zero to two arguments.", span);
                        }

                        if (arguments.Length >= 1) RequireCodecNameType(arguments[0], "str.encode()", "encoding", span);
                        if (arguments.Length == 2) RequireCodecNameType(arguments[1], "str.encode()", "errors", span);

                        var encoding = arguments.Length >= 1
                            ? ParseTextEncoding(arguments[0], "str.encode()", span)
                            : TextEncodingMode.Utf8;
                        var errors = arguments.Length == 2
                            ? ParseTextErrors(arguments[1], "str.encode()", span)
                            : TextErrorMode.Strict;
                        return EncodeGuestBytes(text, encoding, errors, context, span);
                    }, StrEncodeSignature),
                    "replace" => ReceiverMethods.StringReplace.Bind(text),
                    "startswith" => ReceiverMethods.StringStartsWith.Bind(text),
                    "endswith" => ReceiverMethods.StringEndsWith.Bind(text),
                    "lower" => BoundCallable.CreateNoArguments(text, "str.lower", Lower),
                    "capitalize" => BoundCallable.CreateNoArguments(text, "str.capitalize", static (receiver, span, context) => PyStringOps.Capitalize(receiver, context, span)),
                    "islower" => BoundCallable.CreateNoArguments(text, "str.islower", GetNoArgumentsOperation(name)!),
                    "upper" => BoundCallable.CreateNoArguments(text, "str.upper", Upper),
                    "swapcase" => BoundCallable.CreateNoArguments(text, "str.swapcase", static (receiver, span, context) => PyStringOps.SwapCase(receiver, context, span)),
                    "title" => BoundCallable.CreateNoArguments(text, "str.title", static (receiver, span, context) => PyStringOps.Title(receiver, context, span)),
                    "casefold" => BoundCallable.CreateNoArguments(text, "str.casefold", static (receiver, span, context) => PyStringOps.CaseFold(receiver, context, span)),
                    "isupper" => BoundCallable.CreateNoArguments(text, "str.isupper", GetNoArgumentsOperation(name)!),
                    "isalpha" => BoundCallable.CreateNoArguments(text, "str.isalpha", GetNoArgumentsOperation(name)!),
                    "isdigit" => BoundCallable.CreateNoArguments(text, "str.isdigit", GetNoArgumentsOperation(name)!),
                    "isalnum" => BoundCallable.CreateNoArguments(text, "str.isalnum", GetNoArgumentsOperation(name)!),
                    "isascii" => BoundCallable.CreateNoArguments(text, "str.isascii", GetNoArgumentsOperation(name)!),
                    "isdecimal" => BoundCallable.CreateNoArguments(text, "str.isdecimal", GetNoArgumentsOperation(name)!),
                    "isidentifier" => BoundCallable.CreateNoArguments(text, "str.isidentifier", GetNoArgumentsOperation(name)!),
                    "isnumeric" => BoundCallable.CreateNoArguments(text, "str.isnumeric", GetNoArgumentsOperation(name)!),
                    "isprintable" => BoundCallable.CreateNoArguments(text, "str.isprintable", GetNoArgumentsOperation(name)!),
                    "istitle" => BoundCallable.CreateNoArguments(text, "str.istitle", GetNoArgumentsOperation(name)!),
                    "isspace" => BoundCallable.CreateNoArguments(text, "str.isspace", GetNoArgumentsOperation(name)!),
                    _ => MissingMemberValue.Instance,
                };

                return !ReferenceEquals(value, MissingMemberValue.Instance);

            }
        }
    }
}
