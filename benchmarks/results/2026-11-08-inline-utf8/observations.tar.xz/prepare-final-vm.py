from pathlib import Path
import hashlib,json,os,shutil,tarfile
root=Path(__file__).resolve().parent;r=root/'final-comparison';r.mkdir()
initial=json.loads((root/'initial/archive-receipt.json').read_text());assert initial['complete'] and hashlib.sha256((root/'initial/observations.tgz').read_bytes()).hexdigest()==initial['archiveSHA256']
for name in ['identity.json','source.patch','current-core.dll','focused.json','representative.json','reclaimed-extracts.json','reclaimed-report-extracts.json']:
 shutil.copyfile(root/name,r/name)
(r/'images/before').mkdir(parents=True);os.link(root/'images/before/Lokad.Lython.dll',r/'images/before/Lokad.Lython.dll')
s=(root/'prepare-vm.py').read_text().replace("old=r.parent/'json-float-entry-r74'","old=r.parent.parent/'json-float-entry-r74'")
a=s.index('jobs=');b=s.index('\nvm=dict',a)
jobs=[['scripts.text-summary-helpers.large','warm'],['scripts.text-summary-helpers.large','warm-async'],['scripts.csv-summary-functions.large','warm'],['scripts.report-render.large','warm'],['scripts.numeric-report.float.large','warm-async']]
s=s[:a]+'jobs='+repr(jobs)+s[b:]
s=s.replace('inline-text-b435-20261108','inline-text-b436-20261108').replace('lython-b435-inline-text-20261108','lython-b436-inline-text-20261108').replace('plus12MiB','plus8MiB').replace('and240MiB','and240MiB').replace('evidenceHeadroomMiB=12','evidenceHeadroomMiB=8')
s=s.replace("'current-core.dll','baseline-core.dll',","'current-core.dll',")
s=s.replace("if name=='archive-owned.py':", "if name=='archive-owned.py':\n  s=s.replace(\"with tarfile.open(root/'observations.tgz'\",\"with tarfile.open(root/'observations.tgz'\")\n  s=s.replace(\"for n in ['confirmation'\",\"for n in ['retired-initial-core.json', 'confirmation'\")")
compile(s,'final-vm','exec');(r/'prepare.py').write_text(s,encoding='utf-8',newline='\n')
exec(compile(s,str(r/'prepare.py'),'exec'),{'__file__':str(r/'prepare.py')})
for name in ['collect.py','archive-owned.py','retrieve.py','assess-vm.py']:
 p=r/name;t=p.read_text().replace('len(jobs)==4','len(jobs)==5').replace("len(r['jobs'])==4","len(r['jobs'])==5").replace("len(d['jobs'])==4","len(d['jobs'])==5").replace("['jobs']==4","['jobs']==5").replace('jobs=4','jobs=5');compile(t,name,'exec');p.write_text(t,encoding='utf-8',newline='\n')
p=r/'setup-contract.json';d=json.loads(p.read_text());d['ownerSeconds']=180;d['jobs']=jobs;p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
p=r/'contract.md';p.write_text(p.read_text()+'''\nFinal refinement after092/B435: direct factory-private final writes remove the prototype's stack-copy phase and caller storage branches; Complete commits before publication. Native stable memory is prepaid pure data access; no origin-governor/data-getter refusal/cancellation policy. Compiler-managed word storage has natural alignment, exposed only through checked typed spans; no unsafe code, layout assumptions, pointer operations or endian assumptions. Initial getter/hash codegen already inlines; no inlining attribute or causal CPU claim. Initial092 all adverse/variable results preserved; intermediate7eb construction/desktop also preserved. Final source decision includes measured regression debt. Retire only two092 redundant extracted core links after verifying B435 immutable archive and the independent local copy; full original binaries remain recoverable.\n''',encoding='utf-8')
# Repack the revised contract; the baseline core will be a verified persistent hard link.
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for name in ['collect.py','archive-owned.py','run.sh','current-core.dll','representative.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','reclaimed-extracts.json','reclaimed-report-extracts.json']:a.add(r/name,arcname=name)
 a.add(r/'vm-identity.json',arcname='identity.json')
s=(root/'launch.py').read_text().replace('inline-text-b435','inline-text-b436').replace('lython-b435','lython-b436').replace("reference=base/'json-float-entry-b430-20261108/candidate'","reference=base/'inline-text-b435-20261108/reference'").replace('(240+12)','(240+8)').replace('evidenceHeadroomMiB=12','evidenceHeadroomMiB=8')
s=s.replace('len(jobs)==4','len(jobs)==5').replace("len(r['jobs'])==4","len(r['jobs'])==5").replace('allFourJobsValidated','allFiveJobsValidated').replace('ownerSeconds=150','ownerSeconds=180').replace('RuntimeMaxSec=150','RuntimeMaxSec=180').replace('seconds=210','seconds=240')
needle=" with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:"
assert needle in s
retire=''' prior=base/'inline-text-b435-20261108';digest='3667e5951fa22141fd4d01fc0866c74318e4b362910dae8da4f08a1838b50c9e'
 receipt=json.loads((prior/'archive-receipt.json').read_text());assert receipt['complete'] and receipt['archiveSHA256']==digest and hashlib.sha256((prior/'observations.tgz').read_bytes()).hexdigest()==digest
 expected=json.loads((prior/'identity.json').read_text())['coreSHA256']['candidate']
 with tarfile.open(prior/'observations.tgz')as old:assert hashlib.sha256(old.extractfile('current-core.dll').read()).hexdigest()==expected
 targets=[prior/'current-core.dll',prior/'candidate/Lokad.Lython.dll']
 for p in targets:assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(base.resolve()) and hashlib.sha256(p.read_bytes()).hexdigest()==expected
 before=shutil.disk_usage(base).free
 for p in targets:p.unlink()
 retired=dict(paths=[str(p)for p in targets],coreSHA256=expected,archiveSHA256=digest,beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,allOriginalBytesRetainedInImmutableVmAndVerifiedLocalArchives=True)
 retirement=base/'inline-text-b436-retired-initial-core.json';assert not retirement.exists();retirement.write_text(json.dumps(retired,indent=2)+'\\n')
'''
s=s.replace(needle,retire+needle)
needle=" for role,core in [('reference','baseline-core.dll'),('candidate','current-core.dll')]:"
assert needle in s
s=s.replace(needle," shutil.copyfile(retirement,root/'retired-initial-core.json')\n os.link(reference/'Lokad.Lython.dll',root/'baseline-core.dll')\n"+needle)
compile(s,'launch-final','exec');(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
print('Final source-pair prepared with verified baseline reuse and archived-prototype retirement; no collection launched yet.')
