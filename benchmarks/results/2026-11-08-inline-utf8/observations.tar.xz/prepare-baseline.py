from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent
assert not (r/'baseline.json').exists()
assert not subprocess.check_output(['git','status','--porcelain']).strip()
old=r.parent/'json-float-entry-r74'
shutil.copytree(old/'images/candidate',r/'images/before',copy_function=os.link)
p=r/'images/before/Lokad.Lython.dll';p.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',p)
d=dict(sourceRevision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),runtimeRevision='06651b11 Unicode cache cancellation on fully qualified33b6c191',qualification='67 internal/135 public per actual11/10; full delivery batches with this representation. Preceding33b CI42431587731 terminal green.',coreSHA256=hashlib.sha256(p.read_bytes()).hexdigest(),productionSources={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*.cs')if not {'bin','obj'} & set(p.parts)})
(r/'baseline.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'before-sources.tar.xz','w:xz',preset=3)as a:
 for name in d['productionSources']:a.add(name,arcname=name)
for name in ['catalog.json','representative.json']:shutil.copyfile(old/name,r/name)
plan='''# R76 selected representation

Sourcec384956f/runtime06651b11 baseline. Remove per-token final byte arrays using
fully managed C# inline storage for up to8 UTF-8 bytes. Keep adopted arrays and
their full retained capacities; do not copy transferred builders into inline data.
Use one new physical inline field and a flag, retaining current index/hash caches;
do not introduce storage unions, sidecars, new owners or special guest syntax.
Wrapper growth is an explicit possible cost on every ordinary/adopted string.
Native synchronous readers use a span/byte length. ReadOnlyMemory borrows lazily
materialize one stable immutable tiny array, funded by existing128B metadata
headroom from initial admission; preserve concurrent users and current-token
checks. No caller token retained, unsafe/layout assumptions or new allowance.
Update short copy/string/concat/slice/index factories and complete casing/split
construction, including expansion-capacity rollback. Displace prior short payload
arrays; transferred/large storage remains ordinary necessary representation.
Check Unicode/equality/hash/identity, offsets, all memory consumers, real suspension,
terminal refusal, cancellation-after-admission, input/result/alias funding and reuse.
Existing focused tests plus a few real storage/borrow/rollback regressions on
actual11/10; matching probes if invoked. Existing five full-script normal allocation
diagnostic with old/current/old controls only after semantic acceptance. Complete
text affected; CSV/JSON/report/long-string controls expose general wrapper cost.
One bounded controlled VM source pair after disk/socket setup preflight correction;
no new capture framework or blocked implementation. Stop with retained/withdrawn
source, explicit regression disposition and removed displaced paths. Allocation,
normal elapsed and CPU are distinct; no universal gain or fixed percentage veto.
'''
(r/'selected-plan.md').write_text(plan,encoding='utf-8')
p=Path('PLAN.md');s=p.read_text();marker='1. Source/representation gate:';assert marker in s
s=s.replace('Current status:\n   design assessment, no storage prototype.', 'Selected prototype: safe C# inline8 storage plus existing array adoption.\n   A new inline field/flag can grow ordinary wrappers; retain current caches,\n   native span/byte-length readers and one lazy stable tiny memory borrow. Existing\n   128B metadata headroom funds that borrow before initial allocation. No storage\n   unions/new sidecars/owners. Frozen baseline/selected-plan in inline-text-r76;\n   no timing claim. Complete factories and casing/split construction before timing.')
p.write_text(s,encoding='utf-8',newline='\n')
print('Frozen runtime06651b11',d['coreSHA256'],'and selected coherent token construction contract.')
