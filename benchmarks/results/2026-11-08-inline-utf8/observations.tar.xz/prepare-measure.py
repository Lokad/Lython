from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).resolve().parent
focused=json.loads((r/'focused.json').read_text())
assert all(focused[label+'-'+target]['passed']==n for target in ['net11.0','net10.0']for label,n in [('internal',162),('public',415)])
shutil.copytree(r/'images/before',r/'images/candidate',copy_function=os.link)
p=r/'images/candidate/Lokad.Lython.dll';p.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',p)
assert hashlib.sha256(p.read_bytes()).hexdigest()==focused['net11.0-coreSHA256']
shutil.copyfile(p,r/'current-core.dll')
identity=dict(sourceRevision='c384956f plus complete R76 inline UTF-8 construction/native span migration',baseline=json.loads((r/'baseline.json').read_text()),coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},productionSources={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*.cs')if not {'bin','obj'}&set(p.parts)})
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src','tests']))
s=(r.parent/'json-float-entry-r74/measure.py').read_text();compile(s,'measure.py','exec');(r/'measure.py').write_text(s,encoding='utf-8',newline='\n')
print(identity['coreSHA256'])
