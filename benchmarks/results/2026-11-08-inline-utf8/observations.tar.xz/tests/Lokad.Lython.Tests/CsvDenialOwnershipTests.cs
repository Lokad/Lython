using System.Runtime.CompilerServices;
using System.Reflection;
using System.Text;
using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Text;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.Tests;

[Collection("AllocationSensitive")]
public sealed class CsvDenialOwnershipTests
{
    private const long Cap = 3L * 1024 * 1024;
    private static readonly LythonSourceSpan Span = new(0, 0, 0, 0);

    [Fact]
    public void QuotedEofRefusalIsTerminalBeforePublishingTheFinalRow()
    {
        var budget = new LythonMemoryBudget(Cap);
        using var owner = budget.CreateScope();
        var context = new LythonRuntime.ExecutionContext(new MockLythonHost(),
            new LythonRunOptions { MemoryBudget = owner });
        var parser = new LythonRuntime.CsvRecordParser(Options() with { Strict = false }, context, Span);
        parser.Feed(Encoding.UTF8.GetBytes("a,\"" + new string('x', 8192)));
        Assert.True(budget.TryReserve(Cap - budget.ReservedBytes, out var blocker));
        using (blocker)
        {
            var error = Assert.Throws<LythonRuntimeException>(() => parser.Finish());
            Assert.Same(context.MemoryGovernor.AdmissionFailure, error);
            Assert.Equal(LythonFailureReason.SharedMemoryAllowance, error.Attribution?.Reason);
            Assert.False(parser.TryTakeReady(out _));
            Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
            Assert.Same(error, Assert.Throws<LythonRuntimeException>(() => context.CheckExecution(Span)));
            parser.ReleaseScratch();
        }
        owner.Dispose();
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void NumericConversionRefusalIsTerminalBeforePublishingTheRow(bool shared)
    {
        var budget = new LythonMemoryBudget(Cap);
        using var owner = budget.CreateScope();
        var context = new LythonRuntime.ExecutionContext(new MockLythonHost(), new LythonRunOptions
            { MemoryBudget = owner},regexProvider:Utf8RegexProvider.Instance);
        var governor = context.MemoryGovernor;
        var source = new LythonRuntime.CsvRecordSource(new PyList([]),
            Options() with { Quoting = LythonRuntime.CsvQuotingMode.NonNumeric }, Span, context);
        var parser = Parser(source);
        parser.Feed("1,"u8);
        Assert.True(parser.TryTakeReady(out var retained));
        var held = PyString.FromString("held", governor, Span);
        var heldBytes = held.Utf8Bytes;
        ILythonMemoryReservation? padding = null;
        // Fund the 130-byte UTF-8 value, leaving 70 bytes for its 72-byte float scratch.
        if (shared) Assert.True(budget.TryReserve(Cap - budget.ReservedBytes - 200, out padding));
        else { governor.Reserve(Cap - governor.CurrentAccountedBytes - 200, Span); governor.Commit(governor.CurrentReservedBytes); }
        using var blocker = padding;
        var error = Assert.Throws<LythonRuntimeException>(() => parser.Feed("٢\n"u8));
        Assert.Same(governor.AdmissionFailure, error);
        Assert.Equal(shared ? LythonFailureReason.SharedMemoryAllowance : LythonFailureReason.SharedMemoryAllowance,
            error.Attribution?.Reason);
        Assert.Equal(72, governor.LastDeniedReservationBytes); // Existing float scratch for two UTF-8 bytes.
        Assert.Equal(1.0, Assert.IsType<double>(retained[0]));
        Assert.False(parser.TryTakeReady(out _));
        Assert.True(heldBytes.Span.SequenceEqual("held"u8));
        Assert.Equal(0, governor.CurrentReservedBytes);
        parser.ResetRecord();
        Assert.Same(error, Assert.Throws<LythonRuntimeException>(() => parser.Feed("3\n"u8)));
        parser.ReleaseScratch();
        blocker?.Dispose();
        owner.Dispose();
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Fact]
    public void DeniedBulkFieldGrowthPreservesItsExistingFundedPrefix()
    {
        var context = Context();
        var source = new LythonRuntime.CsvRecordSource(new PyList([]), Options(), Span, context);
        var parser = Parser(source);
        parser.Feed("\"prefix\n"u8);
        var field = (GovernedByteBuilder)typeof(LythonRuntime.CsvRecordParser)
            .GetField("_record", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(parser)!;
        var capacity = checked((int)field.CommittedCapacity);
        var committed = context.MemoryGovernor.CurrentCommittedBytes;
        var pressure = Cap - context.MemoryGovernor.CurrentAccountedBytes;
        context.MemoryGovernor.Reserve(pressure, Span);

        var error = Assert.Throws<LythonRuntimeException>(() => parser.Feed(Encoding.UTF8.GetBytes(new string('x', capacity + 1) + "\n")));

        Assert.Equal("MemoryError", error.ExceptionType);
        Assert.True(field.WrittenSpan.SequenceEqual("prefix\n"u8));
        Assert.Equal(capacity, field.CommittedCapacity);
        Assert.Equal(committed, context.MemoryGovernor.CurrentCommittedBytes);
        Assert.Equal(pressure, context.MemoryGovernor.CurrentReservedBytes);
        context.MemoryGovernor.ReleaseReserved(pressure);
        parser.ResetRecord();
        Assert.Same(error, Assert.Throws<LythonRuntimeException>(() => parser.Feed("ok\n"u8)));
        parser.ReleaseScratch();
    }

    [Fact]
    public void DeniedFieldGrowthPreservesPhysicalCapacityAndFunding()
    {
        var context = Context();
        var source = new LythonRuntime.CsvRecordSource(new PyList([]), Options(), Span, context);
        var parser = Parser(source);
        parser.Feed(Encoding.UTF8.GetBytes("\"" + new string('x', 15) + "\n")); // supplied newline fills the initial 16 bytes
        var field = (GovernedByteBuilder)typeof(LythonRuntime.CsvRecordParser)
            .GetField("_record", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(parser)!;
        Assert.Equal(16, field.Length);
        Assert.Equal(16, field.CommittedCapacity);
        var owned = source.OwnedBytes;
        var committed = context.MemoryGovernor.CurrentCommittedBytes;
        var pressure = Cap - context.MemoryGovernor.CurrentAccountedBytes;
        context.MemoryGovernor.Reserve(pressure, Span);

        var error = Assert.Throws<LythonRuntimeException>(() => parser.Feed("x"u8));

        Assert.Equal("MemoryError", error.ExceptionType);
        Assert.Equal(16, field.Length);
        Assert.Equal(16, field.CommittedCapacity);
        Assert.Equal(owned, source.OwnedBytes);
        Assert.Equal(committed, context.MemoryGovernor.CurrentCommittedBytes);
        Assert.Equal(pressure, context.MemoryGovernor.CurrentReservedBytes);
        context.MemoryGovernor.ReleaseReserved(pressure);
        parser.ResetRecord();
        Assert.Same(error, Assert.Throws<LythonRuntimeException>(() => parser.Feed("ok\n"u8)));
        parser.ReleaseScratch();
    }

    [Fact]
    public void EofReleasesSourceScratchWithoutRefundingEscapedFields()
    {
        var context = Context();
        var source = new LythonRuntime.CsvRecordSource(
            new PyList(new object[] { PyString.FromString("left,right\n") }), Options(), Span, context);
        var escaped = ReadEscapedField(source);
        Assert.True(source.OwnedBytes > LythonRuntime.CsvRecordSource.ShellBytes);
        Assert.False(source.TryMoveNext(out _));
        Assert.Equal(LythonRuntime.CsvRecordSource.ShellBytes, source.OwnedBytes);
        GC.Collect();
        Assert.Equal("left", escaped.AsString());
        Assert.True(((IPyOwnershipSnapshot)escaped).TrySnapshotOwnership(out var bytes));
        Assert.True(context.MemoryGovernor.CurrentCommittedBytes >= source.OwnedBytes + bytes);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
        GC.KeepAlive(source);
        GC.KeepAlive(escaped);
    }

    [Fact]
    public void DeniedSourceAdmissionRefundsItsUnpublishedStorage()
    {
        var context = Context();
        var pressure = Cap - (LythonRuntime.CsvRecordSource.ShellBytes - 1);
        context.MemoryGovernor.Reserve(pressure, Span);
        var error = Assert.Throws<LythonRuntimeException>(() =>
            new LythonRuntime.CsvRecordSource(new PyList([]), Options(), Span, context));
        Assert.Equal("MemoryError", error.ExceptionType);
        Assert.Equal(0, context.MemoryGovernor.CurrentCommittedBytes);
        Assert.Equal(pressure, context.MemoryGovernor.CurrentReservedBytes);
        context.MemoryGovernor.ReleaseReserved(pressure);
        Assert.Same(error, Assert.Throws<LythonRuntimeException>(() =>
            new LythonRuntime.CsvRecordSource(new PyList([]), Options(), Span, context)));
        Assert.Equal(0, context.MemoryGovernor.CurrentAccountedBytes);
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static PyString ReadEscapedField(LythonRuntime.CsvRecordSource source)
    {
        Assert.True(source.TryMoveNext(out var row));
        return (PyString)row[0];
    }

    [Fact]
    public void DeniedFieldPayloadAdmissionPreservesCurrentParserStorage()
    {
        var context = Context();
        var governor = context.MemoryGovernor;
        var owner = new LythonRuntime.CsvRecordSource(new PyList([]), Options(), Span, context);
        var parser = Parser(owner);
        parser.Feed("prime\n"u8);
        Assert.True(parser.TryTakeReady(out _)); // Reuse admitted descriptor/queue capacity.
        parser.Feed("\"\n"u8); // Pending quoted field contains one supplied newline.
        var committed = governor.CurrentCommittedBytes;
        var reserved = governor.CurrentReservedBytes;
        // Deny the 129-byte UTF-8 field before its storage is allocated.
        var pressure = Cap - governor.CurrentAccountedBytes - 128;
        governor.Reserve(pressure, Span);

        var error = Assert.Throws<LythonRuntimeException>(() => parser.Feed("\","u8));

        Assert.Equal("MemoryError", error.ExceptionType);
        Assert.Equal(reserved + pressure, governor.CurrentReservedBytes);
        Assert.Equal(committed, governor.CurrentCommittedBytes);
        Assert.True(governor.PeakAccountedBytes <= Cap);
        governor.ReleaseReserved(pressure);
        parser.ResetRecord();
        Assert.Same(error, Assert.Throws<LythonRuntimeException>(() => parser.Feed("ok\n"u8)));
        parser.ReleaseScratch();
        Assert.Equal(0, governor.CurrentReservedBytes);
        GC.KeepAlive(owner);
    }

    [Fact]
    public void DeniedRowBackingAdmissionPreservesRecordWorkingStorage()
    {
        var context = Context();
        var governor = context.MemoryGovernor;
        var owner = new LythonRuntime.CsvRecordSource(new PyList([]), Options(), Span, context);
        var parser = Parser(owner);
        parser.Feed("x,\"\n"u8); // Retained first field and pending newline field.
        var committed = governor.CurrentCommittedBytes;
        var reserved = governor.CurrentReservedBytes;
        // Admit both payload estimates, then deny row backing before any final
        // field payload is allocated. Staged record bytes remain funded.
        var pressure = Cap - governor.CurrentAccountedBytes - (129 + 192 - 1);
        governor.Reserve(pressure, Span);

        var error = Assert.Throws<LythonRuntimeException>(() => parser.Feed("\""u8));

        Assert.Equal("MemoryError", error.ExceptionType);
        Assert.Equal(reserved + pressure, governor.CurrentReservedBytes);
        Assert.Equal(committed, governor.CurrentCommittedBytes);
        Assert.True(governor.PeakAccountedBytes <= Cap);
        governor.ReleaseReserved(pressure);
        parser.ResetRecord();
        Assert.Same(error, Assert.Throws<LythonRuntimeException>(() => parser.Feed("ok\n"u8)));
        parser.ReleaseScratch();
        Assert.Equal(0, governor.CurrentReservedBytes);
        GC.KeepAlive(owner);
    }

    [Fact]
    public void WholeRecordAdmissionPrecedesFinalFieldAllocation()
    {
        var budget = new LythonMemoryBudget(Cap);
        using var owner = budget.CreateScope();
        var context = Context(owner);
        var governor = context.MemoryGovernor;
        var source = new LythonRuntime.CsvRecordSource(new PyList([]), Options(), Span, context);
        var parser = Parser(source);
        parser.Feed("retained\n"u8);
        Assert.True(parser.TryTakeReady(out var previous));
        const int length = 65536;
        parser.Feed(Encoding.UTF8.GetBytes(new string('a', length) + ",\"" + new string('b', length)));
        var committed = governor.CurrentCommittedBytes;
        Assert.True(owner.TryReserve(Cap - budget.ReservedBytes - 70000, out var pressure));
        using (pressure)
        {
            var before = GC.GetAllocatedBytesForCurrentThread();
            var refusal = Assert.Throws<LythonRuntimeException>(() => parser.Feed("\"\n"u8));
            var allocated = GC.GetAllocatedBytesForCurrentThread() - before;
            Assert.Same(governor.AdmissionFailure, refusal);
            Assert.Equal(LythonFailureReason.SharedMemoryAllowance, refusal.Attribution?.Reason);
            Assert.True(allocated < 32768, $"Allocated {allocated} bytes before refusing complete record storage.");
            Assert.Equal(committed, governor.CurrentCommittedBytes);
            Assert.Equal(0, governor.CurrentReservedBytes);
            Assert.False(parser.TryTakeReady(out _));
            Assert.Equal("retained", Assert.IsType<PyString>(previous[0]).AsString());
            parser.ResetRecord();
            Assert.Same(refusal, Assert.Throws<LythonRuntimeException>(() => parser.Feed("ok\n"u8)));
            parser.ReleaseScratch();
        }
        owner.Dispose();
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void PartialRowsStayOwnedUntilTheirExplicitBatchEnds(bool asynchronous)
    {
        var budget = new LythonMemoryBudget(Cap);
        using var owner = budget.CreateScope();
        var context = Context(owner);
        var committed = context.MemoryGovernor.CurrentCommittedBytes;
        var abandoned = AbandonPartialSource(context, asynchronous);
        Assert.True(context.MemoryGovernor.CurrentCommittedBytes > committed);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
        GC.Collect();
        GC.WaitForPendingFinalizers();
        GC.Collect();
        Assert.False(abandoned.TryGetTarget(out _));
        Assert.True(budget.ReservedBytes > committed);
        owner.Dispose();
        Assert.Equal(0, budget.ReservedBytes);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
        GC.KeepAlive(context);
    }

    [Theory]
    [InlineData("x,\"", 64L)]
    [InlineData("a,b,c,d,e,\"", 128L)]
    public void PartialRowsFundTheirCurrentScratchCapacityOnce(string input, long rowBytes)
    {
        var context = Context();
        var owner = new LythonRuntime.CsvRecordSource(new PyList([]), Options(), Span, context);
        var parser = Parser(owner);
        parser.Feed(Encoding.UTF8.GetBytes(input));
        var field = (GovernedByteBuilder)typeof(LythonRuntime.CsvRecordParser)
            .GetField("_record", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(parser)!;
        Assert.Equal(LythonRuntime.CsvRecordSource.ShellBytes + rowBytes + field.CommittedCapacity, owner.OwnedBytes);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
        GC.KeepAlive(owner);
        GC.KeepAlive(parser);
    }

    [Fact]
    public void EmptyPhysicalLinesPublishIndependentlyTrackedRows()
    {
        var context = Context();
        var owner = new LythonRuntime.CsvRecordSource(new PyList([]), Options(), Span, context);
        var parser = Parser(owner);
        parser.Feed(ReadOnlySpan<byte>.Empty);
        Assert.True(parser.TryTakeReady(out var row));
        Assert.Empty(row);
        GC.KeepAlive(owner);
        GC.KeepAlive(row);
    }

    [Fact]
    public void DeniedScratchGrowthKeepsEarlierFundingUntilCleanup()
    {
        var context = Context();
        var governor = context.MemoryGovernor;
        var owner = new LythonRuntime.CsvRecordSource(new PyList([]), Options(), Span, context);
        var parser = Parser(owner);
        parser.Feed("a,b,c,d,\"\n"u8);
        var reserved = governor.CurrentReservedBytes;
        var pressure = Cap - governor.CurrentAccountedBytes - (129 + 128 + 127);
        governor.Reserve(pressure, Span);

        var error = Assert.Throws<LythonRuntimeException>(() => parser.Feed("\""u8));

        Assert.Equal("MemoryError", error.ExceptionType);
        Assert.Equal(reserved + pressure, governor.CurrentReservedBytes);
        Assert.False(parser.TryTakeReady(out _));
        governor.ReleaseReserved(pressure);
        parser.ResetRecord();
        Assert.Same(error, Assert.Throws<LythonRuntimeException>(() => parser.Feed("a,b,c,d,e\n"u8)));
        parser.ReleaseScratch();
        Assert.Equal(0, governor.CurrentReservedBytes);
        Assert.True(governor.PeakAccountedBytes <= Cap);
        GC.KeepAlive(owner);
    }

    [Fact]
    public void ShrinkingScratchCannotSpendAnotherReservationsFunding()
    {
        var governor = new MemoryGovernor(new LythonMemoryBudget(Cap));
        governor.Reserve(128, Span);
        using var scratch = governor.ReserveTemporary(96, Span);
        scratch.Shrink(64);
        Assert.Equal(160, governor.CurrentReservedBytes);
        Assert.Throws<InvalidOperationException>(() => scratch.Shrink(64));
        Assert.Equal(160, governor.CurrentReservedBytes);
        scratch.Dispose();
        Assert.Equal(128, governor.CurrentReservedBytes);
        governor.ReleaseReserved(128);
        Assert.Equal(0, governor.CurrentReservedBytes);
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static WeakReference<LythonRuntime.CsvRecordSource> AbandonPartialSource(
        LythonRuntime.ExecutionContext context, bool asynchronous)
    {
        var source = new LythonRuntime.CsvRecordSource(
            new PyList(new object[] { PyString.FromString("x,\""), 42 }), Options(), Span, context);
        var error = asynchronous
            ? Assert.Throws<LythonRuntimeException>(() => source.TryMoveNextAsync().GetAwaiter().GetResult())
            : Assert.Throws<LythonRuntimeException>(() => source.TryMoveNext(out _));
        Assert.Equal("Error", error.ExceptionType);
        return new(source);
    }

    private static LythonRuntime.CsvRecordParser Parser(LythonRuntime.CsvRecordSource source)
        => (LythonRuntime.CsvRecordParser)typeof(LythonRuntime.CsvRecordSource)
            .GetField("_parser", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(source)!;

    private static LythonRuntime.ExecutionContext Context(ILythonMemoryBudget? budget = null) => new(new MockLythonHost(),
        new LythonRunOptions { MemoryBudget = budget ?? new LythonMemoryBudget(Cap) },regexProvider:Utf8RegexProvider.Instance);

    private static LythonRuntime.CsvOptions Options() => new(PyStringOps.CommaLiteral,
        PyString.FromString("\""), LythonRuntime.CsvQuotingMode.Minimal, true, null,
        false, PyString.FromString("\n"), false);
}
