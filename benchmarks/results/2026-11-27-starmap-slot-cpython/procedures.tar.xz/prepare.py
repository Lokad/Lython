from hashlib import sha256
from pathlib import Path
import gzip
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
previous = lab.with_name('compiled-prefix-search-20261126')
source = lab.with_name('staged-list-yield-20261127') / 'local'
quiet = lab / 'comparison/quiet'
quiet.mkdir(parents=True)
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda b: sha256(b).hexdigest()
sha = lambda p: digest(p.read_bytes())
write = lambda p,x: p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
reference = read(source/'identity.json')
revision = subprocess.check_output(['git','rev-parse','489fde50e'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','diff','origin/master','HEAD','--','src'],cwd=repo)
assert subprocess.check_output(['git','diff','--binary',reference['sourceRevision'],revision,'--','src'],cwd=repo)==(source/'candidate.patch').read_bytes()
assert sha(source/'candidate.patch') == reference['sourcePatchSHA256']
files = reference['imageFiles']['candidate']
core='Lokad.Lython.dll'
assert len(files)==32 and {p.name:sha(p) for p in (source/'candidate').iterdir()}==files
proof=read(source/'candidate-verify.json')
assert proof['caseCount']==4 and proof['state']=='Completed' and proof['catalogSha256']==reference['catalogs']['representative.json']['sha256']
assert proof['launched']['library']['sha256']==files[core]
for name in ('representative.json','cpython-worker.py','candidate-verify.json'):
    shutil.copyfile(source/name,quiet/name)
for name in ('collect.py','summarize.py','run.sh'):
    content=(previous/'comparison/quiet'/name).read_text(encoding='utf-8').replace('lython-b1815-fixtures','lython-b1823-fixtures')
    (quiet/name).write_text(content,encoding='utf-8',newline='\n')
assert b'\r' not in (quiet/'run.sh').read_bytes()
assert sha(quiet/'cpython-worker.py')==reference['cpythonWorkerSHA256']==sha(repo/'benchmarks/cpython-worker.py')
assert sha(quiet/'representative.json')==reference['catalogs']['representative.json']['sha256']
short='diagnostic.shipment-starmap-short-lists'
wide='diagnostic.shipment-starmap-wide-lists'
zip_report='diagnostic.shipment-bound-starmap'
map_report='diagnostic.shipment-file-fed-map'
assert {row['id'] for row in read(quiet/'representative.json')['cases']}=={short,wide,zip_report,map_report}
write(quiet/'jobs.json',[[wide,'warm'],[short,'warm-async'],[zip_report,'warm-async'],[wide,'warm-async'],[map_report,'warm-async'],[wide,'compile-run']])
last=read(repo/'benchmarks/results/2026-11-27-compiled-prefix-cpython/identity.json')
preview=read(previous/'vm-duplicate-preview-b1822.json')
eligible=[c for c in preview['result']['results'] if c['eligible']]
assert len(eligible)==1
reclaim=next(c for c in preview['configuration']['choices'] if c['root']==eligible[0]['root'])
assert reclaim['root']=='unified-builtin-operands-b1714-20261125'
assert digest(gzip.decompress(Path(reclaim['backup']).read_bytes()))==reclaim['image'][core]
archived=subprocess.check_output(['git','show','origin/master:benchmarks/results/2026-11-25-unified-builtin-operands/quiet-observations.tar.xz'],cwd=repo)
assert digest(archived)==reclaim['archive']
duplicate=lab.with_name('unified-builtin-operands-20261125')/'candidate'
assert {p.name:sha(p) for p in duplicate.iterdir()}==reclaim['image']
assert preview['configuration']['donorArchive']==last['donorArchiveSHA256']
aux={name:value for name,value in files.items() if name!=core}
assert all(preview['configuration']['donorFiles'][name]==value for name,value in aux.items())
stage='starmap-slot-cpython-b1823-20261127'
identity=dict(sourceRevision=revision,productionSource=revision,candidate=revision,
    frozenImage=f'/home/lokad/lython-bench-checks/{stage}/candidate',auxiliaryFiles=aux,
    imageFiles={'candidate':files},coreSHA256={r:files[core] for r in ('candidate','candidate-control')},
    cpythonWorkerSHA256=reference['cpythonWorkerSHA256'],expectedCPythonSHA256=last['expectedCPythonSHA256'],
    donorArchiveSHA256=last['donorArchiveSHA256'],sourcePatchSHA256=reference['sourcePatchSHA256'],
    catalogs={n:{'sha256':sha(quiet/n)} for n in ('representative.json','jobs.json')},priorExternalSource=last['sourceRevision'],
    purpose='Compare the fully qualified starmap generator-slot handoff against CPython on shipment, bound zip and file-fed map.')
write(quiet/'identity.json',identity)
names=('identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py')
payload=quiet/'stage.tar.gz'
sources={name:quiet/name for name in names}
sources['candidate/'+core]=source/'candidate'/core
with tarfile.open(payload,'w:gz',compresslevel=6) as bundle:
    for name,path in sources.items():
        bundle.add(path,arcname=name,recursive=False)
frame={name:{'length':path.stat().st_size,'sha256':sha(path)} for name,path in sources.items()}
write(quiet/'upload.json',dict(root=stage,payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size,
      expandedBytes=sum(x['length'] for x in frame.values()),minimumAfterStageBytes=4_800_000,
      files=frame,reclaim=reclaim,donor=preview['configuration']['donor'],
      donorFiles=preview['configuration']['donorFiles'],donorArchive=last['donorArchiveSHA256']))
print(f'{revision}: {sum(x["length"] for x in frame.values()):,} B streamed expanded; {payload.stat().st_size:,} B compressed')