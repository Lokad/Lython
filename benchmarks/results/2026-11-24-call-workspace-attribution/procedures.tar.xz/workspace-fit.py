from pathlib import Path
import json, re

lab = Path(__file__).resolve().parent
data = json.loads((lab/'compiled-shapes.json').read_text(encoding='utf-8'))
leaves = [
    ('for_policy',), ('make_rules','alternate'), ('make_rules',),
    ('words_from_line',), ('price_line',), ('compile_rule',),
]
rows = []
for i, case in enumerate(data['rows']):
    code_size = {code['name']:code['capacity'] for code in case['codes']}
    source = json.loads((lab/f'case-{i}.json').read_text(encoding='utf-8'))['cases'][0]['source'].splitlines()
    for owner in case['codes']:
        for site, call in enumerate(owner['calls']):
            start, length, line, _ = map(int,re.findall(r'= (\d+)',call['span']))
            callee = next((name for name in leaves[i] if name+'(' in source[line-1]),None)
            if callee is None: continue
            matched = [op for op in owner['tape'] if op['<Span>k__BackingField']['Start']==start
                       and op['<Span>k__BackingField']['Length']==length and op['_primaryOperand']==site
                       and op['<OpCode>k__BackingField']==42]
            assert len(matched)==1, (line,site,matched)
            op = matched[0]
            capacity = owner['capacity']-op['_resultSlot']-call['offset']
            rows.append(dict(case=case['id'],caller=owner['name'],callee=callee,line=line,
                existingOperandWindow=capacity,calleeSlots=code_size[callee],capacityDelta=max(0,code_size[callee]-capacity)))
print(json.dumps(rows,indent=2))
(lab/'workspace-fit.json').write_text(json.dumps(dict(coreSHA256=data['coreSHA256'],rows=rows),indent=2)+'\n',encoding='utf-8')
