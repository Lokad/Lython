from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
donor = lab.with_name('native-completed-call-workspace-20261124')
comparison = donor/'comparison'
image = lab/'image'
image.mkdir(exist_ok=True)
identity = json.loads((comparison/'identity.json').read_text(encoding='utf-8'))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
files = identity['imageFiles']['candidate'] | identity['helperFiles']
for name, expected in files.items():
    source = donor/'candidate'/name
    assert digest(source) == expected
    shutil.copyfile(source,image/name)
core = 'Lokad.Lython.dll'
shutil.copyfile(lab/'build/bin/Lokad.Lython/release_net11.0'/core,image/core)
files[core] = digest(image/core)
assert all(digest(image/name)==expected for name, expected in files.items())

catalog = json.loads((comparison/'representative.json').read_text(encoding='utf-8'))
additional = json.loads((lab.with_name('native-callable-definition-20261124')/'comparison/representative.json').read_text(encoding='utf-8'))
annotated, = (case for case in additional['cases'] if case['id']=='scripts.annotated-rule-closures')
cases = [*catalog['cases'], annotated]
dotnet = Path.home()/'.dotnet11/dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
results = {}
for index, case in enumerate(cases):
    incoming = lab/f'case-{index}.json'
    allocation = lab/f'allocation-{index}.json'
    incoming.write_text(json.dumps(catalog | {'cases': [case]},ensure_ascii=False), encoding='utf-8',newline='\n')
    process = subprocess.run([dotnet,image/'ValidatedAllocation.dll',image,incoming,allocation],
                             env=env,capture_output=True,encoding='utf-8',timeout=40)
    assert process.returncode==0,(process.stdout,process.stderr)
    raw = process.stderr
    (lab/f'route-{index}.txt').write_text(raw,encoding='utf-8',newline='\n')
    proof, = json.loads(allocation.read_text(encoding='utf-8'))['rows']
    assert proof['id']==case['id'] and proof['sharedBudgetBaselineRestored']
    rows = []
    for entry in raw.splitlines():
        tag, route, name, count = entry.split('\t')
        assert tag=='LYTHON_CALL_ROUTE'
        rows.append(dict(route=route, function=name, count=int(count)))
    results[case['id']] = rows
    print(case['id'],flush=True)
    for row in rows:
        print(' ', row['route'],row['function'],row['count'],flush=True)
assert all(digest(image/name)==expected for name, expected in files.items())
(lab/'route-counts.json').write_text(json.dumps(dict(source='489d3a3f6',image=files,cases=results),indent=2)+'\n',
                                      encoding='utf-8',newline='\n')
