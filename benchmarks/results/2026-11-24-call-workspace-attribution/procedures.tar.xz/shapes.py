from pathlib import Path
import hashlib, json, shutil, subprocess

lab = Path('.git/agent-notes/review-20261031/call-boundary-attribution-20261124').resolve()
src = lab.with_name('closed-definition-return-20261123')/'inspect/build/bin/Inspect/release_net11.0'
tools = lab/'inspector'
tools.mkdir(exist_ok=True)
for name in ('Inspect.dll','Inspect.deps.json','Inspect.runtimeconfig.json'):
    shutil.copyfile(src/name,tools/name)
core = tools/'Lokad.Lython.dll'
shutil.copyfile(lab/'exact/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll',core)
cases = [json.loads((lab/f'case-{i}.json').read_text(encoding='utf-8'))['cases'][0] for i in range(6)]
catalog = tools/'catalog.json'
catalog.write_text(json.dumps({'cases':cases},ensure_ascii=False),encoding='utf-8')
out = lab/'compiled-shapes.json'
subprocess.run([Path.home()/'.dotnet11/dotnet.exe',tools/'Inspect.dll',catalog,out],check=True,timeout=30)
rows = json.loads(out.read_text(encoding='utf-8-sig'))
assert rows['coreSHA256']==hashlib.sha256(core.read_bytes()).hexdigest()
for row in rows['rows']:
    print(row['id'])
    for code in row['codes']:
        print(code['name'],'slots',code['capacity'],'tape',code['instructions'])
        if code['calls']:
            print(*[(call['span'],call['count'],call['deadTailCapacity']) for call in code['calls']],sep='\n  ')
