from pathlib import Path

repo = Path.cwd()
runtime = repo/'.git/agent-worktrees/regex-wrapper-cache-20261124/src/Lokad.Lython/Runtime'
calls = runtime/'LythonRuntime.Executable.Calls.cs'
functions = runtime/'PyExecutableFunction.cs'

def edit(path, replacements):
    source = path.read_text(encoding='utf-8')
    for old, new in replacements:
        assert source.count(old)==1, old
        source = source.replace(old, new)
    path.write_text(source,encoding='utf-8',newline='\n')


instrumentation = """
    private static class CallRouteCounts
    {
        private static readonly System.Collections.Concurrent.ConcurrentDictionary<(string Route, string Name), int> Counts = new();

        static CallRouteCounts()
        {
            AppDomain.CurrentDomain.ProcessExit += (_, _) =>
            {
                foreach (var entry in Counts.OrderBy(item => item.Key.Route).ThenBy(item => item.Key.Name))
                    Console.Error.WriteLine($"LYTHON_CALL_ROUTE\t{entry.Key.Route}\t{entry.Key.Name}\t{entry.Value}");
            };
        }

        internal static void Add(string route, string name)
            => Counts.AddOrUpdate((route, name), 1, static (_, count) => count + 1);
    }

    internal static void CountCallRoute(string route, string name) => CallRouteCounts.Add(route, name);
"""
edit(calls, [
    ("    internal sealed partial class ExecutionContext\n", instrumentation+"\n    internal sealed partial class ExecutionContext\n"),
    ("            var ordinaryCall = site is not null;","            CountCallRoute(\"general-binding\", function.Name);\n            var ordinaryCall = site is not null;"),
    ("            scope.EnterInterpreterFrame(site.CallSpan);\n            BoundFunctionArguments bound = default;",
     "            CountCallRoute(\"deferred-child-binding\", function.Name);\n            scope.EnterInterpreterFrame(site.CallSpan);\n            BoundFunctionArguments bound = default;"),
    ("            var scope = function.DefinitionContext;\n            scope.EnterFunctionCall(span);",
     "            CountCallRoute(\"borrowed-activation\", function.Name);\n            var scope = function.DefinitionContext;\n            scope.EnterFunctionCall(span);"),
])
edit(functions, [
    ("        if (suppliedInteger) return true;","        if (suppliedInteger)\n        {\n            LythonRuntime.CountCallRoute(\"supplied-completion\", Name);\n            return true;\n        }"),
    ("        return completePositional\n", "        var completed = completePositional\n"),
    ("out result);\n    }\n\n    [System.Runtime.CompilerServices.InlineArray", "out result);\n        if (completed) LythonRuntime.CountCallRoute(completePositional ? \"definition-completion\" : \"default-completion\", Name);\n        return completed;\n    }\n\n    [System.Runtime.CompilerServices.InlineArray"),
    ("        NativeValues buffer = default;\n        Span<LythonRuntime.ExecutableSlot> values = buffer;\n        values = values[..CodeObject.ValueStorageCapacity];",
     "        LythonRuntime.CountCallRoute(\"native-workspace\", Name);\n        NativeValues buffer = default;\n        Span<LythonRuntime.ExecutableSlot> values = buffer;\n        values = values[..CodeObject.ValueStorageCapacity];"),
    ("        var state = new LythonRuntime.NativeExecution(this, values, consumedByIteration, unpackedReturn.Length);",
     "        LythonRuntime.CountCallRoute(existing is null ? \"native-private-body\" : \"native-bound-body\", Name);\n        var state = new LythonRuntime.NativeExecution(this, values, consumedByIteration, unpackedReturn.Length);"),
    ("            state.PrepareTransfer();","            LythonRuntime.CountCallRoute(\"native-promotes\", Name);\n            state.PrepareTransfer();"),
])
