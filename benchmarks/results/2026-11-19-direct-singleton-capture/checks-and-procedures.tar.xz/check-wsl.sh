set -e
cd /mnt/d/code/Lython/.git/agent-worktrees/direct-singleton-capture-r643
export PATH="$HOME/.dotnet:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/direct-singleton-capture-r643
filter='(FullyQualifiedName~LambdaExecutable|FullyQualifiedName~Closure|FullyQualifiedName~MutableCapture|FullyQualifiedName~Nonlocal|FullyQualifiedName~ComprehensionLambda|FullyQualifiedName~Generator|FullyQualifiedName~ClassCell|FullyQualifiedName~GovernedMemoryContract)&Category!=Stress'
for project in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$logs/$project-wsl-net10.log"
    code=0
    dotnet test "tests/$project" -c Release -f net10.0 --artifacts-path "$PWD/tests/artifacts/r643-wsl" --filter "$filter" > "$log" 2>&1 || code=$?
    if [ "$code" != 0 ]; then tail -25 "$log"; exit "$code"; fi
    tail -4 "$log"
done
