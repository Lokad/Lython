set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
repo=/mnt/d/code/Lython
lab="$repo/.git/agent-notes/review-20261031/current-short-script-profile-20261127"
source="$repo/.git/agent-notes/review-20261031/compiled-prefix-search-20261126"
work=$(mktemp -d "$HOME/lython-starmap-rows-XXXXXX")
printf '%s\n' "$work" > "$lab/ubuntu-source.txt"
tar -xf "$source/test-source.tar" -C "$work"
cd "$work"
while IFS= read -r part; do
    part=$(printf '%s' "$part" | tr -d '\r')
    cp "$repo/$part" "$part"
    cmp "$repo/$part" "$part"
done < "$source/changed-files.txt"
for part in src/Lokad.Lython/Runtime/Calls/CallExpansion.cs src/Lokad.Lython/Runtime/PyIteration.cs src/Lokad.Lython/Runtime/PyItertools.Transforms.cs tests/Lokad.Lython.PublicApi.Tests/StarmapMaterializationParityTests.cs; do
    cp "$repo/$part" "$part"
    cmp "$repo/$part" "$part"
done
filter='Category!=Stress&(FullyQualifiedName~Starmap|FullyQualifiedName~Itertools|FullyQualifiedName~CallExpansion|FullyQualifiedName~Invocation|FullyQualifiedName~Generator|FullyQualifiedName~AdmissionFailureCommand)'
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
    log="$lab/starmap-$suite-ubuntu10.log"
    if dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --filter "$filter" > "$log" 2>&1; then tail -7 "$log"; else tail -28 "$log"; exit 1; fi
done
