from pathlib import Path
from hashlib import sha256
from statistics import median
import base64
import importlib.util
import json
import os
import shutil
import subprocess
import tempfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
ref=lab.with_name('compiled-prefix-search-20261126')/'corrected'
shipment=lab.with_name('starmap-frame-inputs-20261126')
run=lab/'iterable-row-lab'
run.mkdir()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda data:sha256(data).hexdigest()
def write(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
core='Lokad.Lython.dll'
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert base.startswith('6cc8e9f50')
for area, name in (('src','candidate.patch'),('tests','regression.patch')):
    (run/name).write_bytes(subprocess.check_output(['git','diff','--binary','HEAD','--',area],cwd=repo))
pinned=read(ref/'identity.json')
files=pinned['imageFiles']['candidate']
assert {p.name:sha(p.read_bytes()) for p in (ref/'candidate').iterdir()}==files and len(files)==32
new=repo/'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0'/core
assert sha(new.read_bytes())==sha((repo/'src/Lokad.Lython/bin/Release/net11.0'/core).read_bytes())
images={}
for role in ('candidate','reference'):
    target=run/role
    shutil.copytree(ref/'candidate',target)
    if role=='candidate':shutil.copyfile(new,target/core)
    images[role]={p.name:sha(p.read_bytes()) for p in target.iterdir()}
assert set(images['reference'])==set(images['candidate']) and images['reference']==files
assert [p for p,x in files.items() if x!=images['candidate'][p]]==[core]
shutil.copyfile(ref/'cpython-worker.py',run/'cpython-worker.py')
assert sha((run/'cpython-worker.py').read_bytes())==pinned['cpythonWorkerSHA256']
spec=importlib.util.spec_from_file_location('protocol',run/'cpython-worker.py')
protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)

catalog=read(ref/'representative.json')
control,=[row for row in read(shipment/'local/representative.json')['cases'] if row['id']=='diagnostic.shipment-starmap-wide-lists']
python=Path('C:/Python313/python.exe')
fixture=''.join(','.join(str((i*j)%97) for j in range(1,6))+'\n' for i in range(1,1025)).encode()
names=[]
rows=[]
for producer,body in (('map','return map(int, line.strip().split(","))'),('generator','for item in line.strip().split(","):\n        yield int(item)')):
    source=f'''from itertools import starmap

def fields(line):
    {body}

def weighted(a, b, c, d, e):
    return a + 2*b + 3*c + 4*d + 5*e

with open('input.csv') as source:
    total = sum(starmap(weighted, (fields(line) for line in source)))
with open('report.txt', 'w', newline='') as report:
    report.write(str(total) + '\\n')
print(total)
'''
    with tempfile.TemporaryDirectory(prefix='lython-iterable-starmap-golden-') as tmp:
        folder=Path(tmp)
        (folder/'input.csv').write_bytes(fixture)
        (folder/'source.py').write_text(source,encoding='utf-8',newline='\n')
        command=subprocess.run([python,'-I','-S','-X','utf8',folder/'source.py'],cwd=folder,capture_output=True,check=True,timeout=10)
        stdout=command.stdout.decode('utf-8').replace('\r\n','\n')
        produced=(folder/'report.txt').read_bytes()
        assert stdout.encode()==produced and not command.stderr
    fixture_json=json.dumps(dict(size=1024,text=None,inputFiles={'input.csv':base64.b64encode(fixture).decode()},
                                 outputFiles={'report.txt':base64.b64encode(produced).decode()}),separators=(',',':'))
    # Reuse the existing fixture schema and its independent output digest.
    expected=protocol.file_fixture(json.loads(fixture_json))[1]
    identifier=f'diagnostic.starmap-iterable-{producer}'
    row=dict(id=identifier,family='starmap-iterable',category='script',scale='large',size=1024,source=source,
             fixtureJson=fixture_json,expectedOutput=stdout,sourceUtf8Bytes=len(source.encode()),expectedOutputUtf8Bytes=len(stdout.encode()),
             fixtureTextUtf8Bytes=None,fixtureTextCodePoints=None,sourceSha256=sha(source.encode()),fixtureSha256=sha(fixture_json.encode()),
             expectedOutputSha256=sha(stdout.encode()),expectedFilesSha256=protocol.file_digest(expected))
    rows.append(row)
    names.append(identifier)
catalog['cases']=[*rows,control]
write(run/'representative.json',catalog)
for name in ('collect.py','run.sh'):
    source=(ref/name).read_text(encoding='utf-8')
    if name=='collect.py':source=source.replace("assert len(jobs) == 3 and","assert len(jobs) == 5 and").replace('lython-compiled-prefix-fixture-','lython-iterable-starmap-fixture-')
    (run/name).write_text(source,encoding='utf-8',newline='\n')
assert b'\r' not in (run/'run.sh').read_bytes()
write(run/'jobs.json',{'warm':[[names[0],'warm-async'],[control['id'],'warm-async'],[names[1],'warm-async'],[names[0],'warm'],[names[1],'warm']]})
identity=dict(sourceRevision=base,sourcePatchSHA256=sha((run/'candidate.patch').read_bytes()),imageFiles=images,
              cpythonWorkerSHA256=pinned['cpythonWorkerSHA256'],coreSHA256={role+suffix:im[core] for role,im in images.items() for suffix in ('','-control')},
              catalogs={name:{'sha256':sha((run/name).read_bytes())} for name in ('representative.json','jobs.json')},
              purpose='Test one admitted dynamic starmap argument accumulator on file-fed mapped and generated rows with an exact-row control.')
write(run/'identity.json',identity)
text=(ref.parent/'summarize.py').read_text(encoding='utf-8').replace("lab / 'local'","lab / 'iterable-row-lab'")
compile(text,'summarize-starmap.py','exec')
(lab/'summarize-starmap.py').write_text(text,encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11';dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role, im in images.items():
    report=run/f'{role}-verify.json'
    subprocess.run([dotnet,run/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',run/'representative.json',
                    '--dotnet',dotnet,'--python',python,'--python-worker',run/'cpython-worker.py','--out',report],cwd=repo,env=env,check=True,timeout=40)
    checked=read(report)
    assert checked['caseCount']==3 and checked['state']=='Completed'
    assert checked['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert checked['launched']['library']['sha256']==im[core]
    diagnostic=run/f'{role}-allocated'
    shutil.copytree(run/role,diagnostic)
    for path in (ref.parent/'candidate-allocated').glob('ValidatedAllocation*'):
        shutil.copyfile(path,diagnostic/path.name)
    assert all(sha((diagnostic/p).read_bytes())==h for p,h in im.items())
all_allocations=[]
for mode in ('sync','async'):
    for case in catalog['cases']:case['runAsync']=mode=='async'
    selected=run/f'{mode}-allocation-catalog.json'
    write(selected,catalog)
    values=[]
    for role in ('reference','candidate'):
        diagnostic=run/f'{role}-allocated'
        receipt=run/f'{role}-{mode}-allocation.json'
        subprocess.run([dotnet,diagnostic/'ValidatedAllocation.dll',diagnostic,selected,receipt],env=env,check=True,timeout=75)
        values.append(read(receipt)['rows'])
    for before,after in zip(*values,strict=True):
        assert before['id']==after['id'] and before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
        entry=dict(case=before['id'],mode=mode,clr=[median(r['allocatedBytesPerInvocation']) for r in (before,after)],peak=[r['peakExecutionMemoryBytes'] for r in (before,after)])
        all_allocations.append(entry)
        print(entry,flush=True)
write(run/'allocation-summary.json',all_allocations)
