set -eu
export DOTNET_ROOT=/home/vermorel/.dotnet
export DOTNET_ROOT_X64=$DOTNET_ROOT
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/early-cased-split-20261123
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu-public" --filter 'FullyQualifiedName~Cased|FullyQualifiedName~TrimmedSplit|FullyQualifiedName~NativeWordBinding|FullyQualifiedName~NativeFunction|FullyQualifiedName~FailureProjection|FullyQualifiedName~NativeTruthiness|FullyQualifiedName~ExecutableCache|FullyQualifiedName~MemberCall'
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu-white" --filter 'FullyQualifiedName~Cased|FullyQualifiedName~ClosureSequence|FullyQualifiedName~Whitespace|FullyQualifiedName~Executable|FullyQualifiedName~TrimmedSplit'
