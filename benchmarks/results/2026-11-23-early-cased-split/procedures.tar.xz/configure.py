from pathlib import Path

lab = Path(__file__).resolve().parent
prior = lab.with_name('module-failure-bindings-20261123')


def adapt(name, substitutions):
    src = (prior / name).read_text(encoding='utf-8')
    for before, after in substitutions:
        assert src.count(before) == 1, (name, before)
        src = src.replace(before, after)
    compile(src, str(lab / name), 'exec')
    (lab / name).write_text(src, encoding='utf-8', newline='\n')


adapt('prepare.py', (
    ('tree=repo\n', "tree=repo/'.git/agent-worktrees/early-cased-split-20261123'\n"),
    ("donor=notes/'plain-class-fixed-20261123'", "donor=notes/'module-failure-bindings-20261123'"),
    ("reference,candidate=git('rev-parse','0112138c1'),git('rev-parse','e4392967b')",
     "reference,candidate=git('rev-parse','e4392967b'),git('rev-parse','HEAD',cwd=tree)"),
    ("assert reference.startswith('0112138c1')", "assert reference.startswith('e4392967b')"),
    ("assert not git('diff','--name-only',candidate,'HEAD','--','src','tests')",
     "assert not git('diff','--name-only',reference,'HEAD','--','src','tests')"),
    ("    'scripts.config-manifest.small',", "    'diagnostic.text-summary.borrowed-cased-words.mixed-width',\n"
                                           "    'scripts.ordinary-fully-supplied-helper.local-function',"),
    ('B1536 benchmark controls for the corrected public module lifetime',
     'B1537 start a prepared cased split at member lookup'),
))
adapt('prepare-jobs.py', (
    ('quote,short,manifest=', 'quote,short,mixed,supplied='),
    ("jobs=[(quote['id'],'warm'),(short['id'],'warm'),(manifest['id'],'compile-run')]",
     "jobs=[(short['id'],'warm'),(mixed['id'],'warm'),(quote['id'],'warm'),(supplied['id'],'warm')]"),
))
adapt('stage.py', (
    ('module-failure-bindings-b1536-20261123', 'early-cased-split-b1537-20261123'),
    ('plain-class-namespace-b1533-20261123', 'module-failure-bindings-b1536-20261123'),
    ('lython-b1536-fixtures', 'lython-b1537-fixtures'),
    ('len(jobs) == 3', 'len(jobs) == 4'),
    ('< 190,', '< 235,'),
))
adapt('quiet.py', (
    ('lython-b1536-module-failure-bindings-20261123', 'lython-b1537-early-cased-split-20261123'),
    ('.+b1536-', '.+b1537-'),
    ('lython-b1536-stage-', 'lython-b1537-stage-'),
    ('Three bounded lanes write under 1 MiB of receipts. A 20 MiB',
     'Four bounded lanes write under 1 MiB of receipts. A 15 MiB'),
    ('20 * 1024 * 1024', '15 * 1024 * 1024'),
    ('RuntimeMaxSec=230', 'RuntimeMaxSec=270'),
    ('seconds=150', 'seconds=196'),
))
adapt('summarize.py', (
    ('== 3\nassert hashlib', '== 4\nassert hashlib'), ('len(warm["jobs"])==3', 'len(warm["jobs"])==4'),
    ('timedBatches=84', 'timedBatches=112'),
))
(lab / 'verified-replicas.json').write_text('[]\n', encoding='utf-8', newline='\n')
