from pathlib import Path
import hashlib,json

lab=Path(__file__).resolve().parent
comparison=lab/'comparison'
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
quote,short,mixed,supplied=read(comparison/'representative.json')['cases']
jobs=[(short['id'],'warm'),(mixed['id'],'warm'),(quote['id'],'warm'),(supplied['id'],'warm')]
write(comparison/'jobs.json',{'warm':jobs})
proof=read(comparison/'identity.json')
proof['catalogs']['jobs.json']={'sha256':hashlib.sha256((comparison/'jobs.json').read_bytes()).hexdigest()}
proof['coreSHA256']={label:files['Lokad.Lython.dll'] for role,files in proof['imageFiles'].items()
    for label in (role,role+'-control')}
write(comparison/'identity.json',proof)
