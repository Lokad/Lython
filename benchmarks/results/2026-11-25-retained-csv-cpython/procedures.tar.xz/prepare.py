from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.with_name("csv-read-completed-prefix-20261125")
previous=lab.with_name("retained-async-cpython-20261125")
quiet=lab/"external"
quiet.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
digest=lambda data:hashlib.sha256(data).hexdigest()
sha=lambda p:digest(p.read_bytes())
def write(p,text):
    p.write_text(text,encoding="utf-8",newline="\n")
def save(p,value):
    write(p,json.dumps(value,ensure_ascii=False,indent=2)+"\n")
def git(*args):
    return subprocess.check_output(["git",*args],cwd=repo)

source=git("rev-parse","96d54066a").decode().strip()
assert git("diff","--name-only",source,"HEAD","--","src","benchmarks/cpython-worker.py","benchmarks/Lokad.Lython.Benchmarks")==b""
sealed=donor/"comparison/quiet"
baseline=read(sealed/"identity.json")
patch=git("diff","--binary",baseline["comparisonRevision"],source,"--","src")
assert patch==(donor/"candidate.patch").read_bytes() and digest(patch)==baseline["sourcePatchSHA256"]
files=baseline["imageFiles"]["candidate"]
assert len(files)==32
assert {p.name:sha(p) for p in (donor/"candidate").iterdir()}==files
image=lab/"candidate"
image.mkdir(exist_ok=True)
for name in files: shutil.copyfile(donor/"candidate"/name,image/name)
assert {p.name:sha(p) for p in image.iterdir()}==files
terminal=read(sealed/"terminal-status.json")
assert terminal["receipt"]["complete"] and sha(sealed/"observations.tar.xz")==terminal["receipt"]["archiveSHA256"]
location="retained-csv-cpython-b1705-20261125"
reference=read(sealed/"upload.json")["root"]

old=read(previous/"external/identity.json")
assert old["expectedCPythonSHA256"]==baseline["expectedCPythonSHA256"]
assert old["auxiliaryFiles"]=={name:value for name,value in files.items() if name!="Lokad.Lython.dll"}
catalog=read(previous/"external/representative.json")
cases={c["id"]:c for c in catalog["cases"]}
fed="diagnostic.shipment-file-fed-map"
cases[fed]=next(c for c in read(sealed/"representative.json")["cases"] if c["id"]==fed)
ship="diagnostic.shipment-routing-callbacks"
rules="scripts.rule-default-closures"
plain="diagnostic.generated-ordinary-definitions"
invoice="scripts.csv-invoice.method-policy.quoted-control"
jobs=[(fed,"warm-async"),(plain,"warm"),(ship,"warm-async"),(rules,"compile"),
      (invoice,"warm"),(ship,"warm"),(plain,"compile"),(rules,"compile-run"),
      (ship,"compile-run"),(plain,"compile-run")]
catalog["cases"]=[cases[name] for name in (ship,rules,plain,invoice,fed)]
save(quiet/"representative.json",catalog)
save(quiet/"jobs.json",jobs)
core=files["Lokad.Lython.dll"]
identity=dict(sourceRevision=source,candidate=source,productionSource=source,imageFiles={"candidate":files},
              frozenImage="/home/lokad/lython-bench-checks/"+location+"/candidate",
              auxiliaryFiles=old["auxiliaryFiles"],coreSHA256={"candidate":core,"candidate-control":core},
              expectedCPythonSHA256=baseline["expectedCPythonSHA256"],cpythonWorkerSHA256=baseline["cpythonWorkerSHA256"],
              auxiliaryImageReference="B1704",productionBuild="B1704 nonincremental Release core. The exact source patch is committed.",
              sourcePatchSHA256=digest(patch),sourcePatchBase=baseline["comparisonRevision"],
              catalogs={name:dict(sha256=sha(quiet/name)) for name in ("representative.json","jobs.json")})
save(quiet/"identity.json",identity)
protocol=repo/"benchmarks/cpython-worker.py"
assert sha(protocol)==identity["cpythonWorkerSHA256"]
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
evidence=quiet/"candidate-verify.json"
subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",quiet/"representative.json",
    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",evidence],
    cwd=repo,env=env,check=True,timeout=80)
report=read(evidence)
assert report["state"]=="Completed" and report["caseCount"]==5
assert report["launched"]["library"]["sha256"]==core and report["catalogSha256"]==identity["catalogs"]["representative.json"]["sha256"]
assert {p.name:sha(p)for p in image.iterdir()}==files

shutil.copyfile(previous/"external/run.sh",quiet/"run.sh")
assert b"\r" not in (quiet/"run.sh").read_bytes()
collect=(previous/"external/collect.py").read_text(encoding="utf-8").replace("b1685c-fixtures","b1705-fixtures")
collect=collect.replace("len(jobs) == 11","len(jobs) == 10").replace("Production CPython checkpoint for shared locals and borrowed callback returns",
      "Production CPython checkpoint after inline completed CSV reads")
summary=(previous/"external/summarize.py").read_text(encoding="utf-8").replace('len(raw["jobs"])==11','len(raw["jobs"])==10').replace(
    'receipt["warmJobs"]==11','receipt["warmJobs"]==10')
for name,text in (("collect.py",collect),("summarize.py",summary)):
    compile(text,name,"exec")
    write(quiet/name,text)
launch=(previous/"quiet.py").read_text(encoding="utf-8").replace("b1694c","b1705").replace("lython-b1705-retained-defaults-cpython",
    "lython-b1705-retained-csv-cpython")
anchor="assert donor['archiveSHA256']=='"
i=launch.index(anchor)
j=launch.index("\n",i)
launch=launch[:i]+f"assert donor['archiveSHA256']=={terminal['receipt']['archiveSHA256']!r}"+launch[j:]
launch=launch.replace("seconds=385","seconds=360").replace("RuntimeMaxSec=480","RuntimeMaxSec=435")
compile(launch,"quiet.py","exec")
write(lab/"quiet.py",launch)
archiver=(previous/"archive.py").read_text(encoding="utf-8").replace("2026-11-25-retained-async-cpython","2026-11-25-retained-csv-cpython").replace(
    'summary["timedBatches"] == 308 and len(summary["rows"]) == 11','summary["timedBatches"] == 280 and len(summary["rows"]) == 10').replace("Archived 308","Archived 280")
write(lab/"archive.py",archiver)
payload=quiet/"payload.tar.gz"
with tarfile.open(payload,"w:gz",compresslevel=3) as bundle:
    for name in ("identity.json","jobs.json","representative.json","collect.py","run.sh"):
        bundle.add(quiet/name,arcname=name)
save(quiet/"upload.json",dict(root=location,reference=reference,payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
save(lab/"verified-raw-replicas.json",[])
print("Ten production phases and five independent CPython goldens verified.")
