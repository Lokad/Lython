from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
comparison=lab/'comparison'
quiet=comparison/'quiet'
dest=repo/'benchmarks/results/2026-11-23-closed-definition-return'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
identity=read(comparison/'identity.json')
terminal=read(quiet/'terminal-status.json')
assert terminal['exitCode']=='0' and read(quiet/'summary.json')['timedBatches']==168
assert all(terminal['receipt'][key] for key in ('archivedAndVerifiedUnderLease','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter'))
assert sha((quiet/'observations.tar.xz').read_bytes())==terminal['receipt']['archiveSHA256']
assert len(read(lab/'selected-returns.json'))==3
for role,files in identity['imageFiles'].items():
    assert len(files)==32
    assert all(sha((lab/role/name).read_bytes())==digest for name,digest in files.items())
dest.mkdir(exist_ok=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,encoding='utf-8').strip()
retained=not subprocess.check_output(['git','diff','--name-only',head,identity['candidate'],'--','src','tests'],cwd=repo)
patch=subprocess.check_output(['git','diff','--binary',identity['sourceRevision'],identity['candidate'],'--','src','tests'],cwd=repo)
(comparison/'production.patch').write_bytes(patch)
(dest/'identity.json').write_text(json.dumps(dict(identity,retainedRevision=head if retained else None,
    productionPatchSHA256=sha(patch)),indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ('terminal-status.json','observations.tar.xz','summary.json'):
    shutil.copyfile(quiet/name,dest/name)
for name in ('allocation-summary-six.json','selected-returns.json','jit-summary.json'):
    shutil.copyfile(lab/name,dest/name)
for role in ('reference','candidate'):
    core=(lab/role/'Lokad.Lython.dll').read_bytes()
    blob=gzip.compress(core,mtime=0)
    assert sha(gzip.decompress(blob))==identity['coreSHA256'][role]
    (dest/(role+'-core.dll.gz')).write_bytes(blob)
with tarfile.open(dest/'procedures.tar.xz','w:xz') as archive:
    for name in ('archive.py','freeze.py','quiet.py','quiet-first.py','stage.py','summarize.py','allocations.py','prototype.py',
                 'test-platform.py','first-test-platform.py','windows-white.log','windows-public.log','ubuntu-white.log','ubuntu-public.log',
                 'first-windows-public.log','first-ubuntu-public.log','reference-allocation-six.json','candidate-allocation-six.json',
                 'comparison/reference-verify.json','comparison/candidate-verify.json','comparison/production.patch',
                 'launch-first.log','launch.log','retrieval.log','comparison/quiet/observe-not-before',
                 'inspect-shapes.py','inspect/Program.cs','inspect/Inspect.csproj','reference-executable.json','candidate-executable.json',
                 'inspect-jit.py','reference-native.asm','candidate-native.asm'):
        archive.add(lab/name,arcname=name,recursive=False)
print(dest,'retained' if retained else 'private')
