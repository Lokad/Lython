from pathlib import Path
import json,os,hashlib,subprocess,shutil
p=Path('.git/agent-notes/review-20261031/closed-definition-return-20261123')
read=lambda file:json.loads(file.read_text(encoding='utf-8'))
image=read(p/'comparison/identity.json')
dotnet=Path.home()/'.dotnet11/dotnet.exe'
shapes={}
for role in ('reference','candidate'):
    target=p/role
    for name in ('Inspect.dll','Inspect.deps.json','Inspect.runtimeconfig.json'):
        shutil.copyfile(p/'inspect/build/bin/Inspect/release_net11.0'/name,target/name)
    report=p/(role+'-executable.json')
    subprocess.run([dotnet,target/'Inspect.dll',p/'representative.json',report],check=True,timeout=20,
        env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent)))
    data=read(report)
    assert data['coreSHA256']==image['coreSHA256'][role]
    for name,sha in image['imageFiles'][role].items():
        assert hashlib.sha256((target/name).read_bytes()).hexdigest()==sha
    shapes[role]=data['rows']
selected=[]
for ref,cand in zip(shapes['reference'],shapes['candidate'],strict=True):
    assert ref['id']==cand['id']
    for a,b in zip(ref['codes'],cand['codes'],strict=True):
        assert not a.pop('directDefinitionReturn')
        if b.pop('directDefinitionReturn'):
            selected.append([cand['id'],b['name'],b['capacity'],b['opcodeCounts']])
        assert a==b
print(selected)
assert len(selected)==3 and all(item[1]=='for_policy' and item[3]=={'ApplyOperation':1,'Return':1} for item in selected)
(p/'selected-returns.json').write_text(json.dumps(selected,indent=2)+'\n',encoding='utf-8',newline='\n')

