from pathlib import Path
import os
import subprocess
import sys

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
role=sys.argv[1]
filters={
  "white": ("Lokad.Lython.Tests", "Category!=Stress&(FullyQualifiedName~SimpleFunctionExecutionBoundary|FullyQualifiedName~Function|FullyQualifiedName~Operand|FullyQualifiedName~Closure|FullyQualifiedName~Capture|FullyQualifiedName~ExecutableArchitecture|FullyQualifiedName~ManagedStack|FullyQualifiedName~Cancellation|FullyQualifiedName~Admission)"),
  "public": ("Lokad.Lython.PublicApi.Tests", "Category!=Stress&(FullyQualifiedName~Capture|FullyQualifiedName~Function|FullyQualifiedName~Closure|FullyQualifiedName~BoundCallable|FullyQualifiedName~CallArgument|FullyQualifiedName~GlobalBinding|FullyQualifiedName~Namespace|FullyQualifiedName~ExecutableCleanup|FullyQualifiedName~CooperativeCancellation|FullyQualifiedName~ClassMethod|FullyQualifiedName~Generator|FullyQualifiedName~Import)"),
}


tree=repo/".git/agent-worktrees/closed-definition-return-20261123"
windows_dotnet=Path.home()/".dotnet11/dotnet.exe"
linux_dotnet="/home/vermorel/.dotnet/dotnet"
args = ["test","-c","Release"]
if role=="windows":
    command=[str(windows_dotnet)]
    env=dict(os.environ,DOTNET_ROOT=str(windows_dotnet.parent),DOTNET_HOST_PATH=str(windows_dotnet))
    target="net11.0"
    artifacts=lab/"windows"
else:
    def linux(path): return "/mnt/d/"+path.relative_to(path.anchor).as_posix()
    command=["wsl.exe","--cd",linux(tree),"--exec","env","DOTNET_ROOT=/home/vermorel/.dotnet",
             "DOTNET_HOST_PATH="+linux_dotnet,linux_dotnet]
    env=None
    target="net10.0"
    artifacts=linux(lab/"ubuntu")
for kind,(project,query) in filters.items():
    log=lab/(role+"-"+kind+".log")
    with log.open("wb") as out:
        result=subprocess.run(command+args+["tests/"+project, "-f",target,"--artifacts-path",str(artifacts),"--filter",query],
                              cwd=tree,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=200)
    lines=log.read_text(encoding="utf-8").splitlines()
    print("\n".join(lines[-(9 if result.returncode==0 else 25):]),flush=True)
    result.check_returncode()
