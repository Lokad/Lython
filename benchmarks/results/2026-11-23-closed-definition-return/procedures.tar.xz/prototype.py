from pathlib import Path
repo=Path.cwd()
tree=repo/'.git/agent-worktrees/closed-definition-return-20261123'
def edit(name,before,after):
    file=tree/'src/Lokad.Lython'/name
    text=file.read_text(encoding='utf-8')
    assert text.count(before)==1,name
    file.write_text(text.replace(before,after),encoding='utf-8',newline='\n')
edit('Frontend/ExecutableScript.cs',
     '''        HasDirectIntegerReturn = CanRunNativeInstructions && HasClosedIntegerReturn(cancellationToken);''',
     '''        HasDirectIntegerReturn = CanRunNativeInstructions && HasClosedIntegerReturn(cancellationToken);
        if (CanRunNativeInstructions) DirectDefinitionReturn = PrepareDirectDefinitionReturn();''')
edit('Frontend/ExecutableScript.cs',
     '''    internal ExecutableCaptureSources? CaptureSources { get; private set; }''',
     '''    internal ExecutableCaptureSources? CaptureSources { get; private set; }
    internal ExecutableCreateFunction? DirectDefinitionReturn { get; }''')
edit('Frontend/ExecutableScript.NativeSegments.cs',
     '''    private bool HasClosedIntegerReturn(CancellationToken cancellationToken)''',
     '''    private ExecutableCreateFunction? PrepareDirectDefinitionReturn()
    {
        if (!UsesOnlyLexicalSlots || EntryIndex != 0 || ExceptionRegions.Count != 0 ||
            Instructions.Length != 2 || Instructions[0].OpCode != ExecutableOpCode.ApplyOperation ||
            Instructions[1].OpCode != ExecutableOpCode.Return || Instructions[1].InputStart != Instructions[0].ResultSlot ||
            Constants[Instructions[0].ConstantIndex] is not ExecutableCreateFunction
            {
                InputCount: 0, IsGenerator: false, DeferredAnnotations.Length: 0,
                TypeParameters: null, EagerAnnotationReads: null, PostponedAnnotations: null,
            } definition) return null;

        // The declaration captures the factory's only bound argument by value.
        // Its code still owns live function metadata and allocates a fresh callable.
        var body = definition.CodeObject;
        var capture = body.CaptureSources;
        return body.UsesOnlyLexicalSlots && !body.ScopeFacts.RequiresClassCell &&
            capture is { CanCaptureByValue: true, Slots: [0] } &&
            ReferenceEquals(capture.ParentLocalSlots, LocalNameToSlot) ? definition : null;
    }

    private bool HasClosedIntegerReturn(CancellationToken cancellationToken)''')
edit('Runtime/PyExecutableFunction.cs',
     '''        if (receiver is null && CodeObject.HasDirectIntegerReturn &&''',
     '''        if (receiver is null && completePositional && arguments.Length == 1 &&
            CodeObject.DirectDefinitionReturn is { } definition && !Closure.IsTypeParameterScope)
        {
            result = LythonRuntime.ExecutableSlot.FromObject(ReturnDefinition(definition, arguments[0], span));
            unpacked = false;
            frame = null;
            return;
        }

        if (receiver is null && CodeObject.HasDirectIntegerReturn &&''')
edit('Runtime/PyExecutableFunction.cs',
     '''    private bool TryStartPreparedIntegerReturn(ExecutableCallSite call, ReadOnlySpan<LythonRuntime.ExecutableSlot> arguments,''',
     '''    private PyFunctionBase ReturnDefinition(ExecutableCreateFunction definition,
        LythonRuntime.ExecutableSlot argument, LythonSourceSpan span)
    {
        try
        {
            Closure.EnterFunctionCall(span);
            var previous = Closure.State.CurrentException;
            try
            {
                var result = LythonRuntime.CreateClosedFunctionDefinition(definition, Closure, argument,
                    CodeObject.Instructions[0].Span);
                Closure.CheckExecution(CodeObject.Instructions[1].Span);
                return result;
            }
            catch (LythonRuntimeException error)
            {
                if (previous is not null && !ReferenceEquals(error.OriginalPythonException, previous))
                    error.PythonContext ??= previous;
                throw;
            }
            finally
            {
                Closure.State.SetCurrentException(previous);
                Closure.LeaveFunctionCall();
            }
        }
        catch (LythonRuntimeException error)
        {
            PyFunctionBinding.AnnotateException(error, Closure, Name, span);
            throw;
        }
    }

    private bool TryStartPreparedIntegerReturn(ExecutableCallSite call, ReadOnlySpan<LythonRuntime.ExecutableSlot> arguments,''')
edit('Runtime/LythonRuntime.Executable.PreparedDefinitions.cs',
     '''    private static bool CanDefineLexically(ExecutableCodeObject code)''',
     '''    internal static PyFunctionBase CreateClosedFunctionDefinition(ExecutableCreateFunction definition,
        ExecutionContext scope, ExecutableSlot argument, LythonSourceSpan span)
    {
        scope.CheckExecution(span);
        return CreateFunctionValue(definition.ParameterLayout, definition.CodeObject, GetGlobalContext(scope),
            default, default, false, scope, span, uncapturedLocal: new Span<ExecutableSlot>(ref argument));
    }

    private static bool CanDefineLexically(ExecutableCodeObject code)''')
