from pathlib import Path
import hashlib, json, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
previous=lab.with_name("forwarded-positional-cpython-20261124")
donor=lab.with_name("borrow-forwarded-integers-20261124")
source=(previous/"prepare.py").read_text(encoding="utf-8")
source=source.replace('donor = lab.with_name("forwarded-positional-framed-20261124")','donor = lab.with_name("borrow-forwarded-integers-20261124")')
source=source.replace('"6466fbb52"','"d6a168491"')
source=source.replace('"forwarded-positional-cpython-b1625-20261124"','"forwarded-integers-cpython-b1633-20261124"')
source=source.replace('"forwarded-positional-framed-b1624-20261124"','"borrow-forwarded-integers-b1631-20261124"')
source=source.replace('order = ["scripts.rule-default-closures", "scripts.captured-rule-closures", "scripts.annotated-rule-closures",\n         "diagnostic.text-summary.nonlocal-computed-width.large", "scripts.csv-invoice.method-policy.quoted-control"]',
'''order = ["scripts.rule-default-closures", "scripts.captured-rule-closures", "scripts.annotated-rule-closures"]
catalog["cases"] = [case for case in catalog["cases"] if case["id"] in set(order)]''')
start=source.index('assert len(jobs) == 15')
end=source.index('save(output / "jobs.json"', start)
source=source[:start]+'''assert len(jobs) == 9
save(output / "representative.json", catalog)
'''+source[end:]
source=source.replace('replace("len(jobs) == 7", "len(jobs) == 15").replace("started<392", "started<475")',
                      'replace("len(jobs) == 7", "len(jobs) == 9").replace("started<392", "started<308")')
source=source.replace('"b1625-fixtures"','"b1633-fixtures"').replace('CPython checkpoint for delivered positional operand forwarding','CPython checkpoint for shared defaults and forwarded integer operands')
source=source.replace('"forwarded-positional-framed-20261124/comparison/quiet"','"borrow-forwarded-integers-20261124/comparison/quiet"')
source=source.replace('lython-b1625-forwarded-positional-cpython','lython-b1633-forwarded-integers-cpython')
source=source.replace('replace("RuntimeMaxSec=460", "RuntimeMaxSec=535").replace("seconds=405", "seconds=454")',
                      'replace("RuntimeMaxSec=460", "RuntimeMaxSec=365").replace("seconds=405", "seconds=275")')
source=source.replace("len(raw[\"jobs\"])==15 and receipt[\"warmJobs\"]==15", "len(raw[\"jobs\"])==9 and receipt[\"warmJobs\"]==9")
source=source.replace("Prepared 15 short quiet lanes with five CPython goldens and attested sources.",
                      "Prepared nine short quiet lanes with three CPython goldens and attested sources.")
start=source.index('launcher = launcher[:start] +')
end=source.index('launcher = launcher.replace("RuntimeMaxSec', start)
source=source[:start]+r'''launcher=launcher[:start]+""" free_after=free; plans=[]
 for row in duplicates:
  if free_after>=minimum:break
  prior=base/row['location']
  raw=prior/'confirmation/confirmation.json'
  archive=prior/'observations.tar.xz'
  marker=prior/'archive-receipt.json'
  if not raw.is_file():continue
  assert raw.resolve()==raw and raw.is_relative_to(base) and raw.stat().st_nlink==1
  if (prior/'guest-fixtures').exists() or not marker.is_file():continue
  info=json.loads(marker.read_text())
  if not info.get('allWorkersJoined') or not info.get('archivedAndVerifiedUnderLease'):continue
  if raw.stat().st_size!=row['bytes'] or not archive.is_file():continue
  if digest(archive)!=row['archiveSHA256'] or digest(raw)!=row['rawSHA256']:continue
  plans.append((row,raw))
  free_after+=raw.stat().st_blocks*512
 print(json.dumps(dict(freeBefore=free,available=free_after,required=minimum,verifiedDuplicates=[row for row,_ in plans])))
 assert free_after>=minimum
 for _,raw in plans:raw.unlink()
"""+launcher[end:]
launcher=launcher.replace('script = f"payload={payload!r}; checksum={previous[\'archiveSHA256\']!r}\\n"',
    'duplicates=json.loads((lab/"verified-raw-replicas.json").read_text(encoding="utf-8"))\n    script = f"payload={payload!r}; duplicates={duplicates!r}; checksum={previous[\'archiveSHA256\']!r}\\n"')
'''+source[end:]
compile(source,"prepare.py","exec")
(lab/"prepare.py").write_text(source,encoding="utf-8",newline="\n")

read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
replicas=read(donor/"verified-raw-replicas.json")
for name,bundle in (
    ("defaults-forwarded-cumulative-b1632-20261124", donor/"cumulative/comparison/quiet/observations.tar.xz"),
    ("shared-function-defaults-confirm-b1630-20261124", lab.with_name("shared-function-defaults-20261124")/"confirmation/comparison/quiet/observations.tar.xz"),
):
    terminal=read(bundle.parent/"terminal-status.json")["receipt"]
    assert terminal["allWorkersJoined"] and terminal["archivedAndVerifiedUnderLease"]
    assert sha(bundle)==terminal["archiveSHA256"]
    with tarfile.open(bundle) as data:
        raw=data.extractfile("confirmation/confirmation.json").read()
    replicas.append(dict(location=name, bytes=len(raw),rawSHA256=hashlib.sha256(raw).hexdigest(),archiveSHA256=sha(bundle)))
(lab/"verified-raw-replicas.json").write_text(json.dumps(replicas,indent=2)+"\n",encoding="utf-8")
