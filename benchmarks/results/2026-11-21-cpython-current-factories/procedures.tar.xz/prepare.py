from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile


lab = Path(__file__).resolve().parent
repo = lab.parents[3]
snapshot = lab.parent / "function-metadata-reset-current"
prior = lab.parent / "shared-function-binding-facts-on-current/quiet"
older = lab.parent / "callable-standard-overrides-direct/quiet"
template = lab.parent / "csv-restock-cpython/quiet"
quiet = lab / "quiet"
core = "Lokad.Lython.dll"


def read(path):
    return path.read_text(encoding="utf-8-sig")


def load(path):
    return json.loads(read(path))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def emit(path, source):
    if path.suffix == ".py":
        compile(source, str(path), "exec")
    path.write_text(source, encoding="utf-8", newline="\n")


def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")


index = load(snapshot / "identity.json")
image = snapshot / "frozen/candidate"
revision = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
assert revision == index["candidate"] and revision.startswith("256c5e651")
files = index["imageFiles"]["candidate"]
assert len(files) == 32 and {name: sha(image / name) for name in files} == files
protocol = repo / "benchmarks/cpython-worker.py"
assert index["pythonWorkerSHA256"] == sha(protocol)
catalog = load(snapshot / "representative.json")
postponed = "scripts.annotated-rule-closures.nested-factories.postponed"
eager = "scripts.annotated-rule-closures.nested-factories"
catalog["cases"] = [row for row in catalog["cases"] if row["id"] in {postponed, eager}]
assert len(catalog["cases"]) == 2
manifest = lab / "representative.json"
save(manifest, catalog)
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ["PATH"])
subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
                "--catalog", manifest, "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
                "--python-worker", protocol, "--out", lab / "verify.json"], check=True, env=env, timeout=120)
verification = load(lab / "verify.json")
assert verification["state"] == "Completed" and verification["caseCount"] == 2
assert verification["catalogSha256"] == sha(manifest)
assert {name: sha(image / name) for name in files} == files

previous = load(prior / "config.json")
previous_receipt = load(prior / "archive-receipt.json")
older_config = load(older / "config.json")
older_receipt = load(older / "archive-receipt.json")
for folder, receipt in ((prior, previous_receipt), (older, older_receipt)):
    assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
    assert receipt["archiveSHA256"] == sha(folder / "observations.tgz")
source_files = previous["identity"]["imageFiles"]["candidate"]
assert [name for name in source_files if source_files[name] != files[name]] == [core]
prior_name = Path(previous["root"]).name
older_name = Path(older_config["root"]).name
prior_archive = prior_name + "/observations.tgz"
older_archive = older_name + "/observations.tgz"
old_reference = previous["identity"]["imageFiles"]["reference"][core]
assert old_reference == older_config["identity"]["imageFiles"]["candidate"][core]


def retirement(paths, canonical, digest, archives):
    binary = gzip.decompress(subprocess.check_output(["git", "show", "HEAD:" + canonical], cwd=repo))
    assert hashlib.sha256(binary).hexdigest() == digest
    return dict(paths=paths, links=len(paths), bytes=len(binary), sha256=digest,
                archives=archives, verifiedCanonicalGitImage=canonical)


retire = [
    retirement([older_name + "/candidate/" + core, prior_name + "/reference/" + core],
               "benchmarks/results/2026-11-21-direct-function-override-admission/candidate-core.dll.gz",
               old_reference, {older_archive: older_receipt["archiveSHA256"], prior_archive: previous_receipt["archiveSHA256"]}),
    retirement([prior_name + "/candidate/" + core],
               "benchmarks/results/2026-11-21-compiled-call-metadata/candidate-core.dll.gz", source_files[core],
               {prior_archive: previous_receipt["archiveSHA256"]}),
]
root = "/home/lokad/lython-bench-checks/current-factories-cpython-b1285-20261121"
unit = "lython-b1285-current-factories-cpython-20261121"
quiet.mkdir(exist_ok=False)
identity = dict(sourceRevision=revision, imageSource=revision, purpose="Current factory and call metadata checkpoint against CPython",
                imageFiles=dict(candidate=files), catalogSHA256=sha(manifest), cpythonWorkerSHA256=sha(protocol),
                auxiliaryFiles={name: digest for name, digest in files.items() if name != core},
                coreSHA256={label: files[core] for label in ("candidate", "candidate-control")})
save(quiet / "identity.json", identity)
earlier = load(template / "config.json")
jobs = [(postponed, "warm"), (postponed, "compile-run"), (postponed, "compile"), (eager, "warm")]
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    source = read(template / name).replace(earlier["root"], root).replace(earlier["unit"], unit)
    if name == "collect.py":
        begin = source.index("    for case_id,lane in ")
        end = source.index("        assert time.monotonic()", begin)
        source = source[:begin] + f"    for case_id,lane in {jobs!r}:\n" + source[end:]
    emit(quiet / name, source.replace("B1278", "B1285"))
assert b"\r" not in (quiet / "run.sh").read_bytes()
(quiet / "candidate").mkdir()
shutil.copyfile(image / core, quiet / "candidate" / core)
shutil.copyfile(manifest, quiet / "representative.json")
shutil.copyfile(protocol, quiet / "cpython-worker.py")
parts = ("identity.json", "representative.json", "collect.py", "archive-owned.py", "run.sh", "cpython-worker.py", "candidate/" + core)
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as packed:
    for name in parts:
        packed.add(quiet / name, arcname=name)
config = dict(root=root, unit=unit, identity=identity, source=previous["root"], sourceRole="candidate",
              sourceFiles=source_files, sourceCatalogSHA256=previous["catalogSHA256"],
              donorArchiveSHA256=previous_receipt["archiveSHA256"], catalogSHA256=identity["catalogSHA256"], retireGroups=retire,
              cpythonWorkerSHA256=identity["cpythonWorkerSHA256"], payloadBytes=payload.stat().st_size,
              payloadSHA256=sha(payload), unpackedBytes=sum((quiet / name).stat().st_size for name in parts))
save(quiet / "config.json", config)
source = read(template / "remote-launch.py")
begin = source.index("\nc=") + 1
end = source.index("\nb=Path(", begin)
source = source[:begin] + "c=" + repr(config) + source[end:]
emit(quiet / "remote-launch.py", source.replace("lython-b1278-fixtures", "lython-b1285-fixtures"))
emit(lab / "launch.py", read(template.parent / "launch.py").replace("B1278 CSV restock", "B1285 factory")
     .replace("245", "250"))
