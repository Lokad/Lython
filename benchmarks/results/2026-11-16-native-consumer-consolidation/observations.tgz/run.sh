set -eu
root=/home/lokad/lython-bench-checks/native-consumers-b853-20261116
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
