from pathlib import Path
import hashlib,io,json,os,re,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');w=repo/'.git/agent-worktrees/native-consumers-r450';old=r.parent/'iteration-result-r448';sdk='C:/Users/JoannesVermorel/.dotnet11';env=dict(os.environ,DOTNET_ROOT=sdk,DOTNET_ROOT_X64=sdk);sha=lambda b:hashlib.sha256(b).hexdigest()
for suite,count in [('Lokad.Lython.Tests',4806),('Lokad.Lython.PublicApi.Tests',17935)]:
 log=(r/f'ordinary-checks/net11.0-{suite}.log').read_text(encoding='utf-8-sig');assert re.search(r'Passed!\s+-\s+Failed:\s+0,\s+Passed:\s+'+str(count),log),(suite,log[-300:])
reference=json.loads((old/'final-inputs.json').read_text(encoding='utf-8'));refcore=repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll';assert sha(refcore.read_bytes())==reference['coreSHA256']
with tarfile.open(repo/'benchmarks/results/2026-11-16-compact-iteration-result/final-sources.tar.xz')as a:
 for member in a.getmembers():
  if member.isfile()and member.name.startswith('src/Lokad.Lython/'):
   assert (repo/member.name).read_text(encoding='utf-8-sig')==a.extractfile(member).read().decode('utf-8-sig').replace('\r\n','\n'),member.name
paths=subprocess.check_output(['git','ls-files','src','tests','docs','Directory.Build.props','Directory.Build.targets','global.json','Lokad.Lython.slnx'],cwd=w).decode().splitlines();inputs={n:sha((w/n).read_bytes())for n in sorted(set(paths))if(w/n).is_file()}
with(r/'frozen-core-build.log').open('w',encoding='utf-8')as log:p=subprocess.run([sdk+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','--no-incremental'],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0,(r/'frozen-core-build.log').read_text(encoding='utf-8')[-2000:]
for n,h in inputs.items():assert sha((w/n).read_bytes())==h,n
f=r/'frozen';f.mkdir(exist_ok=False);prior=json.loads((old/'frozen/identity.json').read_text(encoding='utf-8'));aux=prior['imageFiles']['reference']
for role in ['reference','candidate']:
 (f/role).mkdir()
 for n,h in aux.items():
  assert sha((old/'frozen/reference'/n).read_bytes())==h,n
  shutil.copy2(old/'frozen/reference'/n,f/role/n)
shutil.copy2(refcore,f/'reference/Lokad.Lython.dll');shutil.copy2(w/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',f/'candidate/Lokad.Lython.dll')
images={role:{p.name:sha(p.read_bytes())for p in sorted((f/role).iterdir())if p.is_file()}for role in ['reference','candidate']};assert [n for n in images['candidate']if images['candidate'][n]!=images['reference'][n]]==['Lokad.Lython.dll']
identity=dict(referenceSource='Final R448 d77a8bdd,qualified43908598724; local e1204916 exact production text parity with qualified final sources',candidateSource='R450 private complete native/CLR consumer consolidation at3f98a725; exact sources archived',imageFiles=images,inputs=inputs,catalogSHA256=sha((r/'catalog.json').read_bytes()),normalAdapterPin='0.4.0',publicationHeld=True)
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
 for n in inputs:t.add(w/n,arcname=n)
for role in ['reference','candidate']:
 with(r/f'preflight-{role}.log').open('w',encoding='utf-8')as log:p=subprocess.run([sdk+'/dotnet.exe',str(f/role/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'catalog.json'),'--out',str(r/f'preflight-{role}.json')],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
 assert p.returncode==0,(r/f'preflight-{role}.log').read_text(encoding='utf-8')[-2000:]
print(json.dumps(dict(imagesFrozen=True,onlyCoreDiffers=True,cores={role:images[role]['Lokad.Lython.dll']for role in images},inputs=len(inputs),production=sum(n.startswith('src/Lokad.Lython/')for n in inputs),allFiveFrozenWorkerCasesVerified=True)))
