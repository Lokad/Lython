using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text;
using System.Text.Json;
var root=Path.GetFullPath(args[0]);var write=args.Contains("--write");var rows=new List<object>();
foreach(var path in Directory.GetFiles(Path.Combine(root,"src/Lokad.Lython/Runtime"),"*.cs",SearchOption.AllDirectories))
{
 var original=File.ReadAllText(path,Encoding.UTF8);var tree=CSharpSyntaxTree.ParseText(original,new CSharpParseOptions(LanguageVersion.Preview));var visitor=new NativeLoops(original);var result=visitor.Visit(tree.GetRoot())!;
 if(visitor.Count==0)continue;rows.Add(new{path=Path.GetRelativePath(root,path),loops=visitor.Count});if(write)File.WriteAllText(path,result.ToFullString(),new UTF8Encoding(false));
}
Console.WriteLine(JsonSerializer.Serialize(new{write,rows},new JsonSerializerOptions{WriteIndented=true}));
sealed class NativeLoops(string source):CSharpSyntaxRewriter
{
 public int Count;private int _id;
 public override SyntaxNode? VisitForEachStatement(ForEachStatementSyntax node)
 {
  var expression=node.Expression;
  if(expression is InvocationExpressionSyntax {Expression:MemberAccessExpressionSyntax {Name.Identifier.ValueText:"ConfigureAwait",Expression:var inner}})expression=inner;
  if(expression is not InvocationExpressionSyntax call||node.Type.ToString()!="var")return base.VisitForEachStatement(node);
  var name=call.Expression switch{IdentifierNameSyntax n=>n.Identifier.ValueText,MemberAccessExpressionSyntax m=>m.Name.Identifier.ValueText,_=>null};
  if(name is not("ToSequence"or"ToSequenceAsync")||call.ArgumentList.Arguments.Count is not(2 or 3))return base.VisitForEachStatement(node);
  var asynchronous=!node.AwaitKeyword.IsKind(SyntaxKind.None);if(asynchronous!=(name=="ToSequenceAsync"))throw new InvalidOperationException("Unexpected iteration mode");
  string cursor,next;do{cursor="nativeCursor"+(++_id);next="nativeNext"+_id;}while(source.Contains(cursor,StringComparison.Ordinal)||source.Contains(next,StringComparison.Ordinal));
  Count++;var body=Visit(node.Statement)!.ToFullString();var parameters=call.ArgumentList.ToFullString();var acquire=asynchronous&&call.ArgumentList.Arguments.Count==3?"await PyIteration.Cursor.CreateAsync"+parameters+".ConfigureAwait(false)":"PyIteration.Cursor.Create"+parameters;
  var pull=asynchronous?"await "+cursor+".TryMoveNextAsync().ConfigureAwait(false)":cursor+".TryMoveNext()";
  var loop="while(true){var "+next+"="+pull+";if(!"+next+".HasValue)break;var "+node.Identifier.ValueText+"="+next+".Value;"+body+"}";
  var text=asynchronous?"{var "+cursor+"="+acquire+";await using("+cursor+".ConfigureAwait(false)){"+loop+"}}":"{using(var "+cursor+"="+acquire+"){"+loop+"}}";
  var formatted=SyntaxFactory.ParseStatement(text).NormalizeWhitespace(indentation:"    ",eol:"\n").ToFullString();var indent=new string(' ',node.GetLocation().GetLineSpan().StartLinePosition.Character);formatted=formatted.Replace("\n","\n"+indent,StringComparison.Ordinal);
  return SyntaxFactory.ParseStatement(formatted).WithLeadingTrivia(node.GetLeadingTrivia()).WithTrailingTrivia(node.GetTrailingTrivia());
 }
}
