using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text;
using System.Text.Json;
var root=Path.GetFullPath(args[0]);var write=args.Contains("--write");var rows=new List<object>();
foreach(var path in Directory.GetFiles(Path.Combine(root,"src/Lokad.Lython/Runtime"),"*.cs",SearchOption.AllDirectories))
{
 var original=File.ReadAllText(path,Encoding.UTF8);var tree=CSharpSyntaxTree.ParseText(original,new CSharpParseOptions(LanguageVersion.Preview));var visitor=new NativeLoops(original);var result=visitor.Visit(tree.GetRoot())!;
 if(visitor.Count==0)continue;rows.Add(new{path=Path.GetRelativePath(root,path),loops=visitor.Count});if(write)File.WriteAllText(path,result.ToFullString(),new UTF8Encoding(false));
}
Console.WriteLine(JsonSerializer.Serialize(new{write,rows},new JsonSerializerOptions{WriteIndented=true}));
sealed class NativeLoops(string source):CSharpSyntaxRewriter
{
 public int Count;
 public override SyntaxNode? VisitBlock(BlockSyntax node)
 {
  InvocationExpressionSyntax? acquire=null;BlockSyntax? owner=null;var asynchronous=false;
  if(node.Statements is [UsingStatementSyntax{Declaration.Variables:[{Initializer.Value:InvocationExpressionSyntax sync}],Statement:BlockSyntax syncBody}])
  {acquire=sync;owner=syncBody;}
  else if(node.Statements is [LocalDeclarationStatementSyntax{Declaration.Variables:[{Initializer.Value:var value}]},UsingStatementSyntax{AwaitKeyword.RawKind:(int)SyntaxKind.AwaitKeyword,Statement:BlockSyntax asyncBody}])
  {
   asynchronous=true;owner=asyncBody;
   if(value is AwaitExpressionSyntax{Expression:InvocationExpressionSyntax{Expression:MemberAccessExpressionSyntax{Expression:InvocationExpressionSyntax inner}}})acquire=inner;
   else acquire=value as InvocationExpressionSyntax;
  }
  if(acquire is null||acquire.Expression.ToString() is not("PyIteration.Cursor.Create"or"PyIteration.Cursor.CreateAsync")||
     owner?.Statements is not [WhileStatementSyntax{Statement:BlockSyntax loop}]||loop.Statements.Count!=4||
     loop.Statements[0] is not LocalDeclarationStatementSyntax{Declaration.Variables:[var next]}||!next.Identifier.ValueText.StartsWith("nativeNext",StringComparison.Ordinal)||
     loop.Statements[2] is not LocalDeclarationStatementSyntax{Declaration.Variables:[var item]})return base.VisitBlock(node);
  var body=Visit(loop.Statements[3])!;Count++;
  var expression=asynchronous?SyntaxFactory.ParseExpression("PyIteration.Cursor.ForAsyncEnumeration"+acquire.ArgumentList+".ConfigureAwait(false)"):acquire;
  var replacement=SyntaxFactory.ForEachStatement(SyntaxFactory.IdentifierName("var"),item.Identifier,expression,(StatementSyntax)body);
  if(asynchronous)replacement=replacement.WithAwaitKeyword(SyntaxFactory.Token(SyntaxKind.AwaitKeyword));
  var formatted=replacement.NormalizeWhitespace(indentation:"    ",eol:"\n").ToFullString();var indent=new string(' ',node.GetLocation().GetLineSpan().StartLinePosition.Character);formatted=formatted.Replace("\n","\n"+indent,StringComparison.Ordinal);
  return SyntaxFactory.ParseStatement(formatted).WithLeadingTrivia(node.GetLeadingTrivia()).WithTrailingTrivia(node.GetTrailingTrivia());
 }
}
