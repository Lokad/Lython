from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
pair = lab / 'comparison'
quiet = pair / 'quiet'
quiet.mkdir()
previous = lab.parent / 'direct-loop-position-b1953-20261128'
source = previous / 'comparison/quiet'
donor = lab.parent / 'shared-subscript-b1977-20261128/comparison/quiet'
root = 'script-deferred-starmap-row-b1980-20261128'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


identity = read(pair / 'identity.json')
donor_image = read(donor / 'identity.json')['imageFiles']['candidate']
donor_receipt = read(donor / 'archive-receipt.json')
assert donor_receipt['archiveSHA256'] == digest(donor / 'observations.tar.xz')
assert donor_receipt['complete'] and donor_receipt['allWorkersJoined']
for role, files in identity['imageFiles'].items():
    assert {p.name: digest(p) for p in (pair / role).iterdir()} == files
    assert {name for name in files if donor_image[name] != files[name]} == ({'Lokad.Lython.dll'} if role == 'candidate' else set())
    proof = read(pair / f'{role}-verify.json')
    assert proof['state'] == 'Completed' and proof['caseCount'] == 10
    assert proof['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['library']['sha256'] == files['Lokad.Lython.dll']

identity.update(donorArchiveSHA256=donor_receipt['archiveSHA256'],
                frozenImage=f'/home/lokad/lython-bench-checks/{root}/candidate')
save(quiet / 'identity.json', identity)
for name in ('representative.json', 'cpython-worker.py'):
    copy2(pair / name, quiet / name)
for name in ('collect.py', 'run.sh'):
    copy2(source / name, quiet / name)
assert b'\r' not in (quiet / 'run.sh').read_bytes()
save(quiet / 'jobs.json', read(pair / 'jobs.json')['warm'])
identity['catalogs']['jobs.json']['sha256'] = digest(quiet / 'jobs.json')
save(quiet / 'identity.json', identity)
collector = (quiet / 'collect.py').read_text(encoding='utf-8')
assert collector.count('len(jobs) == 3') == 1
(quiet / 'collect.py').write_text(collector.replace('len(jobs) == 3', 'len(jobs) == 4'),
                                  encoding='utf-8', newline='\n')
files = {name: quiet / name for name in ('identity.json', 'representative.json', 'cpython-worker.py', 'collect.py', 'run.sh', 'jobs.json')}
files['candidate/Lokad.Lython.dll'] = pair / 'candidate/Lokad.Lython.dll'
payload = quiet / 'stage.tar.gz'
with tarfile.open(payload, 'w:gz') as archive:
    for name, path in files.items():
        archive.add(path, arcname=name)
save(quiet / 'upload.json', dict(root=root, donor=read(donor / 'upload.json')['root'],
     donorArchive=identity['donorArchiveSHA256'], donorFiles=donor_image,
     minimumAfterStageBytes=4_800_000, expandedBytes=sum(p.stat().st_size for p in files.values()),
     caseCount=10, payloadSHA256=digest(payload),
     files={name: dict(sha256=digest(p), length=p.stat().st_size) for name, p in files.items()}))

script = (previous / 'quiet-vm.py').read_text(encoding='utf-8')
script = script.replace('lython-b1953-loop-position','lython-b1980-deferred-starmap-row').replace("proof['caseCount']==3", "proof['caseCount']==cfg['caseCount']")
(lab / 'quiet-vm.py').write_text(script, encoding='utf-8', newline='\n')
script = (donor.parents[1] / 'summarize-quiet.py').read_text(encoding='utf-8')
(lab / 'summarize-quiet.py').write_text(script.replace("verified['caseCount'] == 9", "verified['caseCount'] == 10"), encoding='utf-8', newline='\n')
print('Verified local worker identities and created two-image quiet collection.')