#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
lab=.git/agent-notes/review-20261031/deferred-starmap-row-b1980-20261128
unset DOTNET_BUNDLE_EXTRACT_BASE_DIR
"$HOME/.dotnet/dotnet" test tests/Lokad.Lython.Tests -c Release -f net11.0 --artifacts-path "$lab/ubuntu-tests" \
  --filter 'Category!=Stress&(FullyQualifiedName~RecordFieldLookupOwnership|FullyQualifiedName~DescriptorMethodBinding|FullyQualifiedName~RawDescriptorGetDispatch|FullyQualifiedName~IterationIndexingSubsystem|FullyQualifiedName~ExecutableSubscriptStore|FullyQualifiedName~ExecutableAugmentedSubscript|FullyQualifiedName~StringIndexCacheCancellation|FullyQualifiedName~DirectOperandOwnership|FullyQualifiedName~ExecutableStackAdmission)' > "$lab/ubuntu-net11.0-whitebox.log" 2>&1