#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
lab=.git/agent-notes/review-20261031/deferred-starmap-row-b1980-20261128
dotnet="$HOME/.dotnet/dotnet"
unset DOTNET_BUNDLE_EXTRACT_BASE_DIR
"$dotnet" test tests/Lokad.Lython.PublicApi.Tests -c Release -f net11.0 --artifacts-path "$lab/ubuntu-tests" \
  --filter 'Category!=Stress&(FullyQualifiedName~Starmap|FullyQualifiedName~NativeGeneratorSum|FullyQualifiedName~Generator|FullyQualifiedName~Iteration|FullyQualifiedName~BudgetRefusal|FullyQualifiedName~AdmissionFailureCommandTests)' > "$lab/ubuntu-net11.0-public.log" 2>&1
"$dotnet" test tests/Lokad.Lython.Tests -c Release -f net11.0 --artifacts-path "$lab/ubuntu-tests" \
  --filter 'Category!=Stress&(FullyQualifiedName~IterationIndexingSubsystem|FullyQualifiedName~DirectOperandOwnership|FullyQualifiedName~ExecutableStackAdmission|FullyQualifiedName~RecordFieldLookupOwnership|FullyQualifiedName~GeneratorExpressionAdmissionTests)' > "$lab/ubuntu-net11.0-whitebox.log" 2>&1