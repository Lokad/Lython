from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
out = lab.parents[3] / 'benchmarks/results/2026-11-28-deferred-starmap-argument-frame'
pair = lab / 'comparison'
quiet = pair / 'quiet'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()

identity = read(quiet / 'identity.json')
assert identity['sourcePatchSHA256'] == digest(lab / 'candidate.patch')
assert identity['imageFiles'] == read(pair / 'identity.json')['imageFiles']
for role, files in identity['imageFiles'].items():
    assert {path.name: digest(path) for path in (pair / role).iterdir()} == files
    assert read(pair / f'{role}-verify.json')['caseCount'] == 10

summary = read(quiet / 'summary.json')
assert summary['verifiedTimedBatches'] == 112 and summary['quietGates']
receipt = read(quiet / 'archive-receipt.json')
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert receipt['archiveSHA256'] == digest(quiet / 'observations.tar.xz')
allocation = read(lab / 'allocation/summary.json')
admission = read(lab / 'admission/summary.json')
assert len(allocation) == len(admission) == 20
assert all(row['compiled'][0] == row['compiled'][1] for row in allocation)
assert all(row['requests'][0] == row['requests'][1] for row in admission)
owned_by_run = {(row['case'], row['asynchronous']): row for row in admission}
assert len(owned_by_run) == 20
for row in allocation:
    owned = owned_by_run[(row['case'], row['mode'] == 'async')]
    assert row['admittedPeak'] == owned['peak']
    difference = row['clr'][0] - row['clr'][1]
    assert owned['peak'][0] == owned['peak'][1]
    if row['case'].endswith('starmap-iterable-rows'):
        assert difference == (835_592 if owned['asynchronous'] else 835_480)
        assert owned['peak'] == [4_304_384, 4_304_384] and owned['requests'] == [6_179, 6_179]
    else:
        assert difference == 0 if 'aliases' in row['case'] else abs(difference) <= 402
for target in ('windows-net10.0', 'windows-net11.0', 'ubuntu-net11.0'):
    for suite, count in (('public', 760), ('whitebox', 53)):
        log = lab / f'{target}-{suite}.log'
        assert f'Passed: {count:5d}' in log.read_text(encoding='utf-8')
        assert 'Failed:     0' in log.read_text(encoding='utf-8')
assert 'TakeStagedGeneratorYield' in (lab / 'ubuntu-first-whitebox.log').read_text(encoding='utf-8')

out.mkdir(exist_ok=True)
public = {name: quiet / name for name in ('identity.json', 'summary.json', 'observations.tar.xz', 'terminal-status.json')}
public.update({f'{category}-summary.json': lab / category / 'summary.json' for category in ('allocation', 'admission')})
for name, path in public.items():
    copy2(path, out / name)
    assert digest(out / name) == digest(path)

procedures = {path.name: path for path in lab.iterdir() if path.is_file()
              and path.suffix in ('.log', '.py', '.patch', '.sh', '.json')}
for category in ('allocation', 'admission'):
    procedures.update({f'{category}/{path.name}': path for path in (lab / category).glob('*.json')})
for folder, location in ((pair, 'local'), (quiet, 'quiet')):
    procedures.update({f'{location}/{path.name}': path for path in folder.iterdir() if path.name.endswith('-verify.json')})
for name in ('archive-receipt.json', 'stage-custody.json', 'launch.log'):
    procedures[f'quiet/{name}'] = quiet / name
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in procedures.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    assert all(sha256(archive.extractfile(name).read()).hexdigest() == digest(path)
               for name, path in procedures.items())
print('Verified six focused suites, ten goldens per image, allocation and admission, and 112 quiet batches.')