from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent
old=r.parent/'prepared-binding-r124'
images=r/'images-verified'
assert not images.exists()
paths=[Path(p)/'bin/Release/net11.0/Lokad.Lython.dll' for p in ['src/Lokad.Lython','tests/Lokad.Lython.Tests','tests/Lokad.Lython.PublicApi.Tests']]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert len({sha(p) for p in paths})==1
for name in ['before','candidate']:
    shutil.copytree(r.parent/'function-lookup-lifetime-r121/refined/images/candidate',images/name)
assert sha(images/'before/Lokad.Lython.dll')=='c6172fec19b0fd8d36ba5eba0046ac66578646ba3714f5f7bed99501619ff0bd'
shutil.copyfile(paths[0],images/'candidate/Lokad.Lython.dll')
shutil.copyfile(old/'catalog.json',r/'catalog.json')
shutil.copyfile(old/'measure.py',r/'measure.py')
s=(old/'assess-local.py').read_text(encoding='utf8')
at=s.index("out['limitations']=");end=s.index("\n(r/'assessment-local",at)
s=s[:at]+"out['limitations']='R125 read-operation lifetime correctness fix. Qualified C617 reference; five unchanged primary scripts, identical worker/optional0.4 auxiliaries. Complete public Run/awaitedRunAsync, goldens, shared-budget balances and cleanup. Compilation excluded. Shared CoreLib/processGC/desktop controls: allocation diagnostic and elapsed uncertainty, no CPU-gain claim.'"+s[end:]
(r/'assess-local.py').write_text(s,encoding='utf8')
identity=dict(baseline='Qualified d97/runtime6f76/C617, cached CI42527042378',candidate='R125 read-operation lifetime after a9ef3e1c',coreSHA256={n:sha(images/n/'Lokad.Lython.dll') for n in ['before','candidate']},sources={p:sha(Path(p)) for p in subprocess.check_output(['git','ls-files','src'],text=True).splitlines()},qualification='225internal/140public Release eachactual11/10; full delivery pending')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
print(identity['coreSHA256'])
