from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;dest=Path('benchmarks/results/2026-11-09-text-read-lifetimes');dest.mkdir(exist_ok=True)
validation=dict(status='Focused Release passed',actualFrameworks=['net11.0','net10.0'],uniqueInternalPerTarget=228,publicPerTarget=140,newReadCases=16,explanation='225 expanded internal + 3 cleanup-error cases; final16 includes13 already in expanded set. Public140 passed on the final runtime. No duplicate-case count inflation.',baselineRegression='2 expected failures on qualified C617: allowance832->490 while72-byte raw input remains borrowed',initialNewFixtureMistake='Transport close failures use HostOperationException subclass; exact-type fixture corrected, original failure log retained.',fullDelivery='Pending coherent Windows/Ubuntu full Release11/10, original stress11/10 and installed-core consumers; publication postponed')
(dest/'focused-validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf8')
for name,path in [('identity.json',r/'refined/identity.json'),('initial-assessment.json',r/'assessment-local.json'),('refined-assessment.json',r/'refined/assessment-local.json'),('design.md',r/'design.md')]:shutil.copyfile(path,dest/name)
(r/'final-source.patch').write_bytes(subprocess.check_output(['git','diff','--','src','tests','docs/RUNTIME.md']))
shutil.copyfile('tests/Lokad.Lython.Tests/TextReadBorrowLifetimeTests.cs',r/'TextReadBorrowLifetimeTests.cs')
with tarfile.open(dest/'local-source-and-diagnostics.tar.xz','w:xz')as a:
 for p in sorted(r.iterdir()):
  if p.is_file()and p.suffix in ['.py','.cs','.json','.log','.md','.patch']:a.add(p,arcname=p.name)
 for folder in ['warm-sync','warm-async','refined/warm-sync','refined/warm-async']:
  a.add(r/folder,arcname=folder)
 a.add(r/'refined/identity.json',arcname='refined/identity.json')
 a.add(r/'images-verified/candidate/Lokad.Lython.dll',arcname='initial-core2f4e.dll')
print('Local evidence archived',dest)
