from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;b=r/'b485';b.mkdir()
old=r.parent/'prepared-binding-r124/b483'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
root='text-read-lifetime-b485-20261108';unit='lython-b485-read-lifetime-20261108'
for name in ['collect.py','archive-owned.py','run.sh','launch.py']:
 s=(old/name).read_text(encoding='utf8').replace('prepared-binding-b483-20261108',root).replace('lython-b483-prepared-binding-20261108',unit).replace('prepared-binding-b483-launch.py','text-read-lifetime-b485-launch.py')
 if name=='collect.py':
  start=s.index('jobs=');end=s.index('\nassert len(jobs)',start)
  s=s[:start]+"jobs=[['scripts.text-summary-helpers.large','warm'],['scripts.text-summary-helpers.large','warm-async'],['scripts.report-render.large','warm']]"+s[end:]
  start=s.index("purpose='R124");end=s.index("',\n",start)
  s=s[:start]+"purpose='R125 pending read lifetime correctness fix. Qualified C617 versus004e. Both text APIs and report control. Preserve conflicting desktop initial/refined adverse results; no assumed speedup"+s[end:]
 if name=='archive-owned.py': s=s.replace('jobs=4','jobs=3')
 if name=='launch.py':s=s.replace('allFourJobsValidated','allThreeJobsValidated')
 s=s.replace('len(jobs)==4','len(jobs)==3').replace("len(r['jobs'])==4","len(r['jobs'])==3")
 (b/name).write_text(s,encoding='utf8',newline='\n')
candidate=r/'refined/images-verified/candidate/Lokad.Lython.dll'
shutil.copyfile(candidate,b/'current-core.dll');shutil.copyfile(r/'catalog.json',b/'representative.json')
base=json.loads((r/'refined/identity.json').read_text(encoding='utf8'))
ident=dict(sourceRevision='a9ef3e1c + R125 final read lifetime',coreSHA256={role:base['coreSHA256']['before' if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles={p.name:sha(p)for p in (r/'refined/images-verified/before').glob('*.dll')if p.name!='Lokad.Lython.dll'})
(b/'identity.json').write_text(json.dumps(ident,indent=2)+'\n',encoding='utf8')
shutil.copyfile('PLAN.md',b/'pre-measurement-plan.md')
(b/'baseline-source.json').write_text(json.dumps(base,indent=2)+'\n',encoding='utf8')
(b/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src']))
for name,data in {
 'setup-contract.json':dict(roles=4,jobs=3,normalGcAndTiering=True,ownerSeconds=180,timeoutStopSeconds=30,quietBeforeAndAfterRequired=True,publication=False),
 'focused.json':dict(internalPerTarget=228,publicPerTarget=140,actualFrameworks=['net11.0','net10.0'],newReadCases=16,distinctInternal='225 original expanded + 3 new cleanup-error cases; 13 overlap'),
 'sizing.json':dict(warmupSecondsPerRole=5,rotatedRounds=7,targetBatchSeconds=.15,expectedSeconds=95,ownerSeconds=180,reservedCleanupSeconds=30)
}.items():(b/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
(b/'contract.md').write_text('R125 correctness fix: active read owns raw/decoded/file borrows until actual work and awaited cleanup settle. Both text APIs and complete report control; no allocation or CPU-gain assumption. Qualified C617 reference, same worker and optional0.4. Same mediated RAM-file fixtures/goldens/budget balances/cleanup, warm execution only; compilation/startup/reset/final cache teardown excluded. Original desktop controls/adverse data preserved. Four independent processes/job, normal GC/tiering, finite joined owner, persistent evidence, removed owned RAM, verified archive under lease.\n',encoding='utf8')
names=['collect.py','archive-owned.py','run.sh','current-core.dll','representative.json','identity.json','pre-measurement-plan.md','baseline-source.json','source.patch','setup-contract.json','focused.json','sizing.json','contract.md']
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for name in names:a.add(b/name,arcname=name)
for name in ['collect.py','archive-owned.py','launch.py']:compile((b/name).read_text(encoding='utf8'),name,'exec')
print('Prepared bounded B485',sha(candidate),(b/'payload.tgz').stat().st_size)
