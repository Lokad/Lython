from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent/'b485'
for name in ['launch.py','launch.log','launch-command.py','payload.tgz']:shutil.copyfile(r/name,r/('initial-'+name))
identity=json.loads((r/'identity.json').read_text(encoding='utf8'))
identity['catalogSHA256']=hashlib.sha256((r/'representative.json').read_bytes()).hexdigest()
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
s=(r/'launch.py').read_text(encoding='utf8')
s=s.replace("identity=json.loads((root/'identity.json').read_text());", "catalog_source=base/'prepared-binding-b483-20261108/representative.json'\n identity=json.loads((root/'identity.json').read_text());")
needle=" assert hashlib.sha256((reference/'Lokad.Lython.dll').read_bytes())"
at=s.index(needle)
s=s[:at]+" assert catalog_source.is_file() and not catalog_source.is_symlink() and catalog_source.stat().st_uid==os.geteuid() and os.access(catalog_source.parent,os.W_OK)\n assert hashlib.sha256(catalog_source.read_bytes()).hexdigest()==identity['catalogSHA256']\n os.link(catalog_source,root/'representative.json')\n"+s[at:]
s=s.replace('text-read-lifetime-b485-launch.py','text-read-lifetime-b485-launch-retry1.py').replace("r/'launch.log'","r/'launch-retry1.log'")
(r/'launch-retry1.py').write_text(s,encoding='utf8')
names=['collect.py','archive-owned.py','run.sh','current-core.dll','identity.json','pre-measurement-plan.md','baseline-source.json','source.patch','setup-contract.json','focused.json','sizing.json','contract.md']
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for name in names:a.add(r/name,arcname=name)
compile(s,'launch-retry1','exec')
print('Reused catalog exact SHA',identity['catalogSHA256'],'new compressed bytes',(r/'payload.tgz').stat().st_size)
