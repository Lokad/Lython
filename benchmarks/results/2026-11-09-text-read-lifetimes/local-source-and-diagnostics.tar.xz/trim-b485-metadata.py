from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent/'b485'
shutil.copyfile(r/'payload.tgz',r/'retry1-payload.tgz')
original=r/'baseline-source.json';shutil.copyfile(original,r/'baseline-source-full.json')
d=json.loads(original.read_text(encoding='utf8'))
fullhash=hashlib.sha256(original.read_bytes()).hexdigest()
d['fullProductionInventorySHA256']=fullhash
d['sources']={p:h for p,h in d['sources'].items()if p=='src/Lokad.Lython/Runtime/LythonRuntime.TextFileHandle.Read.cs'}
d['inventoryNote']='Full original inventory retained locally as baseline-source-full.json; changed source patch and exact core hashes travel with collection.'
original.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
s=(r/'launch-retry1.py').read_text(encoding='utf8').replace('text-read-lifetime-b485-launch-retry1.py','text-read-lifetime-b485-launch-retry2.py').replace('launch-retry1.log','launch-retry2.log')
(r/'launch-retry2.py').write_text(s,encoding='utf8')
names=['collect.py','archive-owned.py','run.sh','current-core.dll','identity.json','pre-measurement-plan.md','baseline-source.json','source.patch','setup-contract.json','focused.json','sizing.json','contract.md']
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for name in names:a.add(r/name,arcname=name)
print('Retained complete local inventory',fullhash,'remote source proof reduced from75254 bytes to',original.stat().st_size)
