from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;dest=r/'refined';dest.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cores=[Path(p)/'bin/Release/net11.0/Lokad.Lython.dll'for p in ['src/Lokad.Lython','tests/Lokad.Lython.Tests','tests/Lokad.Lython.PublicApi.Tests']]
assert len({sha(p)for p in cores})==1
for role in ['before','candidate']:shutil.copytree(r/'images-verified'/role,dest/'images-verified'/role)
shutil.copyfile(cores[0],dest/'images-verified/candidate/Lokad.Lython.dll')
for name in ['catalog.json','assess-local.py']:shutil.copyfile(r/name,dest/name)
s=(r/'measure.py').read_text(encoding='utf8').replace("old=r.parent/'integer-utf8-r45'","old=r.parent.parent/'integer-utf8-r45'")
assert "old=r.parent.parent/'integer-utf8-r45'" in s
(dest/'measure.py').write_text(s,encoding='utf8')
i=json.loads((r/'identity.json').read_text(encoding='utf8'))
i.update(candidate='R125 refined: entry ownership check replaces duplicate initial scanner poll; existing bounded refill/line checks retained',coreSHA256={role:sha(dest/'images-verified'/role/'Lokad.Lython.dll')for role in ['before','candidate']},sources={p:sha(Path(p))for p in subprocess.check_output(['git','ls-files','src'],text=True).splitlines()},qualification='225internal/140public eachactual11/10 plus16 final new-lifetime cases eachtarget (13 overlap); full delivery pending')
(dest/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf8')
print(i['coreSHA256'])
