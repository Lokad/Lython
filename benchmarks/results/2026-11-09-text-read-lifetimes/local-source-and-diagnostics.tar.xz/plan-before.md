# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Current contracts belong in docs; original/adverse conditions and prototypes live
in [experimental history](benchmarks/EXPERIMENTS.md) and immutable linked results.

## Actual delivery status

- **Fully qualified production:** R119 d05/core19b8; R120/R121 runtime6f76/corec617
  plus typed fixture correction d97. Cached CI42527042378success22:19:56UTC verifies
  Windows/Ubuntu full Release actual.NET11/.NET10, original stress on both targets,
  and installed-core consumers. Earlier CI42519822299/d05 and42512127664/b1 also
  cached success. Never requery terminal runs or repeat unchanged qualification.
- **Completed earlier work preserved:** shared compiler-fact correction,
  direct UTF8 formatting/storage, native helper returns, native JSON construction,
  record capacity/adoption, primitive result-shape facts/accounting, flat lookup
  storage and function-execution-owned field facts. No new engine/owner/options.
  Function lookup capacity conservatively survives until execution cleanup;
  admission reentrancy, actual suspension, refusal and retained aliases are covered.
- **Current external baseline:** [BENCHMARKS](docs/BENCHMARKS.md), R122/B481,
  measured6f76/corec617 versus CPython3.13.16. Fifteen jobs311.685s, all source,
  golden, quiet, ownership, cleanup, archive and local-verification gates pass.
  Compile-to-result: validatedCSV1.17x, CSV1.01–1.03xvariable, text1.52–1.53x,
  JSON0.91–0.96xvariable, report1.32–1.33x. Warm/compile separate; mediated RAM-file
  I/O, full validation and prior-result cleanup included. Startup, pending I/O,
  RSS and embedding tails unmeasured. Config/search/manifest remain historical726.
- **R124 prototype HELD, not promoted:** compile-owned named-argument slots/shared
  defaults, currentC4bb. Correctness81internal/41public peractual11/10 plus262public11
  pass; warm allocation neutral, compile allocation+0.20–0.25%. B483114.346s and
  B484109.217s verified; mainCSV candidate spread4.33% prevents a stable CPU claim.
  Original async text adverse remains; confirmation improves it, not consistently
  reproducing the adverse. Narrow registry/mapping/guard adds mechanisms while
  general binding remains necessary. No automatic percentage veto or permanent
  rejection: full source/binaries/data preserved for a broader redesign. Production
  restored to qualified source with forced fresh builds. Useful named/default/
  suspension/cancellation/refusal/alias regressions retained; targeted5internal/
  6public cases pass on each target after restoration. No active runtime prototype.

**Separate claims/debts:** native-return allocation−19.92/−19.31%, original elapsed
only diagnostic; formatting allocation−8.67%, controlledB102 elapsed/CPU−5–8%,
original adverse15.125ms unexplained/preserved. R110 wide allocation−8.56–8.58%.
R119 complete CSV/JSON~5–10% elapsed/custom~3–6%, supporting CPU; text inconclusive,
report CPU+1.53–6.25%possible debt. R120 custom allocation−1.71%, no CPU claim.
R121 confirmation report−6.09–6.66%, validatedCSV−3.30–5.45%/supportingCPU, inline
control±0.60%; async float variable. Combined earlier source pair's possible
async-float+1–2%debt remains. Independent source pairs are not additive and do not
silently settle older custom/config/report debts. Initial failed fixtures, widened
frames, report-cache inflation and inventory/collection mistakes remain in history.

## Prioritized roadmap

1. **Complete call/frame/operand design, not another isolated binding bypass.**
   Hypothesis: shared compiler facts and canonical executable invocation can remove
   complete repeated call preparation/operand classification transitions. R123 current
   complete helper/inline evidence~5.1vs3.3ms includes real calls/tuple work, not pure
   overhead. Binding/workspace4.97%leaf, preparation4.14%, context0; inclusive frame
   samples include useful execution. Current13instruction helper borrows bound locals;
   no missing local array/context allocation exists. Exact tuple unpack already
   borrows immutable items; tuple creation transfers its final array.

   Source gate about20min: identify a COMPLETE removable construction/dispatch phase,
   affected validatedCSV/report/JSON/text helper scripts and displaced code before
   selecting a redesign. Preserve measured native return allocation benefits, direct
   operands, managed stack admission, defaults/closures/recursion/evaluation order,
   actual callback suspension, cleanup and funded pending/retained aliases. Do not
   revive slower R71 arena/control/carriers or add another evaluator/owner/dispatcher.
   R124 positions may participate in broader fact consolidation; do not replay its
   unchanged narrow form just to chase timing. A temporary setback needs an explicit
   implementation-completion milestone and regression-debt decision before delivery.

   Acceptance: existing semantic/current-token cancellation/refusal/ownership tests,
   primary complete scripts and unchanged native controls; compile/warm/allocation/CPU
   separate. One bounded before/after on the quiet VM after source/correctness gates;
   confirmation/refinement allowed for specific evidence, not automatic thresholds.

2. **Bulk record/text/frontend simplification as an independent track.**
   - Per-record construction: revisit actual current intermediates, preserve order,
     duplicate keys, rest fields, hooks and retained rows. Original bulkCSV6–8% was
     reassessed with its adverse control; current CSV already adopts arrays and JSON
     constructs direct/shared-layout values. Copying premise is gone; no automatic
     promotion or permanent ban. R118 get/add/store would duplicate CFG/proofs and
     canonical code; no prototype selected. Any new design must displace real work.
   - Remaining text conversions: inline/native UTF8, casing-split, final-buffer
     formatting and cached hashes are delivered. Input windows already borrow raw
     bytes; returned copies protect refill immutability. A string-view representation
     needs explicit retained-lifetime/identity tradeoffs and a completion milestone.
     Select actual conversion/storage from existing CPU evidence, not assumed copies.
   - Frontend: compilation is a product boundary. Reuse immutable binding/scope facts
     and retain only live representations. ScopeDirectiveFacts already memoizes facts
     on syntax; LexicalScopePreparation publishes them before lowering. The apparent
     repeated ForFunction calls do not imply duplicate walks: inspected, no prototype
     or new measurement. A new analysis consolidation needs exact current callers,
     compile-to-result workloads and storage/work deleted; no new parser/framework.

   For each selected milestone record hypothesis, expected code/storage removal,
   representative scripts, Python/ownership/cancellation acceptance and bounded
   controls BEFORE implementation. Source gate about20min; if no coherent phase is
   demonstrated, record uncertainty and pursue independent work. No open-ended audit
   or measurement campaign. Scoped scalar/dispatch changes need dominant-cost evidence;
   boxing/inclusive samples alone do not justify universal tagged slots, JIT or VM
   stack replacement. This objective remains open after individual experiments.

3. **Independent regex contract/implementation and final adapter qualification.**
   Core owns Python/native UTF8 names, byte captures/scalar positions/original windows,
   effective flags/errors/replacements, one frontend/runtime/import provider, current
   tokens and explicit existing ownership. Development producers/adapter-local bridges
   are allowed; core has no Utf8Regex dependency and must not wait for publication.
   Optional adapter nonpackable, ordinary selected pin0.4. Dev55/d6067925 focused
   86internal/514public peractual11/10 already passed: no unchanged replay or sibling
   edits/builds. Final selected-package qualification needs DetailedData with separate
   preparation/working owners, native-name enumeration and cursor creation without
   retaining an earlier token. Track these precise capabilities, not a blanket block.
   Separate contract forwarding/unwind, Python semantics and actual backend speed.

## Iteration and containment

Bounded confirmation, source refinement and measurement correction are allowed
when evidence justifies them. Timeout, unstable unchanged controls or inconclusive
measurements establish uncertainty, not failed designs or permanent closure.
Percentages inform decisions, not automatic vetoes. Preserve original adverse/source/
control conditions. Architectural simplification, allocation reduction and measured
CPU improvement are distinct. Batch full platform/stress/installed-package checks
at retained coherent delivery boundaries; focused Release regressions during work.

AGENTS.md governs fully managed memory safety/stack admission, host mediation,
cooperative current-token cancellation, shared coarse admission/preflights/replacement
overlap, funded aliases/results/caches/pending users and awaited cleanup. Refusal is
terminal. No unsafe/Unsafe/native probes, tracing/weak reclaim/forcedGC, independent
caps/fuel/quotas, hidden allowance, silent regex fallback or abandoned work. No local
build/test/measurement overlap; force nonincremental builds after source restoration.
Explicit UTF8. Only core Release pack to artifacts/nuget; no publication.

VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem. Persistent workers/catalog/raw
separate from owned RAM fixtures; join/verify/unmount/archive under lease and verify
locally. All collections throughB484 terminal/cached/locally verified; no VM users or
fixtures, never requery. Cached terminal CI never queried again; observations of any
new active run at least5min apart. Space recovery only fresh idle exact-byte links,
permitted canonical ownership/writable parents/all-inode-alias/SHA proof and persisted
plan before mutation. Preserve every historical path/byte/archive. Original failed
conditions/corrections remain linked in history. Publication stays postponed.
