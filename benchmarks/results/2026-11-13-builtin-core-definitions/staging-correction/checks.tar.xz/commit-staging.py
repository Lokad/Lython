from pathlib import Path
import datetime,hashlib,io,json,re,subprocess,tarfile
r=Path(__file__).parent;frozen=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in frozen['sources'].items())
for framework in ('net11.0','net10.0'):
 text=(r/'staging-check'/(framework+'-test.log')).read_text(encoding='utf-8')
 assert 'Test Run Successful.'in text and 'Passed: 32'in text
out=Path('benchmarks/results/2026-11-13-builtin-core-definitions/staging-correction');out.mkdir(exist_ok=True)
failed=sorted(r.glob('failed-job-*.log'));assert len(failed)==1
with tarfile.open(out/'checks.tar.xz','w:xz')as a:
 for path in [*sorted((r/'staging-check').glob('*.log')),r/'check-staging.py',r/'commit-staging.py',*failed]:a.add(path,arcname=path.name)
 for name in ['AdmissionGateFixture.cs','FileStagingOwnershipTests.cs']:a.add('tests/Lokad.Lython.PublicApi.Tests/'+name,arcname=name)
(out/'README.md').write_text('''# File-staging allocation observation correction

The corrected runtime cb8736ff/frozen5a184a1d passed Ubuntu .NET11 ordinary
tests, then full delivery43446552390 failed in .NET10:
FileStagingOwnershipTests.PartlyFilledTextBufferRefusesBeforeWorkingBatchAllocationOrPublication(false)
observed94592process-global allocation bytes against the65536copy-sized bound.
The original completed Ubuntu job log is preserved in checks.tar.xz.

The interval from the clock gate to the first refusal has no I/O or suspension.
Observe current-thread allocation and assert equal thread identities, preserving
the65536bound, first shared-memory refusal, empty destination and zero final
reservation balance. This excludes unrelated process traffic rather than raising
the limit. No runtime sources changed. Focused Release checks pass32cases on each
actual.NET11/10 target; build/test logs and exact fixture sources are archived.
Cross-platform, original stress and installed-package qualification remains pending.
No performance claim follows from this test-only correction.
''',encoding='utf-8',newline='\n')
assert not subprocess.check_output(['git','diff','--cached','--name-only'],text=True).strip()
paths=['tests/Lokad.Lython.PublicApi.Tests/AdmissionGateFixture.cs','tests/Lokad.Lython.PublicApi.Tests/FileStagingOwnershipTests.cs','tests/README.md',str(out)]
for args in [['add','--',*paths],['diff','--cached','--check'],['commit','-m','Isolate file-staging admission allocation observation [skip ci]']]:subprocess.run(['git',*args],check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',head,'src/Lokad.Lython'])))as a:
 for p in frozen['sources']:assert a.extractfile(p).read().replace(b'\r\n',b'\n')==Path(p).read_bytes().replace(b'\r\n',b'\n'),p
subprocess.run(['git','push','origin','master'],check=True)
done=subprocess.run(['C:/Program Files/GitHub CLI/gh.exe','workflow','run','ci.yml','--ref','master','-f','stress=true'],capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
match=re.search(r'/runs/(\d+)',done.stdout+done.stderr);assert match,done.stdout+done.stderr
delivery=dict(head=head,runtimeSourceHead='cb8736ff3ad4886c08e0ac1417b55044d0325d41',coreSHA256=frozen['coreSHA256'],productionFiles=len(frozen['sources']),allFrozenSourcesMatchCommitWithExplicitNewlineNormalization=True,runId=match[1],url='https://github.com/Lokad/Lython/actions/runs/'+match[1],dispatchedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),fullQualificationPending=True,publicationHeld=True)
next_delivery=r/'staging-delivery';next_delivery.mkdir()
(next_delivery/'delivery-candidate.json').write_text(json.dumps(delivery,indent=2)+'\n',encoding='utf-8',newline='\n')
(next_delivery/'check-ci.py').write_bytes((r/'check-ci.py').read_bytes())
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');line=next(x for x in s.splitlines()if x.startswith('| Corrected commit; delivery pending |'))
s=s.replace(line,'| Corrected commit; delivery pending | **'+head[:8]+' tests / cb8736ff runtime / frozen5a184a1d**:86internal/802public focused11; staging/related32cases per actual11/10. Original157factory failure and43446552390Ubuntu10 process-global allocation failure retained. ['+delivery['runId']+']('+delivery['url']+') qualifies the corrected tests and exact unchanged573runtime inputs. Latest fully qualified source remains623until all delivery gates pass. |')
s=s.replace('Runtime code is unchanged by this\n   test correction. Preserve the failed run and qualify the corrected tests.','Runtime code is unchanged by this\n   test correction.32focused cases pass per actual11/10; corrected full delivery'+delivery['runId']+'is pending. Preserve the failed run.')
p.write_text(s,encoding='utf-8')
config=json.loads((r/'b683/config.json').read_text(encoding='utf-8'));config.update(qualificationHead=head,qualificationRun=delivery['runId'],qualificationDirectory=str(next_delivery))
(r/'b683/config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(delivery),flush=True)
