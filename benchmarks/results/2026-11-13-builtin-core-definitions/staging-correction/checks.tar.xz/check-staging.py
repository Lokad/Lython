from pathlib import Path
import os,subprocess
r=Path(__file__).parent/'staging-check';r.mkdir(exist_ok=True)
sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
project='tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj'
for framework in ('net11.0','net10.0'):
 for phase,args in [('build',['build',project,'-c','Release','-f',framework,'--no-restore','--disable-build-servers','-m:1']),('test',['vstest','tests/Lokad.Lython.PublicApi.Tests/bin/Release/'+framework+'/Lokad.Lython.PublicApi.Tests.dll','--TestCaseFilter:Category!=Stress&(FullyQualifiedName~FileStagingOwnership|FullyQualifiedName~NumericArithmeticAdmission|FullyQualifiedName~EncodingAdmission|FullyQualifiedName~ExceptionOwnership)','--logger:console;verbosity=normal'])]:
  p=r/(framework+'-'+phase+'.log');assert not p.exists()
  with p.open('w',encoding='utf-8') as out:done=subprocess.run([str(sdk/'dotnet.exe')]+args,env=env,stdout=out,stderr=subprocess.STDOUT)
  text=p.read_text(encoding='utf-8');print(p.name,done.returncode,text[-2200:],flush=True);assert done.returncode==0
