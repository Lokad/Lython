from pathlib import Path
import shutil
r=Path(__file__).parent
shutil.copyfile(r/'allocation.json',r/'source-gate-baseline-with-decorator.jsonl')
shutil.copyfile(r/'Program.cs',r/'baseline-inspector-source.txt')
