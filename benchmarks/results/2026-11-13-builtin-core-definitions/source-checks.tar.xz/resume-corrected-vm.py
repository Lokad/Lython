from pathlib import Path
import ast,base64,datetime,hashlib,json,shutil,subprocess
r=Path(__file__).parent/'b682';config=json.loads((r/'config.json').read_text(encoding='utf-8'))
stage={n:hashlib.sha256((r/n).read_bytes()).hexdigest()for n in ['identity.json','collect.py','archive-owned.py','run.sh']}
shutil.copyfile(r/'launch.log',r/'launch-failed-newline.log')
code='''from pathlib import Path
import ast,fcntl,hashlib,json,os,shutil,subprocess
config=CONFIG;stage=STAGE
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot']);digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert root.resolve(strict=True)==root and root.parent==base and source.parent==base and not(root/'guest-fixtures').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not(root/'exit-code.txt').exists()and not(root/'confirmation').exists()
 for n,h in stage.items():assert digest(root/n)==h
 for role in ['reference','candidate']:
  assert digest(root/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]
  for n,h in config['identity']['auxiliaryFiles'].items():assert digest(root/role/n)==h
 assert digest(root/'source-identity.json')==config['identity']['sourceIdentitySHA256']and digest(root/'reference-source-identity.json')==config['identity']['referenceSourceIdentitySHA256']and digest(root/'representative.json')==config['identity']['catalogSHA256']
 for n in ['collect.py','archive-owned.py']:ast.parse((root/n).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True);assert shutil.disk_usage(base).free>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(freshIdleLease=True,reusedExactImages=True,afterStagingFreeBytes=shutil.disk_usage(base).free,osFloorMiB=240,evidenceHeadroomMiB=12,additionalArchiveHeadroomMiB=2,retired=config['retireArchive'],stagedByteHashes=stage,correctedTextHashAssumption=True),indent=2)+'\\n')
 fixture=root/'guest-fixtures';fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b682-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=360','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True);assert'ActiveState=active'in live and'MainPID=0'not in live;print(live)
'''.replace('CONFIG',repr(config)).replace('STAGE',repr(stage))
ast.parse(code);(r/'resume-command.py').write_text(code,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];encoded=base64.b64encode(code.encode()).decode()
done=subprocess.run(ssh+["python3 -c 'import base64;exec(base64.b64decode(\""+encoded+"\"))'"],capture_output=True);(r/'resume-launch.log').write_bytes(done.stdout+done.stderr);print((done.stdout+done.stderr).decode(),flush=True);assert done.returncode==0
now=datetime.datetime.now(datetime.timezone.utc);(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=240)).isoformat(),ownerSeconds=360,stopSeconds=30,observationSeconds=240),indent=2)+'\n',encoding='utf-8')
