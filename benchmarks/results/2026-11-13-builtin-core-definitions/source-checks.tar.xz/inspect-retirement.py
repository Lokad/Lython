from pathlib import Path
import ast,subprocess
r=Path(__file__).parent;old=r.parent/'text-window-capacity-r314'
code=(old/'inspect-retirement.py').read_text(encoding='utf-8');a=code.index('specs=');b=code.index('\nproofs=',a)
code=code[:a]+"specs=[('integer-chain-b672-20261113/candidate/Lokad.Lython.dll','benchmarks/results/2026-11-13-native-integer-chains/source-checks.tar.xz',r.parent/'integer-chain-r311/candidate/Lokad.Lython.dll')]"+code[b:]
code=code.replace('prior8f','archived91 baseline').replace('current91 remains','active485 remains')
ast.parse(code);(r/'inspect-old-vm.py').write_text(code,encoding='utf-8')
subprocess.run(['python','-X','utf8',str(r/'inspect-old-vm.py')],check=True)
