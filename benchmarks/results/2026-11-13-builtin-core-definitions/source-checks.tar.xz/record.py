from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-13-builtin-core-definitions');out.mkdir(exist_ok=True);(out/'initial').mkdir(exist_ok=True)
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['sources'].items())
for kind,count in [('internal',94),('public',683)]:
 text=(r/(kind+'-shared-binding-test.log')).read_text(encoding='utf-8');assert 'Test Run Successful.'in text and f'Passed: {count}'in text
receipt=json.loads((r/'b682/archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined'];assert hashlib.sha256((r/'b682/observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for name in ['summary.json','observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(r/'b682'/name,out/name)
for name in ['incomplete-summary.json','incomplete-observations.tgz','incomplete-receipt.json']:shutil.copyfile(r/'b681'/name,out/'initial'/name)
factory={}
for role in ['reference','candidate']:
 text=(r/('factory-'+role+'.jsonl')).read_text(encoding='utf-8');first,end=json.JSONDecoder().raw_decode(text);second=json.loads(text[end:]);factory[role]=dict(measurement=first,decorator=second)
assert factory['reference']['measurement']['factoryBytesPerInvocation']==10248 and factory['candidate']['measurement']['factoryBytesPerInvocation']==7680
(out/'factory-observations.json').write_text(json.dumps(dict(scope='Builtin factory only; elapsed diagnostic, not CPU comparison',bytesRemoved=2568,observations=factory),indent=2)+'\n',encoding='utf-8')
with tarfile.open(out/'source-checks.tar.xz','w:xz')as a:
 for p in r.iterdir():
  if p.is_file()and(p.suffix in ['.py','.cs','.csproj','.json','.jsonl','.log','.txt']or p.name in ['candidate-core.dll','candidate-sources.tar.xz']):a.add(p,arcname=p.name)
 for phase in ['b681','b682']:
  for p in(r/phase).iterdir():
   if p.is_file()and p.name not in ['payload.tgz','observations.tgz','incomplete-observations.tgz']:a.add(p,arcname=phase+'/'+p.name)
 a.add(r/'phases',arcname='reconstructed-failed-source-phases')
 for name in ['BuiltinDefinitionIsolationTests.cs','BuiltinRootIdentityTests.cs']:
  a.add(Path('tests/Lokad.Lython.PublicApi.Tests')/name,arcname='tests/'+name)
print('7ee exact inputs/bits,94/683, factory adverse clocks, original incomplete failure and corrected all-gates comparison archived.',flush=True)
