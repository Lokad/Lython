from pathlib import Path
import subprocess
r=Path(__file__).parent
s=(r/'runtime-check.py').read_text(encoding='utf-8')
s=s.replace("kind+'-build.log'","kind+'-corrected-build.log'").replace("kind+'-test.log'","kind+'-corrected-test.log'")
(r/'corrected-check.py').write_text(s,encoding='utf-8')
subprocess.run(['python','-X','utf8',str(r/'corrected-check.py')],check=True)
