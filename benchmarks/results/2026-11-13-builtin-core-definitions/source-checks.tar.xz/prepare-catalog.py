from pathlib import Path
import base64,hashlib,json
r=Path(__file__).parent;prior=r.parent/'call-construction-r315'
original=json.loads((prior/'catalog.json').read_text(encoding='utf-8'));all_cases=json.loads((r/'all-representative.json').read_text(encoding='utf-8'))
selected=['scripts.config-edit.small','scripts.file-manifest.large']
assert not any(c['id']in selected for c in original['cases'])
for key in selected:
 c=next(c for c in all_cases['cases']if c['id']==key);original['cases'].append(c)
 fixture=json.loads(c['fixtureJson']);print(key,'input bytes',sum(len(base64.b64decode(b))for b in fixture['inputFiles'].values()),'source',c['sourceSha256'],flush=True)
original['fixtureEncoding']='Original eight-fixture source-pair catalog plus existing generator config/manifest cases; command-v2 boundaries unchanged'
(r/'catalog.json').write_text(json.dumps(original,indent=2)+'\n',encoding='utf-8')
print('10 exact cases; no guest execution or timing in catalog generation.',flush=True)
