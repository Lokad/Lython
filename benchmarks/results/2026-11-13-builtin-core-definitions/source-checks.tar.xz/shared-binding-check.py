from pathlib import Path
import os, subprocess
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
names={'internal': ['NamespaceAdmission', 'DefaultObjectAttributeBoundary', 'ClassMethodExecutionBoundary', 'ConstructorOwnership', 'CopyCallerContext', 'ExecutionFrameNamespace', 'ManagedStackGuard', 'NativeFunctionRefund'], 'public': ['BuiltinDefinitionIsolation', 'BuiltinRootIdentity', 'BuiltinSlotOwner', 'BuiltinsModuleTests', 'BuiltinTypeRecognition', 'BuiltinObjectExceptionFunction', 'BuiltinClassPattern', 'DefaultObjectAttributeTests', 'Dataclass', 'ClassMethod', 'Constructor', 'MappingProxy', 'Metaclass', 'Descriptor']}
for kind in names:
    project='tests/'+('Lokad.Lython.Tests/Lokad.Lython.Tests.csproj' if kind=='internal' else 'Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj')
    p=r/(kind+'-shared-binding-build.log');assert not p.exists()
    args=[str(sdk/'dotnet.exe'),'build',project,'-c','Release','-f','net11.0','--no-restore','--disable-build-servers','-m:1']
    with p.open('w',encoding='utf-8')as log:done=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
    txt=p.read_text(encoding='utf-8');print(p.name,done.returncode,txt[-1800:],flush=True);assert done.returncode==0
    p=r/(kind+'-shared-binding-test.log');assert not p.exists()
    dll='tests/'+('Lokad.Lython.Tests/bin/Release/net11.0/Lokad.Lython.WhiteBox.Tests.dll'if kind=='internal'else'Lokad.Lython.PublicApi.Tests/bin/Release/net11.0/Lokad.Lython.PublicApi.Tests.dll')
    args=[str(sdk/'dotnet.exe'),'vstest',dll,'--TestCaseFilter:Category!=Stress&('+'|'.join('FullyQualifiedName~'+n for n in names[kind])+')','--logger:console;verbosity=normal']
    with p.open('w',encoding='utf-8')as log:done=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
    txt=p.read_text(encoding='utf-8');print(p.name,done.returncode,txt[-2400:],flush=True);assert done.returncode==0 and 'Test Run Successful.'in txt
