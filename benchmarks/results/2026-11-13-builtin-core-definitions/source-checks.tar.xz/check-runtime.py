from pathlib import Path
import ast,subprocess
r=Path(__file__).parent;old=r.parent/'call-construction-r315/check.py'
code=old.read_text(encoding='utf-8');a=code.index('names={');b=code.index('\nfor kind in names:',a)
names={'internal':['NamespaceAdmission','DefaultObjectAttributeBoundary','ClassMethodExecutionBoundary','ConstructorOwnership','CopyCallerContext','ExecutionFrameNamespace','ManagedStackGuard','NativeFunctionRefund'],
'public':['BuiltinDefinitionIsolation','BuiltinRootIdentity','BuiltinSlotOwner','BuiltinsModuleTests','BuiltinTypeRecognition','BuiltinObjectExceptionFunction','BuiltinClassPattern','DefaultObjectAttributeTests','Dataclass','ClassMethod','Constructor','MappingProxy','Metaclass','Descriptor']}
code=code[:a]+'names='+repr(names)+code[b:];ast.parse(code);(r/'runtime-check.py').write_text(code,encoding='utf-8')
subprocess.run(['python','-X','utf8',str(r/'runtime-check.py')],check=True)
