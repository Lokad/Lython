from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;prior=r.parent/'call-construction-r315';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for kind,count in [('internal',94),('public',683)]:
 s=(r/(kind+'-shared-binding-test.log')).read_text(encoding='utf-8');assert 'Test Run Successful.'in s and f'Passed: {count}'in s
old=json.loads((prior/'candidate-identity.json').read_text(encoding='utf-8'));sources={p:sha(p)for p in old['sources']};changed=[p for p in sources if sources[p]!=old['sources'][p]]
assert set(changed)=={'src/Lokad.Lython/Runtime/LythonRuntime.ExecutionContext.Builtins.cs','src/Lokad.Lython/Runtime/PyType.cs','src/Lokad.Lython/Runtime/PyMemberAccess.cs','src/Lokad.Lython/Runtime/PyBuiltinRuntimeType.cs','src/Lokad.Lython/Runtime/PyAttributeLookup.cs'},changed
for role in ['reference','candidate']:
 shutil.copytree(prior/'candidate',r/role,copy_function=os.link)
 if role=='candidate':
  (r/role/'Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/role/'Lokad.Lython.dll')
shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(old,head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),description='R317 fixed immutable object/type metadata; per-caller namespace views; centralized builtin immutability before dataclass mutation; raw builtin object new without staticmethod wrapper and shared opaque-slot lookup',referenceSHA256=sha(r/'reference/Lokad.Lython.dll'),coreSHA256=sha(r/'candidate-core.dll'),sources=sources,changed=changed)
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for p in sources:a.add(p,arcname=p)
print(identity['coreSHA256'],'573inputs,94internal/683public pass; fixed immutable definitions prototype.',flush=True)
