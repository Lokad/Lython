from pathlib import Path
import ast,subprocess
r=Path(__file__).parent
s=(r/'b681/summarize.py').read_text(encoding='utf-8').replace("r/'retrieved/confirmation/confirmation.json'","r/'incomplete-retrieved/confirmation/confirmation.json'")
s=s.replace("raw['complete']and len(raw['jobs'])==5","not raw['complete']and len(raw['jobs'])==1")
s=s.replace("r/'summary.json'","r/'incomplete-summary.json'").replace('complete=True,jobs=5','complete=False,jobs=1')
s=s.replace("elapsedSeconds=raw['elapsedSeconds']","elapsedSeconds=None")
ast.parse(s);(r/'b681/summarize-incomplete.py').write_text(s,encoding='utf-8')
subprocess.run(['python','-X','utf8',str(r/'b681/summarize-incomplete.py')],check=True)
