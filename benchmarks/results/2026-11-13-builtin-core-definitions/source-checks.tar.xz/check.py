from pathlib import Path
import os,subprocess
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';'+env['PATH']
with(r/'build.log').open('w',encoding='utf-8')as log:done=subprocess.run([str(sdk/'dotnet.exe'),'build',str(r/'inspect.csproj'),'-c','Release','--disable-build-servers','-m:1'],env=env,stdout=log,stderr=subprocess.STDOUT)
print('build',done.returncode,(r/'build.log').read_text(encoding='utf-8')[-1000:],flush=True);assert done.returncode==0
with(r/'allocation.json').open('w',encoding='utf-8')as out:subprocess.run([str(sdk/'dotnet.exe'),str(r/'bin/Release/net11.0/Lokad.Lython.WhiteBox.Tests.dll')],env=env,stdout=out,check=True)
print((r/'allocation.json').read_text(encoding='utf-8'),flush=True)
