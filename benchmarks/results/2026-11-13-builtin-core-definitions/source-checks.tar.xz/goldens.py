from pathlib import Path
import json,subprocess
r=Path(__file__).parent;rows=[]
for target in ['object','type']:
 source=f"from dataclasses import dataclass\ntry:dataclass({target})\nexcept TypeError:print('immutable')\nprint(hasattr({target},'__dataclass_fields__'))"
 done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-'],input=source,text=True,encoding='utf-8',capture_output=True,check=True)
 assert done.stdout=='immutable\nFalse\n'and not done.stderr
 rows.append(dict(source=source,output=done.stdout))
(r/'python-goldens.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
source="print(object.__dict__['__new__'].__self__ is object)\nprint(type.__dict__['__new__'].__self__ is type)"
done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-'],input=source,text=True,encoding='utf-8',capture_output=True,check=True)
assert done.stdout=='True\nTrue\n'and not done.stderr
(r/'namespace-goldens.json').write_text(json.dumps(dict(source=source,output=done.stdout),indent=2)+'\n',encoding='utf-8')
print('Both immutable builtin decorator cases match isolated CPython.',flush=True)
