from pathlib import Path
import ast,base64,datetime,json,subprocess
r=Path(__file__).parent/'b682';config=json.loads((r/'config.json').read_text(encoding='utf-8'))
code='''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot']);digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and source.parent==base and not root.exists()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(source/'guest-fixtures').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 for role in ['reference','candidate']:
  assert digest(source/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]
  for n,h in config['identity']['auxiliaryFiles'].items():assert digest(source/role/n)==h
 retired=config['retireArchive'];path=base/retired['path'];st=path.lstat()
 assert path.resolve(strict=True)==path and path.is_relative_to(base)and path.is_file()and st.st_uid==os.getuid()and st.st_nlink==1 and st.st_size==retired['bytes']and digest(path)==retired['sha256']
 assert shutil.disk_usage(base).free+st.st_blocks*512>254*1024*1024+config['unpackedBytes']
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 assert digest(path)==retired['sha256'];path.unlink()
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:a.extractall(root,filter='data')
 for n in ['source-identity.json','reference-source-identity.json','representative.json','cpython-worker.py']:os.link(source/n,root/n)
 for role in ['reference','candidate']:shutil.copytree(source/role,root/role,copy_function=os.link)
 assert digest(root/'identity.json')==hashlib.sha256(json.dumps(config['identity'],indent=2).encode()+b'\\n').hexdigest()
 assert digest(root/'source-identity.json')==config['identity']['sourceIdentitySHA256']and digest(root/'reference-source-identity.json')==config['identity']['referenceSourceIdentitySHA256']
 assert digest(root/'representative.json')==config['identity']['catalogSHA256']
 for n in ['collect.py','archive-owned.py']:ast.parse((root/n).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 assert shutil.disk_usage(base).free>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(freshIdleLease=True,reusedExactImages=True,afterStagingFreeBytes=shutil.disk_usage(base).free,osFloorMiB=240,evidenceHeadroomMiB=12,additionalArchiveHeadroomMiB=2,retired=retired),indent=2)+'\\n')
 fixture=root/'guest-fixtures';fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b682-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=360','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True);assert'ActiveState=active'in live and'MainPID=0'not in live;print(live)
'''.replace('CONFIG',repr(config))
ast.parse(code);(r/'launch-command.py').write_text(code,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
encoded=base64.b64encode(code.encode()).decode();command="python3 -c 'import base64;exec(base64.b64decode(\""+encoded+"\"))'"
done=subprocess.run(ssh+[command],input=(r/'payload.tgz').read_bytes(),capture_output=True);(r/'launch.log').write_bytes(done.stdout+done.stderr);print((done.stdout+done.stderr).decode(),flush=True);assert done.returncode==0
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=240)).isoformat(),ownerSeconds=360,stopSeconds=30,observationSeconds=240),indent=2)+'\n',encoding='utf-8')
