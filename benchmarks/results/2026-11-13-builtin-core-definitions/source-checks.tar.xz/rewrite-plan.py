from pathlib import Path
p=Path('PLAN.md');backup=Path(__file__).parent/'PLAN-before-concise-roadmap.md'
assert not backup.exists();backup.write_text(p.read_text(encoding='utf-8'),encoding='utf-8')
p.write_text('''# Lokad.Lython 0.11.0

Updated 2026-11-13. Git-ignored; never force-add. Publication and tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including newly generated scripts. Another experiment or green CI does not finish it.

## Actual delivery status

| State | Source, evidence and limit |
| --- | --- |
| Committed and fully qualified runtime | **6237552b / frozen485e008e**, GREEN43435357297: Windows/Ubuntu actual.NET11/10, ordinary tests, original stress and installed Release consumers. All573 inputs match the exact CI commit with explicit newline normalization; logs/16step counts cached. [Delivery](benchmarks/results/2026-11-13-selected-native-call/delivery/README.md). Do not replay unchanged qualification. |
| Active prototype, not promoted | **R317 / frozen7ee65002** shares fixed immutable object/type definitions, preserves caller-owned namespace views and corrects internal builtin mutation/raw-new-slot behavior.94internal/683public Release11 checks pass. Factory allocation10248→7680B/invocation; local elapsed adverse and diagnostic. B681 config warm/fresh, manifest, invoice/report comparison active. No whole-script or full-delivery claim. |
| Withdrawn storage designs | R314 counted and byte-bound window grants are removed; production restoration to40d is source-proved and198internal/106public checks pass. Eight useful cases committed766e2071. [All original/refined/adverse results](benchmarks/results/2026-11-13-text-window-capacity/rough/README.md). R308 shared CSV backing is also absent; six lifetime cases survive. |
| Independent adapter development | R316 immutabledev80/15b248dc bridge:88internal/534public per actual11/10. Normal29inputs/binaries and573core sources unchanged. Optional normal pin remains0.4; core has no backend dependency. [Exact evidence and gaps](benchmarks/results/2026-11-13-regex-dev80-bridge/README.md). These semantic checks do not establish backend performance/safety or qualify a final release. |
| Latest external comparison, historical to HEAD | Qualified85c73469/8f, CPython3.13.16,2026-11-13: invoice warm1.27–1.31×, compilation1.08–1.09×, fresh1.29–1.31×; variable captured warm1.65–1.75×, search1.75–1.82×, JSON0.82–0.86×. [Sources, controls, I/O/cleanup boundaries](benchmarks/results/2026-11-13-native-return-cpython-checkpoint/README.md). No later gains are multiplied into these ratios. |

## Completed milestones and unresolved debt

- Shared compiler facts/nonlocal correction, annotation demand, lowered-tree
  retention cleanup, direct UTF8 storage/formatting and native helper returns are
  delivered. Historical formatting allocation−8.67% is separate from later supported
  elapsed/CPU direction; the original adverse15.125ms remains unexplained/preserved.
  Historical helper allocation−19.92%Run/−19.31%Async is separate from diagnostic
  elapsed. Reuse their source-specific qualification; [history](benchmarks/EXPERIMENTS.md).
- Native calls use final slots and transfer once to the existing linear runner.
  Separate graph/proof/evaluation and redundant selection/admission are removed.
  The original small-continuation crash, corrected managed depth handoff and slower
  call-arena/control designs remain explicit history; do not restore those designs.
- Qualified40d integer chains remove16384 intermediate boxes/524288B per4096 invoice
  records: allocation−8.46..−8.48%, supported invoice warm/fresh CPU direction.
  [Original report adversity and moving confirmation controls](benchmarks/results/2026-11-13-native-integer-chains/README.md)
  remain unresolved debt.623's text/invoice direction does not resolve that debt.
- The old bulk CSV constructor opportunity (historical6–8%) already shipped in a
  revised form. Current rows adopt funded arrays/shared keys; JSON construction is
  iterative and direct. R308 shared field backing and R314 window grants are
  withdrawn for their measured tradeoffs, not permanently banned by percentages.
  Preserve their independent semantic/ownership regressions and adverse evidence.

Detailed phases, failed conditions and rejected forms live in immutable results and
[EXPERIMENTS](benchmarks/EXPERIMENTS.md), not this active plan or current guides.

## Prioritized deliverables

1. **R317: finish fixed invocation construction.** Delete per-run object/type
   descriptor, MRO and type construction using fixed assembly-owned definitions.
   Keep mutable builtin callable hierarchy caches and namespaces per execution.
   Shared types must never retain a caller's namespace or memory owner. Per-access
   immutable namespace views deliberately admit their wrappers under the actual
   caller; repeated introspection can retain more minor view storage until cleanup.
   Central immutability must reject internal dataclass mutation before changing a
   shared type. Remove the redundant builtin-new staticmethod wrapper and reuse
   canonical inherited-slot binding, preserving original owners and Python errors.
   Acceptance: builtin rebinding, user classes/metaclasses, slot aliases, concurrent
   and suspended executions, retained results/views, terminal refusal, cancellation,
   joined cleanup and budget reuse. Initial/refined683-case failures are preserved;
   final94/683pass and isolated CPython goldens are established. Finish B681's five
   short complete-script jobs, separating factory allocation from measured CPU.
   Record warm versus first-initialization tradeoffs and make an explicit retention/
   regression-debt decision. At retention batch full platform/stress/consumer checks;
  623's completed delivery never qualifies this newer source.

2. **Refresh representative CPython comparisons at the retained checkpoint.**
   Use existing workers/catalog/goldens on the quiet VM; select material CSV/text/
   JSON/file/report rows, avoiding another blanket campaign. Separate compilation,
   warm and compile-to-result; state included mediated I/O, validation and prior-result
   cleanup, and excluded startup/reset/protocol/final-cache teardown. Wider process
   CPU includes reset/protocol. Update current benchmark guide with exact source,
   versions/date/machine, controls and uncertainty; preserve all replaced rows.

3. **Select the next substantial construction/transport redesign from evidence.**
   Each selected milestone names the hypothesis, affected complete scripts, actual
   work/storage/pass eliminated, semantic acceptance, displaced code to delete and
   one bounded source-pair comparison with unchanged controls. Temporary setbacks
   need a named completion milestone and a decision on remaining debt.

   | Area | Current evidence and next design boundary |
   | --- | --- |
   | Complete calls/frames/operands | R313 identifies meaningful native entry/dispatch, including a live keyword-only default; useful/inlined work and20%unknown are not removable CPU shares. R315 removes redundant selection/logical admission. Search has3free caller operands versus6callee slots; invoice7versus12. Do not recreate an arena. Any larger migration must remove an actual packet/workspace/activation, preserve evaluation/error order, defaults/receivers/closures and exact one-way suspension transfer, and keep the256KiB continuation safe. |
   | Scalar transport | R311 proves unpublished integer boxes can matter. Assess remaining complete-workflow costs before a broader representation change; overflow, identity/aliases, Python boundaries and admitted capacity require a concrete design. Do not infer that boxing alone explains the external gap or automatically start a universal tagged-value rewrite. |
   | Per-record collections/bulk text | Current CSV/PyDict adoption, iterative JSON and UTF8 formatting/casing already remove old intermediates. Select a genuinely remaining representation/pass; do not repeat R308 or R314 without a different removal/ownership argument. Preserve eager Python values/errors, hooks, Unicode, retained aliases and bounded host-driven batches. |
   | Frontend | R312's modeled duplicate name strings are0.41–0.95%of full allocation, not measured removable CPU. No name cache or blind flow-visitor merge. Select substantial repeated facts or retained IR, preserving distinct flow-sensitive diagnostics, scope/annotation facts, cancellation and admission. |

   Stop a source gate with a concrete removal/design or a precise unresolved
   boundary, then advance the roadmap. Do not repeatedly inventory unchanged paths
   or treat finishing another isolated experiment as the performance objective.

4. **Keep regex development independent.** The core's Python-specific nativeUTF8
   contract covers frontend/runtime/imports, byte ranges/scalar positions/original
   windows, flags/captures/errors, current-token work and explicit cache/result owners.
   Continue core implementation/testing independently of published producer APIs;
   adapter-local bridges and precisely pinned development packages are allowed.
   Dev80 changed-source checks are complete; do not repeat them unchanged. Precise
   producer gaps: separate one-match working/result owners; UTF8 group-name
   enumeration/copy (lookup exists); token-independent cursor construction with
   cancellable preparation. Missing capabilities defer only affected final adapter
   qualification. Keep bridges outside core, the adapter nonpackable, and contract
   tests, semantic checks, real backend performance and final safety qualification
   distinct. Cached patterns must not retain an earlier operation's token.

## Evidence policy and lasting constraints

Distinguish simplification, allocation reduction and demonstrated CPU improvement.
Percentages inform decisions; they do not automatically veto useful changes.
Timeouts, unstable unchanged controls and inconclusive results establish uncertainty.
Allow bounded confirmation, refinement or measurement correction with stated reasons;
retain original/adverse results and failed conditions. No one-attempt/no-retiming/
permanent-closure rules. Size short runs for usable observations on the existing
quiet VM; long lanes are infrequent milestones. Focused Release checks during
development, batched Windows/Ubuntu actual11/10, original stress and installed
Release consumers at delivery. Cache terminal CI; queries minutes apart. Force
nonincremental builds after source restoration. Persist evidence, join actual users
and SHA-verify RAM archives before unmount; preserve VM floors and active images.

Remain fully managed/memory-safe: no unsafe compilation/C#/APIs, pointers, P/Invoke
or native probing. Preserve managed stack/recursion safety, cooperative cancellation,
host authorization/original path requests+Cwd, cycles/XML depth, checked bounds and
bounded I/O chunks. No fuel/quotas, hidden caps/default allowances, regex time/work
policies, tracing, weak reclamation, forcedGC or abandoned work. Borrowed shared
allowance funds major capacity, overlap, retained aliases/results/caches and pending
users. First refused admission remains terminal through suppression/finally;
preserve its origin and await cleanup/refunds, never retry. Current docs stay
Lython-centric; history belongs outside docs. Publication remains postponed.
''',encoding='utf-8')
print('Ignored PLAN condensed around actual delivery, active prototype, evidence/debt and continuing redesign roadmap.',flush=True)
