from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;old=r.parent/'call-construction-r315/b680';out=r/'b681';out.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
frozen=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));assert all(sha(p)==h for p,h in frozen['sources'].items())
oldroot='/home/lokad/lython-bench-checks/selected-call-b680-20261113';root='/home/lokad/lython-bench-checks/builtin-setup-b681-20261113'
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='Committed6237552b/frozen485e008e versus uncommitted R317/'+frozen['coreSHA256'][:8],purpose='Fixed immutable object/type construction; config warm/fresh and manifest warm with invoice/report controls',coreSHA256={k:frozen['referenceSHA256']if k.startswith('reference')else frozen['coreSHA256']for k in identity['coreSHA256']},catalogSHA256=sha(r/'catalog.json'),referenceSourceIdentitySHA256=sha(r.parent/'call-construction-r315/candidate-identity.json'),sourceIdentitySHA256=sha(r/'candidate-identity.json'),productionSourceArchiveSHA256=sha(r/'candidate-sources.tar.xz'))
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
jobs=[['scripts.config-edit.small','warm'],['scripts.config-edit.small','fresh'],['scripts.file-manifest.large','warm'],['scripts.csv-invoice.large','warm'],['scripts.report-render.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 code=(old/name).read_text(encoding='utf-8').replace(oldroot,root).replace('lython-b680-selected-call-20261113','lython-b681-builtin-setup-20261113').replace('B680','B681')
 if name=='collect.py':
  a=code.index('jobs=');b=code.index('\nenv =',a);code=code[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n'+code[b:]
 if name.endswith('.py'):ast.parse(code)
 (out/name).write_text(code,encoding='utf-8',newline='\n')
files={n:out/n for n in ['identity.json','collect.py','archive-owned.py','run.sh']};files.update({'current-core.dll':r/'candidate-core.dll','source-identity.json':r/'candidate-identity.json','representative.json':r/'catalog.json'})
with tarfile.open(out/'payload.tgz','w:gz')as a:
 for name,p in files.items():a.add(p,arcname=name)
retire=json.loads((r/'retirement-inspection.json').read_text(encoding='utf-8'))['groups'];assert len(retire)==1 and retire[0]['sha256']=='91d0540d439109dd35f3246c4c6234a69a2bc2b698012c83859e9d425d14cc78'
config=dict(json.loads((old/'config.json').read_text(encoding='utf-8')),root=root,unit='lython-b681-builtin-setup-20261113',sourceRoot=oldroot,sourceCoreSHA256=frozen['referenceSHA256'],identity=identity,retire=retire,retireArchives=[],payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=sha(out/'payload.tgz'),unpackedBytes=sum(p.stat().st_size for p in files.values()))
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
code=(old/'launch.py').read_text(encoding='utf-8').replace('b680','b681')
a=code.index(" catalogSource=Path(config['catalogRoot'])");b=code.index(" assert digest(root/'current-core.dll')",a)
code=code[:a]+code[b:]
code=code.replace('current91 and canonical older snapshots stay','active485 and all canonical source evidence stay')
ast.parse(code);(out/'launch.py').write_text(code,encoding='utf-8')
print('B681 existing config warm/fresh and manifest warm, invoice/report controls; exact485 baseline; staged',config['unpackedBytes'],'bytes; floors unchanged.',flush=True)
