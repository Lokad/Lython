from pathlib import Path
import ast,hashlib,json,subprocess,tarfile
r=Path(__file__).parent;old=r/'b681';out=r/'b682';out.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
config=json.loads((old/'config.json').read_text(encoding='utf-8'));oldroot=config['root'];root='/home/lokad/lython-bench-checks/builtin-setup-corrected-b682-20261113'
identity=dict(config['identity'],purpose='Same R317 frozen source pair; correct config compile-run protocol lane after original unsupported fresh label; no runtime change')
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(old/name).read_text(encoding='utf-8').replace(oldroot,root).replace('lython-b681-builtin-setup-20261113','lython-b682-builtin-setup-corrected-20261113').replace('B681','B682')
 if name=='collect.py':
  s=s.replace("['scripts.config-edit.small', 'fresh']","['scripts.config-edit.small', 'compile-run']")
  s=s.replace('Selected native call/body admission; search/captured text/JSON warm with invoice/report controls; exact source pair, no external ratio','Fixed immutable object/type metadata; config warm/compile-run and manifest, invoice/report controls; corrected protocol label, same exact bits')
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
files={n:out/n for n in ['identity.json','collect.py','archive-owned.py','run.sh']}
with tarfile.open(out/'payload.tgz','w:gz')as a:
 for n,p in files.items():a.add(p,arcname=n)
canonical=Path('benchmarks/results/2026-11-13-selected-native-call/observations.tgz');assert subprocess.check_output(['git','show','HEAD:'+canonical.as_posix()])==canonical.read_bytes()
settings=dict(root=root,unit='lython-b682-builtin-setup-corrected-20261113',sourceRoot=oldroot,identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=sha(out/'payload.tgz'),unpackedBytes=sum(p.stat().st_size for p in files.values()),retireArchive=dict(path='selected-call-b680-20261113/observations.tgz',bytes=canonical.stat().st_size,sha256=sha(canonical),canonical=canonical.as_posix()))
(out/'config.json').write_text(json.dumps(settings,indent=2)+'\n',encoding='utf-8')
print('Same frozen7ee/485 cores and catalog; five corrected existing-protocol jobs; hardlink reused images; staged',settings['unpackedBytes'],'bytes.',flush=True)
