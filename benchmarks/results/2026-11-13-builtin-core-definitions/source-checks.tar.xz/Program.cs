using Lokad.Lython;
using Lokad.Lython.Runtime;
using System.Diagnostics;
using System.Reflection;
using System.Text.Json;

var factory=typeof(LythonRuntime.ExecutionContext).GetMethod("CreateBuiltinVariables",BindingFlags.Static|BindingFlags.NonPublic)!
    .CreateDelegate<Func<Dictionary<string,object>>>();
const int count=512;
for(var i=0;i<256;i++)_ = factory();
var before=GC.GetAllocatedBytesForCurrentThread();
var start=Stopwatch.GetTimestamp();
for(var i=0;i<count;i++)_ = factory();
var bytes=GC.GetAllocatedBytesForCurrentThread()-before;
Console.WriteLine(JsonSerializer.Serialize(new {purpose="Fixed builtin-factory allocation source gate; no guest work or performance comparison",count,
    factoryBytesPerInvocation=bytes/(double)count,diagnosticMilliseconds=Stopwatch.GetElapsedTime(start).TotalMilliseconds,
    limitation="Whole factory includes mutable execution-owned type caches; its bytes are not all removable. Object/type subset not isolated; elapsed is diagnostic."},new JsonSerializerOptions{WriteIndented=true}));

using var regression=new LythonEngine().Run("""
    from dataclasses import dataclass
    try:
        dataclass(object)
    except TypeError:
        print('rejected')
    else:
        print('mutated')
    print(hasattr(object,'__dataclass_fields__'))
    """,new PureHost());
Console.WriteLine(JsonSerializer.Serialize(new {kind="Existing source decorator behavior",regression.Success,regression.StandardOutput,failure=regression.Failure?.Message}));

sealed class PureHost:ILythonHost
{
    public string Cwd=>"/";
    public DateTimeOffset LocalNow=>DateTimeOffset.UnixEpoch;
    public DateTimeOffset UtcNow=>DateTimeOffset.UnixEpoch;
    public ValueTask<bool> ExistsAsync(LythonPathRequest path,CancellationToken token)=>ValueTask.FromResult(false);
    public ValueTask<IReadOnlyList<string>> ListDirAsync(LythonPathRequest path,CancellationToken token)=>throw new NotSupportedException();
    public ValueTask MkDirAsync(LythonPathRequest path,CancellationToken token)=>throw new NotSupportedException();
    public ValueTask RemoveAsync(LythonPathRequest path,CancellationToken token)=>throw new NotSupportedException();
    public ValueTask CopyAsync(LythonPathRequest a,LythonPathRequest b,CancellationToken token)=>throw new NotSupportedException();
    public ValueTask MoveAsync(LythonPathRequest a,LythonPathRequest b,CancellationToken token)=>throw new NotSupportedException();
    public ValueTask<LythonPathStat> StatAsync(LythonPathRequest path,CancellationToken token)=>ValueTask.FromResult(new LythonPathStat(LythonPathKind.Missing,0,null));
}
