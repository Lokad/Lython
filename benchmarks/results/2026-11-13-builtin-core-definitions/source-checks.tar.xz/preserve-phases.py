from pathlib import Path
import json,subprocess
r=Path(__file__).parent;out=r/'phases';out.mkdir()
paths=['src/Lokad.Lython/Runtime/LythonRuntime.ExecutionContext.Builtins.cs','src/Lokad.Lython/Runtime/PyType.cs','src/Lokad.Lython/Runtime/PyMemberAccess.cs','src/Lokad.Lython/Runtime/PyBuiltinRuntimeType.cs','src/Lokad.Lython/Runtime/PyAttributeLookup.cs']
for phase in ['initial','raw-new','opaque-raw']:
 folder=out/phase;folder.mkdir()
 for p in paths:
  text=Path(p).read_text(encoding='utf-8')
  if phase=='initial'and p.endswith('ExecutionContext.Builtins.cs'):text=text.replace('["__new__"] = new ObjectNewMethod()','["__new__"] = new PyStaticMethod(new ObjectNewMethod())')
  if p.endswith('PyAttributeLookup.cs')or p.endswith('PyBuiltinRuntimeType.cs')and phase!='opaque-raw':text=subprocess.check_output(['git','show','6237552b:'+p]).decode('utf-8')
  elif p.endswith('PyBuiltinRuntimeType.cs'):
   text=text.replace('value = PyAttributeLookup.BindForType(objectType, sharedRaw, context, span);','value = sharedRaw is IPyDescriptor descriptor\n                ? descriptor.Get(null, objectType, context, span) : sharedRaw;')
  (folder/Path(p).name).write_text(text,encoding='utf-8')
(out/'README.txt').write_text('Reconstructed source phases from explicit patches; original test logs are exact. No prototype timing/qualification is claimed for these reconstructions. Initial: wrapped object new. raw-new: removed wrapper with old consumers. opaque-raw: one consumer accepts raw, remaining two still require descriptors. Final source/bits are independently frozen.\n',encoding='utf-8')
print('All failed semantic phases/log conditions retained; reconstructed sources clearly labelled.',flush=True)
