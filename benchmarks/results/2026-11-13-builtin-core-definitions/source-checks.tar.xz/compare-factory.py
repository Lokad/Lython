from pathlib import Path
import json,os,shutil,subprocess
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';'+env['PATH']
p=r/'factory-driver-build.log';assert not p.exists()
with p.open('w',encoding='utf-8')as log:done=subprocess.run([str(sdk/'dotnet.exe'),'build',str(r/'inspect.csproj'),'-c','Release','--no-restore','--disable-build-servers','-m:1'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0,p.read_text(encoding='utf-8')[-2000:]
rows=[]
for role in ['reference','candidate']:
 image=r/('factory-'+role);shutil.copytree(r/'bin/Release/net11.0',image,copy_function=os.link)
 (image/'Lokad.Lython.dll').unlink();os.link(r/role/'Lokad.Lython.dll',image/'Lokad.Lython.dll')
 p=r/('factory-'+role+'.jsonl');assert not p.exists()
 with p.open('w',encoding='utf-8')as log:subprocess.run([str(sdk/'dotnet.exe'),str(image/'Lokad.Lython.WhiteBox.Tests.dll')],env=env,stdout=log,check=True)
 print(role,p.read_text(encoding='utf-8'),flush=True)
