from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'builtin-setup-b681-20261113';fixture=root/'guest-fixtures'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert root.resolve(strict=True)==root and root.parent==base
 service=subprocess.check_output(['systemctl','show','lython-b681-builtin-setup-20261113.service','--property=ActiveState,MainPID'],text=True)
 assert'MainPID=0'in service and'ActiveState=active'not in service
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert fixture.resolve(strict=True)==fixture and not list(fixture.iterdir())
 mount=json.loads(subprocess.check_output(['findmnt','-J','-T',str(fixture)],text=True))['filesystems'][0]
 assert mount['target']==str(fixture)and mount['fstype']=='tmpfs'and mount['source']=='lython-b681-fixtures'
 raw=json.loads((root/'confirmation/confirmation.json').read_text());assert not raw['complete']and len(raw['jobs'])==1 and raw['jobs'][0]['workersJoinedAndFixturesRemoved']
 (root/'failed-journal.txt').write_text(subprocess.check_output(['journalctl','-u','lython-b681-builtin-setup-20261113.service','--no-pager'],text=True))
 path=root/'incomplete-observations.tgz';assert not path.exists()
 with tarfile.open(path,'w:gz',dereference=True)as a:
  for p in sorted(root.rglob('*')):
   if p.is_file()and p.name not in {'incomplete-observations.tgz','current-core.dll'}and not {'candidate','reference','guest-fixtures'}&set(p.relative_to(root).parts):a.add(p,arcname=p.relative_to(root).as_posix())
 with tarfile.open(path)as a:assert not json.loads(a.extractfile('confirmation/confirmation.json').read())['complete']and len(json.loads(a.extractfile('confirmation/confirmation.json').read())['jobs'])==1
 assert shutil.disk_usage(base).free>252*1024*1024
 digest=hashlib.sha256(path.read_bytes()).hexdigest()
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 receipt=dict(complete=False,completedJobs=1,allWorkersJoined=True,failedConditionsPreserved=True,emptyFixtureVerifiedUnderLease=True,archivedAndVerifiedBeforeUnmount=True,guestFixturesRemoved=True,archiveSHA256=digest,bytes=path.stat().st_size,freeBytes=shutil.disk_usage(base).free,performanceQualified=False)
 (root/'incomplete-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
 print(json.dumps({p.name:p.read_text(errors='replace')for p in(root/'confirmation').glob('*.stderr')}))
