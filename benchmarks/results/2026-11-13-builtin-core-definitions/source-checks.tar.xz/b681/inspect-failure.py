from pathlib import Path
import json,subprocess
r=Path(__file__).parent
code='''from pathlib import Path
import fcntl,json,subprocess
root=Path('/home/lokad/lython-bench-checks/builtin-setup-b681-20261113')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 print(json.dumps(dict(files=[p.name for p in root.iterdir()],journal=subprocess.check_output(['journalctl','-u','lython-b681-builtin-setup-20261113.service','--no-pager','-n','60'],text=True),logs={p.name:p.read_text(errors='replace')[-10000:]for p in root.glob('*.log')})))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True);assert done.returncode==0,done.stderr
(r/'failure-inspection.json').write_text(done.stdout,encoding='utf-8')
data=json.loads(done.stdout);print(data['journal'][-10000:]);print(data['logs'])
