from pathlib import Path
import json,os,shutil,subprocess
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';'+env['PATH']
path=r/'all-representative.json';assert not path.exists()
image=r/'catalog-worker';shutil.copytree(r.parent/'call-construction-r315/reference',image,copy_function=os.link)
shutil.copytree('benchmarks/scripts',image/'RepresentativeScripts')
subprocess.run([str(sdk/'dotnet.exe'),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','list','--profile','representative','--out',str(path)],env=env,check=True)
d=json.loads(path.read_text(encoding='utf-8'))
print([(c['id'],c.get('size'))for c in d['cases']if 'config'in c['id']or'manifest'in c['id']],flush=True)
