from pathlib import Path
import ast,subprocess
r=Path(__file__).parent
s=(r.parent/'builtin-setup-r317/runtime-check.py').read_text(encoding='utf-8');a=s.index('names=');b=s.index('\nfor kind in names:',a)
names={'internal':['NamespaceAdmission','DefaultObjectAttributeBoundary','ClassMethodExecutionBoundary','ConstructorOwnership','ManagedStackGuard','NativeFunctionRefund'],
'public':['SharedFixedLabelBehaviorTests','BuiltinDefinitionIsolation','BuiltinRootIdentity','BuiltinSlotOwner','BuiltinsModuleTests','BuiltinTypeRecognition','BuiltinObjectExceptionFunction','BuiltinClassPattern','DefaultObjectAttributeTests','Dataclass','ClassMethod','Constructor','MappingProxy','Metaclass','Descriptor']}
s=s[:a]+'names='+repr(names)+s[b:];ast.parse(s);(r/'correction-check.py').write_text(s,encoding='utf-8')
subprocess.run(['python','-X','utf8',str(r/'correction-check.py')],check=True)
