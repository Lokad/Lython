from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;prior=r.parent/'builtin-setup-r317';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for kind,count in [('internal',86),('public',802)]:
 s=(r/(kind+'-test.log')).read_text(encoding='utf-8');assert 'Test Run Successful.'in s and f'Passed: {count}'in s
old=json.loads((prior/'candidate-identity.json').read_text(encoding='utf-8'));sources={p:sha(p)for p in old['sources']};changed=[p for p in sources if sources[p]!=old['sources'][p]]
assert changed==['src/Lokad.Lython/Runtime/PyAttributeLookup.cs'],changed
shutil.copytree(prior/'candidate',r/'candidate',copy_function=os.link);(r/'candidate/Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll')
shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(old,head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),description='Correct fourth object-new inherited consumer (partialmethod factory) via existing canonical binding; unchanged assertion and metadata ownership design',coreSHA256=sha(r/'candidate-core.dll'),referenceSHA256=old['coreSHA256'],sources=sources,changed=changed)
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for p in sources:a.add(p,arcname=p)
out=Path('benchmarks/results/2026-11-13-builtin-core-definitions/factory-correction');out.mkdir(exist_ok=True)
with tarfile.open(out/'source-checks.tar.xz','w:xz')as a:
 for name in ['candidate-core.dll','candidate-identity.json','candidate-sources.tar.xz','check-correction.py','correction-check.py','freeze-correction.py','internal-build.log','internal-test.log','public-build.log','public-test.log']:a.add(r/name,arcname=name)
 a.add('tests/Lokad.Lython.PublicApi.Tests/SharedFixedLabelBehaviorTests.cs',arcname='unchanged-regression/SharedFixedLabelBehaviorTests.cs')
print(identity['coreSHA256'],'573inputs,86internal/802public; one cold binding correction, no new timing claim.',flush=True)
