from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys

lab = Path(__file__).resolve().parent
reference = lab.with_name("forwarded-positional-framed-20261124")
sdk = Path.home() / ".dotnet11"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
cases = []
setup = """import re
class BadPattern:
    def __hash__(self):
        print('pattern hash')
        raise RuntimeError('pattern')
class Index:
    def __index__(self):
        print('index')
        raise ValueError('index')
class NotCallable:
    pass
class Replacement:
    def __call__(self, match):
        print(match.group())
        return 'x'
pattern = re.compile('a')
subject = 23
bad = BadPattern()
missing = None
"""
expressions = [
    "re.search(bad, subject)",
    "re.match(bad, subject)",
    "re.fullmatch(bad, subject)",
    "re.findall(bad, subject)",
    "re.finditer(bad, subject)",
    "re.sub(bad, None, subject, count=Index())",
    "re.subn(bad, 'x', 'a', count=Index())",
    "re.split(bad, subject, maxsplit=Index())",
    "pattern.search(subject, Index())",
    "pattern.findall(subject, endpos=Index())",
    "pattern.sub(None, subject, Index())",
    "pattern.split(subject, Index())",
    "re.sub(pattern, 'x', 'a', count=missing)",
    "re.subn(pattern, 'x', 'a', count=missing)",
    "re.split(pattern, 'a', maxsplit=missing)",
    "pattern.sub(NotCallable(), '', -1)",
    "pattern.sub(r'\\9', subject, 0)",
    "pattern.sub(Replacement(), 'aba', 1)",
    "re.subn(pattern, Replacement(), 'aba', count=1)",
    "re.split(pattern, 'aba', maxsplit=1)",
    "re.findall(pattern, 'aba')",
]
for expression in expressions:
    cases.append(setup + "try:\n    print(" + expression +
                 ")\nexcept Exception as error:\n    print(type(error).__name__)\n")
request = json.dumps(cases)
(lab / "oracle-input.json").write_text(request + "\n", encoding="utf-8")
role = sys.argv[1]
assert role in ("reference", "candidate")
image = lab / ("probe-" + role)
image.mkdir(exist_ok=True)
for path in (reference / "probe-candidate").iterdir():
    if path.is_file():
        shutil.copyfile(path, image / path.name)
core = image / "Lokad.Lython.dll"
if role == "candidate":
    shutil.copyfile(sys.argv[2], core)
else:
    identity = json.loads((reference / "comparison/quiet/identity.json").read_text(encoding="utf-8"))
    assert hashlib.sha256(core.read_bytes()).hexdigest() == identity["coreSHA256"]["candidate"]
results = {}
for mode in ("sync", "async"):
    args = ["--async"] if mode == "async" else []
    run = subprocess.run([sdk / "dotnet.exe", image / "LythonProbe.dll", "--batch-json", "--compare-python",
                          "--python", "C:/Python313/python.exe", *args], env=env, capture_output=True, text=True,
                         input=request, encoding="utf-8", timeout=90)
    (lab / (role + "-" + mode + ".jsonl")).write_text(run.stdout, encoding="utf-8", newline="\n")
    rows = [json.loads(line) for line in run.stdout.splitlines()]
    assert len(rows) == len(cases) and all(row["Compared"] for row in rows), (run.stdout[-2500:],run.stderr)
    results[mode] = {"matches":sum(row["Matches"] for row in rows),"total":len(cases),
       "mismatches":[expression for expression,row in zip(expressions,rows,strict=True) if not row["Matches"]]}
    print(mode, results[mode])
summary=dict(core=hashlib.sha256(core.read_bytes()).hexdigest(),results=results)
(lab / (role + "-summary.json")).write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
