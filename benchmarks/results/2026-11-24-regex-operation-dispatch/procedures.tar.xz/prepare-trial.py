from pathlib import Path

lab = Path(__file__).resolve().parent
previous = lab.with_name("forwarded-positional-framed-20261124")
text = (previous / "prepare.py").read_text(encoding="utf-8")
text = text.replace('donor = lab.with_name("json-default-prefix-20261124")',
                    'donor = lab.with_name("forwarded-positional-framed-20261124")')
text = text.replace('donor / "comparison/candidate"', 'donor / "candidate"')
text = text.replace('read(prior / "comparison/representative.json")',
                    'read(lab.with_name("regex-wrapper-cache-20261124") / "comparison/representative.json")')
text = text.replace('assert head.startswith("48790b2c7")', 'assert head.startswith("6466fbb52")')
text = text.replace('assert b"forwardedArgument"', 'assert b"ExecuteResolvedModule"')
text = text.replace('Forward positional operands through the established framed call entry',
                    'Share regex operation dispatch and preserve Python first-error order')
start = text.index("jobs = [")
stop = text.index("expected_ids", start)
text = text[:start] + """jobs = [
    ["scripts.regex-log-search.module", "warm"],
    ["scripts.regex-log-search.compiled", "warm"],
    ["scripts.csv-invoice.method-policy.quoted-control", "warm"],
]
""" + text[stop:]
text = text.replace('"b1621-fixtures", "b1624-fixtures"', '"b1624-fixtures", "b1626-fixtures"')
text = text.replace('len(jobs) == 5", "len(jobs) == 6', 'len(jobs) == 6", "len(jobs) == 3')
text = text.replace('forwarded-positional-framed-b1624-20261124', 'regex-operation-dispatch-b1626-20261124')
text = text.replace('reference="json-default-prefix-b1621-20261124"', 'reference="forwarded-positional-framed-b1624-20261124"')
text = text.replace('"lython-b1621-json-default-prefix-", "lython-b1624-forwarded-positional-framed-"',
                    '"lython-b1624-forwarded-positional-framed-", "lython-b1626-regex-operation-dispatch-"')
text = text.replace('"b1621-", "b1624-"', '"b1624-", "b1626-"')
text = text.replace('oldbase = lab.with_name("json-file-drain-20261124")', 'oldbase = lab.with_name("json-default-prefix-20261124")')
text = text.replace('oldbase / "boxed/quiet/terminal-status.json"', 'oldbase / "comparison/quiet/terminal-status.json"')
text = text.replace('"RuntimeMaxSec=230", "RuntimeMaxSec=268"', '"RuntimeMaxSec=268", "RuntimeMaxSec=175"')
text = text.replace('"seconds=170", "seconds=202"', '"seconds=202", "seconds=109"')
text = text.replace("verified five goldens", "verified three goldens")
compile(text, "prepare.py", "exec")
(lab / "prepare.py").write_text(text, encoding="utf-8", newline="\n")
