from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
out = repo / "benchmarks/results/2026-11-24-regex-operation-dispatch"
quiet = lab / "comparison/quiet"
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
identity = read(quiet / "identity.json")
assert sha(lab / "candidate.patch") == identity["sourcePatchSHA256"]
assert (lab / "candidate.patch").read_bytes() == subprocess.check_output(
    ["git", "diff", "--binary", "--", "src", "tests"], cwd=repo)
for role, manifest in identity["imageFiles"].items():
    assert len(manifest) == 32 and {p.name: sha(p) for p in (lab / role).iterdir()} == manifest
    proof = read(lab / "comparison" / (role + "-verify.json"))
    assert proof["caseCount"] == 3 and proof["state"] == "Completed"
    assert proof["catalogSha256"] == identity["catalogs"]["representative.json"]["sha256"]
    oracle = read(lab / (role + "-summary.json"))
    assert oracle["core"] == manifest["Lokad.Lython.dll"]
    count = 4 if role == "reference" else 21
    assert all(r["total"] == 21 and r["matches"] == count for r in oracle["results"].values())
for platform in ("windows", "ubuntu"):
    assert "Passed:    97" in (lab / (platform + "-white.log")).read_text(encoding="utf-8-sig")
    assert "Passed:   699" in (lab / (platform + "-public.log")).read_text(encoding="utf-8-sig")

out.mkdir(exist_ok=True)
for path in (quiet / "identity.json", lab / "allocation-summary.json", lab / "candidate-summary.json", lab / "reference-summary.json"):
    shutil.copyfile(path, out / path.name)
with tarfile.open(out / "procedures.tar.xz", "w:xz") as archive:
    for name in ["archive.py", "archive-quiet.py", "prepare-trial.py", "prepare.py", "refactor.py",
                 "oracle.py", "oracle-input.json", "allocations.py", "quiet.py", "candidate.patch",
                 "windows-build.log", "windows-public.log", "windows-public-initial.log", "windows-white.log",
                 "ubuntu-public.log", "ubuntu-public-initial.log", "ubuntu-white.log",
                 "reference-allocation.json", "candidate-allocation.json", "prepare.log", "launch.log", "retrieve.log",
                 "comparison/candidate-verify.json", "comparison/reference-verify.json",
                 "comparison/quiet/jobs.json", "comparison/quiet/representative.json", "comparison/quiet/run.sh",
                 "comparison/quiet/collect.py", "comparison/quiet/storage-custody.json"] + [
                     f"{role}-{mode}.jsonl" for role in ("reference", "candidate") for mode in ("sync", "async")]:
        archive.add(lab / name, arcname=name, recursive=False)
