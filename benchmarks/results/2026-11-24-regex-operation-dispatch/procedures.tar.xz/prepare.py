from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name("forwarded-positional-framed-20261124")
prior = lab.with_name("callable-singleton-defaults-isolated-20261124")
comparison = lab / "comparison"
quiet = comparison / "quiet"
quiet.mkdir(parents=True, exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
save = lambda p, v: p.write_text(json.dumps(v, indent=2) + "\n", encoding="utf-8", newline="\n")
donor_identity = read(donor / "comparison/quiet/identity.json")
core = "Lokad.Lython.dll"
current = prior / "windows/bin/Lokad.Lython/release_net11.0" / core
reference = donor_identity["imageFiles"]["candidate"]
donor_image = donor / "candidate"
assert sha(current) != reference[core] and {p.name: sha(p) for p in donor_image.iterdir()} == reference
images = dict(reference=reference, candidate=reference | {core: sha(current)})
for role, manifest in images.items():
    folder = lab / role
    folder.mkdir(exist_ok=True)
    for name in manifest:
        shutil.copyfile(current if role == "candidate" and name == core else donor_image / name, folder / name)
    assert len(manifest) == 32 and {p.name: sha(p) for p in folder.iterdir()} == manifest

jobs = [
    ["scripts.regex-log-search.module", "warm"],
    ["scripts.regex-log-search.compiled", "warm"],
    ["scripts.csv-invoice.method-policy.quoted-control", "warm"],
]
expected_ids = {case for case, _ in jobs}
expected = quiet / "representative.json"
fixture = read(lab.with_name("regex-wrapper-cache-20261124") / "comparison/representative.json")
fixture["cases"] = [row for row in fixture["cases"] if row["id"] in expected_ids]
assert {r["id"] for r in fixture["cases"]} == expected_ids
save(expected, fixture)
save(quiet / "jobs.json", {"warm": jobs})
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
assert head.startswith("6466fbb52")
patch = lab / "candidate.patch"
patch.write_bytes(subprocess.check_output(["git", "diff", "--binary", "--", "src", "tests"], cwd=repo))
assert b"ExecuteResolvedModule" in patch.read_bytes()
identity = dict(sourceRevision=head, comparisonRevision=head, sourcePatchSHA256=sha(patch),
    purpose="Share regex operation dispatch and preserve Python first-error order",
    imageFiles=images, expectedCPythonSHA256=donor_identity["expectedCPythonSHA256"],
    cpythonWorkerSHA256=donor_identity["cpythonWorkerSHA256"],
    coreSHA256={role + suffix: manifest[core] for role, manifest in images.items() for suffix in ("", "-control")},
    catalogs={name: {"sha256": sha(quiet / name)} for name in ("representative.json", "jobs.json")})
save(quiet / "identity.json", identity)
save(comparison / "identity.json", identity)
collector = (donor / "comparison/quiet/collect.py").read_text(encoding="utf-8").replace("b1624-fixtures", "b1626-fixtures")
collector = collector.replace("len(jobs) == 6", "len(jobs) == 3")
compile(collector, "collect.py", "exec")
(quiet / "collect.py").write_text(collector, encoding="utf-8", newline="\n")
shutil.copyfile(donor / "comparison/quiet/run.sh", quiet / "run.sh")
assert b"\r" not in (quiet / "run.sh").read_bytes()
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
python = Path("C:/Python313/python.exe")
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
worker = lab.with_name("json-file-drain-20261124") / "comparison/cpython-worker.py"
assert sha(worker) == identity["cpythonWorkerSHA256"]
for role in images:
    output = comparison / (role + "-verify.json")
    subprocess.run([dotnet, lab / role / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
                    "--catalog", expected, "--dotnet", dotnet, "--python", python,
                    "--python-worker", worker, "--out", output],
                   env=env, cwd=repo, check=True, timeout=60)
    proof = read(output)
    assert proof["state"] == "Completed" and proof["caseCount"] == len(expected_ids)
    assert proof["catalogSha256"] == sha(expected) and proof["launched"]["library"]["sha256"] == images[role][core]

payload = quiet / "payload.tar.gz"
with tarfile.open(payload, "w:gz", compresslevel=3) as archive:
    for name in ("identity.json", "jobs.json", "representative.json", "collect.py", "run.sh"):
        archive.add(quiet / name, arcname=name, recursive=False)
    archive.add(lab / "candidate" / core, arcname="candidate-core.dll", recursive=False)
save(quiet / "upload.json", dict(root="regex-operation-dispatch-b1626-20261124",
    reference="forwarded-positional-framed-b1624-20261124", payloadSHA256=sha(payload), payloadBytes=payload.stat().st_size))
save(lab / "verified-raw-replicas.json", [])
launch = (donor / "quiet.py").read_text(encoding="utf-8")
launch = launch.replace("lython-b1624-forwarded-positional-framed-", "lython-b1626-regex-operation-dispatch-").replace("b1624-", "b1626-")
oldbase = lab.with_name("json-default-prefix-20261124")
oldsha = read(oldbase / "comparison/quiet/terminal-status.json")["receipt"]["archiveSHA256"]
newsha = read(donor / "comparison/quiet/terminal-status.json")["receipt"]["archiveSHA256"]
assert oldsha in launch
launch = launch.replace(oldsha, newsha).replace("RuntimeMaxSec=268", "RuntimeMaxSec=175").replace("seconds=202", "seconds=109")
compile(launch, "quiet.py", "exec")
(lab / "quiet.py").write_text(launch, encoding="utf-8", newline="\n")
print("Sealed both 32-file images and verified three goldens.")
