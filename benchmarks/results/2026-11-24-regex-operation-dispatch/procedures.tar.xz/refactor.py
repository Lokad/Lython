from pathlib import Path
base = Path("src/Lokad.Lython/Runtime")

def rewrite(name, edit):
    path = base / name
    raw = path.read_bytes()
    content = raw.decode("utf-8").replace("\r\n", "\n")
    result = edit(content)
    assert result != content
    path.write_bytes(result.encode("utf-8").replace(b"\n", b"\r\n" if b"\r\n" in raw else b"\n"))

def module(s):
    start = s.index("        private static readonly BuiltinCallable SearchMethod")
    stop = s.index("\n        private ReModule()", start)
    s = s[:start] + """        private static readonly BuiltinCallable SearchMethod = CreatePatternBuiltin(LythonKnownCallableSignatures.Regex.Search, RegexPatternOperation.Search);
        private static readonly BuiltinCallable MatchMethod = CreatePatternBuiltin(LythonKnownCallableSignatures.Regex.Match, RegexPatternOperation.Match);
        private static readonly BuiltinCallable FullMatchMethod = CreatePatternBuiltin(LythonKnownCallableSignatures.Regex.FullMatch, RegexPatternOperation.FullMatch);
        private static readonly BuiltinCallable FindAllMethod = CreatePatternBuiltin(LythonKnownCallableSignatures.Regex.FindAll, RegexPatternOperation.FindAll);
        private static readonly BuiltinCallable FindIterMethod = CreatePatternBuiltin(LythonKnownCallableSignatures.Regex.FindIter, RegexPatternOperation.FindIter);
        private static readonly BuiltinCallable SubMethod = CreatePatternBuiltin(LythonKnownCallableSignatures.Regex.Sub, RegexPatternOperation.Sub);
        private static readonly BuiltinCallable SubCountMethod = CreatePatternBuiltin(LythonKnownCallableSignatures.Regex.Subn, RegexPatternOperation.SubCount);
        private static readonly BuiltinCallable SplitMethod = CreatePatternBuiltin(LythonKnownCallableSignatures.Regex.Split, RegexPatternOperation.Split);
""" + s[stop:]
    start = s.index("        private enum ModuleMatchOperation")
    stop = s.index("        private object Escape(", start)
    return s[:start] + """        private static BuiltinCallable CreatePatternBuiltin(LythonCallableSignature signature, RegexPatternOperation operation)
            => BuiltinCallable.CreateWithPresence(signature,
                (arguments, span, context) => RePatternMembers.ExecuteModule(arguments, span, context, signature.Name, operation, false)
                    .GetAwaiter().GetResult(),
                (arguments, span, context) => RePatternMembers.ExecuteModule(arguments, span, context, signature.Name, operation, true));

""" + s[stop:]

def compiler(s):
    start = s.index("        internal readonly record struct RegexPatternRange(")
    stop = s.index("        internal static int ReadCaptureSlotCount", start)
    s = s[:start] + s[stop:]
    s = s.replace("        private static ValueTask<RePatternObject> ResolvePattern(", "        internal static ValueTask<RePatternObject> ResolvePattern(")
    start = s.index("        internal static ValueTask<RegexPatternRange> CreatePatternAndRange(")
    stop = s.index("        internal static int ParsePosition(", start)
    s = s[:start] + s[stop:]
    start = s.index("        private static int ParseOptionalPosition(")
    stop = s.index("        internal static long ParseIndex(", start)
    return s[:start] + s[stop:]

def objects(s):
    s = s.replace("    internal static class RePatternMembers\n    {\n        private enum PatternOperation { Search, Match, FullMatch, FindAll, FindIter, Split, Sub, SubCount }\n",
                  "    internal enum RegexPatternOperation { Search, Match, FullMatch, FindAll, FindIter, Split, Sub, SubCount }\n\n    internal static class RePatternMembers\n    {")
    s = s.replace("PatternOperation", "RegexPatternOperation").replace("RegexRegexPatternOperation", "RegexPatternOperation")
    start = s.index("        private static ValueTask<object> Execute(RePatternObject pattern")
    stop = s.index("        private static ValueTask<object> ExecutePrepared(", start)
    s = s[:start] + """        internal static ValueTask<object> ExecuteModule(BoundBuiltinArguments arguments, LythonSourceSpan span,
            ExecutionContext context, string name, RegexPatternOperation operation, bool asynchronous)
        {
            var flagIndex = operation switch
            {
                RegexPatternOperation.Sub or RegexPatternOperation.SubCount => 4,
                RegexPatternOperation.Split => 3,
                _ => 2,
            };
            context.CheckExecution(span);
            // Module-level re functions compile or look up the pattern before
            // the compiled method performs any index or subject operations.
            var pending = RegexCompiler.ResolvePattern(arguments.Values[0], Optional(arguments, flagIndex), span, context, asynchronous);
            return pending.IsCompletedSuccessfully
                ? ExecuteResolvedModule(pending.Result, arguments, flagIndex, context, span, name, operation, asynchronous)
                : AwaitModulePattern(pending, arguments, flagIndex, context, span, name, operation);

            static async ValueTask<object> AwaitModulePattern(ValueTask<RePatternObject> pending,
                BoundBuiltinArguments arguments, int flagIndex, ExecutionContext context, LythonSourceSpan span,
                string name, RegexPatternOperation operation)
                => await ExecuteResolvedModule(await pending.ConfigureAwait(false), arguments, flagIndex, context, span, name,
                    operation, true).ConfigureAwait(false);
        }

        private static object? Optional(BoundBuiltinArguments arguments, int index)
            => arguments.Assigned[index] ? arguments.Values[index] : null;

        private static ValueTask<object> ExecuteResolvedModule(RePatternObject pattern, BoundBuiltinArguments arguments,
            int flagIndex, ExecutionContext context, LythonSourceSpan span, string name, RegexPatternOperation operation, bool asynchronous)
        {
            var substitution = flagIndex == 4;
            // The module's window extension also accepts None for an omitted bound.
            var pos = Optional(arguments, flagIndex + 1);
            var end = Optional(arguments, flagIndex + 2);
            return ExecuteArguments(pattern, arguments.Values[substitution ? 2 : 1], substitution ? arguments.Values[1] : null,
                flagIndex > 2 ? Optional(arguments, flagIndex - 1) : null, pos is PyNone ? null : pos, end is PyNone ? null : end,
                operation, context, span, name, asynchronous);
        }

        private static ValueTask<object> Execute(RePatternObject pattern, ReceiverArguments arguments, LythonSourceSpan span,
            ExecutionContext context, string name, RegexPatternOperation operation, bool asynchronous)
        {
            var substitution = operation is RegexPatternOperation.Sub or RegexPatternOperation.SubCount;
            var subjectIndex = substitution ? 1 : 0;
            var counted = substitution || operation == RegexPatternOperation.Split;
            var positionIndex = subjectIndex + (counted ? 2 : 1);
            return ExecuteArguments(pattern, arguments[subjectIndex]!, substitution ? arguments[0] : null,
                counted ? arguments.Optional(subjectIndex + 1) : null, arguments.Optional(positionIndex),
                arguments.Optional(positionIndex + 1), operation, context, span, name, asynchronous);
        }

        private static ValueTask<object> ExecuteArguments(RePatternObject pattern, object subject, object? replacement,
            object? count, object? pos, object? end, RegexPatternOperation operation, ExecutionContext context,
            LythonSourceSpan span, string name, bool asynchronous)
        {
            context.CheckExecution(span);
            // Integer conversions belong to argument binding. Run them in order
            // before the matcher checks the subject or prepares a replacement.
            if (asynchronous && (count is PyInstance || pos is PyInstance || end is PyInstance))
                return ExecuteWithIndexProtocols(pattern, subject, replacement, count, pos, end, operation, context, span, name);

            var limit = count is null ? 0 : RegexCompiler.ParseIndex(count, span, context);
            var start = pos is null ? 0 : RegexCompiler.ParsePosition(pos, span, context);
            var stop = end is null ? int.MaxValue : RegexCompiler.ParsePosition(end, span, context);
            return ExecutePrepared(pattern, subject, replacement, limit, start, stop, operation, context, span, name, asynchronous);
        }

        private static async ValueTask<object> ExecuteWithIndexProtocols(RePatternObject pattern, object subject, object? replacement,
            object? count, object? pos, object? end, RegexPatternOperation operation,
            ExecutionContext context, LythonSourceSpan span, string name)
        {
            var limit = count is null ? 0
                : await RegexCompiler.ParseIndexAsync(count, span, context).ConfigureAwait(false);
            var start = pos is null ? 0 : await RegexCompiler.ParsePositionAsync(pos, span, context).ConfigureAwait(false);
            var stop = end is null ? int.MaxValue : await RegexCompiler.ParsePositionAsync(end, span, context).ConfigureAwait(false);
            return await ExecutePrepared(pattern, subject, replacement, limit, start, stop, operation, context, span, name, true)
                .ConfigureAwait(false);
        }

""" + s[stop:]
    start = s.index("        private static ValueTask<object> ExecutePrepared(")
    end = s.index("            switch (operation)", start)
    s = s[:start] + """        private static ValueTask<object> ExecutePrepared(RePatternObject pattern, object subject, object? replacement,
            long count, int pos, int end, RegexPatternOperation operation, ExecutionContext context, LythonSourceSpan span,
            string name, bool asynchronous)
        {
            if (operation is RegexPatternOperation.Sub or RegexPatternOperation.SubCount)
            {
                var mode = operation == RegexPatternOperation.Sub ? RegexSubstitutionMode.TextOnly : RegexSubstitutionMode.TextAndCount;
                return RegexMatcher.Substitute(pattern, replacement!, subject, count, pos, end, span, context, mode, name, asynchronous);
            }
            if (!PyStringOps.TryAsString(subject, out var text)) throw RuntimeErrors.Type(SubjectError(name), span);
            var range = RegexCompiler.CreateSubjectRange(text, pos, end, span, context);
""" + s[end:]
    start = s.index("                case RegexPatternOperation.Sub or")
    end = s.index("                default:", start)
    s = s[:start] + s[end:]
    start = s.index("        private static string SubjectError(")
    return s[:start] + """        internal static string SubjectError(string name) => $"{name} expects a string subject.";
    }
}
"""

def matcher(s):
    start = s.index("        internal static object ExecuteSubstitute(")
    stop = s.index("            if (count < 0)", start)
    return s[:start] + """        internal static async ValueTask<object> Substitute(RePatternObject pattern, object replacement, object subject,
            long count, int pos, int end, LythonSourceSpan span, ExecutionContext context, RegexSubstitutionMode mode,
            string name, bool asynchronous)
        {
            context.CheckExecution(span);
            var hasText = PyStringOps.TryAsString(subject, out var text);
            var range = hasText ? RegexCompiler.CreateSubjectRange(text, pos, end, span, context) : default;
            if (hasText && !range.IsValid)
                throw new LythonRuntimeException("ValueError", "Regex substitution endpos must not precede pos.", span);
            var isTemplate = PyStringOps.TryAsString(replacement, out var template);
            if (!isTemplate && !IsCallable(replacement))
                throw RuntimeErrors.Type("Regex replacement must be a string or callable.", span);
            // Python validates templates even with no matches, negative count
            // or an invalid subject. The private plan lives through cleanup.
            using var plan = isTemplate ? ReMatchMembers.CompileReplacementTemplate(pattern, template!, context, span) : null;
            if (!hasText) throw RuntimeErrors.Type(RePatternMembers.SubjectError(name), span);
""" + s[stop:]

rewrite("LythonRuntime.RegexModule.cs", module)
rewrite("LythonRuntime.RegexCompiler.cs", compiler)
rewrite("LythonRuntime.RegexObjects.cs", objects)
rewrite("LythonRuntime.RegexMatcher.cs", matcher)
