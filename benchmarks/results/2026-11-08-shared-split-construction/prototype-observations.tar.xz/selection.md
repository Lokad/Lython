R98: share admitted explicit-separator/whitespace result construction.
Old explicit rsplit: List<PyString> growth, reversal, conversion object[], copied PyList backing.
Old forward split: separately growing result storage. Reuse existing ranges/final array and
owned fragment construction; existing bytes candidate search supplies current cancellation.
No new pool/cache/owner/policy/framework or unboxing representation. Full unchanged whitespace
helper remains a control; this change does not close its CPython gap.
Two complete delimiter-report scripts (3072lines/35840B) use explicit single-space separators
and independent local CPython full stdout/file goldens. Three unchanged scripts are controls.
Existing allocation driver, two APIs, normalGC/tiering, isolated cores with same auxiliarybits.
Retain architecture/admission correction and allocation reduction; desktop elapsed is unstable,
including adverse results, so make no controlled CPU/speedup claim. No new VM timing.
150public/33internal focused Release per actual11/10. First whole-output refusal now precedes
fragment allocation. Independent owners, retained aliases, sequential cleanup/reuse and
cancellation during admission retain their funding and first structured origin.
Original red both directions allocated66752/67376B before failure. Initial migration missed
three wrapper names and failed compilation; fixed, not interpreted as runtime evidence.
Initial public oracle expected CPython immutable-string identity reuse across independently
owned storage, which Python does not require and prior Lython did not guarantee. Its original
source/expected/error are preserved; corrected oracle checks value semantics/list independence.
Existing retained-owner tests still require actual funded aliases, never premature refunds.
Batch full Windows/Ubuntu/Stress/installed-core qualification at next coherent delivery;
not implied by focused tests. Regex0.4 unchanged, publication/tagging postponed.
