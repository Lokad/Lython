from pathlib import Path
import os,subprocess
r=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
filters=dict(internal='(FullyQualifiedName~SeparatedSplitOwnershipTests|FullyQualifiedName~WhitespaceStorageOwnershipTests|FullyQualifiedName~WhitespaceSplitCancellationTests|FullyQualifiedName~CasedSplitOwnershipTests|FullyQualifiedName~PythonWhitespaceInventoryTests)&Category!=Stress',public='(FullyQualifiedName~SeparatedStringSplitTests|FullyQualifiedName~DirectStringSplitExecutionTests|FullyQualifiedName~PythonWhitespaceCompatibilityTests|FullyQualifiedName~WhitespaceSplitBoundaryTests|FullyQualifiedName~WhitespaceFragmentValueTests|FullyQualifiedName~CasedWhitespacePipelineTests|FullyQualifiedName~ExpandedStringArgumentTests)&Category!=Stress')
for target in ['11','10']:
 for family,project in [('internal','Lokad.Lython.Tests'),('public','Lokad.Lython.PublicApi.Tests')]:
  p=r/(family+'-corrected'+target+'.log')
  with p.open('w',encoding='utf-8')as output:
   done=subprocess.run([env['DOTNET_HOST_PATH'],'test',f'tests/{project}/{project}.csproj','-c','Release','-f','net'+target+'.0','--no-restore','--filter',filters[family],'--logger','console;verbosity=minimal'],env=env,stdout=output,stderr=subprocess.STDOUT)
  assert done.returncode==0,p.read_text(encoding='utf-8')[-5000:]
  print(family,target,p.read_text(encoding='utf-8').splitlines()[-1],flush=True)
