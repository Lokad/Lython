from pathlib import Path
import shutil
r=Path(__file__).parent
paths=['src/Lokad.Lython/Runtime/Text/PyStringOps.cs','src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs','src/Lokad.Lython/Runtime/LythonRuntime.BytesMembers.cs']
for p in paths:
 q=r/'before'/Path(p).name;q.parent.mkdir(parents=True,exist_ok=True);assert not q.exists();shutil.copyfile(p,q)
p=Path(paths[0]);s=p.read_text(encoding='utf-8')
def replace_body(signature,body):
 global s
 a=s.index(signature);b=s.index('{',a);depth=1;end=b+1
 while depth:
  if s[end]=='{':depth+=1
  if s[end]=='}':depth-=1
  end+=1
 s=s[:a]+signature+'\n        => '+body+';'+s[end:]
replace_body('    public static PyList Split(PyString value, PyString separator, MemoryGovernor? governor, LythonSourceSpan? span)','SplitCore(value, -1, false, governor, span, null, separator: separator)')
replace_body('    public static PyList Split(PyString value, PyString separator, int maxSplit, MemoryGovernor? governor, LythonSourceSpan? span)','SplitCore(value, maxSplit, false, governor, span, null, separator: separator)')
replace_body('    public static PyList RSplit(PyString value, PyString separator, int maxSplit, MemoryGovernor? governor, LythonSourceSpan? span)','SplitCore(value, maxSplit, true, governor, span, null, separator: separator)')
p.write_text(s,encoding='utf-8',newline='\n')
p=Path(paths[1]);s=p.read_text(encoding='utf-8').replace('SplitWhitespaceCore','SplitCore').replace('AppendWhitespaceRange','AppendSplitRange')
s=s.replace('CaseMapping? casing = null)','CaseMapping? casing = null, PyString? separator = null)')
needle='''            if (reverse)
                CollectWhitespaceReverse'''
assert needle in s
s=s.replace(needle,'''            if (separator is not null)
            {
                if (separator.ByteLength == 0) throw new InvalidOperationException("empty separator");
                CollectSeparatedRanges(source, separator.Utf8Span, maxSplit, reverse,
                    ref ranges, ref count, ref outputBytes, ref scratchBytes, ref scratch, governor, span, context);
            }
            else if (reverse)
                CollectWhitespaceReverse''')
needle='''            var listBytes = PyList.EstimateCapacityBytes(count);'''
assert needle in s
s=s.replace(needle,'''            // A whole unchanged source remains a funded alias in its owner.
            // Independent output owners still receive their own copied storage.
            var reuseWhole = casing is null && count == 1 && ranges[0].Start == 0 &&
                ranges[0].End == source.Length && ReferenceEquals(governor, value.OwnerMemoryGovernor);
            if (reuseWhole && ranges[0].Capacity != 0)
                outputBytes -= PyString.EstimateApproximateBytes(ranges[0].Capacity);
            var listBytes = PyList.EstimateCapacityBytes(count);''')
needle='''                var fragment = PyString.CreateReservedUtf8(range.Capacity, governor);'''
assert needle in s
s=s.replace(needle,'''                if (reuseWhole) { parts[index] = value; continue; }
                if (range.Capacity == 0) { parts[index] = PyString.Empty; continue; }
                var fragment = PyString.CreateReservedUtf8(range.Capacity, governor);''')
s=s.replace('outputBytes = checked(outputBytes + PyString.EstimateApproximateBytes(outputCapacity));','if (outputCapacity != 0) outputBytes = checked(outputBytes + PyString.EstimateApproximateBytes(outputCapacity));')
helper='''
    private static void CollectSeparatedRanges(ReadOnlySpan<byte> source, ReadOnlySpan<byte> separator,
        int maxSplit, bool reverse, scoped ref Span<(int Start, int End, int Capacity)> ranges,
        ref int count, ref long outputBytes, ref long scratchBytes,
        ref MemoryGovernor.TemporaryMemoryReservation? scratch, MemoryGovernor? governor, LythonSourceSpan? span,
        LythonRuntime.ExecutionContext? context)
    {
        var offset = reverse ? source.Length : 0;
        var splits = 0;
        while (maxSplit < 0 || splits < maxSplit)
        {
            var remaining = reverse ? source[..offset] : source[offset..];
            var found = LythonRuntime.FindBytes(remaining, separator, context, span, reverse);
            if (found < 0) break;
            if (!reverse) found += offset;
            AppendSplitRange(ref ranges, ref count, reverse ? found + separator.Length : offset,
                reverse ? offset : found, ref outputBytes, ref scratchBytes, ref scratch, governor, span, context);
            offset = reverse ? found : found + separator.Length;
            splits++;
        }
        AppendSplitRange(ref ranges, ref count, reverse ? 0 : offset, reverse ? offset : source.Length,
            ref outputBytes, ref scratchBytes, ref scratch, governor, span, context);
    }
'''
a=s.index('    private static void CollectWhitespaceForward')
s=s[:a]+helper+'\n'+s[a:]
p.write_text(s,encoding='utf-8',newline='\n')
p=Path(paths[2]);s=p.read_text(encoding='utf-8')
needle='''    private static int FindBytes(ReadOnlySpan<byte> source, ReadOnlySpan<byte> needle,
        ExecutionContext? context, LythonSourceSpan span, bool reverse = false)'''
assert needle in s
s=s.replace(needle,'''    // Also used by string segmentation: UTF-8 separators use the same byte
    // search and current cancellation policy, without converting the subject.
    internal static int FindBytes(ReadOnlySpan<byte> source, ReadOnlySpan<byte> needle,
        ExecutionContext? context, LythonSourceSpan? span, bool reverse = false)''')
p.write_text(s,encoding='utf-8',newline='\n')
print('Explicit and whitespace split now share admitted final construction; old explicit builders/copies removed.')
