from pathlib import Path
import base64,copy,hashlib,importlib.util,json,os,re,shutil,subprocess,tempfile
r=Path(__file__).parent;old=r.parent/'direct-operands-r96'
d=json.loads((old/'catalog.json').read_text(encoding='utf-8'));cases={v['id']:v for v in d['cases']}
template=cases['scripts.text-summary-rsplit-helpers.large'];affected=[]
spec=importlib.util.spec_from_file_location('protocol',r.parent/'operand-cpython-r97/retrieved/cpython-worker.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
for method in ['split','rsplit']:
 c=copy.deepcopy(template);c['id']='scripts.text-separated-'+method+'-helpers.large'
 c['source']=c['source'].replace('line.lower().rsplit()', "line.rstrip('\\n').lower()."+method+"(' ')").replace('            counts[word]', '            if not word: continue\n            counts[word]')
 assert "if not word: continue"in c['source']and "rstrip"in c['source']
 c['sourceUtf8Bytes']=len(c['source'].encode());c['sourceSha256']=hashlib.sha256(c['source'].encode()).hexdigest()
 fixture=json.loads(c['fixtureJson'])
 with tempfile.TemporaryDirectory(prefix='trusted-cpython-',dir=r.resolve())as owned:
  root=Path(owned)
  for name,data in fixture['inputFiles'].items():(root/name).write_bytes(base64.b64decode(data))
  done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',c['source']],cwd=root,text=True,encoding='utf-8',capture_output=True);assert done.returncode==0,done.stderr
  assert done.stdout==c['expectedOutput']
  actual={name:(root/name).read_bytes()for name in fixture['outputFiles']}
  assert protocol.file_digest(actual)==c['expectedFilesSha256']
 affected.append(c)
d['cases']=affected+[cases[n]for n in ['scripts.text-summary-rsplit-helpers.large','scripts.csv-summary-functions.large','scripts.report-render.large']]
assert len(d['cases'])==5
(r/'catalog.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name,expected in [('public-final11',150),('public-final10',150),('internal-final11',33),('internal-final10',33)]:
 s=(r/(name+'.log')).read_text(encoding='utf-8');assert 'Failed:     0'in s and re.search(r'Passed:\s+'+str(expected)+r'\b',s)
for role in ['before','candidate']:shutil.copytree(old/'images/candidate',r/'images'/role,copy_function=os.link)
core=r/'images/candidate/Lokad.Lython.dll';core.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',core)
inventory={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*')if p.is_file()and not {'bin','obj'}&set(p.parts)}
identity=dict(baselineSource='94cb8963/core d6254b2e, R96 full CI pending independently',candidateSource='fa995d65 plus shared explicit/whitespace split construction',coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},productionSources=inventory,qualification='150public/33internal focused Release peractual11/10; full retained boundary pending independently',catalogSemantics='Two explicit-separator reports independently revalidated under local CPython3.13; three unchanged complete controls. Identical fixture/full goldens across both images.')
assert identity['coreSHA256']['before'].startswith('d6254b2e')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython']))
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
for name in ['measure.py','assess-local.py']:shutil.copyfile(old/name,r/name)
print(json.dumps(identity['coreSHA256']),'Five complete scripts prepared with independent Python goldens; focused checks verified.')
