from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
out=Path('benchmarks/results/2026-11-08-shared-split-construction');out.mkdir()
selection='''R98: share admitted explicit-separator/whitespace result construction.
Old explicit rsplit: List<PyString> growth, reversal, conversion object[], copied PyList backing.
Old forward split: separately growing result storage. Reuse existing ranges/final array and
owned fragment construction; existing bytes candidate search supplies current cancellation.
No new pool/cache/owner/policy/framework or unboxing representation. Full unchanged whitespace
helper remains a control; this change does not close its CPython gap.
Two complete delimiter-report scripts (3072lines/35840B) use explicit single-space separators
and independent local CPython full stdout/file goldens. Three unchanged scripts are controls.
Existing allocation driver, two APIs, normalGC/tiering, isolated cores with same auxiliarybits.
Retain architecture/admission correction and allocation reduction; desktop elapsed is unstable,
including adverse results, so make no controlled CPU/speedup claim. No new VM timing.
150public/33internal focused Release per actual11/10. First whole-output refusal now precedes
fragment allocation. Independent owners, retained aliases, sequential cleanup/reuse and
cancellation during admission retain their funding and first structured origin.
Original red both directions allocated66752/67376B before failure. Initial migration missed
three wrapper names and failed compilation; fixed, not interpreted as runtime evidence.
Initial public oracle expected CPython immutable-string identity reuse across independently
owned storage, which Python does not require and prior Lython did not guarantee. Its original
source/expected/error are preserved; corrected oracle checks value semantics/list independence.
Existing retained-owner tests still require actual funded aliases, never premature refunds.
Batch full Windows/Ubuntu/Stress/installed-core qualification at next coherent delivery;
not implied by focused tests. Regex0.4 unchanged, publication/tagging postponed.
'''
(r/'selection.md').write_text(selection,encoding='utf-8')
shutil.copyfile(r.parent/'operand-cpython-r97/r98-red.log',r/'original-refusal-red.log')
(r/'tested-tests').mkdir()
for name in ['SeparatedSplitOwnershipTests.cs','WhitespaceSplitCancellationTests.cs']:
 shutil.copyfile(Path('tests/Lokad.Lython.Tests')/name,r/'tested-tests'/name)
shutil.copyfile('tests/Lokad.Lython.PublicApi.Tests/SeparatedStringSplitTests.cs',r/'tested-tests/SeparatedStringSplitTests.cs')
with tarfile.open(out/'observations.tar.xz','w:xz')as a:
 for p in sorted(r.iterdir()):
  if p.name=='images':
   for role in ['before','candidate']:a.add(p/role/'Lokad.Lython.dll',arcname=role+'-core.dll')
  else:a.add(p,arcname=p.name)
for src,name in [(r/'identity.json','identity.json'),(r/'assessment-local.json','allocation-and-local.json')]:shutil.copyfile(src,out/name)
archivehash=hashlib.sha256((out/'observations.tar.xz').read_bytes()).hexdigest()
status=dict(status='Retained coherent construction/admission correction; focused actual11/10 pass. Full retained-boundary qualification pending.',coreSHA256=identity['coreSHA256'],archiveSHA256=archivehash,focusedChecks=dict(public11=150,public10=150,internal11=33,internal10=33),measurement='Allocation reduction established for two affected complete scripts; desktop elapsed inconclusive/adverse preserved; no controlled CPU claim.',noNewVMCollection=True)
(out/'status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf-8')
readme='''# Shared split construction — 2026-11-08

Explicit-separator split/rsplit reuse the existing whitespace range scratch,
complete output admission and final-array adoption. Delete three independent
builders, the temporary right-split list, reverse/conversion array and copied
list backing. Reuse the existing managed bytes search with current cancellation;
no conversion, new owner/pool/cache or public option. Whole unchanged strings can
remain aliases in the same funded owner; different owners receive copied storage.

Baseline committed94cb8963/core d6254b2e; candidatefa995d65 plus archived production
patch/core2e232a4d. Complete production inventory/core hashes are in identity.json.
The earlier CPython checkpoint still describes94cb8963. Full retained-source
Windows/Ubuntu/Stress/installed-core qualification is pending independently.

| Complete delimiter report | Sync allocation | Async API allocation |
| --- | ---: | ---: |
| Forward explicit split |−5.47%|−5.47%|
| Reverse explicit split |−8.92%|−8.91%|

Each reads3072lines/35840B, aggregates words through an ordinary helper and writes
the complete report. Explicit separators require stripping newlines/skipping
empty fields; both candidate and baseline execute the identical complete source.
Local isolated CPython independently confirms full stdout/file goldens.
Existing allocation driver:32warmups, five rotated four-invocation samples, two
baseline controls/current core, normalGC/tiering. Captures public Run/RunAsync,
fixture reset, actual mediated file I/O, full checks and result cleanup; excludes
startup and compilation. I/O completes inline; this does not measure real pending
I/O latency. Whitespace/CSV/report controls are allocation-neutral within0.03%.
Desktop elapsed controls drift about4–20%, including adverse observations; no
controlled elapsed/CPU gain claimed and no additional VM campaign performed.

150public/33internal focused Release checks per actual11/10 pass. Independent
Python cases preserve forward/reverse nonoverlap, Unicode/empty fields, zero/
negative/indexed maxsplit, exposed/keyword/expanded calls and search boundaries.
Ownership checks retain aliases after source-owner cleanup, repeat batch cleanup/
budget reuse and cancel during actual output admission before construction.
Original regressions allocate66752/67376B before refusing whole-result storage;
the retained implementation refuses before fragment allocation and leaves no
unpublished storage committed. First refusal identity/span and input contents hold.

All original failed conditions remain in observations.tar.xz, including the first
migration build and an invalid CPython immutable-identity oracle. The latter was
corrected because Python does not require identical allocation/identity reuse;
value semantics and independently funded aliases remain tested. This is a coherent
storage/admission simplification with measured allocation reduction. It does not
close the whitespace-helper performance gap or repay prior text/report debt.

[Allocation/raw elapsed](allocation-and-local.json), [identity](identity.json),
[status](status.json), [raw source/cores/logs/tests](observations.tar.xz).
'''
(out/'README.md').write_text(readme,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf-8')+'''
[R98](results/2026-11-08-shared-split-construction/README.md) shares explicit and
whitespace split final construction, removing temporary reverse lists/conversion/
copied arrays and duplicate forward growth. Original red tests demonstrate67KB
allocated before whole-result refusal; complete admission now precedes fragments.
Two complete delimiter reports allocate5.47%/8.91–8.92%less across both APIs;
unchanged whitespace/CSV/report allocation neutral. Desktop elapsed/control drift
and adverse originals remain diagnostic; no controlled CPU claim/new VM campaign.
150public/33internal peractual11/10 pass; full retained-boundary qualification pending.
Native UTF-8/owners/aliases/current cancellation use existing mechanisms. Initial
build failure and invalid immutable-identity oracle/source are preserved separately.
''',encoding='utf-8',newline='\n')
print('R98 retained with explicit qualification limits; archive SHA256',archivehash)
