from pathlib import Path
import hashlib,json,re,shutil,subprocess
r=Path(__file__).resolve().parent
assert r.is_relative_to(Path('D:/code/Lython/.git/agent-notes').resolve())
for name in ['identity.json','source.patch','assessment-local.json']:
 shutil.copyfile(r/name,r/('prototype-'+name))
shutil.copyfile(r/'images/candidate/Lokad.Lython.dll',r/'prototype-core.dll')
for folder in ['warm-sync','warm-async']:
 src=r/folder;dst=r/('prototype-'+folder)
 assert src.resolve().is_relative_to(r)and dst.resolve().is_relative_to(r)and not dst.exists()
 src.rename(dst)
core=r/'images/candidate/Lokad.Lython.dll';core.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',core)
identity=json.loads((r/'prototype-identity.json').read_text(encoding='utf-8'))
identity['candidateSource']='fa995d65 plus shared split construction and explicit current context after genuine suspension'
identity['coreSHA256']['candidate']=hashlib.sha256(core.read_bytes()).hexdigest()
identity['productionSources']={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*')if p.is_file()and not {'bin','obj'}&set(p.parts)}
for family,expected in [('public',150),('internal',35)]:
 for target in ['11','10']:
  s=(r/(family+'-corrected'+target+'.log')).read_text(encoding='utf-8');assert 'Failed:     0'in s and re.search(r'Passed:\s+'+str(expected)+r'\b',s)
identity['qualification']='Corrected source:150public/35internal focused Release peractual11/10. Suspended __index__ host I/O now keeps explicit context/cancellation for split and rsplit; first refusal and aliases preserved. Full retained-boundary qualification pending.'
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython']))
p=r/'assess-local.py';s=p.read_text(encoding='utf-8').replace('Preserve original call-site-metadata prototype and all adverse/unstable controls.','Preserve original shared-construction prototype, suspended-context failure and all adverse/unstable controls.');p.write_text(s,encoding='utf-8')
print('Corrected source frozen',identity['coreSHA256']['candidate'],'original prototype and diagnostic preserved.')
