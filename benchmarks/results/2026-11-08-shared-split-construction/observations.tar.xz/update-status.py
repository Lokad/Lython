from pathlib import Path
import json
ci=Path('benchmarks/results/2026-11-08-direct-operand-transport/delivery-ci.json')
data=json.loads(ci.read_text(encoding='utf-8'));assert data['conclusion']=='success'and data['headSha'].startswith('94cb8963')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8')
old=f"Focused Release checks pass on actual .NET11/.NET10. Full Windows/Ubuntu,\noriginal Stress and installed-consumer qualification is pending independently\nat [CI{data['databaseId']}](https://github.com/Lokad/Lython/actions/runs/{data['databaseId']})."
assert old in s
s=s.replace(old,f"Windows/Ubuntu Release actual .NET11/.NET10, original Stress and installed core\nconsumers pass [cached CI{data['databaseId']}](../benchmarks/results/2026-11-08-direct-operand-transport/delivery-ci.json).")
s=s.replace('Report possible elapsed debt; R95 text debt remains separately recorded. Full delivery pending. [R96]','Report possible elapsed debt; R95 text debt remains separately recorded. Full delivery qualified at94cb8963. [R96]')
needle='| Native workstate dispatch |'
a=s.index(needle);s=s[:a]+'| Shared split construction / delimiter reports | Complete forward report allocation −5.47%, reverse −8.91–8.92% across both APIs | Temporary lists/conversion/copies removed; whole output admitted before fragments. Desktop elapsed inconclusive/adverse; full retained-boundary delivery pending. [R98](../benchmarks/results/2026-11-08-shared-split-construction/README.md) |\n'+s[a:]
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('benchmarks/results/2026-11-08-direct-operand-checkpoint/README.md');s=p.read_text(encoding='utf-8').replace('remain pending at94cb8963, CI42475420182.','pass at94cb8963, cached [CI42475420182](../2026-11-08-direct-operand-transport/delivery-ci.json).')
assert 'remain pending at94cb8963'not in s;p.write_text(s,encoding='utf-8',newline='\n')
p=Path('benchmarks/results/2026-11-08-direct-operand-transport/README.md');s=p.read_text(encoding='utf-8').replace('Full delivery remains pending independently at CI42475420182.','Full Windows/Ubuntu actual11/10, originalStress and installed-core delivery is independently green at [CI42475420182](delivery-ci.json).');p.write_text(s,encoding='utf-8',newline='\n')
p=Path('benchmarks/results/2026-11-08-direct-operand-transport/status.json');v=json.loads(p.read_text(encoding='utf-8'));v['status']='Committed94cb8963; fully qualified Windows/Ubuntu actual11/10, originalStress and installed core consumers';p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8').replace('Full source qualification is independently pending CI42475420182.','Full source qualification is independently green/cached CI42475420182.');p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s=s.replace('Full delivery dispatched11:21:54UTC, pending independently. R95 text debt remains separate.','Fully qualified CI42475420182, cached green11:48UTC: Windows/Ubuntu actual11/10, originalStress and installed consumers. R95 text debt remains separate.')
needle='| Regex R68 |';a=s.index(needle)
s=s[:a]+'''| R97 | Committedfa995d65, B458 completed26jobs539.873s at94cb8963/cored6254b2e, CPython3.13.16; all gates/archive/local verification pass. Separate compile/warm/result and included I/O/cleanup in current guide. WarmCSV1.07×, JSON0.90–0.91×, returnedCSV1.24–1.25×, rsplit1.80×, guarded2.01–2.02×; report/control variability visible. Independent full CI42475420182 green. No causal attribution or debt repayment. |
| R98 | Retained sourcefa995+patch/core2e232a4d,150public/33internal peractual11/10 pass. Explicit split/rsplit share existing admitted final construction/search; temporary list/reversal/conversion/copied backing and duplicate forward builders removed. Original67KB-before-refusal red reproduced; complete preflight now precedes fragments. Full delimiter reports allocation−5.47%forward/−8.91–8.92%reverse; desktop elapsed inconclusive/adverse, controls drift4–20%. Full retained-boundary delivery pending. |
'''+s[a:]
a=s.index('Latest fully qualified runtime');z=s.index('Allocation reduction,',a)
s=s[:a]+'''Latest fully qualified runtime94cb8963/cored6254b2e, CI42475420182 green/cached
11:48UTC: Windows/Ubuntu actual11/10, originalStress and installed consumers.
R98 is separately focused-qualified, not covered by this older CI. CI42475420182/
42472284713/42467357131/42463155006/42459221409/42457767068 and B450-B458 are terminal/
cached, never requery. All VM users/fixtures joined/removed; archives locally verified.
Never requery/re-dispatch terminal runs or imply they qualify later changes.
'''+s[z:]
a=s.index('0. **R96:');z=s.index('2. **Continue',a)
s=s[:a]+'''0. **R98 retained construction milestone.** Source/focused checks, original red,
   failed build/oracle conditions and complete-script allocation evidence are
   recorded in results/EXPERIMENTS. Batch its Windows/Ubuntu actual11/10, original
   Stress and installed-core delivery at this coherent source freeze. Qualification
   must identify this source; R96's green receipt does not certify it. No timing
   gain asserted from unstable desktop controls, no whitespace-gap closure.

1. **R96/R97 closed.** Full source94cb8963 and representative CPython checkpoint
   are independently qualified/recorded. Preserve variable report/control evidence,
   R95 text debt and R96 possible report debt. No repeated collection or old CI polls.

'''+s[z:]
a=s.index('3. **R97:');z=s.index('4. **Independent regex',a)
s=s[:a]+'''3. **Next substantial redesign selection.** R97 still shows ordinary text helpers
   around1.6–2.0×CPython and report/search/manifest gaps. Use existing R93/R94 plus
   current source to identify a complete remaining call/frame, value-transport,
   collection or frontend phase to remove; do not mistake sampled allocation for
   CPU dominance or revive slower arenas/wide carriers. R98 demonstrates that a
   real construction phase can be removed without another architecture layer.
   Bound the next selection to one source pass~20min; if no coherent deletion is
   supported, record why and choose a different boundary instead of producing
   speculative micro-optimizations or repeating unchanged profiling. Before coding,
   state affected complete scripts, displaced implementation, semantic/cancellation/
   ownership gates and one short controlled source pair with unchanged controls.
   Existing R90/R97 evidence is the external checkpoint; no refresh after each tweak.

'''+s[z:]
a=s.index('5. **R98:');z=s.index('## Following substantial',a)
s=s[:a]+s[z:]
s=s.replace('R90/ac5aea97 remains the current CPython\n   checkpoint; refresh at combined milestones, not after every tweak.','R97/94cb8963 is the current CPython\n   checkpoint; refresh at combined milestones, not after every tweak.')
s=s.replace('Current guide accurately names sourceac5aea97; do not remeasure after every tweak.','Current guide accurately names source94cb8963; do not remeasure after every tweak.')
p.write_text(s,encoding='utf-8',newline='\n')
print('R96 cached full delivery recorded; R97 checkpoint closed; R98 delivery and next substantial source gate remain active.')
