from pathlib import Path
import json,subprocess
r=Path(__file__).parent
sources=[
"""for text, sep, limit in [('a::b::::c::','::',-1),('aaa','aa',1),('ababa','aba',1),('é😀tail😀','😀',2),('','|',-1),('||','|',-1),('a|b','|',0),('a|b','|',-7),('a|b','|',99)]:
 print(text.split(sep,limit),text.rsplit(sep,limit))
""",
"""def pieces(text):
 left=text.split
 right=text.rsplit
 return [left(sep='<>',maxsplit=1),right(*('<>',1)),right(**{'sep':'<>','maxsplit':True})]
print(pieces('α<>β<><>γ'))
class Count:
 def __index__(self):return 1
print('a::b::c'.split('::',Count()),'a::b::c'.rsplit('::',Count()))
for method in ('split','rsplit'):
 try:getattr('a',method)('')
 except ValueError as error:print(type(error).__name__,str(error))
""",
"""text='a'*16383+'<>tail<>end'
print([len(part) for part in text.split('<>')],[len(part) for part in text.rsplit('<>')])
print(text.split('<>',1)[1],text.rsplit('<>',1)[1])
value='unchanged'
first=value.rsplit('|',0)
second=value.rsplit('|',-1)
first.append('x')
print(first,second,first is second)
"""
]
items=[]
for i,source in enumerate(sources):
 done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],text=True,encoding='utf-8',capture_output=True);assert done.returncode==0,done.stderr
 (r/f'semantic-{i}.py').write_text(source,encoding='utf-8')
 (r/f'semantic-{i}.expected').write_text(done.stdout,encoding='utf-8')
 items.append('        { '+json.dumps(source,ensure_ascii=False)+', '+json.dumps(done.stdout,ensure_ascii=False)+' },')
text='''using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.PublicApi.Tests;

public sealed class SeparatedStringSplitTests
{
    public static TheoryData<string, string> Cases => new()
    {
'''+ '\n'.join(items)+'''
    };

    [Theory]
    [MemberData(nameof(Cases))]
    public async Task SeparatorsFollowPythonThroughOrdinaryAndExposedCalls(string source, string expected)
    {
        using var compiled = new LythonEngine(Utf8RegexProvider.Instance).Compile(source);
        Assert.True(compiled.IsValid, string.Join("; ", compiled.Diagnostics.Select(d => d.Message)));
        foreach (var asynchronous in new[] { false, true })
        {
            using var result = asynchronous ? await compiled.RunAsync(new MockLythonHost()) : compiled.Run(new MockLythonHost());
            Assert.True(result.Success, result.Failure?.Message);
            Assert.Equal(expected, result.StandardOutput);
        }
    }
}
'''
Path('tests/Lokad.Lython.PublicApi.Tests/SeparatedStringSplitTests.cs').write_text(text,encoding='utf-8',newline='\n')
print('Three independent CPython programs cover both APIs, overlap/direction/Unicode/options/errors/aliases and search chunk boundaries.')
