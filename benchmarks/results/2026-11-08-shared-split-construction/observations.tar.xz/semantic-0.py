for text, sep, limit in [('a::b::::c::','::',-1),('aaa','aa',1),('ababa','aba',1),('é😀tail😀','😀',2),('','|',-1),('||','|',-1),('a|b','|',0),('a|b','|',-7),('a|b','|',99)]:
 print(text.split(sep,limit),text.rsplit(sep,limit))
