def pieces(text):
 left=text.split
 right=text.rsplit
 return [left(sep='<>',maxsplit=1),right(*('<>',1)),right(**{'sep':'<>','maxsplit':True})]
print(pieces('α<>β<><>γ'))
class Count:
 def __index__(self):return 1
print('a::b::c'.split('::',Count()),'a::b::c'.rsplit('::',Count()))
for method in ('split','rsplit'):
 try:getattr('a',method)('')
 except ValueError as error:print(type(error).__name__,str(error))
