text='a'*16383+'<>tail<>end'
print([len(part) for part in text.split('<>')],[len(part) for part in text.rsplit('<>')])
print(text.split('<>',1)[1],text.rsplit('<>',1)[1])
value='unchanged'
first=value.rsplit('|',0)
second=value.rsplit('|',-1)
first.append('x')
print(first,second,first is second)
