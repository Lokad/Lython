from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-08-shared-split-construction')
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
for name in ['observations.tar.xz','identity.json','allocation-and-local.json']:
 target=out/('prototype-'+name);assert not target.exists();shutil.copyfile(out/name,target)
for family,name in [('Lokad.Lython.Tests','WhitespaceSplitCancellationTests.cs'),('Lokad.Lython.Tests','SeparatedSplitOwnershipTests.cs'),('Lokad.Lython.PublicApi.Tests','SeparatedStringSplitTests.cs')]:
 shutil.copyfile(Path('tests')/family/name,r/'tested-tests'/name)
p=r/'selection.md';p.write_text(p.read_text(encoding='utf-8')+'''
Corrected final source: both explicit split/rsplit failed a real suspended __index__
test (two failures, original whitespace case passed). Thread-static ambient context
did not follow awaited host I/O; output admission cancelled but no exception occurred.
Pass current context explicitly from both member implementations. Corrected150public/
35internal peractual11/10 all pass, including genuine pending host I/O/cleanup.
Reconfirmed allocation on corrected core57e1ef6c; old2e232a4d source/core/raw results
and every adverse condition remain as separately labelled prototype evidence.
Corrected desktop report+24.6–28.7%/asyncCSV+15.7–26.6% and unchanged-control drift
remain unexplained/inconclusive; no CPU gain, repayment or final release claim.
''',encoding='utf-8')
with tarfile.open(out/'observations.tar.xz','w:xz')as a:
 for p in sorted(r.iterdir()):
  if p.name=='images':
   for role in ['before','candidate']:a.add(p/role/'Lokad.Lython.dll',arcname=role+'-core.dll')
  else:a.add(p,arcname=p.name)
for src,name in [(r/'identity.json','identity.json'),(r/'assessment-local.json','allocation-and-local.json')]:shutil.copyfile(src,out/name)
p=out/'status.json';v=json.loads(p.read_text(encoding='utf-8'));v['coreSHA256']=identity['coreSHA256'];v['prototypeCoreSHA256']=json.loads((r/'prototype-identity.json').read_text(encoding='utf-8'))['coreSHA256']['candidate'];v['focusedChecks']['internal11']=v['focusedChecks']['internal10']=35;v['archiveSHA256']=hashlib.sha256((out/'observations.tar.xz').read_bytes()).hexdigest();p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
p=out/'README.md';s=p.read_text(encoding='utf-8').replace('patch/core2e232a4d.','patch and explicit-context correction/core57e1ef6c.').replace('150public/33internal','150public/35internal')
s=s.replace('Desktop elapsed controls drift about4–20%, including adverse observations; no','Initial/corrected desktop elapsed controls drift about2–20%, including adverse\nreport+24.6–28.7% and asyncCSV+15.7–26.6% observations; no')
s+='''

The first shared-construction prototype2e232a4d failed two genuine suspended-count
tests: after awaited host I/O, explicit split/rsplit relied on thread-static ambient
context and returned despite cancellation. Both now receive the current context
explicitly; original whitespace and both explicit cases pass on actual11/10.
The corrected57e1ef6c allocation comparison reconfirms the table above. The
[original archive](prototype-observations.tar.xz), [identity](prototype-identity.json)
and [diagnostic](prototype-allocation-and-local.json) retain the earlier source,
conditions and allocation results. Neither its CPU nor the corrected desktop
elapsed is promoted to a controlled speedup claim.
'''
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s=s.replace('150public/33internal peractual11/10 pass; full retained-boundary qualification pending.','Corrected150public/35internal peractual11/10 pass; full retained-boundary qualification pending.')
s+='''The initial R98 prototype2e232a4d then failed two real suspended __index__ cases:
both explicit directions returned despite admission-triggered cancellation after
awaited host I/O. Current context now passes explicitly into shared construction.
Corrected57e1ef6c reconfirms allocation; oldcore/source/results and red tests remain
separate. Corrected desktop report+24.6–28.7% and asyncCSV+15.7–26.6%, unstable
unchanged controls and all initial adverse results remain inconclusive/unexplained.
No controlled elapsed/CPU gain asserted; no new VM collection.

'''
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8').replace('patch/core2e232a4d,150public/33internal','patch/core57e1ef6c,150public/35internal').replace('Full retained-boundary delivery pending. |','Real suspended __index__ cancellation gap reproduced/fixed by explicit current context; old2e prototype/source/diagnostics preserved. Full retained-boundary delivery pending. |');p.write_text(s,encoding='utf-8',newline='\n')
print('Corrected R98 retained; core',identity['coreSHA256']['candidate'],'all original evidence preserved.')
