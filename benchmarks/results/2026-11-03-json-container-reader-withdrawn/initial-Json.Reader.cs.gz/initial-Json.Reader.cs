using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private sealed partial class JsonModule
    {
        private static ValueTask<(object Value, int End)> ReadJsonValueExactAsync(
            PyString input, JsonLoadOptions options, ExecutionContext context,
            LythonSourceSpan span, int position, bool asynchronous)
        {
            var reader = new JsonContainerReader(input, options, context, span, position, asynchronous);
            try
            {
                if (reader.TryRead(out var value, out var pending))
                {
                    reader.Dispose();
                    return new(value);
                }
                // Only a real scalar/object callback suspension transfers this
                // state. Its parent storage stays owned until that user settles.
                return CompleteJsonReadAsync(reader, pending);
            }
            catch { reader.Dispose(); throw; }
        }

        private static async ValueTask<(object Value, int End)> CompleteJsonReadAsync(
            JsonContainerReader reader, ValueTask<(object Value, int End)> pending)
        {
            try
            {
                while (true)
                {
                    reader.AcceptPending(await pending.ConfigureAwait(false));
                    if (reader.TryRead(out var value, out pending)) return value;
                }
            }
            finally { reader.Dispose(); }
        }

        private enum JsonContainerKind { Array, Object, Pairs }

        private struct JsonReadFrame(object container, JsonContainerKind kind, int start)
        {
            internal object Container = container;
            internal JsonContainerKind Kind = kind;
            internal int Start = start;
            internal int ValueEnd = -1;
            internal PyString? Key;
            internal readonly bool IsObject => Kind != JsonContainerKind.Array;
        }

        // The current container is a value. Flat documents allocate no reader
        // object or workspace; only nested containers need the admitted array.
        private struct JsonContainerReader
        {
            private readonly PyString _input;
            private readonly JsonLoadOptions _options;
            private readonly ExecutionContext _context;
            private readonly LythonSourceSpan _span;
            private readonly bool _asynchronous;
            private JsonReadFrame _frame;
            private bool _hasFrame;
            private JsonReadFrame[]? _parents;
            private int _parentCount;
            private MemoryGovernor.TemporaryMemoryReservation? _parentStorage;
            private int _position;
            private (object Value, int End) _value;
            private bool _hasValue;
            private bool _pendingContainer;

            internal JsonContainerReader(PyString input, JsonLoadOptions options,
                ExecutionContext context, LythonSourceSpan span, int position, bool asynchronous)
            {
                _input = input;
                _options = options;
                _context = context;
                _span = span;
                _position = position;
                _asynchronous = asynchronous;
            }

            internal bool TryRead(out (object Value, int End) value,
                out ValueTask<(object Value, int End)> pending)
            {
                var bytes = _input.Utf8Bytes;
                while (true)
                {
                    _context.CheckExecution(_span);
                    if (_hasValue)
                    {
                        if (!_hasFrame)
                        {
                            value = _value;
                            pending = default;
                            return true;
                        }
                        var element = _value.Value!;
                        switch (_frame.Kind)
                        {
                            case JsonContainerKind.Array:
                                ((PyList)_frame.Container).Add(element);
                                break;
                            case JsonContainerKind.Pairs:
                                ((PyList)_frame.Container).Add(PyTuple.FromOwnedArray(
                                    [_frame.Key!, element], _context.MemoryGovernor, _span));
                                break;
                            case JsonContainerKind.Object:
                                ((PyDict)_frame.Container).SetItem(_frame.Key!, element);
                                break;
                        }
                        _frame.Key = null;
                        _frame.ValueEnd = _value.End;
                        _value = default;
                        _hasValue = false;
                        _context.CheckExecution(_span);
                    }

                    if (_hasFrame)
                    {
                        var peek = SkipJsonWhitespace(bytes.Span,
                            _frame.ValueEnd < 0 ? _frame.Start : _frame.ValueEnd, _context, _span);
                        var closing = _frame.IsObject ? (byte)'}' : (byte)']';
                        if (peek < bytes.Length && bytes.Span[peek] == closing)
                        {
                            var end = peek + 1;
                            var callback = _frame.Kind == JsonContainerKind.Pairs ? _options.ObjectPairsHook
                                : _frame.IsObject ? _options.ObjectHook : null;
                            if (callback is not null)
                            {
                                var converted = InvokeJsonCallbackCoreAsync(callback,
                                    _frame.Container, _context, _span, _asynchronous);
                                if (!converted.IsCompletedSuccessfully)
                                {
                                    _pendingContainer = true;
                                    pending = CompleteJsonScalarAsync(converted, end, null);
                                    value = default;
                                    return false;
                                }
                                CompleteContainer((converted.Result, end));
                            }
                            else CompleteContainer((_frame.Container, end));
                            continue;
                        }

                        var next = peek;
                        if (_frame.ValueEnd >= 0)
                        {
                            var comma = EnsureJsonComma(bytes.Span, _frame.ValueEnd, _input, _span, _context);
                            next = SkipJsonWhitespace(bytes.Span, comma + 1, _context, _span);
                            if (next < bytes.Length && bytes.Span[next] == closing)
                                throw NewJsonDecodeFailure(_input,
                                    "Illegal trailing comma before end of " + (_frame.IsObject ? "object" : "array"),
                                    comma, null, _span, _context);
                        }
                        if (next >= bytes.Length || (_frame.IsObject && bytes.Span[next] != (byte)'"'))
                            throw CreateJsonExpectingError(_input, Math.Min(next, bytes.Length),
                                _frame.IsObject ? JsonIncompleteExpectation.PropertyName : JsonIncompleteExpectation.Value,
                                _span, _context);

                        if (_frame.IsObject)
                        {
                            var key = ReadJsonObjectKey(_input, _options, next, _context, _span);
                            _frame.Key = key.Value;
                            var colon = EnsureJsonColon(bytes.Span, key.End, _input, _span, _context);
                            next = SkipJsonWhitespace(bytes.Span, colon + 1, _context, _span);
                        }
                        _position = next;
                    }

                    if (_position >= bytes.Length)
                        throw CreateJsonExpectingError(_input, bytes.Length, JsonIncompleteExpectation.Value, _span, _context);
                    var first = bytes.Span[_position];
                    if (first is (byte)'{' or (byte)'[')
                    {
                        if (_parentCount + (_hasFrame ? 1 : 0) >= 64)
                            throw CreateJsonDepthError(_input, _position, first == (byte)'[', _span, _context);
                        if (_hasFrame) PushParent();
                        var kind = first == (byte)'[' ? JsonContainerKind.Array
                            : _options.ObjectPairsHook is null ? JsonContainerKind.Object : JsonContainerKind.Pairs;
                        object container = kind == JsonContainerKind.Object
                            ? new PyDict(_context.MemoryGovernor, _span)
                            : new PyList([], _context.MemoryGovernor, _span);
                        _frame = new(container, kind, _position + 1);
                        _hasFrame = true;
                        continue;
                    }

                    var scalar = ReadJsonScalarAsync(_input, _options, _context, _span, _position, _asynchronous);
                    if (!scalar.IsCompletedSuccessfully)
                    {
                        _pendingContainer = false;
                        pending = scalar;
                        value = default;
                        return false;
                    }
                    _value = scalar.Result;
                    _hasValue = true;
                }
            }

            internal void AcceptPending((object Value, int End) value)
            {
                if (_pendingContainer) CompleteContainer(value);
                else { _value = value; _hasValue = true; }
                _pendingContainer = false;
            }

            private void CompleteContainer((object Value, int End) value)
            {
                if (_parentCount == 0) { _frame = default; _hasFrame = false; }
                else
                {
                    _frame = _parents![--_parentCount];
                    _parents[_parentCount] = default;
                }
                _value = value;
                _hasValue = true;
            }

            private void PushParent()
            {
                if (_parents is null || _parentCount == _parents.Length)
                {
                    var capacity = _parents?.Length ?? 0;
                    var next = capacity == 0 ? 4 : checked(capacity * 2);
                    // Deliberate metadata headroom; replacement overlaps the
                    // old private array until the copy and reference transfer.
                    var bytes = checked(32L + 96L * next);
                    var previous = capacity == 0 ? 0 : checked(32L + 96L * capacity);
                    _parentStorage ??= _context.MemoryGovernor.ReserveTemporary(0, _span);
                    _parentStorage.Grow(bytes, _span);
                    try { Array.Resize(ref _parents, next); }
                    catch { _parentStorage.Shrink(bytes); throw; }
                    _parentStorage.Shrink(previous);
                }
                _parents[_parentCount++] = _frame;
            }

            internal void Dispose()
            {
                if (_parents is not null) Array.Clear(_parents);
                _parents = null;
                _frame = default;
                _value = default;
                _parentStorage?.Dispose();
                _parentStorage = null;
            }
        }
    }
}
