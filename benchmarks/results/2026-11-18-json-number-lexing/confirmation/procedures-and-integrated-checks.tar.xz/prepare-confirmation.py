from pathlib import Path
import ast
import hashlib
import json
import tarfile

lab = Path(__file__).resolve().parent
original = lab / 'quiet'
target = lab / 'confirmation'
target.mkdir()
read = lambda path: path.read_text(encoding='utf-8')
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, text):
    if name.endswith('.py'):
        ast.parse(text)
    (target / name).write_text(text, encoding='utf-8', newline='\n')


config = json.loads(read(original / 'config.json'))
identity = config['identity']
for role, files in identity['imageFiles'].items():
    assert all(sha(lab / 'frozen' / role / name) == digest for name, digest in files.items())
assert sha(lab / 'representative.json') == config['catalogSHA256']
base = config['root']
root = base.replace('json-numeric-b964', 'json-numeric-confirm-b965')
unit = config['unit'].replace('lython-b964-json-numeric', 'lython-b965-json-numeric-confirm')
config.update(root=root, unit=unit, source=base, retireGroups=[],
              sourceCatalogSHA256=config['catalogSHA256'])
jobs = [('scripts.json-summary-helpers.large', 'warm'),
        ('scripts.numeric-squared-error.floating.large', 'warm')]
collect = read(original / 'collect.py')
left, right = collect.index('jobs = '), collect.index('\nassert len(jobs)')
collect = collect[:left] + 'jobs = ' + repr(jobs) + collect[right:]
collect = collect.replace('len(jobs)==5', 'len(jobs)==2').replace('accumulate8seconds', 'accumulate12seconds')
collect = collect.replace('warmupSeconds=8', 'warmupSeconds=12').replace('min(warmed)<8', 'min(warmed)<12')
collect = collect.replace('warmed[i]>=8', 'warmed[i]>=12').replace('if job_index >= 2:', 'if job_index == 0:')
write('collect.py', collect)
write('archive-owned.py', read(original / 'archive-owned.py').replace(
    "len(raw['jobs'])==5", "len(raw['jobs'])==2").replace('jobs=5,elapsedSeconds', 'jobs=2,elapsedSeconds'))
write('run.sh', read(original / 'run.sh').replace(base, root))
assert b'\r' not in (target / 'run.sh').read_bytes()
write('identity.json', read(original / 'identity.json'))
members = ['collect.py', 'archive-owned.py', 'run.sh', 'identity.json']
payload = target / 'payload.tgz'
with tarfile.open(payload, 'w:gz') as archive:
    for name in members:
        archive.add(target / name, arcname=name)
config.update(payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload),
              unpackedBytes=sum((target / name).stat().st_size for name in members))
write('config.json', json.dumps(config, indent=2) + '\n')

launch = read(original / 'remote-launch.py')
left, right = launch.index('\nc=') + 1, launch.index('\nb=Path(')
launch = launch[:left] + 'c=' + repr(config) + launch[right:]
old_source = "for n,h in c['sourceFiles'].items():assert sha(source/c['sourceRole']/n)==h,n"
assert old_source in launch
launch = launch.replace(old_source, "for role, files in c['identity']['imageFiles'].items():\n"
                        "  for n,h in files.items():assert sha(source/role/n)==h,n")
assert "os.link(source/c['sourceRole']/n,p)" in launch
launch = launch.replace("os.link(source/c['sourceRole']/n,p)", 'os.link(source/role/n,p)')
launch = launch.replace('lython-b964-fixtures', 'lython-b965-fixtures').replace('RuntimeMaxSec=330', 'RuntimeMaxSec=220')
write('remote-launch.py', launch)
write('retrieve.py', read(original / 'retrieve.py').replace("['jobs']==5", "['jobs']==2"))
launcher = read(lab / 'launch.py').replace("/'quiet'", "/'confirmation'").replace('seconds=255', 'seconds=170')
launcher = launcher.replace('before255seconds', 'before170seconds')
ast.parse(launcher)
(lab / 'launch-confirmation.py').write_text(launcher, encoding='utf-8', newline='\n')
summary = read(lab / 'summarize.py').split('reference=json.loads', 1)[0]
summary = summary.replace("r/'quiet/retrieved", "r/'confirmation/retrieved")
summary = summary.replace("len(raw['jobs'])==5", "len(raw['jobs'])==2")
summary = summary.replace("r/'summary.json'", "r/'confirmation/summary.json'")
summary += "print('duration', raw['elapsedSeconds'])\n"
ast.parse(summary)
(lab / 'summarize-confirmation.py').write_text(summary, encoding='utf-8', newline='\n')
