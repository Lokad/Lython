from pathlib import Path
import ast

lab = Path(__file__).resolve().parent
regex = lab.parent / 'regex-capture-count-r533'
stage = (regex / 'stage-comparison.py').read_text(encoding='utf-8')
start = stage.index("    ('2026-11-07")
end = stage.index("    ('2026-11-16", start)
stage = stage[:start] + stage[end:]
start, end = stage.index('\njobs = [') + 1, stage.index('\nstage = stage[:start]')
jobs = [
    ('scripts.numeric-squared-error.floating.large', 'warm'),
    ('scripts.numeric-squared-error.floating.large', 'compile-run'),
    ('scripts.numeric-squared-error.floating.large', 'compile'),
    ('scripts.json-summary-helpers.large', 'warm'),
    ('scripts.text-normalization.helper-list', 'warm'),
]
stage = stage[:start] + 'jobs = ' + repr(jobs) + stage[end:]
start = stage.index("stage = stage.replace(\"'len(jobs)")
end = stage.index('ast.parse(stage)', start)
stage = stage[:start] + """stage = stage.replace(
    "old = lab.parent / 'frontend-dispatch-r527'",
    "old = lab.parent / 'frontend-dispatch-r527'\\ndonor = lab.parent / 'numeric-compiler-facts-r532'")
stage = stage.replace("old_config = read_json(old_quiet / 'config.json')",
                      "old_config = read_json(donor / 'quiet/config.json')")
stage = stage.replace(".replace(source, remote)",
                      ".replace(read_json(old_quiet / 'config.json')['root'], remote)")
stage = stage.replace('Result transport', 'JSON numeric decoding').replace(
    'result transport source pair', 'JSON numeric decoding source pair')
""" + stage[end:]
start = stage.index('identity_path =')
end = stage.index("stage = (lab.parent", start)
stage = stage[:start] + stage[end:]
stage = stage.replace('regex-capture-b963', 'json-numeric-b964').replace(
    'lython-b963-regex-capture', 'lython-b964-json-numeric').replace('lython-b963-fixtures', 'lython-b964-fixtures')
ast.parse(stage)
(lab / 'stage-comparison-generated.py').write_text(stage, encoding='utf-8', newline='\n')
exec(compile(stage, str(lab / 'stage-comparison-generated.py'), 'exec'),
     {'__file__': str(lab / 'stage-comparison-generated.py')})
