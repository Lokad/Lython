from pathlib import Path
import hashlib
import json
import os
import random
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = Path('D:/code/Lython')
previous = lab.parent / 'numeric-compiler-facts-r532'
work = repo / '.git/agent-worktrees/json-numeric-tokens'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
dotnet = Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
python = 'C:/Python313/python.exe'
env = os.environ.copy()
env.update(DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
env['PATH'] = str(dotnet.parent) + os.pathsep + env['PATH']


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n',
                    encoding='utf-8', newline='\n')


def run(name, *arguments):
    with (lab / (name + '.log')).open('w', encoding='utf-8') as output:
        subprocess.run([str(dotnet), *map(str, arguments)], cwd=repo, env=env,
                       stdout=output, stderr=subprocess.STDOUT, check=True, timeout=120)
    print(name, 'passed', flush=True)


core_name = 'Lokad.Lython.dll'
core = work / 'src/Lokad.Lython/bin/Release/net11.0' / core_name
assert sha(core) == sha(work / 'benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0' / core_name)
installed = previous / 'frozen/candidate'
base_hashes = read(previous / 'frozen-identity.json')['imageFiles']['candidate']
assert len(base_hashes) == 32 and base_hashes[core_name].startswith('29192b95')
img = {}
for role in ('reference', 'candidate'):
    folder = lab / 'frozen' / role
    folder.mkdir(parents=True)
    for name, digest in base_hashes.items():
        source = installed / name
        assert sha(source) == digest, name
        shutil.copyfile(core if role == 'candidate' and name == core_name else source, folder / name)
    img[role] = {name: sha(folder / name) for name in base_hashes}
    for source in installed.glob('ValidatedAllocation.*'):
        shutil.copyfile(source, folder / source.name)
assert img['reference'] == base_hashes
assert img['candidate'] == base_hashes | {core_name: sha(core)}

catalog = read(lab.parent / 'frontend-dispatch-r527/catalog.json')
cases = {
    'scripts.numeric-squared-error.floating.large',
    'scripts.json-summary-helpers.large',
    'scripts.report-render.large',
    'scripts.text-normalization.helper-list',
}
selected = [case for case in catalog['cases'] if case['id'] in cases]
assert {case['id'] for case in selected} == cases
catalog_path = lab / 'representative.json'
write(catalog_path, catalog | {'cases': selected})
for role, hashes in img.items():
    folder = lab / 'frozen' / role
    run(role + '-verification', folder / 'Lokad.Lython.Benchmarks.dll',
        '--compare', 'verify', '--catalog', catalog_path, '--dotnet', dotnet,
        '--python', python, '--python-worker', repo / 'benchmarks/cpython-worker.py',
        '--out', lab / (role + '-verification.json'))
    assert all(sha(folder / name) == digest for name, digest in hashes.items())
write(lab / 'frozen-identity.json', {
    'sourceRevision': 'dd4c5165c / 29192b95 versus isolated R534 numeric decoder',
    'purpose': 'JSON fixed-point and integer scalar decoding with warm, compile and complete fresh controls',
    'imageFiles': img,
    'catalogSHA256': sha(catalog_path),
    'coreSHA256': {name: img[role][core_name] for role in img for name in (role, role + '-control')},
    'normalAdapterPin': '0.4.0',
})

# Compare exact output bits for both bounded and fallback numeric tokens.
tokens = ['0', '-0', '-0.' + '0' * 18, '9223372036854775807', '-9223372036854775808',
          '9223372036854775808', '-9223372036854775809', '18446744073709551616000000',
          '900719925474099.1', '900719925474099.2', '900719925474099.3',
          '2.2250738585072014e-308', '2.2250738585072011e-308', '4.9406564584124654e-324',
          '1e400', '-1e400', '-1e-400', '1.000000000000000000000001']
rng = random.Random(534)
for _ in range(350):
    whole = str(rng.randrange(0, 10 ** rng.randrange(1, 19)))
    width = rng.randrange(1, 22)
    fraction = str(rng.randrange(10 ** width)).zfill(width)
    if rng.randrange(3) != 0:
        whole += '.' + fraction
    if rng.randrange(5) == 0:
        whole += 'e' + str(rng.randrange(-355, 355))
    tokens.append(('-' if rng.randrange(2) else '') + whole)
script = lab / 'exact-reference.py'
script.write_text(
    "import json\nfor item in json.loads(" + repr('[' + ','.join(tokens) + ']') +
    "):\n    print(item.hex() if isinstance(item,float) else item)\n",
    encoding='utf-8', newline='\n')
for target in ('net11.0', 'net10.0'):
    probe = work / 'tools/LythonProbe/bin/Release' / target / 'LythonProbe.dll'
    for mode in ('sync', 'async'):
        run(f'python-{target}-{mode}', probe, script, '--compare-python', '--python', python,
            *(['--async'] if mode == 'async' else []))
