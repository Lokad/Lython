from pathlib import Path
import ast
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
old = lab.parent / 'frontend-dispatch-r527'
donor = lab.parent / 'numeric-compiler-facts-r532'
old_quiet = old / 'quiet'
quiet = lab / 'quiet'
quiet.mkdir(exist_ok=False)
remote = '/home/lokad/lython-bench-checks/json-numeric-b964-20261118'
unit = 'lython-b964-json-numeric-20261118'

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def read(path):
    return path.read_text(encoding='utf-8')

def write(path, value):
    path.write_text(value, encoding='utf-8', newline='\n')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

identity = read_json(lab / 'frozen-identity.json')
assert all(digest(lab / 'frozen' / role / name) == sha for role, files in identity['imageFiles'].items() for name, sha in files.items())
write(quiet / 'identity.json', json.dumps(identity, indent=2) + '\n')
old_config = read_json(donor / 'quiet/config.json')
source = old_config['root']
jobs = [('scripts.numeric-squared-error.floating.large', 'warm'), ('scripts.numeric-squared-error.floating.large', 'compile-run'), ('scripts.numeric-squared-error.floating.large', 'compile'), ('scripts.json-summary-helpers.large', 'warm'), ('scripts.text-normalization.helper-list', 'warm')]
collect = read(old_quiet / 'collect.py')
start, end = collect.index('jobs='), collect.index('\nassert len(jobs)')
collect = collect[:start] + 'jobs = ' + repr(jobs) + collect[end:]
collect = collect.replace('len(jobs)==6', 'len(jobs)==5').replace('prepared discarded-result consumer source pair', 'JSON numeric decoding source pair')
write(quiet / 'collect.py', collect)
write(quiet / 'archive-owned.py', read(old_quiet / 'archive-owned.py').replace("len(raw['jobs'])==6", "len(raw['jobs'])==5").replace('jobs=6,elapsedSeconds', 'jobs=5,elapsedSeconds'))
write(quiet / 'run.sh', read(old_quiet / 'run.sh').replace(read_json(old_quiet / 'config.json')['root'], remote))
assert b'\r' not in (quiet / 'run.sh').read_bytes()
(quiet / 'candidate').mkdir()
shutil.copyfile(lab / 'frozen/candidate/Lokad.Lython.dll', quiet / 'candidate/Lokad.Lython.dll')
shutil.copyfile(lab / 'representative.json', quiet / 'representative.json')
members = ['representative.json', 'collect.py', 'archive-owned.py', 'run.sh', 'identity.json', 'candidate/Lokad.Lython.dll']
with tarfile.open(quiet / 'payload.tgz', 'w:gz') as archive:
    for name in members:
        archive.add(quiet / name, arcname=name)
total = sum((quiet / name).stat().st_size for name in members)
space = read_json(lab / 'space.json')
proofs = []
free = space['freeBytes']
for group in space['choices']:
    if free > 254 * 1024 * 1024 + total + 131072:
        break
    proofs.append(group)
    free += group['bytes']
assert free > 254 * 1024 * 1024 + total + 131072, (free, total)
config = dict(root=remote, unit=unit, source=source, sourceRole='candidate', sourceFiles=identity['imageFiles']['reference'],
              sourceCatalogSHA256=old_config['catalogSHA256'], catalogSHA256=identity['catalogSHA256'], identity=identity,
              retireGroups=proofs, payloadBytes=(quiet / 'payload.tgz').stat().st_size,
              payloadSHA256=digest(quiet / 'payload.tgz'), unpackedBytes=total)
write(quiet / 'config.json', json.dumps(config, indent=2) + '\n')
launch = read(old_quiet / 'remote-launch.py')
start, end = launch.index('\nc=') + 1, launch.index('\nb=Path(')
launch = launch[:start] + 'c=' + repr(config) + launch[end:]
write(quiet / 'remote-launch.py', launch.replace('lython-b957-fixtures', 'lython-b964-fixtures').replace('RuntimeMaxSec=400', 'RuntimeMaxSec=330'))
write(quiet / 'retrieve.py', read(old_quiet / 'retrieve.py').replace("['jobs']==6", "['jobs']==5").replace('B944 complete-source', 'JSON numeric decoding'))
write(lab / 'launch.py', read(old / 'launch.py').replace('seconds=340', 'seconds=255').replace('before340seconds', 'before255seconds').replace('Six-job frontend-dispatch source pair', 'JSON numeric decoding source pair'))
write(lab / 'summarize.py', read(old / 'summarize.py').replace("len(raw['jobs'])==6", "len(raw['jobs'])==5"))
for path in [lab / 'launch.py', lab / 'summarize.py', *quiet.glob('*.py')]:
    ast.parse(read(path))
print('Staging', total, 'bytes using', len(proofs), 'verified historical replica group(s).')
