from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = Path('D:/code/Lython')
work = repo / '.git/agent-worktrees/json-numeric-tokens'
out = repo / 'benchmarks/results/2026-11-18-json-number-lexing'
quiet = lab / 'quiet'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
status = read(quiet / 'terminal-status.json')
receipt = status['receipt']
assert status['exitCode'] == '0' and not status['remainingTrace'] and not status['remainingWorkers']
assert receipt['complete'] and receipt['jobs'] == 5 and receipt['archivedAndVerifiedUnderLease']
assert receipt['allWorkersJoined'] and receipt['guestFixturesRemoved'] and receipt['quietBeforeAndAfter']
assert sha(quiet / 'observations.tgz') == receipt['archiveSHA256']
out.mkdir()
for name in ('archive-receipt.json', 'terminal-status.json', 'observations.tgz'):
    shutil.copyfile(quiet / name, out / name)
for name in ('frozen-identity.json', 'reference-verification.json', 'candidate-verification.json',
             'allocation-summary.json', 'summary.json'):
    shutil.copyfile(lab / name, out / name)
patch = subprocess.check_output(['git', 'diff', '--binary'], cwd=work)
(out / 'candidate.patch.gz').write_bytes(gzip.compress(patch, mtime=0))
with tarfile.open(out / 'procedures-and-checks.tar.xz', 'w:xz') as archive:
    for name in ('prepare-comparison.py', 'stage-comparison.py', 'stage.py', 'launch.py',
                 'summarize.py', 'archive.py', 'space.json', 'representative.json',
                 'reference-verification.log', 'candidate-verification.log',
                 'reference-allocation.json', 'candidate-allocation.json', 'exact-reference.py',
                 'quiet/config.json', 'quiet/collect.py', 'quiet/archive-owned.py', 'quiet/run.sh',
                 'quiet/remote-launch.py', 'quiet/retrieve.py', 'quiet/launch.log'):
        archive.add(lab / name, arcname=name)
    for check in sorted(lab.glob('*.log')):
        if check.name not in ('reference-verification.log', 'candidate-verification.log'):
            archive.add(check, arcname=check.name)
    archive.add(lab.parent / 'json-numeric-tokens-r534-build.log', arcname='build.log')
print('Archived source, both actual images’ hashes, focused checks and the five-job comparison.')
