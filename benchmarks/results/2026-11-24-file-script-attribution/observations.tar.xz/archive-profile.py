from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
test=lab/"comparison/attribution"
out=root/"benchmarks/results/2026-11-24-file-script-attribution"
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
read=lambda path:json.loads(path.read_text(encoding="utf-8-sig"))
identity=read(lab/"comparison/identity.json")
commit="556c8d71c"
committed=subprocess.check_output(["git","diff","--binary",commit+"^",commit,"--","src","tests"],cwd=root)
assert hashlib.sha256(committed).hexdigest()==identity["sourcePatchSHA256"]
expected=identity["imageFiles"]["candidate"]
assert {path.name:sha(path) for path in (lab/"comparison/candidate").iterdir()}==expected
proof=read(test/"measurements.json")
assert len(proof)==2
artifacts=["archive-profile.py","comparison/profile.py","comparison/collect.py","comparison/attribution/attribute.py",
           "comparison/attribution/measurements.json","comparison/candidate-verify.json","comparison/identity.json",
           "comparison/representative.json","profile.log"]
for row in proof:
    case=row["case"]
    assert sha(test/(case+".nettrace"))==row["traceSHA256"]
    assert sha(test/(case+".speedscope.json"))==row["speedscopeSHA256"]
    assert row["golden"]["catalogSha256"]==identity["catalogs"]["representative.json"]["sha256"]
    assert next(library["sha256"] for library in row["golden"]["libraries"]
                if Path(library["path"]).name=="Lokad.Lython.dll")==expected["Lokad.Lython.dll"]
    assert all(batch["response"]["status"]=="Completed" for batch in row["batches"])
    for suffix in (".nettrace",".speedscope.json",".trace.log"):
        artifacts.append(f"comparison/attribution/{case}{suffix}")
out.mkdir(exist_ok=True)
shutil.copyfile(test/"attribution.json",out/"attribution.json")
with tarfile.open(out/"observations.tar.xz","w:xz",preset=4) as bundle:
    for file in artifacts: bundle.add(lab/file,arcname=file)
with tarfile.open(out/"observations.tar.xz") as bundle:
    assert all(hashlib.sha256(bundle.extractfile(p).read()).hexdigest()==sha(lab/p) for p in artifacts)
print("Archived both completed traces and checked every stored byte")
