from collections import Counter
from pathlib import Path
import hashlib
import json

folder=Path(__file__).resolve().parent
observations=json.loads((folder/"measurements.json").read_text(encoding="utf-8"))
probes={
  "host_file_methods": ("ComparisonFileHost.","ComparisonFileHost+",),
  "file_open": ("OpenedByteFile+<OpenAsync>",),
  "file_read": ("OpenedByteFile+<ReadAsync>", "OpenedByteFile+<ReadAtAsync>"),
  "file_write": ("OpenedByteFile+<WriteAsync>",),
  "file_close_or_flush": ("OpenedByteFile+<CloseAsync>", "OpenedByteFile+<FlushAsync>"),
  "json": ("LythonRuntime+JsonModule", "LythonRuntime+JsonEncodeIterator", "LythonRuntime+JsonDecode"),
  "json_document": ("JsonModule+<ReadDocumentAsync>",),
  "json_decode": ("JsonModule+<ParseJsonTextCoreAsync>", "JsonModule.ReadJsonContainer", "JsonModule.ContinueJsonContainer"),
  "json_encode": ("JsonEncodeIterator.", "JsonEncodeIterator+"),
  "text_read_all": ("ChunkedTextFileReadState.ReadAll(", "ChunkedTextFileReadState+<ReadAllAsync>"),
  "native_workspace": ("PyExecutableFunction.StartNativeWorkspace(",),
  "dedicated_stack_queue": ("ExecutionThreads.Take(",),
  "result_disposal": ("LythonRunResult.Dispose(",),
  "runtime_work": ("ExecutionThreads+WorkItem.Execute(",),
  "worker_file_verification": ("ComparisonFileHost.ReadOutputs(",),
  "worker_fixture_reset": ("ComparisonFileHost.Reset(",),
  "caller_wait_for_guest": ("ExecutionThreads+SynchronousWorkItem.Wait(",),
}
rows=[]
for proof in observations:
    case=proof["case"]
    speed=folder/(case+".speedscope.json")
    assert hashlib.sha256(speed.read_bytes()).hexdigest()==proof["speedscopeSHA256"]
    trace=folder/(case+".nettrace")
    assert hashlib.sha256(trace.read_bytes()).hexdigest()==proof["traceSHA256"]
    doc=json.loads(speed.read_text(encoding="utf-8"))
    names=[entry["name"] for entry in doc["shared"]["frames"]]
    frame_masks=[tuple(key for key, needles in probes.items() if any(s in name for s in needles)) for name in names]
    guest_profiles=[]
    total=0.0
    cpu=Counter()
    wall=Counter()
    for profile in doc["profiles"]:
        stack=[]
        last=profile["startValue"]
        thread_cpu=Counter()
        for event in profile["events"]:
            at=event["at"]
            weight=at-last
            if weight>0 and stack:
                active=set(key for frame in stack for key in frame_masks[frame])
                wall.update({key:weight for key in active})
                if names[stack[-1]]=="CPU_TIME":
                    total+=weight
                    if {"host_file_methods","file_open"} <= active: active.add("host_while_opening")
                    thread_cpu.update({key:weight for key in active})
            last=at
            if event["type"]=="O": stack.append(event["frame"])
            else: assert stack.pop()==event["frame"]
        assert not stack
        if thread_cpu["runtime_work"] > 1:
            guest_profiles.append((profile["name"],thread_cpu))
        cpu.update(thread_cpu)
    assert len(guest_profiles)==1
    thread,work=guest_profiles[0]
    rows.append({"case":case,"thread":thread,"processCpuTaggedMilliseconds":total,
                 "executionThreadCpuTaggedMillisecondsByStack": {k:round(v,1) for k,v in work.items()},
                 "allThreadsCpuTaggedMillisecondsByStack": {k:round(v,1) for k,v in cpu.items()},
                 "allThreadsElapsedMillisecondsByStack": {k:round(v,1) for k,v in wall.items()},
                 "traceSha256":proof["traceSHA256"],"speedscopeSha256":proof["speedscopeSHA256"]})
    print(case,thread,dict(work))
out=folder/"attribution.json"
out.write_text(json.dumps({"classification":"Inclusive tagged sample weights on the WSL comparison worker, overlapping stack groups. Trace converter categories do not estimate removable cost.",
                           "rows":rows},indent=2)+"\n",encoding="utf-8",newline="\n")
