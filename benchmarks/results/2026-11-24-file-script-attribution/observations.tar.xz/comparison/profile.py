from pathlib import Path
root = Path(__file__).resolve().parent
template = (root / "collect.py").read_text(encoding="utf-8")
prefix = template[:template.index("def warm():")].replace("out = root / 'confirmation'", "out = root / 'attribution'")
exec(compile(prefix, str(root / "collect.py"), "exec"))
tool = Path.home() / ".dotnet/tools/dotnet-trace"
check_image()
observations = []
try:
    for case in (jobs[0][0], jobs[-1][0]):
        with contextlib.ExitStack() as stack:
            runner = Worker("candidate", cases[case], "warm", stack)
            warmed = 0.0
            n = 1
            while warmed < 3:
                runner.request("batch", n)
                warmed += runner.last_request_seconds
                n = max(1,min(100000,math.ceil(n*.2/max(runner.last_request_seconds,.000001))))
            target = out / (case+".nettrace")
            with (out / (case+".trace.log")).open("wb") as log:
                tracer = subprocess.Popen([tool,"collect","--process-id",str(runner.process.pid),
                    "--profile","dotnet-sampled-thread-time","--duration","00:00:00:06","--format","Speedscope",
                    "--output", target],env=env,stdout=log,stderr=subprocess.STDOUT)
                batches=[]
                try:
                    end=time.monotonic()+13
                    while tracer.poll() is None and time.monotonic()<end:
                        response=runner.request("batch",n)
                        batches.append(dict(response=response,requestSeconds=runner.last_request_seconds,
                           cpuTicks=runner.last_cpu_ticks, cpuFrequency=cpu_frequency))
                    assert tracer.wait(timeout=2)==0
                finally:
                    if tracer.poll() is None: tracer.terminate(); tracer.wait(timeout=3)
            assert target.stat().st_size>0
            profile=read_trace=next(out.glob(case+".*speedscope.json"))
            observations.append(dict(case=case, golden=runner.identity, batches=batches, traceSHA256=digest(target),
                 speedscopeSHA256=digest(profile), sampling="managed thread time diagnostic, no CPU or elapsed comparison"))
        print(case,"trace collected and worker closed",flush=True)
    check_image()
    assert not list(owned_ram.iterdir())
    (out/"measurements.json").write_text(json.dumps(observations,indent=2)+"\n",encoding="utf-8")
finally:
    owned_ram.rmdir()
