from pathlib import Path
import hashlib, json, shutil, tarfile

r = Path(__file__).parent
repo = Path('D:/code/Lython')
out = repo / 'benchmarks/results/2026-11-17-current-script-costs'
out.mkdir(exist_ok=False)
receipt = json.loads((r / 'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter']
assert receipt['ramTraceArchivedAndVerifiedBeforeUnmount'] and receipt['guestFixturesRemoved']
assert hashlib.sha256((r / 'observations.tgz').read_bytes()).hexdigest() == receipt['archiveSHA256']
for name in ['observations.tgz', 'archive-receipt.json', 'terminal-status.json', 'identity.json', 'attribution.json']:
    shutil.copyfile(r / name, out / name)
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for p in list(r.glob('*.py')) + list(r.glob('*.json')) + list(r.glob('*.log')):
        archive.add(p, arcname=p.name)
    archive.add(repo / '.git/agent-notes/review-20261031/generator-sum-r475/prepare-current-profile.py', arcname='prepare-current-profile.py')
source_gate = dict(source='abcbd9fd/frozenca1a8239',
    demonstrated=[
        'Eligible native calls already use stack-backed small arguments and deferred invocation contexts. Bound storage already becomes locals; no unconditional full child frame per helper.',
        'Default JSON numeric conversion is a non-async method returning a completed ValueTask over native UTF-8. Construction is iterative and suspends only for hooks; no per-number async state machine to delete.',
        'PyList already owns its final object[] with explicit count/capacity and replacement preflight; no List<object> wrapper to remove.',
        'Native integral floor division/modulo and direct unpacked helper returns already exist. Do not repeat their original optimization.'],
    hypothesesNotDecisions=[
        'Native list storage could avoid numeric boxes, but mutable reads must retain canonical identity across aliases and later mutation. Immutable tuple indirection cannot simply be reused. A uniform wider payload also affects string-heavy CSV and direct array transfers.',
        'Call/record pipeline consolidation still merits inspection, but current profiles do not identify another removable whole stage. Inclusive dispatch/call groups contain useful arithmetic, parsing and indexing.'],
    gateDecision='Two bounded current-source captures and targeted source checks complete. No new runtime prototype justified yet; continue structural call/record design with explicit semantic/storage scope. No permanent design ban, repeated capture, fixed-percentage veto or performance forecast.',
    unchangedProduction=True, publicationHeld=True)
(out / 'source-gate.json').write_text(json.dumps(source_gate, indent=2) + '\n', encoding='utf-8')
(out / 'README.md').write_text('''# Current complete-script costs after generator lifetime sharing

R476/B888,2026-11-17UTC, committed **abcbd9fd / frozenca1a8239**. One bounded
CPU capture each of the complete floating report and CSV invoice. This is
attribution, **not a controlled elapsed comparison or removable CPU shares**.
No production edit or new qualification of unchanged source.

| Capture | Active samples | Unknown leaves | Highest nearest Lython frames |
| --- | ---: | ---: | --- |
| Floating JSON report | 950 | 69 | instruction prefix167; stack transfer112; JSON numeric conversion104; construction63; sequence selector51; index read50 |
| CSV invoice | 1,090 | 71 | native execution134; instruction prefix109; parser Feed79; native call74; record finish48; integer selection40; admission39 |

Nearest-frame categories distinguish where samples return to Lython from the
broader overlapping inclusive groups in the raw summary. Inlined useful work is
included. Generic MoveNext carriers are not generator-exclusive cost. Unknown,
ambiguous and malformed symbol data remain in the full attribution; do not
subtract sample fractions from R472 or forecast an eliminated percentage.

Quiet AzureF4as_v7/Ubuntu24.04.4/.NET11RC3, same frozen32file image and actual-
worker-verified2case catalog as B887. Diagnostic DOTNET_PerfMapEnabled=3,
perf cpu-clock199Hz/frame-pointer stacks, about5s active capture/case. The active
execution threads use4.78/5.49CPU seconds; wider thread CPU/raw stacks remain
preserved. Whole worker batches include reset/protocol/validation beyond guest
clocks. No default-runtime timing, allocation change or CPython ratio is inferred.

Source checks correct stale premises: native calls already use stack-backed
arguments/deferred contexts and bound locals; default JSON numbers already parse
synchronously from UTF-8; construction already iterates/adopts admitted frames;
lists already own their final arrays; integer floor/modulo and direct unpacked
helper returns already exist. A mutable native-slot list rewrite would also need
canonical scalar identity across aliases/mutation and revised direct transfers.
The immutable tuple mechanism is not sufficient by itself; no new identity ledger
or storage prototype is started on an allocation estimate alone.

The bounded gate is complete with remaining architectural uncertainty. Current
evidence supports continued call/record pipeline investigation, not another local
selector or a repeated old full-frame optimization. Name a removable complete
stage and its semantic contract before the next prototype. This is not a permanent
ban or conclusion that further improvements are impossible.

Both actual workers finish goldens/Closed/exit and join. Machine gates pass;
every RAM trace is archived and SHA-verified persistently before unmount. Exact
committed replica retirement420,800B has fresh UID/path/hash/link/all-alias proof;
current images/toolchains/canonicals and254/252MiBfloors preserved. Terminal
cached; no repeat capture. Full runtime delivery is separately tracked. Publication
held and the broader performance objective remains active.

[Full attribution](attribution.json),[source gate](source-gate.json),
[exact raw stacks/maps](observations.tgz),[identity](identity.json),
[custody](archive-receipt.json),[procedures](procedures.tar.xz).
''', encoding='utf-8', newline='\n')
with (repo / 'benchmarks/EXPERIMENTS.md').open('a', encoding='utf-8', newline='\n') as stream:
    stream.write('''
[R476/B888 current floating/CSV costs](results/2026-11-17-current-script-costs/README.md):
950/1090active samples,69/71unknown leaves; useful parsing/index/arithmetic overlaps
dispatch/calls, no removable-share forecast. Native stack arguments/deferred contexts,
iterative/defaultUTF8JSON, owned list arrays, nativefloor/mod and unpacked returns
already exist. Mutable scalar-slot storage needs identity/mutation/direct-transfer
design, not immutable-tuple reuse alone. Two bounded captures/source gate complete;
no justified next runtime prototype yet, no permanent ban or repeated capture.
All users joined/RAM traces archived+verified before unmount; qualified runtime
unchanged. Continue structural call/record design; publication held.
''')
p = repo / 'PLAN.md'
s = p.read_text(encoding='utf-8')
a = s.index('**R476 —')
b = s.index('\n| Selected design area', a)
s = s[:a] + '''**R476 current-source gate complete; next design selection remains active.**
[Two bounded floating/CSV captures](benchmarks/results/2026-11-17-current-script-costs/README.md)
retain950/1090active samples and69/71unknown leaves. Inclusive dispatch/call
groups overlap useful parsing/index/arithmetic, not removable shares. Native calls
already have stack arguments/deferred contexts/bound locals; default JSON numbers
already parse synchronously from UTF-8; list payload arrays, integer floor/modulo
and native unpacked returns already exist. Do not implement those old premises.
No further unchanged capture. A mutable slot-array rewrite needs a canonical
identity/mutation/direct-transfer design; immutable tuple indirection is insufficient.
Do not add a scalar identity ledger or prototype it from allocation estimates alone.
Next: select a complete remaining call/record handoff or storage stage and its
semantic scope before code. The profile gate ends with explicit uncertainty,
not a permanent design ban or completion of the performance objective.
''' + s[b:]
p.write_text(s, encoding='utf-8', newline='\n')
print('Two current-source captures preserved; bounded source gate complete with explicit uncertainty. No runtime prototype or repeated qualification.')
