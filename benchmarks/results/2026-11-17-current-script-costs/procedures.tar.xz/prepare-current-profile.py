from pathlib import Path
import ast, hashlib, io, json, subprocess, tarfile

base = Path(__file__).parent
r = base.parent / 'current-script-costs-r476'
r.mkdir(exist_ok=False)
old = base.parent / 'numeric-pipeline-r472'
repo = Path('D:/code/Lython')
remote = '/home/lokad/lython-bench-checks/current-script-costs-b888-20261117'
prior = json.loads((base / 'cpython-focused/quiet/config.json').read_text(encoding='utf-8'))
f = json.loads((base / 'frozen/identity.json').read_text(encoding='utf-8'))
identity = dict(sourceRevision='abcbd9fd/frozenca1a8239; no production changes since retainedR475', purpose='One bounded current-source CPU attribution for complete floating report and CSV invoice, after generator frame-lifetime consolidation. Identify a removable call/frame/storage stage, not elapsed comparison or inclusive removable shares.', coreSHA256={'candidate': f['imageFiles']['candidate']['Lokad.Lython.dll']}, auxiliaryFiles={n:h for n,h in f['imageFiles']['candidate'].items() if n != 'Lokad.Lython.dll'}, imageFiles={'candidate': f['imageFiles']['candidate']}, catalogSHA256=prior['catalogSHA256'], productionFiles=585, publicationHeld=True)
(r / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8')
old_labels = "['numeric-integer','numeric-floating']"
labels = "['numeric-floating','csv-invoice']"
s = (old / 'ops-profile.py').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/numeric-pipeline-b882-20261117', remote)
s = s.replace("[('numeric-integer','scripts.numeric-squared-error.large','warm'),('numeric-floating','scripts.numeric-squared-error.floating.large','warm')]", "[('numeric-floating','scripts.numeric-squared-error.floating.large','warm'),('csv-invoice','scripts.csv-invoice.large','warm')]")
(r / 'ops-profile.py').write_text(s, encoding='utf-8', newline='\n')
s = (old / 'collect.py').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/numeric-pipeline-b882-20261117', remote).replace(old_labels, labels)
s = s.replace('Committeddc480d38/frozen5ecb2599; R472 complete integer/floating report attribution, fullCI44022750002active', 'Committedabcbd9fd/frozenca1a8239; R476 complete floating report/CSV attribution, delivery44041981387active')
(r / 'collect.py').write_text(s, encoding='utf-8', newline='\n')
(r / 'run.sh').write_text((old / 'run.sh').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/numeric-pipeline-b882-20261117', remote), encoding='utf-8', newline='\n')
groups = []
for canonical, prefix, members in [
    ('benchmarks/results/2026-11-17-generator-sum/cpython/observations.tgz', 'generator-sum-cpython-b887-20261117', ['confirmation/confirmation.json', '__pycache__/cpython-worker.cpython-312.pyc']),
    ('benchmarks/results/2026-11-17-generator-sum/observations.tgz', 'generator-sum-b886-20261117', ['__pycache__/cpython-worker.cpython-312.pyc'])]:
    blob = subprocess.check_output(['git', 'show', 'HEAD:' + canonical], cwd=repo)
    assert blob == (repo / canonical).read_bytes()
    with tarfile.open(fileobj=io.BytesIO(blob)) as archive:
        for member in members:
            data = archive.extractfile(member).read()
            groups.append(dict(paths=[prefix + '/' + member], bytes=len(data), links=1, sha256=hashlib.sha256(data).hexdigest(), canonical=canonical, canonicalSHA256=hashlib.sha256(blob).hexdigest(), member=member, committedBlobVerified=True, optional=True))
    if 'cpython/' in canonical:
        groups.append(dict(paths=[prefix + '/observations.tgz'], bytes=len(blob), links=1, sha256=hashlib.sha256(blob).hexdigest(), canonical=canonical, canonicalSHA256=hashlib.sha256(blob).hexdigest(), member='whole-archive', committedBlobVerified=True, optional=True))
names = ['collect.py', 'ops-profile.py', 'run.sh', 'identity.json']
with tarfile.open(r / 'payload.tgz', 'w:gz') as archive:
    for name in names: archive.add(r / name, arcname=name)
c = dict(root=remote, unit='lython-b888-current-script-costs-20261117', source=prior['root'], sourceRole='candidate', sourceFiles=f['imageFiles']['candidate'], sourceCatalogSHA256=prior['catalogSHA256'], catalogSHA256=prior['catalogSHA256'], identity=identity, retireGroups=groups, payloadBytes=(r / 'payload.tgz').stat().st_size, payloadSHA256=hashlib.sha256((r / 'payload.tgz').read_bytes()).hexdigest(), unpackedBytes=sum((r / name).stat().st_size for name in names))
(r / 'config.json').write_text(json.dumps(c, indent=2) + '\n', encoding='utf-8')
s = (old / 'remote-launch.py').read_text(encoding='utf-8'); a = s.index('c='); b = s.index('\nb=Path(', a); s = s[:a] + 'c=' + repr(c) + s[b:]
s = s.replace('lython-b882-fixtures', 'lython-b888-fixtures')
(r / 'remote-launch.py').write_text(s, encoding='utf-8', newline='\n')
for name in ['launch.py', 'retrieve.py']:
    (r / name).write_text((old / name).read_text(encoding='utf-8'), encoding='utf-8', newline='\n')
(r / 'analyze.py').write_text((old / 'analyze.py').read_text(encoding='utf-8').replace(old_labels, labels), encoding='utf-8', newline='\n')
for p in r.glob('*.py'): ast.parse(p.read_text(encoding='utf-8'))
print('Prepared two bounded current-source CPU captures; existing actual-worker-verified2case catalog. Stage', c['unpackedBytes'], 'retire only', sum(g['bytes'] for g in groups), 'committed replica bytes; preserve both current cores/toolchains.')
