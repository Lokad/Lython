set -eu
root=/home/lokad/lython-bench-checks/protected-checkpoint-b757-20261114
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
