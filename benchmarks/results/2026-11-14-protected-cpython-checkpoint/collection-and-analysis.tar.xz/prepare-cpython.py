from pathlib import Path
import ast,hashlib,json,tarfile

r=Path(__file__).parent;b=r/'b757';b.mkdir()
old=r.parent/'range-iteration-r362/b747'
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
delivery=json.loads((r/'delivery/delivery-candidate.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
remote='/home/lokad/lython-bench-checks/protected-checkpoint-b757-20261114';unit='lython-b757-protected-checkpoint-20261114'
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='Committed'+delivery['head']+'/frozen'+source['coreSHA256']['candidate']+'; full'+delivery['runId']+' independently active',purpose='One targeted external checkpoint for newly qualified source forms: protected invoice warm/compile/fresh and protected early-exit search warm. Same actual current script/input/output under stockCPython3.13.16, fixed existing workers. Earlier B747 plain scripts remain their own revision; no unchanged nine-job rerun or crosscollection attribution.',coreSHA256={k:source['coreSHA256']['candidate'] for k in identity['coreSHA256']},catalogSHA256=sha(r/'catalog.json'),sourceIdentitySHA256=sha(r/'candidate-identity.json'),sourceProofSHA256=sha(r/'delivery/source-proof.json'),sourceArchiveSHA256=sha(r/'candidate-sources.tar.xz'),sourceProofCommit=delivery['head'],publicationHeld=True)
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.csv-invoice.large.protected','warm'],['scripts.csv-invoice.large.protected','compile'],['scripts.csv-invoice.large.protected','compile-run'],['scripts.file-search.large.protected','warm']]
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(old/n).read_text(encoding='utf-8').replace('range-checkpoint-b747-20261114','protected-checkpoint-b757-20261114').replace('lython-b747-range-checkpoint-20261114',unit).replace('B747','B757')
    if n=='collect.py':
        a=s.index('jobs=');end=s.index('\nenv =',a)
        s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n'+s[end:]
        s=s.replace('started < 420','started < 180')
    elif n=='archive-owned.py':s=s.replace("len(raw['jobs'])==9","len(raw['jobs'])==4").replace('jobs=9','jobs=4')
    elif n=='retrieve.py':s=s.replace("['jobs']==9","['jobs']==4").replace("['elapsedSeconds']<480","['elapsedSeconds']<240").replace('nine-job','four-job')
    elif n=='summarize.py':s=s.replace("len(raw['jobs'])==9","len(raw['jobs'])==4").replace('jobs=9','jobs=4')
    if n.endswith('.py'):ast.parse(s)
    (b/n).write_text(s,encoding='utf-8',newline='\n')
(b/'prospective.json').write_text(json.dumps(dict(purpose=identity['purpose'],jobs=jobs,bound='One240sowner/180sstartguard,4phasejobs,2freshprocesses/engine/job,5sfullrequestwarmup,5rotating0.5sbatches;normalGC/tiering/GIL. Existing image/catalog/worker/toolchain hardlinks, no new core/catalog upload or retirement.254/252MiB floors unchanged.',acceptance='Exact current source proof/all libraries, independent output/files/budget, stockPythonidentity/GIL/GC, quiet/join/archive. Separate compile,warm,fresh plus includedRAMI/O/cleanup and widerCPU. Keep every spread/IQR/adverse result and historicaltable revision explicit.',stopping='One usable targeted external observation or bounded measurement correction justified by evidence. No new benchmark framework or unchangedB747rerun. FullCI runs independently; sourcequal status explicit; publicationheld.'),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(b/'payload.tgz','w:gz') as t:
    for n in ['identity.json','collect.py','archive-owned.py','run.sh','prospective.json']:t.add(b/n,arcname=n)
with tarfile.open(b/'payload.tgz') as t:unpacked=sum(m.size for m in t.getmembers())
priorConfig=json.loads((old/'config.json').read_text(encoding='utf-8'))
config=dict(root=remote,sourceRoot='/home/lokad/lython-bench-checks/protected-activation-b756-20261114',catalogRoot='/home/lokad/lython-bench-checks/protected-activation-b756-20261114',unit=unit,identity=identity,pythonWorkerSHA256=priorConfig['pythonWorkerSHA256'],payloadBytes=(b/'payload.tgz').stat().st_size,payloadSHA256=sha(b/'payload.tgz'),unpackedBytes=unpacked)
s=(old/'launch-command.py').read_text(encoding='utf-8');a=s.index('config=');end=s.index('\nbase=',a);s=s[:a]+'config='+repr(config)+s[end:]
s=s.replace('lython-b747-fixtures','lython-b757-fixtures').replace('RuntimeMaxSec=480','RuntimeMaxSec=240')
ast.parse(s);(b/'launch-command.py').write_text(s,encoding='utf-8',newline='\n')
(b/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(r/'b756/launch.py').read_text(encoding='utf-8').replace("r.parent.parent/'protected-helper-r367/terminal-status.json'", "r.parent/'b756/terminal-status.json'").replace('seconds=360','seconds=180').replace('ownerSeconds=420','ownerSeconds=240')
ast.parse(s);(b/'launch.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared B757targetedCPythoncheckpoint; no remote action.',flush=True)
