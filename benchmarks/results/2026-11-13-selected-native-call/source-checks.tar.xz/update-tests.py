from pathlib import Path
import re
for p in Path('tests/Lokad.Lython.Tests').glob('*.cs'):
    s=p.read_text(encoding='utf-8')
    if 'TryStartNativeCall' not in s:continue
    s=re.sub(r'Assert\.True\((function\.TryStartNativeCall\(.*?\))\);',r'\1;',s,flags=re.S)
    s=s.replace('TryStartNativeCall','StartNativeCall')
    p.write_text(s,encoding='utf-8')
