using Lokad.Lython.Frontend;
using System.Text.Json;
using System.Security.Cryptography;

using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var rows = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var source = item.GetProperty("source").GetString()!;
    var parsed = LythonFrontend.Compile(source);
    if (parsed.Script is null) throw new Exception("Invalid maintained source");
    var root = ExecutableScript.Compile(LoweredScript.Lower(parsed.Script!)).EntryPoint;
    var codes = new List<object>();
    void Visit(ExecutableCodeObject code)
    {
        codes.Add(new {code.Name, code.FirstTemporarySlot, code.OperandCapacity,
            code.ValueStorageCapacity, code.PatternStorageStart, code.PatternStorageCount,
            code.CanInlineInstructions, code.RequiresLocalVariableMirroring,
            calls = code.Instructions.Select((i,pc) => (i,pc)).Where(x => x.i.OpCode == ExecutableOpCode.Call).Select(x => new {
                x.pc, x.i.InputStart, x.i.ResultSlot, x.i.LiveExtent,
                freeOperandTail = code.PatternStorageStart-x.i.InputStart,
                argumentCount = code.CallSites[x.i.CallSiteIndex].ArgumentCount,
                receiver = code.CallSites[x.i.CallSiteIndex].HasReceiver,
                span = code.CallSites[x.i.CallSiteIndex].CallSpan}),
            instructions=code.Instructions.Select((i,pc)=>new{pc,op=i.OpCode.ToString(),i.InputStart,i.SecondInput,i.ResultSlot,i.LiveExtent,i.HasLocalResult})});
        foreach(var function in code.Functions) Visit(function.CodeObject);
    }
    Visit(root);
    rows.Add(new {id=item.GetProperty("id").GetString(), source, codes});
}
Console.WriteLine(JsonSerializer.Serialize(new {
    sourceGateOnly=true, noGuestExecution=true,
    coreSHA256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(LythonFrontend).Assembly.Location))).ToLowerInvariant(),rows},new JsonSerializerOptions{WriteIndented=true}));
