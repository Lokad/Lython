from pathlib import Path
import ast,subprocess
r=Path(__file__).parent;old=r.parent/'text-window-capacity-r314'
code=(old/'inspect-retirement.py').read_text(encoding='utf-8');a=code.index('specs=');b=code.index('\nproofs=',a)
code=code[:a]+"specs=[('window-capacity-rough-b678-20261113/candidate/Lokad.Lython.dll','benchmarks/results/2026-11-13-text-window-capacity/rough/source-checks.tar.xz',r.parent/'text-window-capacity-r314/rough/candidate-core.dll')]"+code[b:]
code=code.replace('prior8f','withdrawn cf capacity')
ast.parse(code);(r/'inspect-withdrawn-vm.py').write_text(code,encoding='utf-8')
subprocess.run(['python','-X','utf8',str(r/'inspect-withdrawn-vm.py')],check=True)
