from pathlib import Path
import ast,base64,datetime,json,subprocess
r=Path(__file__).parent;config=json.loads((r/'config.json').read_text(encoding='utf-8'))
code='''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot'])
assert root.parent==base and source.parent==base and not root.exists()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(source/'guest-fixtures').exists()
 users=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True)
 assert users.returncode==1,users.stdout
 assert digest(source/'candidate/Lokad.Lython.dll')==config['sourceCoreSHA256']
 for name,sha in config['identity']['auxiliaryFiles'].items():assert digest(source/'candidate'/name)==sha
 for row in config['retireArchives']:
  p=base/row['path'];s=p.lstat()
  assert p.resolve(strict=True)==p and p.is_relative_to(base)and p.is_file()and s.st_uid==os.getuid()and s.st_nlink==1 and s.st_size==row['bytes']and digest(p)==row['sha256']
 for row in config['retireArchives']:
  p=base/row['path'];assert digest(p)==row['sha256'];p.unlink()
 before=shutil.disk_usage(base).free
 assert before+sum(p['allocatedBytes']for p in config['retire'])>252*1024*1024+config['unpackedBytes']+2*1024*1024
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 # Retire only exact, obsolete VM working copies whose bytes are already
 # independently verified in tracked canonical archives; current91 and canonical older snapshots stay.
 for row in config['retire']:
  actual=[]
  for folder,dirs,files in os.walk(base,followlinks=False):
   for name in files:
    p=Path(folder)/name;s=p.lstat()
    if(s.st_dev,s.st_ino)==(row['device'],row['inode']):actual.append(str(p.relative_to(base)))
  assert sorted(actual)==sorted(row['aliases'])and len(actual)==row['links'] and row['links'] >= 1
  for p in [base/a for a in row['aliases']]:
   s=p.lstat();assert p.resolve(strict=True)==p and p.is_relative_to(base)and p.is_file()and s.st_uid==os.getuid()
   assert(s.st_dev,s.st_ino,s.st_nlink,s.st_size)==(row['device'],row['inode'],row['links'],row['bytes'])and digest(p)==row['sha256']==row['canonical']['sha256']
 for row in config['retire']:
  for i,a in enumerate(row['aliases']):
   p=base/a;s=p.lstat();assert(s.st_dev,s.st_ino,s.st_nlink,s.st_size)==(row['device'],row['inode'],row['links']-i,row['bytes'])and digest(p)==row['sha256'];p.unlink()
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as archive:archive.extractall(root,filter='data')
 os.link(source/'source-identity.json',root/'reference-source-identity.json')
 os.link(source/'cpython-worker.py',root/'cpython-worker.py')
 assert digest(root/'reference-source-identity.json')==config['identity']['referenceSourceIdentitySHA256']
 catalogSource=Path(config['catalogRoot']);assert catalogSource.parent==base
 os.link(catalogSource/'representative.json',root/'representative.json')
 assert digest(root/'current-core.dll')==config['identity']['coreSHA256']['candidate']
 for role in ['reference','candidate']:
  shutil.copytree(source/'candidate',root/role,copy_function=os.link,ignore=shutil.ignore_patterns('Lokad.Lython.dll'))
  os.link(source/'candidate/Lokad.Lython.dll'if role=='reference'else root/'current-core.dll',root/role/'Lokad.Lython.dll')
  assert digest(root/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]
  for name,sha in config['identity']['auxiliaryFiles'].items():assert digest(root/role/name)==sha
 assert digest(root/'representative.json')==config['identity']['catalogSHA256']
 assert digest(root/'source-identity.json')==config['identity']['sourceIdentitySHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 (root/'space-preflight.json').write_text(json.dumps(dict(freshIdleLease=True,beforeFreeBytes=before,afterStagingFreeBytes=shutil.disk_usage(base).free,osFloorMiB=240,evidenceHeadroomMiB=12,additionalArchiveHeadroomMiB=2,retired=config['retire']+config['retireArchives']),indent=2)+'\\n')
 assert shutil.disk_usage(base).free>252*1024*1024+2*1024*1024
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b680-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=360','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live;print(live)
'''.replace('CONFIG',repr(config))
ast.parse(code);(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
encoded=base64.b64encode(code.encode()).decode();command="python3 -c 'import base64;exec(base64.b64decode(\""+encoded+"\"))'"
done=subprocess.run(ssh+[command],input=(r/'payload.tgz').read_bytes(),capture_output=True)
(r/'launch.log').write_bytes(done.stdout+done.stderr);print((done.stdout+done.stderr).decode(),flush=True);assert done.returncode==0
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=240)).isoformat(),ownerSeconds=360,stopSeconds=30,observationSeconds=240),indent=2)+'\n',encoding='utf-8',newline='\n')
