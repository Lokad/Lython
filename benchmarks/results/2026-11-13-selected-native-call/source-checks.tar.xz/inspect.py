from pathlib import Path
import os,subprocess,json
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';'+env['PATH']
p=r/'frozen-inspect-build.log';assert not p.exists()
with p.open('w',encoding='utf-8')as log:done=subprocess.run([str(sdk/'dotnet.exe'),'build',str(r/'inspect/inspect.csproj'),'-c','Release','--disable-build-servers','--no-restore','-m:1'],env=env,stdout=log,stderr=subprocess.STDOUT)
print('build',done.returncode,p.read_text(encoding='utf-8')[-1400:],flush=True);assert done.returncode==0
with (r/'compiled-facts.json').open('w',encoding='utf-8')as out:subprocess.run([str(sdk/'dotnet.exe'),str(r/'inspect/bin/Release/net11.0/Lokad.Lython.WhiteBox.Tests.dll'),'.git/agent-notes/review-20261031/text-window-capacity-r314/rough/b678/retrieved/representative.json'],env=env,stdout=out,check=True)
data=json.loads((r/'compiled-facts.json').read_text(encoding='utf-8'))
for row in data['rows']:
 print(row['id'],[(c['Name'],c['ValueStorageCapacity'],[(x['pc'],x['freeOperandTail'])for x in c['calls']])for c in row['codes']],flush=True)
