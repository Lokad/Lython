from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;prior=r.parent/'integer-chain-r311';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for kind in ['internal','public']:
 text=(r/(kind+'-test.log')).read_text(encoding='utf-8');assert 'Test Run Successful.'in text and 'Failed:'not in text
old=json.loads((prior/'candidate-identity.json').read_text(encoding='utf-8'));sources={p:sha(p)for p in old['sources']}
changed=[p for p in sources if sources[p]!=old['sources'][p]]
assert set(changed)=={'src/Lokad.Lython/Runtime/PyExecutableFunction.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.Invoke.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs'},changed
for role in ['reference','candidate']:
 shutil.copytree(prior/'candidate',r/role,copy_function=os.link)
 if role=='candidate':
  (r/role/'Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/role/'Lokad.Lython.dll')
shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(old,head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),description='R315 selected native call completes/transfers without a decline result; body managed-stack validation without duplicate logical nesting charge; no workspace borrowing or arena',referenceSHA256=sha(r/'reference/Lokad.Lython.dll'),coreSHA256=sha(r/'candidate-core.dll'),sources=sources)
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for p in sources:a.add(p,arcname=p)
shutil.copyfile(prior/'catalog.json',r/'catalog.json')
print(identity['coreSHA256'],len(sources),'inputs, selected start/body admission deletion; not yet promoted.',flush=True)
