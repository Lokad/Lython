from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-13-selected-native-call');out.mkdir(exist_ok=True)
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['sources'].items())
receipt=json.loads((r/'b680/archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined'];assert hashlib.sha256((r/'b680/observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for name,count in [('internal',186),('public',440)]:
 s=(r/(name+'-test.log')).read_text(encoding='utf-8');assert 'Test Run Successful.'in s and f'Passed: {count}'in s
for name in ['summary.json','observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(r/'b680'/name,out/name)
with tarfile.open(out/'source-checks.tar.xz','w:xz')as a:
 for p in r.iterdir():
  if p.is_file()and(p.suffix in ['.py','.json','.log']or p.name in ['candidate-core.dll','candidate-sources.tar.xz']):a.add(p,arcname=p.name)
 for p in (r/'inspect').glob('*'):
  if p.is_file():a.add(p,arcname='inspect/'+p.name)
 for p in (r/'b680').iterdir():
  if p.is_file()and p.name not in ['observations.tgz','payload.tgz']:a.add(p,arcname='b680/'+p.name)
 for name in ['ComposedNativeCallTests.cs','FormattedStringExecutableTests.cs','NativeIntegerChainTests.cs','NativeTupleReturnTests.cs','SimpleFunctionExecutionBoundaryTests.cs']:
  p=Path('tests/Lokad.Lython.Tests')/name;a.add(p,arcname='tests/'+name)
print('R315 exact485 source/bits,186internal/440public, all B680 raw/adverse controls archived.',flush=True)
