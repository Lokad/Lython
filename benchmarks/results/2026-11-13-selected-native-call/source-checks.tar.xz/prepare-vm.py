from pathlib import Path
import ast,subprocess
r=Path(__file__).parent;old=r.parent/'text-window-capacity-r314'
code=(old/'prepare-vm.py').read_text(encoding='utf-8')
code=code.replace("out=r/'b676'","out=r/'b680'").replace('window-capacity-b676-20261113','selected-call-b680-20261113').replace('lython-b676-window-capacity-20261113','lython-b680-selected-call-20261113').replace("replace('b669','b676')","replace('b669','b680')")
code=code.replace('decoded-window header capacity','selected native call/body admission').replace('Window header capacity','Selected native call/body admission').replace('Complete file-search/captured-text/JSON warm, invoice/report controls; no new CPython ratio','Complete search/invoice/JSON warm with captured/report controls; no new CPython ratio')
code=code.replace("assert len(retire)==1 and retire[0]['sha256']=='8f69261d79a3e32a563bb374d1ad9bc49b980b1b9884fbf697fea02996068aa2'","assert len(retire)==1 and retire[0]['sha256']=='cf762db110633b45d329da0ff7cf548b6264e92880f00dae7daa2a31e91abb26'")
a=code.index("config['retireArchives']=[]");b=code.index("(out/'config.json')",a);code=code[:a]+"config['retireArchives']=[]\n"+code[b:]
code=code.replace('B676','B680').replace('prior8f','withdrawn cf capacity').replace("replace('B668','B676')","replace('B668','B680')")
ast.parse(code);(r/'prepare-b680.py').write_text(code,encoding='utf-8')
subprocess.run(['python','-X','utf8',str(r/'prepare-b680.py')],check=True)
