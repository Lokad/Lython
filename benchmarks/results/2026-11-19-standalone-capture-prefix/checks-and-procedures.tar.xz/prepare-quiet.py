import ast
import json
from pathlib import Path

lab=Path(__file__).resolve().parent
old=lab.parent/'prepared-integer-prefix-r671'
stage=(old/'stage-quiet.py').read_text(encoding='utf-8')
stage=stage.replace('retained-defaults-cpython-b1102','token-source-cpython-b1106')
stage=stage.replace('R671 compiler-prepared machine integer continuations','R675 standalone captured locals in deferred invocations')
stage=stage.replace('prepared-integer-prefix-b1103','standalone-capture-prefix-b1107')
stage=stage.replace('b1103-prepared-integer-prefix','b1107-standalone-capture-prefix').replace('b1103-fixtures','b1107-fixtures')
stage=stage.replace('Compiler-prepared integer prefix source pair','Standalone capture prefix source pair')
stage=stage.replace('for role in ("candidate",):','for role in ("reference", "candidate"):')
stage=stage.replace('"candidate/" + core]', '"reference/" + core, "candidate/" + core]')
stage=stage.replace("assert source_files == images['reference']", "assert sha(quiet / 'reference' / core) == images['reference'][core]")
cases=json.loads((lab/'catalog.json').read_text(encoding='utf-8'))['cases']
siblings=next(c['id'] for c in cases if 'nonlocal' in c['id'])
jobs=[
    ('scripts.captured-rule-closures','warm'),
    (siblings,'warm'),
    ('scripts.rule-default-closures','warm'),
    ('scripts.annotated-rule-closures','warm'),
    ('scripts.captured-rule-closures','compile-run'),
    ('scripts.report-forwarding.expanded','warm'),
    ('calls.defaults.computed','warm-async'),
]
a,b=stage.index('        jobs = '),stage.index('        source=source[:a]')
stage=stage[:a]+"        jobs = "+repr(jobs)+"\n"+stage[b:]
ast.parse(stage)
(lab/'stage-quiet.py').write_text(stage,encoding='utf-8',newline='\n')
