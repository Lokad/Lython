import ast
import json
from pathlib import Path

lab = Path(__file__).resolve().parent
old = lab.parent / 'token-source-transport-r673'
read = lambda p: p.read_text(encoding='utf-8-sig')
load = lambda p: json.loads(read(p))
def write(name, data):
    if name.endswith('.py'):
        ast.parse(data)
    (lab/name).write_text(data,encoding='utf-8',newline='\n')
catalog = load(lab.parent/'retained-defaults-cpython-b1102/representative.json')
wanted = {'scripts.rule-default-closures','scripts.annotated-rule-closures',
          'scripts.captured-rule-closures','scripts.report-forwarding.expanded'}
catalog['cases'] = [c for c in catalog['cases'] if c['id'] in wanted]
siblings = load(lab.parent/'compiled-binding-cpython-r656/representative.json')
retained = [c for c in siblings['cases'] if 'nonlocal' in c['id']]
assert len(retained)==1, [c['id'] for c in siblings['cases']]
catalog['cases'].extend(retained)
extra = load(lab.parent/'positional-default-slots-r669/catalog.json')
catalog['cases'].extend([c for c in extra['cases'] if c['id']=='calls.defaults.computed'])
assert len(catalog['cases'])==6
write('catalog.json',json.dumps(catalog,indent=2,ensure_ascii=False)+'\n')
freeze=read(old/'freeze-and-verify.py').replace('token-source-transport-r673','standalone-capture-prefix-r675')
freeze=freeze.replace("'retained-defaults-cpython-b1102'","'token-source-cpython-b1106'")
freeze=freeze.replace("'bc65698dd'","'2166c7295'").replace("'80cbf4988'","'34072680e'")
freeze=freeze.replace("assert manifest['imageSource']==ref","assert manifest['sourceRevision'].startswith('27f68744b')")
freeze=freeze.replace("if role=='candidate' and name==core:\n            origin=lab/'build-win/bin/Lokad.Lython/release_net11.0'/name",
                      "if name==core:\n            build = 'build-win' if role=='candidate' else 'build-reference'\n            origin=lab/build/'bin/Lokad.Lython/release_net11.0'/name")
freeze=freeze.replace('== 5','== 6').replace('all five','all six')
assert "build = 'build-win'" in freeze
freeze+="\nassert images['reference'][core] != images['candidate'][core]\n"
write('freeze-and-verify.py',freeze)
