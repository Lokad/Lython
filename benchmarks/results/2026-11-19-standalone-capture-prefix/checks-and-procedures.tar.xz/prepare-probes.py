from pathlib import Path
import ast

lab=Path(__file__).resolve().parent
source=(lab.parent/'token-source-transport-r673/compare-probes.py').read_text(encoding='utf-8-sig')
a=source.index('source = [')
b=source.index("(lab/'probes.json')",a)
cases=[
 """def make(x):
 shared=[x]
 def update(v):
  shared.append(v)
  return shared
 def reader():
  return lambda: shared
 return update, reader()
write, read = make(3)
other, view = make(9)
print(write(1) is read(), other(2) is view(), read(), view())
""",
 """def make(value):
 def store(next):
  nonlocal value
  value=next
 def mid():
  return lambda: value
 return store,mid()
store,read=make(0)
store(123)
print(read())
""",
 """def make(x,y):
 def build():
  return lambda:(x,y)
 return build
print(make(2,3)()())
""",
 """def make(x):
 def read():return x
 return read, lambda z:x+z
a,b=make(8)
print(a(),b(4),a.__qualname__,b.__qualname__)
""",
 """def make(x):
 f=lambda:x
 del x
 return f
try:print(make(3)())
except NameError as e:print(type(e).__name__, str(e))
""",
 """def make():
 def read():return value
 try: print(read())
 except NameError:print('missing')
 value=3
 return read
print(make()())
""",
 """def make(x):
 def read():return x
 def live():return locals()
 return read,live
r,l=make(3)
print(r(),l())
""",
 """def make(x):
 def item():return x
 return [lambda i=i: (item(),i) for i in range(3)]
print([f() for f in make(6)])
""",
 """def make(x):
 def read():return x
 class C:
  def run(self):
   return read(), __class__.__name__
 return C
print(make(6)().run())
""",
 """def make(x):
 def read():return x
 yield read
 x=x+1
 yield read
values=make(5)
first=next(values)
print(first(), next(values) is first, first())
""",
 """def make(x):
 def alter(y=1,*,amount=2):
  nonlocal x
  x += y + amount
  return x
 return alter
f=make(4)
print(f(), f(amount=3), f(y=2,amount=4))
""",
 """def make(x):
 def later()->int:
  return x
 return later
f=make(3)
print(f(),list(f.__annotations__))
""",
 """def make(x):
 def claim():return x
 raise LookupError(claim())
make(27)
""",
 """def make(x):
 def item():return x
 return item
last=make(1)
for i in range(100): make(i)
print(last() is last(), last())
""",
]
source=source[:a]+'source = '+repr(cases)+'\n'+source[b:]
ast.parse(source)
(lab/'compare-probes.py').write_text(source,encoding='utf-8',newline='\n')
