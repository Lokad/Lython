import ast
import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile

lab = Path(__file__).resolve().parent
prior = lab.parent / "token-source-cpython-b1106"
template = lab.parent / "private-keyword-mapping-r660"
previous = template / "quiet"
quiet = lab / "quiet"
def read(path):
    return path.read_text(encoding="utf-8-sig")
def load(path):
    return json.loads(read(path))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value):
    if path.suffix == ".py":
        ast.parse(value)
    path.write_text(value, encoding="utf-8", newline="\n")
def save(path, value):
    write(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")

old = load(prior / "config.json")
template_config = load(previous / "config.json")
donor_archive=load(prior/"archive-receipt.json")
assert donor_archive["complete"] and donor_archive["archivedAndVerifiedUnderLease"]
minimum_headroom = 174 * 1024 * 1024
pair = load(lab / "frozen-identity.json")
catalog = lab / "catalog.json"
images = pair["images"]
source_files = old["identity"]["imageFiles"]["candidate"]
core = "Lokad.Lython.dll"
assert pair["casesSHA256"] == sha(catalog)
for role, files in images.items():
    assert len(files) == 32 and files == source_files | {core: files[core]}
    assert {name: sha(lab / "frozen" / role / name) for name in files} == files
    verified = load(lab / f"{role}-verify.json")
    assert verified["state"] == "Completed" and verified["catalogSha256"] == sha(catalog)

quiet.mkdir(exist_ok=True)
for role in ("reference", "candidate"):
    image = quiet / role
    image.mkdir(exist_ok=True)
    shutil.copyfile(lab / "frozen" / role / core, image / core)
shutil.copyfile(catalog, quiet / "representative.json")
identity = dict(sourceRevision=pair["referenceCommit"] + " versus " + pair["candidateCommit"],
    purpose="R675 standalone captured locals in deferred invocations", imageFiles=images,
    catalogSHA256=sha(catalog), normalAdapterPin="0.4.0",
    coreSHA256={label: images[role][core] for role in images for label in (role, role + "-control")})
save(quiet / "identity.json", identity)

root = "/home/lokad/lython-bench-checks/standalone-capture-prefix-b1107-20261119"
unit = "lython-b1107-standalone-capture-prefix-20261119"
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    source = read(previous / name).replace(template_config["root"], root)
    source = source.replace("Completed machine integer prefix", "Completed machine integer prefix source pair")
    if name == "collect.py":
        a,b=source.index("\njobs = "),source.index("\nassert len(jobs)")
        jobs = [('scripts.captured-rule-closures', 'warm'), ('scripts.retained-nonlocal-factories', 'warm'), ('scripts.rule-default-closures', 'warm'), ('scripts.annotated-rule-closures', 'warm'), ('scripts.captured-rule-closures', 'compile-run'), ('scripts.report-forwarding.expanded', 'warm'), ('calls.defaults.computed', 'warm-async')]
        source=source[:a]+"\njobs = "+repr(jobs)+source[b:]
    source = source.replace("len(jobs)==6","len(jobs)==7").replace("len(raw['jobs'])==6","len(raw['jobs'])==7").replace("jobs=6,","jobs=7,").replace("['jobs']==6","['jobs']==7")
    if name == "collect.py":
        source = source.replace("accumulate8seconds", "accumulate10seconds").replace("warmupSeconds=8", "warmupSeconds=10")
        source = source.replace("min(warmed)<8", "min(warmed)<10").replace("warmed[i]>=8", "warmed[i]>=10")
        source = source.replace("Deferred factory frame source pair", "Standalone capture prefix source pair")
    if name == "retrieve.py":
        source = source.replace("Deferred factory frame source pair", "Standalone capture prefix source pair")
    if name == "archive-owned.py":
        source=source.replace(str(192*1024*1024), str(minimum_headroom))
    write(quiet / name, source)
write(lab / "launch-quiet.py", read(template / "launch-quiet.py").replace(
    "Separated default and explicit trim scan", "Completed machine integer prefix").replace("323","398"))
write(lab / "summarize-quiet.py", read(template / "summarize-quiet.py").replace("==6","==7"))
parts = ["collect.py", "archive-owned.py", "run.sh", "identity.json", "representative.json",
         "reference/" + core, "candidate/" + core]
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as archive:
    for part in parts:
        archive.add(quiet / part, arcname=part)
expanded = sum((quiet / part).stat().st_size for part in parts)
archive_headroom = 1792 * 1024 # B1063 used 651264 bytes after staging.
needed = minimum_headroom + expanded + archive_headroom
space = load(lab / "quiet-space.json")
available = space["freeBytes"]
selected = []
for proof in sorted(space["replicas"], key=lambda item: -item["bytes"]):
    if available > needed + 49152:
        break
    if proof["sha256"] == donor_archive["archiveSHA256"]:
        continue
    assert proof["committedBlobVerified"]
    available += proof["bytes"]
    selected.append(proof)
save(lab / "preflight.json", dict(available=available, need=needed, withoutRetirement=space["freeBytes"], selected=selected))
assert available > needed, (available, needed)

config = dict(root=root, unit=unit, source=old["root"], sourceRole="candidate",
              sourceFiles=source_files, sourceCatalogSHA256=old["catalogSHA256"],
              catalogSHA256=sha(catalog), identity=identity, retireGroups=selected, donorArchiveSHA256=donor_archive["archiveSHA256"],
              payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload), unpackedBytes=expanded)
save(quiet / "config.json", config)
launcher = read(lab.parent / "prepared-compiler-bindings-r627" / "quiet" / "remote-launch.py")
a, b = launcher.index("\nc=") + 1, launcher.index("\nb=Path(")
launcher = launcher[:a] + "c=" + repr(config) + launcher[b:]
launcher = re.sub(r"lython-b[0-9]+-fixtures", "lython-b1107-fixtures", launcher)
launcher = launcher.replace(str(200*1024*1024), str(minimum_headroom)).replace("+2097152,", f"+{archive_headroom},")
write(quiet / "remote-launch.py", launcher)
print("Verified both full images and the six-case, seven-job plan. Staging headroom", available - needed, "bytes.")

collector = read(quiet / 'collect.py')
archive = read(quiet / 'archive-owned.py')
assert 'assert len(jobs)==7' in collector
assert "len(raw['jobs'])==7" in archive and 'jobs=7,' in archive
assert "['jobs']==7" in read(quiet / 'retrieve.py')
assert "len(raw['jobs'])==7" in read(lab / 'summarize-quiet.py')

staged = load(quiet / 'config.json')
assert sha(quiet / 'candidate' / core) == images['candidate'][core]
assert staged['sourceFiles'] == source_files and staged['sourceRole'] == 'candidate'
assert sha(quiet / 'reference' / core) == images['reference'][core]
assert 'timedelta(seconds=398)' in read(lab / 'launch-quiet.py')

assert 'warmupSeconds=10' in collector and 'warmed[i]>=10' in collector
assert 'RuntimeMaxSec=540' in read(quiet / 'remote-launch.py')
assert len({case for case, lane in ast.literal_eval(re.search(r'^jobs = (.*)$', collector, re.M).group(1))}) == 6
