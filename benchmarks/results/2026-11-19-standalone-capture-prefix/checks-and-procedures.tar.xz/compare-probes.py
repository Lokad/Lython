from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
sdk = Path.home()/'.dotnet11'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ['PATH'])
source = ['def make(x):\n shared=[x]\n def update(v):\n  shared.append(v)\n  return shared\n def reader():\n  return lambda: shared\n return update, reader()\nwrite, read = make(3)\nother, view = make(9)\nprint(write(1) is read(), other(2) is view(), read(), view())\n', 'def make(value):\n def store(next):\n  nonlocal value\n  value=next\n def mid():\n  return lambda: value\n return store,mid()\nstore,read=make(0)\nstore(123)\nprint(read())\n', 'def make(x,y):\n def build():\n  return lambda:(x,y)\n return build\nprint(make(2,3)()())\n', 'def make(x):\n def read():return x\n return read, lambda z:x+z\na,b=make(8)\nprint(a(),b(4),a.__qualname__,b.__qualname__)\n', 'def make(x):\n f=lambda:x\n del x\n return f\ntry:print(make(3)())\nexcept NameError as e:print(type(e).__name__, str(e))\n', "def make():\n def read():return value\n try: print(read())\n except NameError:print('missing')\n value=3\n return read\nprint(make()())\n", 'def make(x):\n def read():return x\n def live():return locals()\n return read,live\nr,l=make(3)\nprint(r(),l())\n', 'def make(x):\n def item():return x\n return [lambda i=i: (item(),i) for i in range(3)]\nprint([f() for f in make(6)])\n', 'def make(x):\n def read():return x\n class C:\n  def run(self):\n   return read(), __class__.__name__\n return C\nprint(make(6)().run())\n', 'def make(x):\n def read():return x\n yield read\n x=x+1\n yield read\nvalues=make(5)\nfirst=next(values)\nprint(first(), next(values) is first, first())\n', 'def make(x):\n def alter(y=1,*,amount=2):\n  nonlocal x\n  x += y + amount\n  return x\n return alter\nf=make(4)\nprint(f(), f(amount=3), f(y=2,amount=4))\n', 'def make(x):\n def later()->int:\n  return x\n return later\nf=make(3)\nprint(f(),list(f.__annotations__))\n', 'def make(x):\n def claim():return x\n raise LookupError(claim())\nmake(27)\n', 'def make(x):\n def item():return x\n return item\nlast=make(1)\nfor i in range(100): make(i)\nprint(last() is last(), last())\n']
(lab/'probes.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
inputs = (lab/'probes.json').read_bytes()
driver = Path('tools/LythonProbe/bin/Release/net11.0')
identity = json.loads((lab/'frozen-identity.json').read_text(encoding='utf-8'))['images']
work = lab/'probe'
work.mkdir(exist_ok=True)
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def all_hashes(path):
    return {entry.name:digest(entry) for entry in path.iterdir() if entry.is_file()}
matches=[]
for role in ('reference','candidate'):
    image = work/role
    image.mkdir(exist_ok=True)
    for entry in driver.iterdir():
        if entry.is_file() and entry.suffix != '.pdb': shutil.copyfile(entry,image/entry.name)
    for name in ['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']:
        shutil.copyfile(lab/'frozen'/role/name, image/name)
        assert digest(image/name)==identity[role][name]
common=all_hashes(work/'reference')
assert common | {'Lokad.Lython.dll':identity['candidate']['Lokad.Lython.dll']} == all_hashes(work/'candidate')
for mode in ('sync','async'):
    results=[]
    for role in ('reference','candidate'):
        args=[sdk/'dotnet.exe',work/role/'LythonProbe.dll','--batch-json']+(['--async'] if mode=='async' else [])
        completed=subprocess.run(args,env=env,input=inputs,capture_output=True,timeout=60)
        (lab/f'probe-{role}-{mode}.jsonl').write_bytes(completed.stdout)
        (lab/f'probe-{role}-{mode}.stderr').write_bytes(completed.stderr)
        records=[json.loads(line) for line in completed.stdout.decode('utf-8-sig').splitlines()]
        assert len(records)==len(source), (role, mode, completed.returncode, completed.stderr)
        results.append([record['Lython'] for record in records])
    assert results[0]==results[1], [i for i,pair in enumerate(zip(*results)) if pair[0]!=pair[1]]
    matches.append(dict(mode=mode, matching=len(source)))
(lab/'probe-summary.json').write_text(json.dumps(dict(results=matches, referenceImage=common),indent=2)+'\n',encoding='utf-8',newline='\n')
print(matches)
