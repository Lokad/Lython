from pathlib import Path
import gzip
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
quiet=lab/'quiet'
out=Path('benchmarks/results/2026-11-20-frame-default-refinement')
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()

terminal=read(quiet/'terminal-status.json')
receipt=read(quiet/'archive-receipt.json')
assert terminal['exitCode']=='0' and terminal['receipt']==receipt and not terminal['live']
assert not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert all(receipt[name] for name in ('complete','quietBeforeAndAfter','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert receipt['jobs']==4 and receipt['archiveSHA256']==sha(quiet/'observations.tgz')
pair=read(lab/'frozen-identity.json')
assert pair['referenceCommit'].startswith('a5214a158') and pair['candidateCommit'].startswith('cf44cfc31')
assert pair['casesSHA256']==sha(lab/'catalog.json')
for role,files in pair['images'].items():
    assert len(files)==32 and {name:sha(lab/'frozen'/role/name) for name in files}==files
    verified=read(lab/(role+'-verify.json'))
    assert verified['state']=='Completed' and verified['catalogSha256']==pair['casesSHA256']
    assert all(row['sharedBudgetBaselineRestored'] for row in read(lab/(role+'-allocation.json'))['rows'])
raw=read(quiet/'retrieved/confirmation/confirmation.json')
assert raw['complete'] and raw['warmupSeconds']>=10 and len(raw['jobs'])==4
cases={case['id']:case for case in read(lab/'catalog.json')['cases']}
batches=0
for lane in raw['jobs']:
    assert lane['workersJoinedAndFixturesRemoved']
    case=cases[lane['case']]
    for label,worker in lane['identities'].items():
        files=pair['images'][label.split('-',1)[0]]
        libraries={Path(lib['path']).name:lib['sha256'].lower() for lib in worker['libraries']}
        assert libraries['Lokad.Lython.dll']==files['Lokad.Lython.dll']
        assert all(libraries[name]==files[name] for name in libraries.keys() & files.keys())
    for sample in lane['samples']:
        response=sample['response']
        assert response['status']=='Completed' and response['completedInvocations']>0
        assert all(response[key]==case[key] for key in ('sourceSha256','fixtureSha256','expectedOutputSha256'))
        assert response['actualOutputSha256']==case['expectedOutputSha256']
        assert response.get('actualFilesSha256')==case.get('expectedFilesSha256')
        batches+=1
assert len(cases)==4 and batches==80
windows=lab.parent/'frame-default-storage/native-prefix-refinement-windows.log'
assert 'Passed:   131' in windows.read_text(encoding='utf-8-sig')
assert 'Passed:   131' in (lab/'ubuntu-whitebox.log').read_text(encoding='utf-8-sig')

out.mkdir(exist_ok=True)
for name in ('archive-receipt.json','terminal-status.json','observations.tgz'):
    shutil.copyfile(quiet/name,out/name)
summary=read(lab/'quiet-summary.json')
summary.update(reference=pair['referenceCommit'],candidate=pair['candidateCommit'],
               cores={role:files['Lokad.Lython.dll'] for role,files in pair['images'].items()},archiveSHA256=receipt['archiveSHA256'])
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
# The exact reference core is already archived in B1163.
reference_core=Path('benchmarks/results/2026-11-20-owned-annotation-values/measured-core.dll.gz')
assert hashlib.sha256(gzip.decompress(reference_core.read_bytes())).hexdigest()==pair['images']['reference']['Lokad.Lython.dll']
(out/'measured-core.dll.gz').write_bytes(gzip.compress((lab/'frozen/candidate/Lokad.Lython.dll').read_bytes(),mtime=0))
with tarfile.open(out/'checks-and-procedures.tar.xz','w:xz',preset=6) as archive:
    for name in ('archive-evidence.py','freeze-and-verify.py','stage-quiet.py','prove-quiet-space.py',
                 'quiet-space.json','launch-quiet.py','summarize-quiet.py','measured-source.patch','catalog.json','frozen-identity.json',
                 'freeze.log','retrieval.log','reference-verify.json','candidate-verify.json','reference-allocation.json',
                 'candidate-allocation.json','candidate-build.log','test-ubuntu.sh','stage.log','ubuntu-whitebox.log'):
        archive.add(lab/name,arcname=name)
    archive.add(windows,arcname='windows-whitebox.log')
    for name in ('identity.json','config.json','collect.py','archive-owned.py','run.sh','remote-launch.py','retrieve.py','launch.log','observe-not-before.json'):
        archive.add(quiet/name,arcname='quiet/'+name)
print('Verified both complete images, four CPython goldens and all 80 timed batches.')
