set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Default|FullyQualifiedName~LambdaExecutable|FullyQualifiedName~SynchronousGeneratorAdvance|FullyQualifiedName~OrdinaryFunctionTransport|FullyQualifiedName~NativeReturn)&Category!=Stress'
