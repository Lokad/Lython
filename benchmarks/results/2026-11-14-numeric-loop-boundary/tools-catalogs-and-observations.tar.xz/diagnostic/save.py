from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-14-numeric-loop-boundary');out.mkdir(exist_ok=False)
summary=json.loads((r/'summary.json').read_text(encoding='utf-8'));profile=json.loads((r/'b730/attribution-range-outside.json').read_text(encoding='utf-8'))
assert summary['complete']and profile['samples']==1033 and profile['ambiguousLeafSamples']==0
assert json.loads((r/'terminal-status.json').read_text(encoding='utf-8'))['receipt']['complete']and json.loads((r/'b730/terminal-status.json').read_text(encoding='utf-8'))['receipt']['complete']
inside,outside=[v['medianMilliseconds']for v in summary['timing']]
effect=sorted(100*(outside[a]/inside[b]-1)for a in ['candidate','candidate-control']for b in ['candidate','candidate-control'])
decision=dict(status='Source gate complete; general native reentry unselected as main redesign, not permanently banned.',source='Fully qualifiedf5817a15/frozen9cfb7d5b, all581production inputs identical at b5d97f45 before R357 prototype.',diagnosticVariantChangePercent=effect,diagnosticOnly=True,localAllocation='~7.52MB/invocation both variants, five counters after warmup; shared-budget baseline restored; no CPU inference.',owningProfile=dict(samples=1033,unknown=65,ambiguous=0,nearestExactAddition=505,nativeBodyLeaves=191,sameProcessTier1Bytes=6619),selected='R357 share existing checked machine-integer kernel with individual exact arithmetic. Eliminate general BigInteger limb arithmetic for int64 operands/results before inventing a new value representation. Existing published BigInteger identity/aliases and major preflight remain.',remaining='Boxed integer publication/range iteration/native dispatch still need evidence and coherent ownership/identity contract; R357 is not completion of whole-script performance. No data/source variant establishes runtime source-pair speedup.',failedConditions=['First staging identity accidentally included local-only Allocation helper dependencies; remote failed before mutation/launch. Same core/data/collector used after restricting to comparison auxiliaries.','B730 archive receipt source label inherits R354 fulfillment text from template; actual catalog/Ready/request/record/identity identify the range-outside case unambiguously. Raw receipt retained unchanged.'],publicationHeld=True)
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['decision.json','prospective.json','summary.json','allocation.json','independent-goldens.json','worker-verification.json']:shutil.copyfile(r/name,out/name)
for src,name in [(r/'b730/attribution-range-outside.json','cpu-attribution.json'),(r/'b730/native-body-range-outside-instruction-groups.json','native-instruction-groups.json')]:shutil.copyfile(src,out/name)
with tarfile.open(out/'tools-catalogs-and-observations.tar.xz','w:xz')as t:
 for folder,prefix in [(r,'diagnostic'),(r/'b730','owning-profile')]:
  for p in sorted(folder.iterdir()):
   if p.is_file()and p.suffix in ['.py','.json','.log','.tgz','.md']:t.add(p,arcname=prefix+'/'+p.name)
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()=='36d13d10fe88713f92d9ee54518f956d9d95aaf1f6e6b28196527b34305cecb1'
assert hashlib.sha256((r/'b730/observations.tgz').read_bytes()).hexdigest()=='bb1b02d30aa4a5a668b65c1c386f3fee6fe5f9f1953d115dcbd3658d5811a43f'
(out/'README.md').write_text('''# Numeric loop execution boundary

2026-11-14UTC, R356. Exact fully qualifiedf5817a15/frozen9cfb7d5b on the
quiet AzureF4as_v7 VM, .NET11RC3 and stockCPython3.13.16. A helper sums the same
100,000range values, constructing range inside or outside the helper. No file I/O.
Warm guest clocks include stdout validation and result cleanup; compilation,
startup, fixture reset/protocol and final cache disposal are excluded. Wider
process CPU is retained separately. These **source variants are diagnostics**,
not a runtime source-pair speedup or representative-script replacement.

| Range construction | Lython warm ms | CPython warm ms | Lython/CPython |
| --- | ---: | ---: | ---: |
| Inside helper |5.162–5.194|1.698–1.715|3.01–3.06×|
| Outside helper |4.741–4.748|1.670–1.683|2.82–2.84×|

Two fresh processes per engine/case,5s full-request warmups,five0.5s rotating
batches. Lython process spread0.61%inside/0.15%outside, CPython0.95%/0.76%;
maximum sample IQR3.13%. B729completes71.399s with every identity, output, budget,
quietness and joined-user/archive gate. Local warmed allocation is~7.52MB/run
for either variant; cleanup restores the compilation budget baseline. This does
not establish allocation's CPU share or embedding tail latency.

Moving range construction outside saves roughly8–9%in Lython; the source confirms
range is outside closed native calls and ordinary calls can end native execution.
That boundary does not explain most of the remaining gap. General native reentry
is a secondary opportunity, not the selected redesign and not permanently banned.

One additional5s199Hzcpu-clock/fp owning profile of the outside variant, after
8guest-second warmup, yields1,033guest leaves/65unknown/zeroambiguous. Exact
addition owns505nearest leaves;185leaves are in BigInteger.Add,55in its limb
constructor,240in AddExactIntegers. NativeRunCore has191leaves; same-process JIT
map/disassembly uniquely match its6,619-byteTier1body. Counts include useful work
and are **not removable CPU shares**. Other-thread CPU/raw samples remain.
Every RAM byte was archived/verified before unmount; all workers/profiler joined.

Select the existing checked machine-integer kernel as the next coherent step:
share it with individual exact arithmetic before considering new value storage.
Keep exact overflow promotion, Python signed division/modulo/protocol behavior,
published aliases/identity and existing major-storage admission. No predicted
speedup or allocation reduction. The broader scalar/whole-script roadmap remains.

Preserved fine print: initial staging named local allocation-tool dependencies
absent from the comparison image and failed before mutation/launch. The corrected
identity retains the same core/data/collector. B730's raw receipt has a stale
R354fulfillment source label; actual catalog, Ready, request, record and identity
all identify the numeric outside-helper case. No failed condition is discarded.

[Decision](decision.json),[normal timings](summary.json),[owning CPU](cpu-attribution.json),
[exact native groups](native-instruction-groups.json),[original tools/raw archives](tools-catalogs-and-observations.tar.xz).
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='''
## R356 — numeric-loop boundary and owning scalar evidence

[Two-case diagnostic/one owning profile](results/2026-11-14-numeric-loop-boundary/README.md)
at fully qualifiedf5817a15/frozen9cfb:100kadds take5.16–5.19msinside-range/
4.74–4.75msoutside, CPython1.67–1.71ms; both allocate~7.52MB. The8–9%boundary
is secondary to the2.82–3.06×gap.1,033guest leaves/65unknown/zeroambiguous,
505nearest exact-addition leaves and191native-body leaves select the shared
machine-integer arithmetic kernel, not a tagged VM or general native reentry.
Counts are not removable CPU shares; variants are not runtime source-pair gains.
B729/B730all gates/joins/archive pass; original staging mismatch and stale raw
receipt label remain explicit. R357development proceeds independently; publication held.
''';p.write_text(s,encoding='utf-8',newline='\n')
print('R356 normal timing, allocation, owning CPU and original failures preserved canonically.')
