from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;p=Path('PLAN.md');s=p.read_text(encoding='utf-8');(r/'PLAN-after-source-gate-before-selection.md').write_text(s,encoding='utf-8',newline='\n')
start=s.index('1. **R356 ordinary-loop/helper');end=s.index('\n2. **Advance',start)
s=s[:start]+'''1. **R357 shared exact machine-integer kernel.** R356closes its source gate:
   same100,000adds cost5.16–5.19ms with range inside the helper/4.74–4.75ms
   outside; CPython1.67–1.71ms. Both allocate~7.52MB and restore allowance.
   The8–9%boundary is secondary to the remaining2.82–3.06×gap. One owning
   profile has1,033guest leaves/65unknown/zeroambiguous;505nearest leaves
   belong to exact addition,191native-body leaves. Counts are not removable CPU
   shares. Native resumption is unselected; no repeated timing is needed to
   establish that it cannot explain most of this loop gap.

   Before wider scalar storage, consolidate the existing checked64bit arithmetic
   kernel used by chains/cells with ordinary exact integer arithmetic. Eliminate
   general BigInteger limb arithmetic and repeated magnitude-admission analysis
   for add/subtract/multiply/floor-divide/modulo whose operands/result fit int64.
   Keep existing object/BigInteger publication and major-result admission; no
   new value format, slots, cache, owner or option. Move the shared scalar kernel
   out of executable-only plumbing; keep one implementation and delete displaced
   duplicate routing where justified. This is a coherent kernel step, not completion
   of the scalar/whole-script objective or a promised allocation reduction.

   Accept exact overflow promotion, signed Python division/modulo/zero errors,
   bool/protocol behavior, stable published identity/aliases, cancellation and
   terminal major-allocation refusal before effects. Focused actual11/10 checks,
   independent CPython controls, local allocation diagnostics and one bounded
   frozen source pair: complete loop plus fulfillment/invoice/text controls.
   Decide regression debt explicitly; full delivery batches only if retained.
   Further representation work depends on remaining owning evidence; do not
   invent tagged storage solely because boxing exists.
''' + s[end:]
anchor='   R354\'s bounded fulfillment source gate selected the actual CSV copy stage;'
end=s.index('   Imports already execute code',s.index(anchor))
s=s[:s.index(anchor)]+'''   R354selected CSV compaction; R355tested/withdrew it. R356now establishes a
   bounded numeric-loop gap and owning addition cost. Prioritize the shared exact
   arithmetic kernel, then assess the remaining publication/operand stage from
   changed-source evidence. Native reentry remains a secondary opportunity;
   range-inside/outside source variants are diagnostics, never source-pair speedups.
''' +s[end:]
p.write_text(s,encoding='utf-8',newline='\n')
out=r.parent/'machine-integer-kernel-r357';out.mkdir(exist_ok=False)
prospective=dict(hypothesis='The native-only loop profile puts505/1033 nearest leaves under AddExactIntegers, including BigInteger.Add185/ctor55leaves, while existing machine arithmetic serves only instruction chains/cells. Reuse that checked kernel for individual ordinary exact operations to eliminate general limb arithmetic for int64 results before considering new storage.',eliminated='General BigInteger add/subtract/multiply/division/modulo arithmetic and repeated major-estimation path for checked int64 operands/results; move one shared machine kernel from executable-only file to integer core. Keep boxed BigInteger publication, so allocation reduction is not assumed.',affected='Diagnostic100kcounter and complete invoice/CSVfulfillment helpers/aggregates. Text control unchanged; unknown/adverse measurements retained.',semantics='Exact signed long overflow promotion including min/-1, Python floor/mod signs and zero errors; bool/reflected/in-place protocols remain outside exact path; same result identities/aliases. No allocation/admission before determining fit; major fallback keeps original preflights/terminal refusal/current token and cleanup.',comparison='One frozen source pair with four fresh processes, standard warmups/rotating batches, full output/files/budget checks on quiet VM; complete inside-helper loop, fulfillment/invoice/text. Local allocation counts separately. No prediction of CPU or allocation magnitude.',completion='Retain only a useful coherent shared kernel with focused actual11/10 semantic/cancellation/ownership checks and explicit decision on regression debt. If retained, batch full platform/stress/installed consumers; continue remaining scalar/whole-script roadmap.',publicationHeld=True)
(out/'prospective.json').write_text(json.dumps(prospective,indent=2)+'\n',encoding='utf-8',newline='\n')
source=json.loads((r.parent/'owned-tuple-return-r353/candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==v for n,v in source['sources'].items())
(out/'reference-state.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source=source,sourceIdenticalToFullyQualified='f5817a15/9cfb7d5b'),indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['src/Lokad.Lython/Runtime/LythonRuntime.IntegerBinary.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.IntegerChains.cs','src/Lokad.Lython/Runtime/LythonRuntime.Evaluation.Operators.cs']:
 dest=out/'original'/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(n,dest)
print('R356 source gate closed; R357 hypothesis/semantics/comparison and original source saved before changes.')
