from pathlib import Path
import ast,base64,datetime,hashlib,json,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'fulfillment-stage-r354';out=r/'b730';out.mkdir(exist_ok=False)
oldroot='fulfillment-stage-b726-20261114';newroot='loop-stage-b730-20261114';unit='lython-b730-loop-stage-20261114'
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'));identity.update(purpose='R356 one owning scalar/operand profile after range-boundary diagnostic. Not timing comparison.',diagnosticOnly=True,scriptCaptureWallSeconds=5,warmGuestSeconds=8)
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['ops-profile.py','collect.py']:
 s=(old/name).read_text(encoding='utf-8').replace(oldroot,newroot).replace("'fulfillment'","'range-outside'").replace("'scripts.csv-fulfillment.large'","'diagnostic.loop-range.outside.large'")
 ast.parse(s);(out/name).write_text(s,encoding='utf-8',newline='\n')
(out/'run.sh').write_text('set -eu\nroot=/home/lokad/lython-bench-checks/'+newroot+'\ntrap \'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"\' EXIT\npython3 "$root/collect.py"\n',encoding='utf-8',newline='\n')
prospective=dict(reason='B729 native-only loop remains2.82–2.84timesCPython with7.52MBallocation per100,000adds. Range boundary itself~8–9percent and is not selected as main redesign.',question='Does owning CPU evidence support a coherent scalar publication/operand redesign rather than general native reentry?',bound='One5second199Hzcpu-clock/fp capture,8guestsecond warmup,64invocation requests,120second owner. Same-process JIT map/disassembly. Stop at supported candidate selection/rejection; no broad audit.',constraints='No new value/owner/cache representation until semantic identity/overflow/publication/preflight/cancellation contracts and displaced implementation are explicit. Hot methods are not removable shares.',publicationHeld=True)
(out/'prospective.json').write_text(json.dumps(prospective,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['ops-profile.py','collect.py','run.sh','identity.json','prospective.json']:t.add(out/name,arcname=name)
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root='/home/lokad/lython-bench-checks/'+newroot,sourceRoot='/home/lokad/lython-bench-checks/loop-boundary-b729-20261114',unit=unit,identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
code=(old/'launch-command.py').read_text(encoding='utf-8');start=code.index('config=');end=code.index('\nbase=',start);code=code[:start]+'config='+repr(config)+code[end:];code=code.replace('lython-b726-fixtures','lython-b730-fixtures');ast.parse(code)
(out/'launch-command.py').write_text(code,encoding='utf-8',newline='\n');(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],input=(out/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(out/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc);(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=60)).isoformat(),ownerSeconds=120),indent=2)+'\n',encoding='utf-8',newline='\n')
retrieve=(old/'retrieve.py').read_text(encoding='utf-8').replace(oldroot,newroot).replace('lython-b726-fulfillment-stage-20261114',unit).replace('B726','B730');ast.parse(retrieve);(out/'retrieve.py').write_text(retrieve,encoding='utf-8',newline='\n')
print(done.stdout.decode(),flush=True);print('Earliest observation',(now+datetime.timedelta(seconds=60)).isoformat(),flush=True)
