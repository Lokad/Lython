# Lokad.Lython 0.11.0

Updated 2026-11-14. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including freshly generated scripts. A delivered experiment is a checkpoint,
not completion. Current contracts belong in docs; revision-specific history,
failed conditions and superseded plans remain in [EXPERIMENTS](benchmarks/EXPERIMENTS.md)
and immutable results/private saved plans.

## Actual delivery status

| State | Delivered work and remaining limits |
| --- | --- |
| Completed foundations | Shared compiler-fact/nonlocal correction and lowered-tree retention cleanup; [evidence](benchmarks/results/2026-11-02-shared-compiler-facts/README.md). Do not repeat unchanged qualification. |
| Formatting, qualified | Direct UTF8 formatting/storage allocation−8.67%original/−8.59%later pair. Controlled report confirmations support5–8%CPU/elapsed reductions on their sources; original15.125ms adversity stays unexplained. [Evidence](benchmarks/results/2026-11-02-formatting-confirmation/README.md). |
| Helper returns, qualified | Whole-run allocation−19.92%CSVhelpers/−19.31%JSONhelpers, distinct from diagnostic elapsed. Corrected full8f07764a delivery complete. [Evidence](benchmarks/results/2026-11-02-native-function-returns/README.md). |
| Record/call/iteration foundations, qualified | CSV admitted array adoption/shared keys, final call slots/linear continuations/native prefixes, immutable builtins, native UTF8 JSON, incremental XML and native builtin-for loops delivered. R345warm−14.7..−20.3%, confirmed fresh−17.8..−19.9%; R346indexed cursors full43563853239green. Source-specific adverse controls remain evidence, not release-wide neutrality. [History](benchmarks/EXPERIMENTS.md). |
| R349, fully qualified | e235b18b/frozen71ba, GREEN43571864663Windows/Ubuntu actual11/10, original stress and installed consumers. Captured-cell scalar storage/publication removes per-update boxes: allocation−18.00%, frequent-read allocation+8B. B720elapsed/CPU improve, but faster/variable unchanged controls make attribution uncertain. 581inputs/16summaries cached. [Delivery](benchmarks/results/2026-11-14-captured-scalar-storage/delivery/README.md). |
| R351, fully qualified | 7e2f7cac/frozen72c9, six changed production inputs. Emitted facts hoist immutable tuples; current-owner slice/concat and pre-copy ZIP shape validation delete source-owner selection/LINQ/snapshots.1,382focused actual11/10cases pass,14Python controls, real I/O/cancellation/refusal/retained owners; old01fd fails original regression guards. B723all6jobs/gates pass: allocation−7.51%invoice/−4.68%fulfillment; warm CPU modest. Compile/fresh/text spreads leave uncertainty. GREEN43579225278: Windows/Ubuntu actual11/10, original stress and installed consumers; 581inputs/16summaries cached. [Evidence](benchmarks/results/2026-11-14-compiled-literal-tuples/README.md). |
| R352, measurement complete | Exact7e2f7cac/frozen72c9 vs stockCPython3.13.16, unchanged9job catalog/workers: B724360.499s/all gates. Invoice warm1.19–1.24×/compile1.09–1.10×/fresh1.21–1.24×; captured text1.42–1.49×, JSON0.83–0.84×, search1.63–1.69×, report1.19–1.25×, fulfillment1.27–1.29×, for-loopCSV1.27–1.29×. Report spread4.16%/maxIQR6.20%uncertain. [Current table/boundaries](docs/BENCHMARKS.md). Measured source now passes full43579225278; timing uncertainty stays independent. |
| R353, fully qualified | f5817a15/frozen9cfb7d5b, three production inputs. Existing direct-unpack convention now covers admitted large-helper storage; shared caller completion removes tuple construction/duplicate logic.382focused actual11/10checks/9Python controls pass. Fulfillment allocation−6.77%, invoice/text effectively flat. B725all4jobs/gates pass: fulfillment warm−1.25..−3.13%/fresh−1.12..−4.65%, modest CPU support. Invoice also improves; text process spreads~3%/adversity leave uncertainty. GREEN43583650094 at production-identical24cdc5b4: Windows/Ubuntu actual11/10, original stress and installed consumers;581inputs/16summaries cached. [Evidence](benchmarks/results/2026-11-14-owned-native-tuple-returns/README.md). |
| R355, runtime withdrawn; tests retained | Corrected B728same510a/9cfb completes5jobs/375.423s/all gates. Allocation flat; borrowed effectively flat, escaped−0.54..−1.02%elapsed/CPUuncertain, normal warm−2.39..+0.71%/fresh−1.39..−2.57%. Text+0.50..+3.09%/CPU+1.19..+3.05%, variable. Extra field-end state/copy primitive/raw scratch are not justified by limited benefit. Restored all581production inputs to qualifiedf581/9cfb;18new public cases/stronger prefix assertions retained, forced actual11/10 rebuild/70focused restored checks pass. Original B727failure/partial data survive. [Decision](benchmarks/results/2026-11-14-owned-csv-field-ranges/README.md). |
| Withdrawn / unresolved | Slower call arenas/control remain lessons. R348coarse cased inventory rejects20KB/two words under1MiB; refined form allocation flat/time3–18%adverse. B718unexplained stop remains uncertainty; B719corrected same-bit measurement completes. R351initial01fd ownership gaps/B722fixture failure retain all failures/partial data. No active discarded runtime prototype. [History](benchmarks/EXPERIMENTS.md). |

## Prioritized deliverables

1. **R356 ordinary-loop/helper execution boundary source gate.** R355is closed
   by withdrawal; runtime source remains fully qualifiedf581/9cfb.18independent
   public cases and stronger refusal checks pass forced actual11/10 restoration
   builds (70checks); broader new-test qualification batches at the next coherent
   checkpoint. Original failed and corrected data remain immutable; no replay.
   R356source inspection confirms range is outside closed native calls; a two-case
   same-work100,000iteration diagnostic is locally golden/budget verified on9cfb.
   One180sowner with stockCPython controls; no runtime prototype yet. Establish
   whether ordinary range construction/general calls terminate a
   useful native prefix for a material complete-loop cost. Inspect current code/
   history, use short same-work inside/outside-helper range diagnostics with current
   CPython controls and separate compilation/warm/cleanup boundaries. Data/source
   variants are diagnostics, not source-pair speedup proof. Stop by selecting or
   rejecting one coherent displaced stage; don't add builtin exceptions, tagged
   values or new policies without evidence and semantic/alias/promotion/ownership
   contracts. Continue the substantial roadmap, not another entry micro-tweak.

2. **Advance a substantial representation redesign from owning evidence.**
   R350closed its bounded source gate:1,053invoice/742search guest leaves,
   96/142unknown, zero ambiguous; all native-body leaves map exact same-process
   Tier1. Mixed useful metadata/lookup/arithmetic does not establish a large redundant
   complete activation. Calls already bind final slots; DictReader already bypasses
   lists/adopts arrays/shared keys/combines major admission. Do not duplicate those
   stages or infer removable CPU shares. [Source gate](benchmarks/results/2026-11-14-invoice-search-stage-attribution/README.md).

   R354's bounded fulfillment source gate selected the actual CSV copy stage;
   R355tested/withdrew that representation and preserves the evidence. Move to a
   different coherent boundary. Ordinary loops and helper execution after a first
   general call are the next source question: native prefix recognizes only selected
   builtins, so range construction or a real callback can promote the whole remaining
   body. Establish whether this creates a material ordinary-script cliff before
   changing execution/value machinery. Inspect existing route/history and compare
   identical numeric work with range inside/outside a helper, using short focused
   diagnostics and current CPython controls. Keep compilation/warm/cleanup boundaries
   explicit; source/data variants are diagnostics, not source-pair speedup proof.
   Stop at a supported selection/rejection; don't add individual builtin exceptions
   or a tagged VM without a displaced stage and alias/promotion/ownership contract.
   Imports already execute code, bindings retain declarations and module mirroring
   is demand-driven; don't duplicate those delivered removals.

   | Area / representative scripts | Elimination target; semantic acceptance and displaced implementation |
   | --- | --- |
   | Complete calls/frames/operand transport / helpers, search, invoices | An actually redundant complete activation/storage stage, beyond existing final slots/deferred prefixes. Preserve defaults/receivers, closure identity, exact errors, stack admission, real suspension and awaited pending cleanup; remove displaced construction/dispatch. No renamed slower arena. |
   | Per-record construction / CSV/JSON aggregates, reports | Remove an entire record representation, copy or pass, building on existing CSV adoption. Preserve callbacks, mutation, aliases, pre-effect admission and replacement overlap; delete superseded constructor. Earlier6–8%CSV opportunity already yielded retained integration; withdrawn variants are selective evidence, not automatic promotions. |
   | Scalar transport / counters, invoices, checksums | Wider storage only with owning evidence beyond R349. Preserve exact overflow promotion/identity/publication; remove displaced transport. Universal tagged VM remains unselected. |
   | Remaining text conversions / file search, summaries, reports | Remove a complete conversion/build stage. Preserve Unicode expansion/context, errors, eager admission and callback suspension; retire superseded pipeline. R343/R348teach scan/storage tradeoffs, not permanent bans. |
   | Frontend / fresh generated scripts | Reuse demonstrated repeated facts/IR, preserving scopes/nonlocals, diagnostics, cancellation and admission. Remove displaced analysis. Invoice compile is~0.102ms against~7.3–7.7ms execution; visitor count alone does not prove priority or dominance. |

   Before a selected prototype: record hypothesis, storage/work eliminated, affected
   complete scripts, semantic/cancellation/ownership criteria, implementation to
   delete, bounded source-pair/control comparison and explicit regression-debt
   decision. Stop investigation when a coherent candidate is selected/rejected;
   it need not exhaust every explanation. Temporary setbacks are acceptable with
   a completion milestone. No new arena/cache/framework without displaced work.

3. **Keep regex architecture independent and develop it where capabilities allow.**
   Core-owned Python/nativeUTF8/original-window/byte-scalar/capture/flags/error/
   current-token contract, caches and existing owners remain authoritative.
   Development producers and adapter-local bridges are allowed; core has no backend
   edge. Producer fbf58099leaves the integration files byte-identical toae463cb4;
   independent immutable dev84package834162df is not inferred equivalent.
   Missing capabilities: separate one-match work/result owners, nativeUTF8group-name
   enumeration/copy, token-independent cursor creation with cancellable preparation.
   Search-cursor filtering cannot replace anchored/fullmatch semantics. Only affected
   final released-adapter qualification waits. Completed dev80/15b248dc checks
   (88internal/534public per actual11/10) remain cached; normal optional nonpackable
   adapter0.4pin unchanged. No repeated unchanged producer qualification.
   Distinguish contract correctness, backend semantic validation and actual backend
   performance/managed safety. [Precise capability assessment](benchmarks/results/2026-11-14-regex-provider-capabilities/README.md).

## Measurement and acceptance policy

Architectural simplification, allocation reduction and demonstrated CPU improvement
are separate claims. Percentages inform decisions, not automatic vetoes. Timeout,
unstable unchanged control or inconclusive observation establishes uncertainty.
Allow bounded confirmation/refinement/measurement correction for a stated reason,
retaining every adverse point and original failed condition. No blanket one-attempt,
no-retiming or permanently-closed rule; no open-ended qualification campaign.

R352closes the changed coherent checkpoint's external snapshot; no unchanged replay.
Next CPython refresh follows a material coherent change. Separate compilation,
warm execution and fresh compile-to-result; state mediated I/O, reset, output,
result/cache cleanup boundaries. Startup, genuinely pending I/O, contention,
RSS/heap peaks and embedding tail latency remain unmeasured. VM evidence persists
before owned RAM teardown; preserve current images/catalogs and254/252MiBfloors.

Focused Release semantic/cancellation/ownership checks during iteration; batch
Windows/Ubuntu actual11/10, original stress and installed Release consumers at
meaningful delivery checkpoints. Preserve historical qualification without replay.
Force nonincremental builds after restoration; copy/verify full frozen images.

## Lasting constraints

[AGENTS](AGENTS.md) remains binding. Fully managed/memory-safe only: no unsafe,
Unsafe, pointers, P/Invoke or native probing. Preserve managed stack protection,
host capabilities/original paths+Cwd, cooperative cancellation, cycles/XMLdepth,
checked representation bounds and bounded I/O chunks. No fuel/quotas, hidden caps/
default allowance, regex work/time policies, tracing, weak reclamation, forced GC
or abandoned users. Borrowed allowance funds retained capacity/overlap, aliases,
results/caches and pending users. First refusal is terminal through suppression/
finally; retain origin, await cleanup, never retry. Long streams use bounded host
commands. Only core is packaged; adapter remains nonpackable. Publication held.
