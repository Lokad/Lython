from pathlib import Path
import ast,base64,datetime,hashlib,importlib.util,io,json,os,subprocess,tarfile,tempfile
r=Path(__file__).parent;previous=r.parent/'literal-checkpoint-r352';frozen=r.parent/'owned-tuple-return-r353'
sha=lambda b:hashlib.sha256(b).hexdigest()
identity_source=json.loads((frozen/'candidate-identity.json').read_text(encoding='utf-8'))
core=identity_source['coreSHA256']['candidate'];assert core.startswith('9cfb7d5b')
full_aux=identity_source['auxiliaryFiles']['candidate']
assert {p.name:sha(p.read_bytes())for p in(frozen/'candidate').iterdir()if p.is_file()}==dict(full_aux,**{'Lokad.Lython.dll':core})
aux=json.loads((previous/'identity.json').read_text(encoding='utf-8'))['auxiliaryFiles']
assert all(full_aux[n]==s for n,s in aux.items())
assert not subprocess.check_output(['git','diff','f5817a15','HEAD','--','src'])
old=json.loads((r.parent/'literal-tuples-r351/corrected/return-control.json').read_text(encoding='utf-8'))
cases=[];goldens=[]
for position in ['inside','outside']:
 source=('def fold(count):\n    total = 0\n    for value in range(count):\n        total += value\n    return total\nprint(fold(100000))\n' if position=='inside' else 'def fold(values):\n    total = 0\n    for value in values:\n        total += value\n    return total\nprint(fold(range(100000)))\n')
 output=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],capture_output=True,check=True).stdout.decode('utf-8').replace('\r\n','\n');assert output=='4999950000\n'
 case=dict(old['cases'][0]);fixture=json.dumps(dict(size=100000,text='',inputFiles={},outputFiles={}),separators=(',',':'))
 case.update(id='diagnostic.loop-range.'+position+'.large',category='ordinary-loop-boundary',size=100000,source=source,fixtureJson=fixture,expectedOutput=output,sourceUtf8Bytes=len(source.encode()),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,expectedOutputUtf8Bytes=len(output.encode()),sourceSha256=sha(source.encode()),fixtureSha256=sha(fixture.encode()),expectedOutputSha256=sha(output.encode()))
 cases.append(case);goldens.append(dict(case=case['id'],isolatedCPython='3.13.2',stdout=output))
old['cases']=cases
(r/'representative.json').write_text(json.dumps(old,indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'independent-goldens.json').write_text(json.dumps(goldens,indent=2)+'\n',encoding='utf-8',newline='\n')
spec=importlib.util.spec_from_file_location('protocol',r.parent/'utf8-byte-ownership-r334/b705/retrieved/cpython-worker.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['PATH']=os.environ.get('PATH','');env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
rows=[]
for case in cases:
 with tempfile.TemporaryDirectory(prefix='lython-comparison-files-')as folder:
  p=subprocess.Popen([env['DOTNET_ROOT']+'/dotnet.exe',str((frozen/'candidate/Lokad.Lython.Benchmarks.dll').resolve()),'--compare','worker','--catalog',str((r/'representative.json').resolve())],cwd=folder,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  try:
   ready=protocol.read_frame(p.stdout);assert ready and ready['status']=='Ready'
   assert next(v['sha256'].lower()for v in ready['libraries']if Path(v['path']).name=='Lokad.Lython.dll')==core
   request={k:case[k]for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']};request.update(protocolVersion=2,requestId=1,operation='verify',caseId=case['id'],lane='warm',iterations=2)
   protocol.write_frame(p.stdin,request);response=protocol.read_frame(p.stdout);assert response['status']=='Equivalent',response
   assert response['actualOutputSha256']==case['expectedOutputSha256']and response['actualFilesSha256']==case['expectedFilesSha256']
   protocol.write_frame(p.stdin,dict(protocolVersion=2,requestId=2,operation='quit'));assert protocol.read_frame(p.stdout)['status']=='Closed';assert p.wait(timeout=15)==0 and not p.stderr.read()
   rows.append(dict(case=case['id'],ready=ready,response=response))
  finally:
   if p.poll()is None:p.kill();p.wait()
   p.stdin.close();p.stdout.close();p.stderr.close()
(r/'worker-verification.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
root='/home/lokad/lython-bench-checks/loop-boundary-b729-20261114';unit='lython-b729-loop-boundary-20261114'
identity=dict(sourceRevision='f5817a15/frozen9cfb7d5b; fully qualified43583650094; current b5d97f45 production-identical',purpose='R356 same-work source-variant diagnostic: range construction inside/outside helper, not a source-pair runtime speedup. CPython controls; warm guest timing includes output verification and result cleanup, excludes compilation/startup/reset/protocol/final cache disposal. No file I/O.',coreSHA256={k:core for k in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles=aux,catalogSHA256=sha((r/'representative.json').read_bytes()),publicationHeld=True)
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
collector=(previous/'collect.py').read_text(encoding='utf-8').replace('literal-checkpoint-b724-20261114','loop-boundary-b729-20261114')
start=collector.index('jobs=');end=collector.index('\nenv =',start)
collector=collector[:start]+'jobs='+repr([[c['id'],'warm']for c in cases])+"\nassert len(jobs)==2 and all(case in cases for case,lane in jobs)\n"+collector[end:]
collector=collector.replace('< 420','< 120').replace('Reserve60seconds','Reserve60seconds')
assert 'control_catalog'not in collector;ast.parse(collector)
(r/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
archive=(previous/'archive-owned.py').read_text(encoding='utf-8').replace('literal-checkpoint-b724-20261114','loop-boundary-b729-20261114').replace("len(raw['jobs'])==9","len(raw['jobs'])==2").replace('jobs=9','jobs=2')
ast.parse(archive);(r/'archive-owned.py').write_text(archive,encoding='utf-8',newline='\n')
(r/'run.sh').write_text((previous/'run.sh').read_text(encoding='utf-8').replace('literal-checkpoint-b724-20261114','loop-boundary-b729-20261114'),encoding='utf-8',newline='\n')
prospective=dict(hypothesis='A general call constructing range inside an eligible helper may terminate its native prefix, leaving an ordinary continuation for the entire loop. Establish material same-work cliff before selecting any runtime redesign.',workEliminatedIfConfirmed='Potential one-way promotion/duplicate operand transport after ordinary calls, not individual range exception or new tagged VM.',cases=[c['id']for c in cases],bounds='One180second owner; two jobs/four fresh processes each;5seconds full-request warmup/five0.5second rotating batches; existing stock CPython3.13.16 and exact frozen9cfb image.',stopping='Select or reject a coherent execution boundary from current source and this diagnostic. Source variants cannot establish runtime source-pair speedup; no additional unchanged measurement unless uncertainty prevents the decision.',criteria='Future prototype must preserve Python effects/evaluation order, actual suspension, managed stack bounds, current cancellation, terminal admission, admitted aliases/caches/results and awaited cleanup.',publicationHeld=True)
(r/'prospective.json').write_text(json.dumps(prospective,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=Path('PLAN.md');text=plan.read_text(encoding='utf-8');(r/'PLAN-before.md').write_text(text,encoding='utf-8',newline='\n')
text=text.replace('Next establish whether ordinary range construction/general calls terminate a','R356source inspection confirms range is outside closed native calls; a two-case\n   same-work100,000iteration diagnostic is locally golden/budget verified on9cfb.\n   One180sowner with stockCPython controls; no runtime prototype yet. Establish\n   whether ordinary range construction/general calls terminate a',1);plan.write_text(text,encoding='utf-8',newline='\n')
with tarfile.open(r/'payload.tgz','w:gz')as t:
 for name in ['identity.json','collect.py','archive-owned.py','run.sh','representative.json','prospective.json']:t.add(r/name,arcname=name)
with tarfile.open(r/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root=root,sourceRoot='/home/lokad/lython-bench-checks/owned-return-b725-20261114',unit=unit,identity=identity,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=sha((r/'payload.tgz').read_bytes()),unpackedBytes=unpacked)
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
code='''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
c=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(c['root']);source=Path(c['sourceRoot']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and source.parent==base and not root.exists()and source.resolve()==source
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert(source/'exit-code.txt').read_text().strip()=='0'and not os.path.ismount(source/'guest-fixtures')and json.loads((source/'archive-receipt.json').read_text())['complete']
 expected=dict(c['identity']['auxiliaryFiles'],**{'Lokad.Lython.dll':c['identity']['coreSHA256']['candidate']})
 for name,digest in expected.items():assert sha(source/'candidate'/name)==digest
 payload=sys.stdin.buffer.read(c['payloadBytes']+1);assert len(payload)==c['payloadBytes']and hashlib.sha256(payload).hexdigest()==c['payloadSHA256']
 before=shutil.disk_usage(base).free;assert before>254*1024*1024+c['unpackedBytes']
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:t.extractall(root,filter='data')
 (root/'candidate').mkdir()
 for name in expected:os.link(source/'candidate'/name,root/'candidate'/name)
 os.link(source/'cpython-worker.py',root/'cpython-worker.py')
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir();assert shutil.disk_usage(base).free>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,noImageUploaded=True,noRetirement=True,floorsUnchanged=True))+'\\n')
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b729-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+c['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=180','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print('Launched owned R356 two-case diagnostic;180seconds hard owner.')
'''.replace('CONFIG',repr(config));ast.parse(code);(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],input=(r/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(r/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc);(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=120)).isoformat(),ownerSeconds=180),indent=2)+'\n',encoding='utf-8',newline='\n')
retrieve=(previous/'retrieve.py').read_text(encoding='utf-8').replace('literal-checkpoint-b724-20261114','loop-boundary-b729-20261114').replace('lython-b724-literal-checkpoint-20261114','lython-b729-loop-boundary-20261114').replace("['jobs']==9","['jobs']==2").replace("['elapsedSeconds']<480","['elapsedSeconds']<180").replace('B724 nine-job','B729 two-job')
ast.parse(retrieve);(r/'retrieve.py').write_text(retrieve,encoding='utf-8',newline='\n')
print(done.stdout.decode(),flush=True);print('Earliest observation',(now+datetime.timedelta(seconds=120)).isoformat(),flush=True)
