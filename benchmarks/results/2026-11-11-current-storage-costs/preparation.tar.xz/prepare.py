from pathlib import Path
import ast,hashlib,json,subprocess,tarfile
p=Path(__file__).parent;q=p/'b591';q.mkdir(exist_ok=False)
prior=p.parent/'dictionary-value-storage-r245';old=p.parent/'native-closure-sequence-r243/b585'
name='current-value-profile-b591-20261111';unit='lython-b591-current-value-profile-20261111'
def replace(t):return t.replace('current-phases-profile-b585-20261111',name).replace('lython-b585-current-phases-profile-20261111',unit).replace('lython-b585-fixtures','lython-b591-fixtures').replace('current-phases-profile-b585-launch.py','current-value-profile-b591-launch.py')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
identity=json.loads((prior/'b590/identity.json').read_text(encoding='utf-8'))
identity['coreSHA256'].pop('candidate-control')
identity['sourceRevision']='Retained8f8628a4 exact frozen refined R245 source, after dictionary integer storage. Two6s current CPU captures: captured text Run and JSON report RunAsync (accepted source-pair widerCPU debt). Select next complete phase from actual code/maps. No elapsed comparison, allocation attribution or removable-CPU forecast. Full43081976930 separately pending.'
source=json.loads((prior/'b590/source-identity.json').read_text(encoding='utf-8'))
for filename,h in source['sourceSHA256'].items():assert sha(Path(filename))==h,filename
(q/'catalog.json').write_bytes((prior/'b590/representative.json').read_bytes())
(q/'source-identity.json').write_text(json.dumps(source,indent=2)+'\n',encoding='utf-8')
identity['catalogSHA256']=sha(q/'catalog.json')
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for filename in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','launch.py','retrieve-original.py','remote-launch.py']:
 t=replace((old/filename).read_text(encoding='utf-8')).replace('B585','B591')
 t=t.replace('scripts.file-search.large','scripts.report-render.large').replace('file-search','report-async')
 if filename=='ops-profile.py':
  t=t.replace('("report-async", "scripts.report-render.large", "warm")','("report-async", "scripts.report-render.large", "warm-async")')
  t=t.replace('TryExecuteDictionaryLoop EvaluateNativeReturn GuardNativeReturn','TryExecuteDictionaryLoop EvaluateNativeReturn GuardNativeReturn TryReadRecordValue')
 if filename=='remote-launch.py':
  t=t.replace("source=base/'captured-sequence-b583-20261111/candidate'","source=base/'dictionary-checkpoint-b590-20261111/candidate'")
  a=t.index('protected=');b=t.index("with(base/'comparison-vm.lock')",a)
  t=t[:a]+"protected={source/'Lokad.Lython.dll':config['identity']['coreSHA256']['candidate']}\n"+t[b:]
 if filename.endswith('.py')and filename!='remote-launch.py':ast.parse(t)
 (q/filename).write_text(t,encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz')as archive:
 for filename in ['catalog.json','identity.json','source-identity.json','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh']:archive.add(q/filename,arcname=filename)
with tarfile.open(q/'payload.tgz')as archive:expanded=sum(((m.size+4095)//4096)*4096 for m in archive.getmembers())
canonical=Path('benchmarks/results/2026-11-11-dictionary-integer-storage/initial/quiet/observations.tgz')
data=canonical.read_bytes();assert data==subprocess.check_output(['git','show','HEAD:'+canonical.as_posix()])
with tarfile.open(canonical)as archive:core=archive.extractfile('current-core.dll').read()
oldHash=hashlib.sha256(core).hexdigest();assert oldHash!=identity['coreSHA256']['candidate']
retire=[dict(kind='all-aliases',knownPath='dictionary-values-b588-20261111/candidate/Lokad.Lython.dll',bytes=len(core),sha256=oldHash,canonicalStorage=canonical.as_posix(),canonicalEntry='current-core.dll',canonicalArchiveSHA256=sha(canonical),reason='Initial R245 image superseded by retained refined8f8628a4. Exact source/core/adverse observations preserved in committed Git; current selected refined image protected. Fresh absolute-path/UID/inode/all-alias proof before retiring only obsolete image aliases.')]
config=dict(root='/home/lokad/lython-bench-checks/'+name,unit=unit,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),requiredFreeBytes=252*1024*1024+expanded+65536,retire=retire,identity=identity)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
ast.parse((q/'remote-launch.py').read_text(encoding='utf-8').replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
assert '("report-async", "scripts.report-render.large", "warm-async")'in(q/'ops-profile.py').read_text(encoding='utf-8')
print('Prepared two current6s captures and original120s owner. No VM action; require B590terminal/cached and a fresh idle/disk/identity proof.')
