from pathlib import Path
import hashlib,json,shutil,tarfile
p=Path(__file__).parent;r=p/'b591';out=Path('benchmarks/results/2026-11-11-current-storage-costs')
assert not out.exists();out.mkdir()
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete']and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']and receipt['archivedAndVerifiedUnderLease']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for name in ['observations.tgz','archive-receipt.json','source-identity.json','identity.json','terminal-status.json','inventory.json','config.json','observe-not-before.json','launch.log']:shutil.copyfile(r/name,out/name)
rows=[]
for name in ['text-warm','report-async']:
 base=r/'retrieved/profiles'/name
 d=json.loads((base/'guest-cpu-leaves.json').read_text(encoding='utf-8'));record=json.loads((base/'record.json').read_text(encoding='utf-8'))
 rows.append(dict(name=name,workload=record['workload'],lane=record['lane'],samples=d['samples'],cpuSeconds=d['cpuSeconds'],unknown=d['unknown'],activeTids=d['activeTids'],topLeaves=d['topLeafCpuSamples'],limitations='Current named/inlined associations include useful work, not additive removable fractions; wider host/reset/protocol CPU retained separately. No elapsed/allocation attribution.'))
 with tarfile.open(r/'observations.tgz')as archive:assert json.loads(archive.extractfile('profiles/'+name+'/record.json').read())['exitCode']==0
assessment=dict(source='Retained8f8628a4 exact frozen refined R245. Runtime source unchanged in458be840 test scheduling/current external guide.',profiles=rows,sourceGates=[
 'ExecutionContext already serves as its executable frame; CanDeferInvocationContext executes a borrowed prefix before materializing a required context. R241 already shares final arguments/locals/workspace. Method labels do not prove duplicate frame allocations.',
 'Actual saved Unix Tier1 native node stride72B; EvaluateNativeReturn copies a32B executable instruction into its local frame. This is much smaller than a speculative wide representation. Native preparation precedes operand forwarding/linearization, so referencing final instruction indexes needs a mapping. No compact-node redesign selected without dominant-cost evidence.',
 'Text reader already borrows unchanged UTF8 windows without UTF16 decoding; returned strings copy independently because raw windows are mutable/reused. A shared-view/batch scheme adds lifetime/admission invariants. CSV already has a caller-owned ReadLineInto destination; no repeated intermediary to remove there.',
 'Actual text fixtures call lower().split(), with no redundant strip(). Existing casing/split integration and inline small words remain; no new two-word scratch representation.',
 '.NET11 native numeric formatting already uses UTF8 TryFormat and grouping; a BCL FormatBigInteger symbol alone does not establish a UTF16 conversion. .NET10 admitted character bridge remains intentional.',
 'Next bounded source gate: native dictionary loop admission. Determine whether one managed stack-admission scope can cover the native segment and replace per-word Enter/Leave/try-finally. Preserve first binding/effect order, empty loops, reentry, fallback, cancellation, first refusal and exact promotion. No new policy/mode/guard hierarchy; do not force a lifetime redesign if consolidation requires disproportionate machinery.'
],qualification='Two6s captures total11.644s, all checks/quiet/join/RAM/archive pass; no new timing/CPU gain or allocation claim. Full runtime delivery is separate: firstCI43081976930mixed failure cached; corrected458be840/43087005596pending.',publication='Postponed')
(out/'assessment.json').write_text(json.dumps(assessment,indent=2)+'\n',encoding='utf-8')
with tarfile.open(out/'preparation.tar.xz','w:xz')as archive:
 for f in [*r.glob('*.py'),r/'run.sh',p/'prepare.py',p/'preserve-preparation.py',p/'archive.py']:archive.add(f,arcname=f.name)
 for f in(p/'b591-generation-refusal').rglob('*'):
  if f.is_file()and f.name!='payload.tgz':archive.add(f,arcname='generation-refusal/'+f.relative_to(p/'b591-generation-refusal').as_posix())
print('Current raw code/maps/profiles and source gates preserved; no runtime prototype, no new performance forecast.')
