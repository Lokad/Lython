from pathlib import Path
repo=Path.cwd().resolve();r=Path(__file__).parent.resolve()
source=(r/'b591').resolve();target=(r/'b591-generation-refusal').resolve()
assert source.is_relative_to(repo)and target.is_relative_to(repo)and not target.exists()
assert not(source/'observe-not-before.json').exists()
source.rename(target)
print('Pre-VM generation assertion preserved; corrected replacement order keeps actual report case ID and async lane.')
