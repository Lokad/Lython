import base64
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys

lab = Path(__file__).resolve().parent
repo = Path.cwd()
donor = lab.parent / "lexical-binding-order-r563"
work = repo / ".git/agent-worktrees/direct-variadics-r564"
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
python = Path("C:/Python313/python.exe")
python_worker = repo / "benchmarks/cpython-worker.py"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ["PATH"])

def digest(data):
    return hashlib.sha256(data).hexdigest()

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def run(command, logfile):
    with logfile.open("w", encoding="utf-8") as output:
        subprocess.run(command, check=True, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=45)

catalog = lab / "catalog.json"
target_id = "scripts.report-forwarding.variadic"
control_id = "calls.positional.large"
core_name = "Lokad.Lython.dll"
worker_name = "Lokad.Lython.Benchmarks.dll"

if sys.argv[1] == "prepare":
    source = r"""def line(label, *fields, pattern):
    return pattern.format(label, *fields)

pattern = '{}\t{}\t{}\t{}\n'
count = 0
with open('input.txt', encoding='utf-8') as source, open('report.txt', 'w', encoding='utf-8', newline='') as target:
    for record in source:
        label, start, end, count_text = record.rstrip('\n').split(',')
        target.write(line(label, start, end, count_text, pattern=pattern))
        count += 1
print(count)
"""
    data = ("café,7,19,12\nnotes,3,9,6\n商品,18,38,20\nreport,40,71,31\n" * 256).encode()
    output = data.replace(b",", b"\t")
    expected = "1024\n"
    fixture = json.dumps(dict(size=1024, text=None, inputFiles={"input.txt": base64.b64encode(data).decode()},
                              outputFiles={"report.txt": base64.b64encode(output).decode()}),
                         ensure_ascii=False, separators=(",", ":"))
    def part(data):
        return struct.pack(">i", len(data)) + data
    report = dict(id=target_id, family="scripts", category="whole-script", scale="1024-records", size=1024,
                  source=source, fixtureJson=fixture, expectedOutput=expected,
                  sourceUtf8Bytes=len(source.encode()), expectedOutputUtf8Bytes=len(expected),
                  fixtureTextUtf8Bytes=len(data), fixtureTextCodePoints=len(data.decode()),
                  sourceSha256=digest(source.encode()), fixtureSha256=digest(fixture.encode()),
                  expectedOutputSha256=digest(expected.encode()),
                  expectedFilesSha256=digest(struct.pack(">i", 1) + part(b"report.txt") + part(output)))
    # Reuse the canonical unchanged positional control.
    catalog_data = load(donor / "representative.json")
    catalog_data["cases"] = [report, next(c for c in catalog_data["cases"] if c["id"] == control_id)]
    save(catalog, catalog_data)

    manifest = load(donor / "frozen-identity.json")["imageFiles"]["candidate"]
    base = donor / "frozen/candidate"
    assert len(manifest) == 32
    assert all(digest((base / name).read_bytes()) == value for name, value in manifest.items())
    identities = {}
    for role, src in [("reference", repo), ("candidate", work)]:
        replacement = src / "src/Lokad.Lython/bin/Release/net11.0" / core_name
        frozen = lab / "frozen" / role
        frozen.mkdir(parents=True)
        for name in manifest:
            shutil.copyfile(replacement if name == core_name else base / name, frozen / name)
        for path in base.glob("ValidatedAllocation.*"):
            shutil.copyfile(path, frozen / path.name)
        identities[role] = {name: digest((frozen / name).read_bytes()) for name in manifest}
        assert identities[role] == manifest | {core_name: digest(replacement.read_bytes())}
    save(lab / "frozen-identity.json", dict(referenceCommit="da1946b1c", candidateBase="da1946b1c",
                                             casesSHA256=digest(catalog.read_bytes()), images=identities))

identities = load(lab / "frozen-identity.json")["images"]
for role, files in identities.items():
    assert all(digest((lab / "frozen" / role / name).read_bytes()) == value for name, value in files.items())
reference = lab / "frozen/reference"
candidate = lab / "frozen/candidate"
if sys.argv[1] == "prepare":
    for role, image in [("reference", reference), ("candidate", candidate)]:
        run([dotnet, image / worker_name, "--compare", "verify", "--catalog", catalog, "--dotnet", dotnet,
             "--python", python, "--python-worker", python_worker, "--out", lab / f"{role}-verify.json"],
            lab / f"{role}-verify.log")
        run([dotnet, image / "ValidatedAllocation.dll", image, catalog, lab / f"{role}-allocation.json"],
            lab / f"{role}-allocation.log")
else:
    for index, (case, lane) in enumerate([
        (target_id, "warm"), (control_id, "warm"), (target_id, "compile-run"), (target_id, "compile"),
        (target_id, "compile"), (target_id, "compile-run"), (control_id, "warm"), (target_id, "warm"),
    ]):
        old, new = (reference, candidate) if index < 4 else (candidate, reference)
        tag = f"micro-{index}-{lane}"
        try:
            run([dotnet, new / worker_name, "--compare", "micro", "--catalog", catalog, "--dotnet", dotnet,
                 "--baseline-worker", old / worker_name, "--python", python,
                 "--python-worker", python_worker, "--out", lab / f"{tag}.json", "--case", case, "--lane", lane],
                lab / f"{tag}.log")
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as failure:
            print(tag, "failed", repr(failure), flush=True)
        else:
            print(tag, load(lab / f"{tag}.json")["summaries"], flush=True)

for role, files in identities.items():
    assert all(digest((lab / "frozen" / role / name).read_bytes()) == value for name, value in files.items())
