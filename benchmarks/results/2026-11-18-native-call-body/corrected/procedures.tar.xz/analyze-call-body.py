from pathlib import Path
import bisect,collections,gzip,json,re
r=Path(__file__).parent;f=r/'retrieved/profiles/text-helper'
asm=(f/'native-call.asm').read_text(encoding='utf-8');bodies=[]
for body in re.split(r'(?=; Assembly listing for method )',asm):
 if not body.startswith('; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call('):continue
 sizes=re.findall(r'; Total bytes of code (\d+)',body)
 assert len(sizes)==1
 labels=list(re.finditer(r'^(G_M\d+_IG\d+):[^\n]*offset=0x([0-9a-fA-F]+)',body,re.M))
 blocks=[]
 for i,m in enumerate(labels):
  blocks.append(dict(label=m[1],offset=int(m[2],16),assembly=body[m.start():labels[i+1].start()if i+1<len(labels)else len(body)]))
 offsets=[x['offset']for x in blocks]
 assert offsets==sorted(set(offsets))
 bodies.append(dict(header=body.splitlines()[0],bytes=int(sizes[0]),blocks=blocks))
assert bodies
ranges=[]
for line in gzip.open(f/'perf.map.gz','rt',encoding='utf-8'):
 parts=line.rstrip().split(' ',2)
 if len(parts)!=3:continue
 start,size,name=parts
 if 'NativeExecution::Call('not in name:continue
 start,size=int(start,16),int(size,16)
 matched=[b for b in bodies if b['bytes']==size and ('(Tier1)'in b['header'])==('[OptimizedTier1]'in name)]
 ranges.append(dict(start=start,bytes=size,name=name,matchedBodies=matched))
assert ranges
leaves=[];first=False
for line in gzip.open(f/'all-thread-stacks.txt.gz','rt',encoding='utf-8'):
 if re.match(r'^.*?\s\d+\s+\d+\.\d+:\s+\d+\s+cpu-clock:',line):first=True;continue
 m=re.match(r'^\s+([0-9a-f]+)\s+(.*)$',line)
 if first and m:leaves.append(int(m[1],16));first=False
matched=collections.Counter();unmatched=[]
for address in leaves:
 candidates=[v for v in ranges if v['start']<=address<v['start']+v['bytes']]
 if not candidates:continue
 if len(candidates)!=1 or len(candidates[0]['matchedBodies'])!=1:
  unmatched.append(dict(address=hex(address),candidates=[dict(start=hex(v['start']),bytes=v['bytes'],name=v['name'],matchingAssemblyBodies=len(v['matchedBodies']))for v in candidates]));continue
 v=candidates[0];b=v['matchedBodies'][0];offset=address-v['start'];blocks=b['blocks']
 i=bisect.bisect_right([x['offset']for x in blocks],offset)-1
 assert i>=0
 matched[(b['header'],b['bytes'],blocks[i]['label'],blocks[i]['offset'],blocks[i]['assembly'])]+=1
result=dict(kind='Same-process native Call leaf offsets. Require unique managed map range, version and exact assembly size. Block samples include skid/inlined useful work, not removable cost or a controlled speedup.',allThreadLeafSamples=len(leaves),assemblyVersions=[dict(header=b['header'],bytes=b['bytes'],blockCount=len(b['blocks']))for b in bodies],ranges=[dict(start=hex(v['start']),bytes=v['bytes'],name=v['name'],matchingAssemblyBodies=len(v['matchedBodies']))for v in ranges],unmatchedLeaves=unmatched,matchedCallLeafSamples=sum(matched.values()),blocks=[dict(samples=count,header=key[0],bytes=key[1],label=key[2],offset=hex(key[3]),assembly=key[4])for key,count in matched.most_common()])
(r/'call-body.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print('All-thread leaf samples',len(leaves),'matched native Call',sum(matched.values()),'unmatched Call',len(unmatched))
print('Assembly versions',result['assemblyVersions'])
for b in result['blocks'][:12]:print('\n',b['samples'],b['label'],b['offset'],'\n',b['assembly'])
