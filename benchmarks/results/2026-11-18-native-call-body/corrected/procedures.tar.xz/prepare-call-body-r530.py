from pathlib import Path
import ast,hashlib,io,json,os,subprocess,tarfile
repo=Path('D:/code/Lython');notes=Path(__file__).parent;r=notes/'call-body-r530';r.mkdir(exist_ok=True);prior=notes/'runtime-deletion-r529'
old='/home/lokad/lython-bench-checks/runtime-deletion-b958-20261118';remote='/home/lokad/lython-bench-checks/call-body-b959-20261118'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
catalog=json.loads((prior/'catalog.json').read_text(encoding='utf-8'));catalog['cases']=[c for c in catalog['cases']if c['id']=='scripts.text-normalization.helper-list']
(r/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'));files=identity['imageFiles']['candidate'];identity.update(purpose='One bounded same-process native Call assembly/CPU attribution; complete helper normalization only, no timing comparison, no runtime hooks or controller design.',catalogSHA256=sha(r/'catalog.json'))
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
image=notes/'frontend-dispatch-r527/frozen/candidate';assert len(files)==32 and all(sha(image/n)==h for n,h in files.items())
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
with(r/'actual-worker-preflight.log').open('w',encoding='utf-8')as log:
 p=subprocess.run([str(dotnet),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'catalog.json'),'--dotnet',str(dotnet),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/'actual-worker-preflight.json')],env=env,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==0
for n in ['ops-profile.py','collect.py','run.sh','launch.py','retrieve.py','analyze.py']:
 s=(prior/n).read_text(encoding='utf-8').replace(old,remote).replace('b958','b959')
 s=s.replace("[('floating', 'scripts.numeric-squared-error.floating.large', 'warm'), ('text-helper', 'scripts.text-normalization.helper-list', 'warm')]","[('text-helper', 'scripts.text-normalization.helper-list', 'warm')]")
 s=s.replace("['floating','text-helper']","['text-helper']").replace('len(records)==2','len(records)==1')
 s=s.replace('R529/B958','R530/B959').replace('floating/helper text attribution','helper native Call assembly attribution')
 if n=='ops-profile.py':
  s=s.replace('folder.mkdir()','folder.mkdir()\n        env[\'DOTNET_JitDisasm\']=\'Call\'\n        env[\'DOTNET_JitStdOutFile\']=str(folder/\'native-call.asm\')')
  s=s.replace('for k in ["DOTNET_PerfMapEnabled"]','for k in ["DOTNET_PerfMapEnabled", "DOTNET_JitDisasm", "DOTNET_JitStdOutFile"]')
  s=s.replace('deadline=time.monotonic()+5','deadline=time.monotonic()+8')
  s=s.replace('Same8s warmup/5s capture/12s total guest cap.','Same8s warmup;8s capture/12s total guest cap; one helper case only.')
 (r/n).write_text(s,encoding='utf-8',newline='\n')
assert b'\r'not in(r/'run.sh').read_bytes()
canonical='benchmarks/results/2026-11-18-runtime-source-gate/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
proof=dict(kind='archived-whole-working-replica',sha256=hashlib.sha256(blob).hexdigest(),bytes=len(blob),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='whole-file',committedBlobVerified=True,paths=['runtime-deletion-b958-20261118/observations.tgz'],links=1)
stage=['ops-profile.py','collect.py','run.sh','identity.json','catalog.json']
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for n in stage:a.add(r/n,arcname=n)
c=dict(root=remote,unit='lython-b959-call-body-20261118',source=old,sourceFiles=files,sourceCatalogSHA256=json.loads((prior/'config.json').read_text(encoding='utf-8'))['catalogSHA256'],catalogSHA256=sha(r/'catalog.json'),identity=identity,retireGroups=[proof],payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=sha(r/'payload.tgz'),unpackedBytes=sum((r/n).stat().st_size for n in stage))
(r/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(prior/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace('lython-b958-fixtures','lython-b959-fixtures').replace("source/'representative.json'","source/'catalog.json'")
(r/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
for p in r.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
print('Actual frozen32-file image/helper golden pass; declared map/Call disassembly,8s warmup/8s capture,one case. Stage',c['unpackedBytes'],'bytes,exact committed archive eligible',len(blob))
