from pathlib import Path
import ast
notes=Path(__file__).parent
s=(notes/'prepare-call-body-r530.py').read_text(encoding='utf-8')
s=s.replace("r=notes/'call-body-r530'","r=notes/'call-body-r530-corrected'")
s=s.replace('call-body-b959-20261118','call-body-b960-20261118').replace('lython-b959-call-body','lython-b960-call-body')
s=s.replace("retireGroups=[proof]","retireGroups=[]")
a=s.index("with(r/'actual-worker-preflight.log')");b=s.index("assert p.returncode==0",a)+len("assert p.returncode==0")
s=s[:a]+"import shutil\nassert (r/'catalog.json').read_bytes()==(notes/'call-body-r530/catalog.json').read_bytes()\nfor n in ['actual-worker-preflight.json','actual-worker-preflight.log']:shutil.copyfile(notes/'call-body-r530'/n,r/n)\n"+s[b:]
s=s.replace('R530/B959','R530/B960')
ast.parse(s)
exec(compile(s,'prepare-r530-corrected','exec'))
ops=(notes/'call-body-r530-corrected/ops-profile.py').read_text(encoding='utf-8')
assert 'env["DOTNET_PerfMapEnabled"] = "3"'in ops
assert 'env["DOTNET_PerfMapEnabled",'not in ops
assert 'env[\'DOTNET_JitDisasm\']=\'Call\''in ops
print('Correction scope: one accidental tuple-key edit only; same source/catalog/goldens. No retirement required.')
