from pathlib import Path
import hashlib,json,shutil,sys,tarfile
notes=Path(__file__).parent;corrected='--corrected'in sys.argv
r=notes/('call-body-r530-corrected'if corrected else'call-body-r530')
out=Path('D:/code/Lython/benchmarks/results/2026-11-18-native-call-body')/('corrected'if corrected else'initial');out.mkdir(parents=True,exist_ok=True)
assert not(out/'observations.tgz').exists()
for n in ['identity.json','catalog.json','actual-worker-preflight.json','archive-receipt.json','terminal-status.json','attribution.json','call-body.json','observations.tgz']:
 if(r/n).exists():shutil.copyfile(r/n,out/n)
with tarfile.open(out/'procedures.tar.xz','w:xz')as a:
 for n in ['config.json','ops-profile.py','collect.py','run.sh','launch.py','remote-launch.py','retrieve.py','analyze.py','actual-worker-preflight.log','launch.log','analyze-call-body.py']:
  if(r/n).exists():a.add(r/n,arcname=n)
 for n in ['prepare-call-body-r530.py','prepare-call-body-r530-corrected.py','archive-call-body-r530.py']:
  a.add(notes/n,arcname=n)
assert hashlib.sha256((out/'observations.tgz').read_bytes()).hexdigest()==json.loads((out/'archive-receipt.json').read_text(encoding='utf-8'))['archiveSHA256']
print('Preserved',out)
