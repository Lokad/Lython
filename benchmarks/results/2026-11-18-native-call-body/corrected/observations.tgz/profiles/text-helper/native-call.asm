; Assembly listing for method Lokad.Lython.Frontend.ExecutableInstruction:Call(int,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Frontend.ExecutableInstruction (Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 80
       lea      rbp, [rsp+0x50]
       xor      eax, eax
       mov      qword ptr [rbp-0x38], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x30], xmm8
       mov      qword ptr [rbp-0x20], rax
       mov      qword ptr [rbp-0x08], rdi
       mov      dword ptr [rbp-0x0C], esi
       mov      gword ptr [rbp-0x18], rdx
 
G_M000_IG02:                ;; offset=0x0029
       mov      dword ptr [rsp], -1
       xor      eax, eax
       mov      dword ptr [rsp+0x08], eax
       lea      rdi, [rbp-0x38]
       mov      ecx, dword ptr [rbp-0x0C]
       mov      rdx, gword ptr [rbp-0x18]
       mov      esi, 44
       mov      r8d, 0x7FFFFFFF
       mov      r9d, 0x7FFFFFFF
       call     [Lokad.Lython.Frontend.ExecutableInstruction:.ctor(int,Lokad.Lython.LythonSourceSpan,int,int,int,int,int):this]
       mov      rax, qword ptr [rbp-0x08]
 
G_M000_IG03:                ;; offset=0x005C
       vmovdqu  ymm0, ymmword ptr [rbp-0x38]
       vmovdqu  ymmword ptr [rax], ymm0
 
G_M000_IG04:                ;; offset=0x0065
       mov      rax, qword ptr [rbp-0x08]
 
G_M000_IG05:                ;; offset=0x0069
       vzeroupper 
       add      rsp, 80
       pop      rbp
       ret      
 
; Total bytes of code 114

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 592
       lea      rbp, [rsp+0x250]
       xor      eax, eax
       mov      qword ptr [rbp-0x248], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa32 xmmword ptr [rbp-0x240], xmm8
       vmovdqa32 xmmword ptr [rbp-0x230], xmm8
       mov      rax, -528
 
G_M000_IG43:                ;; offset=0x0036
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       vmovdqa  xmmword ptr [rax+rbp], xmm8
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG43
       mov      bword ptr [rbp-0x08], rdi
       mov      bword ptr [rbp-0x10], rsi
 
G_M000_IG02:                ;; offset=0x0055
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0xC0], rax
       mov      rdi, bword ptr [rbp-0x10]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1F4], eax
       mov      esi, dword ptr [rbp-0x1F4]
       mov      rdi, gword ptr [rbp-0xC0]
       mov      r11, 0x7F32964420C8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x18], rax
       mov      rdi, bword ptr [rbp-0x10]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1C], eax
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0xC8], rax
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0x1C]
       mov      dword ptr [rbp-0xCC], eax
       mov      rax, bword ptr [rbp-0xC8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xCC], eax
       jae      G_M000_IG32
       mov      rax, bword ptr [rbp-0xC8]
       mov      ecx, dword ptr [rbp-0xCC]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x200], rax
       mov      rsi, gword ptr [rbp-0x200]
       mov      rdi, 0x7F3298E13318
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x28], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x38], xmm0
 
G_M000_IG03:                ;; offset=0x012F
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       lea      r8, [rbp-0x38]
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x18]
       mov      edx, dword ptr [rbp-0x1C]
       mov      rcx, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG28
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG30
 
G_M000_IG04:                ;; offset=0x016A
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       jne      G_M000_IG06
       mov      rdi, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG06
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0x1B0], rax
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x1C]
       mov      dword ptr [rbp-0x1B4], eax
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x204], eax
       mov      edx, dword ptr [rbp-0x204]
       mov      esi, dword ptr [rbp-0x1B4]
       mov      rdi, bword ptr [rbp-0x1B0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1C8], rax
       mov      qword ptr [rbp-0x1C0], rdx
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x210], rax
       mov      rdx, gword ptr [rbp-0x210]
       lea      r8, [rbp-0x48]
       mov      rdi, bword ptr [rbp-0x1C8]
       mov      rsi, qword ptr [rbp-0x1C0]
       mov      rax, bword ptr [rbp-0x08]
       mov      rcx, gword ptr [rax+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG05
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG30
 
G_M000_IG05:                ;; offset=0x023B
       lea      rdi, [rbp-0x38]
       mov      rsi, gword ptr [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG28
 
G_M000_IG06:                ;; offset=0x024E
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG18
       mov      rsi, gword ptr [rbp-0x28]
       mov      rdi, 0x7F3298DBE118
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       je       G_M000_IG18
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0x108], rax
       mov      rax, bword ptr [rbp-0x108]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x1C], eax
       jae      G_M000_IG27
       mov      rax, bword ptr [rbp-0x108]
       mov      ecx, dword ptr [rbp-0x1C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x58], rax
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG16
       mov      rsi, gword ptr [rbp-0x58]
       mov      rdi, 0x7F3298AB0CC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x60], 0
       je       G_M000_IG16
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CasedSplit():Lokad.Lython.Frontend.ExecutableCasedSplit:this]
       mov      gword ptr [rbp-0x68], rax
       cmp      gword ptr [rbp-0x68], 0
       je       G_M000_IG16
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingMethod():Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod:this]
       cmp      rax, gword ptr [rbp-0x28]
       jne      G_M000_IG16
       mov      rax, bword ptr [rbp-0x08]
 
G_M000_IG07:                ;; offset=0x0337
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x40]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG27
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
 
G_M000_IG08:                ;; offset=0x0361
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
 
G_M000_IG09:                ;; offset=0x036D
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x130], rax
       lea      rdi, [rbp-0x90]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x214], eax
       mov      esi, dword ptr [rbp-0x214]
       mov      rdi, gword ptr [rbp-0x130]
       mov      r11, 0x7F32964420D0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x98], rax
       mov      rax, bword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x138], rax
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingCallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x220], rax
       mov      rsi, gword ptr [rbp-0x220]
       mov      rdi, gword ptr [rbp-0x138]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG10:                ;; offset=0x03F1
       mov      rax, bword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x140], rax
       lea      rax, bword ptr [rbp-0x38]
       mov      bword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x150], rax
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x140]
       mov      gword ptr [rbp-0x160], rax
       mov      rdi, gword ptr [rbp-0x98]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      G_M000_IG12
       mov      rax, bword ptr [rbp-0x148]
       mov      bword ptr [rbp-0x190], rax
       mov      rax, gword ptr [rbp-0x150]
       mov      gword ptr [rbp-0x198], rax
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rax, gword ptr [rbp-0x160]
       mov      gword ptr [rbp-0x1A8], rax
       mov      rax, bword ptr [rbp-0x08]
       movzx    rax, byte  ptr [rax+0x48]
       test     eax, eax
       je       SHORT G_M000_IG11
       mov      rax, bword ptr [rbp-0x190]
       mov      bword ptr [rbp-0x168], rax
       mov      rax, gword ptr [rbp-0x198]
       mov      gword ptr [rbp-0x170], rax
       mov      rax, gword ptr [rbp-0x1A0]
       mov      gword ptr [rbp-0x178], rax
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rbp-0x180], rax
       mov      rdi, gword ptr [rbp-0x98]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0x184], eax
       jmp      G_M000_IG13
 
G_M000_IG11:                ;; offset=0x04DC
       mov      rax, bword ptr [rbp-0x190]
       mov      bword ptr [rbp-0x168], rax
       mov      rax, gword ptr [rbp-0x198]
       mov      gword ptr [rbp-0x170], rax
       mov      rax, gword ptr [rbp-0x1A0]
       mov      gword ptr [rbp-0x178], rax
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rbp-0x180], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x184], eax
       jmp      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x051E
       mov      rax, bword ptr [rbp-0x148]
       mov      bword ptr [rbp-0x168], rax
       mov      rax, gword ptr [rbp-0x150]
       mov      gword ptr [rbp-0x170], rax
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rbp-0x178], rax
       mov      rax, gword ptr [rbp-0x160]
       mov      gword ptr [rbp-0x180], rax
       mov      dword ptr [rbp-0x184], 1
 
G_M000_IG13:                ;; offset=0x0560
       mov      rdi, gword ptr [rbp-0x170]
       mov      rsi, gword ptr [rbp-0x178]
       mov      rdx, gword ptr [rbp-0x180]
       mov      ecx, dword ptr [rbp-0x184]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x228], rax
       mov      rsi, gword ptr [rbp-0x228]
       mov      rdi, bword ptr [rbp-0x168]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       nop      
 
G_M000_IG14:                ;; offset=0x059D
       call     G_M000_IG33
       nop      
 
G_M000_IG15:                ;; offset=0x05A3
       mov      rax, bword ptr [rbp-0x08]
       add      dword ptr [rax+0x40], 2
       lea      rsi, [rbp-0x90]
       mov      rdx, gword ptr [rbp-0x38]
       mov      rcx, qword ptr [rbp-0x30]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      dword ptr [rbp-0x3C], 1
       jmp      G_M000_IG30
 
G_M000_IG16:                ;; offset=0x05D0
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0x110], rax
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x1C]
       mov      dword ptr [rbp-0x114], eax
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x22C], eax
       mov      edx, dword ptr [rbp-0x22C]
       mov      esi, dword ptr [rbp-0x114]
       mov      rdi, bword ptr [rbp-0x110]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x128], rax
       mov      qword ptr [rbp-0x120], rdx
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x238], rax
       lea      rax, [rbp-0x70]
       mov      qword ptr [rsp], rax
       mov      r8, gword ptr [rbp-0x238]
       mov      rax, bword ptr [rbp-0x08]
       mov      r9, gword ptr [rax+0x18]
       mov      rdx, bword ptr [rbp-0x128]
       mov      rcx, qword ptr [rbp-0x120]
       mov      rsi, gword ptr [rbp-0x58]
       mov      rdi, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG17
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG30
 
G_M000_IG17:                ;; offset=0x0687
       lea      rdi, [rbp-0x38]
       mov      rsi, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG28
 
G_M000_IG18:                ;; offset=0x069A
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       cmp      eax, 1
       jne      SHORT G_M000_IG19
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x06BB
       xor      rax, rax
       mov      gword ptr [rbp-0xD8], rax
       jmp      SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x06C6
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0xF8], rax
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x1C]
       mov      dword ptr [rbp-0xFC], eax
       mov      rax, bword ptr [rbp-0xF8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xFC], eax
       jae      G_M000_IG27
       mov      rax, bword ptr [rbp-0xF8]
       mov      ecx, dword ptr [rbp-0xFC]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0xD8], rax
 
G_M000_IG21:                ;; offset=0x072A
       mov      rax, gword ptr [rbp-0xD8]
       mov      gword ptr [rbp-0xA0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0xA8], eax
       cmp      gword ptr [rbp-0xA0], 0
       jne      SHORT G_M000_IG22
       xor      rax, rax
       mov      gword ptr [rbp-0xE0], rax
       jmp      SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x0755
       lea      rdx, [rbp-0xA8]
       mov      rdi, gword ptr [rbp-0x28]
       mov      rsi, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.Runtime.LythonRuntime:SelectNativeUnaryOperation(System.Object,System.Object,byref):System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      gword ptr [rbp-0xE0], rax
 
G_M000_IG23:                ;; offset=0x0774
       mov      rax, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0xB0], rax
       movzx    rax, byte  ptr [rbp-0xA8]
       cmp      gword ptr [rbp-0xB0], 0
       setne    cl
       movzx    rcx, cl
       and      eax, ecx
       test     eax, eax
       je       SHORT G_M000_IG26
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x240], rax
       mov      rdx, gword ptr [rbp-0x240]
       mov      rax, bword ptr [rbp-0x08]
       mov      rcx, gword ptr [rax+0x18]
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeSingleInput(System.Object,System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      gword ptr [rbp-0xF0], rax
       mov      qword ptr [rbp-0xE8], rdx
 
G_M000_IG24:                ;; offset=0x07E1
       vmovdqu32 xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0x38], xmm0
 
G_M000_IG25:                ;; offset=0x07ED
       jmp      SHORT G_M000_IG28
 
G_M000_IG26:                ;; offset=0x07EF
       lea      r8, [rbp-0x38]
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x18]
       mov      edx, dword ptr [rbp-0x1C]
       mov      rcx, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG28
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      SHORT G_M000_IG30
 
G_M000_IG27:                ;; offset=0x0813
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG28:                ;; offset=0x0819
       mov      rdx, gword ptr [rbp-0x38]
       mov      rcx, qword ptr [rbp-0x30]
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, bword ptr [rbp-0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      eax, 1
 
G_M000_IG29:                ;; offset=0x0834
       vzeroupper 
       add      rsp, 592
       pop      rbp
       ret      
 
G_M000_IG30:                ;; offset=0x0840
       mov      eax, dword ptr [rbp-0x3C]
 
G_M000_IG31:                ;; offset=0x0843
       vzeroupper 
       add      rsp, 592
       pop      rbp
       ret      
 
G_M000_IG32:                ;; offset=0x084F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG33:                ;; offset=0x0855
       push     rax
 
G_M000_IG34:                ;; offset=0x0856
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG35:                ;; offset=0x0867
       vzeroupper 
       add      rsp, 8
       ret      
 
G_M000_IG36:                ;; offset=0x086F
       push     rax
 
G_M000_IG37:                ;; offset=0x0870
       mov      gword ptr [rbp-0x1D0], rdi
       mov      rsi, gword ptr [rbp-0x1D0]
       mov      rdi, 0x7F32976A18E8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rax, gword ptr [rbp-0x1D8]
       mov      gword ptr [rbp-0x1E0], rax
       cmp      gword ptr [rbp-0x1D8], 0
       jne      SHORT G_M000_IG38
       xor      eax, eax
       mov      dword ptr [rbp-0x1E4], eax
       jmp      SHORT G_M000_IG39
 
G_M000_IG38:                ;; offset=0x08B7
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x248], rax
       mov      rsi, gword ptr [rbp-0x248]
       lea      rdx, [rbp-0xB8]
       mov      rdi, gword ptr [rbp-0x1E0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
       mov      dword ptr [rbp-0x1E4], eax
 
G_M000_IG39:                ;; offset=0x08F3
       mov      eax, dword ptr [rbp-0x1E4]
 
G_M000_IG40:                ;; offset=0x08F9
       vzeroupper 
       add      rsp, 8
       ret      
 
G_M000_IG41:                ;; offset=0x0901
       push     rax
 
G_M000_IG42:                ;; offset=0x0902
       mov      gword ptr [rbp-0x1F0], rdi
       mov      rdi, gword ptr [rbp-0xB8]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 2326

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 640
       lea      rbp, [rsp+0x280]
       xor      eax, eax
       mov      qword ptr [rbp-0x278], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa32 xmmword ptr [rbp-0x270], xmm8
       vmovdqa32 xmmword ptr [rbp-0x260], xmm8
       mov      rax, -576
 
G_M000_IG51:                ;; offset=0x0036
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       vmovdqa  xmmword ptr [rax+rbp], xmm8
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG51
       mov      bword ptr [rbp-0x08], rdi
       mov      bword ptr [rbp-0x10], rsi
 
G_M000_IG02:                ;; offset=0x0055
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0xC0], rax
       mov      rax, gword ptr [rbp-0xC0]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rdi, gword ptr [rbp-0x1F8]
       mov      rsi, 0x7F329902EB18
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1F8]
       mov      gword ptr [rbp-0x210], rax
       mov      rdi, bword ptr [rbp-0x10]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x214], eax
       mov      rdi, gword ptr [rbp-0x210]
       mov      esi, dword ptr [rbp-0x214]
       mov      r11, 0x7F3296442408
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x18], rax
       mov      rdi, bword ptr [rbp-0x10]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1C], eax
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0xC8], rax
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0x1C]
       mov      dword ptr [rbp-0xCC], eax
       mov      rax, bword ptr [rbp-0xC8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xCC], eax
       jae      G_M000_IG40
       mov      rax, bword ptr [rbp-0xC8]
       mov      ecx, dword ptr [rbp-0xCC]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x220], rax
       mov      rsi, gword ptr [rbp-0x220]
       mov      rdi, 0x7F3298E13318
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x28], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x38], xmm0
 
G_M000_IG03:                ;; offset=0x0161
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       lea      r8, [rbp-0x38]
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x18]
       mov      edx, dword ptr [rbp-0x1C]
       mov      rcx, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG35
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG38
 
G_M000_IG04:                ;; offset=0x019C
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       jne      G_M000_IG07
       mov      rdi, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG05
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0x1B0], rax
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x1C]
       mov      dword ptr [rbp-0x1B4], eax
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x224], eax
       mov      edx, dword ptr [rbp-0x224]
       mov      esi, dword ptr [rbp-0x1B4]
       mov      rdi, bword ptr [rbp-0x1B0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1C8], rax
       mov      qword ptr [rbp-0x1C0], rdx
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x230], rax
       mov      rdx, gword ptr [rbp-0x230]
       lea      r8, [rbp-0x48]
       mov      rdi, bword ptr [rbp-0x1C8]
       mov      rsi, qword ptr [rbp-0x1C0]
       mov      rax, bword ptr [rbp-0x08]
       mov      rcx, gword ptr [rax+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG06
       mov      rdi, 0x7F329902EC20
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG38
 
G_M000_IG05:                ;; offset=0x027C
       mov      rdi, 0x7F329902EC24
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x028D
       mov      rdi, 0x7F329902EC28
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x38]
       mov      rsi, gword ptr [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG35
 
G_M000_IG07:                ;; offset=0x02AF
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG23
       mov      rsi, gword ptr [rbp-0x28]
       mov      rdi, 0x7F3298DBE118
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       je       G_M000_IG19
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0x108], rax
       mov      rax, bword ptr [rbp-0x108]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x1C], eax
       jae      G_M000_IG33
       mov      rax, bword ptr [rbp-0x108]
       mov      ecx, dword ptr [rbp-0x1C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x58], rax
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG21
       mov      rsi, gword ptr [rbp-0x58]
       mov      rdi, 0x7F3298AB0CC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x60], 0
       je       G_M000_IG18
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CasedSplit():Lokad.Lython.Frontend.ExecutableCasedSplit:this]
       mov      gword ptr [rbp-0x68], rax
       cmp      gword ptr [rbp-0x68], 0
       je       G_M000_IG17
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingMethod():Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod:this]
       cmp      rax, gword ptr [rbp-0x28]
       jne      G_M000_IG16
       mov      rax, bword ptr [rbp-0x08]
 
G_M000_IG08:                ;; offset=0x0398
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x40]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG33
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
 
G_M000_IG09:                ;; offset=0x03C2
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
 
G_M000_IG10:                ;; offset=0x03CE
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x130], rax
       mov      rax, gword ptr [rbp-0x130]
       mov      gword ptr [rbp-0x200], rax
       mov      rdi, gword ptr [rbp-0x200]
       mov      rsi, 0x7F329902EC30
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x200]
       mov      gword ptr [rbp-0x238], rax
       lea      rdi, [rbp-0x90]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x23C], eax
       mov      rdi, gword ptr [rbp-0x238]
       mov      esi, dword ptr [rbp-0x23C]
       mov      r11, 0x7F3296442410
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x98], rax
       mov      rax, bword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x138], rax
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingCallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x248], rax
       mov      rsi, gword ptr [rbp-0x248]
       mov      rdi, gword ptr [rbp-0x138]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG11:                ;; offset=0x0484
       mov      rax, bword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x140], rax
       lea      rax, bword ptr [rbp-0x38]
       mov      bword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x150], rax
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x140]
       mov      gword ptr [rbp-0x160], rax
       mov      rdi, gword ptr [rbp-0x98]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      G_M000_IG13
       mov      rax, bword ptr [rbp-0x148]
       mov      bword ptr [rbp-0x190], rax
       mov      rax, gword ptr [rbp-0x150]
       mov      gword ptr [rbp-0x198], rax
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rax, gword ptr [rbp-0x160]
       mov      gword ptr [rbp-0x1A8], rax
       mov      rax, bword ptr [rbp-0x08]
       movzx    rax, byte  ptr [rax+0x48]
       test     eax, eax
       je       SHORT G_M000_IG12
       mov      rax, bword ptr [rbp-0x190]
       mov      bword ptr [rbp-0x168], rax
       mov      rax, gword ptr [rbp-0x198]
       mov      gword ptr [rbp-0x170], rax
       mov      rax, gword ptr [rbp-0x1A0]
       mov      gword ptr [rbp-0x178], rax
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rbp-0x180], rax
       mov      rdi, gword ptr [rbp-0x98]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0x184], eax
       jmp      G_M000_IG14
 
G_M000_IG12:                ;; offset=0x056F
       mov      rdi, 0x7F329902ED38
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x190]
       mov      bword ptr [rbp-0x168], rax
       mov      rax, gword ptr [rbp-0x198]
       mov      gword ptr [rbp-0x170], rax
       mov      rax, gword ptr [rbp-0x1A0]
       mov      gword ptr [rbp-0x178], rax
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rbp-0x180], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x184], eax
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x05C0
       mov      rdi, 0x7F329902ED3C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x148]
       mov      bword ptr [rbp-0x168], rax
       mov      rax, gword ptr [rbp-0x150]
       mov      gword ptr [rbp-0x170], rax
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rbp-0x178], rax
       mov      rax, gword ptr [rbp-0x160]
       mov      gword ptr [rbp-0x180], rax
       mov      dword ptr [rbp-0x184], 1
 
G_M000_IG14:                ;; offset=0x0611
       mov      rdi, gword ptr [rbp-0x170]
       mov      rsi, gword ptr [rbp-0x178]
       mov      rdx, gword ptr [rbp-0x180]
       mov      ecx, dword ptr [rbp-0x184]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x250], rax
       mov      rsi, gword ptr [rbp-0x250]
       mov      rdi, bword ptr [rbp-0x168]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       nop      
 
G_M000_IG15:                ;; offset=0x064E
       call     G_M000_IG41
       jmp      SHORT G_M000_IG20
 
G_M000_IG16:                ;; offset=0x0655
       mov      rdi, 0x7F329902ED40
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG21
 
G_M000_IG17:                ;; offset=0x0666
       mov      rdi, 0x7F329902ED44
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG21
 
G_M000_IG18:                ;; offset=0x0677
       mov      rdi, 0x7F329902ED48
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG21
 
G_M000_IG19:                ;; offset=0x0688
       mov      rdi, 0x7F329902ED4C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG23
 
G_M000_IG20:                ;; offset=0x069C
       mov      rdi, 0x7F329902ED54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       add      dword ptr [rax+0x40], 2
       lea      rsi, [rbp-0x90]
       mov      rdx, gword ptr [rbp-0x38]
       mov      rcx, qword ptr [rbp-0x30]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      dword ptr [rbp-0x3C], 1
       jmp      G_M000_IG38
 
G_M000_IG21:                ;; offset=0x06D8
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0x110], rax
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x1C]
       mov      dword ptr [rbp-0x114], eax
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x254], eax
       mov      edx, dword ptr [rbp-0x254]
       mov      esi, dword ptr [rbp-0x114]
       mov      rdi, bword ptr [rbp-0x110]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x128], rax
       mov      qword ptr [rbp-0x120], rdx
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x260], rax
       lea      rax, [rbp-0x70]
       mov      qword ptr [rsp], rax
       mov      r8, gword ptr [rbp-0x260]
       mov      rax, bword ptr [rbp-0x08]
       mov      r9, gword ptr [rax+0x18]
       mov      rdx, bword ptr [rbp-0x128]
       mov      rcx, qword ptr [rbp-0x120]
       mov      rsi, gword ptr [rbp-0x58]
       mov      rdi, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG22
       mov      rdi, 0x7F329902ED58
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG38
 
G_M000_IG22:                ;; offset=0x079E
       mov      rdi, 0x7F329902ED5C
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x38]
       mov      rsi, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG35
 
G_M000_IG23:                ;; offset=0x07C0
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       cmp      eax, 1
       jne      SHORT G_M000_IG25
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG26
 
G_M000_IG24:                ;; offset=0x07E1
       mov      rdi, 0x7F329902ED60
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG25:                ;; offset=0x07F0
       xor      rax, rax
       mov      gword ptr [rbp-0xD8], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x07FB
       mov      rdi, 0x7F329902ED64
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0xF8], rax
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x1C]
       mov      dword ptr [rbp-0xFC], eax
       mov      rax, bword ptr [rbp-0xF8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xFC], eax
       jae      G_M000_IG33
       mov      rax, bword ptr [rbp-0xF8]
       mov      ecx, dword ptr [rbp-0xFC]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0xD8], rax
 
G_M000_IG27:                ;; offset=0x086E
       mov      rax, gword ptr [rbp-0xD8]
       mov      gword ptr [rbp-0xA0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0xA8], eax
       cmp      gword ptr [rbp-0xA0], 0
       jne      SHORT G_M000_IG28
       xor      rax, rax
       mov      gword ptr [rbp-0xE0], rax
       jmp      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0899
       mov      rdi, 0x7F329902ED68
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0xA8]
       mov      rdi, gword ptr [rbp-0x28]
       mov      rsi, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.Runtime.LythonRuntime:SelectNativeUnaryOperation(System.Object,System.Object,byref):System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      gword ptr [rbp-0xE0], rax
 
G_M000_IG29:                ;; offset=0x08C7
       mov      rax, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0xB0], rax
       movzx    rax, byte  ptr [rbp-0xA8]
       cmp      gword ptr [rbp-0xB0], 0
       setne    cl
       movzx    rcx, cl
       and      eax, ecx
       test     eax, eax
       je       SHORT G_M000_IG32
       mov      rdi, 0x7F329902ED6C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x268], rax
       mov      rdx, gword ptr [rbp-0x268]
       mov      rax, bword ptr [rbp-0x08]
       mov      rcx, gword ptr [rax+0x18]
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeSingleInput(System.Object,System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      gword ptr [rbp-0xF0], rax
       mov      qword ptr [rbp-0xE8], rdx
 
G_M000_IG30:                ;; offset=0x0943
       vmovdqu32 xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0x38], xmm0
 
G_M000_IG31:                ;; offset=0x094F
       jmp      SHORT G_M000_IG35
 
G_M000_IG32:                ;; offset=0x0951
       lea      r8, [rbp-0x38]
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x18]
       mov      edx, dword ptr [rbp-0x1C]
       mov      rcx, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG34
       mov      rdi, 0x7F329902ED70
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      SHORT G_M000_IG38
 
G_M000_IG33:                ;; offset=0x0984
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG34:                ;; offset=0x098A
       mov      rdi, 0x7F329902ED74
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG35:                ;; offset=0x0999
       nop      
 
G_M000_IG36:                ;; offset=0x099A
       mov      rdi, 0x7F329902EE88
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdx, gword ptr [rbp-0x38]
       mov      rcx, qword ptr [rbp-0x30]
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, bword ptr [rbp-0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      eax, 1
 
G_M000_IG37:                ;; offset=0x09C4
       vzeroupper 
       add      rsp, 640
       pop      rbp
       ret      
 
G_M000_IG38:                ;; offset=0x09D0
       mov      rdi, 0x7F329902EE8C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
 
G_M000_IG39:                ;; offset=0x09E2
       vzeroupper 
       add      rsp, 640
       pop      rbp
       ret      
 
G_M000_IG40:                ;; offset=0x09EE
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG41:                ;; offset=0x09F4
       push     rax
 
G_M000_IG42:                ;; offset=0x09F5
       mov      rdi, 0x7F329902ED50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG43:                ;; offset=0x0A15
       vzeroupper 
       add      rsp, 8
       ret      
 
G_M000_IG44:                ;; offset=0x0A1D
       push     rax
 
G_M000_IG45:                ;; offset=0x0A1E
       mov      gword ptr [rbp-0x1D0], rdi
       mov      rax, gword ptr [rbp-0x1D0]
       mov      gword ptr [rbp-0x208], rax
       mov      rdi, gword ptr [rbp-0x208]
       mov      rsi, 0x7F329902ED78
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x208]
       mov      gword ptr [rbp-0x270], rax
       mov      rsi, gword ptr [rbp-0x270]
       mov      rdi, 0x7F32976A18E8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rax, gword ptr [rbp-0x1D8]
       mov      gword ptr [rbp-0x1E0], rax
       cmp      gword ptr [rbp-0x1D8], 0
       jne      SHORT G_M000_IG46
       xor      eax, eax
       mov      dword ptr [rbp-0x1E4], eax
       jmp      SHORT G_M000_IG47
 
G_M000_IG46:                ;; offset=0x0A97
       mov      rdi, 0x7F329902EE80
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x278], rax
       mov      rsi, gword ptr [rbp-0x278]
       lea      rdx, [rbp-0xB8]
       mov      rdi, gword ptr [rbp-0x1E0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
       mov      dword ptr [rbp-0x1E4], eax
 
G_M000_IG47:                ;; offset=0x0AE2
       mov      rdi, 0x7F329902EE84
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x1E4]
 
G_M000_IG48:                ;; offset=0x0AF7
       vzeroupper 
       add      rsp, 8
       ret      
 
G_M000_IG49:                ;; offset=0x0AFF
       push     rax
 
G_M000_IG50:                ;; offset=0x0B00
       mov      gword ptr [rbp-0x1F0], rdi
       mov      rdi, gword ptr [rbp-0xB8]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 2836

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 251008
; 29 inlinees with PGO data; 91 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 184
       lea      rbp, [rsp+0xE0]
       xor      eax, eax
       mov      qword ptr [rbp-0xC8], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0xC0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x80], zmm8
       vmovdqa  xmmword ptr [rbp-0x40], xmm8
       mov      qword ptr [rbp-0x30], rax
       mov      bword ptr [rbp-0x98], rdi
       mov      rbx, rsi
 
G_M000_IG02:                ;; offset=0x0048
       mov      rax, gword ptr [rdi+0x08]
       mov      rax, gword ptr [rax+0x78]
       cmp      dword ptr [rbx+0x1C], 44
       jne      G_M000_IG124
       mov      esi, dword ptr [rbx+0x08]
       mov      rcx, 0x7F3298D60468
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG126
       mov      ecx, dword ptr [rax+0x08]
       cmp      ecx, esi
       jbe      G_M000_IG125
       mov      ecx, esi
       mov      r15, gword ptr [rax+8*rcx+0x10]
 
G_M000_IG03:                ;; offset=0x0082
       mov      gword ptr [rbp-0xA0], r15
       mov      r14d, dword ptr [rbx+0x10]
       mov      rdi, bword ptr [rbp-0x98]
       lea      rax, bword ptr [rdi+0x50]
       cmp      byte  ptr [r15+0x30], 0
       setne    cl
       movzx    rcx, cl
       add      ecx, r14d
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG141
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      r13, gword ptr [rcx]
       mov      rax, 0x7F2AB9803DF8
       mov      r12, gword ptr [rax]
       cmp      r13, r12
       je       G_M000_IG127
 
G_M000_IG04:                ;; offset=0x00CF
       mov      rax, 0x7F2AB9803E00
       cmp      r13, gword ptr [rax]
       je       G_M000_IG128
       cmp      qword ptr [rcx+0x08], 0
       jne      G_M000_IG129
 
G_M000_IG05:                ;; offset=0x00ED
       test     r13, r13
       je       G_M000_IG130
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x38], xmm0
 
G_M000_IG06:                ;; offset=0x00FF
       cmp      byte  ptr [r15+0x34], 0
       je       G_M000_IG75
 
G_M000_IG07:                ;; offset=0x010A
       cmp      byte  ptr [r15+0x30], 0
       je       G_M000_IG76
 
G_M000_IG08:                ;; offset=0x0115
       cmp      byte  ptr [r15+0x30], 0
       je       G_M000_IG43
       mov      rax, 0x7F3298DBE118
       cmp      qword ptr [r13], rax
       jne      G_M000_IG43
 
G_M000_IG09:                ;; offset=0x0134
       mov      rdi, bword ptr [rbp-0x98]
       lea      rax, bword ptr [rdi+0x50]
       cmp      r14d, dword ptr [rax+0x08]
       jae      G_M000_IG95
       mov      ecx, r14d
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       cmp      gword ptr [rcx], r12
       je       G_M000_IG79
 
G_M000_IG10:                ;; offset=0x015C
       mov      rax, gword ptr [rcx]
       mov      rdx, 0x7F2AB9803E00
       cmp      rax, gword ptr [rdx]
       je       G_M000_IG80
       cmp      qword ptr [rcx+0x08], 0
       jne      G_M000_IG81
       mov      rax, gword ptr [rcx]
 
G_M000_IG11:                ;; offset=0x0180
       mov      ecx, dword ptr [r15+0x28]
       test     ecx, ecx
       jne      SHORT G_M000_IG15
 
G_M000_IG12:                ;; offset=0x0188
       test     rax, rax
       je       SHORT G_M000_IG15
 
G_M000_IG13:                ;; offset=0x018D
       mov      rsi, 0x7F3298AB0CC0
       cmp      qword ptr [rax], rsi
       jne      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x019C
       mov      gword ptr [rbp-0xA8], rax
       mov      r9, gword ptr [r15+0x20]
       mov      gword ptr [rbp-0xB0], r9
       test     r9, r9
       jne      G_M000_IG82
 
G_M000_IG15:                ;; offset=0x01B7
       mov      rdi, bword ptr [rbp-0x98]
       lea      rsi, bword ptr [rdi+0x50]
       cmp      byte  ptr [r15+0x30], 0
       setne    dl
       movzx    rdx, dl
       lea      edx, [r14+rdx+0x01]
       mov      r14d, ecx
       mov      r8d, edx
       mov      edx, r14d
       add      rdx, r8
       mov      ecx, dword ptr [rsi+0x08]
       cmp      rdx, rcx
       ja       G_M000_IG77
       shl      r8, 4
       add      r8, bword ptr [rsi]
       mov      bword ptr [rbp-0xD8], r8
       mov      rsi, gword ptr [r15+0x18]
       mov      gword ptr [rbp-0xC0], rsi
       mov      rcx, gword ptr [rdi+0x18]
       mov      gword ptr [rbp-0xC8], rcx
       test     r14d, r14d
       je       G_M000_IG54
 
G_M000_IG16:                ;; offset=0x0217
       cmp      r14d, 1
       jne      G_M000_IG32
 
G_M000_IG17:                ;; offset=0x0221
       test     rax, rax
       je       G_M000_IG32
 
G_M000_IG18:                ;; offset=0x022A
       mov      rcx, 0x7F3298DDDAB0
       mov      gword ptr [rbp-0xB8], rax
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG31
 
G_M000_IG19:                ;; offset=0x0244
       mov      rcx, 0x7F2AB9803E08
       cmp      r13, gword ptr [rcx]
       jne      G_M000_IG92
       mov      r14, gword ptr [r8]
       cmp      r14, r12
       je       G_M000_IG91
 
G_M000_IG20:                ;; offset=0x0263
       mov      rcx, 0x7F2AB9803E00
       cmp      r14, gword ptr [rcx]
       je       G_M000_IG93
       cmp      qword ptr [r8+0x08], 0
       jne      G_M000_IG94
 
G_M000_IG21:                ;; offset=0x0281
       mov      rcx, gword ptr [rbp-0xC8]
       mov      rdi, gword ptr [rcx+0x98]
       mov      rsi, gword ptr [rbp-0xC0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG22:                ;; offset=0x029F
       mov      rcx, gword ptr [rbp-0xC8]
       mov      rdi, gword ptr [rcx+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      SHORT G_M000_IG26
       mov      rsi, gword ptr [rdi+0x178]
       test     rsi, rsi
       jne      SHORT G_M000_IG25
 
G_M000_IG23:                ;; offset=0x02C7
       mov      r13, gword ptr [r13+0x08]
       mov      rdi, 0x7F3298DEBF18
       cmp      qword ptr [r13+0x18], rdi
       jne      SHORT G_M000_IG27
 
G_M000_IG24:                ;; offset=0x02DB
       mov      r13, gword ptr [rbp-0xB8]
       mov      rdi, r13
       mov      rsi, r14
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0xC8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ListMembers:Append(Lokad.Lython.Runtime.PyList,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       jmp      SHORT G_M000_IG28
 
G_M000_IG25:                ;; offset=0x02FE
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       SHORT G_M000_IG23
 
G_M000_IG26:                ;; offset=0x030E
       mov      rsi, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      SHORT G_M000_IG23
 
G_M000_IG27:                ;; offset=0x031D
       mov      rdx, r14
       mov      rcx, 0x1FFFFFFFF
       mov      rsi, gword ptr [rbp-0xB8]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9, gword ptr [rbp-0xC8]
       mov      rdi, gword ptr [r13+0x10]
       call     [r13+0x18]System.Func`5[System.__Canon,Lokad.Lython.Runtime.LythonRuntime+ReceiverArguments,System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,Lokad.Lython.Runtime.LythonRuntime+ReceiverArguments,System.__Canon,System.__Canon):System.__Canon:this
       nop      
 
G_M000_IG28:                ;; offset=0x0348
       mov      r9, gword ptr [rbp-0xC8]
       mov      r14, gword ptr [r9+0x98]
       mov      rdi, qword ptr [r14+0x168]
       test     rdi, rdi
       jle      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x0362
       dec      rdi
       mov      qword ptr [r14+0x168], rdi
 
G_M000_IG30:                ;; offset=0x036C
       xor      rdi, rdi
       mov      gword ptr [rbp-0x80], rdi
       jmp      G_M000_IG65
 
G_M000_IG31:                ;; offset=0x0377
       mov      rax, gword ptr [rbp-0xB8]
 
G_M000_IG32:                ;; offset=0x037E
       test     rax, rax
       jne      G_M000_IG67
 
G_M000_IG33:                ;; offset=0x0387
       test     rax, rax
       je       G_M000_IG53
 
G_M000_IG34:                ;; offset=0x0390
       mov      rcx, 0x7F3298DD8638
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG53
 
G_M000_IG35:                ;; offset=0x03A3
       mov      r15, rax
       cmp      r14d, 1
       je       SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x03AC
       cmp      r14d, 2
       jne      G_M000_IG53
 
G_M000_IG37:                ;; offset=0x03B6
       mov      rax, 0x7F2AB9803E10
       cmp      r13, gword ptr [rax]
       jne      G_M000_IG53
 
G_M000_IG38:                ;; offset=0x03C9
       test     r14d, r14d
       je       G_M000_IG95
       mov      rdi, r8
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      r13, rax
       mov      rdi, r15
       mov      rsi, r13
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG53
 
G_M000_IG39:                ;; offset=0x03F2
       cmp      r14d, 2
       je       SHORT G_M000_IG42
 
G_M000_IG40:                ;; offset=0x03F8
       mov      rdi, 0x7F2AB98016E8
       mov      rdx, gword ptr [rdi]
 
G_M000_IG41:                ;; offset=0x0405
       mov      rdi, r15
       mov      rsi, r13
       mov      rcx, gword ptr [rbp-0xC0]
       mov      r8, gword ptr [rbp-0xC8]
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeDictionaryGet(Lokad.Lython.Runtime.PyDict,System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       jmp      G_M000_IG65
 
G_M000_IG42:                ;; offset=0x0424
       mov      r12, bword ptr [rbp-0xD8]
       lea      rdi, bword ptr [r12+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       jmp      SHORT G_M000_IG41
 
G_M000_IG43:                ;; offset=0x043B
       cmp      dword ptr [r15+0x28], 1
       jne      SHORT G_M000_IG45
 
G_M000_IG44:                ;; offset=0x0442
       cmp      byte  ptr [r15+0x30], 0
       je       SHORT G_M000_IG50
 
G_M000_IG45:                ;; offset=0x0449
       xor      r12, r12
 
G_M000_IG46:                ;; offset=0x044C
       xor      edx, edx
       mov      dword ptr [rbp-0x68], edx
       test     r12, r12
       jne      SHORT G_M000_IG51
 
G_M000_IG47:                ;; offset=0x0456
       xor      rsi, rsi
 
G_M000_IG48:                ;; offset=0x0458
       test     rsi, rsi
       setne    dl
       movzx    rdx, dl
       movzx    rcx, byte  ptr [rbp-0x68]
       test     edx, ecx
       je       SHORT G_M000_IG52
 
G_M000_IG49:                ;; offset=0x0469
       mov      rdx, gword ptr [r15+0x18]
       mov      rdi, bword ptr [rbp-0x98]
       mov      rcx, gword ptr [rdi+0x18]
       mov      rdi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeSingleInput(System.Object,System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      gword ptr [rbp-0x38], rax
       mov      qword ptr [rbp-0x30], rdx
       jmp      G_M000_IG98
 
G_M000_IG50:                ;; offset=0x048E
       mov      rdi, bword ptr [rbp-0x98]
       lea      rax, bword ptr [rdi+0x50]
       cmp      byte  ptr [r15+0x30], 0
       setne    cl
       movzx    rcx, cl
       lea      ecx, [r14+rcx+0x01]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG95
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      r12, rax
       jmp      SHORT G_M000_IG46
 
G_M000_IG51:                ;; offset=0x04C7
       lea      rdx, [rbp-0x68]
       mov      rdi, r13
       mov      rsi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:SelectNativeUnaryOperation(System.Object,System.Object,byref):System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rsi, rax
       jmp      G_M000_IG48
 
G_M000_IG52:                ;; offset=0x04DF
       lea      r8, [rbp-0x38]
       mov      rdi, bword ptr [rbp-0x98]
       mov      rsi, r15
       mov      edx, r14d
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG98
 
G_M000_IG53:                ;; offset=0x0501
       xor      eax, eax
       jmp      G_M000_IG123
 
G_M000_IG54:                ;; offset=0x0508
       test     rax, rax
       je       SHORT G_M000_IG56
 
G_M000_IG55:                ;; offset=0x050D
       mov      rsi, 0x7F3298AB0CC0
       cmp      qword ptr [rax], rsi
       je       SHORT G_M000_IG59
 
G_M000_IG56:                ;; offset=0x051C
       mov      rsi, rax
       test     rsi, rsi
       je       SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x0524
       mov      rdx, 0x7F3298DD8638
       xor      rcx, rcx
       cmp      qword ptr [rsi], rdx
       cmovne   rsi, rcx
 
G_M000_IG58:                ;; offset=0x0537
       test     rsi, rsi
       je       G_M000_IG16
 
G_M000_IG59:                ;; offset=0x0540
       mov      rsi, gword ptr [r13+0x20]
       mov      rsi, gword ptr [rsi+0x10]
       cmp      dword ptr [rsi+0x08], 0
       jg       G_M000_IG16
       mov      rdx, rsi
       movzx    rcx, byte  ptr [rdx+0x0C]
       mov      edx, dword ptr [rdx+0x10]
       test     ecx, ecx
       je       SHORT G_M000_IG60
       test     edx, edx
       jl       G_M000_IG16
 
G_M000_IG60:                ;; offset=0x0568
       test     rsi, rsi
       je       SHORT G_M000_IG64
 
G_M000_IG61:                ;; offset=0x056D
       mov      rcx, 0x7F32989A9298
       cmp      qword ptr [rsi], rcx
       jne      SHORT G_M000_IG64
 
G_M000_IG62:                ;; offset=0x057C
       movzx    rcx, byte  ptr [rsi+0x30]
       mov      edx, dword ptr [rsi+0x34]
       test     ecx, ecx
       je       G_M000_IG90
       mov      esi, edx
       not      esi
       shr      esi, 31
 
G_M000_IG63:                ;; offset=0x0592
       test     esi, esi
       je       G_M000_IG16
 
G_M000_IG64:                ;; offset=0x059A
       mov      rdi, r13
       mov      rsi, rax
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0xC8]
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeReceiverMethod(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
 
G_M000_IG65:                ;; offset=0x05B4
       mov      gword ptr [rbp-0x38], rax
 
G_M000_IG66:                ;; offset=0x05B8
       xor      eax, eax
       mov      qword ptr [rbp-0x30], rax
       jmp      G_M000_IG98
 
G_M000_IG67:                ;; offset=0x05C3
       mov      rsi, 0x7F3298AB0CC0
       cmp      qword ptr [rax], rsi
       jne      G_M000_IG33
 
G_M000_IG68:                ;; offset=0x05D6
       mov      gword ptr [rbp-0xB8], rax
       mov      r15, rax
       mov      esi, r14d
       sub      esi, 1
       cmp      esi, 2
       ja       G_M000_IG96
       mov      rdi, r13
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime:SelectNativeStringOperation(System.Object,int):System.Nullable`1[int]]
       mov      qword ptr [rbp-0x78], rax
       cmp      byte  ptr [rbp-0x78], 0
       mov      rax, gword ptr [rbp-0xB8]
       je       G_M000_IG74
 
G_M000_IG69:                ;; offset=0x0610
       mov      rdi, bword ptr [rbp-0xD8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      r13, rax
       cmp      r14d, 1
       jle      SHORT G_M000_IG73
 
G_M000_IG70:                ;; offset=0x0626
       mov      r12, bword ptr [rbp-0xD8]
       lea      rdi, bword ptr [r12+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
 
G_M000_IG71:                ;; offset=0x0638
       cmp      r14d, 2
       jg       G_M000_IG97
       xor      r14, r14
 
G_M000_IG72:                ;; offset=0x0645
       mov      edi, dword ptr [rbp-0x74]
       mov      rsi, r13
       mov      gword ptr [rbp-0xD0], rax
       mov      rdx, rax
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeStringCall(int,System.Object,System.Object,System.Object):bool]
       test     eax, eax
       je       G_M000_IG53
       mov      r9, gword ptr [rbp-0xC8]
       mov      gword ptr [rsp], r9
       mov      edi, dword ptr [rbp-0x74]
       mov      rsi, r15
       mov      rdx, r13
       mov      rcx, gword ptr [rbp-0xD0]
       mov      r8, r14
       mov      r9, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeNativeStringOperation(int,Lokad.Lython.Runtime.Text.PyString,System.Object,System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       jmp      G_M000_IG65
 
G_M000_IG73:                ;; offset=0x0696
       xor      rax, rax
       mov      gword ptr [rbp-0xD0], rax
       mov      rax, gword ptr [rbp-0xD0]
       mov      r12, bword ptr [rbp-0xD8]
       jmp      SHORT G_M000_IG71
 
G_M000_IG74:                ;; offset=0x06AF
       mov      r8, bword ptr [rbp-0xD8]
       jmp      G_M000_IG34
 
G_M000_IG75:                ;; offset=0x06BB
       lea      r8, [rbp-0x38]
       mov      rdi, bword ptr [rbp-0x98]
       mov      rsi, r15
       mov      edx, r14d
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG98
       jmp      G_M000_IG53
 
G_M000_IG76:                ;; offset=0x06E2
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG08
       mov      rdi, bword ptr [rbp-0x98]
       lea      rsi, bword ptr [rdi+0x50]
       cmp      byte  ptr [r15+0x30], 0
       setne    dl
       movzx    rdx, dl
       lea      edx, [r14+rdx+0x01]
       mov      ecx, dword ptr [r15+0x28]
       mov      r8d, edx
       mov      eax, ecx
       add      r8, rax
       mov      eax, dword ptr [rsi+0x08]
       cmp      r8, rax
       jbe      SHORT G_M000_IG78
 
G_M000_IG77:                ;; offset=0x0722
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG78:                ;; offset=0x0729
       mov      edx, edx
       shl      rdx, 4
       add      rdx, bword ptr [rsi]
       mov      rdi, rdx
       mov      esi, ecx
       mov      rdx, gword ptr [r15+0x18]
       mov      r12, bword ptr [rbp-0x98]
       mov      rcx, gword ptr [r12+0x18]
       lea      r8, [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG53
       mov      rdi, gword ptr [rbp-0x40]
       mov      gword ptr [rbp-0x38], rdi
       jmp      G_M000_IG66
 
G_M000_IG79:                ;; offset=0x0766
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rdi, rax
       mov      rax, rdi
       jmp      G_M000_IG11
 
G_M000_IG80:                ;; offset=0x077A
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rdi, rax
       mov      rax, rdi
       jmp      G_M000_IG11
 
G_M000_IG81:                ;; offset=0x078E
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rdi, rax
       mov      rax, rdi
       jmp      G_M000_IG11
 
G_M000_IG82:                ;; offset=0x07A2
       cmp      r13, gword ptr [r9+0x08]
       jne      G_M000_IG15
       mov      rdi, bword ptr [rbp-0x98]
       mov      rsi, gword ptr [rdi+0x08]
       mov      rsi, gword ptr [rsi+0x60]
       mov      edx, dword ptr [rdi+0x40]
       add      edx, 2
       cmp      edx, dword ptr [rsi+0x08]
       jae      G_M000_IG95
       shl      rdx, 5
 
G_M000_IG83:                ;; offset=0x07CE
       vmovdqu  ymm0, ymmword ptr [rsi+rdx+0x10]
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
 
G_M000_IG84:                ;; offset=0x07D9
       mov      rsi, gword ptr [rdi+0x08]
       mov      r15, gword ptr [rsi+0x78]
       lea      rdi, [rbp-0x60]
       mov      esi, 44
       mov      rdx, 0x7F2AA5C52FA8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:ReadPrimaryOperand(int,System.String):int:this]
       mov      esi, eax
       mov      rdi, r15
       mov      r11, 0x7F32964424E8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r14, rax
       mov      r12, bword ptr [rbp-0x98]
       mov      rdi, gword ptr [r12+0x18]
       mov      r13, gword ptr [rbp-0xB0]
       mov      rsi, gword ptr [r13+0x18]
       mov      rdi, gword ptr [rdi+0x98]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG85:                ;; offset=0x0836
       mov      rdx, gword ptr [r12+0x18]
       cmp      byte  ptr [r14+0x31], 0
       jne      SHORT G_M000_IG87
       cmp      byte  ptr [r12+0x48], 0
       je       SHORT G_M000_IG86
       movzx    rcx, byte  ptr [r14+0x32]
       jmp      SHORT G_M000_IG88
 
G_M000_IG86:                ;; offset=0x0851
       xor      ecx, ecx
       jmp      SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x0855
       mov      ecx, 1
 
G_M000_IG88:                ;; offset=0x085A
       mov      rdi, r13
       mov      rsi, gword ptr [rbp-0xA8]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x38], rax
       xor      edi, edi
       mov      qword ptr [rbp-0x30], rdi
 
G_M000_IG89:                ;; offset=0x0874
       mov      r15, gword ptr [r12+0x18]
       mov      rdi, gword ptr [r15+0x98]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       add      dword ptr [r12+0x40], 2
       mov      rdx, gword ptr [rbp-0x38]
       mov      rcx, qword ptr [rbp-0x30]
       lea      rsi, [rbp-0x60]
       mov      rdi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      eax, 1
       jmp      G_M000_IG123
 
G_M000_IG90:                ;; offset=0x08AD
       mov      esi, 1
       jmp      G_M000_IG63
 
G_M000_IG91:                ;; offset=0x08B7
       mov      rdi, r8
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG21
 
G_M000_IG92:                ;; offset=0x08C8
       mov      rax, gword ptr [rbp-0xB8]
       jmp      G_M000_IG32
 
G_M000_IG93:                ;; offset=0x08D4
       mov      rdi, r8
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG21
 
G_M000_IG94:                ;; offset=0x08E5
       mov      rdi, r8
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG21
 
G_M000_IG95:                ;; offset=0x08F6
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG96:                ;; offset=0x08FC
       mov      rax, gword ptr [rbp-0xB8]
       jmp      G_M000_IG34
 
G_M000_IG97:                ;; offset=0x0908
       mov      gword ptr [rbp-0xD0], rax
       lea      rdi, bword ptr [r12+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      r14, rax
       mov      rax, gword ptr [rbp-0xD0]
       jmp      G_M000_IG72
 
G_M000_IG98:                ;; offset=0x0929
       vmovdqu  xmm0, xmmword ptr [rbp-0x38]
       vmovdqu32 xmmword ptr [rbp-0x90], xmm0
 
G_M000_IG99:                ;; offset=0x0935
       cmp      dword ptr [rbx+0x18], 0
       jge      G_M000_IG114
 
G_M000_IG100:                ;; offset=0x093F
       mov      esi, dword ptr [rbx+0x18]
       mov      r15d, esi
       not      r15d
       mov      esi, r15d
       mov      r12, bword ptr [rbp-0x98]
       mov      r14d, dword ptr [r12+0x44]
       cmp      esi, r14d
       jge      SHORT G_M000_IG103
 
G_M000_IG101:                ;; offset=0x095C
       dec      r14d
       mov      rsi, gword ptr [r12+0x08]
       mov      esi, dword ptr [rsi+0xB0]
       cmp      r14d, esi
       cmovg    r14d, esi
       cmp      r14d, r15d
       jge      G_M000_IG132
 
G_M000_IG102:                ;; offset=0x097A
       mov      dword ptr [r12+0x44], r15d
 
G_M000_IG103:                ;; offset=0x097F
       mov      rdi, gword ptr [r12+0x18]
       mov      rdi, gword ptr [rdi+0x98]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       G_M000_IG135
       lea      r15, bword ptr [r12+0x50]
       mov      edi, dword ptr [rbx+0x1C]
       cmp      edi, 53
       ja       SHORT G_M000_IG105
 
G_M000_IG104:                ;; offset=0x09A8
       mov      rax, 0x1FFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG136
 
G_M000_IG105:                ;; offset=0x09BC
       mov      eax, dword ptr [rbx+0x14]
 
G_M000_IG106:                ;; offset=0x09BF
       cmp      eax, dword ptr [r15+0x08]
       jae      G_M000_IG141
       mov      rdi, bword ptr [r15]
       mov      eax, eax
       shl      rax, 4
       xor      ecx, ecx
       mov      qword ptr [rdi+rax], rcx
       mov      qword ptr [rdi+rax+0x08], rcx
       mov      edi, dword ptr [rbx+0x1C]
       cmp      edi, 53
       ja       SHORT G_M000_IG108
 
G_M000_IG107:                ;; offset=0x09E5
       mov      rax, 0x1FFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG137
 
G_M000_IG108:                ;; offset=0x09F9
       mov      eax, dword ptr [rbx+0x14]
 
G_M000_IG109:                ;; offset=0x09FC
       mov      dword ptr [r12+0x44], eax
       mov      rdi, gword ptr [r12+0x08]
       mov      rdi, gword ptr [rdi+0x60]
       mov      eax, dword ptr [r12+0x40]
       inc      eax
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG141
       shl      rax, 5
       lea      rdi, bword ptr [rdi+rax+0x10]
       mov      eax, dword ptr [rdi+0x1C]
       cmp      eax, 27
       je       G_M000_IG138
 
G_M000_IG110:                ;; offset=0x0A2F
       cmp      eax, 32
       jne      G_M000_IG139
       cmp      gword ptr [rbp-0x90], 0
       je       G_M000_IG140
 
G_M000_IG111:                ;; offset=0x0A46
       inc      dword ptr [r12+0x40]
 
G_M000_IG112:                ;; offset=0x0A4B
       mov      eax, 1
 
G_M000_IG113:                ;; offset=0x0A50
       vzeroupper 
       add      rsp, 184
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG114:                ;; offset=0x0A65
       mov      edi, dword ptr [rbx+0x1C]
       cmp      edi, 53
       ja       SHORT G_M000_IG116
 
G_M000_IG115:                ;; offset=0x0A6D
       mov      rax, 0x1FFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG131
 
G_M000_IG116:                ;; offset=0x0A81
       mov      r15d, dword ptr [rbx+0x14]
 
G_M000_IG117:                ;; offset=0x0A85
       mov      ebx, dword ptr [rbx+0x18]
       test     ebx, ebx
       jge      SHORT G_M000_IG121
 
G_M000_IG118:                ;; offset=0x0A8C
       not      ebx
 
G_M000_IG119:                ;; offset=0x0A8E
       mov      r14, gword ptr [rbp-0x90]
       mov      r13, qword ptr [rbp-0x88]
       mov      r12, bword ptr [rbp-0x98]
       cmp      ebx, dword ptr [r12+0x44]
       jl       SHORT G_M000_IG122
 
G_M000_IG120:                ;; offset=0x0AAA
       lea      rdi, bword ptr [r12+0x50]
       cmp      r15d, dword ptr [rdi+0x08]
       jae      G_M000_IG141
       mov      r15d, r15d
       shl      r15, 4
       add      r15, bword ptr [rdi]
       mov      rdi, r15
       mov      rsi, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [r15+0x08], r13
       mov      dword ptr [r12+0x44], ebx
       jmp      G_M000_IG112
 
G_M000_IG121:                ;; offset=0x0ADC
       jmp      SHORT G_M000_IG119
 
G_M000_IG122:                ;; offset=0x0ADE
       mov      rdi, r12
       mov      esi, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      SHORT G_M000_IG120
 
G_M000_IG123:                ;; offset=0x0AEB
       vzeroupper 
       add      rsp, 184
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG124:                ;; offset=0x0B00
       mov      rdi, rbx
       mov      rsi, 0x7F2AA5C52FA8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG125:                ;; offset=0x0B1C
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG126:                ;; offset=0x0B23
       mov      rdi, rax
       mov      r11, 0x7F32964424E0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r15, rax
       jmp      G_M000_IG03
 
G_M000_IG127:                ;; offset=0x0B3B
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r13, rax
       jmp      G_M000_IG05
 
G_M000_IG128:                ;; offset=0x0B4C
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r13, rax
       jmp      G_M000_IG05
 
G_M000_IG129:                ;; offset=0x0B5D
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r13, rax
       jmp      G_M000_IG05
 
G_M000_IG130:                ;; offset=0x0B6E
       mov      rdi, 0x7F3297D77A68
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7F2AA5C53978
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG131:                ;; offset=0x0B9C
       mov      rdi, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r15d, eax
       jmp      G_M000_IG117
 
G_M000_IG132:                ;; offset=0x0BAD
       lea      rsi, bword ptr [r12+0x50]
       cmp      r14d, dword ptr [rsi+0x08]
       jae      G_M000_IG141
       mov      rsi, bword ptr [rsi]
       mov      edi, r14d
       shl      rdi, 4
       mov      rsi, gword ptr [rsi+rdi]
       mov      rdi, 0x7F3298DD3CF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG134
       lea      rdi, bword ptr [r12+0x50]
       cmp      r14d, dword ptr [rdi+0x08]
       jae      G_M000_IG141
       mov      ecx, r14d
       shl      rcx, 4
       add      rcx, bword ptr [rdi]
       xor      rdi, rdi
       mov      gword ptr [rcx], rdi
 
G_M000_IG133:                ;; offset=0x0BFC
       mov      qword ptr [rcx+0x08], rdi
       mov      rdi, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
 
G_M000_IG134:                ;; offset=0x0C0D
       dec      r14d
       cmp      r14d, r15d
       jge      SHORT G_M000_IG132
       jmp      G_M000_IG102
 
G_M000_IG135:                ;; offset=0x0C1A
       mov      rdi, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r15d, eax
       mov      rdi, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      esi, r15d
       mov      rcx, gword ptr [rbp-0x90]
       mov      r8, qword ptr [rbp-0x88]
       mov      rdi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG112
 
G_M000_IG136:                ;; offset=0x0C50
       mov      rdi, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG106
 
G_M000_IG137:                ;; offset=0x0C5E
       mov      rdi, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG109
 
G_M000_IG138:                ;; offset=0x0C6C
       lea      rbx, bword ptr [r12+0x50]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG141
       mov      r15d, eax
       shl      r15, 4
       add      r15, bword ptr [rbx]
       mov      rsi, gword ptr [rbp-0x90]
       mov      rdi, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdi, qword ptr [rbp-0x88]
       mov      qword ptr [r15+0x08], rdi
       jmp      G_M000_IG111
 
G_M000_IG139:                ;; offset=0x0CA9
       mov      rdi, 0x7F3297D77A68
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       mov      rdi, r12
       mov      rsi, 0x7F2AA5C560F0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, r12
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG140:                ;; offset=0x0CD7
       lea      rdi, [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rsi, rax
       mov      rdi, 0x7F3298E13318
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       jmp      G_M000_IG111
 
G_M000_IG141:                ;; offset=0x0CFC
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG142:                ;; offset=0x0D02
       push     rax
 
G_M000_IG143:                ;; offset=0x0D03
       mov      r12, bword ptr [rbp-0x98]
       mov      r15, gword ptr [r12+0x18]
       mov      rdi, gword ptr [r15+0x98]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG144:                ;; offset=0x0D1F
       vzeroupper 
       add      rsp, 8
       ret      
 
G_M000_IG145:                ;; offset=0x0D27
       push     rax
 
G_M000_IG146:                ;; offset=0x0D28
       mov      rsi, rdi
       mov      rdi, 0x7F32976A18E8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG148
 
G_M000_IG147:                ;; offset=0x0D3F
       xor      eax, eax
       jmp      SHORT G_M000_IG149
 
G_M000_IG148:                ;; offset=0x0D43
       lea      rdx, [rbp-0x80]
       mov      rdi, rax
       mov      rsi, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG149:                ;; offset=0x0D5F
       vzeroupper 
       add      rsp, 8
       ret      
 
G_M000_IG150:                ;; offset=0x0D67
       push     rax
 
G_M000_IG151:                ;; offset=0x0D68
       mov      rdi, gword ptr [rbp-0x80]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG152:                ;; offset=0x0D72
       push     rax
 
G_M000_IG153:                ;; offset=0x0D73
       mov      r8, gword ptr [rbp-0xC8]
       mov      r14, gword ptr [r8+0x98]
       mov      rdi, qword ptr [r14+0x168]
       test     rdi, rdi
       jle      SHORT G_M000_IG155
 
G_M000_IG154:                ;; offset=0x0D8D
       dec      rdi
       mov      qword ptr [r14+0x168], rdi
 
G_M000_IG155:                ;; offset=0x0D97
       vzeroupper 
       add      rsp, 8
       ret      
 
G_M000_IG156:                ;; offset=0x0D9F
       push     rax
 
G_M000_IG157:                ;; offset=0x0DA0
       mov      rsi, rdi
       mov      rdi, 0x7F32976A18E8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbx, rax
       test     rbx, rbx
       jne      SHORT G_M000_IG159
 
G_M000_IG158:                ;; offset=0x0DBA
       xor      eax, eax
       jmp      SHORT G_M000_IG160
 
G_M000_IG159:                ;; offset=0x0DBE
       mov      rdi, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rsi, rax
       lea      rdx, [rbp-0x70]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG160:                ;; offset=0x0DE3
       vzeroupper 
       add      rsp, 8
       ret      
 
G_M000_IG161:                ;; offset=0x0DEB
       push     rax
 
G_M000_IG162:                ;; offset=0x0DEC
       mov      rdi, gword ptr [rbp-0x70]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 3574

