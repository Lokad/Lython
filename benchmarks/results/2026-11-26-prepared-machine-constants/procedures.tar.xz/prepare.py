from pathlib import Path
from difflib import unified_diff
import subprocess, zipfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
source=lab/'candidate-source'
source.mkdir()
snapshot=lab/'source.zip'
subprocess.run(['git','archive','--format=zip','--output',snapshot,'df71fc295','--',
                'src','tests','benchmarks/Lokad.Lython.Benchmarks','benchmarks/scripts',
                'tools/LythonProbe','Directory.Build.props','Directory.Build.targets','Directory.Build.rsp',
                'Directory.Packages.props','global.json','NuGet.Config'],cwd=repo,check=True)
with zipfile.ZipFile(snapshot) as archive:
    assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in archive.namelist())
    archive.extractall(source)
changes=[]
def edit(name, replacements):
    path=source/name
    before=path.read_text(encoding='utf-8')
    after=before
    for old,new in replacements:
        assert after.count(old)==1,(name,old)
        after=after.replace(old,new)
    path.write_text(after,encoding='utf-8',newline='\n')
    changes.extend(unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),'a/'+name,'b/'+name))
frontend='src/Lokad.Lython/Frontend/'
runtime='src/Lokad.Lython/Runtime/'
edit(frontend+'ExecutableScript.cs',[
    ('        PyString? docstring,\n        CancellationToken cancellationToken)',
     '        PyString? docstring,\n        MemoryGovernor? governor,\n        CancellationToken cancellationToken)'),
    ('        Constants = constants;\n        Names = names;',
     '        Constants = constants;\n        _machineConstants = PrepareMachineConstants(constants, governor, cancellationToken);\n        Names = names;'),
    ('    public object?[] Constants { get; }',
'''    public object?[] Constants { get; }
    private readonly long?[]? _machineConstants;

    // The original objects retain Python-visible identity and overflow
    // behavior. Arithmetic can read exact signed literals without reclassifying
    // their immutable BigInteger objects on each execution.
    internal bool TryReadMachineConstant(int index, out long value)
    {
        if (_machineConstants is { } values && values[index] is { } integer)
        {
            value = integer;
            return true;
        }
        value = 0;
        return false;
    }

    private static long?[]? PrepareMachineConstants(object?[] constants, MemoryGovernor? governor, CancellationToken token)
    {
        for (var first = 0; first < constants.Length; first++)
        {
            PythonTokenization.CheckCancellation(token, first);
            if (!LythonRuntime.TryMachineInteger(constants[first], out var initial)) continue;
            var bytes = checked(32L + 16L * constants.Length);
            using var storage = governor?.ReserveTemporary(bytes, null);
            PythonTokenization.CheckCancellation(token, 0);
            var prepared = new long?[constants.Length];
            prepared[first] = initial;
            for (var index = first + 1; index < prepared.Length; index++)
            {
                PythonTokenization.CheckCancellation(token, index);
                if (LythonRuntime.TryMachineInteger(constants[index], out var integer))
                    prepared[index] = integer;
            }
            storage?.Commit(bytes);
            return prepared;
        }
        return null;
    }''')])
edit(frontend+'ExecutableScript.Builder.cs',[
    ('                docstring: docstring,\n                cancellationToken:',
     '                docstring: docstring,\n                governor: _compilation.Governor,\n                cancellationToken:')])
edit(runtime+'LythonRuntime.IntegerBinary.cs',[
    ('    private static bool TryMachineInteger(object? value, out long result)',
     '    internal static bool TryMachineInteger(object? value, out long result)')])
edit(runtime+'LythonRuntime.Executable.Operands.cs',[
    ('        if (name < 0) return TryMachineInteger(code.Constants[index], out value);',
     '        if (name < 0) return code.TryReadMachineConstant(index, out value);')])
edit(runtime+'LythonRuntime.Executable.PreparedDefinitions.cs',[
    ('            return source < 0 ? TryMachineInteger(factory.Constants[~source], out value) : prior.TryGetInteger(out value);',
     '            return source < 0 ? factory.TryReadMachineConstant(~source, out value) : prior.TryGetInteger(out value);')])
(lab/'candidate.patch').write_text(''.join(changes),encoding='utf-8',newline='\n')
