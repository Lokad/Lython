from pathlib import Path
from statistics import median
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
parent = lab.with_name("post-update-arithmetic-routes-20261126")
prior = parent/"frozen"
read = lambda p: json.loads(p.read_text(encoding="utf-8"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
save = lambda p,v: p.write_text(json.dumps(v,indent=2)+"\n",encoding="utf-8",newline="\n")
donor = read(parent/"frozen-identity.json")
reference = donor["imageFiles"]["candidate"]
assert len(reference)==32 and {p.name:sha(p) for p in (prior/"candidate").iterdir()}==reference
assert not subprocess.check_output(["git","diff","df71fc295","HEAD","--","src"],cwd=repo)
changed = [line[6:] for line in (lab/"candidate.patch").read_text(encoding="utf-8").splitlines() if line.startswith("+++ b/")]
assert len(changed)==5
core = lab/"candidate-source/src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll"
assert core.is_file()
images={}
for role in ("reference","candidate"):
    path=lab/"frozen"/role
    path.mkdir(parents=True)
    for name,digest in reference.items():
        shutil.copyfile(prior/"candidate"/name,path/name)
        assert sha(path/name)==digest
    if role=="candidate": shutil.copyfile(core,path/core.name)
    images[role]={p.name:sha(p) for p in path.iterdir()}
assert {name for name in reference if reference[name]!=images["candidate"][name]}=={core.name}
catalog=lab/"representative.json"
worker=repo/"benchmarks/cpython-worker.py"
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
allocation_tool=lab.with_name("json-traversal-20261124")/"reference"
allocations={}
for role,files in images.items():
    image=lab/"frozen"/role
    report=lab/(role+"-verify.json")
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,"--dotnet",dotnet,
                    "--python","C:/Python313/python.exe","--python-worker",worker,"--out",report],
                   cwd=repo,env=env,check=True,timeout=85)
    proof=read(report)
    assert proof["state"]=="Completed" and proof["caseCount"]==4
    assert proof["catalogSha256"]==sha(catalog) and proof["launched"]["library"]["sha256"]==files[core.name]
    allocated=lab/(role+"-allocated")
    shutil.copytree(image,allocated)
    assert {p.name:sha(p) for p in allocated.iterdir()}==files
    for executable in allocation_tool.glob("ValidatedAllocation*"):
        shutil.copyfile(executable,allocated/executable.name)
    output=lab/(role+"-allocation.json")
    subprocess.run([dotnet,allocated/"ValidatedAllocation.dll",allocated,catalog,output],
                   cwd=repo,env=env,check=True,timeout=58)
    allocations[role]=read(output)["rows"]
result=[]
for before,after in zip(allocations["reference"],allocations["candidate"],strict=True):
    assert before["id"]==after["id"] and before["sharedBudgetBaselineRestored"] and after["sharedBudgetBaselineRestored"]
    result.append(dict(case=before["id"],
                       allocationBytes=[median(row["allocatedBytesPerInvocation"]) for row in (before,after)],
                       peakAdmission=[row["peakExecutionMemoryBytes"] for row in (before,after)]))
save(lab/"allocation-summary.json",result)
save(lab/"frozen-identity.json",dict(sourceRevision="df71fc295",runtimeRevision="df71fc295",
     sourcePatchSHA256=sha(lab/"candidate.patch"),imageFiles=images,
     coreSHA256={role+suffix:files[core.name] for role,files in images.items() for suffix in ("","-control")},
     cpythonWorkerSHA256=sha(worker),catalogs={"representative.json":{"sha256":sha(catalog)}}))
print(json.dumps(result))
