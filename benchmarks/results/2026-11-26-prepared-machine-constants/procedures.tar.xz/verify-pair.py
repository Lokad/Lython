from pathlib import Path
from statistics import median
import ast, json, os, shutil, subprocess, sys

lab=Path(__file__).resolve().parent
root=lab.parents[3]
baseline=lab.with_name('post-update-arithmetic-routes-20261126')
profile=lab.with_name('post-deferral-factory-cpu-20261126')
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
old=read(profile/'routes/cases.json')
control=read(profile/'routes/control.json')['cases'][0]
old['cases']=[(case['id'],case) for case in old['cases'] if not case['runAsync']]
old['cases']=[{k:v for k,v in item.items() if k!='runAsync'} for _,item in old['cases']]+[control]
assert len(old['cases'])==4
(lab/'representative.json').write_text(json.dumps(old,ensure_ascii=False),encoding='utf-8',newline='\n')
script=(baseline/'prepare-frozen.py').read_text(encoding='utf-8')
for before,after in (
 ('converted-dictionary-update-20261126','post-update-arithmetic-routes-20261126'),
 ('"7f7c4ed59"','"df71fc295"'),
 ('assert len(changed)==1','assert len(changed)==5'),
 ('catalog=parent/"comparison/quiet/representative.json"','catalog=lab/"representative.json"'),
 ('proof["caseCount"]==5','proof["caseCount"]==4')):
    assert before in script
    script=script.replace(before,after)
prepare=lab/'prepare-frozen.py'
prepare.write_text(script,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'-X','utf8',prepare],check=True)
identity=read(lab/'frozen-identity.json')
toolchain=Path.home()/'.dotnet11'
diagnostic=lab.with_name('shared-literal-decoding-20261124')/'refinement/compiler-owner'
rows={}
for role in ('reference','candidate'):
    runner=lab/(role+'-compiler-owner')
    runner.mkdir()
    for path in diagnostic.glob('Inspect*'):
        shutil.copyfile(path,runner/path.name)
    shutil.copyfile(lab/'frozen'/role/'Lokad.Lython.dll',runner/'Lokad.Lython.dll')
    result=lab/(role+'-compiler-allocation.json')
    subprocess.run([toolchain/'dotnet.exe',runner/'Inspect.dll',lab/'representative.json',result],
                   env=dict(os.environ,DOTNET_ROOT=str(toolchain),DOTNET_ROOT_X64=str(toolchain)),check=True,timeout=65)
    data=read(result)
    assert data['coreSHA256']==identity['coreSHA256'][role]
    rows[role]=data['rows']
summary=[]
for before,after in zip(rows['reference'],rows['candidate'],strict=True):
    assert before['id']==after['id']
    summary.append(dict(case=before['id'],allocationBytes=[median(r['allocatedBytes']) for r in (before,after)],
                        retainedAdmission=[r['retainedAdmission'] for r in (before,after)]))
assert len(summary)==4
(lab/'compile-allocation-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(summary))
