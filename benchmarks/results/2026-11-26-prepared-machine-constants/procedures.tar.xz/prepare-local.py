from pathlib import Path
import hashlib,json,shutil

lab=Path(__file__).resolve().parent
previous=lab.with_name('ready-json-decoder-entry-20261126')
comparison=lab/'local'
comparison.mkdir()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,t:p.write_text(t,encoding='utf-8',newline='\n')
save=lambda p,v:write(p,json.dumps(v,indent=2)+'\n')
identity=json.loads((lab/'frozen-identity.json').read_text(encoding='utf-8'))
for role,files in identity['imageFiles'].items():
    image=lab/'frozen'/role
    assert len(files)==32 and {p.name:digest(p) for p in image.iterdir()}==files
    shutil.copytree(image,comparison/role)
    assert {p.name:digest(p) for p in (comparison/role).iterdir()}==files
for path in (lab/'representative.json',previous/'local/cpython-worker.py',previous/'local/run.sh'):
    shutil.copyfile(path,comparison/path.name)
assert digest(comparison/'cpython-worker.py')==identity['cpythonWorkerSHA256']
ordinary='diagnostic.generated-ordinary-definitions'
rules='scripts.rule-default-closures'
text='diagnostic.text-summary.nonlocal-computed-width.large'
save(comparison/'jobs.json',{'warm':[[ordinary,'warm'],[rules,'compile-run'],
    ['diagnostic.shipment-file-fed-map','warm'],[text,'warm'],
    [ordinary,'compile-run'],[rules,'warm'],[text,'compile-run']]})
identity['catalogs']={name:{'sha256':digest(comparison/name)} for name in ('representative.json','jobs.json')}
identity['purpose']='Pinned local diagnostic for moving exact signed constant classification into compilation.'
save(comparison/'identity.json',identity)
collector=(previous/'local/collect.py').read_text(encoding='utf-8')
for old,new in (('len(jobs) == 4','len(jobs) == 7'),('accumulate 4 seconds','accumulate 3 seconds'),
                ('warmupSeconds=4, targetBatchSeconds=.35','warmupSeconds=3, targetBatchSeconds=.31'),
                ('lython-json-ready-fixture-','lython-machine-constants-fixture-')):
    assert collector.count(old)==1
    collector=collector.replace(old,new)
compile(collector,'collect.py','exec')
write(comparison/'collect.py',collector)
runner=(previous/'run-local.sh').read_text(encoding='utf-8').replace(previous.name,lab.name).replace('150s','245s')
write(lab/'run-local.sh',runner)
assert all(b'\r' not in p.read_bytes() for p in (lab/'run-local.sh',comparison/'run.sh'))
summarizer=(previous/'summarize.py').read_text(encoding='utf-8').replace('== 4','== 7').replace('timedBatches=112','timedBatches=196')
compile(summarizer,'summarize.py','exec')
write(lab/'summarize.py',summarizer)
