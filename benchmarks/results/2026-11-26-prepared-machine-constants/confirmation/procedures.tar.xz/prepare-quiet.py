from pathlib import Path
import ast, hashlib, json, os, shutil, subprocess, tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.with_name('post-update-arithmetic-routes-20261126')
template=prior/'comparison/quiet'
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,t:p.write_text(t,encoding='utf-8',newline='\n')
save=lambda p,v:write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
identity=read(lab/'frozen-identity.json')
assert sha(lab/'candidate.patch')==identity['sourcePatchSHA256']
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and {p.name:sha(p) for p in (lab/'frozen'/role).iterdir()}==files
assert identity['imageFiles']['reference']==read(template/'identity.json')['imageFiles']['candidate']
donor=read(template/'terminal-status.json')['receipt']
assert donor['complete'] and donor['allWorkersJoined'] and sha(template/'observations.tar.xz')==donor['archiveSHA256']
identity['expectedCPythonSHA256']=read(template/'identity.json')['expectedCPythonSHA256']
identity['purpose']='Quiet confirmation of immutable machine-integer constants after an unstable local block.'
ordinary='diagnostic.generated-ordinary-definitions'
rules='scripts.rule-default-closures'
text='diagnostic.text-summary.nonlocal-computed-width.large'
control='diagnostic.shipment-file-fed-map'
jobs=[[control,'warm'],[ordinary,'warm'],[rules,'compile-run'],[text,'warm'],[ordinary,'compile-run'],[rules,'warm']]
save(quiet/'jobs.json',dict(warm=jobs))
shutil.copyfile(lab/'representative.json',quiet/'representative.json')
assert {p['id'] for p in read(quiet/'representative.json')['cases']}=={row[0] for row in jobs}
shutil.copyfile(template/'cpython-worker.py',quiet/'cpython-worker.py')
assert sha(quiet/'cpython-worker.py')==identity['cpythonWorkerSHA256']
identity['catalogs']={name:dict(sha256=sha(quiet/name)) for name in ('representative.json','jobs.json')}
save(quiet/'identity.json',identity)
collector=(template/'collect.py').read_text(encoding='utf-8')
for old,new in (('len(jobs) == 4','len(jobs) == 6'),('accumulate 7 seconds','accumulate 5 seconds'),
                ('lython-b1766-fixtures','lython-b1770-fixtures')):
    assert collector.count(old)==1
    collector=collector.replace(old,new)
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
shutil.copyfile(template/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
for role,files in identity['imageFiles'].items():
    image=lab/'frozen'/role
    proof=quiet/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
                    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',quiet/'cpython-worker.py','--out',proof],
                   cwd=repo,env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=88)
    report=read(proof)
    assert report['state']=='Completed' and report['caseCount']==4
    assert report['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert report['launched']['library']['sha256'].lower()==files['Lokad.Lython.dll'].lower()
package=quiet/'stage.tar.gz'
inputs=[('new-core.dll',lab/'frozen/candidate/Lokad.Lython.dll')]
inputs.extend((name,quiet/name) for name in ('identity.json','representative.json','jobs.json','collect.py','run.sh','cpython-worker.py'))
with tarfile.open(package,'w:gz',compresslevel=6) as bundle:
    for name,path in inputs: bundle.add(path,arcname=name,recursive=False)
expanded=sum(path.stat().st_size for _,path in inputs)
save(quiet/'upload.json',dict(root='prepared-constants-b1770-20261126',payloadSHA256=sha(package),
                             payloadBytes=package.stat().st_size,expandedBytes=expanded,donorSHA256=donor['archiveSHA256']))
launcher=(prior/'quiet.py').read_text(encoding='utf-8')
for old,new in (('lython-b1766-boolean-increments-20261126','lython-b1770-prepared-constants-20261126'),
                ('converted-dictionary-update-b1763-20261126','boolean-increments-b1766-20261126'),
                ("cfg['payloadBytes']+13*1024*1024","cfg['payloadBytes']+cfg['expandedBytes']+5*1024*1024"),
                ("verified['caseCount']==3","verified['caseCount']==4"),
                ('RuntimeMaxSec=214','RuntimeMaxSec=325'),('seconds=172','seconds=241')):
    assert launcher.count(old)==1,(old,launcher.count(old))
    launcher=launcher.replace(old,new)
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
summary=(prior/'summarize-quiet.py').read_text(encoding='utf-8').replace("== 4","== 6").replace('timedBatches=112','timedBatches=168')
compile(summary,'summarize-quiet.py','exec')
write(lab/'summarize-quiet.py',summary)
