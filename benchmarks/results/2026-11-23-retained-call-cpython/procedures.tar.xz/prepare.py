from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
baseline = lab.parent / "supplied-scalar-return-20261123"
external = lab.parent / "computed-factory-cpython-20261123"
terminal = lab.parent / "guarded-native-closed-entry-20261123"
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(path.read_bytes())
def write(name, value):
    (lab/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+"\n",encoding="utf-8",newline="\n")
def git(*args):
    return subprocess.check_output(["git",*args],cwd=repo)

built = (lab/"built-revision").read_text(encoding="utf-8").strip()
assert not git("diff","--name-only",built,"HEAD","--","src","tests","benchmarks/cpython-worker.py","benchmarks/Lokad.Lython.Benchmarks")
assert not git("diff","--name-only",built,"origin/master","--","src","tests","benchmarks/cpython-worker.py","benchmarks/Lokad.Lython.Benchmarks")

catalog = read(external/"representative.json")
short = "diagnostic.text-summary.nonlocal-computed-width.large"
short_case = next(row for row in read(lab.parent/"closure-cpython-20261123/representative.json")["cases"] if row["id"] == short)
catalog["cases"].append(short_case)
assert len(catalog["cases"]) == 5
write("representative.json",catalog)
eager = "scripts.annotated-rule-closures.nested-factories"
postponed = eager + ".postponed"
supplied = "scripts.ordinary-fully-supplied-helper"
quoted = "scripts.csv-invoice.method-policy.quoted-control"
write("jobs.json", [[eager,"warm"],[postponed,"warm"],[supplied,"warm"],[quoted,"warm"],
                   [eager,"compile-run"],[postponed,"compile-run"],[supplied,"compile-run"],[short,"compile-run"]])
assert {row["id"] for row in catalog["cases"]} == {eager,postponed,supplied,quoted,short}

prior = read(baseline/"comparison/identity.json")
files = prior["imageFiles"]["candidate"]
assert len(files)==32
image = lab/"candidate"
image.mkdir(exist_ok=True)
core = "Lokad.Lython.dll"
for name, expected in files.items():
    old = baseline/"candidate"/name
    assert digest(old)==expected
    source = lab/"frozen/bin/Lokad.Lython/release_net11.0"/core if name==core else old
    shutil.copyfile(source,image/name)
hashes={name:digest(image/name) for name in files}
assert [name for name in files if files[name]!=hashes[name]]==[core]
remote = "/home/lokad/lython-bench-checks/retained-call-cpython-b1510-20261123"
protocol = repo/"benchmarks/cpython-worker.py"
assert digest(protocol)==prior["cpythonWorkerSHA256"]
dotnet = Path.home()/".dotnet11/dotnet.exe"
env = dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
receipt=lab/"candidate-verify.json"
subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",lab/"representative.json",
                "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",receipt],
               env=env,timeout=90,check=True)
proof=read(receipt)
assert proof["state"]=="Completed" and proof["caseCount"]==5
assert proof["launched"]["library"]["sha256"]==hashes[core]
assert {name:digest(image/name) for name in files}==hashes
write("identity.json",dict(sourceRevision=built,candidate=built,retainedRevision=built,
    frozenImage=remote+"/candidate",imageFiles={"reference":files,"candidate":hashes},
    auxiliaryFiles={name:value for name,value in hashes.items() if name!=core},
    coreSHA256={name:hashes[core] for name in ("candidate","candidate-control")},
    cpythonWorkerSHA256=prior["cpythonWorkerSHA256"],expectedCPythonSHA256=prior["expectedCPythonSHA256"],
    catalogs={name:dict(sha256=digest(lab/name)) for name in ("representative.json","jobs.json")}))

def install(name, donor, replacements):
    source=(donor/name).read_text(encoding="utf-8")
    for before,after in replacements:
        assert before in source, (name,before)
        source=source.replace(before,after)
    compile(source,name,"exec")
    (lab/name).write_text(source,encoding="utf-8",newline="\n")
install("collect.py",external,[
    ("len(jobs) == 6","len(jobs) == 8"),
    ("<305,","<400,"),
    ("CPython checkpoint for computed factory defaults","CPython checkpoint on retained supplied calls and factories"),
])
install("summarize.py",external,[("==6","==8")])
shutil.copyfile(external/"run.sh",lab/"run.sh")
assert b"\r" not in (lab/"run.sh").read_bytes()
payload=lab/"payload.tar.gz"
with tarfile.open(payload,"w:gz") as package:
    for name in ("identity.json","representative.json","jobs.json","run.sh","collect.py"):
        package.add(lab/name,arcname=name)
    package.add(image/core,arcname="candidate-core.dll")
write("upload.json",dict(root=remote.rsplit("/",1)[-1],reference="supplied-scalar-return-b1504-20261123",
                          payloadBytes=payload.stat().st_size,payloadSHA256=digest(payload)))

historical="benchmarks/results/2026-11-23-guarded-native-closed-entry/"
def pushed(name): return git("show","origin/master:"+historical+name)
old_terminal=json.loads(pushed("terminal-status.json"))["receipt"]
assert old_terminal["complete"] and old_terminal["archivedAndVerifiedUnderLease"]
assert sha(pushed("observations.tar.xz"))==old_terminal["archiveSHA256"]
old_files=json.loads(pushed("identity.json"))["imageFiles"]["candidate"]
assert len(old_files)==32 and all(digest(terminal/"candidate"/n)==h for n,h in old_files.items())
replica=gzip.decompress(pushed("candidate-core.dll.gz"))
assert sha(replica)==old_files[core]
retirement=dict(core=sha(replica),size=len(replica),archive=old_terminal["archiveSHA256"])
(lab/"quiet.py").write_text((terminal/"recovered-quiet.py").read_text(encoding="utf-8"),encoding="utf-8",newline="\n")
install("quiet.py",lab,[
    ('quiet=lab/"comparison/quiet"','quiet=lab'),
    ("lython-b1509-guarded-native-closed-entry-20261123","lython-b1510-retained-call-cpython-20261123"),
    (".+b1509-",".+b1510-"),
    ("lython-b1509-stage-","lython-b1510-stage-"),
    ("  assert free >= minimum,", """
  if free < minimum:
   proof=RETIREMENT_PROOF
   previous=base/'guarded-native-closed-entry-b1509-20261123'
   replica=previous/'candidate/Lokad.Lython.dll'
   info=replica.lstat()
   assert replica.resolve()==replica and stat.S_ISREG(info.st_mode)
   assert info.st_uid==os.getuid() and info.st_nlink==1 and info.st_size==proof['size']
   assert digest(replica)==proof['core']
   assert digest(previous/'observations.tar.xz')==proof['archive']
   assert not (previous/'guest-fixtures').exists()
   replica.unlink()
   free=shutil.disk_usage(base).free
   print(json.dumps(dict(retiredWorkingReplica=str(replica),sha256=proof['core'],freeAfterRetirement=free)),flush=True)
  assert free >= minimum,""".replace("RETIREMENT_PROOF",repr(retirement))),
    ("RuntimeMaxSec=350","RuntimeMaxSec=450"),
    ("seconds=298","seconds=395"),
])
