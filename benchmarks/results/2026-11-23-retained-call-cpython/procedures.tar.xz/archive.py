from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
dest = repo / "benchmarks/results/2026-11-23-retained-call-cpython"
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
identity = read(lab / "identity.json")
terminal = read(lab / "terminal-status.json")
receipt = terminal["receipt"]
assert not terminal["live"] and terminal["exitCode"] == "0" and not terminal["fixtures"]
assert all(receipt[name] for name in ("complete", "archivedAndVerifiedUnderLease", "allWorkersJoined", "guestFixturesRemoved", "quietBeforeAndAfter"))
assert sha((lab / "observations.tar.xz").read_bytes()) == receipt["archiveSHA256"]
assert read(lab / "summary.json")["timedBatches"] == 224
assert "needs one core, publication archive and working-room floor" in (lab / "first-stage.log").read_text(encoding="utf-8")
assert not subprocess.check_output(["git","diff","--name-only",identity["sourceRevision"],"HEAD",
    "--","src","tests","benchmarks/cpython-worker.py","benchmarks/Lokad.Lython.Benchmarks"],cwd=repo)
files = identity["imageFiles"]["candidate"]
assert len(files) == 32
assert all(sha((lab / "candidate" / name).read_bytes()) == digest for name, digest in files.items())
dest.mkdir(exist_ok=True)
assert all(path.name=="README.md" for path in dest.iterdir())
core = (lab / "candidate/Lokad.Lython.dll").read_bytes()
assert sha(core) == files["Lokad.Lython.dll"]
dll = dest / "candidate-core.dll.gz"
dll.write_bytes(gzip.compress(core, mtime=0))
assert sha(gzip.decompress(dll.read_bytes())) == files["Lokad.Lython.dll"]
for name in ("identity.json","observations.tar.xz", "summary.json", "terminal-status.json"):
    shutil.copyfile(lab / name, dest / name)
with tarfile.open(dest / "procedures.tar.xz", "w:xz") as archive:
    for name in ("archive.py","prepare.py","collect.py","quiet.py","first-quiet.py","recovered-quiet.py","run.sh",
                 "summarize.py","built-revision","windows-frozen.log","prepare.log","stage.log","first-stage.log",
                 "retrieval.log","candidate-verify.json","observe-not-before"):
        archive.add(lab / name, arcname=name)
print(dest,identity["sourceRevision"])
