for sample, chars in [
    ('', None),
    (' word ', None),
    (' 🚀aé　', None),
    ('🚀éhelloé🚀', '🚀é😀é'),
    ('éx😀é', 'é'),
    ('    ', ' '),
    ('🪐éa', ''),
    ('no change', '🚀😀'),
]:
    strip = sample.strip
    print(repr(sample.strip(chars)), repr(sample.lstrip(chars)),
          repr(sample.rstrip(chars)), repr(strip(chars)),
          repr(str.strip(sample, chars)), strip(chars) is sample)
for source in [' word ', '　aé️ ', 'unchanged']:
    print(repr(source.strip()), repr(source.lstrip()), repr(source.rstrip()))
for name, method in [('strip', 'a'.strip), ('lstrip', 'a'.lstrip), ('rstrip', 'a'.rstrip)]:
    try:
        method(7)
    except TypeError as error:
        print(name, str(error))
