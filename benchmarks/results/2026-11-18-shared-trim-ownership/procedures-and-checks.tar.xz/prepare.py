from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = Path('D:/code/Lython')
runner = lab.parent / 'native-index-bounds-r536'
candidate = repo / '.git/agent-worktrees/shared-strip-entry'
head = 'f7b1c056da2eb796abea5069a78e19cbd69f1e83'
core_name = 'Lokad.Lython.dll'
pinned = Path.home() / '.dotnet11'
dotnet = pinned / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(pinned), DOTNET_ROOT_X64=str(pinned),
           PATH=str(pinned) + os.pathsep + os.environ['PATH'])


def git(work, *args):
    return subprocess.check_output(['git', '-C', str(work), *args])


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n',
                    encoding='utf-8', newline='\n')


assert set(git(candidate, 'diff', '--name-only', head).decode().splitlines()) == {
    'src/Lokad.Lython/Runtime/LythonRuntime.StringMembers.Segmentation.cs',
    'src/Lokad.Lython/Runtime/Text/PyStringOps.Helpers.cs',
    'src/Lokad.Lython/Runtime/Text/PyStringOps.cs',
}
assert 'Build succeeded.' in (lab / 'build.log').read_text(encoding='utf-8-sig')
(lab / 'source.patch').write_bytes(git(candidate, 'diff', head, '--', 'src'))
donor = runner / 'frozen/candidate'
donor_hashes = read(runner / 'frozen-identity.json')['imageFiles']['candidate']
assert len(donor_hashes) == 32 and all(sha(donor / n) == digest for n, digest in donor_hashes.items())
images = {}
for role, tree in [('reference', None), ('candidate', candidate)]:
    frozen = lab / 'frozen' / role
    frozen.mkdir(parents=True)
    core = donor / core_name if tree is None else tree / 'src/Lokad.Lython/bin/Release/net11.0' / core_name
    if tree is not None:
        assert sha(core) == sha(tree / 'benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0' / core_name)
    for name in donor_hashes:
        shutil.copyfile(core if name == core_name else donor / name, frozen / name)
    for extra in donor.glob('ValidatedAllocation.*'):
        shutil.copyfile(extra, frozen / extra.name)
    images[role] = {name: sha(frozen / name) for name in donor_hashes}
    assert images[role] == donor_hashes | {core_name: sha(core)}
assert images['candidate'][core_name] != images['reference'][core_name]
cases = [
    ('scripts.text-normalization.helper-list', 'warm'),
    ('scripts.text-normalization.helper-list', 'compile-run'),
    ('scripts.text-normalization.large', 'warm'),
    ('calls.positional.large', 'warm'),
]
catalog_path = lab / 'representative.json'
shutil.copyfile(runner / 'representative.json', catalog_path)
assert sha(catalog_path) == read(runner / 'frozen-identity.json')['catalogSHA256']
assert {case for case, lane in cases} <= {row['id'] for row in read(catalog_path)['cases']}
write(lab / 'jobs.json', cases)
for role, hashes in images.items():
    frozen = lab / 'frozen' / role
    with (lab / (role + '-verification.log')).open('w', encoding='utf-8') as log:
        subprocess.run([dotnet, frozen / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify',
                        '--catalog', catalog_path, '--dotnet', dotnet, '--python', 'C:/Python313/python.exe',
                        '--python-worker', repo / 'benchmarks/cpython-worker.py', '--out',
                        lab / (role + '-verification.json')], cwd=repo, env=env, stdout=log,
                       stderr=subprocess.STDOUT, timeout=120, check=True)
    assert all(sha(frozen / n) == digest for n, digest in hashes.items())
    print(role, 'goldens passed', hashes[core_name], flush=True)
write(lab / 'frozen-identity.json', {
    'sourceRevision': 'f7b1c056d / 9eed03c9 versus isolated R538 trim entry',
    'purpose': 'Shared trim entry and scratch ownership across complete text scripts, with positional control',
    'imageFiles': images,
    'catalogSHA256': sha(catalog_path),
    'coreSHA256': {label: images[role][core_name] for role in images for label in (role, role + '-control')},
    'normalAdapterPin': '0.4.0',
})
