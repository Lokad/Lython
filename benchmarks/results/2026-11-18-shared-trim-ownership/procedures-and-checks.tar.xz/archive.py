from pathlib import Path
import gzip
import hashlib
import json
import shutil
import tarfile

repo = Path('D:/code/Lython')
lab = Path(__file__).resolve().parent
out = repo / 'benchmarks/results/2026-11-18-shared-trim-ownership'
out.mkdir()
source = lab / 'quiet'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
status = read(source / 'terminal-status.json')
receipt = status['receipt']
assert status['exitCode'] == '0' and not status['remainingTrace'] and not status['remainingWorkers']
assert receipt['jobs'] == 4 and receipt['complete'] and receipt['quietBeforeAndAfter']
assert receipt['archivedAndVerifiedUnderLease'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert sha(source / 'observations.tgz') == receipt['archiveSHA256']
for name in ('archive-receipt.json', 'terminal-status.json', 'observations.tgz'):
    shutil.copyfile(source / name, out / name)
summary = read(lab / 'summary.json')
summary['retentionDecisionPending'] = False
summary['decision'] = 'Retain shared trim dispatch and scratch ownership. The complete helper script is modestly faster; other elapsed controls are mixed.'
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8', newline='\n')
for name in ('allocation-summary.json', 'reference-verification.json', 'candidate-verification.json',
             'frozen-identity.json', 'source.patch'):
    shutil.copyfile(lab / name, out / name)
core = lab / 'frozen/candidate/Lokad.Lython.dll'
assert sha(core) == read(lab / 'frozen-identity.json')['imageFiles']['candidate'][core.name]
(out / 'candidate-core.dll.gz').write_bytes(gzip.compress(core.read_bytes(), mtime=0))
with tarfile.open(out / 'procedures-and-checks.tar.xz', 'w:xz') as archive:
    for name in ('prepare.py', 'stage.py', 'launch.py', 'summarize.py', 'archive.py',
                 'space.json', 'representative.json', 'jobs.json', 'build.log', 'trim-probe.py',
                 'reference-verification.log', 'candidate-verification.log',
                 'reference-allocation.json', 'candidate-allocation.json'):
        archive.add(lab / name, arcname=name)
    for check in sorted([*lab.glob('Lokad.*.log'), *lab.glob('trim-*.log')]):
        archive.add(check, arcname=check.name)
    for name in ('config.json', 'collect.py', 'archive-owned.py', 'run.sh', 'remote-launch.py',
                 'retrieve.py', 'launch.log'):
        archive.add(source / name, arcname='quiet/' + name)
