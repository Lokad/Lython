; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:TryConsumeBufferedCsvLine(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,System.Nullable`1[System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]],byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 144
       lea      rbp, [rsp+0x90]
       xor      eax, eax
       mov      qword ptr [rbp-0x68], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0039
       mov      rax, bword ptr [rbp+0x28]
       mov      dword ptr [rax], -1
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x6C]
       mov      dword ptr [rbp-0x04], eax
       lea      rdx, [rbp-0x18]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x78]
       call     [System.ReadOnlyMemory`1[byte]:get_Span():System.ReadOnlySpan`1[byte]:this]
       mov      eax, dword ptr [rbp-0x04]
       cmp      eax, dword ptr [rbp-0x10]
       jne      SHORT G_M000_IG04
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x006F
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x0078
       vmovdqu  xmm0, xmmword ptr [rbp-0x18]
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
 
G_M000_IG05:                ;; offset=0x0082
       lea      rcx, [rbp-0x40]
       mov      rax, gword ptr [rbp+0x10]
       mov      r8d, dword ptr [rax+0x58]
       mov      edx, dword ptr [rbp-0x04]
       call     [Lokad.Lython.Runtime.Text.TextLineScanning:FindLineEndByte(System.ReadOnlySpan`1[byte],int,int):int]
       mov      dword ptr [rbp-0x1C], eax
       mov      eax, dword ptr [rbp-0x1C]
       cmp      eax, dword ptr [rbp-0x10]
       jne      SHORT G_M000_IG07
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:EndsWithTerminator():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
       xor      eax, eax
 
G_M000_IG06:                ;; offset=0x00B2
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x00BB
       mov      rcx, gword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp-0x1C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:Advance(int):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x30]
       xor      rdx, rdx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      eax, dword ptr [rbp-0x04]
       mov      dword ptr [rbp-0x20], eax
       mov      eax, dword ptr [rbp-0x1C]
       mov      r9d, eax
       sub      r9d, dword ptr [rbp-0x20]
       lea      rcx, [rbp-0x18]
       lea      rdx, [rbp-0x30]
       mov      r8d, dword ptr [rbp-0x20]
       call     [System.ReadOnlySpan`1[byte]:Slice(int,int):System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG08:                ;; offset=0x00FC
       vmovdqu  xmm0, xmmword ptr [rbp-0x30]
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
 
G_M000_IG09:                ;; offset=0x0106
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG10:                ;; offset=0x010A
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x68], xmm0
       mov      rcx, qword ptr [rax+0x10]
       mov      qword ptr [rbp-0x58], rcx
 
G_M000_IG11:                ;; offset=0x011B
       lea      rdx, [rbp-0x50]
       lea      r8, [rbp-0x68]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:ConsumeBorrowedNativeLine(System.ReadOnlySpan`1[byte],System.Nullable`1[System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]):int:this]
       mov      rcx, bword ptr [rbp+0x28]
       mov      dword ptr [rcx], eax
       mov      eax, 1
 
G_M000_IG12:                ;; offset=0x013A
       add      rsp, 144
       pop      rbp
       ret      
 
; Total bytes of code 323

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:TryDescribeLiteralRecord(System.ReadOnlySpan`1[byte],byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 384
       lea      rbp, [rsp+0x180]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x150], xmm4
       vmovdqa  xmmword ptr [rbp-0x140], xmm4
       mov      rax, -240
 
G_M000_IG54:                ;; offset=0x002E
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG54
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
 
G_M000_IG02:                ;; offset=0x0056
       mov      dword ptr [rbp-0xDC], 0x3E8
       mov      rax, gword ptr [rbp+0x10]
       cmp      gword ptr [rax+0x50], 0
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x006B
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xD8], rax
       mov      rcx, gword ptr [rbp-0xD8]
       mov      rdx, 0x1C24A176428
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, gword ptr [rbp-0xD8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG04:                ;; offset=0x00A5
       mov      rax, bword ptr [rbp+0x20]
       xor      ecx, ecx
       mov      dword ptr [rax], ecx
       mov      rcx, bword ptr [rbp+0x18]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rcx, 0x7FF9D7966F08
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG45
 
G_M000_IG05:                ;; offset=0x00CF
       mov      rax, bword ptr [rbp+0x18]
       cmp      dword ptr [rax+0x08], 0
       jbe      G_M000_IG53
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       movzx    rax, byte  ptr [rax]
       mov      dword ptr [rbp-0x5C], eax
       cmp      dword ptr [rbp-0x5C], 10
       je       SHORT G_M000_IG07
       cmp      dword ptr [rbp-0x5C], 13
       jne      SHORT G_M000_IG10
 
G_M000_IG06:                ;; offset=0x00F6
       mov      rcx, 0x7FF9D7966F0C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG07:                ;; offset=0x0105
       mov      rcx, 0x7FF9D7966F10
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x18]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       lea      rdx, [rbp-0x88]
       mov      rcx, bword ptr [rbp+0x18]
       mov      r8d, 1
       call     [System.ReadOnlySpan`1[byte]:Slice(int):System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG08:                ;; offset=0x0143
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0xF0], xmm0
 
G_M000_IG09:                ;; offset=0x0153
       lea      rdx, [rbp-0xF0]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:ValidateRecordEnd(System.ReadOnlySpan`1[byte]):this]
       jmp      G_M000_IG45
 
G_M000_IG10:                ;; offset=0x0169
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x30]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       jne      SHORT G_M000_IG13
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG11:                ;; offset=0x0185
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
 
G_M000_IG12:                ;; offset=0x0192
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x0194
       mov      rcx, 0x7FF9D7966F14
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0x98]
       mov      rcx, gword ptr [rbp-0x50]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG14:                ;; offset=0x01B6
       vmovdqu  xmm0, xmmword ptr [rbp-0x98]
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
 
G_M000_IG15:                ;; offset=0x01C3
       lea      rcx, [rbp-0x48]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG16
       cmp      dword ptr [rbp-0x40], 0
       jbe      G_M000_IG53
       mov      rax, bword ptr [rbp-0x48]
       movzx    rax, byte  ptr [rax]
       mov      dword ptr [rbp-0x9C], eax
       jmp      SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x01EA
       mov      rcx, 0x7FF9D7966F18
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x9C], -1
 
G_M000_IG17:                ;; offset=0x0203
       mov      eax, dword ptr [rbp-0x9C]
       mov      dword ptr [rbp-0x54], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x60]
       cmp      eax, dword ptr [rbp-0x54]
       je       SHORT G_M000_IG19
       cmp      dword ptr [rbp-0x54], 10
       je       SHORT G_M000_IG22
       cmp      dword ptr [rbp-0x54], 13
       jne      SHORT G_M000_IG21
 
G_M000_IG18:                ;; offset=0x0224
       mov      rcx, 0x7FF9D7966F1C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG19:                ;; offset=0x0233
       mov      dword ptr [rbp-0x54], -1
 
G_M000_IG20:                ;; offset=0x023A
       xor      eax, eax
       mov      dword ptr [rbp-0x58], eax
       jmp      G_M000_IG48
 
G_M000_IG21:                ;; offset=0x0244
       mov      rcx, 0x7FF9D7966F20
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG20
 
G_M000_IG22:                ;; offset=0x0255
       mov      rcx, 0x7FF9D7966F24
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG19
 
G_M000_IG23:                ;; offset=0x0266
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x58]
       jle      G_M000_IG34
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x58], eax
       jae      G_M000_IG53
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x58]
       movzx    rax, byte  ptr [rax+rcx]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      eax, ecx
       jne      G_M000_IG33
       cmp      dword ptr [rbp-0x40], 1
       jne      G_M000_IG32
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG24:                ;; offset=0x02AD
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x100], xmm0
 
G_M000_IG25:                ;; offset=0x02B9
       lea      rdx, [rbp-0x100]
       mov      eax, dword ptr [rbp-0x58]
       lea      r8d, [rax+0x01]
       movzx    r9, byte  ptr [rbp-0x54]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:FindLiteralQuote(System.ReadOnlySpan`1[byte],int,byte):int:this]
       mov      dword ptr [rbp-0x78], eax
       cmp      dword ptr [rbp-0x78], 0
       jl       G_M000_IG31
       mov      eax, dword ptr [rbp-0x78]
       inc      eax
       mov      dword ptr [rbp-0x74], eax
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       jle      SHORT G_M000_IG27
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG53
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       movzx    rax, byte  ptr [rax+rcx]
       mov      rcx, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x60]
       cmp      eax, ecx
       je       G_M000_IG30
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG53
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       movzx    rax, byte  ptr [rax+rcx]
       mov      dword ptr [rbp-0x5C], eax
       cmp      dword ptr [rbp-0x5C], 10
       je       G_M000_IG29
       cmp      dword ptr [rbp-0x5C], 13
       jne      SHORT G_M000_IG28
 
G_M000_IG26:                ;; offset=0x0355
       mov      rcx, 0x7FF9D7966F28
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG27:                ;; offset=0x0364
       mov      rcx, 0x7FF9D7966F2C
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovups  xmmword ptr [rbp-0xD0], xmm0
       vxorps   xmm3, xmm3, xmm3
       lea      rcx, [rbp-0xD0]
       mov      eax, dword ptr [rbp-0x58]
       lea      edx, [rax+0x01]
       mov      eax, dword ptr [rbp-0x78]
       sub      eax, dword ptr [rbp-0x58]
       lea      r8d, [rax-0x01]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField:.ctor(int,int,double):this]
       vmovups  xmm0, xmmword ptr [rbp-0xD0]
       vmovups  xmmword ptr [rbp-0x110], xmm0
       lea      rdx, [rbp-0x110]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:DescribeField(Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField):this]
       jmp      G_M000_IG39
 
G_M000_IG28:                ;; offset=0x03C6
       mov      rcx, 0x7FF9D7966F30
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG51
 
G_M000_IG29:                ;; offset=0x03DA
       mov      rcx, 0x7FF9D7966F34
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG27
 
G_M000_IG30:                ;; offset=0x03EE
       mov      rcx, 0x7FF9D7966F38
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG27
 
G_M000_IG31:                ;; offset=0x0402
       mov      rcx, 0x7FF9D7966F3C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG51
 
G_M000_IG32:                ;; offset=0x0416
       mov      rcx, 0x7FF9D7966F40
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG51
 
G_M000_IG33:                ;; offset=0x042A
       mov      rcx, 0x7FF9D7966F44
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG34:                ;; offset=0x0439
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG35:                ;; offset=0x043D
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x120], xmm0
 
G_M000_IG36:                ;; offset=0x0449
       lea      rdx, [rbp-0x120]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8d, dword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:FindLiteralFieldEnd(System.ReadOnlySpan`1[byte],int):int:this]
       mov      dword ptr [rbp-0x74], eax
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG37:                ;; offset=0x0465
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x130], xmm0
 
G_M000_IG38:                ;; offset=0x0471
       mov      eax, dword ptr [rbp-0x74]
       sub      eax, dword ptr [rbp-0x58]
       mov      dword ptr [rsp+0x20], eax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      r8, [rbp-0x130]
       lea      rdx, [rbp-0xB0]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9d, dword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:CreateField(System.ReadOnlySpan`1[byte],int,int,bool):Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField:this]
       vmovups  xmm0, xmmword ptr [rbp-0xB0]
       vmovups  xmmword ptr [rbp-0x140], xmm0
       lea      rdx, [rbp-0x140]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:DescribeField(Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField):this]
 
G_M000_IG39:                ;; offset=0x04BE
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       jne      SHORT G_M000_IG40
       mov      rcx, 0x7FF9D7966F48
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG45
 
G_M000_IG40:                ;; offset=0x04DE
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG53
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       movzx    rax, byte  ptr [rax+rcx]
       mov      dword ptr [rbp-0x5C], eax
       cmp      dword ptr [rbp-0x5C], 10
       je       SHORT G_M000_IG42
       cmp      dword ptr [rbp-0x5C], 13
       jne      SHORT G_M000_IG47
 
G_M000_IG41:                ;; offset=0x050B
       mov      rcx, 0x7FF9D7966F4C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG42:                ;; offset=0x051A
       mov      rcx, 0x7FF9D7966F50
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0xC0]
       mov      eax, dword ptr [rbp-0x74]
       lea      r8d, [rax+0x01]
       mov      rcx, bword ptr [rbp+0x18]
       call     [System.ReadOnlySpan`1[byte]:Slice(int):System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG43:                ;; offset=0x0541
       vmovdqu  xmm0, xmmword ptr [rbp-0xC0]
       vmovdqu  xmmword ptr [rbp-0x150], xmm0
 
G_M000_IG44:                ;; offset=0x0551
       lea      rdx, [rbp-0x150]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:ValidateRecordEnd(System.ReadOnlySpan`1[byte]):this]
 
G_M000_IG45:                ;; offset=0x0562
       mov      eax, 1
 
G_M000_IG46:                ;; offset=0x0567
       add      rsp, 384
       pop      rbp
       ret      
 
G_M000_IG47:                ;; offset=0x0570
       mov      rcx, 0x7FF9D7966F54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x74]
       inc      eax
       mov      dword ptr [rbp-0x58], eax
 
G_M000_IG48:                ;; offset=0x0587
       mov      eax, dword ptr [rbp-0xDC]
       dec      eax
       mov      dword ptr [rbp-0xDC], eax
       cmp      dword ptr [rbp-0xDC], 0
       jg       SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x059E
       lea      rcx, [rbp-0xDC]
       mov      edx, 414
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG50:                ;; offset=0x05B1
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x20]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:get_Count():int:this]
       mov      dword ptr [rbp-0xA0], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x20]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:get_Capacity():int:this]
       cmp      eax, dword ptr [rbp-0xA0]
       jg       G_M000_IG23
 
G_M000_IG51:                ;; offset=0x05E3
       mov      rcx, 0x7FF9D7966F58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
       mov      ecx, dword ptr [rbp-0x58]
       mov      dword ptr [rax], ecx
       xor      eax, eax
 
G_M000_IG52:                ;; offset=0x05FD
       add      rsp, 384
       pop      rbp
       ret      
 
G_M000_IG53:                ;; offset=0x0606
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1548

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:TryConsumeBufferedCsvLine(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,System.Nullable`1[System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]],byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 144
       lea      rbp, [rsp+0x90]
       xor      eax, eax
       mov      qword ptr [rbp-0x68], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0039
       mov      rax, bword ptr [rbp+0x28]
       mov      dword ptr [rax], -1
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x6C]
       mov      dword ptr [rbp-0x04], eax
       lea      rdx, [rbp-0x18]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x78]
       call     [System.ReadOnlyMemory`1[byte]:get_Span():System.ReadOnlySpan`1[byte]:this]
       mov      eax, dword ptr [rbp-0x04]
       cmp      eax, dword ptr [rbp-0x10]
       jne      SHORT G_M000_IG04
       mov      rcx, 0x7FF9D7AADDF8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x007E
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x0087
       vmovdqu  xmm0, xmmword ptr [rbp-0x18]
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
 
G_M000_IG05:                ;; offset=0x0091
       lea      rcx, [rbp-0x40]
       mov      rax, gword ptr [rbp+0x10]
       mov      r8d, dword ptr [rax+0x58]
       mov      edx, dword ptr [rbp-0x04]
       call     [Lokad.Lython.Runtime.Text.TextLineScanning:FindLineEndByte(System.ReadOnlySpan`1[byte],int,int):int]
       mov      dword ptr [rbp-0x1C], eax
       mov      eax, dword ptr [rbp-0x1C]
       cmp      eax, dword ptr [rbp-0x10]
       jne      SHORT G_M000_IG08
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:EndsWithTerminator():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
       mov      rcx, 0x7FF9D7AADDFC
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG06:                ;; offset=0x00D0
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x00D9
       mov      rcx, 0x7FF9D7AADE00
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG08:                ;; offset=0x00E8
       mov      rcx, 0x7FF9D7AADE04
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp-0x1C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:Advance(int):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x30]
       xor      rdx, rdx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      eax, dword ptr [rbp-0x04]
       mov      dword ptr [rbp-0x20], eax
       mov      eax, dword ptr [rbp-0x1C]
       mov      r9d, eax
       sub      r9d, dword ptr [rbp-0x20]
       lea      rcx, [rbp-0x18]
       lea      rdx, [rbp-0x30]
       mov      r8d, dword ptr [rbp-0x20]
       call     [System.ReadOnlySpan`1[byte]:Slice(int,int):System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG09:                ;; offset=0x0138
       vmovdqu  xmm0, xmmword ptr [rbp-0x30]
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
 
G_M000_IG10:                ;; offset=0x0142
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG11:                ;; offset=0x0146
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x68], xmm0
       mov      rcx, qword ptr [rax+0x10]
       mov      qword ptr [rbp-0x58], rcx
 
G_M000_IG12:                ;; offset=0x0157
       lea      rdx, [rbp-0x50]
       lea      r8, [rbp-0x68]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:ConsumeBorrowedNativeLine(System.ReadOnlySpan`1[byte],System.Nullable`1[System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]):int:this]
       mov      rcx, bword ptr [rbp+0x28]
       mov      dword ptr [rcx], eax
       mov      eax, 1
 
G_M000_IG13:                ;; offset=0x0176
       add      rsp, 144
       pop      rbp
       ret      
 
; Total bytes of code 383

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:TryDescribeLiteralRecord(System.ReadOnlySpan`1[byte],byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 384
       lea      rbp, [rsp+0x180]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x150], xmm4
       vmovdqa  xmmword ptr [rbp-0x140], xmm4
       mov      rax, -240
 
G_M000_IG54:                ;; offset=0x002E
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG54
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
 
G_M000_IG02:                ;; offset=0x0056
       mov      dword ptr [rbp-0xDC], 0x3E8
       mov      rax, gword ptr [rbp+0x10]
       cmp      gword ptr [rax+0x50], 0
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x006B
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xD8], rax
       mov      rcx, gword ptr [rbp-0xD8]
       mov      rdx, 0x1C24A176428
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, gword ptr [rbp-0xD8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG04:                ;; offset=0x00A5
       mov      rax, bword ptr [rbp+0x20]
       xor      ecx, ecx
       mov      dword ptr [rax], ecx
       mov      rcx, bword ptr [rbp+0x18]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rcx, 0x7FF9D7966F08
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG45
 
G_M000_IG05:                ;; offset=0x00CF
       mov      rax, bword ptr [rbp+0x18]
       cmp      dword ptr [rax+0x08], 0
       jbe      G_M000_IG53
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       movzx    rax, byte  ptr [rax]
       mov      dword ptr [rbp-0x5C], eax
       cmp      dword ptr [rbp-0x5C], 10
       je       SHORT G_M000_IG07
       cmp      dword ptr [rbp-0x5C], 13
       jne      SHORT G_M000_IG10
 
G_M000_IG06:                ;; offset=0x00F6
       mov      rcx, 0x7FF9D7966F0C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG07:                ;; offset=0x0105
       mov      rcx, 0x7FF9D7966F10
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x18]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       lea      rdx, [rbp-0x88]
       mov      rcx, bword ptr [rbp+0x18]
       mov      r8d, 1
       call     [System.ReadOnlySpan`1[byte]:Slice(int):System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG08:                ;; offset=0x0143
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0xF0], xmm0
 
G_M000_IG09:                ;; offset=0x0153
       lea      rdx, [rbp-0xF0]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:ValidateRecordEnd(System.ReadOnlySpan`1[byte]):this]
       jmp      G_M000_IG45
 
G_M000_IG10:                ;; offset=0x0169
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x30]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       jne      SHORT G_M000_IG13
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG11:                ;; offset=0x0185
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
 
G_M000_IG12:                ;; offset=0x0192
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x0194
       mov      rcx, 0x7FF9D7966F14
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0x98]
       mov      rcx, gword ptr [rbp-0x50]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG14:                ;; offset=0x01B6
       vmovdqu  xmm0, xmmword ptr [rbp-0x98]
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
 
G_M000_IG15:                ;; offset=0x01C3
       lea      rcx, [rbp-0x48]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG16
       cmp      dword ptr [rbp-0x40], 0
       jbe      G_M000_IG53
       mov      rax, bword ptr [rbp-0x48]
       movzx    rax, byte  ptr [rax]
       mov      dword ptr [rbp-0x9C], eax
       jmp      SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x01EA
       mov      rcx, 0x7FF9D7966F18
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x9C], -1
 
G_M000_IG17:                ;; offset=0x0203
       mov      eax, dword ptr [rbp-0x9C]
       mov      dword ptr [rbp-0x54], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x60]
       cmp      eax, dword ptr [rbp-0x54]
       je       SHORT G_M000_IG19
       cmp      dword ptr [rbp-0x54], 10
       je       SHORT G_M000_IG22
       cmp      dword ptr [rbp-0x54], 13
       jne      SHORT G_M000_IG21
 
G_M000_IG18:                ;; offset=0x0224
       mov      rcx, 0x7FF9D7966F1C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG19:                ;; offset=0x0233
       mov      dword ptr [rbp-0x54], -1
 
G_M000_IG20:                ;; offset=0x023A
       xor      eax, eax
       mov      dword ptr [rbp-0x58], eax
       jmp      G_M000_IG48
 
G_M000_IG21:                ;; offset=0x0244
       mov      rcx, 0x7FF9D7966F20
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG20
 
G_M000_IG22:                ;; offset=0x0255
       mov      rcx, 0x7FF9D7966F24
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG19
 
G_M000_IG23:                ;; offset=0x0266
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x58]
       jle      G_M000_IG34
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x58], eax
       jae      G_M000_IG53
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x58]
       movzx    rax, byte  ptr [rax+rcx]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      eax, ecx
       jne      G_M000_IG33
       cmp      dword ptr [rbp-0x40], 1
       jne      G_M000_IG32
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG24:                ;; offset=0x02AD
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x100], xmm0
 
G_M000_IG25:                ;; offset=0x02B9
       lea      rdx, [rbp-0x100]
       mov      eax, dword ptr [rbp-0x58]
       lea      r8d, [rax+0x01]
       movzx    r9, byte  ptr [rbp-0x54]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:FindLiteralQuote(System.ReadOnlySpan`1[byte],int,byte):int:this]
       mov      dword ptr [rbp-0x78], eax
       cmp      dword ptr [rbp-0x78], 0
       jl       G_M000_IG31
       mov      eax, dword ptr [rbp-0x78]
       inc      eax
       mov      dword ptr [rbp-0x74], eax
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       jle      SHORT G_M000_IG27
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG53
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       movzx    rax, byte  ptr [rax+rcx]
       mov      rcx, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x60]
       cmp      eax, ecx
       je       G_M000_IG30
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG53
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       movzx    rax, byte  ptr [rax+rcx]
       mov      dword ptr [rbp-0x5C], eax
       cmp      dword ptr [rbp-0x5C], 10
       je       G_M000_IG29
       cmp      dword ptr [rbp-0x5C], 13
       jne      SHORT G_M000_IG28
 
G_M000_IG26:                ;; offset=0x0355
       mov      rcx, 0x7FF9D7966F28
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG27:                ;; offset=0x0364
       mov      rcx, 0x7FF9D7966F2C
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovups  xmmword ptr [rbp-0xD0], xmm0
       vxorps   xmm3, xmm3, xmm3
       lea      rcx, [rbp-0xD0]
       mov      eax, dword ptr [rbp-0x58]
       lea      edx, [rax+0x01]
       mov      eax, dword ptr [rbp-0x78]
       sub      eax, dword ptr [rbp-0x58]
       lea      r8d, [rax-0x01]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField:.ctor(int,int,double):this]
       vmovups  xmm0, xmmword ptr [rbp-0xD0]
       vmovups  xmmword ptr [rbp-0x110], xmm0
       lea      rdx, [rbp-0x110]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:DescribeField(Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField):this]
       jmp      G_M000_IG39
 
G_M000_IG28:                ;; offset=0x03C6
       mov      rcx, 0x7FF9D7966F30
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG51
 
G_M000_IG29:                ;; offset=0x03DA
       mov      rcx, 0x7FF9D7966F34
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG27
 
G_M000_IG30:                ;; offset=0x03EE
       mov      rcx, 0x7FF9D7966F38
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG27
 
G_M000_IG31:                ;; offset=0x0402
       mov      rcx, 0x7FF9D7966F3C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG51
 
G_M000_IG32:                ;; offset=0x0416
       mov      rcx, 0x7FF9D7966F40
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG51
 
G_M000_IG33:                ;; offset=0x042A
       mov      rcx, 0x7FF9D7966F44
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG34:                ;; offset=0x0439
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG35:                ;; offset=0x043D
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x120], xmm0
 
G_M000_IG36:                ;; offset=0x0449
       lea      rdx, [rbp-0x120]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8d, dword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:FindLiteralFieldEnd(System.ReadOnlySpan`1[byte],int):int:this]
       mov      dword ptr [rbp-0x74], eax
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG37:                ;; offset=0x0465
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x130], xmm0
 
G_M000_IG38:                ;; offset=0x0471
       mov      eax, dword ptr [rbp-0x74]
       sub      eax, dword ptr [rbp-0x58]
       mov      dword ptr [rsp+0x20], eax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      r8, [rbp-0x130]
       lea      rdx, [rbp-0xB0]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9d, dword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:CreateField(System.ReadOnlySpan`1[byte],int,int,bool):Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField:this]
       vmovups  xmm0, xmmword ptr [rbp-0xB0]
       vmovups  xmmword ptr [rbp-0x140], xmm0
       lea      rdx, [rbp-0x140]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:DescribeField(Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField):this]
 
G_M000_IG39:                ;; offset=0x04BE
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       jne      SHORT G_M000_IG40
       mov      rcx, 0x7FF9D7966F48
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG45
 
G_M000_IG40:                ;; offset=0x04DE
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG53
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       movzx    rax, byte  ptr [rax+rcx]
       mov      dword ptr [rbp-0x5C], eax
       cmp      dword ptr [rbp-0x5C], 10
       je       SHORT G_M000_IG42
       cmp      dword ptr [rbp-0x5C], 13
       jne      SHORT G_M000_IG47
 
G_M000_IG41:                ;; offset=0x050B
       mov      rcx, 0x7FF9D7966F4C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG42:                ;; offset=0x051A
       mov      rcx, 0x7FF9D7966F50
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0xC0]
       mov      eax, dword ptr [rbp-0x74]
       lea      r8d, [rax+0x01]
       mov      rcx, bword ptr [rbp+0x18]
       call     [System.ReadOnlySpan`1[byte]:Slice(int):System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG43:                ;; offset=0x0541
       vmovdqu  xmm0, xmmword ptr [rbp-0xC0]
       vmovdqu  xmmword ptr [rbp-0x150], xmm0
 
G_M000_IG44:                ;; offset=0x0551
       lea      rdx, [rbp-0x150]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:ValidateRecordEnd(System.ReadOnlySpan`1[byte]):this]
 
G_M000_IG45:                ;; offset=0x0562
       mov      eax, 1
 
G_M000_IG46:                ;; offset=0x0567
       add      rsp, 384
       pop      rbp
       ret      
 
G_M000_IG47:                ;; offset=0x0570
       mov      rcx, 0x7FF9D7966F54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x74]
       inc      eax
       mov      dword ptr [rbp-0x58], eax
 
G_M000_IG48:                ;; offset=0x0587
       mov      eax, dword ptr [rbp-0xDC]
       dec      eax
       mov      dword ptr [rbp-0xDC], eax
       cmp      dword ptr [rbp-0xDC], 0
       jg       SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x059E
       lea      rcx, [rbp-0xDC]
       mov      edx, 414
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG50:                ;; offset=0x05B1
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x20]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:get_Count():int:this]
       mov      dword ptr [rbp-0xA0], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x20]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:get_Capacity():int:this]
       cmp      eax, dword ptr [rbp-0xA0]
       jg       G_M000_IG23
 
G_M000_IG51:                ;; offset=0x05E3
       mov      rcx, 0x7FF9D7966F58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
       mov      ecx, dword ptr [rbp-0x58]
       mov      dword ptr [rax], ecx
       xor      eax, eax
 
G_M000_IG52:                ;; offset=0x05FD
       add      rsp, 384
       pop      rbp
       ret      
 
G_M000_IG53:                ;; offset=0x0606
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1548

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:TryConsumeBufferedCsvLine(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,System.Nullable`1[System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]],byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 149381
; 62 inlinees with PGO data; 114 single block inlinees; 4 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 408
       vmovaps  xmmword ptr [rsp+0x180], xmm6
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rsp+0x70], xmm4
       vmovdqa  xmmword ptr [rsp+0x80], xmm4
       mov      rax, -240
 
G_M000_IG153:                ;; offset=0x0039
       vmovdqa  xmmword ptr [rsp+rax+0x180], xmm4
       vmovdqa  xmmword ptr [rsp+rax+0x190], xmm4
       vmovdqa  xmmword ptr [rsp+rax+0x1A0], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG153
       mov      rsi, rcx
       mov      rdi, rdx
       mov      rbx, r8
       mov      rbp, r9
 
G_M000_IG02:                ;; offset=0x0066
       mov      bword ptr [rsp+0x1F8], rbp
       mov      dword ptr [rbp], -1
       mov      r14d, dword ptr [rsi+0x6C]
       lea      r15, bword ptr [rsi+0x78]
       xor      r13, r13
       xor      r12d, r12d
       mov      rcx, gword ptr [r15]
       test     rcx, rcx
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x008B
       mov      rdx, qword ptr [rcx]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       je       G_M000_IG78
       lea      r13, bword ptr [rcx+0x10]
       mov      r12d, dword ptr [rcx+0x08]
 
G_M000_IG04:                ;; offset=0x00A2
       mov      ecx, dword ptr [r15+0x08]
       and      ecx, 0x7FFFFFFF
       mov      r8d, dword ptr [r15+0x0C]
       mov      edx, r8d
       add      rdx, rcx
       mov      eax, r12d
       cmp      rdx, rax
       ja       G_M000_IG79
       add      r13, rcx
       mov      r12d, r8d
 
G_M000_IG05:                ;; offset=0x00C8
       cmp      r14d, r12d
       je       G_M000_IG80
 
G_M000_IG06:                ;; offset=0x00D1
       mov      bword ptr [rsp+0xA0], r13
       mov      dword ptr [rsp+0xA8], r12d
       lea      rcx, [rsp+0xA0]
       mov      r8d, dword ptr [rsi+0x58]
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.Text.TextLineScanning:FindLineEndByte(System.ReadOnlySpan`1[byte],int,int):int]
       mov      r15d, eax
       cmp      r15d, r12d
       je       G_M000_IG82
 
G_M000_IG07:                ;; offset=0x0102
       lea      rax, bword ptr [rsi+0x78]
       mov      bword ptr [rsp+0x68], rax
       mov      rcx, gword ptr [rax]
       test     rcx, rcx
       je       SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0113
       mov      rdx, qword ptr [rcx]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       je       G_M000_IG83
       mov      r8d, dword ptr [rcx+0x08]
 
G_M000_IG09:                ;; offset=0x0126
       mov      rax, bword ptr [rsp+0x68]
       mov      ecx, dword ptr [rax+0x08]
       and      ecx, 0x7FFFFFFF
       mov      edx, dword ptr [rax+0x0C]
       add      rcx, rdx
       mov      edx, r8d
       cmp      rcx, rdx
       ja       G_M000_IG79
 
G_M000_IG10:                ;; offset=0x0146
       mov      ecx, r15d
       sub      ecx, dword ptr [rsi+0x6C]
       movsxd   rcx, ecx
       add      qword ptr [rsi+0x48], rcx
       mov      dword ptr [rsi+0x6C], r15d
       mov      rcx, gword ptr [rsi+0x30]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG85
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG84
 
G_M000_IG11:                ;; offset=0x017D
       sub      r15d, r14d
       mov      ecx, r14d
       mov      edx, r15d
       add      rcx, rdx
       mov      edx, r12d
       cmp      rcx, rdx
       ja       G_M000_IG79
       mov      esi, r14d
       add      rsi, r13
       mov      rcx, gword ptr [rdi+0x28]
       mov      rdx, gword ptr [rdi+0x30]
       mov      rcx, gword ptr [rcx+0x98]
       mov      rax, gword ptr [rcx+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG87
       mov      rax, gword ptr [rcx+0x180]
       test     rax, rax
       jne      G_M000_IG86
 
G_M000_IG12:                ;; offset=0x01CC
       inc      dword ptr [rdi+0x3C]
       mov      rdi, gword ptr [rdi+0x08]
       cmp      gword ptr [rdi+0x50], 0
       jne      G_M000_IG88
       test     r15d, r15d
       je       G_M000_IG62
       movzx    r14, byte  ptr [rsi]
       cmp      r14d, 10
       je       G_M000_IG89
       cmp      r14d, 13
       je       G_M000_IG89
       mov      r14, gword ptr [rdi+0x30]
       test     r14, r14
       je       SHORT G_M000_IG19
 
G_M000_IG13:                ;; offset=0x0208
       movzx    rdx, byte  ptr [r14+0x24]
       test     edx, edx
       je       G_M000_IG91
 
G_M000_IG14:                ;; offset=0x0215
       cmp      edx, 255
       je       G_M000_IG95
       lea      rax, bword ptr [r14+0x28]
       mov      r13d, dword ptr [r14+0x18]
       cmp      r13d, 8
       ja       G_M000_IG79
 
G_M000_IG15:                ;; offset=0x0233
       mov      dword ptr [rsp+0xB8], r13d
       test     r13d, r13d
       je       G_M000_IG98
       movzx    r14, byte  ptr [rax]
 
G_M000_IG16:                ;; offset=0x0248
       cmp      r14d, dword ptr [rdi+0x60]
       je       SHORT G_M000_IG20
 
G_M000_IG17:                ;; offset=0x024E
       cmp      r14d, 10
       je       SHORT G_M000_IG20
       cmp      r14d, 13
       je       SHORT G_M000_IG20
 
G_M000_IG18:                ;; offset=0x025A
       xor      r12d, r12d
       mov      rcx, gword ptr [rdi+0x20]
       mov      edx, dword ptr [rcx+0x10]
       mov      rcx, gword ptr [rcx+0x08]
       cmp      edx, dword ptr [rcx+0x08]
       jge      G_M000_IG137
       jmp      G_M000_IG33
 
G_M000_IG19:                ;; offset=0x0276
       xor      rax, rax
       xor      r13d, r13d
       jmp      SHORT G_M000_IG15
 
G_M000_IG20:                ;; offset=0x027D
       mov      r14d, -1
       jmp      SHORT G_M000_IG18
       align    [0 bytes for IG47]
 
G_M000_IG21:                ;; offset=0x0285
       cmp      r13d, 1
       jne      G_M000_IG137
       lea      eax, [r12+0x01]
       mov      dword ptr [rsp+0x124], eax
       cmp      eax, r15d
       jge      G_M000_IG102
 
G_M000_IG22:                ;; offset=0x02A4
       mov      rcx, gword ptr [rdi+0x10]
       mov      rdx, gword ptr [rdi+0x18]
       mov      rcx, gword ptr [rcx+0x98]
       mov      r8, gword ptr [rcx+0x88]
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG100
       mov      r8, gword ptr [rcx+0x180]
       test     r8, r8
       jne      G_M000_IG99
 
G_M000_IG23:                ;; offset=0x02D5
       mov      eax, dword ptr [rsp+0x124]
       mov      r10d, r15d
       sub      r10d, eax
       cmp      r10d, 0x1000
       jge      G_M000_IG69
 
G_M000_IG24:                ;; offset=0x02EF
       mov      ecx, eax
       mov      edx, r10d
       add      rcx, rdx
       mov      edx, r15d
       cmp      rcx, rdx
       ja       G_M000_IG79
       mov      dword ptr [rsp+0x124], eax
       mov      ecx, eax
       add      rcx, rsi
       movzx    rdx, r14b
       mov      dword ptr [rsp+0x120], r10d
       mov      r8d, r10d
       call     [System.SpanHelpers:NonPackedIndexOfValueType[byte,System.SpanHelpers+DontNegate`1[byte]](byref,byte,int):int]
       test     eax, eax
       jl       G_M000_IG101
       mov      edx, dword ptr [rsp+0x124]
       add      eax, edx
 
G_M000_IG25:                ;; offset=0x0335
       test     eax, eax
       jl       G_M000_IG137
       lea      r8d, [rax+0x01]
       cmp      r8d, r15d
       jge      SHORT G_M000_IG28
 
G_M000_IG26:                ;; offset=0x0346
       cmp      r8d, r15d
       jae      G_M000_IG151
       mov      dword ptr [rsp+0x138], r8d
       mov      edx, r8d
       movzx    rdx, byte  ptr [rsi+rdx]
       cmp      edx, dword ptr [rdi+0x60]
       je       G_M000_IG70
 
G_M000_IG27:                ;; offset=0x0367
       cmp      edx, 10
       jne      G_M000_IG103
       mov      r8d, dword ptr [rsp+0x138]
 
G_M000_IG28:                ;; offset=0x0378
       lea      edx, [r12+0x01]
       sub      eax, r12d
       lea      r12d, [rax-0x01]
       mov      rcx, gword ptr [rdi+0x20]
       inc      dword ptr [rcx+0x14]
       mov      rax, gword ptr [rcx+0x08]
       mov      r10d, dword ptr [rcx+0x10]
       cmp      dword ptr [rax+0x08], r10d
       jbe      G_M000_IG104
       lea      r9d, [r10+0x01]
       mov      dword ptr [rcx+0x10], r9d
       mov      ecx, r10d
       shl      rcx, 4
       lea      rcx, bword ptr [rax+rcx+0x10]
       mov      dword ptr [rcx], edx
       mov      dword ptr [rcx+0x04], r12d
       xor      edx, edx
       mov      qword ptr [rcx+0x08], rdx
 
G_M000_IG29:                ;; offset=0x03BD
       test     r12d, r12d
       je       G_M000_IG105
       movsxd   rcx, r12d
       add      rcx, 128
       add      rcx, qword ptr [rdi+0x58]
       jo       G_M000_IG152
       mov      qword ptr [rdi+0x58], rcx
       cmp      r12d, 8
       jg       G_M000_IG71
 
G_M000_IG30:                ;; offset=0x03E8
       mov      dword ptr [rsp+0x138], r8d
 
G_M000_IG31:                ;; offset=0x03F0
       mov      eax, dword ptr [rsp+0x138]
       cmp      eax, r15d
       je       G_M000_IG62
       cmp      eax, r15d
       jae      G_M000_IG151
       mov      ecx, eax
       movzx    rdx, byte  ptr [rsi+rcx]
       cmp      edx, 10
       je       G_M000_IG61
 
G_M000_IG32:                ;; offset=0x0418
       cmp      edx, 13
       je       G_M000_IG61
       lea      r12d, [rax+0x01]
       mov      rcx, gword ptr [rdi+0x20]
       mov      eax, dword ptr [rcx+0x10]
       mov      rcx, gword ptr [rcx+0x08]
       cmp      eax, dword ptr [rcx+0x08]
       mov      r13d, dword ptr [rsp+0xB8]
       jge      G_M000_IG137
 
G_M000_IG33:                ;; offset=0x0441
       cmp      r12d, r15d
       jge      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x0446
       mov      ecx, r12d
       movzx    rcx, byte  ptr [rsi+rcx]
       cmp      ecx, r14d
       je       G_M000_IG21
 
G_M000_IG35:                ;; offset=0x0456
       mov      eax, r12d
       mov      dword ptr [rsp+0x11C], eax
       cmp      eax, r15d
       jge      G_M000_IG109
 
G_M000_IG36:                ;; offset=0x0469
       mov      rcx, gword ptr [rdi+0x10]
       mov      rdx, gword ptr [rdi+0x18]
       mov      rcx, gword ptr [rcx+0x98]
       mov      r8, gword ptr [rcx+0x88]
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG107
       mov      r8, gword ptr [rcx+0x180]
       test     r8, r8
       jne      G_M000_IG106
 
G_M000_IG37:                ;; offset=0x049A
       mov      eax, dword ptr [rsp+0x11C]
       mov      r10d, r15d
       sub      r10d, eax
       cmp      r10d, 0x1000
       jge      G_M000_IG72
 
G_M000_IG38:                ;; offset=0x04B4
       mov      r9d, eax
       mov      edx, r10d
       add      r9, rdx
       mov      edx, r15d
       cmp      r9, rdx
       ja       G_M000_IG79
       mov      dword ptr [rsp+0x11C], eax
       mov      ecx, eax
       add      rcx, rsi
       mov      r11, gword ptr [rdi+0x40]
       test     r11, r11
       je       G_M000_IG130
       mov      r9, 0x7FF9D749EAE8
       cmp      qword ptr [r11], r9
       jne      G_M000_IG73
 
G_M000_IG39:                ;; offset=0x04F5
       mov      dword ptr [rsp+0x118], r10d
       mov      dword ptr [rsp+0x20], r10d
       movzx    r9, byte  ptr [r11+0x0A]
       movzx    rdx, byte  ptr [r11+0x08]
       movzx    r8, byte  ptr [r11+0x09]
       call     [System.SpanHelpers:NonPackedIndexOfAnyValueType[byte,System.SpanHelpers+DontNegate`1[byte]](byref,byte,byte,byte,int):int]
 
G_M000_IG40:                ;; offset=0x0517
       test     eax, eax
       jl       G_M000_IG108
       mov      ecx, dword ptr [rsp+0x11C]
       add      eax, ecx
       mov      r8d, eax
 
G_M000_IG41:                ;; offset=0x052B
       mov      eax, r8d
       mov      dword ptr [rsp+0x138], eax
       mov      r8d, eax
       sub      r8d, r12d
       mov      rcx, gword ptr [rdi+0x08]
       cmp      dword ptr [rcx+0x28], 2
       jne      G_M000_IG110
 
G_M000_IG42:                ;; offset=0x0549
       test     r8d, r8d
       je       G_M000_IG110
       mov      ecx, r12d
       mov      edx, r8d
       add      rcx, rdx
       mov      edx, r15d
       cmp      rcx, rdx
       ja       G_M000_IG79
       mov      r12d, r12d
       add      r12, rsi
       mov      dword ptr [rsp+0xB4], r8d
       mov      r9, gword ptr [rdi+0x10]
       mov      gword ptr [rsp+0x60], r9
       mov      r11, gword ptr [rdi+0x18]
       mov      gword ptr [rsp+0x58], r11
       xor      ecx, ecx
       mov      qword ptr [rsp+0x100], rcx
 
G_M000_IG43:                ;; offset=0x0591
       mov      qword ptr [rsp+0xF0], rcx
 
G_M000_IG44:                ;; offset=0x0599
       mov      dword ptr [rsp+0xE8], ecx
       mov      rcx, gword ptr [r9+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG112
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG111
 
G_M000_IG45:                ;; offset=0x05C9
       mov      r10d, dword ptr [rsp+0xB4]
       mov      dword ptr [rsp+0xB0], r10d
       movzx    rdx, byte  ptr [r12]
       cmp      edx, 45
       sete     r8b
       movzx    r8, r8b
       cmp      edx, 43
       je       G_M000_IG114
       cmp      edx, 45
       setne    dl
       movzx    rdx, dl
 
G_M000_IG46:                ;; offset=0x05FB
       test     edx, edx
       sete     dl
       movzx    rdx, dl
       mov      r11d, r10d
       sub      r11d, edx
       mov      r13d, r11d
       sub      r13d, 1
       cmp      r13d, 16
       ja       G_M000_IG113
       xor      r13d, r13d
       mov      ebp, -1
       cmp      edx, r10d
       jge      SHORT G_M000_IG50
 
G_M000_IG47:                ;; offset=0x0627
       movzx    rcx, byte  ptr [r12+rdx]
       add      ecx, -48
       cmp      ecx, 9
       ja       G_M000_IG74
 
G_M000_IG48:                ;; offset=0x0638
       lea      r13, [r13+4*r13]
       mov      ecx, ecx
       lea      r13, [rcx+2*r13]
 
G_M000_IG49:                ;; offset=0x0643
       inc      edx
       cmp      edx, r10d
       jl       SHORT G_M000_IG47
 
G_M000_IG50:                ;; offset=0x064A
       cmp      r11d, 1
       je       G_M000_IG75
 
G_M000_IG51:                ;; offset=0x0654
       mov      rcx, 0x20000000000000
       cmp      r13, rcx
       ja       G_M000_IG113
       test     ebp, ebp
       jl       G_M000_IG76
 
G_M000_IG52:                ;; offset=0x066F
       mov      ecx, dword ptr [rsp+0xB0]
       sub      ecx, ebp
       dec      ecx
 
G_M000_IG53:                ;; offset=0x067A
       vxorps   xmm0, xmm0, xmm0
       mov      r10, r13
       shr      r10, 1
       mov      edx, r13d
       and      edx, 1
       or       rdx, r10
       test     r13, r13
       cmovns   rdx, r13
       vcvtsi2sd xmm0, rdx
       jns      SHORT G_M000_IG54
       vaddsd   xmm0, xmm0
 
G_M000_IG54:                ;; offset=0x069F
       cmp      ecx, 19
       jae      G_M000_IG151
       mov      ecx, ecx
       mov      rdx, 0x1E23F93C0E8
       vdivsd   xmm6, xmm0, qword ptr [rdx+8*rcx]
       test     r8d, r8d
       jne      G_M000_IG77
 
G_M000_IG55:                ;; offset=0x06C2
       mov      r9, gword ptr [rsp+0x60]
       mov      rcx, gword ptr [r9+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG116
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG115
 
G_M000_IG56:                ;; offset=0x06F0
       mov      r12d, -1
       xor      r13d, r13d
 
G_M000_IG57:                ;; offset=0x06F9
       mov      rcx, gword ptr [rdi+0x20]
       inc      dword ptr [rcx+0x14]
       mov      rdx, gword ptr [rcx+0x08]
       mov      r8d, dword ptr [rcx+0x10]
       cmp      dword ptr [rdx+0x08], r8d
       jbe      G_M000_IG129
       lea      r10d, [r8+0x01]
       mov      dword ptr [rcx+0x10], r10d
       mov      ecx, r8d
       shl      rcx, 4
       lea      rdx, bword ptr [rdx+rcx+0x10]
       mov      dword ptr [rdx], r12d
       mov      dword ptr [rdx+0x04], r13d
       vmovsd   qword ptr [rdx+0x08], xmm6
 
G_M000_IG58:                ;; offset=0x0732
       test     r12d, r12d
       jl       G_M000_IG31
 
G_M000_IG59:                ;; offset=0x073B
       test     r13d, r13d
       je       G_M000_IG31
       movsxd   rcx, r13d
       add      rcx, 128
       add      rcx, qword ptr [rdi+0x58]
       jo       G_M000_IG152
       mov      qword ptr [rdi+0x58], rcx
       cmp      r13d, 8
       jle      G_M000_IG31
 
G_M000_IG60:                ;; offset=0x0766
       add      r13d, dword ptr [rdi+0x68]
       jo       G_M000_IG152
       mov      dword ptr [rdi+0x68], r13d
       jmp      G_M000_IG31
 
G_M000_IG61:                ;; offset=0x0779
       lea      ecx, [rax+0x01]
       cmp      ecx, r15d
       ja       G_M000_IG79
       mov      r14d, ecx
       add      r14, rsi
       mov      r13d, r15d
       sub      r13d, ecx
       xor      r12d, r12d
       cmp      r12d, r13d
       jl       G_M000_IG132
 
G_M000_IG62:                ;; offset=0x079D
       movzx    rdx, byte  ptr [rbx]
       mov      rcx, gword ptr [rbx+0x08]
       mov      r14d, dword ptr [rbx+0x10]
       mov      ebx, dword ptr [rbx+0x14]
       test     edx, edx
       je       G_M000_IG139
 
G_M000_IG63:                ;; offset=0x07B3
       xor      r13, r13
       xor      r12d, r12d
       test     rcx, rcx
       je       SHORT G_M000_IG66
 
G_M000_IG64:                ;; offset=0x07BE
       mov      rdx, qword ptr [rcx]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       je       G_M000_IG138
       lea      r13, bword ptr [rcx+0x10]
       mov      r12d, dword ptr [rcx+0x08]
 
G_M000_IG65:                ;; offset=0x07D5
       and      r14d, 0x7FFFFFFF
       mov      edx, r14d
       mov      r8d, ebx
       add      r8, rdx
       mov      ecx, r12d
       cmp      r8, rcx
       ja       G_M000_IG79
       shl      rdx, 4
       add      r13, rdx
       mov      r12d, ebx
 
G_M000_IG66:                ;; offset=0x07FB
       mov      bword ptr [rsp+0xA0], rsi
       mov      dword ptr [rsp+0xA8], r15d
       mov      bword ptr [rsp+0x70], r13
       mov      dword ptr [rsp+0x78], r12d
       lea      rdx, [rsp+0xA0]
       lea      r8, [rsp+0x70]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:UnpackRecord(System.ReadOnlySpan`1[byte],System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int:this]
       mov      r14d, eax
 
G_M000_IG67:                ;; offset=0x082E
       mov      rbp, bword ptr [rsp+0x1F8]
       mov      dword ptr [rbp], r14d
       mov      eax, 1
 
G_M000_IG68:                ;; offset=0x083F
       vmovaps  xmm6, xmmword ptr [rsp+0x180]
       add      rsp, 408
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG69:                ;; offset=0x085C
       mov      r10d, 0x1000
       jmp      G_M000_IG24
 
G_M000_IG70:                ;; offset=0x0867
       mov      r8d, dword ptr [rsp+0x138]
       jmp      G_M000_IG28
 
G_M000_IG71:                ;; offset=0x0874
       add      r12d, dword ptr [rdi+0x68]
       jo       G_M000_IG152
       mov      dword ptr [rdi+0x68], r12d
       mov      dword ptr [rsp+0x138], r8d
       jmp      G_M000_IG31
 
G_M000_IG72:                ;; offset=0x088F
       mov      r10d, 0x1000
       jmp      G_M000_IG38
 
G_M000_IG73:                ;; offset=0x089A
       mov      bword ptr [rsp+0xA0], rcx
       mov      dword ptr [rsp+0x118], r10d
       mov      dword ptr [rsp+0xA8], r10d
       lea      rdx, [rsp+0xA0]
       mov      rcx, r11
       mov      r8, qword ptr [r11]
       mov      r8, qword ptr [r8+0x40]
       call     [r8+0x30]System.Buffers.SearchValues`1[byte]:IndexOfAny(System.ReadOnlySpan`1[byte]):int:this
       jmp      G_M000_IG40
 
G_M000_IG74:                ;; offset=0x08CD
       cmp      byte  ptr [r12+rdx], 46
       jne      G_M000_IG113
       test     ebp, ebp
       jge      G_M000_IG113
       mov      ebp, edx
       jmp      G_M000_IG49
 
G_M000_IG75:                ;; offset=0x08E7
       test     ebp, ebp
       jge      G_M000_IG113
       jmp      G_M000_IG51
 
G_M000_IG76:                ;; offset=0x08F4
       xor      ecx, ecx
       jmp      G_M000_IG53
 
G_M000_IG77:                ;; offset=0x08FB
       vxorps   xmm6, xmm6, xmmword ptr [reloc @RWD00]
       jmp      G_M000_IG55
 
G_M000_IG78:                ;; offset=0x0908
       lea      rdx, [rsp+0x170]
       mov      rax, qword ptr [rcx]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[byte]:GetSpan():System.Span`1[byte]:this
       mov      r13, bword ptr [rsp+0x170]
       mov      r12d, dword ptr [rsp+0x178]
       jmp      G_M000_IG04
 
G_M000_IG79:                ;; offset=0x092F
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG80:                ;; offset=0x0936
       xor      eax, eax
 
G_M000_IG81:                ;; offset=0x0938
       vmovaps  xmm6, xmmword ptr [rsp+0x180]
       add      rsp, 408
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG82:                ;; offset=0x0955
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:EndsWithTerminator():bool:this]
       test     eax, eax
       jne      G_M000_IG07
       jmp      SHORT G_M000_IG80
 
G_M000_IG83:                ;; offset=0x0968
       lea      rdx, [rsp+0x160]
       mov      r8, qword ptr [rcx]
       mov      r8, qword ptr [r8+0x40]
       call     [r8+0x28]System.Buffers.MemoryManager`1[byte]:GetSpan():System.Span`1[byte]:this
       mov      r8d, dword ptr [rsp+0x168]
       jmp      G_M000_IG09
 
G_M000_IG84:                ;; offset=0x0988
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG11
 
G_M000_IG85:                ;; offset=0x099A
       xor      rdx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG11
 
G_M000_IG86:                ;; offset=0x09A7
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG12
 
G_M000_IG87:                ;; offset=0x09B9
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG12
 
G_M000_IG88:                ;; offset=0x09C4
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1C24A176428
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG89:                ;; offset=0x09F2
       mov      rcx, gword ptr [rdi+0x10]
       mov      r14, gword ptr [rdi+0x18]
       mov      r13, gword ptr [rcx+0x98]
       cmp      byte  ptr [r13], r13b
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG90
       mov      rcx, r13
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG90:                ;; offset=0x0A1E
       lea      rdx, bword ptr [rsi+0x01]
       lea      ecx, [r15-0x01]
       mov      bword ptr [rsp+0xA0], rdx
       mov      dword ptr [rsp+0xA8], ecx
       lea      rdx, [rsp+0xA0]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:ValidateRecordEnd(System.ReadOnlySpan`1[byte]):this]
       jmp      G_M000_IG62
 
G_M000_IG91:                ;; offset=0x0A4B
       mov      rax, gword ptr [r14+0x08]
       mov      r13d, dword ptr [r14+0x18]
       test     rax, rax
       jne      SHORT G_M000_IG93
 
G_M000_IG92:                ;; offset=0x0A58
       test     r13d, r13d
       jne      G_M000_IG79
       xor      rax, rax
       xor      r13d, r13d
       jmp      SHORT G_M000_IG94
 
G_M000_IG93:                ;; offset=0x0A68
       cmp      dword ptr [rax+0x08], r13d
       jb       G_M000_IG79
       add      rax, 16
 
G_M000_IG94:                ;; offset=0x0A76
       jmp      G_M000_IG15
 
G_M000_IG95:                ;; offset=0x0A7B
       mov      rdx, gword ptr [r14+0x08]
       lea      rcx, bword ptr [r14+0x28]
       mov      ecx, dword ptr [rcx]
       mov      eax, dword ptr [r14+0x18]
       test     rdx, rdx
       jne      SHORT G_M000_IG96
       or       ecx, eax
       jne      G_M000_IG79
       xor      rdx, rdx
       xor      eax, eax
       jmp      SHORT G_M000_IG97
 
G_M000_IG96:                ;; offset=0x0A9C
       mov      r8d, ecx
       mov      r10d, eax
       add      r8, r10
       mov      r10d, dword ptr [rdx+0x08]
       cmp      r8, r10
       ja       G_M000_IG79
       mov      ecx, ecx
       lea      rdx, bword ptr [rdx+rcx+0x10]
 
G_M000_IG97:                ;; offset=0x0AB9
       mov      bword ptr [rsp+0x90], rdx
       mov      dword ptr [rsp+0x98], eax
       lea      rdx, [rsp+0x90]
       lea      rcx, [rsp+0x128]
       call     [System.Span`1[byte]:op_Implicit(System.Span`1[byte]):System.ReadOnlySpan`1[byte]]
       mov      rax, bword ptr [rsp+0x128]
       mov      r13d, dword ptr [rsp+0x130]
       jmp      G_M000_IG15
 
G_M000_IG98:                ;; offset=0x0AF3
       mov      r14d, -1
       jmp      G_M000_IG16
 
G_M000_IG99:                ;; offset=0x0AFE
       cmp      dword ptr [r8+0x20], 0
       setne    r8b
       movzx    r8, r8b
       test     r8d, r8d
       je       G_M000_IG23
 
G_M000_IG100:                ;; offset=0x0B14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG23
 
G_M000_IG101:                ;; offset=0x0B1F
       mov      eax, dword ptr [rsp+0x124]
       add      eax, dword ptr [rsp+0x120]
       cmp      eax, r15d
       mov      dword ptr [rsp+0x124], eax
       jl       G_M000_IG22
 
G_M000_IG102:                ;; offset=0x0B3D
       mov      eax, -1
       jmp      G_M000_IG25
 
G_M000_IG103:                ;; offset=0x0B47
       cmp      edx, 13
       mov      r8d, dword ptr [rsp+0x138]
       jne      G_M000_IG137
       jmp      G_M000_IG28
 
G_M000_IG104:                ;; offset=0x0B5D
       mov      dword ptr [rsp+0x138], r8d
       mov      dword ptr [rsp+0x80], edx
       mov      dword ptr [rsp+0x84], r12d
       xor      edx, edx
       mov      qword ptr [rsp+0x88], rdx
       lea      rdx, [rsp+0x80]
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:AddWithResize(Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField):this]
       mov      r8d, dword ptr [rsp+0x138]
       jmp      G_M000_IG29
 
G_M000_IG105:                ;; offset=0x0B99
       mov      dword ptr [rsp+0x138], r8d
       jmp      G_M000_IG31
 
G_M000_IG106:                ;; offset=0x0BA6
       cmp      dword ptr [r8+0x20], 0
       setne    r8b
       movzx    r8, r8b
       test     r8d, r8d
       je       G_M000_IG37
 
G_M000_IG107:                ;; offset=0x0BBC
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG37
 
G_M000_IG108:                ;; offset=0x0BC7
       mov      eax, dword ptr [rsp+0x11C]
       add      eax, dword ptr [rsp+0x118]
       cmp      eax, r15d
       mov      dword ptr [rsp+0x11C], eax
       jl       G_M000_IG36
 
G_M000_IG109:                ;; offset=0x0BE5
       mov      eax, dword ptr [rsp+0x11C]
       mov      r8d, eax
       jmp      G_M000_IG41
 
G_M000_IG110:                ;; offset=0x0BF4
       vxorps   xmm6, xmm6, xmm6
       mov      r13d, r8d
       jmp      G_M000_IG57
 
G_M000_IG111:                ;; offset=0x0C00
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG45
 
G_M000_IG112:                ;; offset=0x0C12
       mov      rdx, r11
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      r11, gword ptr [rsp+0x58]
       jmp      G_M000_IG45
 
G_M000_IG113:                ;; offset=0x0C25
       mov      bword ptr [rsp+0xA0], r12
       mov      dword ptr [rsp+0xA8], r10d
       mov      r13, gword ptr [rsp+0x58]
       mov      gword ptr [rsp+0x20], r13
       lea      rdx, [rsp+0xA0]
       lea      rcx, [rsp+0x108]
       mov      r8d, 1
       mov      r9, gword ptr [rsp+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TrimNumericWhitespace(System.ReadOnlySpan`1[byte],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.ReadOnlySpan`1[byte]]
       mov      ecx, dword ptr [rsp+0x110]
       test     ecx, ecx
       jle      G_M000_IG120
       jmp      SHORT G_M000_IG117
 
G_M000_IG114:                ;; offset=0x0C71
       xor      edx, edx
       jmp      G_M000_IG46
 
G_M000_IG115:                ;; offset=0x0C78
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG56
 
G_M000_IG116:                ;; offset=0x0C8A
       mov      rdx, gword ptr [rsp+0x58]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG56
 
G_M000_IG117:                ;; offset=0x0C9A
       cmp      ecx, 0x1000
       jg       SHORT G_M000_IG120
       cmp      dword ptr [rsp+0x110], 0
       jbe      G_M000_IG151
       mov      rcx, bword ptr [rsp+0x108]
       movzx    rcx, byte  ptr [rcx]
       cmp      ecx, 43
       je       SHORT G_M000_IG118
       cmp      ecx, 45
       jne      SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x0CC5
       cmp      dword ptr [rsp+0x110], 1
       jle      SHORT G_M000_IG119
       cmp      dword ptr [rsp+0x110], 1
       jbe      G_M000_IG151
       mov      rcx, bword ptr [rsp+0x108]
       movzx    rcx, byte  ptr [rcx+0x01]
 
G_M000_IG119:                ;; offset=0x0CE9
       cmp      ecx, 48
       jl       SHORT G_M000_IG121
       cmp      ecx, 57
       jle      SHORT G_M000_IG122
 
G_M000_IG120:                ;; offset=0x0CF3
       cmp      dword ptr [rsp+0x110], 256
       jle      G_M000_IG126
       jmp      G_M000_IG125
 
G_M000_IG121:                ;; offset=0x0D09
       cmp      ecx, 46
       jne      SHORT G_M000_IG120
 
G_M000_IG122:                ;; offset=0x0D0E
       vmovdqu  xmm0, xmmword ptr [rsp+0x108]
       vmovdqu  xmmword ptr [rsp+0xA0], xmm0
 
G_M000_IG123:                ;; offset=0x0D20
       lea      rcx, [rsp+0xA0]
       lea      rdx, [rsp+0xF0]
       lea      r8, [rsp+0xE8]
       xor      r9d, r9d
       call     [System.Buffers.Text.Utf8Parser:TryParse(System.ReadOnlySpan`1[byte],byref,byref,char):bool]
       test     eax, eax
       je       SHORT G_M000_IG120
       mov      ecx, dword ptr [rsp+0xE8]
       cmp      ecx, dword ptr [rsp+0x110]
       jne      SHORT G_M000_IG120
       mov      r12, gword ptr [rsp+0x60]
       mov      r12, gword ptr [r12+0x98]
       cmp      byte  ptr [r12], r12b
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG124
       mov      rcx, r12
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG124:                ;; offset=0x0D7F
       vmovsd   xmm6, qword ptr [rsp+0xF0]
       jmp      G_M000_IG56
 
G_M000_IG125:                ;; offset=0x0D8D
       lea      rcx, [rsp+0x100]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x108]
       mov      edx, 1
       mov      r8, gword ptr [rsp+0x60]
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:TryParseWideFloat(System.ReadOnlySpan`1[byte],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       mov      dword ptr [rsp+0xFC], eax
       jmp      SHORT G_M000_IG127
 
G_M000_IG126:                ;; offset=0x0DBE
       lea      rcx, [rsp+0x100]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x108]
       mov      edx, 1
       mov      r8, gword ptr [rsp+0x60]
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:TryParseNormalizedFloat(System.ReadOnlySpan`1[byte],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       mov      dword ptr [rsp+0xFC], eax
 
G_M000_IG127:                ;; offset=0x0DED
       mov      rdx, gword ptr [rsp+0x60]
       mov      r8, gword ptr [rdx+0x98]
       mov      gword ptr [rsp+0x50], r8
       cmp      byte  ptr [r8], r8b
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG128
       mov      rcx, gword ptr [rsp+0x50]
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG128:                ;; offset=0x0E1C
       cmp      dword ptr [rsp+0xFC], 0
       je       SHORT G_M000_IG131
       vmovsd   xmm6, qword ptr [rsp+0x100]
       jmp      G_M000_IG56
 
G_M000_IG129:                ;; offset=0x0E34
       mov      dword ptr [rsp+0x80], r12d
       mov      dword ptr [rsp+0x84], r13d
       vmovsd   qword ptr [rsp+0x88], xmm6
       lea      rdx, [rsp+0x80]
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:AddWithResize(Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField):this]
       jmp      G_M000_IG58
 
G_M000_IG130:                ;; offset=0x0E60
       mov      ecx, 6
       call     [System.ThrowHelper:ThrowArgumentNullException(int)]
       int3     
 
G_M000_IG131:                ;; offset=0x0E6C
       mov      bword ptr [rsp+0xA0], r12
       mov      r15d, dword ptr [rsp+0xB4]
       mov      dword ptr [rsp+0xA8], r15d
       xor      rcx, rcx
       mov      gword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0xA0]
       mov      r9, r13
       mov      r8, gword ptr [rsp+0x60]
       mov      rdx, 0x1C24A1765C8
       call     [Lokad.Lython.Runtime.LythonRuntime:TextConversionError(System.ReadOnlySpan`1[byte],System.String,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.PyBytes):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG132:                ;; offset=0x0EB4
       mov      rcx, gword ptr [rdi+0x10]
       mov      rax, gword ptr [rdi+0x18]
       mov      gword ptr [rsp+0x48], rax
       mov      rdx, gword ptr [rcx+0x98]
       mov      gword ptr [rsp+0x40], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG133
       mov      rcx, gword ptr [rsp+0x40]
       mov      rdx, gword ptr [rsp+0x48]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG133:                ;; offset=0x0EEC
       mov      eax, r13d
       sub      eax, r12d
       cmp      eax, 0x1000
       jge      SHORT G_M000_IG134
       jmp      SHORT G_M000_IG135
 
G_M000_IG134:                ;; offset=0x0EFB
       mov      eax, 0x1000
 
G_M000_IG135:                ;; offset=0x0F00
       mov      ecx, r12d
       mov      r9d, eax
       add      rcx, r9
       mov      r9d, r13d
       cmp      rcx, r9
       ja       G_M000_IG79
       mov      ecx, r12d
       add      rcx, r14
       mov      dword ptr [rsp+0xE4], eax
       mov      r9d, eax
       mov      edx, 13
       mov      r8d, 10
       call     [System.SpanHelpers:NonPackedIndexOfAnyValueType[byte,System.SpanHelpers+Negate`1[byte]](byref,byte,byte,int):int]
       test     eax, eax
       jge      SHORT G_M000_IG136
       add      r12d, dword ptr [rsp+0xE4]
       cmp      r12d, r13d
       jl       G_M000_IG132
       jmp      G_M000_IG62
 
G_M000_IG136:                ;; offset=0x0F50
       mov      rdx, gword ptr [rdi+0x18]
       mov      rcx, 0x1C24A1764A0
       call     [Lokad.Lython.Runtime.LythonRuntime:CsvError(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG137:                ;; offset=0x0F6D
       mov      r14d, r12d
       test     r14d, r14d
       je       G_M000_IG149
       jmp      SHORT G_M000_IG140
 
G_M000_IG138:                ;; offset=0x0F7B
       lea      rdx, [rsp+0xD0]
       mov      rax, qword ptr [rcx]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r13, bword ptr [rsp+0xD0]
       mov      r12d, dword ptr [rsp+0xD8]
       jmp      G_M000_IG65
 
G_M000_IG139:                ;; offset=0x0FA2
       mov      bword ptr [rsp+0xA0], rsi
       mov      dword ptr [rsp+0xA8], r15d
       lea      rdx, [rsp+0xA0]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:EmitRecord(System.ReadOnlySpan`1[byte]):this]
       mov      r14d, -1
       jmp      G_M000_IG67
 
G_M000_IG140:                ;; offset=0x0FCE
       mov      r9, gword ptr [rdi+0x10]
       mov      r9, gword ptr [r9+0x98]
       mov      r9, gword ptr [r9+0x180]
       mov      rcx, gword ptr [rdi+0x28]
       lea      rdx, [rsp+0x140]
       mov      r8d, r14d
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:GetWriteWindow(int,System.Threading.CancellationToken):System.Memory`1[byte]:this]
       xor      r13, r13
       xor      r12d, r12d
       mov      rcx, gword ptr [rsp+0x140]
       test     rcx, rcx
       je       SHORT G_M000_IG143
       mov      rdx, qword ptr [rcx]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       je       SHORT G_M000_IG141
       lea      r13, bword ptr [rcx+0x10]
       mov      r12d, dword ptr [rcx+0x08]
       jmp      SHORT G_M000_IG142
 
G_M000_IG141:                ;; offset=0x101F
       lea      rdx, [rsp+0xC0]
       mov      rax, qword ptr [rcx]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[byte]:GetSpan():System.Span`1[byte]:this
       mov      r13, bword ptr [rsp+0xC0]
       mov      r12d, dword ptr [rsp+0xC8]
 
G_M000_IG142:                ;; offset=0x1041
       mov      ecx, dword ptr [rsp+0x148]
       and      ecx, 0x7FFFFFFF
       mov      eax, dword ptr [rsp+0x14C]
       mov      edx, eax
       add      rdx, rcx
       mov      r8d, r12d
       cmp      rdx, r8
       ja       G_M000_IG79
       add      r13, rcx
       mov      r12d, eax
 
G_M000_IG143:                ;; offset=0x106C
       xor      eax, eax
       jmp      G_M000_IG148
 
G_M000_IG144:                ;; offset=0x1073
       mov      rcx, gword ptr [rdi+0x10]
       mov      rdx, gword ptr [rdi+0x18]
       mov      gword ptr [rsp+0x38], rdx
       mov      r8, gword ptr [rcx+0x98]
       mov      gword ptr [rsp+0x30], r8
       cmp      byte  ptr [r8], r8b
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG145
       mov      rcx, gword ptr [rsp+0x30]
       mov      rdx, gword ptr [rsp+0x38]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG145:                ;; offset=0x10AC
       mov      eax, dword ptr [rsp+0x13C]
       mov      r10d, r12d
       sub      r10d, eax
       cmp      r10d, 0x1000
       jge      SHORT G_M000_IG146
       jmp      SHORT G_M000_IG147
 
G_M000_IG146:                ;; offset=0x10C4
       mov      r10d, 0x1000
 
G_M000_IG147:                ;; offset=0x10CA
       mov      r8d, eax
       mov      ecx, r10d
       add      r8, rcx
       mov      ecx, r15d
       cmp      r8, rcx
       ja       G_M000_IG79
       mov      edx, eax
       add      rdx, rsi
       mov      r8d, eax
       mov      ecx, r10d
       add      r8, rcx
       mov      ecx, r12d
       cmp      r8, rcx
       ja       G_M000_IG79
       mov      dword ptr [rsp+0x13C], eax
       mov      ecx, eax
       add      rcx, r13
       mov      dword ptr [rsp+0xBC], r10d
       mov      r8d, r10d
       call     [System.SpanHelpers:Memmove(byref,byref,nuint)]
       mov      eax, dword ptr [rsp+0x13C]
       add      eax, dword ptr [rsp+0xBC]
 
G_M000_IG148:                ;; offset=0x1124
       mov      dword ptr [rsp+0x13C], eax
       cmp      eax, r12d
       jl       G_M000_IG144
       mov      rcx, gword ptr [rdi+0x28]
       mov      edx, r12d
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:Advance(int):this]
 
G_M000_IG149:                ;; offset=0x1143
       mov      bword ptr [rsp+0xA0], rsi
       mov      dword ptr [rsp+0xA8], r15d
       lea      rdx, [rsp+0xA0]
       mov      rcx, rdi
       mov      r8d, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:ResumeRecordAtField(System.ReadOnlySpan`1[byte],int):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG150
       mov      r14d, -1
       jmp      G_M000_IG67
 
G_M000_IG150:                ;; offset=0x1176
       mov      rcx, gword ptr [rdi+0x28]
       lea      rdx, [rsp+0x150]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:get_WrittenSpan():System.ReadOnlySpan`1[byte]:this]
       lea      rdx, [rsp+0x150]
       mov      rcx, rdi
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:PublishRecord(System.ReadOnlySpan`1[byte],System.Nullable`1[System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]):int:this]
       mov      r14d, eax
       jmp      G_M000_IG67
 
G_M000_IG151:                ;; offset=0x11A6
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG152:                ;; offset=0x11AC
       call     CORINFO_HELP_OVERFLOW
       int3     
 
RWD00  	dq	8000000000000000h, 8000000000000000h

; Total bytes of code 4530

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:TryDescribeLiteralRecord(System.ReadOnlySpan`1[byte],byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 199456
; 43 inlinees with PGO data; 75 single block inlinees; 3 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 232
       vmovaps  xmmword ptr [rsp+0xD0], xmm6
       xor      eax, eax
       mov      qword ptr [rsp+0x58], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x60], ymm4
       vmovdqu  ymmword ptr [rsp+0x80], ymm4
       vmovdqu  ymmword ptr [rsp+0xA0], ymm4
       vmovdqa  xmmword ptr [rsp+0xC0], xmm4
       mov      rbx, rcx
       mov      rsi, r8
 
G_M000_IG02:                ;; offset=0x004E
       mov      rdi, bword ptr [rdx]
       mov      ebp, dword ptr [rdx+0x08]
       cmp      gword ptr [rbx+0x50], 0
       jne      G_M000_IG61
       xor      edx, edx
       mov      bword ptr [rsp+0x140], rsi
       mov      dword ptr [rsi], edx
       test     ebp, ebp
       je       G_M000_IG51
       movzx    r14, byte  ptr [rdi]
       cmp      r14d, 10
       je       G_M000_IG62
       cmp      r14d, 13
       je       G_M000_IG62
       mov      r14, gword ptr [rbx+0x30]
       test     r14, r14
       je       SHORT G_M000_IG09
 
G_M000_IG03:                ;; offset=0x0094
       movzx    rdx, byte  ptr [r14+0x24]
       test     edx, edx
       je       G_M000_IG65
 
G_M000_IG04:                ;; offset=0x00A1
       cmp      edx, 255
       je       G_M000_IG69
       lea      rax, bword ptr [r14+0x28]
       mov      r15d, dword ptr [r14+0x18]
       cmp      r15d, 8
       ja       G_M000_IG63
 
G_M000_IG05:                ;; offset=0x00BF
       mov      dword ptr [rsp+0x84], r15d
       test     r15d, r15d
       je       G_M000_IG72
       movzx    r14, byte  ptr [rax]
 
G_M000_IG06:                ;; offset=0x00D4
       cmp      r14d, dword ptr [rbx+0x60]
       je       SHORT G_M000_IG10
 
G_M000_IG07:                ;; offset=0x00DA
       cmp      r14d, 10
       je       SHORT G_M000_IG10
       cmp      r14d, 13
       je       SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x00E6
       xor      r13d, r13d
       mov      rcx, gword ptr [rbx+0x20]
       mov      edx, dword ptr [rcx+0x10]
       mov      rcx, gword ptr [rcx+0x08]
       cmp      edx, dword ptr [rcx+0x08]
       jge      G_M000_IG115
       jmp      G_M000_IG22
 
G_M000_IG09:                ;; offset=0x0102
       xor      rax, rax
       xor      r15d, r15d
       jmp      SHORT G_M000_IG05
 
G_M000_IG10:                ;; offset=0x0109
       mov      r14d, -1
       jmp      SHORT G_M000_IG08
       align    [0 bytes for IG36]
 
G_M000_IG11:                ;; offset=0x0111
       cmp      r15d, 1
       jne      G_M000_IG115
       lea      r12d, [r13+0x01]
       cmp      r12d, ebp
       jge      G_M000_IG76
 
G_M000_IG12:                ;; offset=0x0128
       mov      rcx, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rbx+0x18]
       mov      rcx, gword ptr [rcx+0x98]
       mov      rax, gword ptr [rcx+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG74
       mov      rax, gword ptr [rcx+0x180]
       test     rax, rax
       jne      G_M000_IG73
 
G_M000_IG13:                ;; offset=0x0159
       mov      eax, ebp
       sub      eax, r12d
       cmp      eax, 0x1000
       jge      G_M000_IG54
 
G_M000_IG14:                ;; offset=0x0169
       mov      ecx, r12d
       mov      edx, eax
       add      rcx, rdx
       mov      edx, ebp
       cmp      rcx, rdx
       ja       G_M000_IG63
       mov      ecx, r12d
       add      rcx, rdi
       movzx    rdx, r14b
       mov      dword ptr [rsp+0xBC], eax
       mov      r8d, eax
       call     [System.SpanHelpers:NonPackedIndexOfValueType[byte,System.SpanHelpers+DontNegate`1[byte]](byref,byte,int):int]
       test     eax, eax
       jl       G_M000_IG75
       add      eax, r12d
 
G_M000_IG15:                ;; offset=0x01A1
       test     eax, eax
       jl       G_M000_IG115
       lea      r12d, [rax+0x01]
       cmp      r12d, ebp
       jge      SHORT G_M000_IG18
 
G_M000_IG16:                ;; offset=0x01B2
       cmp      r12d, ebp
       jae      G_M000_IG117
       mov      edx, r12d
       movzx    rdx, byte  ptr [rdi+rdx]
       cmp      edx, dword ptr [rbx+0x60]
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x01C7
       cmp      edx, 10
       jne      G_M000_IG77
 
G_M000_IG18:                ;; offset=0x01D0
       lea      edx, [r13+0x01]
       sub      eax, r13d
       lea      r13d, [rax-0x01]
       mov      rcx, gword ptr [rbx+0x20]
       inc      dword ptr [rcx+0x14]
       mov      rax, gword ptr [rcx+0x08]
       mov      r8d, dword ptr [rcx+0x10]
       cmp      dword ptr [rax+0x08], r8d
       jbe      G_M000_IG78
       lea      r10d, [r8+0x01]
       mov      dword ptr [rcx+0x10], r10d
       mov      ecx, r8d
       shl      rcx, 4
       lea      rcx, bword ptr [rax+rcx+0x10]
       mov      dword ptr [rcx], edx
       mov      dword ptr [rcx+0x04], r13d
       xor      edx, edx
       mov      qword ptr [rcx+0x08], rdx
 
G_M000_IG19:                ;; offset=0x0214
       test     r13d, r13d
       je       SHORT G_M000_IG20
       movsxd   rcx, r13d
       add      rcx, 128
       add      rcx, qword ptr [rbx+0x58]
       jo       G_M000_IG118
       mov      qword ptr [rbx+0x58], rcx
       cmp      r13d, 8
       jg       G_M000_IG53
 
G_M000_IG20:                ;; offset=0x023B
       cmp      r12d, ebp
       je       G_M000_IG51
       cmp      r12d, ebp
       jae      G_M000_IG117
       mov      ecx, r12d
       movzx    rdx, byte  ptr [rdi+rcx]
       cmp      edx, 10
       je       G_M000_IG50
 
G_M000_IG21:                ;; offset=0x025D
       cmp      edx, 13
       je       G_M000_IG50
       lea      r13d, [r12+0x01]
       mov      rcx, gword ptr [rbx+0x20]
       mov      eax, dword ptr [rcx+0x10]
       mov      rcx, gword ptr [rcx+0x08]
       cmp      eax, dword ptr [rcx+0x08]
       mov      r15d, dword ptr [rsp+0x84]
       jge      G_M000_IG115
 
G_M000_IG22:                ;; offset=0x0287
       cmp      r13d, ebp
       jge      SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x028C
       mov      ecx, r13d
       movzx    rcx, byte  ptr [rdi+rcx]
       cmp      ecx, r14d
       je       G_M000_IG11
 
G_M000_IG24:                ;; offset=0x029C
       mov      r12d, r13d
       cmp      r12d, ebp
       jge      G_M000_IG82
 
G_M000_IG25:                ;; offset=0x02A8
       mov      rcx, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rbx+0x18]
       mov      rcx, gword ptr [rcx+0x98]
       mov      rax, gword ptr [rcx+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG80
       mov      rax, gword ptr [rcx+0x180]
       test     rax, rax
       jne      G_M000_IG79
 
G_M000_IG26:                ;; offset=0x02D9
       mov      eax, ebp
       sub      eax, r12d
       cmp      eax, 0x1000
       jge      G_M000_IG55
 
G_M000_IG27:                ;; offset=0x02E9
       mov      r9d, r12d
       mov      edx, eax
       add      r9, rdx
       mov      edx, ebp
       cmp      r9, rdx
       ja       G_M000_IG63
       mov      ecx, r12d
       add      rcx, rdi
       mov      r10, gword ptr [rbx+0x40]
       test     r10, r10
       je       G_M000_IG108
       mov      r9, 0x7FF9D749EAE8
       cmp      qword ptr [r10], r9
       jne      G_M000_IG56
 
G_M000_IG28:                ;; offset=0x0322
       mov      dword ptr [rsp+0xB8], eax
       mov      dword ptr [rsp+0x20], eax
       movzx    r9, byte  ptr [r10+0x0A]
       movzx    rdx, byte  ptr [r10+0x08]
       movzx    r8, byte  ptr [r10+0x09]
       call     [System.SpanHelpers:NonPackedIndexOfAnyValueType[byte,System.SpanHelpers+DontNegate`1[byte]](byref,byte,byte,byte,int):int]
 
G_M000_IG29:                ;; offset=0x0342
       test     eax, eax
       jl       G_M000_IG81
       add      eax, r12d
 
G_M000_IG30:                ;; offset=0x034D
       mov      r12d, eax
       mov      eax, r12d
       sub      eax, r13d
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x28], 2
       jne      G_M000_IG83
 
G_M000_IG31:                ;; offset=0x0364
       test     eax, eax
       je       G_M000_IG83
       mov      ecx, r13d
       mov      edx, eax
       add      rcx, rdx
       mov      edx, ebp
       cmp      rcx, rdx
       ja       G_M000_IG63
       mov      r13d, r13d
       add      r13, rdi
       mov      dword ptr [rsp+0x7C], eax
       mov      r10, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x40], r10
       mov      r9, gword ptr [rbx+0x18]
       mov      gword ptr [rsp+0x38], r9
       xor      ecx, ecx
       mov      qword ptr [rsp+0xA0], rcx
 
G_M000_IG32:                ;; offset=0x03A5
       mov      qword ptr [rsp+0x90], rcx
 
G_M000_IG33:                ;; offset=0x03AD
       mov      dword ptr [rsp+0x88], ecx
       mov      rcx, gword ptr [r10+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG85
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG84
 
G_M000_IG34:                ;; offset=0x03DD
       mov      r8d, dword ptr [rsp+0x7C]
       mov      ecx, r8d
       movzx    rdx, byte  ptr [r13]
       cmp      edx, 45
       sete     al
       movzx    rax, al
       cmp      edx, 43
       je       G_M000_IG87
       cmp      edx, 45
       setne    dl
       movzx    rdx, dl
 
G_M000_IG35:                ;; offset=0x0405
       test     edx, edx
       sete     dl
       movzx    rdx, dl
       mov      r11d, r8d
       sub      r11d, edx
       mov      r9d, r11d
       sub      r9d, 1
       cmp      r9d, 16
       ja       G_M000_IG88
       xor      r9d, r9d
       mov      esi, -1
       cmp      edx, r8d
       jge      SHORT G_M000_IG39
 
G_M000_IG36:                ;; offset=0x0431
       movzx    r15, byte  ptr [rdx+r13]
       add      r15d, -48
       cmp      r15d, 9
       ja       G_M000_IG57
 
G_M000_IG37:                ;; offset=0x0444
       lea      r9, [r9+4*r9]
       mov      r15d, r15d
       lea      r9, [r15+2*r9]
 
G_M000_IG38:                ;; offset=0x044F
       inc      edx
       cmp      edx, r8d
       jl       SHORT G_M000_IG36
 
G_M000_IG39:                ;; offset=0x0456
       cmp      r11d, 1
       je       G_M000_IG58
 
G_M000_IG40:                ;; offset=0x0460
       mov      rdx, 0x20000000000000
       cmp      r9, rdx
       ja       G_M000_IG89
       test     esi, esi
       jl       G_M000_IG59
 
G_M000_IG41:                ;; offset=0x047B
       sub      ecx, esi
       dec      ecx
 
G_M000_IG42:                ;; offset=0x047F
       vxorps   xmm0, xmm0, xmm0
       mov      r8, r9
       shr      r8, 1
       mov      edx, r9d
       and      edx, 1
       or       rdx, r8
       test     r9, r9
       cmovns   rdx, r9
       vcvtsi2sd xmm0, rdx
       jns      SHORT G_M000_IG43
       vaddsd   xmm0, xmm0
 
G_M000_IG43:                ;; offset=0x04A4
       cmp      ecx, 19
       jae      G_M000_IG117
       mov      ecx, ecx
       mov      rdx, 0x1E23F93C0E8
       vdivsd   xmm6, xmm0, qword ptr [rdx+8*rcx]
       test     eax, eax
       jne      G_M000_IG60
 
G_M000_IG44:                ;; offset=0x04C6
       mov      r10, gword ptr [rsp+0x40]
       mov      rcx, gword ptr [r10+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG94
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG93
 
G_M000_IG45:                ;; offset=0x04F4
       mov      r13d, -1
       xor      eax, eax
 
G_M000_IG46:                ;; offset=0x04FC
       mov      rcx, gword ptr [rbx+0x20]
       inc      dword ptr [rcx+0x14]
       mov      rdx, gword ptr [rcx+0x08]
       mov      r8d, dword ptr [rcx+0x10]
       cmp      dword ptr [rdx+0x08], r8d
       jbe      G_M000_IG107
       lea      r10d, [r8+0x01]
       mov      dword ptr [rcx+0x10], r10d
       mov      ecx, r8d
       shl      rcx, 4
       lea      rdx, bword ptr [rdx+rcx+0x10]
       mov      dword ptr [rdx], r13d
       mov      dword ptr [rdx+0x04], eax
       vmovsd   qword ptr [rdx+0x08], xmm6
 
G_M000_IG47:                ;; offset=0x0534
       test     r13d, r13d
       jl       G_M000_IG20
 
G_M000_IG48:                ;; offset=0x053D
       test     eax, eax
       je       G_M000_IG20
       movsxd   rcx, eax
       add      rcx, 128
       add      rcx, qword ptr [rbx+0x58]
       jo       G_M000_IG118
       mov      qword ptr [rbx+0x58], rcx
       cmp      eax, 8
       jle      G_M000_IG20
 
G_M000_IG49:                ;; offset=0x0566
       add      eax, dword ptr [rbx+0x68]
       jo       G_M000_IG118
       mov      dword ptr [rbx+0x68], eax
       jmp      G_M000_IG20
 
G_M000_IG50:                ;; offset=0x0577
       lea      ecx, [r12+0x01]
       cmp      ecx, ebp
       ja       G_M000_IG63
       mov      esi, ecx
       add      rdi, rsi
       sub      ebp, ecx
       xor      esi, esi
       cmp      esi, ebp
       jl       G_M000_IG110
 
G_M000_IG51:                ;; offset=0x0595
       mov      eax, 1
 
G_M000_IG52:                ;; offset=0x059A
       vmovaps  xmm6, xmmword ptr [rsp+0xD0]
       add      rsp, 232
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG53:                ;; offset=0x05B7
       add      r13d, dword ptr [rbx+0x68]
       jo       G_M000_IG118
       mov      dword ptr [rbx+0x68], r13d
       jmp      G_M000_IG20
 
G_M000_IG54:                ;; offset=0x05CA
       mov      eax, 0x1000
       jmp      G_M000_IG14
 
G_M000_IG55:                ;; offset=0x05D4
       mov      eax, 0x1000
       jmp      G_M000_IG27
 
G_M000_IG56:                ;; offset=0x05DE
       mov      bword ptr [rsp+0x58], rcx
       mov      dword ptr [rsp+0xB8], eax
       mov      dword ptr [rsp+0x60], eax
       lea      rdx, [rsp+0x58]
       mov      rcx, r10
       mov      r8, qword ptr [r10]
       mov      r8, qword ptr [r8+0x40]
       call     [r8+0x30]System.Buffers.SearchValues`1[byte]:IndexOfAny(System.ReadOnlySpan`1[byte]):int:this
       jmp      G_M000_IG29
 
G_M000_IG57:                ;; offset=0x0606
       cmp      byte  ptr [rdx+r13], 46
       jne      G_M000_IG92
       test     esi, esi
       jge      G_M000_IG91
       mov      esi, edx
       jmp      G_M000_IG38
 
G_M000_IG58:                ;; offset=0x0620
       test     esi, esi
       jge      G_M000_IG90
       jmp      G_M000_IG40
 
G_M000_IG59:                ;; offset=0x062D
       xor      ecx, ecx
       jmp      G_M000_IG42
 
G_M000_IG60:                ;; offset=0x0634
       vxorps   xmm6, xmm6, xmmword ptr [reloc @RWD00]
       jmp      G_M000_IG44
 
G_M000_IG61:                ;; offset=0x0641
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1C24A176428
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG62:                ;; offset=0x066F
       mov      rcx, gword ptr [rbx+0x10]
       mov      rsi, gword ptr [rbx+0x18]
       mov      r14, gword ptr [rcx+0x98]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG64
       mov      rcx, r14
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      SHORT G_M000_IG64
 
G_M000_IG63:                ;; offset=0x069C
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG64:                ;; offset=0x06A3
       lea      rdx, bword ptr [rdi+0x01]
       lea      ecx, [rbp-0x01]
       mov      bword ptr [rsp+0x58], rdx
       mov      dword ptr [rsp+0x60], ecx
       lea      rdx, [rsp+0x58]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:ValidateRecordEnd(System.ReadOnlySpan`1[byte]):this]
       jmp      G_M000_IG51
 
G_M000_IG65:                ;; offset=0x06C6
       mov      rax, gword ptr [r14+0x08]
       mov      r15d, dword ptr [r14+0x18]
       test     rax, rax
       jne      SHORT G_M000_IG67
 
G_M000_IG66:                ;; offset=0x06D3
       test     r15d, r15d
       jne      SHORT G_M000_IG63
       xor      rax, rax
       xor      r15d, r15d
       jmp      SHORT G_M000_IG68
 
G_M000_IG67:                ;; offset=0x06DF
       cmp      dword ptr [rax+0x08], r15d
       jb       SHORT G_M000_IG63
       add      rax, 16
 
G_M000_IG68:                ;; offset=0x06E9
       jmp      G_M000_IG05
 
G_M000_IG69:                ;; offset=0x06EE
       mov      rdx, gword ptr [r14+0x08]
       lea      rcx, bword ptr [r14+0x28]
       mov      ecx, dword ptr [rcx]
       mov      eax, dword ptr [r14+0x18]
       test     rdx, rdx
       jne      SHORT G_M000_IG70
       or       ecx, eax
       jne      SHORT G_M000_IG63
       xor      rdx, rdx
       xor      eax, eax
       jmp      SHORT G_M000_IG71
 
G_M000_IG70:                ;; offset=0x070B
       mov      r8d, ecx
       mov      r10d, eax
       add      r8, r10
       mov      r10d, dword ptr [rdx+0x08]
       cmp      r8, r10
       ja       G_M000_IG63
       mov      ecx, ecx
       lea      rdx, bword ptr [rdx+rcx+0x10]
 
G_M000_IG71:                ;; offset=0x0728
       mov      bword ptr [rsp+0x68], rdx
       mov      dword ptr [rsp+0x70], eax
       lea      rdx, [rsp+0x68]
       lea      rcx, [rsp+0xC0]
       call     [System.Span`1[byte]:op_Implicit(System.Span`1[byte]):System.ReadOnlySpan`1[byte]]
       mov      rax, bword ptr [rsp+0xC0]
       mov      r15d, dword ptr [rsp+0xC8]
       jmp      G_M000_IG05
 
G_M000_IG72:                ;; offset=0x0759
       mov      r14d, -1
       jmp      G_M000_IG06
 
G_M000_IG73:                ;; offset=0x0764
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG13
 
G_M000_IG74:                ;; offset=0x0776
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG13
 
G_M000_IG75:                ;; offset=0x0781
       add      r12d, dword ptr [rsp+0xBC]
       cmp      r12d, ebp
       jl       G_M000_IG12
 
G_M000_IG76:                ;; offset=0x0792
       mov      eax, -1
       jmp      G_M000_IG15
 
G_M000_IG77:                ;; offset=0x079C
       cmp      edx, 13
       jne      G_M000_IG115
       jmp      G_M000_IG18
 
G_M000_IG78:                ;; offset=0x07AA
       mov      dword ptr [rsp+0x48], edx
       mov      dword ptr [rsp+0x4C], r13d
       xor      edx, edx
       mov      qword ptr [rsp+0x50], rdx
       lea      rdx, [rsp+0x48]
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:AddWithResize(Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField):this]
       jmp      G_M000_IG19
 
G_M000_IG79:                ;; offset=0x07CA
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG26
 
G_M000_IG80:                ;; offset=0x07DC
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG26
 
G_M000_IG81:                ;; offset=0x07E7
       add      r12d, dword ptr [rsp+0xB8]
       cmp      r12d, ebp
       jl       G_M000_IG25
 
G_M000_IG82:                ;; offset=0x07F8
       mov      eax, r12d
       jmp      G_M000_IG30
 
G_M000_IG83:                ;; offset=0x0800
       vxorps   xmm6, xmm6, xmm6
       jmp      G_M000_IG46
 
G_M000_IG84:                ;; offset=0x0809
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG34
 
G_M000_IG85:                ;; offset=0x081B
       mov      rdx, r9
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      r9, gword ptr [rsp+0x38]
       jmp      G_M000_IG34
 
G_M000_IG86:                ;; offset=0x082E
       mov      bword ptr [rsp+0x58], r13
       mov      dword ptr [rsp+0x60], r8d
       mov      rax, gword ptr [rsp+0x38]
       mov      gword ptr [rsp+0x20], rax
       lea      rdx, [rsp+0x58]
       lea      rcx, [rsp+0xA8]
       mov      r8d, 1
       mov      r9, r10
       call     [Lokad.Lython.Runtime.LythonRuntime:TrimNumericWhitespace(System.ReadOnlySpan`1[byte],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.ReadOnlySpan`1[byte]]
       mov      ecx, dword ptr [rsp+0xB0]
       test     ecx, ecx
       jle      G_M000_IG98
       jmp      SHORT G_M000_IG95
 
G_M000_IG87:                ;; offset=0x086F
       xor      edx, edx
       jmp      G_M000_IG35
 
G_M000_IG88:                ;; offset=0x0876
       mov      r10, gword ptr [rsp+0x40]
       jmp      SHORT G_M000_IG86
 
G_M000_IG89:                ;; offset=0x087D
       mov      r10, gword ptr [rsp+0x40]
       mov      r15d, dword ptr [rsp+0x84]
       jmp      SHORT G_M000_IG86
 
G_M000_IG90:                ;; offset=0x088C
       mov      r10, gword ptr [rsp+0x40]
       mov      r15d, dword ptr [rsp+0x84]
       jmp      SHORT G_M000_IG86
 
G_M000_IG91:                ;; offset=0x089B
       mov      r10, gword ptr [rsp+0x40]
       mov      r15d, dword ptr [rsp+0x84]
       jmp      SHORT G_M000_IG86
 
G_M000_IG92:                ;; offset=0x08AA
       mov      r10, gword ptr [rsp+0x40]
       mov      r15d, dword ptr [rsp+0x84]
       jmp      G_M000_IG86
 
G_M000_IG93:                ;; offset=0x08BC
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG45
 
G_M000_IG94:                ;; offset=0x08CE
       mov      rdx, gword ptr [rsp+0x38]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG45
 
G_M000_IG95:                ;; offset=0x08DE
       cmp      ecx, 0x1000
       jg       SHORT G_M000_IG98
       cmp      dword ptr [rsp+0xB0], 0
       jbe      G_M000_IG117
       mov      rcx, bword ptr [rsp+0xA8]
       movzx    rcx, byte  ptr [rcx]
       cmp      ecx, 43
       je       SHORT G_M000_IG96
       cmp      ecx, 45
       jne      SHORT G_M000_IG97
 
G_M000_IG96:                ;; offset=0x0909
       cmp      dword ptr [rsp+0xB0], 1
       jle      SHORT G_M000_IG97
       cmp      dword ptr [rsp+0xB0], 1
       jbe      G_M000_IG117
       mov      rcx, bword ptr [rsp+0xA8]
       movzx    rcx, byte  ptr [rcx+0x01]
 
G_M000_IG97:                ;; offset=0x092D
       cmp      ecx, 48
       jl       SHORT G_M000_IG99
       cmp      ecx, 57
       jle      SHORT G_M000_IG100
 
G_M000_IG98:                ;; offset=0x0937
       cmp      dword ptr [rsp+0xB0], 256
       jle      G_M000_IG104
       jmp      G_M000_IG103
 
G_M000_IG99:                ;; offset=0x094D
       cmp      ecx, 46
       jne      SHORT G_M000_IG98
 
G_M000_IG100:                ;; offset=0x0952
       vmovdqu  xmm0, xmmword ptr [rsp+0xA8]
       vmovdqu  xmmword ptr [rsp+0x58], xmm0
 
G_M000_IG101:                ;; offset=0x0961
       lea      rcx, [rsp+0x58]
       lea      rdx, [rsp+0x90]
       lea      r8, [rsp+0x88]
       xor      r9d, r9d
       call     [System.Buffers.Text.Utf8Parser:TryParse(System.ReadOnlySpan`1[byte],byref,byref,char):bool]
       test     eax, eax
       je       SHORT G_M000_IG98
       mov      ecx, dword ptr [rsp+0x88]
       cmp      ecx, dword ptr [rsp+0xB0]
       jne      SHORT G_M000_IG98
       mov      r13, gword ptr [rsp+0x40]
       mov      r13, gword ptr [r13+0x98]
       cmp      byte  ptr [r13], r13b
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG102
       mov      rcx, r13
       mov      rdx, gword ptr [rsp+0x38]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG102:                ;; offset=0x09BE
       vmovsd   xmm6, qword ptr [rsp+0x90]
       jmp      G_M000_IG45
 
G_M000_IG103:                ;; offset=0x09CC
       lea      rcx, [rsp+0xA0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0xA8]
       mov      edx, 1
       mov      r8, gword ptr [rsp+0x40]
       mov      r9, gword ptr [rsp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryParseWideFloat(System.ReadOnlySpan`1[byte],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       mov      dword ptr [rsp+0x9C], eax
       jmp      SHORT G_M000_IG105
 
G_M000_IG104:                ;; offset=0x09FF
       lea      rcx, [rsp+0xA0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0xA8]
       mov      edx, 1
       mov      r8, gword ptr [rsp+0x40]
       mov      r9, gword ptr [rsp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryParseNormalizedFloat(System.ReadOnlySpan`1[byte],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       mov      dword ptr [rsp+0x9C], eax
 
G_M000_IG105:                ;; offset=0x0A30
       mov      rdx, gword ptr [rsp+0x40]
       mov      r8, gword ptr [rdx+0x98]
       mov      gword ptr [rsp+0x30], r8
       cmp      byte  ptr [r8], r8b
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG106
       mov      rcx, gword ptr [rsp+0x30]
       mov      rdx, gword ptr [rsp+0x38]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG106:                ;; offset=0x0A61
       cmp      dword ptr [rsp+0x9C], 0
       je       SHORT G_M000_IG109
       vmovsd   xmm6, qword ptr [rsp+0xA0]
       jmp      G_M000_IG45
 
G_M000_IG107:                ;; offset=0x0A79
       mov      dword ptr [rsp+0x48], r13d
       mov      dword ptr [rsp+0x80], eax
       mov      dword ptr [rsp+0x4C], eax
       vmovsd   qword ptr [rsp+0x50], xmm6
       lea      rdx, [rsp+0x48]
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:AddWithResize(Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField):this]
       mov      eax, dword ptr [rsp+0x80]
       jmp      G_M000_IG47
 
G_M000_IG108:                ;; offset=0x0AA6
       mov      ecx, 6
       call     [System.ThrowHelper:ThrowArgumentNullException(int)]
       int3     
 
G_M000_IG109:                ;; offset=0x0AB2
       mov      bword ptr [rsp+0x58], r13
       mov      r12d, dword ptr [rsp+0x7C]
       mov      dword ptr [rsp+0x60], r12d
       xor      rcx, rcx
       mov      gword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x58]
       mov      r9, gword ptr [rsp+0x38]
       mov      r8, gword ptr [rsp+0x40]
       mov      rdx, 0x1C24A1765C8
       call     [Lokad.Lython.Runtime.LythonRuntime:TextConversionError(System.ReadOnlySpan`1[byte],System.String,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.PyBytes):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG110:                ;; offset=0x0AF0
       mov      rcx, gword ptr [rbx+0x10]
       mov      r14, gword ptr [rbx+0x18]
       mov      r15, gword ptr [rcx+0x98]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG111
       mov      rcx, r15
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG111:                ;; offset=0x0B1B
       mov      r14d, ebp
       sub      r14d, esi
       cmp      r14d, 0x1000
       jge      SHORT G_M000_IG112
       jmp      SHORT G_M000_IG113
 
G_M000_IG112:                ;; offset=0x0B2C
       mov      r14d, 0x1000
 
G_M000_IG113:                ;; offset=0x0B32
       mov      ecx, esi
       mov      r9d, r14d
       add      rcx, r9
       mov      r9d, ebp
       cmp      rcx, r9
       ja       G_M000_IG63
       mov      ecx, esi
       add      rcx, rdi
       mov      r9d, r14d
       mov      edx, 13
       mov      r8d, 10
       call     [System.SpanHelpers:NonPackedIndexOfAnyValueType[byte,System.SpanHelpers+Negate`1[byte]](byref,byte,byte,int):int]
       test     eax, eax
       jge      SHORT G_M000_IG114
       add      esi, r14d
       cmp      esi, ebp
       jl       SHORT G_M000_IG110
       jmp      G_M000_IG51
 
G_M000_IG114:                ;; offset=0x0B6F
       mov      rdx, gword ptr [rbx+0x18]
       mov      rcx, 0x1C24A1764A0
       call     [Lokad.Lython.Runtime.LythonRuntime:CsvError(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG115:                ;; offset=0x0B8C
       mov      rsi, bword ptr [rsp+0x140]
       mov      dword ptr [rsi], r13d
       xor      eax, eax
 
G_M000_IG116:                ;; offset=0x0B99
       vmovaps  xmm6, xmmword ptr [rsp+0xD0]
       add      rsp, 232
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG117:                ;; offset=0x0BB6
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG118:                ;; offset=0x0BBC
       call     CORINFO_HELP_OVERFLOW
       int3     
 
RWD00  	dq	8000000000000000h, 8000000000000000h

; Total bytes of code 3010

