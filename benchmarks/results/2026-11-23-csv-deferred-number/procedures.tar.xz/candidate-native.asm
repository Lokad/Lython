; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:TryConsumeBufferedCsvLine(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,System.Nullable`1[System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]],byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 320
       lea      rbp, [rsp+0x140]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x110], xmm4
       vmovdqa  xmmword ptr [rbp-0x100], xmm4
       mov      rax, -240
 
G_M000_IG31:                ;; offset=0x002E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG31
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0055
       mov      rax, bword ptr [rbp+0x28]
       mov      dword ptr [rax], -1
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x6C]
       mov      dword ptr [rbp-0x04], eax
       lea      rdx, [rbp-0x18]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x78]
       call     [System.ReadOnlyMemory`1[byte]:get_Span():System.ReadOnlySpan`1[byte]:this]
       mov      eax, dword ptr [rbp-0x04]
       cmp      eax, dword ptr [rbp-0x10]
       jne      SHORT G_M000_IG04
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x008B
       add      rsp, 320
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x0094
       xor      eax, eax
       mov      dword ptr [rbp-0x20], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x58]
       mov      dword ptr [rbp-0x2C], eax
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG05
       cmp      dword ptr [rbp-0x2C], 1
       jne      SHORT G_M000_IG08
 
G_M000_IG05:                ;; offset=0x00AF
       lea      rdx, [rbp-0x40]
       lea      rcx, [rbp-0x18]
       mov      r8d, dword ptr [rbp-0x04]
       call     [System.ReadOnlySpan`1[byte]:Slice(int):System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG06:                ;; offset=0x00C1
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG07:                ;; offset=0x00CE
       lea      rdx, [rbp-0xD8]
       lea      r8, [rbp-0x20]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:TryDescribeBufferedNativeLine(System.ReadOnlySpan`1[byte],byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x00EA
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
 
G_M000_IG09:                ;; offset=0x00EF
       movzx    rax, byte  ptr [rbp-0x44]
       mov      dword ptr [rbp-0x24], eax
       cmp      dword ptr [rbp-0x24], 0
       jne      SHORT G_M000_IG12
 
G_M000_IG10:                ;; offset=0x00FC
       vmovdqu  xmm0, xmmword ptr [rbp-0x18]
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
 
G_M000_IG11:                ;; offset=0x0109
       lea      rcx, [rbp-0xE8]
       mov      rax, gword ptr [rbp+0x10]
       mov      r8d, dword ptr [rax+0x58]
       mov      eax, dword ptr [rbp-0x04]
       mov      edx, eax
       add      edx, dword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.Text.TextLineScanning:FindLineEndByte(System.ReadOnlySpan`1[byte],int,int):int]
       mov      dword ptr [rbp-0x48], eax
       jmp      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x012B
       mov      eax, dword ptr [rbp-0x04]
       add      eax, dword ptr [rbp-0x20]
       mov      dword ptr [rbp-0x48], eax
 
G_M000_IG13:                ;; offset=0x0134
       mov      eax, dword ptr [rbp-0x48]
       mov      dword ptr [rbp-0x28], eax
       mov      eax, dword ptr [rbp-0x28]
       cmp      eax, dword ptr [rbp-0x10]
       jne      SHORT G_M000_IG17
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:EndsWithTerminator():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG17
       cmp      dword ptr [rbp-0x24], 0
       jne      SHORT G_M000_IG14
       cmp      dword ptr [rbp-0x20], 0
       je       SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x015C
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:DiscardBufferedNativeLine():this]
 
G_M000_IG15:                ;; offset=0x0168
       xor      eax, eax
 
G_M000_IG16:                ;; offset=0x016A
       add      rsp, 320
       pop      rbp
       ret      
 
G_M000_IG17:                ;; offset=0x0173
       mov      rcx, gword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:Advance(int):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x30]
       xor      rdx, rdx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      eax, dword ptr [rbp-0x04]
       mov      dword ptr [rbp-0x30], eax
       mov      rax, bword ptr [rbp+0x28]
       mov      bword ptr [rbp-0x50], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x58], rax
       mov      eax, dword ptr [rbp-0x28]
       mov      r9d, eax
       sub      r9d, dword ptr [rbp-0x30]
       lea      rcx, [rbp-0x18]
       lea      rdx, [rbp-0x68]
       mov      r8d, dword ptr [rbp-0x30]
       call     [System.ReadOnlySpan`1[byte]:Slice(int,int):System.ReadOnlySpan`1[byte]:this]
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG18:                ;; offset=0x01C8
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x80], xmm0
       mov      rcx, qword ptr [rax+0x10]
       mov      qword ptr [rbp-0x70], rcx
 
G_M000_IG19:                ;; offset=0x01D9
       mov      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x84], eax
       cmp      dword ptr [rbp-0x24], 0
       jne      SHORT G_M000_IG23
       mov      rax, bword ptr [rbp-0x50]
       mov      bword ptr [rbp-0x90], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x98], rax
 
G_M000_IG20:                ;; offset=0x01FE
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG21:                ;; offset=0x020B
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
       mov      rax, qword ptr [rbp-0x70]
       mov      qword ptr [rbp-0xB0], rax
 
G_M000_IG22:                ;; offset=0x0223
       mov      eax, dword ptr [rbp-0x84]
       mov      dword ptr [rbp-0xC4], eax
       mov      eax, dword ptr [rbp-0x20]
       mov      dword ptr [rbp-0xC8], eax
       jmp      SHORT G_M000_IG27
 
G_M000_IG23:                ;; offset=0x023A
       mov      rax, bword ptr [rbp-0x50]
       mov      bword ptr [rbp-0x90], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x98], rax
 
G_M000_IG24:                ;; offset=0x0250
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG25:                ;; offset=0x025D
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
       mov      rax, qword ptr [rbp-0x70]
       mov      qword ptr [rbp-0xB0], rax
 
G_M000_IG26:                ;; offset=0x0275
       mov      eax, dword ptr [rbp-0x84]
       mov      dword ptr [rbp-0xC4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xC8], eax
 
G_M000_IG27:                ;; offset=0x0289
       vmovdqu  xmm0, xmmword ptr [rbp-0xA8]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG28:                ;; offset=0x0299
       vmovdqu  xmm0, xmmword ptr [rbp-0xC0]
       vmovdqu  xmmword ptr [rbp-0x110], xmm0
       mov      rax, qword ptr [rbp-0xB0]
       mov      qword ptr [rbp-0x100], rax
 
G_M000_IG29:                ;; offset=0x02B7
       mov      eax, dword ptr [rbp-0xC8]
       mov      dword ptr [rsp+0x20], eax
       lea      rdx, [rbp-0xF8]
       lea      r8, [rbp-0x110]
       mov      rcx, gword ptr [rbp-0x98]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:ConsumeBorrowedNativeLine(System.ReadOnlySpan`1[byte],System.Nullable`1[System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]],bool,int):int:this]
       mov      rcx, bword ptr [rbp-0x90]
       mov      dword ptr [rcx], eax
       mov      eax, 1
 
G_M000_IG30:                ;; offset=0x02F3
       add      rsp, 320
       pop      rbp
       ret      
 
; Total bytes of code 764

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:TryDescribeLiteralRecord(System.ReadOnlySpan`1[byte],byref,bool):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 336
       lea      rbp, [rsp+0x150]
       xor      eax, eax
       mov      qword ptr [rbp-0x118], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x110], xmm4
       mov      rax, -192
 
G_M000_IG62:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG62
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
 
G_M000_IG02:                ;; offset=0x005B
       mov      dword ptr [rbp-0xB4], 0x3E8
       mov      rax, gword ptr [rbp+0x10]
       cmp      gword ptr [rax+0x50], 0
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0070
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xB0], rax
       mov      rcx, gword ptr [rbp-0xB0]
       mov      rdx, 0x1C842436428
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, gword ptr [rbp-0xB0]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG04:                ;; offset=0x00AA
       mov      rcx, bword ptr [rbp+0x18]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rcx, 0x7FF9D7966F98
       call     CORINFO_HELP_COUNTPROFILE32
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG59
 
G_M000_IG05:                ;; offset=0x00DE
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax]
       mov      dword ptr [rbp-0x3C], eax
       cmp      dword ptr [rbp-0x3C], 0
       jne      G_M000_IG11
       mov      rax, bword ptr [rbp+0x18]
       cmp      dword ptr [rax+0x08], 0
       jbe      G_M000_IG61
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       movzx    rax, byte  ptr [rax]
       mov      dword ptr [rbp-0x60], eax
       cmp      dword ptr [rbp-0x60], 10
       je       SHORT G_M000_IG07
       cmp      dword ptr [rbp-0x60], 13
       jne      SHORT G_M000_IG10
 
G_M000_IG06:                ;; offset=0x0118
       mov      rcx, 0x7FF9D7966F9C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG07:                ;; offset=0x0127
       mov      rcx, 0x7FF9D7966FA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x18]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG08:                ;; offset=0x0152
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG09:                ;; offset=0x015E
       mov      rax, bword ptr [rbp+0x20]
       mov      bword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0xC8]
       movzx    r9, byte  ptr [rbp+0x28]
       mov      rcx, gword ptr [rbp+0x10]
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:CompleteLiteralRecord(System.ReadOnlySpan`1[byte],int,bool,byref):this]
       jmp      G_M000_IG51
 
G_M000_IG10:                ;; offset=0x0185
       mov      rcx, 0x7FF9D7966FA4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x0194
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x30]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       jne      SHORT G_M000_IG14
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG12:                ;; offset=0x01B0
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0xA0], xmm0
 
G_M000_IG13:                ;; offset=0x01BD
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x01BF
       mov      rcx, 0x7FF9D7966FA8
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0xA0]
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG15:                ;; offset=0x01E1
       vmovdqu  xmm0, xmmword ptr [rbp-0xA0]
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
 
G_M000_IG16:                ;; offset=0x01EE
       lea      rcx, [rbp-0x50]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG17
       cmp      dword ptr [rbp-0x48], 0
       jbe      G_M000_IG61
       mov      rax, bword ptr [rbp-0x50]
       movzx    rax, byte  ptr [rax]
       mov      dword ptr [rbp-0xA4], eax
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0215
       mov      rcx, 0x7FF9D7966FAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xA4], -1
 
G_M000_IG18:                ;; offset=0x022E
       mov      eax, dword ptr [rbp-0xA4]
       mov      dword ptr [rbp-0x5C], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x60]
       cmp      eax, dword ptr [rbp-0x5C]
       je       SHORT G_M000_IG20
       cmp      dword ptr [rbp-0x5C], 10
       je       SHORT G_M000_IG22
       cmp      dword ptr [rbp-0x5C], 13
       jne      SHORT G_M000_IG21
 
G_M000_IG19:                ;; offset=0x024F
       mov      rcx, 0x7FF9D7966FB0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG20:                ;; offset=0x025E
       mov      dword ptr [rbp-0x5C], -1
       jmp      G_M000_IG54
 
G_M000_IG21:                ;; offset=0x026A
       mov      rcx, 0x7FF9D7966FB4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG54
 
G_M000_IG22:                ;; offset=0x027E
       mov      rcx, 0x7FF9D7966FB8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG20
 
G_M000_IG23:                ;; offset=0x028F
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x3C]
       jle      G_M000_IG37
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x3C], eax
       jae      G_M000_IG61
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x3C]
       movzx    rax, byte  ptr [rax+rcx]
       mov      ecx, dword ptr [rbp-0x5C]
       cmp      eax, ecx
       jne      G_M000_IG36
       cmp      dword ptr [rbp-0x48], 1
       jne      G_M000_IG35
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG24:                ;; offset=0x02D6
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG25:                ;; offset=0x02E2
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       lea      rdx, [rbp-0xD8]
       movzx    r9, byte  ptr [rbp-0x5C]
       mov      eax, dword ptr [rbp-0x3C]
       lea      r8d, [rax+0x01]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:FindLiteralQuote(System.ReadOnlySpan`1[byte],int,byte,bool):int:this]
       mov      dword ptr [rbp-0x8C], eax
       cmp      dword ptr [rbp-0x8C], 0
       jl       G_M000_IG34
       mov      eax, dword ptr [rbp-0x8C]
       inc      eax
       mov      dword ptr [rbp-0x74], eax
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       SHORT G_M000_IG27
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       je       G_M000_IG33
 
G_M000_IG26:                ;; offset=0x033D
       mov      rcx, 0x7FF9D7966FBC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG27:                ;; offset=0x034C
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       jle      SHORT G_M000_IG29
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG61
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       movzx    rax, byte  ptr [rax+rcx]
       mov      rcx, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x60]
       cmp      eax, ecx
       je       G_M000_IG32
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG61
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       movzx    rax, byte  ptr [rax+rcx]
       mov      dword ptr [rbp-0x60], eax
       cmp      dword ptr [rbp-0x60], 10
       je       SHORT G_M000_IG31
       cmp      dword ptr [rbp-0x60], 13
       jne      SHORT G_M000_IG30
 
G_M000_IG28:                ;; offset=0x03B2
       mov      rcx, 0x7FF9D7966FC0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG29:                ;; offset=0x03C1
       mov      rcx, 0x7FF9D7966FC4
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm3, xmm3, xmm3
       lea      rcx, [rbp-0x88]
       mov      eax, dword ptr [rbp-0x3C]
       lea      edx, [rax+0x01]
       mov      eax, dword ptr [rbp-0x8C]
       sub      eax, dword ptr [rbp-0x3C]
       lea      r8d, [rax-0x01]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField:.ctor(int,int,double):this]
       jmp      G_M000_IG44
 
G_M000_IG30:                ;; offset=0x03F9
       mov      rcx, 0x7FF9D7966FC8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG57
 
G_M000_IG31:                ;; offset=0x040D
       mov      rcx, 0x7FF9D7966FCC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG29
 
G_M000_IG32:                ;; offset=0x041E
       mov      rcx, 0x7FF9D7966FD0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG29
 
G_M000_IG33:                ;; offset=0x042F
       mov      rcx, 0x7FF9D7966FD4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG57
 
G_M000_IG34:                ;; offset=0x0443
       mov      rcx, 0x7FF9D7966FD8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG57
 
G_M000_IG35:                ;; offset=0x0457
       mov      rcx, 0x7FF9D7966FDC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG57
 
G_M000_IG36:                ;; offset=0x046B
       mov      rcx, 0x7FF9D7966FE0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG37:                ;; offset=0x047A
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG38:                ;; offset=0x047E
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
 
G_M000_IG39:                ;; offset=0x048A
       lea      rdx, [rbp-0xE8]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8d, dword ptr [rbp-0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:FindLiteralFieldEnd(System.ReadOnlySpan`1[byte],int):int:this]
       mov      dword ptr [rbp-0x74], eax
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       SHORT G_M000_IG41
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       je       G_M000_IG45
 
G_M000_IG40:                ;; offset=0x04BA
       mov      rcx, 0x7FF9D7966FE4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG41:                ;; offset=0x04C9
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG42:                ;; offset=0x04CD
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG43:                ;; offset=0x04D9
       mov      eax, dword ptr [rbp-0x74]
       sub      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rsp+0x20], eax
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x28], eax
       lea      r8, [rbp-0xF8]
       lea      rdx, [rbp-0x88]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9d, dword ptr [rbp-0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:CreateLiteralBareField(System.ReadOnlySpan`1[byte],int,int,bool):Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField:this]
 
G_M000_IG44:                ;; offset=0x0507
       vmovups  xmm0, xmmword ptr [rbp-0x88]
       vmovups  xmmword ptr [rbp-0x108], xmm0
       lea      rdx, [rbp-0x108]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:DescribeField(Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField):this]
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       jne      SHORT G_M000_IG46
       mov      rcx, 0x7FF9D7966FE8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG51
 
G_M000_IG45:                ;; offset=0x0548
       mov      rcx, 0x7FF9D7966FEC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG57
 
G_M000_IG46:                ;; offset=0x055C
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG61
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       movzx    rax, byte  ptr [rax+rcx]
       mov      dword ptr [rbp-0x60], eax
       cmp      dword ptr [rbp-0x60], 10
       je       SHORT G_M000_IG48
       cmp      dword ptr [rbp-0x60], 13
       jne      SHORT G_M000_IG53
 
G_M000_IG47:                ;; offset=0x0589
       mov      rcx, 0x7FF9D7966FF0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG48:                ;; offset=0x0598
       mov      rcx, 0x7FF9D7966FF4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG49:                ;; offset=0x05AB
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x118], xmm0
 
G_M000_IG50:                ;; offset=0x05B7
       mov      rax, bword ptr [rbp+0x20]
       mov      bword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0x118]
       movzx    r9, byte  ptr [rbp+0x28]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8d, dword ptr [rbp-0x74]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:CompleteLiteralRecord(System.ReadOnlySpan`1[byte],int,bool,byref):this]
 
G_M000_IG51:                ;; offset=0x05DA
       mov      eax, 1
 
G_M000_IG52:                ;; offset=0x05DF
       add      rsp, 336
       pop      rbp
       ret      
 
G_M000_IG53:                ;; offset=0x05E8
       mov      rcx, 0x7FF9D7966FF8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x74]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG54:                ;; offset=0x05FF
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG56
 
G_M000_IG55:                ;; offset=0x0616
       lea      rcx, [rbp-0xB4]
       mov      edx, 443
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG56:                ;; offset=0x0629
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x20]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:get_Count():int:this]
       mov      dword ptr [rbp-0xA8], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x20]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:get_Capacity():int:this]
       cmp      eax, dword ptr [rbp-0xA8]
       jg       G_M000_IG23
 
G_M000_IG57:                ;; offset=0x065B
       mov      rcx, 0x7FF9D7966FFC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
       mov      ecx, dword ptr [rbp-0x3C]
       mov      dword ptr [rax], ecx
       xor      eax, eax
 
G_M000_IG58:                ;; offset=0x0675
       add      rsp, 336
       pop      rbp
       ret      
 
G_M000_IG59:                ;; offset=0x067E
       movzx    rax, byte  ptr [rbp-0xB8]
 
G_M000_IG60:                ;; offset=0x0685
       add      rsp, 336
       pop      rbp
       ret      
 
G_M000_IG61:                ;; offset=0x068E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1684

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:TryConsumeBufferedCsvLine(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,System.Nullable`1[System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]],byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 320
       lea      rbp, [rsp+0x140]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x110], xmm4
       vmovdqa  xmmword ptr [rbp-0x100], xmm4
       mov      rax, -240
 
G_M000_IG36:                ;; offset=0x002E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG36
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0055
       mov      rax, bword ptr [rbp+0x28]
       mov      dword ptr [rax], -1
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x6C]
       mov      dword ptr [rbp-0x04], eax
       lea      rdx, [rbp-0x18]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x78]
       call     [System.ReadOnlyMemory`1[byte]:get_Span():System.ReadOnlySpan`1[byte]:this]
       mov      eax, dword ptr [rbp-0x04]
       cmp      eax, dword ptr [rbp-0x10]
       jne      SHORT G_M000_IG04
       mov      rcx, 0x7FF9D7AA6868
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x009A
       add      rsp, 320
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x00A3
       xor      eax, eax
       mov      dword ptr [rbp-0x20], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x58]
       mov      dword ptr [rbp-0x2C], eax
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG06
       cmp      dword ptr [rbp-0x2C], 1
       jne      SHORT G_M000_IG09
 
G_M000_IG05:                ;; offset=0x00BE
       mov      rcx, 0x7FF9D7AA686C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG06:                ;; offset=0x00CD
       lea      rdx, [rbp-0x40]
       lea      rcx, [rbp-0x18]
       mov      r8d, dword ptr [rbp-0x04]
       call     [System.ReadOnlySpan`1[byte]:Slice(int):System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG07:                ;; offset=0x00DF
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG08:                ;; offset=0x00EC
       lea      rdx, [rbp-0xD8]
       lea      r8, [rbp-0x20]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:TryDescribeBufferedNativeLine(System.ReadOnlySpan`1[byte],byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x0108
       mov      rcx, 0x7FF9D7AA6870
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
 
G_M000_IG10:                ;; offset=0x011C
       movzx    rax, byte  ptr [rbp-0x44]
       mov      dword ptr [rbp-0x24], eax
       cmp      dword ptr [rbp-0x24], 0
       jne      SHORT G_M000_IG13
 
G_M000_IG11:                ;; offset=0x0129
       vmovdqu  xmm0, xmmword ptr [rbp-0x18]
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
 
G_M000_IG12:                ;; offset=0x0136
       lea      rcx, [rbp-0xE8]
       mov      rax, gword ptr [rbp+0x10]
       mov      r8d, dword ptr [rax+0x58]
       mov      eax, dword ptr [rbp-0x04]
       mov      edx, eax
       add      edx, dword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.Text.TextLineScanning:FindLineEndByte(System.ReadOnlySpan`1[byte],int,int):int]
       mov      dword ptr [rbp-0x48], eax
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x0158
       mov      rcx, 0x7FF9D7AA6874
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x04]
       add      eax, dword ptr [rbp-0x20]
       mov      dword ptr [rbp-0x48], eax
 
G_M000_IG14:                ;; offset=0x0170
       mov      eax, dword ptr [rbp-0x48]
       mov      dword ptr [rbp-0x28], eax
       mov      eax, dword ptr [rbp-0x28]
       cmp      eax, dword ptr [rbp-0x10]
       jne      SHORT G_M000_IG21
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:EndsWithTerminator():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG20
       cmp      dword ptr [rbp-0x24], 0
       jne      SHORT G_M000_IG16
       cmp      dword ptr [rbp-0x20], 0
       je       SHORT G_M000_IG19
 
G_M000_IG15:                ;; offset=0x0198
       mov      rcx, 0x7FF9D7AA6878
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG16:                ;; offset=0x01A7
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:DiscardBufferedNativeLine():this]
 
G_M000_IG17:                ;; offset=0x01B3
       mov      rcx, 0x7FF9D7AA687C
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG18:                ;; offset=0x01C4
       add      rsp, 320
       pop      rbp
       ret      
 
G_M000_IG19:                ;; offset=0x01CD
       mov      rcx, 0x7FF9D7AA6880
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG17
 
G_M000_IG20:                ;; offset=0x01DE
       mov      rcx, 0x7FF9D7AA6884
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG21:                ;; offset=0x01ED
       mov      rcx, gword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:Advance(int):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x30]
       xor      rdx, rdx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      eax, dword ptr [rbp-0x04]
       mov      dword ptr [rbp-0x30], eax
       mov      rax, bword ptr [rbp+0x28]
       mov      bword ptr [rbp-0x50], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x58], rax
       mov      eax, dword ptr [rbp-0x28]
       mov      r9d, eax
       sub      r9d, dword ptr [rbp-0x30]
       lea      rcx, [rbp-0x18]
       lea      rdx, [rbp-0x68]
       mov      r8d, dword ptr [rbp-0x30]
       call     [System.ReadOnlySpan`1[byte]:Slice(int,int):System.ReadOnlySpan`1[byte]:this]
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG22:                ;; offset=0x0242
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x80], xmm0
       mov      rcx, qword ptr [rax+0x10]
       mov      qword ptr [rbp-0x70], rcx
 
G_M000_IG23:                ;; offset=0x0253
       mov      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x84], eax
       cmp      dword ptr [rbp-0x24], 0
       jne      SHORT G_M000_IG27
       mov      rax, bword ptr [rbp-0x50]
       mov      bword ptr [rbp-0x90], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x98], rax
 
G_M000_IG24:                ;; offset=0x0278
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG25:                ;; offset=0x0285
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
       mov      rax, qword ptr [rbp-0x70]
       mov      qword ptr [rbp-0xB0], rax
 
G_M000_IG26:                ;; offset=0x029D
       mov      eax, dword ptr [rbp-0x84]
       mov      dword ptr [rbp-0xC4], eax
       mov      eax, dword ptr [rbp-0x20]
       mov      dword ptr [rbp-0xC8], eax
       jmp      SHORT G_M000_IG31
 
G_M000_IG27:                ;; offset=0x02B4
       mov      rcx, 0x7FF9D7AA6888
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x50]
       mov      bword ptr [rbp-0x90], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x98], rax
 
G_M000_IG28:                ;; offset=0x02D9
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG29:                ;; offset=0x02E6
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
       mov      rax, qword ptr [rbp-0x70]
       mov      qword ptr [rbp-0xB0], rax
 
G_M000_IG30:                ;; offset=0x02FE
       mov      eax, dword ptr [rbp-0x84]
       mov      dword ptr [rbp-0xC4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xC8], eax
 
G_M000_IG31:                ;; offset=0x0312
       mov      rcx, 0x7FF9D7AA688C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG32:                ;; offset=0x0321
       vmovdqu  xmm0, xmmword ptr [rbp-0xA8]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG33:                ;; offset=0x0331
       vmovdqu  xmm0, xmmword ptr [rbp-0xC0]
       vmovdqu  xmmword ptr [rbp-0x110], xmm0
       mov      rax, qword ptr [rbp-0xB0]
       mov      qword ptr [rbp-0x100], rax
 
G_M000_IG34:                ;; offset=0x034F
       mov      eax, dword ptr [rbp-0xC8]
       mov      dword ptr [rsp+0x20], eax
       lea      rdx, [rbp-0xF8]
       lea      r8, [rbp-0x110]
       mov      rcx, gword ptr [rbp-0x98]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:ConsumeBorrowedNativeLine(System.ReadOnlySpan`1[byte],System.Nullable`1[System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]],bool,int):int:this]
       mov      rcx, bword ptr [rbp-0x90]
       mov      dword ptr [rcx], eax
       mov      eax, 1
 
G_M000_IG35:                ;; offset=0x038B
       add      rsp, 320
       pop      rbp
       ret      
 
; Total bytes of code 916

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:TryDescribeLiteralRecord(System.ReadOnlySpan`1[byte],byref,bool):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 336
       lea      rbp, [rsp+0x150]
       xor      eax, eax
       mov      qword ptr [rbp-0x118], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x110], xmm4
       mov      rax, -192
 
G_M000_IG62:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG62
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
 
G_M000_IG02:                ;; offset=0x005B
       mov      dword ptr [rbp-0xB4], 0x3E8
       mov      rax, gword ptr [rbp+0x10]
       cmp      gword ptr [rax+0x50], 0
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0070
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xB0], rax
       mov      rcx, gword ptr [rbp-0xB0]
       mov      rdx, 0x1C842436428
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, gword ptr [rbp-0xB0]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG04:                ;; offset=0x00AA
       mov      rcx, bword ptr [rbp+0x18]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rcx, 0x7FF9D7966F98
       call     CORINFO_HELP_COUNTPROFILE32
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG59
 
G_M000_IG05:                ;; offset=0x00DE
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax]
       mov      dword ptr [rbp-0x3C], eax
       cmp      dword ptr [rbp-0x3C], 0
       jne      G_M000_IG11
       mov      rax, bword ptr [rbp+0x18]
       cmp      dword ptr [rax+0x08], 0
       jbe      G_M000_IG61
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       movzx    rax, byte  ptr [rax]
       mov      dword ptr [rbp-0x60], eax
       cmp      dword ptr [rbp-0x60], 10
       je       SHORT G_M000_IG07
       cmp      dword ptr [rbp-0x60], 13
       jne      SHORT G_M000_IG10
 
G_M000_IG06:                ;; offset=0x0118
       mov      rcx, 0x7FF9D7966F9C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG07:                ;; offset=0x0127
       mov      rcx, 0x7FF9D7966FA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x18]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG08:                ;; offset=0x0152
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG09:                ;; offset=0x015E
       mov      rax, bword ptr [rbp+0x20]
       mov      bword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0xC8]
       movzx    r9, byte  ptr [rbp+0x28]
       mov      rcx, gword ptr [rbp+0x10]
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:CompleteLiteralRecord(System.ReadOnlySpan`1[byte],int,bool,byref):this]
       jmp      G_M000_IG51
 
G_M000_IG10:                ;; offset=0x0185
       mov      rcx, 0x7FF9D7966FA4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x0194
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x30]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       jne      SHORT G_M000_IG14
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG12:                ;; offset=0x01B0
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0xA0], xmm0
 
G_M000_IG13:                ;; offset=0x01BD
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x01BF
       mov      rcx, 0x7FF9D7966FA8
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0xA0]
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG15:                ;; offset=0x01E1
       vmovdqu  xmm0, xmmword ptr [rbp-0xA0]
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
 
G_M000_IG16:                ;; offset=0x01EE
       lea      rcx, [rbp-0x50]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG17
       cmp      dword ptr [rbp-0x48], 0
       jbe      G_M000_IG61
       mov      rax, bword ptr [rbp-0x50]
       movzx    rax, byte  ptr [rax]
       mov      dword ptr [rbp-0xA4], eax
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0215
       mov      rcx, 0x7FF9D7966FAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xA4], -1
 
G_M000_IG18:                ;; offset=0x022E
       mov      eax, dword ptr [rbp-0xA4]
       mov      dword ptr [rbp-0x5C], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x60]
       cmp      eax, dword ptr [rbp-0x5C]
       je       SHORT G_M000_IG20
       cmp      dword ptr [rbp-0x5C], 10
       je       SHORT G_M000_IG22
       cmp      dword ptr [rbp-0x5C], 13
       jne      SHORT G_M000_IG21
 
G_M000_IG19:                ;; offset=0x024F
       mov      rcx, 0x7FF9D7966FB0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG20:                ;; offset=0x025E
       mov      dword ptr [rbp-0x5C], -1
       jmp      G_M000_IG54
 
G_M000_IG21:                ;; offset=0x026A
       mov      rcx, 0x7FF9D7966FB4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG54
 
G_M000_IG22:                ;; offset=0x027E
       mov      rcx, 0x7FF9D7966FB8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG20
 
G_M000_IG23:                ;; offset=0x028F
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x3C]
       jle      G_M000_IG37
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x3C], eax
       jae      G_M000_IG61
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x3C]
       movzx    rax, byte  ptr [rax+rcx]
       mov      ecx, dword ptr [rbp-0x5C]
       cmp      eax, ecx
       jne      G_M000_IG36
       cmp      dword ptr [rbp-0x48], 1
       jne      G_M000_IG35
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG24:                ;; offset=0x02D6
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG25:                ;; offset=0x02E2
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       lea      rdx, [rbp-0xD8]
       movzx    r9, byte  ptr [rbp-0x5C]
       mov      eax, dword ptr [rbp-0x3C]
       lea      r8d, [rax+0x01]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:FindLiteralQuote(System.ReadOnlySpan`1[byte],int,byte,bool):int:this]
       mov      dword ptr [rbp-0x8C], eax
       cmp      dword ptr [rbp-0x8C], 0
       jl       G_M000_IG34
       mov      eax, dword ptr [rbp-0x8C]
       inc      eax
       mov      dword ptr [rbp-0x74], eax
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       SHORT G_M000_IG27
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       je       G_M000_IG33
 
G_M000_IG26:                ;; offset=0x033D
       mov      rcx, 0x7FF9D7966FBC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG27:                ;; offset=0x034C
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       jle      SHORT G_M000_IG29
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG61
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       movzx    rax, byte  ptr [rax+rcx]
       mov      rcx, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x60]
       cmp      eax, ecx
       je       G_M000_IG32
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG61
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       movzx    rax, byte  ptr [rax+rcx]
       mov      dword ptr [rbp-0x60], eax
       cmp      dword ptr [rbp-0x60], 10
       je       SHORT G_M000_IG31
       cmp      dword ptr [rbp-0x60], 13
       jne      SHORT G_M000_IG30
 
G_M000_IG28:                ;; offset=0x03B2
       mov      rcx, 0x7FF9D7966FC0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG29:                ;; offset=0x03C1
       mov      rcx, 0x7FF9D7966FC4
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm3, xmm3, xmm3
       lea      rcx, [rbp-0x88]
       mov      eax, dword ptr [rbp-0x3C]
       lea      edx, [rax+0x01]
       mov      eax, dword ptr [rbp-0x8C]
       sub      eax, dword ptr [rbp-0x3C]
       lea      r8d, [rax-0x01]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField:.ctor(int,int,double):this]
       jmp      G_M000_IG44
 
G_M000_IG30:                ;; offset=0x03F9
       mov      rcx, 0x7FF9D7966FC8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG57
 
G_M000_IG31:                ;; offset=0x040D
       mov      rcx, 0x7FF9D7966FCC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG29
 
G_M000_IG32:                ;; offset=0x041E
       mov      rcx, 0x7FF9D7966FD0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG29
 
G_M000_IG33:                ;; offset=0x042F
       mov      rcx, 0x7FF9D7966FD4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG57
 
G_M000_IG34:                ;; offset=0x0443
       mov      rcx, 0x7FF9D7966FD8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG57
 
G_M000_IG35:                ;; offset=0x0457
       mov      rcx, 0x7FF9D7966FDC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG57
 
G_M000_IG36:                ;; offset=0x046B
       mov      rcx, 0x7FF9D7966FE0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG37:                ;; offset=0x047A
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG38:                ;; offset=0x047E
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
 
G_M000_IG39:                ;; offset=0x048A
       lea      rdx, [rbp-0xE8]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8d, dword ptr [rbp-0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:FindLiteralFieldEnd(System.ReadOnlySpan`1[byte],int):int:this]
       mov      dword ptr [rbp-0x74], eax
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       SHORT G_M000_IG41
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       je       G_M000_IG45
 
G_M000_IG40:                ;; offset=0x04BA
       mov      rcx, 0x7FF9D7966FE4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG41:                ;; offset=0x04C9
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG42:                ;; offset=0x04CD
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG43:                ;; offset=0x04D9
       mov      eax, dword ptr [rbp-0x74]
       sub      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rsp+0x20], eax
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x28], eax
       lea      r8, [rbp-0xF8]
       lea      rdx, [rbp-0x88]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9d, dword ptr [rbp-0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:CreateLiteralBareField(System.ReadOnlySpan`1[byte],int,int,bool):Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField:this]
 
G_M000_IG44:                ;; offset=0x0507
       vmovups  xmm0, xmmword ptr [rbp-0x88]
       vmovups  xmmword ptr [rbp-0x108], xmm0
       lea      rdx, [rbp-0x108]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:DescribeField(Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField):this]
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       jne      SHORT G_M000_IG46
       mov      rcx, 0x7FF9D7966FE8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG51
 
G_M000_IG45:                ;; offset=0x0548
       mov      rcx, 0x7FF9D7966FEC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG57
 
G_M000_IG46:                ;; offset=0x055C
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG61
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       movzx    rax, byte  ptr [rax+rcx]
       mov      dword ptr [rbp-0x60], eax
       cmp      dword ptr [rbp-0x60], 10
       je       SHORT G_M000_IG48
       cmp      dword ptr [rbp-0x60], 13
       jne      SHORT G_M000_IG53
 
G_M000_IG47:                ;; offset=0x0589
       mov      rcx, 0x7FF9D7966FF0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG48:                ;; offset=0x0598
       mov      rcx, 0x7FF9D7966FF4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG49:                ;; offset=0x05AB
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x118], xmm0
 
G_M000_IG50:                ;; offset=0x05B7
       mov      rax, bword ptr [rbp+0x20]
       mov      bword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0x118]
       movzx    r9, byte  ptr [rbp+0x28]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8d, dword ptr [rbp-0x74]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:CompleteLiteralRecord(System.ReadOnlySpan`1[byte],int,bool,byref):this]
 
G_M000_IG51:                ;; offset=0x05DA
       mov      eax, 1
 
G_M000_IG52:                ;; offset=0x05DF
       add      rsp, 336
       pop      rbp
       ret      
 
G_M000_IG53:                ;; offset=0x05E8
       mov      rcx, 0x7FF9D7966FF8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x74]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG54:                ;; offset=0x05FF
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG56
 
G_M000_IG55:                ;; offset=0x0616
       lea      rcx, [rbp-0xB4]
       mov      edx, 443
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG56:                ;; offset=0x0629
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x20]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:get_Count():int:this]
       mov      dword ptr [rbp-0xA8], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x20]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:get_Capacity():int:this]
       cmp      eax, dword ptr [rbp-0xA8]
       jg       G_M000_IG23
 
G_M000_IG57:                ;; offset=0x065B
       mov      rcx, 0x7FF9D7966FFC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
       mov      ecx, dword ptr [rbp-0x3C]
       mov      dword ptr [rax], ecx
       xor      eax, eax
 
G_M000_IG58:                ;; offset=0x0675
       add      rsp, 336
       pop      rbp
       ret      
 
G_M000_IG59:                ;; offset=0x067E
       movzx    rax, byte  ptr [rbp-0xB8]
 
G_M000_IG60:                ;; offset=0x0685
       add      rsp, 336
       pop      rbp
       ret      
 
G_M000_IG61:                ;; offset=0x068E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1684

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:TryConsumeBufferedCsvLine(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,System.Nullable`1[System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]],byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 118472
; 44 inlinees with PGO data; 87 single block inlinees; 4 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 424
       vmovaps  xmmword ptr [rsp+0x190], xmm6
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rsp+0x90], xmm4
       mov      rax, -240
 
G_M000_IG149:                ;; offset=0x0033
       vmovdqa  xmmword ptr [rsp+rax+0x190], xmm4
       vmovdqa  xmmword ptr [rsp+rax+0x1A0], xmm4
       vmovdqa  xmmword ptr [rsp+rax+0x1B0], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG149
       mov      bword ptr [rsp+0x200], r8
       mov      rsi, rcx
       mov      rdi, rdx
       mov      rbp, r9
 
G_M000_IG02:                ;; offset=0x0065
       mov      bword ptr [rsp+0x208], rbp
       mov      dword ptr [rbp], -1
       mov      r14d, dword ptr [rsi+0x6C]
       lea      r15, bword ptr [rsi+0x78]
       xor      r13, r13
       xor      r12d, r12d
       mov      rcx, gword ptr [r15]
       test     rcx, rcx
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x008A
       mov      rdx, qword ptr [rcx]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       je       G_M000_IG95
       lea      r13, bword ptr [rcx+0x10]
       mov      r12d, dword ptr [rcx+0x08]
 
G_M000_IG04:                ;; offset=0x00A1
       mov      ecx, dword ptr [r15+0x08]
       and      ecx, 0x7FFFFFFF
       mov      eax, dword ptr [r15+0x0C]
       mov      edx, eax
       add      rdx, rcx
       mov      r8d, r12d
       cmp      rdx, r8
       ja       G_M000_IG96
       add      r13, rcx
       mov      r12d, eax
 
G_M000_IG05:                ;; offset=0x00C6
       mov      r15, r13
       mov      bword ptr [rsp+0x38], r15
       mov      dword ptr [rsp+0xE4], r12d
       cmp      r14d, r12d
       je       G_M000_IG97
 
G_M000_IG06:                ;; offset=0x00DF
       xor      ecx, ecx
       mov      dword ptr [rsp+0x188], ecx
       mov      ecx, dword ptr [rsi+0x58]
       test     ecx, ecx
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x00EF
       cmp      ecx, 1
       jne      G_M000_IG132
 
G_M000_IG08:                ;; offset=0x00F8
       cmp      r14d, r12d
       ja       G_M000_IG96
       mov      r13d, r14d
       add      r13, r15
       mov      eax, r12d
       sub      eax, r14d
       mov      dword ptr [rsp+0x14C], eax
       cmp      byte  ptr [rdi], dil
       xor      ecx, ecx
       mov      dword ptr [rsp+0x188], ecx
       mov      gword ptr [rsp+0x1F8], rdi
       mov      rdx, gword ptr [rdi+0x08]
       mov      gword ptr [rsp+0x78], rdx
       mov      r8, r13
       mov      bword ptr [rsp+0x30], r8
       mov      r10d, eax
       mov      dword ptr [rsp+0xE0], r10d
       cmp      gword ptr [rdx+0x50], 0
       jne      G_M000_IG99
       test     r10d, r10d
       je       G_M000_IG100
       mov      r9d, dword ptr [rsp+0x188]
       mov      dword ptr [rsp+0x148], r9d
       test     r9d, r9d
       jne      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x016D
       movzx    r11, byte  ptr [r8]
       cmp      r11d, 10
       je       G_M000_IG101
       cmp      r11d, 13
       mov      r8, bword ptr [rsp+0x30]
       je       G_M000_IG101
 
G_M000_IG10:                ;; offset=0x018A
       mov      r13, gword ptr [rdx+0x30]
       test     r13, r13
       je       G_M000_IG80
 
G_M000_IG11:                ;; offset=0x0197
       movzx    rcx, byte  ptr [r13+0x24]
       test     ecx, ecx
       je       G_M000_IG103
 
G_M000_IG12:                ;; offset=0x01A4
       cmp      ecx, 255
       je       G_M000_IG107
       lea      rax, bword ptr [r13+0x28]
       mov      r13d, dword ptr [r13+0x18]
       cmp      r13d, 8
       ja       G_M000_IG96
 
G_M000_IG13:                ;; offset=0x01C2
       mov      dword ptr [rsp+0xDC], r13d
       test     r13d, r13d
       je       G_M000_IG110
       movzx    rax, byte  ptr [rax]
 
G_M000_IG14:                ;; offset=0x01D6
       mov      rdx, gword ptr [rsp+0x78]
       cmp      eax, dword ptr [rdx+0x60]
       je       G_M000_IG81
 
G_M000_IG15:                ;; offset=0x01E4
       cmp      eax, 10
       je       G_M000_IG81
       cmp      eax, 13
       jne      G_M000_IG37
       jmp      G_M000_IG81
 
G_M000_IG16:                ;; offset=0x01FB
       mov      ecx, r11d
       mov      r15d, ebp
       add      rcx, r15
       mov      r15d, r10d
       cmp      rcx, r15
       ja       G_M000_IG96
       mov      dword ptr [rsp+0x120], r11d
       mov      ecx, r11d
       add      rcx, r8
       mov      rdx, gword ptr [rsp+0x78]
       mov      r15, gword ptr [rdx+0x40]
       test     r15, r15
       je       G_M000_IG129
       mov      rbx, 0x7FF9D749EAE8
       cmp      qword ptr [r15], rbx
       jne      G_M000_IG44
 
G_M000_IG17:                ;; offset=0x0243
       mov      dword ptr [rsp+0x144], eax
       mov      dword ptr [rsp+0x20], ebp
       movzx    r9, byte  ptr [r15+0x0A]
       movzx    rdx, byte  ptr [r15+0x08]
       movzx    r8, byte  ptr [r15+0x09]
       call     [System.SpanHelpers:NonPackedIndexOfAnyValueType[byte,System.SpanHelpers+DontNegate`1[byte]](byref,byte,byte,byte,int):int]
 
G_M000_IG18:                ;; offset=0x0263
       test     eax, eax
       jl       G_M000_IG121
 
G_M000_IG19:                ;; offset=0x026B
       mov      ebx, dword ptr [rsp+0x120]
       add      eax, ebx
       mov      r11d, eax
 
G_M000_IG20:                ;; offset=0x0277
       mov      r10d, r11d
       mov      ebp, dword ptr [rsp+0xE0]
       cmp      r10d, ebp
       je       G_M000_IG131
 
G_M000_IG21:                ;; offset=0x028A
       mov      dword ptr [rsp+0x140], r10d
       mov      r9d, dword ptr [rsp+0x148]
       mov      r11d, r10d
       sub      r11d, r9d
       mov      rdx, gword ptr [rsp+0x78]
       mov      rcx, gword ptr [rdx+0x08]
       cmp      dword ptr [rcx+0x28], 2
       jne      G_M000_IG123
       test     r11d, r11d
       je       G_M000_IG123
       mov      ecx, r9d
       mov      r15d, r11d
       add      rcx, r15
       mov      r15d, ebp
       cmp      rcx, r15
       ja       G_M000_IG96
       mov      ecx, r9d
       add      rcx, bword ptr [rsp+0x30]
       mov      r15d, r11d
       mov      dword ptr [rsp+0xD4], r15d
       movzx    rbx, byte  ptr [rcx]
       cmp      ebx, 45
       sete     r13b
       movzx    r13, r13b
       mov      dword ptr [rsp+0x10C], r13d
       cmp      ebx, 43
       je       G_M000_IG125
       cmp      ebx, 45
       setne    bl
       movzx    rbx, bl
 
G_M000_IG22:                ;; offset=0x030C
       test     ebx, ebx
       sete     bl
       movzx    rbx, bl
       mov      edi, r15d
       sub      edi, ebx
       mov      r13d, edi
       sub      r13d, 1
       cmp      r13d, 16
       ja       G_M000_IG124
       xor      r13d, r13d
       mov      r12d, -1
       cmp      ebx, r11d
       jge      SHORT G_M000_IG26
       align    [0 bytes for IG23]
 
G_M000_IG23:                ;; offset=0x0338
       movzx    r15, byte  ptr [rcx+rbx]
       add      r15d, -48
       cmp      r15d, 9
       ja       G_M000_IG45
 
G_M000_IG24:                ;; offset=0x034B
       lea      r13, [r13+4*r13]
       mov      r15d, r15d
       lea      r13, [r15+2*r13]
 
G_M000_IG25:                ;; offset=0x0357
       inc      ebx
       cmp      ebx, r11d
       jl       SHORT G_M000_IG23
 
G_M000_IG26:                ;; offset=0x035E
       cmp      edi, 1
       je       G_M000_IG46
 
G_M000_IG27:                ;; offset=0x0367
       mov      rcx, 0x20000000000000
       cmp      r13, rcx
       ja       G_M000_IG124
       test     r12d, r12d
       jl       G_M000_IG47
 
G_M000_IG28:                ;; offset=0x0383
       mov      r15d, dword ptr [rsp+0xD4]
       sub      r15d, r12d
       dec      r15d
 
G_M000_IG29:                ;; offset=0x0391
       vxorps   xmm0, xmm0, xmm0
       mov      r9, r13
       shr      r9, 1
       mov      ecx, r13d
       and      ecx, 1
       or       rcx, r9
       test     r13, r13
       cmovns   rcx, r13
       vcvtsi2sd xmm0, rcx
       jns      SHORT G_M000_IG30
       vaddsd   xmm0, xmm0
 
G_M000_IG30:                ;; offset=0x03B6
       cmp      r15d, 19
       jae      G_M000_IG147
       mov      ecx, r15d
       mov      r11, 0x1C844D3C5A0
       vdivsd   xmm6, xmm0, qword ptr [r11+8*rcx]
       cmp      dword ptr [rsp+0x10C], 0
       jne      G_M000_IG48
 
G_M000_IG31:                ;; offset=0x03E1
       mov      r9d, -1
       xor      ebx, ebx
 
G_M000_IG32:                ;; offset=0x03E9
       mov      rcx, gword ptr [rdx+0x20]
       inc      dword ptr [rcx+0x14]
       mov      r11, gword ptr [rcx+0x08]
       mov      r15d, dword ptr [rcx+0x10]
       mov      r13d, dword ptr [r11+0x08]
       cmp      r13d, r15d
       jbe      G_M000_IG128
       lea      r13d, [r15+0x01]
       mov      dword ptr [rcx+0x10], r13d
       mov      ecx, r15d
       shl      rcx, 4
       lea      rcx, bword ptr [r11+rcx+0x10]
       mov      dword ptr [rcx], r9d
       mov      dword ptr [rcx+0x04], ebx
       vmovsd   qword ptr [rcx+0x08], xmm6
 
G_M000_IG33:                ;; offset=0x0424
       test     r9d, r9d
       jl       SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x0429
       test     ebx, ebx
       jle      SHORT G_M000_IG35
       mov      ecx, ebx
       add      rcx, 128
       mov      rdx, gword ptr [rsp+0x78]
       add      rcx, qword ptr [rdx+0x58]
       jo       G_M000_IG148
       mov      qword ptr [rdx+0x58], rcx
       cmp      ebx, 8
       jg       G_M000_IG49
 
G_M000_IG35:                ;; offset=0x0452
       mov      r10d, dword ptr [rsp+0x140]
       cmp      r10d, ebp
       je       G_M000_IG52
       cmp      r10d, ebp
       jae      G_M000_IG147
       mov      ecx, r10d
       mov      r8, bword ptr [rsp+0x30]
       movzx    rbx, byte  ptr [r8+rcx]
       mov      ecx, ebx
       cmp      ecx, 10
       je       G_M000_IG50
 
G_M000_IG36:                ;; offset=0x0484
       cmp      ecx, 13
       je       G_M000_IG50
       lea      r9d, [r10+0x01]
       mov      r15d, r9d
       mov      dword ptr [rsp+0x148], r15d
       mov      eax, dword ptr [rsp+0x144]
       mov      rdx, gword ptr [rsp+0x78]
       mov      r13d, dword ptr [rsp+0xDC]
 
G_M000_IG37:                ;; offset=0x04B0
       mov      rcx, gword ptr [rdx+0x20]
       mov      r11d, dword ptr [rcx+0x10]
       mov      rcx, gword ptr [rcx+0x08]
       cmp      r11d, dword ptr [rcx+0x08]
       jge      G_M000_IG131
       mov      r9d, dword ptr [rsp+0x148]
       mov      r10d, dword ptr [rsp+0xE0]
       cmp      r9d, r10d
       jge      SHORT G_M000_IG40
 
G_M000_IG38:                ;; offset=0x04DB
       cmp      r9d, r10d
       jae      G_M000_IG147
       mov      ecx, r9d
       movzx    rcx, byte  ptr [r8+rcx]
       cmp      ecx, eax
       je       G_M000_IG82
 
G_M000_IG39:                ;; offset=0x04F4
       mov      r8, bword ptr [rsp+0x30]
 
G_M000_IG40:                ;; offset=0x04F9
       mov      dword ptr [rsp+0x148], r9d
       mov      r11d, r9d
       mov      dword ptr [rsp+0x120], r11d
       cmp      r11d, r10d
       jge      G_M000_IG122
 
G_M000_IG41:                ;; offset=0x0515
       mov      rcx, gword ptr [rdx+0x10]
       mov      r15, gword ptr [rdx+0x18]
       mov      rcx, gword ptr [rcx+0x98]
       mov      rbp, gword ptr [rcx+0x88]
       cmp      gword ptr [rbp+0x20], 0
       jne      G_M000_IG119
       mov      rbp, gword ptr [rcx+0x180]
       test     rbp, rbp
       jne      G_M000_IG118
 
G_M000_IG42:                ;; offset=0x0546
       mov      r10d, dword ptr [rsp+0xE0]
       mov      r11d, dword ptr [rsp+0x120]
       mov      ebp, r10d
       sub      ebp, r11d
       cmp      ebp, 0x1000
       jl       G_M000_IG16
 
G_M000_IG43:                ;; offset=0x0568
       mov      ebp, 0x1000
       jmp      G_M000_IG16
 
G_M000_IG44:                ;; offset=0x0572
       mov      dword ptr [rsp+0x144], eax
       mov      bword ptr [rsp+0xB0], rcx
       mov      dword ptr [rsp+0xB8], ebp
       lea      rdx, [rsp+0xB0]
       mov      rcx, r15
       mov      rbx, qword ptr [r15]
       mov      rbx, qword ptr [rbx+0x40]
       call     [rbx+0x30]System.Buffers.SearchValues`1[byte]:IndexOfAny(System.ReadOnlySpan`1[byte]):int:this
       jmp      G_M000_IG18
 
G_M000_IG45:                ;; offset=0x05A2
       cmp      byte  ptr [rcx+rbx], 46
       jne      G_M000_IG124
       test     r12d, r12d
       jge      G_M000_IG124
       mov      r12d, ebx
       jmp      G_M000_IG25
 
G_M000_IG46:                ;; offset=0x05BD
       test     r12d, r12d
       jge      G_M000_IG124
       jmp      G_M000_IG27
 
G_M000_IG47:                ;; offset=0x05CB
       xor      r15d, r15d
       jmp      G_M000_IG29
 
G_M000_IG48:                ;; offset=0x05D3
       vxorps   xmm6, xmm6, xmmword ptr [reloc @RWD00]
       jmp      G_M000_IG31
 
G_M000_IG49:                ;; offset=0x05E0
       add      ebx, dword ptr [rdx+0x6C]
       jo       G_M000_IG148
       mov      dword ptr [rdx+0x6C], ebx
       jmp      G_M000_IG35
 
G_M000_IG50:                ;; offset=0x05F1
       lea      ecx, [r10+0x01]
       cmp      ebx, 13
       je       G_M000_IG130
 
G_M000_IG51:                ;; offset=0x05FE
       mov      dword ptr [rsp+0x188], ecx
 
G_M000_IG52:                ;; offset=0x0605
       mov      r13d, 1
 
G_M000_IG53:                ;; offset=0x060B
       test     r13d, r13d
       je       G_M000_IG69
 
G_M000_IG54:                ;; offset=0x0614
       mov      eax, r14d
       add      eax, dword ptr [rsp+0x188]
 
G_M000_IG55:                ;; offset=0x061E
       mov      dword ptr [rsp+0x184], eax
       mov      r12d, dword ptr [rsp+0xE4]
       cmp      eax, r12d
       je       G_M000_IG133
 
G_M000_IG56:                ;; offset=0x0636
       lea      r8, bword ptr [rsi+0x78]
       mov      bword ptr [rsp+0x60], r8
       mov      rcx, gword ptr [r8]
       test     rcx, rcx
       je       SHORT G_M000_IG59
 
G_M000_IG57:                ;; offset=0x0647
       mov      rdx, qword ptr [rcx]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       je       G_M000_IG136
       mov      r10d, dword ptr [rcx+0x08]
 
G_M000_IG58:                ;; offset=0x065A
       mov      r8, bword ptr [rsp+0x60]
       mov      ecx, dword ptr [r8+0x08]
       and      ecx, 0x7FFFFFFF
       mov      edx, dword ptr [r8+0x0C]
       add      rcx, rdx
       mov      edx, r10d
       cmp      rcx, rdx
       ja       G_M000_IG96
 
G_M000_IG59:                ;; offset=0x067C
       mov      eax, dword ptr [rsp+0x184]
       mov      ecx, eax
       sub      ecx, dword ptr [rsi+0x6C]
       movsxd   rcx, ecx
       add      qword ptr [rsi+0x48], rcx
       mov      dword ptr [rsp+0x184], eax
       mov      dword ptr [rsi+0x6C], eax
       mov      rcx, gword ptr [rsi+0x30]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG138
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG137
 
G_M000_IG60:                ;; offset=0x06BF
       mov      eax, dword ptr [rsp+0x184]
       sub      eax, r14d
       mov      esi, eax
       mov      ecx, r14d
       mov      edx, esi
       add      rcx, rdx
       mov      edx, r12d
       cmp      rcx, rdx
       ja       G_M000_IG96
       mov      r14d, r14d
       add      r14, bword ptr [rsp+0x38]
       mov      rbx, bword ptr [rsp+0x200]
       movzx    r15, byte  ptr [rbx]
       mov      r12, gword ptr [rbx+0x08]
       mov      eax, dword ptr [rbx+0x10]
       mov      ebx, dword ptr [rbx+0x14]
       mov      rbp, bword ptr [rsp+0x208]
       mov      dword ptr [rsp+0xD0], eax
       xor      r8d, r8d
       test     r13d, r13d
       cmove    r8d, dword ptr [rsp+0x188]
       mov      dword ptr [rsp+0x164], r8d
       mov      rdi, gword ptr [rsp+0x1F8]
       mov      rcx, gword ptr [rdi+0x28]
       mov      rdx, gword ptr [rdi+0x30]
       mov      rcx, gword ptr [rcx+0x98]
       mov      r10, gword ptr [rcx+0x88]
       cmp      gword ptr [r10+0x20], 0
       jne      G_M000_IG140
       mov      r10, gword ptr [rcx+0x180]
       test     r10, r10
       jne      G_M000_IG139
 
G_M000_IG61:                ;; offset=0x075C
       inc      dword ptr [rdi+0x3C]
       mov      rdx, gword ptr [rdi+0x08]
       mov      gword ptr [rsp+0x58], rdx
       cmp      dword ptr [rdx+0x68], 0
       jge      G_M000_IG70
 
G_M000_IG62:                ;; offset=0x0772
       test     r13d, r13d
       je       G_M000_IG144
       mov      rdi, gword ptr [rdi+0x08]
       cmp      byte  ptr [rdi], dil
       test     r15d, r15d
       je       G_M000_IG146
 
G_M000_IG63:                ;; offset=0x078B
       xor      r15, r15
       xor      r13d, r13d
       test     r12, r12
       je       SHORT G_M000_IG66
 
G_M000_IG64:                ;; offset=0x0796
       mov      rdx, qword ptr [r12]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       je       G_M000_IG145
       lea      r15, bword ptr [r12+0x10]
       mov      r13d, dword ptr [r12+0x08]
 
G_M000_IG65:                ;; offset=0x07B0
       mov      eax, dword ptr [rsp+0xD0]
       and      eax, 0x7FFFFFFF
       mov      edx, eax
       mov      r8d, ebx
       add      r8, rdx
       mov      ecx, r13d
       cmp      r8, rcx
       ja       G_M000_IG96
       shl      rdx, 4
       add      r15, rdx
       mov      r13d, ebx
 
G_M000_IG66:                ;; offset=0x07DA
       mov      bword ptr [rsp+0xB0], r14
       mov      dword ptr [rsp+0xB8], esi
       mov      bword ptr [rsp+0x90], r15
       mov      dword ptr [rsp+0x98], r13d
       lea      rdx, [rsp+0xB0]
       lea      r8, [rsp+0x90]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:UnpackRecord(System.ReadOnlySpan`1[byte],System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int:this]
 
G_M000_IG67:                ;; offset=0x0812
       mov      dword ptr [rbp], eax
       mov      eax, 1
 
G_M000_IG68:                ;; offset=0x081A
       vmovaps  xmm6, xmmword ptr [rsp+0x190]
       add      rsp, 424
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG69:                ;; offset=0x0837
       mov      r15, bword ptr [rsp+0x38]
       mov      bword ptr [rsp+0xB0], r15
       mov      r12d, dword ptr [rsp+0xE4]
       mov      dword ptr [rsp+0xB8], r12d
       lea      rcx, [rsp+0xB0]
       mov      edx, r14d
       add      edx, dword ptr [rsp+0x188]
       mov      r8d, dword ptr [rsi+0x58]
       call     [Lokad.Lython.Runtime.Text.TextLineScanning:FindLineEndByte(System.ReadOnlySpan`1[byte],int,int):int]
       jmp      G_M000_IG55
 
G_M000_IG70:                ;; offset=0x0875
       mov      ecx, dword ptr [rdx+0x68]
       mov      r10d, ecx
       mov      rcx, gword ptr [rdx+0x20]
       cmp      r10d, dword ptr [rcx+0x10]
       jl       SHORT G_M000_IG75
 
G_M000_IG71:                ;; offset=0x0885
       mov      dword ptr [rdx+0x68], -1
       jmp      G_M000_IG62
 
G_M000_IG72:                ;; offset=0x0891
       vxorps   xmm0, xmm0, xmm0
 
G_M000_IG73:                ;; offset=0x0895
       mov      r10, qword ptr [rsp+0x80]
       mov      r9, gword ptr [rsp+0x50]
       cmp      r10d, dword ptr [r9+0x10]
       jae      G_M000_IG142
       mov      r8, gword ptr [r9+0x08]
       cmp      r10d, dword ptr [r8+0x08]
       jae      G_M000_IG147
       mov      rax, r10
       shl      rax, 4
       lea      rax, bword ptr [r8+rax+0x10]
       mov      dword ptr [rax], r11d
       mov      dword ptr [rax+0x04], ecx
       vmovsd   qword ptr [rax+0x08], xmm0
       inc      dword ptr [r9+0x14]
       mov      qword ptr [rsp+0x80], r10
 
G_M000_IG74:                ;; offset=0x08DD
       mov      r10, qword ptr [rsp+0x80]
       inc      r10d
       mov      rcx, gword ptr [rdx+0x20]
       cmp      r10d, dword ptr [rcx+0x10]
       jge      SHORT G_M000_IG71
 
G_M000_IG75:                ;; offset=0x08F2
       mov      qword ptr [rsp+0x80], r10
       test     r10d, 0x3FF
       je       G_M000_IG141
 
G_M000_IG76:                ;; offset=0x0907
       mov      rcx, gword ptr [rdx+0x20]
       mov      r10, qword ptr [rsp+0x80]
       cmp      r10d, dword ptr [rcx+0x10]
       jae      G_M000_IG142
       mov      rcx, gword ptr [rcx+0x08]
       cmp      r10d, dword ptr [rcx+0x08]
       jae      G_M000_IG147
       mov      qword ptr [rsp+0x80], r10
       mov      r9, r10
       shl      r9, 4
       lea      rcx, bword ptr [rcx+r9+0x10]
       mov      r11d, dword ptr [rcx]
       mov      ecx, dword ptr [rcx+0x04]
       test     ecx, ecx
       jge      SHORT G_M000_IG74
 
G_M000_IG77:                ;; offset=0x0949
       mov      r9, gword ptr [rdx+0x20]
       mov      gword ptr [rsp+0x50], r9
       not      ecx
       mov      r8, gword ptr [rdx+0x08]
       cmp      dword ptr [r8+0x28], 2
       jne      G_M000_IG72
 
G_M000_IG78:                ;; offset=0x0963
       test     ecx, ecx
       je       G_M000_IG72
 
G_M000_IG79:                ;; offset=0x096B
       mov      r8d, r11d
       mov      qword ptr [rsp+0x88], r8
       mov      r11d, ecx
       add      r11, r8
       mov      r8d, esi
       cmp      r11, r8
       ja       G_M000_IG96
       mov      r8, qword ptr [rsp+0x88]
       add      r8, r14
       mov      bword ptr [rsp+0xB0], r8
       mov      dword ptr [rsp+0xB8], ecx
       lea      rcx, [rsp+0xB0]
       mov      rdx, gword ptr [rdx+0x10]
       mov      r11, gword ptr [rsp+0x58]
       mov      r8, gword ptr [r11+0x18]
       xor      r9, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:ParseFloatText(System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.PyBytes):double]
       mov      r11d, -1
       xor      ecx, ecx
       mov      rdx, gword ptr [rsp+0x58]
       jmp      G_M000_IG73
 
G_M000_IG80:                ;; offset=0x09D2
       xor      rax, rax
       xor      r13d, r13d
       jmp      G_M000_IG13
 
G_M000_IG81:                ;; offset=0x09DC
       mov      eax, -1
       jmp      G_M000_IG37
 
G_M000_IG82:                ;; offset=0x09E6
       cmp      r13d, 1
       jne      G_M000_IG111
       mov      dword ptr [rsp+0x148], r9d
       lea      r11d, [r9+0x01]
       mov      dword ptr [rsp+0x144], eax
       movzx    rcx, al
       mov      dword ptr [rsp+0x124], ecx
       mov      dword ptr [rsp+0x128], r11d
       cmp      r11d, r10d
       jge      G_M000_IG116
 
G_M000_IG83:                ;; offset=0x0A1E
       mov      r15, gword ptr [rdx+0x10]
       mov      rbp, gword ptr [rdx+0x18]
       mov      r15, gword ptr [r15+0x98]
       mov      rbx, gword ptr [r15+0x88]
       cmp      gword ptr [rbx+0x20], 0
       jne      G_M000_IG113
       mov      rbx, gword ptr [r15+0x180]
       test     rbx, rbx
       jne      G_M000_IG112
 
G_M000_IG84:                ;; offset=0x0A4F
       mov      r10d, dword ptr [rsp+0xE0]
       mov      r11d, dword ptr [rsp+0x128]
       mov      ebx, r10d
       sub      ebx, r11d
       cmp      ebx, 0x1000
       jge      G_M000_IG93
 
G_M000_IG85:                ;; offset=0x0A71
       mov      ebp, r11d
       mov      r15d, ebx
       add      rbp, r15
       mov      r15d, r10d
       cmp      rbp, r15
       ja       G_M000_IG96
       mov      dword ptr [rsp+0x128], r11d
       mov      ebp, r11d
       add      rbp, bword ptr [rsp+0x30]
       mov      dword ptr [rsp+0x20], ebx
       mov      rcx, rbp
       mov      edx, dword ptr [rsp+0x124]
       mov      r8d, 13
       mov      r9d, 10
       call     [System.SpanHelpers:NonPackedIndexOfAnyValueType[byte,System.SpanHelpers+DontNegate`1[byte]](byref,byte,byte,byte,int):int]
       test     eax, eax
       jl       G_M000_IG114
 
G_M000_IG86:                ;; offset=0x0ABE
       cmp      eax, ebx
       jae      G_M000_IG147
       mov      ecx, eax
       movzx    rcx, byte  ptr [rcx+rbp]
       mov      ebx, dword ptr [rsp+0x124]
       cmp      ecx, ebx
       jne      G_M000_IG115
       mov      r15d, dword ptr [rsp+0x128]
       add      eax, r15d
 
G_M000_IG87:                ;; offset=0x0AE6
       test     eax, eax
       jl       G_M000_IG131
 
G_M000_IG88:                ;; offset=0x0AEE
       lea      r11d, [rax+0x01]
       mov      r10d, dword ptr [rsp+0xE0]
       cmp      r11d, r10d
       je       G_M000_IG131
 
G_M000_IG89:                ;; offset=0x0B03
       cmp      r11d, r10d
       jge      SHORT G_M000_IG92
 
G_M000_IG90:                ;; offset=0x0B08
       cmp      r11d, r10d
       jae      G_M000_IG147
       mov      ecx, r11d
       mov      r8, bword ptr [rsp+0x30]
       movzx    rcx, byte  ptr [r8+rcx]
       mov      rdx, gword ptr [rsp+0x78]
       cmp      ecx, dword ptr [rdx+0x60]
       je       SHORT G_M000_IG94
 
G_M000_IG91:                ;; offset=0x0B28
       cmp      ecx, 10
       jne      G_M000_IG117
 
G_M000_IG92:                ;; offset=0x0B31
       mov      r9d, dword ptr [rsp+0x148]
       lea      ecx, [r9+0x01]
       sub      eax, r9d
       dec      eax
       vxorps   xmm6, xmm6, xmm6
       mov      dword ptr [rsp+0x140], r11d
       mov      ebx, eax
       mov      ebp, r10d
       mov      r9d, ecx
       mov      rdx, gword ptr [rsp+0x78]
       jmp      G_M000_IG32
 
G_M000_IG93:                ;; offset=0x0B60
       mov      ebx, 0x1000
       jmp      G_M000_IG85
 
G_M000_IG94:                ;; offset=0x0B6A
       jmp      SHORT G_M000_IG92
 
G_M000_IG95:                ;; offset=0x0B6C
       lea      rdx, [rsp+0x150]
       mov      rax, qword ptr [rcx]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[byte]:GetSpan():System.Span`1[byte]:this
       mov      r13, bword ptr [rsp+0x150]
       mov      r12d, dword ptr [rsp+0x158]
       jmp      G_M000_IG04
 
G_M000_IG96:                ;; offset=0x0B93
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG97:                ;; offset=0x0B9A
       xor      eax, eax
 
G_M000_IG98:                ;; offset=0x0B9C
       vmovaps  xmm6, xmmword ptr [rsp+0x190]
       add      rsp, 424
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG99:                ;; offset=0x0BB9
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1C842436428
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG100:                ;; offset=0x0BE7
       xor      r13d, r13d
       jmp      G_M000_IG53
 
G_M000_IG101:                ;; offset=0x0BEF
       mov      rcx, gword ptr [rdx+0x10]
       mov      r8, gword ptr [rdx+0x18]
       mov      gword ptr [rsp+0x70], r8
       mov      r10, gword ptr [rcx+0x98]
       mov      gword ptr [rsp+0x68], r10
       cmp      byte  ptr [r10], r10b
       mov      rcx, r10
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG102
       mov      rcx, gword ptr [rsp+0x68]
       mov      rdx, gword ptr [rsp+0x70]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG102:                ;; offset=0x0C28
       mov      bword ptr [rsp+0xB0], r13
       mov      r13d, dword ptr [rsp+0x14C]
       mov      dword ptr [rsp+0xB8], r13d
       lea      rdx, [rsp+0x188]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0xB0]
       mov      rcx, gword ptr [rsp+0x78]
       xor      r8d, r8d
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:CompleteLiteralRecord(System.ReadOnlySpan`1[byte],int,bool,byref):this]
       jmp      G_M000_IG52
 
G_M000_IG103:                ;; offset=0x0C6E
       mov      rax, gword ptr [r13+0x08]
       mov      r13d, dword ptr [r13+0x18]
       test     rax, rax
       jne      SHORT G_M000_IG105
 
G_M000_IG104:                ;; offset=0x0C7B
       test     r13d, r13d
       jne      G_M000_IG96
       xor      rax, rax
       xor      r13d, r13d
       jmp      SHORT G_M000_IG106
 
G_M000_IG105:                ;; offset=0x0C8B
       cmp      dword ptr [rax+0x08], r13d
       jb       G_M000_IG96
       add      rax, 16
 
G_M000_IG106:                ;; offset=0x0C99
       jmp      G_M000_IG13
 
G_M000_IG107:                ;; offset=0x0C9E
       mov      rcx, gword ptr [r13+0x08]
       lea      rax, bword ptr [r13+0x28]
       mov      eax, dword ptr [rax]
       mov      r11d, dword ptr [r13+0x18]
       mov      dword ptr [rsp+0x12C], r11d
       test     rcx, rcx
       jne      SHORT G_M000_IG108
       or       eax, r11d
       jne      G_M000_IG96
       xor      rcx, rcx
       xor      r11d, r11d
       jmp      SHORT G_M000_IG109
 
G_M000_IG108:                ;; offset=0x0CC9
       mov      r13d, eax
       mov      r11d, r11d
       add      r11, r13
       mov      r13d, dword ptr [rcx+0x08]
       cmp      r11, r13
       ja       G_M000_IG96
       mov      eax, eax
       lea      rcx, bword ptr [rcx+rax+0x10]
       mov      r11d, dword ptr [rsp+0x12C]
 
G_M000_IG109:                ;; offset=0x0CEE
       mov      bword ptr [rsp+0xC0], rcx
       mov      dword ptr [rsp+0xC8], r11d
       lea      rdx, [rsp+0xC0]
       lea      rcx, [rsp+0x130]
       call     [System.Span`1[byte]:op_Implicit(System.Span`1[byte]):System.ReadOnlySpan`1[byte]]
       mov      rax, bword ptr [rsp+0x130]
       mov      r13d, dword ptr [rsp+0x138]
       mov      r8, bword ptr [rsp+0x30]
       jmp      G_M000_IG13
 
G_M000_IG110:                ;; offset=0x0D2E
       mov      eax, -1
       jmp      G_M000_IG14
 
G_M000_IG111:                ;; offset=0x0D38
       mov      dword ptr [rsp+0x148], r9d
       jmp      G_M000_IG131
 
G_M000_IG112:                ;; offset=0x0D45
       cmp      dword ptr [rbx+0x20], 0
       setne    bl
       movzx    rbx, bl
       test     ebx, ebx
       je       G_M000_IG84
 
G_M000_IG113:                ;; offset=0x0D57
       mov      rcx, r15
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG84
 
G_M000_IG114:                ;; offset=0x0D68
       mov      r15d, dword ptr [rsp+0x128]
       add      r15d, ebx
       mov      ebp, dword ptr [rsp+0xE0]
       cmp      r15d, ebp
       mov      dword ptr [rsp+0x128], r15d
       mov      rdx, gword ptr [rsp+0x78]
       jl       G_M000_IG83
       jmp      SHORT G_M000_IG116
 
G_M000_IG115:                ;; offset=0x0D92
       mov      rdx, gword ptr [rsp+0x78]
 
G_M000_IG116:                ;; offset=0x0D97
       mov      r11d, -1
       mov      eax, r11d
       jmp      G_M000_IG87
 
G_M000_IG117:                ;; offset=0x0DA5
       cmp      ecx, 13
       jne      G_M000_IG131
       jmp      G_M000_IG92
 
G_M000_IG118:                ;; offset=0x0DB3
       cmp      dword ptr [rbp+0x20], 0
       setne    bpl
       movzx    rbp, bpl
       test     ebp, ebp
       je       G_M000_IG42
       mov      dword ptr [rsp+0x144], eax
       jmp      SHORT G_M000_IG120
 
G_M000_IG119:                ;; offset=0x0DD0
       mov      dword ptr [rsp+0x144], eax
 
G_M000_IG120:                ;; offset=0x0DD7
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      eax, dword ptr [rsp+0x144]
       mov      r8, bword ptr [rsp+0x30]
       jmp      G_M000_IG42
 
G_M000_IG121:                ;; offset=0x0DF1
       mov      ebx, dword ptr [rsp+0x120]
       add      ebx, ebp
       mov      ebp, dword ptr [rsp+0xE0]
       cmp      ebx, ebp
       mov      dword ptr [rsp+0x120], ebx
       mov      eax, dword ptr [rsp+0x144]
       mov      rdx, gword ptr [rsp+0x78]
       mov      r8, bword ptr [rsp+0x30]
       jl       G_M000_IG41
 
G_M000_IG122:                ;; offset=0x0E21
       mov      r11d, dword ptr [rsp+0x120]
       mov      dword ptr [rsp+0x144], eax
       jmp      G_M000_IG20
 
G_M000_IG123:                ;; offset=0x0E35
       vxorps   xmm6, xmm6, xmm6
       mov      ebx, r11d
       jmp      G_M000_IG32
 
G_M000_IG124:                ;; offset=0x0E41
       cmp      dword ptr [rdx+0x68], 0
       jl       SHORT G_M000_IG126
       jmp      SHORT G_M000_IG127
 
G_M000_IG125:                ;; offset=0x0E49
       xor      ebx, ebx
       jmp      G_M000_IG22
 
G_M000_IG126:                ;; offset=0x0E50
       mov      rcx, gword ptr [rdx+0x20]
       mov      ecx, dword ptr [rcx+0x10]
       mov      dword ptr [rdx+0x68], ecx
 
G_M000_IG127:                ;; offset=0x0E5A
       lea      rcx, [rsp+0x110]
       mov      edx, r9d
       mov      r8d, r11d
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField:DeferredNumber(int,int):Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]
       mov      r9d, dword ptr [rsp+0x110]
       mov      ebx, dword ptr [rsp+0x114]
       vmovsd   xmm6, qword ptr [rsp+0x118]
       mov      rdx, gword ptr [rsp+0x78]
       jmp      G_M000_IG32
 
G_M000_IG128:                ;; offset=0x0E90
       mov      dword ptr [rsp+0xD8], r9d
       mov      dword ptr [rsp+0xA0], r9d
       mov      dword ptr [rsp+0xA4], ebx
       vmovsd   qword ptr [rsp+0xA8], xmm6
       lea      rdx, [rsp+0xA0]
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:AddWithResize(Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField):this]
       mov      r9d, dword ptr [rsp+0xD8]
       jmp      G_M000_IG33
 
G_M000_IG129:                ;; offset=0x0ECB
       mov      ecx, 6
       call     [System.ThrowHelper:ThrowArgumentNullException(int)]
       int3     
 
G_M000_IG130:                ;; offset=0x0ED7
       cmp      ecx, ebp
       jge      G_M000_IG51
       cmp      ecx, ebp
       jae      G_M000_IG147
       mov      edx, ecx
       cmp      byte  ptr [r8+rdx], 10
       jne      G_M000_IG51
       inc      ecx
       jmp      G_M000_IG51
 
G_M000_IG131:                ;; offset=0x0EFB
       mov      r9d, dword ptr [rsp+0x148]
       mov      dword ptr [rsp+0x188], r9d
       jmp      G_M000_IG100
 
G_M000_IG132:                ;; offset=0x0F10
       xor      r13d, r13d
       mov      gword ptr [rsp+0x1F8], rdi
       jmp      G_M000_IG53
 
G_M000_IG133:                ;; offset=0x0F20
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:EndsWithTerminator():bool:this]
       test     eax, eax
       jne      G_M000_IG56
 
G_M000_IG134:                ;; offset=0x0F31
       test     r13d, r13d
       jne      SHORT G_M000_IG135
       cmp      dword ptr [rsp+0x188], 0
       je       G_M000_IG97
 
G_M000_IG135:                ;; offset=0x0F44
       mov      rdi, gword ptr [rsp+0x1F8]
       mov      rcx, gword ptr [rdi+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:ResetRecord():this]
       jmp      G_M000_IG97
 
G_M000_IG136:                ;; offset=0x0F5D
       lea      rdx, [rsp+0xF8]
       mov      r10, qword ptr [rcx]
       mov      r10, qword ptr [r10+0x40]
       call     [r10+0x28]System.Buffers.MemoryManager`1[byte]:GetSpan():System.Span`1[byte]:this
       mov      r10d, dword ptr [rsp+0x100]
       jmp      G_M000_IG58
 
G_M000_IG137:                ;; offset=0x0F7D
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG60
 
G_M000_IG138:                ;; offset=0x0F8F
       xor      rdx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG60
 
G_M000_IG139:                ;; offset=0x0F9C
       cmp      dword ptr [r10+0x20], 0
       setne    r10b
       movzx    r10, r10b
       test     r10d, r10d
       je       G_M000_IG61
 
G_M000_IG140:                ;; offset=0x0FB2
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG61
 
G_M000_IG141:                ;; offset=0x0FBD
       mov      rcx, gword ptr [rdx+0x10]
       mov      r9, gword ptr [rdx+0x18]
       mov      gword ptr [rsp+0x48], r9
       mov      r11, gword ptr [rcx+0x98]
       mov      gword ptr [rsp+0x40], r11
       cmp      byte  ptr [r11], r11b
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG143
       mov      rcx, gword ptr [rsp+0x40]
       mov      rdx, gword ptr [rsp+0x48]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rdx, gword ptr [rsp+0x58]
       jmp      G_M000_IG76
 
G_M000_IG142:                ;; offset=0x1000
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG143:                ;; offset=0x1007
       mov      rdx, gword ptr [rsp+0x58]
       jmp      G_M000_IG76
 
G_M000_IG144:                ;; offset=0x1011
       mov      byte  ptr [rsp+0x168], r15b
       mov      gword ptr [rsp+0x170], r12
       mov      eax, dword ptr [rsp+0xD0]
       mov      dword ptr [rsp+0x178], eax
       mov      dword ptr [rsp+0x17C], ebx
       mov      rcx, gword ptr [rdi+0x08]
       mov      bword ptr [rsp+0xB0], r14
       mov      dword ptr [rsp+0xB8], esi
       lea      rdx, [rsp+0xB0]
       lea      r8, [rsp+0x168]
       mov      r9d, dword ptr [rsp+0x164]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:ConsumeBorrowedLine(System.ReadOnlySpan`1[byte],System.Nullable`1[System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]],int):int:this]
       jmp      G_M000_IG67
 
G_M000_IG145:                ;; offset=0x106E
       lea      rdx, [rsp+0xE8]
       mov      rcx, r12
       mov      r8, qword ptr [r12]
       mov      r8, qword ptr [r8+0x40]
       call     [r8+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r15, bword ptr [rsp+0xE8]
       mov      r13d, dword ptr [rsp+0xF0]
       jmp      G_M000_IG65
 
G_M000_IG146:                ;; offset=0x109A
       mov      bword ptr [rsp+0xB0], r14
       mov      dword ptr [rsp+0xB8], esi
       lea      rdx, [rsp+0xB0]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:EmitRecord(System.ReadOnlySpan`1[byte]):this]
       mov      eax, -1
       jmp      G_M000_IG67
 
G_M000_IG147:                ;; offset=0x10C4
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG148:                ;; offset=0x10CA
       call     CORINFO_HELP_OVERFLOW
       int3     
 
RWD00  	dq	8000000000000000h, 8000000000000000h

; Total bytes of code 4304

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:TryDescribeLiteralRecord(System.ReadOnlySpan`1[byte],byref,bool):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 161564
; 30 inlinees with PGO data; 54 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 200
       vmovaps  xmmword ptr [rsp+0xB0], xmm6
       xor      eax, eax
       mov      qword ptr [rsp+0x48], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x50], ymm4
       vmovdqu  ymmword ptr [rsp+0x70], ymm4
       vmovdqa  xmmword ptr [rsp+0x90], xmm4
       mov      qword ptr [rsp+0xA0], rax
       mov      rbx, rcx
       mov      rdi, r8
       mov      esi, r9d
 
G_M000_IG02:                ;; offset=0x004D
       mov      rbp, bword ptr [rdx]
       mov      r14d, dword ptr [rdx+0x08]
       cmp      gword ptr [rbx+0x50], 0
       jne      G_M000_IG67
       test     r14d, r14d
       je       G_M000_IG68
       mov      r15d, dword ptr [rdi]
       test     r15d, r15d
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0070
       movzx    r13, byte  ptr [rbp]
       cmp      r13d, 10
       je       G_M000_IG70
       cmp      r13d, 13
       je       G_M000_IG70
 
G_M000_IG04:                ;; offset=0x0089
       mov      r13, gword ptr [rbx+0x30]
       test     r13, r13
       je       G_M000_IG50
 
G_M000_IG05:                ;; offset=0x0096
       movzx    rdx, byte  ptr [r13+0x24]
       test     edx, edx
       je       G_M000_IG72
 
G_M000_IG06:                ;; offset=0x00A3
       cmp      edx, 255
       je       G_M000_IG78
       lea      rax, bword ptr [r13+0x28]
       mov      r12d, dword ptr [r13+0x18]
       cmp      r12d, 8
       ja       G_M000_IG74
 
G_M000_IG07:                ;; offset=0x00C1
       mov      dword ptr [rsp+0x68], r12d
       test     r12d, r12d
       je       G_M000_IG81
       movzx    r13, byte  ptr [rax]
 
G_M000_IG08:                ;; offset=0x00D3
       cmp      r13d, dword ptr [rbx+0x60]
       je       G_M000_IG51
 
G_M000_IG09:                ;; offset=0x00DD
       cmp      r13d, 10
       je       G_M000_IG51
       cmp      r13d, 13
       jne      G_M000_IG33
       jmp      G_M000_IG51
 
G_M000_IG10:                ;; offset=0x00F6
       mov      r9d, eax
       mov      edx, r10d
       add      r9, rdx
       mov      edx, r14d
       cmp      r9, rdx
       ja       G_M000_IG74
       mov      dword ptr [rsp+0x88], eax
       mov      ecx, eax
       add      rcx, rbp
       mov      r11, gword ptr [rbx+0x40]
       test     r11, r11
       je       G_M000_IG104
       mov      r9, 0x7FF9D749EAE8
       cmp      qword ptr [r11], r9
       jne      G_M000_IG39
 
G_M000_IG11:                ;; offset=0x0137
       mov      dword ptr [rsp+0x84], r10d
       mov      dword ptr [rsp+0x20], r10d
       movzx    r9, byte  ptr [r11+0x0A]
       movzx    rdx, byte  ptr [r11+0x08]
       movzx    r8, byte  ptr [r11+0x09]
       call     [System.SpanHelpers:NonPackedIndexOfAnyValueType[byte,System.SpanHelpers+DontNegate`1[byte]](byref,byte,byte,byte,int):int]
 
G_M000_IG12:                ;; offset=0x0159
       test     eax, eax
       jl       G_M000_IG90
 
G_M000_IG13:                ;; offset=0x0161
       mov      ecx, dword ptr [rsp+0x88]
       add      eax, ecx
       mov      r8d, eax
 
G_M000_IG14:                ;; offset=0x016D
       mov      eax, r8d
       test     sil, sil
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0175
       cmp      eax, r14d
       je       G_M000_IG107
 
G_M000_IG16:                ;; offset=0x017E
       mov      dword ptr [rsp+0xAC], eax
       mov      r8d, eax
       sub      r8d, r15d
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x28], 2
       jne      G_M000_IG92
       test     r8d, r8d
       je       G_M000_IG92
       test     sil, sil
       je       G_M000_IG93
 
G_M000_IG17:                ;; offset=0x01AB
       mov      ecx, r15d
       mov      edx, r8d
       add      rcx, rdx
       mov      edx, r14d
       cmp      rcx, rdx
       ja       G_M000_IG74
       mov      ecx, r15d
       add      rcx, rbp
       mov      edx, r8d
       movzx    r10, byte  ptr [rcx]
       cmp      r10d, 45
       sete     r9b
       movzx    r9, r9b
       mov      dword ptr [rsp+0x6C], r9d
       cmp      r10d, 43
       je       G_M000_IG95
       cmp      r10d, 45
       setne    r10b
       movzx    r10, r10b
       mov      bword ptr [rsp+0x120], rdi
 
G_M000_IG18:                ;; offset=0x01FC
       test     r10d, r10d
       sete     r10b
       movzx    r10, r10b
       mov      r11d, edx
       sub      r11d, r10d
       mov      edi, r11d
       sub      edi, 1
       cmp      edi, 16
       ja       G_M000_IG94
       xor      edi, edi
       mov      r12d, -1
       cmp      r10d, r8d
       jge      SHORT G_M000_IG22
       align    [0 bytes for IG19]
 
G_M000_IG19:                ;; offset=0x0229
       movzx    r9, byte  ptr [rcx+r10]
       add      r9d, -48
       cmp      r9d, 9
       ja       G_M000_IG40
 
G_M000_IG20:                ;; offset=0x023C
       lea      rdi, [rdi+4*rdi]
       mov      r9d, r9d
       lea      rdi, [r9+2*rdi]
 
G_M000_IG21:                ;; offset=0x0247
       inc      r10d
       cmp      r10d, r8d
       jl       SHORT G_M000_IG19
 
G_M000_IG22:                ;; offset=0x024F
       cmp      r11d, 1
       je       G_M000_IG41
 
G_M000_IG23:                ;; offset=0x0259
       mov      rcx, 0x20000000000000
       cmp      rdi, rcx
       ja       G_M000_IG96
       test     r12d, r12d
       jl       G_M000_IG42
 
G_M000_IG24:                ;; offset=0x0275
       sub      edx, r12d
       dec      edx
 
G_M000_IG25:                ;; offset=0x027A
       vxorps   xmm0, xmm0, xmm0
       mov      r8, rdi
       shr      r8, 1
       mov      ecx, edi
       and      ecx, 1
       or       rcx, r8
       test     rdi, rdi
       cmovns   rcx, rdi
       vcvtsi2sd xmm0, rcx
       jns      SHORT G_M000_IG26
       vaddsd   xmm0, xmm0
 
G_M000_IG26:                ;; offset=0x029E
       cmp      edx, 19
       jae      G_M000_IG109
       mov      ecx, edx
       mov      rdx, 0x1C844D3C5A0
       vdivsd   xmm6, xmm0, qword ptr [rdx+8*rcx]
       cmp      dword ptr [rsp+0x6C], 0
       jne      G_M000_IG43
 
G_M000_IG27:                ;; offset=0x02C3
       mov      r15d, -1
       xor      edi, edi
 
G_M000_IG28:                ;; offset=0x02CB
       mov      rcx, gword ptr [rbx+0x20]
       inc      dword ptr [rcx+0x14]
       mov      rdx, gword ptr [rcx+0x08]
       mov      r8d, dword ptr [rcx+0x10]
       mov      r10d, dword ptr [rdx+0x08]
       cmp      r10d, r8d
       jbe      G_M000_IG103
       lea      r10d, [r8+0x01]
       mov      dword ptr [rcx+0x10], r10d
       mov      ecx, r8d
       shl      rcx, 4
       lea      rdx, bword ptr [rdx+rcx+0x10]
       mov      dword ptr [rdx], r15d
       mov      dword ptr [rdx+0x04], edi
       vmovsd   qword ptr [rdx+0x08], xmm6
 
G_M000_IG29:                ;; offset=0x0306
       test     r15d, r15d
       jl       SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x030B
       test     edi, edi
       jle      SHORT G_M000_IG31
       mov      ecx, edi
       add      rcx, 128
       add      rcx, qword ptr [rbx+0x58]
       jo       G_M000_IG110
       mov      qword ptr [rbx+0x58], rcx
       cmp      edi, 8
       jg       G_M000_IG44
 
G_M000_IG31:                ;; offset=0x032F
       mov      eax, dword ptr [rsp+0xAC]
       cmp      eax, r14d
       je       G_M000_IG48
       cmp      eax, r14d
       jae      G_M000_IG109
       mov      ecx, eax
       movzx    rdi, byte  ptr [rcx+rbp]
       mov      ecx, edi
       cmp      ecx, 10
       je       G_M000_IG45
 
G_M000_IG32:                ;; offset=0x035A
       cmp      ecx, 13
       je       G_M000_IG45
       lea      r15d, [rax+0x01]
       mov      rdi, bword ptr [rsp+0x120]
       mov      r12d, dword ptr [rsp+0x68]
 
G_M000_IG33:                ;; offset=0x0374
       mov      rcx, gword ptr [rbx+0x20]
       mov      edx, dword ptr [rcx+0x10]
       mov      rcx, gword ptr [rcx+0x08]
       cmp      edx, dword ptr [rcx+0x08]
       jge      G_M000_IG107
       cmp      r15d, r14d
       jge      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x038D
       cmp      r15d, r14d
       jae      G_M000_IG109
       mov      ecx, r15d
       movzx    rcx, byte  ptr [rcx+rbp]
       cmp      ecx, r13d
       je       G_M000_IG52
 
G_M000_IG35:                ;; offset=0x03A6
       mov      eax, r15d
       mov      dword ptr [rsp+0x88], eax
       cmp      eax, r14d
       jge      G_M000_IG91
 
G_M000_IG36:                ;; offset=0x03B9
       mov      rcx, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rbx+0x18]
       mov      rcx, gword ptr [rcx+0x98]
       mov      r8, gword ptr [rcx+0x88]
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG89
       mov      r8, gword ptr [rcx+0x180]
       test     r8, r8
       jne      G_M000_IG88
 
G_M000_IG37:                ;; offset=0x03EA
       mov      eax, dword ptr [rsp+0x88]
       mov      r10d, r14d
       sub      r10d, eax
       cmp      r10d, 0x1000
       jl       G_M000_IG10
 
G_M000_IG38:                ;; offset=0x0404
       mov      r10d, 0x1000
       jmp      G_M000_IG10
 
G_M000_IG39:                ;; offset=0x040F
       mov      bword ptr [rsp+0x48], rcx
       mov      dword ptr [rsp+0x84], r10d
       mov      dword ptr [rsp+0x50], r10d
       lea      rdx, [rsp+0x48]
       mov      rcx, r11
       mov      r8, qword ptr [r11]
       mov      r8, qword ptr [r8+0x40]
       call     [r8+0x30]System.Buffers.SearchValues`1[byte]:IndexOfAny(System.ReadOnlySpan`1[byte]):int:this
       jmp      G_M000_IG12
 
G_M000_IG40:                ;; offset=0x0439
       cmp      byte  ptr [rcx+r10], 46
       jne      G_M000_IG99
       test     r12d, r12d
       jge      G_M000_IG98
       mov      r12d, r10d
       jmp      G_M000_IG21
 
G_M000_IG41:                ;; offset=0x0455
       test     r12d, r12d
       jge      G_M000_IG97
       jmp      G_M000_IG23
 
G_M000_IG42:                ;; offset=0x0463
       xor      edx, edx
       jmp      G_M000_IG25
 
G_M000_IG43:                ;; offset=0x046A
       vxorps   xmm6, xmm6, xmmword ptr [reloc @RWD00]
       jmp      G_M000_IG27
 
G_M000_IG44:                ;; offset=0x0477
       add      edi, dword ptr [rbx+0x6C]
       jo       G_M000_IG110
       mov      dword ptr [rbx+0x6C], edi
       jmp      G_M000_IG31
 
G_M000_IG45:                ;; offset=0x0488
       lea      edx, [rax+0x01]
       test     sil, sil
       je       G_M000_IG105
 
G_M000_IG46:                ;; offset=0x0494
       cmp      edi, 13
       je       G_M000_IG106
 
G_M000_IG47:                ;; offset=0x049D
       mov      rdi, bword ptr [rsp+0x120]
       mov      dword ptr [rdi], edx
 
G_M000_IG48:                ;; offset=0x04A7
       mov      eax, 1
 
G_M000_IG49:                ;; offset=0x04AC
       vmovaps  xmm6, xmmword ptr [rsp+0xB0]
       add      rsp, 200
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG50:                ;; offset=0x04C9
       xor      rax, rax
       xor      r12d, r12d
       jmp      G_M000_IG07
 
G_M000_IG51:                ;; offset=0x04D3
       mov      r13d, -1
       jmp      G_M000_IG33
 
G_M000_IG52:                ;; offset=0x04DE
       cmp      r12d, 1
       jne      G_M000_IG107
       lea      eax, [r15+0x01]
       movzx    r8, r13b
       mov      dword ptr [rsp+0x90], r8d
       mov      dword ptr [rsp+0x94], eax
       cmp      eax, r14d
       mov      r8d, dword ptr [rsp+0x90]
       jge      G_M000_IG86
 
G_M000_IG53:                ;; offset=0x0510
       mov      rcx, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rbx+0x18]
       mov      rcx, gword ptr [rcx+0x98]
       mov      r10, gword ptr [rcx+0x88]
       cmp      gword ptr [r10+0x20], 0
       jne      G_M000_IG83
       mov      r10, gword ptr [rcx+0x180]
       test     r10, r10
       jne      G_M000_IG82
 
G_M000_IG54:                ;; offset=0x0541
       mov      eax, dword ptr [rsp+0x94]
       mov      r10d, r14d
       sub      r10d, eax
       cmp      r10d, 0x1000
       jge      G_M000_IG66
 
G_M000_IG55:                ;; offset=0x055B
       mov      ecx, eax
       mov      edx, r10d
       add      rcx, rdx
       mov      edx, r14d
       cmp      rcx, rdx
       ja       G_M000_IG74
       mov      dword ptr [rsp+0x94], eax
       mov      r11d, eax
       add      r11, rbp
       mov      bword ptr [rsp+0x30], r11
       test     sil, sil
       je       G_M000_IG84
 
G_M000_IG56:                ;; offset=0x058A
       mov      dword ptr [rsp+0x8C], r10d
       mov      dword ptr [rsp+0x20], r10d
       mov      rcx, r11
       mov      edx, r8d
       mov      r8d, 13
       mov      r9d, 10
       call     [System.SpanHelpers:NonPackedIndexOfAnyValueType[byte,System.SpanHelpers+DontNegate`1[byte]](byref,byte,byte,byte,int):int]
 
G_M000_IG57:                ;; offset=0x05AF
       test     eax, eax
       jl       G_M000_IG85
 
G_M000_IG58:                ;; offset=0x05B7
       cmp      eax, dword ptr [rsp+0x8C]
       jae      G_M000_IG109
       mov      ecx, eax
       mov      rdx, bword ptr [rsp+0x30]
       movzx    rcx, byte  ptr [rdx+rcx]
       mov      edx, dword ptr [rsp+0x90]
       cmp      ecx, edx
       jne      G_M000_IG86
       mov      ecx, dword ptr [rsp+0x94]
       add      eax, ecx
 
G_M000_IG59:                ;; offset=0x05E7
       test     eax, eax
       jl       G_M000_IG107
 
G_M000_IG60:                ;; offset=0x05EF
       lea      r8d, [rax+0x01]
       test     sil, sil
       je       SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x05F8
       cmp      r8d, r14d
       je       G_M000_IG107
 
G_M000_IG62:                ;; offset=0x0601
       cmp      r8d, r14d
       jge      SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x0606
       cmp      r8d, r14d
       jae      G_M000_IG109
       mov      ecx, r8d
       movzx    rcx, byte  ptr [rcx+rbp]
       cmp      ecx, dword ptr [rbx+0x60]
       je       SHORT G_M000_IG65
 
G_M000_IG64:                ;; offset=0x061B
       cmp      ecx, 10
       jne      G_M000_IG87
 
G_M000_IG65:                ;; offset=0x0624
       lea      r10d, [r15+0x01]
       sub      eax, r15d
       lea      r15d, [rax-0x01]
       vxorps   xmm6, xmm6, xmm6
       mov      dword ptr [rsp+0xAC], r8d
       mov      bword ptr [rsp+0x120], rdi
       mov      edi, r15d
       mov      r15d, r10d
       jmp      G_M000_IG28
 
G_M000_IG66:                ;; offset=0x064E
       mov      r10d, 0x1000
       jmp      G_M000_IG55
 
G_M000_IG67:                ;; offset=0x0659
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1C842436428
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG68:                ;; offset=0x0687
       test     sil, sil
       sete     al
       movzx    rax, al
 
G_M000_IG69:                ;; offset=0x0690
       vmovaps  xmm6, xmmword ptr [rsp+0xB0]
       add      rsp, 200
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG70:                ;; offset=0x06AD
       mov      rcx, gword ptr [rbx+0x10]
       mov      r15, gword ptr [rbx+0x18]
       mov      r13, gword ptr [rcx+0x98]
       cmp      byte  ptr [r13], r13b
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG71
       mov      rcx, r13
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG71:                ;; offset=0x06D9
       mov      bword ptr [rsp+0x48], rbp
       mov      dword ptr [rsp+0x50], r14d
       mov      bword ptr [rsp+0x20], rdi
       lea      rdx, [rsp+0x48]
       movzx    r9, sil
       mov      rcx, rbx
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:CompleteLiteralRecord(System.ReadOnlySpan`1[byte],int,bool,byref):this]
       jmp      G_M000_IG48
 
G_M000_IG72:                ;; offset=0x0702
       mov      rax, gword ptr [r13+0x08]
       mov      r12d, dword ptr [r13+0x18]
       test     rax, rax
       jne      SHORT G_M000_IG76
 
G_M000_IG73:                ;; offset=0x070F
       test     r12d, r12d
       je       SHORT G_M000_IG75
 
G_M000_IG74:                ;; offset=0x0714
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG75:                ;; offset=0x071B
       xor      rax, rax
       xor      r12d, r12d
       jmp      SHORT G_M000_IG77
 
G_M000_IG76:                ;; offset=0x0722
       cmp      dword ptr [rax+0x08], r12d
       jb       SHORT G_M000_IG74
       add      rax, 16
 
G_M000_IG77:                ;; offset=0x072C
       jmp      G_M000_IG07
 
G_M000_IG78:                ;; offset=0x0731
       mov      rdx, gword ptr [r13+0x08]
       lea      rcx, bword ptr [r13+0x28]
       mov      ecx, dword ptr [rcx]
       mov      eax, dword ptr [r13+0x18]
       test     rdx, rdx
       jne      SHORT G_M000_IG79
       or       ecx, eax
       jne      SHORT G_M000_IG74
       xor      rdx, rdx
       xor      eax, eax
       jmp      SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x074E
       mov      r8d, ecx
       mov      r10d, eax
       add      r8, r10
       mov      r10d, dword ptr [rdx+0x08]
       cmp      r8, r10
       ja       SHORT G_M000_IG74
       mov      ecx, ecx
       lea      rdx, bword ptr [rdx+rcx+0x10]
 
G_M000_IG80:                ;; offset=0x0767
       mov      bword ptr [rsp+0x58], rdx
       mov      dword ptr [rsp+0x60], eax
       lea      rdx, [rsp+0x58]
       lea      rcx, [rsp+0x98]
       call     [System.Span`1[byte]:op_Implicit(System.Span`1[byte]):System.ReadOnlySpan`1[byte]]
       mov      rax, bword ptr [rsp+0x98]
       mov      r12d, dword ptr [rsp+0xA0]
       jmp      G_M000_IG07
 
G_M000_IG81:                ;; offset=0x0798
       mov      r13d, -1
       jmp      G_M000_IG08
 
G_M000_IG82:                ;; offset=0x07A3
       cmp      dword ptr [r10+0x20], 0
       setne    r10b
       movzx    r10, r10b
       test     r10d, r10d
       je       G_M000_IG54
 
G_M000_IG83:                ;; offset=0x07B9
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      r8d, dword ptr [rsp+0x90]
       jmp      G_M000_IG54
 
G_M000_IG84:                ;; offset=0x07CC
       mov      rcx, r11
       mov      edx, r8d
       mov      dword ptr [rsp+0x8C], r10d
       mov      r8d, r10d
       call     [System.SpanHelpers:NonPackedIndexOfValueType[byte,System.SpanHelpers+DontNegate`1[byte]](byref,byte,int):int]
       jmp      G_M000_IG57
 
G_M000_IG85:                ;; offset=0x07E8
       mov      eax, dword ptr [rsp+0x94]
       add      eax, dword ptr [rsp+0x8C]
       cmp      eax, r14d
       mov      dword ptr [rsp+0x94], eax
       mov      r8d, dword ptr [rsp+0x90]
       jl       G_M000_IG53
 
G_M000_IG86:                ;; offset=0x080E
       mov      eax, -1
       jmp      G_M000_IG59
 
G_M000_IG87:                ;; offset=0x0818
       cmp      ecx, 13
       jne      G_M000_IG107
       jmp      G_M000_IG65
 
G_M000_IG88:                ;; offset=0x0826
       cmp      dword ptr [r8+0x20], 0
       setne    r8b
       movzx    r8, r8b
       test     r8d, r8d
       je       G_M000_IG37
 
G_M000_IG89:                ;; offset=0x083C
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG37
 
G_M000_IG90:                ;; offset=0x0847
       mov      eax, dword ptr [rsp+0x88]
       add      eax, dword ptr [rsp+0x84]
       cmp      eax, r14d
       mov      dword ptr [rsp+0x88], eax
       jl       G_M000_IG36
 
G_M000_IG91:                ;; offset=0x0865
       mov      eax, dword ptr [rsp+0x88]
       mov      r8d, eax
       jmp      G_M000_IG14
 
G_M000_IG92:                ;; offset=0x0874
       mov      edx, r8d
       vxorps   xmm6, xmm6, xmm6
       mov      bword ptr [rsp+0x120], rdi
       mov      edi, edx
       jmp      G_M000_IG28
 
G_M000_IG93:                ;; offset=0x088A
       mov      bword ptr [rsp+0x48], rbp
       mov      dword ptr [rsp+0x50], r14d
       mov      dword ptr [rsp+0x20], r8d
       xor      r8d, r8d
       mov      dword ptr [rsp+0x28], r8d
       lea      r8, [rsp+0x48]
       lea      rdx, [rsp+0x70]
       mov      rcx, rbx
       mov      r9d, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:CreateField(System.ReadOnlySpan`1[byte],int,int,bool):Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField:this]
       jmp      SHORT G_M000_IG102
 
G_M000_IG94:                ;; offset=0x08B9
       cmp      dword ptr [rbx+0x68], 0
       jge      SHORT G_M000_IG101
       jmp      SHORT G_M000_IG100
 
G_M000_IG95:                ;; offset=0x08C1
       xor      r10d, r10d
       mov      bword ptr [rsp+0x120], rdi
       jmp      G_M000_IG18
 
G_M000_IG96:                ;; offset=0x08D1
       mov      r12d, dword ptr [rsp+0x68]
       jmp      SHORT G_M000_IG94
 
G_M000_IG97:                ;; offset=0x08D8
       mov      r12d, dword ptr [rsp+0x68]
       jmp      SHORT G_M000_IG94
 
G_M000_IG98:                ;; offset=0x08DF
       mov      r12d, dword ptr [rsp+0x68]
       jmp      SHORT G_M000_IG94
 
G_M000_IG99:                ;; offset=0x08E6
       mov      r12d, dword ptr [rsp+0x68]
       jmp      SHORT G_M000_IG94
 
G_M000_IG100:                ;; offset=0x08ED
       mov      rcx, gword ptr [rbx+0x20]
       mov      ecx, dword ptr [rcx+0x10]
       mov      dword ptr [rbx+0x68], ecx
 
G_M000_IG101:                ;; offset=0x08F7
       lea      rcx, [rsp+0x70]
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField:DeferredNumber(int,int):Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]
       mov      rdi, bword ptr [rsp+0x120]
 
G_M000_IG102:                ;; offset=0x090D
       mov      r15d, dword ptr [rsp+0x70]
       mov      edx, dword ptr [rsp+0x74]
       vmovsd   xmm6, qword ptr [rsp+0x78]
       mov      bword ptr [rsp+0x120], rdi
       mov      edi, edx
       jmp      G_M000_IG28
 
G_M000_IG103:                ;; offset=0x092B
       mov      dword ptr [rsp+0x38], r15d
       mov      dword ptr [rsp+0x3C], edi
       vmovsd   qword ptr [rsp+0x40], xmm6
       lea      rdx, [rsp+0x38]
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:AddWithResize(Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField):this]
       jmp      G_M000_IG29
 
G_M000_IG104:                ;; offset=0x094A
       mov      ecx, 6
       call     [System.ThrowHelper:ThrowArgumentNullException(int)]
       int3     
 
G_M000_IG105:                ;; offset=0x0956
       cmp      edx, r14d
       ja       G_M000_IG74
       mov      ecx, edx
       add      rcx, rbp
       sub      r14d, edx
       mov      bword ptr [rsp+0x48], rcx
       mov      dword ptr [rsp+0x50], r14d
       lea      rdx, [rsp+0x48]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:ValidateRecordEnd(System.ReadOnlySpan`1[byte]):this]
       jmp      G_M000_IG48
 
G_M000_IG106:                ;; offset=0x0984
       cmp      edx, r14d
       jge      G_M000_IG47
       cmp      edx, r14d
       jae      SHORT G_M000_IG109
       mov      ecx, edx
       cmp      byte  ptr [rcx+rbp], 10
       jne      G_M000_IG47
       inc      edx
       jmp      G_M000_IG47
 
G_M000_IG107:                ;; offset=0x09A5
       mov      dword ptr [rdi], r15d
       xor      eax, eax
 
G_M000_IG108:                ;; offset=0x09AA
       vmovaps  xmm6, xmmword ptr [rsp+0xB0]
       add      rsp, 200
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG109:                ;; offset=0x09C7
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG110:                ;; offset=0x09CD
       call     CORINFO_HELP_OVERFLOW
       int3     
 
RWD00  	dq	8000000000000000h, 8000000000000000h

; Total bytes of code 2515

