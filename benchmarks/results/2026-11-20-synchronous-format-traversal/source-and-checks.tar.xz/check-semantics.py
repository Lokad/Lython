from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
cases={'retained-nested-format-specs': "seen=[]\nclass Value:\n    def __format__(self,spec):\n        seen.append(spec)\n        return spec\nprint('{0:{1}}|{0:{2}}'.format(Value(),'width','second'))\nprint(seen)\n", 'format-late-grammar-error': "seen=[]\nclass Value:\n    def __format__(self,spec):\n        seen.append(spec)\n        return 'first'\ntry:\n    '{0:{1}} {'.format(Value(),'abc')\nexcept ValueError:\n    print(seen)\n", 'format-recursive-spec-error': "seen=[]\nclass Value:\n    def __format__(self,spec):\n        seen.append(spec)\n        return 'first'\ntry:\n    '{0:{1:{2}}}'.format(Value(),Value(),Value())\nexcept ValueError:\n    print(seen)\n"}

cases["mixed-field-order"] = """
seen=[]
class Item:
    @property
    def child(self):
        seen.append('get child')
        return self
    def __getitem__(self,key):
        seen.append(key)
        return {'okay': 8}
    def __format__(self,spec):
        seen.append(spec)
        return 'rendered'
print('{root[label]}|{item.child[key][okay]:03d}|{item:{root[label]}}|{root[label]}'.format(
    root={'label':'café'}, item=Item()))
print(seen)
"""
cases["mapping-and-late-error"] = """
seen=[]
class Mapping:
    def __getitem__(self,key):
        seen.append(key)
        if key == 'row':
            return {'label':'café'}
        raise KeyError(key)
try:
    '{row[label]}|{later}|{row[label]}'.format_map(Mapping())
except KeyError as error:
    print(seen, error.args)
"""
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
probe=lab.parent/'format-continuation-scratch/probe/candidate'
pair=load(lab/'frozen-identity.json')
body=json.dumps(list(cases.values())).encode('utf-8')
(lab/'probe-cases.json').write_bytes(body)
for role,files in pair['images'].items():
    source=lab/'frozen'/role
    assert len(files)==32 and {n:sha(source/n) for n in files}==files
    image=lab/'probe'/role
    shutil.copytree(probe,image,dirs_exist_ok=True)
    for file in image.glob('Lokad.*.dll'):
        if file.name in files:
            shutil.copyfile(source/file.name,file)
            assert sha(file)==files[file.name]
    assert sha(image/'Lokad.Lython.dll')==files['Lokad.Lython.dll']
    for async_mode in (False,True):
        args=[sdk/'dotnet.exe',image/'LythonProbe.dll','--batch-json','--compare-python','--python','C:/Python313/python.exe']
        if async_mode:args.append('--async')
        process=subprocess.run(args,input=body,capture_output=True,timeout=55,env=env)
        (lab/f'probe-{role}-{async_mode}.jsonl').write_bytes(process.stdout)
        assert process.returncode==0,(role,async_mode,process.stderr.decode(),process.stdout.decode())
        reports=[json.loads(line) for line in process.stdout.splitlines()]
        assert len(reports)==len(cases) and all(row['Matches'] and row['Compared'] for row in reports)
print(f'{len(cases)} CPython semantic probes pass in sync and async modes for both source images.')
