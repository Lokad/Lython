from pathlib import Path
import json, shutil

root = Path('D:/code/Lython')
home = Path(__file__).parent
refined = home / 'refined'
refined.mkdir()
shutil.copytree(home / 'images/before', refined / 'images/before')
shutil.copyfile(home / 'catalog.json', refined / 'catalog.json')
baseline = json.loads((home / 'baseline.json').read_text(encoding='utf-8'))
for name in baseline['productionSources']:
    path = Path(name)
    target = home / 'initial-source' / path.relative_to(root / 'src/Lokad.Lython')
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)
path = root / 'src/Lokad.Lython/Runtime/LythonRuntime.Evaluation.Operators.cs'
text = path.read_text(encoding='utf-8')
old = 'if (!PyNumberOps.IsInteger(left) || !PyNumberOps.IsInteger(right)) return false;'
new = '''// The result representation changes only the existing exact integer
        // route. Other ingress widths/bools keep their shared numeric funnel.
        if (left is not (BigInteger or long) || right is not (BigInteger or long)) return false;'''
assert text.count(old) == 1
path.write_text(text.replace(old, new), encoding='utf-8', newline='\n')
source = (home / 'measure.py').read_text(encoding='utf-8')
source = source.replace("home = Path(__file__).parent", "home = Path(__file__).parent")
source = source.replace("home.parent / 'bulk-whitespace-r157/tool/out/complete-jobs.dll'", "home.parent.parent / 'bulk-whitespace-r157/tool/out/complete-jobs.dll'")
(refined / 'measure.py').write_text(source, encoding='utf-8', newline='\n')
print('Original prototype frozen. Refined exact-operand classification; no public contract change or assertion relaxed.')
