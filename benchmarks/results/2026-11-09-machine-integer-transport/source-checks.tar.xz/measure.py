from pathlib import Path
import hashlib, json, os, shutil, statistics, subprocess

root = Path('D:/code/Lython')
home = Path(__file__).parent
env = os.environ.copy()
env['DOTNET_ROOT'] = 'C:/Users/JoannesVermorel/.dotnet11'
env['DOTNET_HOST_PATH'] = env['DOTNET_ROOT'] + '/dotnet.exe'
env['PATH'] = env['DOTNET_ROOT'] + os.pathsep + env['PATH']
shutil.copytree(home / 'images/before', home / 'images/candidate')
shutil.copyfile(root / 'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll', home / 'images/candidate/Lokad.Lython.dll')
assert all(p.read_bytes() == (home / 'images/candidate' / p.name).read_bytes()
           for p in (home / 'images/before').iterdir() if p.is_file() and p.name != 'Lokad.Lython.dll')
(home / 'source.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary', '--', 'src/Lokad.Lython']))
(home / 'identity.json').write_text(json.dumps(dict(
    cores={label: hashlib.sha256((home / 'images' / label / 'Lokad.Lython.dll').read_bytes()).hexdigest() for label in ['before', 'candidate']},
    productionSources={p.as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in (root / 'src/Lokad.Lython').rglob('*.cs') if 'obj' not in p.parts},
    limitations='Private raw Int64 addition prototype; known public BigInteger projection contract violation, never a promotable implementation.'
), indent=2) + '\n', encoding='utf-8')
driver = home.parent / 'bulk-whitespace-r157/tool/out/complete-jobs.dll'
summary = {}
for api in ['sync', 'async']:
    folder = home / ('warm-' + api)
    folder.mkdir()
    witness = folder / 'hash-witness.json'
    witness.write_text(json.dumps(dict(source="return [hash('Lython-é😀'), hash((1, 2.0, True))]\n"), ensure_ascii=False) + '\n', encoding='utf-8')
    with (folder / 'measurements.json').open('w', encoding='utf-8') as out, (folder / 'stderr.txt').open('w', encoding='utf-8') as err:
        done = subprocess.run([env['DOTNET_HOST_PATH'], str(driver),
            str(home / 'images/before/Lokad.Lython.Benchmarks.dll'), str(home / 'images/candidate/Lokad.Lython.Benchmarks.dll'),
            str(home / 'catalog.json'), str(witness), 'reverse', 'warm', api], env=env, stdout=out, stderr=err, timeout=120)
    assert done.returncode == 0, (folder / 'stderr.txt').read_text(encoding='utf-8')[-3500:]
    data = json.loads((folder / 'measurements.json').read_text(encoding='utf-8'))
    assert all(data[k] for k in ['allGoldensPassed', 'allBalancesZero', 'ownedFixturesRemoved', 'imageIsolationVerified'])
    summary[api] = []
    for case in data['observations']:
        values = {role: {name: statistics.median(s[field] / s['jobs'] for s in case['samples'] if s['image'] == role)
                   for name, field in [('bytes', 'allocatedBytes'), ('elapsedMs', 'executionMilliseconds')]}
                  for role in ['before', 'before-control', 'candidate']}
        row = dict(case=case['caseId'], roles=values,
                   allocationPercent=[100*(values['candidate']['bytes']/values[b]['bytes']-1) for b in ['before','before-control']],
                   elapsedPercent=[100*(values['candidate']['elapsedMs']/values[b]['elapsedMs']-1) for b in ['before','before-control']])
        summary[api].append(row)
        print(api, row['case'], 'allocation', [round(v, 2) for v in row['allocationPercent']], 'elapsed', [round(v, 2) for v in row['elapsedPercent']], flush=True)
    (home / 'desktop.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print('Both five-script private diagnostics complete; no public contract or CPU qualification claimed.', flush=True)
