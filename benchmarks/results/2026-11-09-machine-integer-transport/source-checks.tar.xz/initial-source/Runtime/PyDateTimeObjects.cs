using System.Globalization;
using System.Numerics;
using System.Text;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed class PyTimedelta : IPyTruthyValue, IPyHashableValue, IPyRenderableValue
{
    private readonly record struct NormalizedTimedeltaParts(BigInteger Days, int Seconds, int Microseconds);

    public static readonly BigInteger MicrosecondsPerDay = new(86_400_000_000L);
    private static readonly BigInteger MinimumMicroseconds = -999_999_999 * MicrosecondsPerDay;
    private static readonly BigInteger MaximumMicroseconds = 999_999_999 * MicrosecondsPerDay + MicrosecondsPerDay - 1;

    public static readonly PyTimedelta Min = new(MinimumMicroseconds);
    public static readonly PyTimedelta Max = new(MaximumMicroseconds);
    public static readonly PyTimedelta Resolution = new(TimeSpan.FromTicks(10));

    public PyTimedelta(TimeSpan value)
        : this(new BigInteger(value.Ticks / 10))
    {
    }

    public PyTimedelta(BigInteger totalMicroseconds)
    {
        if (totalMicroseconds < MinimumMicroseconds || totalMicroseconds > MaximumMicroseconds)
        {
            throw new OverflowException("timedelta is outside Python's supported day range");
        }

        TotalMicroseconds = totalMicroseconds;
        var days = BigInteger.DivRem(totalMicroseconds, MicrosecondsPerDay, out var remainderMicroseconds);
        if (remainderMicroseconds.Sign < 0)
        {
            remainderMicroseconds += MicrosecondsPerDay;
            days -= 1;
        }

        _normalized = new NormalizedTimedeltaParts(
            days,
            (int)(remainderMicroseconds / 1_000_000),
            (int)(remainderMicroseconds % 1_000_000));
    }

    private readonly NormalizedTimedeltaParts _normalized;

    public BigInteger TotalMicroseconds { get; }

    public TimeSpan Value => new(checked((long)(TotalMicroseconds * 10)));

    public BigInteger Days => _normalized.Days;

    public BigInteger Seconds => new(_normalized.Seconds);

    public BigInteger Microseconds => new(_normalized.Microseconds);

    public bool IsTruthy() => !TotalMicroseconds.IsZero;

    public int GetPyHashCode() => TotalMicroseconds.GetHashCode();

    public double TotalSeconds() => (double)TotalMicroseconds / 1_000_000.0;

    public PyString RenderPython(PyRenderingContext context)
    {
        _ = context;
        var parts = _normalized;
        if (parts.Days.IsZero && parts.Seconds == 0 && parts.Microseconds == 0)
        {
            return PyString.FromString("datetime.timedelta(0)", context.Context.MemoryGovernor);
        }

        var builder = new StringBuilder("datetime.timedelta(");
        var first = true;
        AppendField(ref first, builder, "days", parts.Days.IsZero ? null : parts.Days.ToString(CultureInfo.InvariantCulture));
        AppendField(ref first, builder, "seconds", parts.Seconds == 0 ? null : parts.Seconds.ToString(CultureInfo.InvariantCulture));
        AppendField(ref first, builder, "microseconds", parts.Microseconds == 0 ? null : parts.Microseconds.ToString(CultureInfo.InvariantCulture));
        builder.Append(')');
        return PyString.FromString(builder.ToString(), context.Context.MemoryGovernor);
    }

    private static void AppendField(ref bool first, StringBuilder builder, string name, string? value)
    {
        if (value is null)
        {
            return;
        }

        if (!first)
        {
            builder.Append(", ");
        }

        builder.Append(name);
        builder.Append('=');
        builder.Append(value);
        first = false;
    }

    public PyString RenderInterpolated(PyRenderingContext context)
        => PyString.FromString(ToString(), context.Context.MemoryGovernor);

    public override string ToString()
    {
        var parts = _normalized;
        var builder = new StringBuilder();
        if (!parts.Days.IsZero)
        {
            builder.Append(parts.Days.ToString(CultureInfo.InvariantCulture));
            builder.Append(BigInteger.Abs(parts.Days) == BigInteger.One ? " day, " : " days, ");
        }

        var hours = parts.Seconds / 3600;
        var minutes = parts.Seconds % 3600 / 60;
        var seconds = parts.Seconds % 60;
        builder.Append(hours.ToString(CultureInfo.InvariantCulture));
        builder.Append(':');
        builder.Append(minutes.ToString("00", CultureInfo.InvariantCulture));
        builder.Append(':');
        builder.Append(seconds.ToString("00", CultureInfo.InvariantCulture));
        if (parts.Microseconds != 0)
        {
            builder.Append('.');
            builder.Append(parts.Microseconds.ToString("000000", CultureInfo.InvariantCulture));
        }

        return builder.ToString();
    }

    public override bool Equals(object? obj) => obj is PyTimedelta other && TotalMicroseconds.Equals(other.TotalMicroseconds);

    public override int GetHashCode() => GetPyHashCode();


}

internal sealed class PyTimezone : IPyTruthyValue, IPyHashableValue, IPyRenderableValue
{
    public static readonly PyTimezone Utc = new(TimeSpan.Zero);

    // CPython bounds fixed-offset zones strictly inside 24 hours; the
    // edge singletons sit one minute inside each bound, unnamed.
    public static readonly PyTimezone Min = new(TimeSpan.FromSeconds(-86340));
    public static readonly PyTimezone Max = new(TimeSpan.FromSeconds(86340));

    public PyTimezone(TimeSpan offset) : this(offset, null) { }

    public PyTimezone(TimeSpan offset, PyString? name)
    {
        Offset = offset;
        HasExplicitName = name is not null;
        Name = name ?? PyString.FromString(offset == TimeSpan.Zero ? "UTC" : "UTC" + PyDateTimeOps.FormatOffset(offset));
    }

    public TimeSpan Offset { get; }

    public PyString Name { get; }

    public bool HasExplicitName { get; }

    public bool IsTruthy() => true;

    public int GetPyHashCode() => HashCode.Combine(Offset.Ticks);

    public PyString RenderPython(PyRenderingContext context)
    {
        var builder = new GovernedByteBuilder(context.Context.MemoryGovernor);
        try
        {
            if (Offset == TimeSpan.Zero && !HasExplicitName)
                builder.AppendAscii("datetime.timezone.utc");
            else
            {
                builder.AppendAscii("datetime.timezone(");
                builder.AppendString(PyDateTimeOps.RenderOffsetDelta(new BigInteger(Offset.Ticks / 10)));
                if (HasExplicitName)
                {
                    builder.AppendAscii(", ");
                    builder.Append(PyRendering.ToReprPyString(Name, context));
                }
                builder.Append((byte)')');
            }
            return builder.ToPyStringAndRelease();
        }
        finally { builder.Release(); }
    }

    public PyString RenderInterpolated(PyRenderingContext context) => Name;

    public override bool Equals(object? obj) => obj is PyTimezone other && Offset.Equals(other.Offset);

    public override int GetHashCode() => GetPyHashCode();

    public override string ToString() => Name.AsString();

}

internal sealed class PyDate : IPyTruthyValue, IPyHashableValue, IPyRenderableValue
{
    public static readonly PyDate Min = new(DateOnly.MinValue);
    public static readonly PyDate Max = new(DateOnly.MaxValue);
    public static readonly PyTimedelta Resolution = new(TimeSpan.FromDays(1));

    public PyDate(DateOnly value)
    {
        Value = value;
    }

    public DateOnly Value { get; }

    public BigInteger Year => new(Value.Year);

    public BigInteger Month => new(Value.Month);

    public BigInteger Day => new(Value.Day);

    public bool IsTruthy() => true;

    public int GetPyHashCode() => HashCode.Combine(Value.DayNumber);

    public int Weekday() => ((int)Value.DayOfWeek + 6) % 7;

    public int IsoWeekday() => Weekday() + 1;

    public PyString IsoFormat(MemoryGovernor? governor = null, LythonSourceSpan? span = null)
    {
        var text = Value.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        return governor is null ? PyString.FromString(text) : PyString.FromString(text, governor, span);
    }

    public BigInteger ToOrdinal() => new(Value.DayNumber + 1);

    public PyString RenderPython(PyRenderingContext context)
    {
        _ = context;
        return PyString.FromString($"datetime.date({Value.Year}, {Value.Month}, {Value.Day})", context.Context.MemoryGovernor);
    }

    public PyString RenderInterpolated(PyRenderingContext context) => IsoFormat(context.Context.MemoryGovernor);

    public override bool Equals(object? obj) => obj is PyDate other && Value.Equals(other.Value);

    public override int GetHashCode() => GetPyHashCode();

    public override string ToString() => IsoFormat().AsString();
}

internal sealed class PyTime : IPyTruthyValue, IPyHashableValue, IPyRenderableValue
{
    public static readonly PyTime Min = new(TimeOnly.MinValue);
    public static readonly PyTime Max = new(new TimeOnly(23, 59, 59, 999).Add(TimeSpan.FromTicks(9990)));
    public static readonly PyTimedelta Resolution = new(TimeSpan.FromTicks(10));

    public PyTime(TimeOnly value) : this(value, null, 0) { }

    public PyTime(TimeOnly value, PyTimezone? tzinfo) : this(value, tzinfo, 0) { }

    public PyTime(TimeOnly value, PyTimezone? tzinfo, int fold)
    {
        Value = value;
        TzInfo = tzinfo;
        Fold = fold;
    }

    public TimeOnly Value { get; }

    public PyTimezone? TzInfo { get; }

    public int Fold { get; }

    public BigInteger Hour => new(Value.Hour);

    public BigInteger Minute => new(Value.Minute);

    public BigInteger Second => new(Value.Second);

    public BigInteger Microsecond => new(Value.Millisecond * 1000 + Value.Microsecond);

    public bool IsTruthy() => true;

    public int GetPyHashCode() => HashCode.Combine(TzInfo is null ? Value.Ticks : PyDateTimeOps.AdjustTimeTicks(Value, TzInfo.Offset));

    public PyString IsoFormat()
        => IsoFormat("auto");

    public PyString IsoFormat(string timespec, MemoryGovernor? governor = null, LythonSourceSpan? span = null)
    {
        var text = PyDateTimeOps.FormatIsoTime(Value, timespec);
        if (TzInfo is not null)
        {
            text += PyDateTimeOps.FormatOffset(TzInfo.Offset);
        }

        return governor is null ? PyString.FromString(text) : PyString.FromString(text, governor, span);
    }

    public PyString RenderPython(PyRenderingContext context)
    {
        var builder = new GovernedByteBuilder(context.Context.MemoryGovernor);
        try
        {
            builder.AppendString($"datetime.time({Value.Hour}, {Value.Minute}");
            if (Value.Second != 0 || Microsecond != 0)
            {
                builder.AppendString($", {Value.Second}");
            }

            if (Microsecond != 0)
            {
                builder.AppendString($", {Microsecond}");
            }

            if (TzInfo is not null)
            {
                builder.AppendAscii(", tzinfo=");
                builder.Append(TzInfo.RenderPython(context));
            }

            if (Fold != 0)
            {
                builder.AppendAscii(", fold=1");
            }

            builder.Append((byte)')');
            return builder.ToPyStringAndRelease();
        }
        finally { builder.Release(); }
    }

    public PyString RenderInterpolated(PyRenderingContext context) => IsoFormat("auto", context.Context.MemoryGovernor);

    public override bool Equals(object? obj)
        => obj is PyTime other &&
           PyDateTimeOps.TimeEquals(this, other);

    public override int GetHashCode() => GetPyHashCode();

    public override string ToString() => IsoFormat().AsString();
}

internal sealed class PyDateTime : IPyTruthyValue, IPyHashableValue, IPyRenderableValue
{
    public static readonly PyDateTime Min = new(DateTime.MinValue);
    public static readonly PyDateTime Max = new(new DateTime(9999, 12, 31, 23, 59, 59, 999, DateTimeKind.Unspecified).AddTicks(9990));
    public static readonly PyTimedelta Resolution = new(TimeSpan.FromTicks(10));

    public PyDateTime(DateTime value) : this(value, null, 0) { }

    public PyDateTime(DateTime value, PyTimezone? tzinfo) : this(value, tzinfo, 0) { }

    public PyDateTime(DateTime value, PyTimezone? tzinfo, int fold)
    {
        Value = DateTime.SpecifyKind(value, DateTimeKind.Unspecified);
        TzInfo = tzinfo;
        Fold = fold;
    }

    public DateTime Value { get; }

    public PyTimezone? TzInfo { get; }

    public int Fold { get; }

    public BigInteger Year => new(Value.Year);

    public BigInteger Month => new(Value.Month);

    public BigInteger Day => new(Value.Day);

    public BigInteger Hour => new(Value.Hour);

    public BigInteger Minute => new(Value.Minute);

    public BigInteger Second => new(Value.Second);

    public BigInteger Microsecond => new(Value.Millisecond * 1000 + Value.Microsecond);

    public bool IsTruthy() => true;

    public int GetPyHashCode() => HashCode.Combine(TzInfo is null ? Value.Ticks : ToUtcTicks());

    public PyDate DatePart() => new(DateOnly.FromDateTime(Value));

    public PyTime TimePart() => new(TimeOnly.FromDateTime(Value), TzInfo, Fold);

    public PyTime NaiveTimePart() => new(TimeOnly.FromDateTime(Value), tzinfo: null, fold: Fold);

    public PyString IsoFormat()
        => IsoFormat("T", "auto");

    public PyString IsoFormat(string separator)
        => IsoFormat(separator, "auto");

    public PyString IsoFormat(string separator, string timespec, MemoryGovernor? governor = null, LythonSourceSpan? span = null)
    {
        var text = Value.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) + separator + PyDateTimeOps.FormatIsoTime(TimeOnly.FromDateTime(Value), timespec);
        if (TzInfo is not null)
        {
            text += PyDateTimeOps.FormatOffset(TzInfo.Offset);
        }

        return governor is null ? PyString.FromString(text) : PyString.FromString(text, governor, span);
    }

    public long ToUtcTicks()
        => Value.Ticks - (TzInfo?.Offset.Ticks ?? 0);

    public BigInteger ToOrdinal() => new(DateOnly.FromDateTime(Value).DayNumber + 1);

    public PyString RenderPython(PyRenderingContext context)
    {
        var builder = new GovernedByteBuilder(context.Context.MemoryGovernor);
        try
        {
            builder.AppendString($"datetime.datetime({Value.Year}, {Value.Month}, {Value.Day}, {Value.Hour}, {Value.Minute}");
            if (Value.Second != 0 || Microsecond != 0)
            {
                builder.AppendString($", {Value.Second}");
            }

            if (Microsecond != 0)
            {
                builder.AppendString($", {Microsecond}");
            }

            if (Fold != 0)
            {
                builder.AppendAscii(", fold=1");
            }

            if (TzInfo is not null)
            {
                builder.AppendAscii(", tzinfo=");
                builder.Append(TzInfo.RenderPython(context));
            }

            builder.Append((byte)')');
            return builder.ToPyStringAndRelease();
        }
        finally { builder.Release(); }
    }

    public PyString RenderInterpolated(PyRenderingContext context)
    {
        _ = context;
        return IsoFormat(" ", "auto", context.Context.MemoryGovernor);
    }

    public override bool Equals(object? obj)
        => obj is PyDateTime other &&
           PyDateTimeOps.DateTimeEquals(this, other);

    public override int GetHashCode() => GetPyHashCode();

    public override string ToString() => IsoFormat(" ").AsString();
}

internal sealed class PyIsoCalendarDate : IPySequenceValue, IPyIndexableValue, IPyIterableValue, IPyTruthyValue, IPyRenderableValue, IPyDynamicAttributes, IPyHashableValue
{
    private readonly PyTuple _items;

    internal PyIsoCalendarDate(BigInteger year, BigInteger week, BigInteger weekday, MemoryGovernor governor, LythonSourceSpan? span)
    {
        _items = PyTuple.FromOwnedArray([year, week, weekday], governor, span);
    }

    public BigInteger Year => (BigInteger)_items[0];

    public BigInteger Week => (BigInteger)_items[1];

    public BigInteger Weekday => (BigInteger)_items[2];

    public int Count => _items.Count;

    public int Length => _items.Length;

    public object this[int index] => _items[index];

    public object GetItem(int index) => _items.GetItem(index);

    public object CreateSlice(IEnumerable<object> items) => new PyTuple(items);

    public object GetIndex(int index) => _items.GetIndex(index);

    public object GetSlice(IEnumerable<int> indices) => _items.GetSlice(indices);

    public int GetPyHashCode() => _items.GetPyHashCode();

    public override int GetHashCode() => GetPyHashCode();

    public override bool Equals(object? other) => other is not null &&
        PyTupleLike.TryGetItems(other, out var items) && _items.SequenceEqual(items, PyValueComparer.Instance);

    public bool IsTruthy() => true;

    public IEnumerable<object> Iterate() => _items;

    public IEnumerator<object> GetEnumerator() => _items.GetEnumerator();

    System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator() => GetEnumerator();

    public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
    {
        value = name switch
        {
            "year" => Year,
            "week" => Week,
            "weekday" => Weekday,
            "__module__" => LythonRuntime.ExceptionTypeValue.SharedModuleLabel("datetime"),
            _ => MissingMemberValue.Instance,
        };

        return !ReferenceEquals(value, MissingMemberValue.Instance) || LythonRuntime.TupleMembers.TryGetMember(_items, name, out value);
    }
    public PyString RenderPython(PyRenderingContext context)
    {
        _ = context;
        return PyString.FromString($"datetime.IsoCalendarDate(year={Year}, week={Week}, weekday={Weekday})", context.Context.MemoryGovernor);
    }

    public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);
}
