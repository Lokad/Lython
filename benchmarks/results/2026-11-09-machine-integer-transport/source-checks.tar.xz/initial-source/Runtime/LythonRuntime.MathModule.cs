using System.Numerics;
using Lokad.Lython.Runtime.Numbers;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private sealed partial class MathModule
    {
        private static readonly double[] LanczosCoefficients =
        [
            676.5203681218851,
            -1259.1392167224028,
            771.32342877765313,
            -176.61502916214059,
            12.507343278686905,
            -0.13857109526572012,
            9.9843695780195716e-6,
            1.5056327351493116e-7,
        ];

        private static object Factorial(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var n = ExpectNonNegativeInteger(arguments[0], "factorial() not defined for negative values", span, context);
            // Upper-bound the exact result before computing (log2(n!) < n * bitlen(n)):
            // reserve result plus product/scratch coexistence so an enormous
            // factorial denies before any multiply traffic instead of after it.
            using var integerAdmission = GuardIntegerProductBytes(n, n, span, context);
            var result = BigInteger.One;
            for (var i = new BigInteger(2); i <= n; i++)
            {
                if ((i & 63) == 0)
                {
                    context.CheckExecution(span);
                }

                result *= i;
            }

            return OwnHeapInteger(result, context.MemoryGovernor, span);
        }

        private static MemoryGovernor.TemporaryMemoryReservation? GuardIntegerProductBytes(BigInteger count, BigInteger n, LythonSourceSpan span, ExecutionContext context)
        {
            // Factorial, permutations and each combination multiply-before-divide
            // are bounded by n**count. Fund result and arithmetic overlap without
            // narrowing the iteration count or imposing a separate work limit.
            var countEstimate = count > long.MaxValue ? long.MaxValue : (long)count;
            var resultBits = RuntimeMemoryEstimates.SaturatingMultiply(countEstimate, RuntimeMemoryEstimates.GetMagnitudeBitLength(n));
            return GuardIntegerResultBytes(
                RuntimeMemoryEstimates.SaturatingMultiply(3, RuntimeMemoryEstimates.EstimateBigIntegerBytesFromBitCount(resultBits)),
                context.MemoryGovernor,
                span);
        }

        private static object Gcd(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var result = BigInteger.Zero;
            var seen = 0;
            foreach (var argument in arguments)
            {
                if ((++seen & 63) == 0)
                {
                    context.CheckExecution(span);
                }

                result = BigInteger.GreatestCommonDivisor(result, BigInteger.Abs(ExpectInteger(argument, span, context)));
            }

            return OwnHeapInteger(result, context.MemoryGovernor, span);
        }

        private static object Lcm(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var result = BigInteger.One;
            var seen = 0;
            foreach (var argument in arguments)
            {
                if ((++seen & 63) == 0)
                {
                    context.CheckExecution(span);
                }

                var value = BigInteger.Abs(ExpectInteger(argument, span, context));
                if (result.IsZero || value.IsZero)
                {
                    result = BigInteger.Zero;
                    continue;
                }

                // Upper-bound the combined multiple before dividing: the product
                // needs at most bits(result) + bits(value), with quotient scratch
                // coexisting transiently. This covers large-magnitude inputs that
                // few iterations would otherwise grow without any bound.
                using var integerAdmission = GuardIntegerResultBytes(
                    RuntimeMemoryEstimates.SaturatingMultiply(3, RuntimeMemoryEstimates.EstimateBigIntegerBytesFromBitCount(
                        RuntimeMemoryEstimates.SaturatingAdd(
                            RuntimeMemoryEstimates.GetMagnitudeBitLength(result),
                            RuntimeMemoryEstimates.GetMagnitudeBitLength(value)))),
                    context.MemoryGovernor,
                    span);
                result = BigInteger.Abs(result / BigInteger.GreatestCommonDivisor(result, value) * value);
            }

            return OwnHeapInteger(result, context.MemoryGovernor, span);
        }

        private static object Comb(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var n = ExpectNonNegativeInteger(arguments[0], "n must be a non-negative integer", span, context);
            var k = ExpectNonNegativeInteger(arguments[1], "k must be a non-negative integer", span, context);
            if (k > n)
            {
                return BigInteger.Zero;
            }

            k = BigInteger.Min(k, n - k);
            using var integerAdmission = GuardIntegerProductBytes(k, n, span, context);
            var result = BigInteger.One;
            for (var i = BigInteger.One; i <= k; i++)
            {
                if ((i & 63) == 0)
                {
                    context.CheckExecution(span);
                }

                result = result * (n - k + i) / i;
            }

            return OwnHeapInteger(result, context.MemoryGovernor, span);
        }

        private static object Perm(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var n = ExpectNonNegativeInteger(arguments[0], "n must be a non-negative integer", span, context);
            var k = arguments.Length >= 2 && !ReferenceEquals(arguments[1], PyNone.Instance)
                ? ExpectNonNegativeInteger(arguments[1], "k must be a non-negative integer", span, context)
                : n;
            if (k > n)
            {
                return BigInteger.Zero;
            }

            // P(n,k) <= n^k: reserve result plus product/scratch coexistence
            // before iterating (also covers large n with small k).
            using var integerAdmission = GuardIntegerProductBytes(k, n, span, context);
            var result = BigInteger.One;
            for (var i = BigInteger.Zero; i < k; i++)
            {
                if ((i & 63) == 0)
                {
                    context.CheckExecution(span);
                }

                result *= n - i;
            }

            return OwnHeapInteger(result, context.MemoryGovernor, span);
        }

        private static object ISqrt(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            return OwnHeapInteger(IntegerSquareRoot(ExpectNonNegativeInteger(arguments[0], "isqrt() argument must be nonnegative", span, context), context, span), context.MemoryGovernor, span);
        }

        private static object Dist(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            // Stream paired inputs instead of draining both into object arrays: when
            // both sides expose a cheap count the dimension check runs before any
            // iteration (matching CPython error precedence), otherwise pairs pull
            // lockstep with cooperative cancellation per element.
            // Differences convert to doubles immediately, so peak scratch is one
            // double per dimension under a live temporary reservation.
            if (TryGetKnownLength(arguments[0], out var pLength) &&
                TryGetKnownLength(arguments[1], out var qLength) &&
                pLength != qLength)
            {
                throw new LythonRuntimeException("ValueError", "both points must have the same number of dimensions", span);
            }

            using var pCursor = PyIteration.Cursor.Create(arguments[0], span, context);
            using var qCursor = PyIteration.Cursor.Create(arguments[1], span, context);
            using var scratch = context.MemoryGovernor.ReserveTemporary(0, span);
            var differences = new List<double>();
            long charged = 0;
            while (true)
            {
                var pHas = pCursor.TryMoveNext(out var pItem);
                var qHas = qCursor.TryMoveNext(out var qItem);
                if (!pHas || !qHas)
                {
                    if (pHas != qHas)
                    {
                        throw new LythonRuntimeException("ValueError", "both points must have the same number of dimensions", span);
                    }

                    break;
                }

                if (differences.Count == differences.Capacity)
                {
                    // Fund the predicted backing before it can allocate, tracking
                    // funded (not observed) capacity so the post-add charge below
                    // covers only a real discrepancy (R12 double-charge pattern).
                    var predicted = differences.Capacity == 0 ? 4L : (long)differences.Capacity * 2L;
                    if (predicted > charged)
                    {
                        scratch.Grow(checked(8L * (predicted - charged)), span);
                        charged = predicted;
                    }
                }

                differences.Add(ExpectReal(pItem!, "math.dist", span) - ExpectReal(qItem!, "math.dist", span));
                if (differences.Capacity > charged)
                {
                    scratch.Grow(8L * (differences.Capacity - charged), span);
                    charged = differences.Capacity;
                }

                context.CheckExecution(span);
            }

            if (differences.Count == 0)
            {
                return 0.0;
            }

            return ScaledHypot(differences);
        }

        private static async ValueTask<object> DistAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            // Async twin of the streaming body above: cursors await delayed host
            // reads through the async boundary instead of driving them
            // synchronously, with the same per-element enforcement.
            if (TryGetKnownLength(arguments[0], out var pLength) &&
                TryGetKnownLength(arguments[1], out var qLength) &&
                pLength != qLength)
            {
                throw new LythonRuntimeException("ValueError", "both points must have the same number of dimensions", span);
            }

            await using var pCursor = PyIteration.Cursor.Create(arguments[0], span, context);
            await using var qCursor = PyIteration.Cursor.Create(arguments[1], span, context);
            using var scratch = context.MemoryGovernor.ReserveTemporary(0, span);
            var differences = new List<double>();
            long charged = 0;
            while (true)
            {
                var pNext = await pCursor.TryMoveNextAsync().ConfigureAwait(false);
                var qNext = await qCursor.TryMoveNextAsync().ConfigureAwait(false);
                if (!pNext.HasValue || !qNext.HasValue)
                {
                    if (pNext.HasValue != qNext.HasValue)
                    {
                        throw new LythonRuntimeException("ValueError", "both points must have the same number of dimensions", span);
                    }

                    break;
                }

                if (differences.Count == differences.Capacity)
                {
                    var predicted = differences.Capacity == 0 ? 4L : (long)differences.Capacity * 2L;
                    if (predicted > charged)
                    {
                        scratch.Grow(checked(8L * (predicted - charged)), span);
                        charged = predicted;
                    }
                }

                differences.Add(ExpectReal(pNext.Value, "math.dist", span) - ExpectReal(qNext.Value, "math.dist", span));
                if (differences.Capacity > charged)
                {
                    scratch.Grow(8L * (differences.Capacity - charged), span);
                    charged = differences.Capacity;
                }

                context.CheckExecution(span);
            }

            if (differences.Count == 0)
            {
                return 0.0;
            }

            return ScaledHypot(differences);
        }

        // Cheap lengths for concrete collections, used only to order the
        // dimension check before iteration. Unsized iterables (generators,
        // user iterators) fall through to lockstep streaming.
        private static bool TryGetKnownLength(object value, out long length)
        {
            switch (value)
            {
                case PyList list:
                    length = list.Count;
                    return true;
                case PyDict dict:
                    length = dict.Count;
                    return true;
                case PySet set:
                    length = set.Count;
                    return true;
                case PyDeque deque:
                    length = deque.Count;
                    return true;
                case PyCounter counter:
                    length = counter.Count;
                    return true;
                case PyDefaultDict defaultdict:
                    length = defaultdict.Count;
                    return true;
                case PyRange range:
                    length = range.Length > long.MaxValue ? long.MaxValue : (long)range.Length;
                    return true;
                default:
                    if (PyTupleLike.TryGetItems(value, out var tuple))
                    {
                        length = tuple.Count;
                        return true;
                    }

                    length = 0;
                    return false;
            }
        }

        private static object Frexp(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var value = ExpectUnaryReal(arguments, "math.frexp", span, context);
            if (value == 0.0 || double.IsNaN(value) || double.IsInfinity(value))
            {
                return PyTuple.FromOwnedArray([value, BigInteger.Zero], context.MemoryGovernor, span);
            }

            var exponent = 0;
            var mantissa = value;
            var abs = Math.Abs(mantissa);
            while (abs < 0.5)
            {
                mantissa *= 2.0;
                exponent--;
                abs *= 2.0;
            }

            while (abs >= 1.0)
            {
                mantissa *= 0.5;
                exponent++;
                abs *= 0.5;
            }

            return PyTuple.FromOwnedArray([mantissa, new BigInteger(exponent)], context.MemoryGovernor, span);
        }

        private static object Ldexp(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var value = ExpectReal(arguments[0], "math.ldexp", span);
            var exponent = ExpectInteger(arguments[1], span, context);
            if (double.IsNaN(value) || double.IsInfinity(value) || value == 0.0)
            {
                return value;
            }

            if (exponent > int.MaxValue)
            {
                throw new LythonRuntimeException("OverflowError", "math range error", span);
            }

            if (exponent < int.MinValue)
            {
                return Math.CopySign(0.0, value);
            }

            return CheckedMathResult(Math.ScaleB(value, (int)exponent), "math.ldexp", span, value);
        }

        private static object Modf(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var value = ExpectUnaryReal(arguments, "math.modf", span, context);
            double fractional;
            double integral;
            if (double.IsInfinity(value))
            {
                fractional = Math.CopySign(0.0, value);
                integral = value;
            }
            else if (double.IsNaN(value))
            {
                fractional = double.NaN;
                integral = double.NaN;
            }
            else
            {
                integral = Math.Truncate(value);
                fractional = value - integral;
                if (fractional == 0.0)
                {
                    fractional = Math.CopySign(0.0, value);
                }
            }

            return PyTuple.FromOwnedArray([fractional, integral], context.MemoryGovernor, span);
        }

        private static object Remainder(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var (x, y) = ExpectBinaryReal(arguments, "math.remainder", span, context);
            if (y == 0.0 || double.IsInfinity(x))
            {
                throw new LythonRuntimeException("ValueError", "math domain error", span);
            }

            return Math.IEEERemainder(x, y);
        }

        private static object NextAfter(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var x = ExpectReal(arguments[0], "math.nextafter", span);
            var y = ExpectReal(arguments[1], "math.nextafter", span);
            var steps = arguments.Length >= 3 && !ReferenceEquals(arguments[2], PyNone.Instance)
                ? ExpectInteger(arguments[2], span, context)
                : BigInteger.One;
            if (steps < BigInteger.Zero)
            {
                throw new LythonRuntimeException("ValueError", "steps must be a non-negative integer", span);
            }

            context.CheckExecution(span);
            if (steps.IsZero || double.IsNaN(x)) return x;
            if (double.IsNaN(y)) return y;

            // IEEE magnitudes count adjacent values directly. Any larger count
            // reaches the target, so saturate at ulong's representation width.
            // BitConverter keeps this independent of native layout and pointers.
            var count = steps.GetBitLength() > 64 ? ulong.MaxValue : (ulong)steps;
            var xBits = BitConverter.DoubleToUInt64Bits(x);
            var yBits = BitConverter.DoubleToUInt64Bits(y);
            if (xBits == yBits) return x;
            const ulong sign = 1UL << 63;
            var xMagnitude = xBits & ~sign;
            var yMagnitude = yBits & ~sign;
            ulong resultBits;
            if (((xBits ^ yBits) & sign) != 0)
            {
                if (count >= xMagnitude + yMagnitude) return y;
                // Reaching zero preserves the source sign; crossing it adopts
                // the target sign without counting an extra signed-zero step.
                resultBits = count > xMagnitude
                    ? (yBits & sign) | (count - xMagnitude)
                    : xBits - count;
            }
            else if (xMagnitude > yMagnitude)
            {
                if (count >= xMagnitude - yMagnitude) return y;
                resultBits = xBits - count;
            }
            else
            {
                if (count >= yMagnitude - xMagnitude) return y;
                resultBits = xBits + count;
            }
            return BitConverter.UInt64BitsToDouble(resultBits);
        }

        private static object Ulp(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var value = ExpectUnaryReal(arguments, "math.ulp", span, context);
            if (double.IsNaN(value))
            {
                return double.NaN;
            }

            if (double.IsInfinity(value))
            {
                return double.PositiveInfinity;
            }

            var abs = Math.Abs(value);
            if (abs == 0.0)
            {
                return double.Epsilon;
            }

            var next = Math.BitIncrement(abs);
            return double.IsInfinity(next) ? abs - Math.BitDecrement(abs) : next - abs;
        }

        private static object Exp2(object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => UnaryCheckedFloat(arguments, "math.exp2", span, context, static value => Math.Pow(2.0, value));

        private static object Expm1(object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => UnaryCheckedFloat(arguments, "math.expm1", span, context, Expm1Accurate);

        private static object Log1p(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var value = ExpectUnaryReal(arguments, "math.log1p", span, context);
            if (value <= -1.0)
            {
                throw new LythonRuntimeException("ValueError", "math domain error", span);
            }

            return Log1pAccurate(value);
        }

        private static object Cbrt(object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => UnaryFloat(arguments, "math.cbrt", span, context, Math.Cbrt);

        private static object Erf(object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => UnaryFloat(arguments, "math.erf", span, context, FloatingPointSpecialFunctions.Erf);

        private static object Erfc(object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => UnaryFloat(arguments, "math.erfc", span, context, FloatingPointSpecialFunctions.Erfc);

        private static object Gamma(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var value = ExpectUnaryReal(arguments, "math.gamma", span, context);
            if (double.IsNaN(value))
            {
                return double.NaN;
            }

            if (double.IsPositiveInfinity(value))
            {
                return double.PositiveInfinity;
            }

            if (double.IsNegativeInfinity(value) || IsNonPositiveInteger(value))
            {
                throw new LythonRuntimeException("ValueError", "math domain error", span);
            }

            return CheckedMathResult(GammaLanczos(value), "math.gamma", span, value);
        }

        private static object LGamma(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var value = ExpectUnaryReal(arguments, "math.lgamma", span, context);
            if (double.IsNaN(value))
            {
                return double.NaN;
            }

            if (double.IsInfinity(value))
            {
                return double.PositiveInfinity;
            }

            if (IsNonPositiveInteger(value))
            {
                throw new LythonRuntimeException("ValueError", "math domain error", span);
            }

            return LogGammaLanczos(value);
        }

        private static object Fma(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            _ = context;
            var x = ExpectReal(arguments[0], "math.fma", span);
            var y = ExpectReal(arguments[1], "math.fma", span);
            var z = ExpectReal(arguments[2], "math.fma", span);
            if ((double.IsInfinity(x) && y == 0.0 || double.IsInfinity(y) && x == 0.0) && !double.IsNaN(z))
            {
                throw new LythonRuntimeException("ValueError", "invalid operation in fma", span);
            }

            var result = Math.FusedMultiplyAdd(x, y, z);
            if (double.IsInfinity(result) && double.IsFinite(x) && double.IsFinite(y) && double.IsFinite(z))
            {
                throw new LythonRuntimeException("OverflowError", "overflow in fma", span);
            }

            return result;
        }

        private static object SumProd(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            // Fully streaming pairwise accumulation: no input is ever materialized,
            // so arbitrary iterables remain cancellable per pair without
            // allocating two object arrays up front.
            if (TryGetKnownLength(arguments[0], out var pLength) &&
                TryGetKnownLength(arguments[1], out var qLength) &&
                pLength != qLength)
            {
                throw new LythonRuntimeException("ValueError", "Inputs are not the same length", span);
            }

            using var pCursor = PyIteration.Cursor.Create(arguments[0], span, context);
            using var qCursor = PyIteration.Cursor.Create(arguments[1], span, context);
            object total = BigInteger.Zero;
            var pairs = 0;
            while (true)
            {
                var pHas = pCursor.TryMoveNext(out var pItem);
                var qHas = qCursor.TryMoveNext(out var qItem);
                if (!pHas || !qHas)
                {
                    if (pHas != qHas)
                    {
                        throw new LythonRuntimeException("ValueError", "Inputs are not the same length", span);
                    }

                    break;
                }

                if (!PyNumberOps.TryAsNumber(pItem!, out var left) || !PyNumberOps.TryAsNumber(qItem!, out var right))
                {
                    throw new LythonRuntimeException("TypeError", "math.sumprod(...) expects iterables of real numbers.", span);
                }

                object product;
                try
                {
                    product = PyNumberOps.Multiply(left, right);
                }
                catch (OverflowException ex)
                {
                    throw new LythonRuntimeException("OverflowError", ex.Message, span);
                }

                total = EvaluateAdd(total, OwnHeapInteger(product, context.MemoryGovernor, span), context, span);
                pairs++;
                context.CheckExecution(span);
            }

            return RuntimeValue(total);
        }

        private static async ValueTask<object> SumProdAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            // Async twin of the streaming body above: cursors await delayed host
            // reads through the async boundary with the same per-pair enforcement.
            if (TryGetKnownLength(arguments[0], out var pLength) &&
                TryGetKnownLength(arguments[1], out var qLength) &&
                pLength != qLength)
            {
                throw new LythonRuntimeException("ValueError", "Inputs are not the same length", span);
            }

            await using var pCursor = PyIteration.Cursor.Create(arguments[0], span, context);
            await using var qCursor = PyIteration.Cursor.Create(arguments[1], span, context);
            object total = BigInteger.Zero;
            var pairs = 0;
            while (true)
            {
                var pNext = await pCursor.TryMoveNextAsync().ConfigureAwait(false);
                var qNext = await qCursor.TryMoveNextAsync().ConfigureAwait(false);
                if (!pNext.HasValue || !qNext.HasValue)
                {
                    if (pNext.HasValue != qNext.HasValue)
                    {
                        throw new LythonRuntimeException("ValueError", "Inputs are not the same length", span);
                    }

                    break;
                }

                if (!PyNumberOps.TryAsNumber(pNext.Value, out var left) || !PyNumberOps.TryAsNumber(qNext.Value, out var right))
                {
                    throw new LythonRuntimeException("TypeError", "math.sumprod(...) expects iterables of real numbers.", span);
                }

                object product;
                try
                {
                    product = PyNumberOps.Multiply(left, right);
                }
                catch (OverflowException ex)
                {
                    throw new LythonRuntimeException("OverflowError", ex.Message, span);
                }

                total = EvaluateAdd(total, OwnHeapInteger(product, context.MemoryGovernor, span), context, span);
                pairs++;
                context.CheckExecution(span);
            }

            return RuntimeValue(total);
        }

        private static BigInteger ExpectInteger(object value, LythonSourceSpan span, ExecutionContext context)
        {
            var converted = CoerceIndexProtocol(value, context, span);
            if (!PyNumberOps.TryAsInteger(converted, out var integer))
            {
                throw new LythonRuntimeException("TypeError", "'" + RuntimeErrors.DatetimeQualifiedTypeName(value, context) + "' object cannot be interpreted as an integer", span);
            }

            return integer;
        }

        private static BigInteger ExpectNonNegativeInteger(object value, string negativeMessage, LythonSourceSpan span, ExecutionContext context)
        {
            var integer = ExpectInteger(value, span, context);
            if (integer < BigInteger.Zero)
            {
                throw new LythonRuntimeException("ValueError", negativeMessage, span);
            }

            return integer;
        }

        private static double ScaledHypot(IReadOnlyList<double> values)
        {
            // Single pass over the caller-owned differences with absolute values
            // taken inline: no coordinate or absolute-value copies are made, while
            // the max-abs scaling keeps infinities, NaNs, and extreme scales exact.
            var max = 0.0;
            foreach (var value in values)
            {
                var absolute = Math.Abs(value);
                if (double.IsPositiveInfinity(absolute))
                {
                    return double.PositiveInfinity;
                }

                max = Math.Max(max, absolute);
            }

            if (max == 0.0 || double.IsNaN(max))
            {
                return max;
            }

            var scaled = 0.0;
            foreach (var value in values)
            {
                var ratio = Math.Abs(value) / max;
                scaled += ratio * ratio;
            }

            return max * Math.Sqrt(scaled);
        }

        private static bool IsNonPositiveInteger(double value)
            => value <= 0.0 && Math.Truncate(value) == value;

        private static double Expm1Accurate(double value)
        {
            if (Math.Abs(value) >= 1e-5 || !double.IsFinite(value))
            {
                return Math.Exp(value) - 1.0;
            }

            var term = value;
            var sum = value;
            for (var n = 2; n <= 18; n++)
            {
                term *= value / n;
                sum += term;
            }

            return sum;
        }

        private static double Log1pAccurate(double value)
        {
            if (Math.Abs(value) >= 1e-4)
            {
                return Math.Log(1.0 + value);
            }

            var term = value;
            var sum = value;
            for (var n = 2; n <= 24; n++)
            {
                term *= -value;
                sum += term / n;
            }

            return sum;
        }

        private static double GammaLanczos(double value)
        {
            if (value < 0.5)
            {
                return Math.PI / (Math.Sin(Math.PI * value) * GammaLanczos(1.0 - value));
            }

            var z = value - 1.0;
            var x = 0.99999999999980993;
            for (var i = 0; i < LanczosCoefficients.Length; i++)
            {
                x += LanczosCoefficients[i] / (z + i + 1.0);
            }

            var t = z + LanczosCoefficients.Length - 0.5;
            return Math.Sqrt(2.0 * Math.PI) * Math.Pow(t, z + 0.5) * Math.Exp(-t) * x;
        }

        private static double LogGammaLanczos(double value)
        {
            if (value < 0.5)
            {
                return Math.Log(Math.PI) - Math.Log(Math.Abs(Math.Sin(Math.PI * value))) - LogGammaLanczos(1.0 - value);
            }

            var z = value - 1.0;
            var x = 0.99999999999980993;
            for (var i = 0; i < LanczosCoefficients.Length; i++)
            {
                x += LanczosCoefficients[i] / (z + i + 1.0);
            }

            var t = z + LanczosCoefficients.Length - 0.5;
            return 0.5 * Math.Log(2.0 * Math.PI) + (z + 0.5) * Math.Log(t) - t + Math.Log(x);
        }
    }
}
