namespace Lokad.Lython.Runtime;

internal readonly record struct BoundCallArguments(
    object[] Values,
    ArgumentPresence Assigned,
    MemoryGovernor? StorageOwner = null);

internal struct ArgumentPresence
{
    // Almost every Python-shaped signature fits in the inline word. The overflow
    // array exists only for unusually wide generated signatures, so ordinary calls
    // do not allocate a parallel bool[] merely to distinguish omitted arguments.
    private ulong _firstAssignments;
    private readonly bool[] _remainingAssignments;

    public ArgumentPresence(int length)
    {
        ArgumentOutOfRangeException.ThrowIfNegative(length);
        Length = length;
        _firstAssignments = 0;
        _remainingAssignments = length > 64 ? new bool[length - 64] : [];
    }

    public static ArgumentPresence Empty { get; } = new(0);

    public int Length { get; }

    public bool this[int index]
    {
        get
        {
            ArgumentOutOfRangeException.ThrowIfGreaterThanOrEqual((uint)index, (uint)Length);
            return index < 64
                ? (_firstAssignments & (1UL << index)) != 0
                : _remainingAssignments[index - 64];
        }
        set
        {
            ArgumentOutOfRangeException.ThrowIfGreaterThanOrEqual((uint)index, (uint)Length);
            if (index < 64)
            {
                var mask = 1UL << index;
                _firstAssignments = value ? _firstAssignments | mask : _firstAssignments & ~mask;
                return;
            }

            _remainingAssignments[index - 64] = value;
        }
    }

    public ArgumentPresence WithLength(int length)
    {
        if (length == Length)
        {
            return this;
        }

        var resized = new ArgumentPresence(length);
        resized._firstAssignments = length >= 64
            ? _firstAssignments
            : _firstAssignments & ((1UL << length) - 1);
        // A default ArgumentPresence has Length == 0 and no initialized overflow
        // storage. Length is therefore the invariant that guards every array access.
        if (Length > 64)
        {
            Array.Copy(
                _remainingAssignments,
                resized._remainingAssignments,
                Math.Min(_remainingAssignments.Length, resized._remainingAssignments.Length));
        }

        return resized;
    }

    public void MarkRange(int start, int count)
    {
        for (var index = start; index < start + count; index++)
        {
            this[index] = true;
        }
    }
}

internal static class CallBinder
{
    public static object[] BindNamedArguments(
        ReadOnlySpan<CallArgumentValue> arguments,
        LythonSourceSpan span,
        LythonCallableSignature signature,
        PythonCallableKind callableKind)
    {
        return BindNamedArgumentsCore(
            arguments,
            span,
            signature.Name,
            callableKind,
            signature.Parameters).Values;
    }

    public static BoundCallArguments BindNamedArgumentsWithPresence(
        ReadOnlySpan<CallArgumentValue> arguments,
        LythonSourceSpan span,
        LythonCallableSignature signature,
        PythonCallableKind callableKind)
    {
        return BindNamedArgumentsCore(
            arguments,
            span,
            signature.Name,
            callableKind,
            signature.Parameters,
            preservePresence: true);
    }

    private static BoundCallArguments BindNamedArgumentsCore(
        ReadOnlySpan<CallArgumentValue> arguments,
        LythonSourceSpan span,
        string callableName,
        PythonCallableKind callableKind,
        CallableParameterLayout parameters,
        bool preservePresence = false)
    {
        if (parameters is PositionalCallableParameterLayout)
        {
            for (var i = 0; i < arguments.Length; i++)
            {
                if (arguments[i].IsKeyword)
                {
                    throw CallErrors.NoKeywordArguments(callableKind, callableName, span);
                }
            }

            var positionalOnly = new object[arguments.Length];
            for (var i = 0; i < arguments.Length; i++)
            {
                positionalOnly[i] = arguments[i].Value;
            }

            return new BoundCallArguments(positionalOnly, ArgumentPresence.Empty);
        }

        var named = (NamedCallableParameterLayout)parameters;
        var parameterNames = named.ParameterNames;
        var assigned = new ArgumentPresence(parameterNames.Length);
        var extraPositionalCount = 0;
        var positionalIndex = 0;

        // Validate the already-expanded arguments before allocating their final
        // shape. No guest code runs during either pass, so the second pass can
        // place values directly without a full temporary array or extra list.
        foreach (var argument in arguments)
        {
            if (argument.IsPositional)
            {
                if (!named.MaximumPositionalArgumentCount.Accepts(positionalIndex + 1))
                {
                    throw CallErrors.TooManyPositional(callableKind, callableName, span);
                }

                if (positionalIndex < assigned.Length && assigned[positionalIndex])
                {
                    throw CallErrors.MultipleValues(callableKind, callableName, parameterNames[positionalIndex], span);
                }

                if (positionalIndex >= parameterNames.Length)
                {
                    if (!named.AllowsExtraPositional)
                    {
                        throw CallErrors.TooManyPositional(callableKind, callableName, span);
                    }

                    extraPositionalCount++;
                    continue;
                }

                assigned[positionalIndex] = true;
                positionalIndex++;
                continue;
            }

            var keywordName = argument.KeywordName;
            if (!named.ParameterIndices.TryGetValue(keywordName, out var index))
            {
                if (named.AllowsExtraKeywords)
                {
                    continue;
                }

                throw CallErrors.UnexpectedKeyword(callableKind, callableName, keywordName, span);
            }

            if (index < named.PositionalOnlyCount)
            {
                throw CallErrors.UnexpectedKeyword(callableKind, callableName, keywordName, span);
            }

            if (assigned[index])
            {
                throw CallErrors.MultipleValues(callableKind, callableName, keywordName, span);
            }

            assigned[index] = true;
        }

        for (var i = 0; i < named.RequiredCount; i++)
        {
            if (!assigned[i])
            {
                throw CallErrors.MissingArgument(callableKind, callableName, parameterNames[i], span);
            }
        }

        var count = parameterNames.Length;
        // Plain bound callables model defaults by omitting only the unassigned suffix.
        // An explicitly supplied None remains present and prevents this trimming.
        while (count > named.RequiredCount && !assigned[count - 1])
        {
            count--;
        }

        if (!named.MaximumArgumentCount.Accepts(count))
        {
            throw CallErrors.TooManyPositional(callableKind, callableName, span);
        }

        var length = preservePresence && extraPositionalCount == 0
            ? parameterNames.Length : count + extraPositionalCount;
        var result = length == 0 ? Array.Empty<object>() : new object[length];
        Array.Fill(result, PyNone.Instance);
        positionalIndex = 0;
        var extraIndex = count;
        foreach (var argument in arguments)
        {
            if (argument.IsPositional)
            {
                result[positionalIndex < parameterNames.Length ? positionalIndex++ : extraIndex++] = argument.Value;
            }
            else if (named.ParameterIndices.TryGetValue(argument.KeywordName, out var index))
            {
                result[index] = argument.Value;
            }
        }

        var resultAssigned = assigned.WithLength(length);
        resultAssigned.MarkRange(count, extraPositionalCount);
        return new BoundCallArguments(result, resultAssigned);
    }

}
