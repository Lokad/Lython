using System.Globalization;
using System.Linq;
using System.Numerics;
using System.Text;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private sealed class PyScandirIterator : PyIteratorBase, IPyContextManager, IPyDynamicAttributes
    {
        private readonly PyDirEntryObject[] _entries;
        private int _index;
        private bool _closed;

        // N17: hot fixed signatures hoisted per family.
        private static readonly LythonCallableSignature ScandirCloseSignature = LythonCallableSignature.Create("ScandirIterator.close", []);
        private static readonly LythonCallableSignature ScandirEnterSignature = LythonCallableSignature.Create("ScandirIterator.__enter__", []);
        private static readonly LythonCallableSignature ScandirExitSignature = LythonCallableSignature.Create("ScandirIterator.__exit__", ["exc_type", "exc", "tb"]);
        public PyScandirIterator(PyDirEntryObject[] entries)
        {

            _entries = entries;
        }

        public override bool TryMoveNext([MaybeNullWhen(false)] out object value)
        {
            if (_closed || _index >= _entries.Length)
            {
                value = PyNone.Instance;
                return false;
            }

            value = _entries[_index++];
            return true;
        }

        public object Enter() => this;

        public bool Exit(object exceptionType, object exceptionValue, object traceback)
        {
            _ = exceptionType;
            _ = exceptionValue;
            _ = traceback;
            _closed = true;
            return false;
        }

        public override bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            value = name switch
            {
                "close" => BoundCallable.Create((arguments, span, _) =>
                {
                    if (arguments.Length != 0)
                    {
                        throw new LythonRuntimeException("TypeError", "ScandirIterator.close() expects no arguments.", span);
                    }

                    _closed = true;
                    return PyNone.Instance;
                }, ScandirCloseSignature),
                "__enter__" => BoundCallable.Create((arguments, span, _) =>
                {
                    if (arguments.Length != 0)
                    {
                        throw new LythonRuntimeException("TypeError", "ScandirIterator.__enter__() expects no arguments.", span);
                    }

                    return this;
                }, ScandirEnterSignature),
                "__exit__" => BoundCallable.Create((arguments, span, _) =>
                {
                    if (arguments.Length != 3)
                    {
                        throw new LythonRuntimeException("TypeError", "ScandirIterator.__exit__(exc_type, exc, tb) expects three arguments.", span);
                    }

                    _closed = true;
                    return false;
                }, ScandirExitSignature),
                _ => MissingMemberValue.Instance,
            };

            if (ReferenceEquals(value, MissingMemberValue.Instance))
            {
                return base.TryGetMember(name, out value);
            }

            return true;
        }
        public override PyString RenderPython(PyRenderingContext context)
        {
            _ = context;
            return PyString.FromString("<ScandirIterator>");
        }
    }

    internal sealed class PyDirEntryObject : IPyDynamicAttributes, IPyRenderableValue
    {
        private readonly string _name;
        private readonly string _path;
        private readonly MemoryGovernor _governor;
        private readonly LythonSourceSpan? _allocationSpan;
        private LythonPathStat? _stat;
        private PyString? _nameValue;
        private PyString? _pathValue;

        // N17: hot fixed signatures hoisted per family.
        private static readonly LythonCallableSignature DirEntryFspathSignature = LythonCallableSignature.Create("DirEntry.__fspath__", []);
        private static readonly LythonCallableSignature DirEntryIsFileSignature = LythonCallableSignature.Create("DirEntry.is_file", []);
        private static readonly LythonCallableSignature DirEntryIsDirSignature = LythonCallableSignature.Create("DirEntry.is_dir", []);
        private static readonly LythonCallableSignature DirEntryStatSignature = LythonCallableSignature.Create("DirEntry.stat", []);
        private static readonly LythonCallableSignature DirEntryInodeSignature = LythonCallableSignature.Create("DirEntry.inode", []);
        private static readonly LythonCallableSignature DirEntryIsSymlinkSignature = LythonCallableSignature.Create("DirEntry.is_symlink", []);
        public PyDirEntryObject(string name, string path, MemoryGovernor governor, LythonSourceSpan? allocationSpan)
        {
            _name = name;
            _path = path;
            _governor = governor;
            _allocationSpan = allocationSpan;
        }

        public string Path => _path;

        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            value = name switch
            {
                "name" => _nameValue ??= PyString.FromString(_name, _governor, _allocationSpan),
                "path" => _pathValue ??= PyString.FromString(_path, _governor, _allocationSpan),
                "__fspath__" => BoundCallable.Create((arguments, span, _) =>
                {
                    if (arguments.Length != 0)
                    {
                        throw new LythonRuntimeException("TypeError", "DirEntry.__fspath__() expects no arguments.", span);
                    }

                    return _pathValue ??= PyString.FromString(_path, _governor, _allocationSpan);
                }, DirEntryFspathSignature),
                "is_file" => BoundCallable.Create((arguments, span, context) =>
                {
                    if (arguments.Length != 0)
                    {
                        throw new LythonRuntimeException("TypeError", "DirEntry.is_file() expects no arguments.", span);
                    }

                    return GetCachedStat(context, span).IsFile;
                },
                DirEntryIsFileSignature, async (arguments, span, context) =>
                {
                    if (arguments.Length != 0)
                    {
                        throw new LythonRuntimeException("TypeError", "DirEntry.is_file() expects no arguments.", span);
                    }

                    return (await GetCachedStatAsync(context, span).ConfigureAwait(false)).IsFile;
                }),
                "is_dir" => BoundCallable.Create((arguments, span, context) =>
                {
                    if (arguments.Length != 0)
                    {
                        throw new LythonRuntimeException("TypeError", "DirEntry.is_dir() expects no arguments.", span);
                    }

                    return GetCachedStat(context, span).IsDir;
                },
                DirEntryIsDirSignature, async (arguments, span, context) =>
                {
                    if (arguments.Length != 0)
                    {
                        throw new LythonRuntimeException("TypeError", "DirEntry.is_dir() expects no arguments.", span);
                    }

                    return (await GetCachedStatAsync(context, span).ConfigureAwait(false)).IsDir;
                }),
                "stat" => BoundCallable.Create((arguments, span, context) =>
                {
                    if (arguments.Length != 0)
                    {
                        throw new LythonRuntimeException("TypeError", "DirEntry.stat() expects no arguments.", span);
                    }

                    return GetCachedStat(context, span);
                },
                DirEntryStatSignature, async (arguments, span, context) =>
                {
                    if (arguments.Length != 0)
                    {
                        throw new LythonRuntimeException("TypeError", "DirEntry.stat() expects no arguments.", span);
                    }

                    return await GetCachedStatAsync(context, span).ConfigureAwait(false);
                }),
                "inode" => BoundCallable.Create((arguments, span, _) =>
                {
                    if (arguments.Length != 0)
                    {
                        throw new LythonRuntimeException("TypeError", "DirEntry.inode() expects no arguments.", span);
                    }

                    throw new LythonRuntimeException("NotImplementedError", "DirEntry.inode() is not supported because Lython's host path model does not expose inode metadata.", span);
                }, DirEntryInodeSignature),
                "is_symlink" => BoundCallable.Create((arguments, span, _) =>
                {
                    if (arguments.Length != 0)
                    {
                        throw new LythonRuntimeException("TypeError", "DirEntry.is_symlink() expects no arguments.", span);
                    }

                    throw new LythonRuntimeException("NotImplementedError", "DirEntry.is_symlink() is not supported because Lython's host path model does not expose symlinks.", span);
                }, DirEntryIsSymlinkSignature),
                _ => MissingMemberValue.Instance,
            };

            return !ReferenceEquals(value, MissingMemberValue.Instance);
        }
        public PyString RenderPython(PyRenderingContext context)
        {
            _ = context;
            return PyString.FromString($"<DirEntry '{_name}'>");
        }

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);

        private LythonPathStat GetCachedStat(ExecutionContext context, LythonSourceSpan span)
            => _stat ??= HostStat(_path, context, span);

        private async ValueTask<LythonPathStat> GetCachedStatAsync(ExecutionContext context, LythonSourceSpan span)
            => _stat ??= await HostStatAsync(_path, context, span).ConfigureAwait(false);
    }

    private sealed class PyWalkIterator : PyIteratorBase
    {
        private readonly bool _topdown;
        private readonly ICallable? _onerror;
        private readonly ExecutionContext _context;
        private readonly MemoryGovernor _governor;
        private readonly LythonSourceSpan? _span;
        private readonly Stack<WalkFrame> _frames = [];

        public PyWalkIterator(string root, bool topdown, ICallable? onerror, ExecutionContext context, LythonSourceSpan? span)
        {
            PyIteratorBase.ChargeIteratorValue(context.MemoryGovernor, span);
            _topdown = topdown;
            _onerror = onerror;
            _context = context;
            _governor = context.MemoryGovernor;
            _span = span;
            _frames.Push(new WalkFrame(root));
        }

        public override bool TryMoveNext([MaybeNullWhen(false)] out object value)
        {
            while (_frames.Count != 0)
            {
                var frame = _frames.Peek();
                if (!frame.Scanned)
                {
                    if (!TryScan(frame))
                    {
                        _frames.Pop();
                        continue;
                    }

                    if (_topdown)
                    {
                        frame.Yielded = true;
                        value = CreateTuple(frame);
                        return true;
                    }
                }

                var childNames = frame.DirectoryNames!;
                while (frame.NextChildIndex < childNames.Count)
                {
                    var childName = WalkFrame.RequireWalkDirName(childNames[frame.NextChildIndex++], _span);
                    var childPath = JoinChild(frame.DirectoryPath, childName);
                    try
                    {
                        _context.CheckExecution(_span);
                        var stat = _context.HostStat(childPath, _span);
                        if (!stat.Exists || !stat.IsDir)
                        {
                            continue;
                        }
                    }
                    catch (InvalidOperationException ex)
                    {
                        HandleWalkError(ex.Message);
                        continue;
                    }

                    _frames.Push(new WalkFrame(childPath));
                    goto ContinueTraversal;
                }

                if (!_topdown && !frame.Yielded)
                {
                    frame.Yielded = true;
                    value = CreateTuple(frame);
                    return true;
                }

                _frames.Pop();

            ContinueTraversal:
                continue;
            }

            value = PyNone.Instance;
            return false;
        }

        public override async ValueTask<PyIterationResult> TryMoveNextAsync()
        {
            while (_frames.Count != 0)
            {
                var frame = _frames.Peek();
                if (!frame.Scanned)
                {
                    if (!await TryScanAsync(frame).ConfigureAwait(false))
                    {
                        _frames.Pop();
                        continue;
                    }

                    if (_topdown)
                    {
                        frame.Yielded = true;
                        return PyIterationResult.Yield(CreateTuple(frame));
                    }
                }

                var childNames = frame.DirectoryNames!;
                while (frame.NextChildIndex < childNames.Count)
                {
                    var childName = WalkFrame.RequireWalkDirName(childNames[frame.NextChildIndex++], _span);
                    var childPath = JoinChild(frame.DirectoryPath, childName);
                    try
                    {
                        _context.CheckExecution(_span);
                        var stat = await _context.HostStatAsync(childPath, _span).ConfigureAwait(false);
                        if (!stat.Exists || !stat.IsDir)
                        {
                            continue;
                        }
                    }
                    catch (InvalidOperationException ex)
                    {
                        await HandleWalkErrorAsync(ex.Message).ConfigureAwait(false);
                        continue;
                    }

                    _frames.Push(new WalkFrame(childPath));
                    goto ContinueTraversal;
                }

                if (!_topdown && !frame.Yielded)
                {
                    frame.Yielded = true;
                    return PyIterationResult.Yield(CreateTuple(frame));
                }

                _frames.Pop();

            ContinueTraversal:
                continue;
            }

            return PyIterationResult.End;
        }

        private bool TryScan(WalkFrame frame)
        {
            try
            {
                _context.CheckExecution(_span);
                var names = _context.HostListDir(frame.DirectoryPath, _span);
                var directories = new List<string>();
                var files = new List<string>();
                foreach (var name in names)
                {
                    var child = JoinChild(frame.DirectoryPath, name);
                    _context.CheckExecution(_span);
                    var stat = _context.HostStat(child, _span);
                    if (!stat.Exists)
                    {
                        continue;
                    }

                    if (stat.IsDir)
                    {
                        directories.Add(name);
                    }
                    else if (stat.IsFile)
                    {
                        files.Add(name);
                    }
                }

                ExecutionSort.Sort(directories, _context, _span, StringComparer.Ordinal.Compare);
                ExecutionSort.Sort(files, _context, _span, StringComparer.Ordinal.Compare);
                frame.SetEntries(CreateStringList(directories), CreateStringList(files));
                return true;
            }
            catch (InvalidOperationException ex)
            {
                HandleWalkError(ex.Message);
                return false;
            }
            catch (HostOperationException ex)
            {
                HandleWalkError(ex.Message);
                return false;
            }
        }

        private async ValueTask<bool> TryScanAsync(WalkFrame frame)
        {
            try
            {
                _context.CheckExecution(_span);
                var names = await _context.HostListDirAsync(frame.DirectoryPath, _span).ConfigureAwait(false);
                var directories = new List<string>();
                var files = new List<string>();
                foreach (var name in names)
                {
                    var child = JoinChild(frame.DirectoryPath, name);
                    _context.CheckExecution(_span);
                    var stat = await _context.HostStatAsync(child, _span).ConfigureAwait(false);
                    if (!stat.Exists)
                    {
                        continue;
                    }

                    if (stat.IsDir)
                    {
                        directories.Add(name);
                    }
                    else if (stat.IsFile)
                    {
                        files.Add(name);
                    }
                }

                ExecutionSort.Sort(directories, _context, _span, StringComparer.Ordinal.Compare);
                ExecutionSort.Sort(files, _context, _span, StringComparer.Ordinal.Compare);
                frame.SetEntries(CreateStringList(directories), CreateStringList(files));
                return true;
            }
            catch (InvalidOperationException ex)
            {
                await HandleWalkErrorAsync(ex.Message).ConfigureAwait(false);
                return false;
            }
            catch (HostOperationException ex)
            {
                await HandleWalkErrorAsync(ex.Message).ConfigureAwait(false);
                return false;
            }
        }

        private PyList CreateStringList(IReadOnlyList<string> items)
        {
            var values = new object[items.Count];
            for (var i = 0; i < items.Count; i++)
            {
                var text = PyString.FromString(items[i], _governor, _span);
                values[i] = text;
            }

            var list = new PyList(values, _governor, _span);
            return list;
        }

        private void HandleWalkError(string message)
        {
            if (_onerror is null)
            {
                return;
            }

            var payload = PyString.FromString(message, _governor, _span);
            var callbackSpan = _span ?? new LythonSourceSpan(0, 0, 0, 0);
            _ = InvokeCallableTarget(
                _onerror,
                callbackSpan,
                callbackSpan,
                _context,
                [CallArgumentValue.Positional(PyException.CreateOwned(PythonExceptionIdentity.FromRuntimeTypeName("RuntimeError"),
                    message, payload, _context, callbackSpan))]);
        }

        private async ValueTask HandleWalkErrorAsync(string message)
        {
            if (_onerror is null)
            {
                return;
            }

            var payload = PyString.FromString(message, _governor, _span);
            var callbackSpan = _span ?? new LythonSourceSpan(0, 0, 0, 0);
            _ = await InvokeCallableTargetAsync(
                _onerror,
                callbackSpan,
                callbackSpan,
                _context,
                () => ValueTask.FromResult(new[] { CallArgumentValue.Positional(PyException.CreateOwned(PythonExceptionIdentity.FromRuntimeTypeName("RuntimeError"),
                    message, payload, _context, callbackSpan)) })).ConfigureAwait(false);
        }

        private object CreateTuple(WalkFrame frame)
        {
            var directory = PyString.FromString(frame.DirectoryPath, _governor, _span);
            var tuple = new PyTuple(
            [
                directory,
                frame.DirectoryNames.RequireNotNull(),
                frame.FileNames.RequireNotNull()
            ],
            _governor,
            _span);
            return tuple;
        }

        public override PyString RenderPython(PyRenderingContext context) => PyString.FromString("<os.walk>");

        private sealed class WalkFrame
        {
            public WalkFrame(string directoryPath)
            {
                DirectoryPath = directoryPath;
            }

            public string DirectoryPath { get; }

            public bool Scanned { get; private set; }

            public bool Yielded { get; set; }

            public int NextChildIndex { get; set; }

            public PyList? DirectoryNames { get; private set; }

            public PyList? FileNames { get; private set; }

            public void SetEntries(PyList directoryNames, PyList fileNames)
            {
                DirectoryNames = directoryNames;
                FileNames = fileNames;
                Scanned = true;
            }

            internal static string RequireWalkDirName(object value, LythonSourceSpan? span)
            {
                if (!PyStringOps.TryAsString(value, out var text))
                {
                    throw new LythonRuntimeException("TypeError", "os.walk(...) expects dirnames to remain a list of strings.", span);
                }

                return text.AsString();
            }
        }
    }
}
