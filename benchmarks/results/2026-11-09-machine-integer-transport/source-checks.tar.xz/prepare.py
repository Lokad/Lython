from pathlib import Path
import hashlib, json, shutil, subprocess

root = Path('D:/code/Lython')
home = Path(__file__).parent
previous = home.parent / 'text-cache-storage-r173/refined'
identity = json.loads((previous / 'identity.json').read_text(encoding='utf-8'))
for name, expected in identity['productionSources'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == expected, name
before = previous / 'images/candidate'
assert hashlib.sha256((before / 'Lokad.Lython.dll').read_bytes()).hexdigest() == identity['cores']['candidate']
shutil.copytree(before, home / 'images/before')
shutil.copyfile(previous / 'catalog.json', home / 'catalog.json')
sources = ['Runtime/LythonRuntime.Evaluation.Operators.cs', 'Runtime/LythonRuntime.OperatorDispatch.cs',
           'Runtime/LythonRuntime.Evaluation.Assignments.cs', 'Runtime/Numbers/PyNumberOps.cs',
           'Runtime/LythonRuntime.Executable.NativeReturn.cs', 'Runtime/LythonRuntime.Executable.NativeCalls.cs',
           'Runtime/LythonRuntime.Executable.Inputs.cs', 'Runtime/LythonRuntime.Executable.PreparedOperations.cs',
           'Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs']
for source in sources:
    target = home / 'before-source' / source
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / 'src/Lokad.Lython' / source, target)
(home / 'baseline.json').write_text(json.dumps(dict(
    revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    production='cac4acf8', imageSource='R173 nonincremental precommit freeze; all current production hashes verified',
    coreSHA256=identity['cores']['candidate'], productionSources=identity['productionSources'],
    hypothesis='Replace boxed BigInteger counter results with already-supported boxed Int64, exact overflow promotion; no tagged slots, cache, pool or ownership policy.',
    allocationLimit='R94 BigInteger sampling is historical, not current exact allocation attribution.',
    semanticChecks=['overflow and large admission', 'bool and host integer ingress', 'integer methods/formatting', 'mixed equality and dictionary hashes', 'aliases and is', 'actual async callbacks', 'cancellation and terminal refusal'],
    comparison='Existing five complete scripts, both APIs, two unchanged baseline roles; allocation established separately from diagnostic desktop elapsed. Quiet confirmation only for a coherent viable final design.'
), indent=2) + '\n', encoding='utf-8')
plan = root / 'PLAN.md'
text = plan.read_text(encoding='utf-8')
old = '1. **Choose and complete a coherent scalar/operand redesign from current costs.**'
new = '''1. **R174 active private prototype: machine-sized integer result transport.**
   Source already accepts CLR integral values as Python int. Hypothesis: use that
   existing representation for counter additions, replacing BigInteger result
   construction/32B boxes with exact signed64 arithmetic/24B boxes. Overflow must
   enter existing BigInteger preflight before magnitude work. Consolidate shared
   integer classification across native eligibility so it cannot silently restore
   frame/binding overhead. No cache, tagged-value layer, pool or new owner policy.
   Initial producer/consumer proof covers addition/accumulation; keep it private
   until whole scripts and all affected consumers qualify. Record any need for a
   wider migration before promoting. Remove displaced exact-add entry branches;
   keep large arithmetic and admission behavior. Existing frozen cac4acf8-equivalent
   baseline/source hashes verified before edits. Five complete scripts/both APIs/
   two unchanged roles; focused numeric/method/alias/refusal/cancellation checks.
   Stop bounded prototype at a concrete semantic/representation obstacle or usable
   source-pair result, refine only with evidence. No CPU prediction from old samples.

   Broader scalar/operand selection remains the objective after this prototype.'''
assert text.count(old) == 1
text = text.replace(old, new).replace('No uncommitted runtime prototype.', 'R174 private machine-integer producer/consumer prototype beginning; no promoted change.')
plan.write_text(text, encoding='utf-8', newline='\n')
print('Current source and baseline verified; private prototype contract recorded before edits.')
