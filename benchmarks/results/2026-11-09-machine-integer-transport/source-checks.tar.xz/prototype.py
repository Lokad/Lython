from pathlib import Path
root = Path('D:/code/Lython')

def change(name, old, new, count=1):
    path = root / 'src/Lokad.Lython' / name
    text = path.read_text(encoding='utf-8')
    assert text.count(old) == count, (name, text.count(old))
    path.write_text(text.replace(old, new), encoding='utf-8', newline='\n')

change('Runtime/Numbers/PyNumberOps.cs', '    public static bool TryAsInteger(object value, out BigInteger integer)', '''    internal static bool TryAsInt64(object value, out long integer)
    {
        switch (value)
        {
            case long number: integer = number; return true;
            case BigInteger number when number.GetByteCount() <= 8: integer = (long)number; return true;
            case bool number: integer = number ? 1 : 0; return true;
            case int number: integer = number; return true;
            case uint number: integer = number; return true;
            case short number: integer = number; return true;
            case ushort number: integer = number; return true;
            case byte number: integer = number; return true;
            case sbyte number: integer = number; return true;
            case ulong number when number <= long.MaxValue: integer = (long)number; return true;
            default: integer = 0; return false;
        }
    }

    public static bool TryAsInteger(object value, out BigInteger integer)''')

change('Runtime/LythonRuntime.Evaluation.Operators.cs',
'''        if (left is BigInteger leftInteger && right is BigInteger rightInteger)
            return AddExactIntegers(leftInteger, rightInteger, context.MemoryGovernor, span);''',
'''        if (TryAddBuiltinIntegers(left, right, context.MemoryGovernor, span, out var integerResult))
            return integerResult;''')
change('Runtime/LythonRuntime.Evaluation.Operators.cs',
'    private static object AddExactIntegers(BigInteger left, BigInteger right, MemoryGovernor? governor, LythonSourceSpan span)',
'''    private static bool TryAddBuiltinIntegers(object left, object right, MemoryGovernor? governor,
        LythonSourceSpan span, out object result)
    {
        result = PyNone.Instance;
        if (!PyNumberOps.IsInteger(left) || !PyNumberOps.IsInteger(right)) return false;
        if (PyNumberOps.TryAsInt64(left, out var lhs) && PyNumberOps.TryAsInt64(right, out var rhs))
        {
            var sum = unchecked(lhs + rhs);
            result = ((lhs ^ sum) & (rhs ^ sum)) >= 0
                ? (object)sum : AddExactIntegers(lhs, rhs, governor, span);
            return true;
        }
        PyNumberOps.TryAsInteger(left, out var leftInteger);
        PyNumberOps.TryAsInteger(right, out var rightInteger);
        result = AddExactIntegers(leftInteger, rightInteger, governor, span);
        return true;
    }

    private static object AddExactIntegers(BigInteger left, BigInteger right, MemoryGovernor? governor, LythonSourceSpan span)''')

change('Runtime/LythonRuntime.OperatorDispatch.cs',
'''        if (op == BinaryOperatorSyntax.Add && left is BigInteger leftInteger && right is BigInteger rightInteger)
            return AddExactIntegers(leftInteger, rightInteger, context.MemoryGovernor, span);''',
'''        if (op == BinaryOperatorSyntax.Add && TryAddBuiltinIntegers(left, right, context.MemoryGovernor, span, out var integerResult))
            return integerResult;''', 2)
change('Runtime/LythonRuntime.Evaluation.Assignments.cs',
'''        if (op == AugmentedAssignmentOperatorSyntax.Add &&
            currentValue is BigInteger leftInteger && right is BigInteger rightInteger)
            return AddExactIntegers(leftInteger, rightInteger, context.MemoryGovernor, span);''',
'''        if (op == AugmentedAssignmentOperatorSyntax.Add &&
            TryAddBuiltinIntegers(currentValue, right, context.MemoryGovernor, span, out var integerResult))
            return integerResult;''')

change('Runtime/LythonRuntime.Executable.NativeReturn.cs',
'        BigInteger => NativeReturnShape.Integer,',
'        BigInteger or sbyte or byte or short or ushort or int or uint or long or ulong => NativeReturnShape.Integer,')
change('Runtime/LythonRuntime.Executable.NativeCalls.cs',
'using System.Numerics;', 'using System.Numerics;\nusing Lokad.Lython.Runtime.Numbers;')
change('Runtime/LythonRuntime.Executable.NativeCalls.cs', 'value is BigInteger or PyString ||', 'value is PyString || PyNumberOps.IsInteger(value) ||')
change('Runtime/LythonRuntime.Executable.NativeCalls.cs', 'value is BigInteger or double or bool ||', 'value is double || PyNumberOps.IsInteger(value) ||')
change('Runtime/LythonRuntime.Executable.Inputs.cs', 'using System.Numerics;', 'using System.Numerics;\nusing Lokad.Lython.Runtime.Numbers;')
change('Runtime/LythonRuntime.Executable.Inputs.cs',
'first is BigInteger or double or bool && second is BigInteger or double or bool ||',
'(first is double || PyNumberOps.IsInteger(first)) && (second is double || PyNumberOps.IsInteger(second)) ||')
change('Runtime/LythonRuntime.Executable.Inputs.cs', 'ExecutableOpCode.Unary => first is BigInteger or double or bool,',
'ExecutableOpCode.Unary => first is double || PyNumberOps.IsInteger(first),')
change('Runtime/LythonRuntime.Executable.Inputs.cs', 'ExecutableOpCode.Subscript => second is BigInteger &&',
'ExecutableOpCode.Subscript => PyNumberOps.IsInteger(second) &&')
change('Runtime/LythonRuntime.Executable.PreparedOperations.cs', 'using System.Numerics;', 'using System.Numerics;\nusing Lokad.Lython.Runtime.Numbers;')
change('Runtime/LythonRuntime.Executable.PreparedOperations.cs',
'value is PyNone or BigInteger or double or bool or PyString or PyBytes;',
'value is PyNone or double or PyString or PyBytes || PyNumberOps.IsInteger(value);')
change('Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs', 'using System.Numerics;', 'using System.Numerics;\nusing Lokad.Lython.Runtime.Numbers;')
change('Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs',
'if (invocation is null && condition is not (PyNone or bool or BigInteger or double or PyString or PyBytes or PyList or PyTuple or PyDict or PySet or PyRange))',
'if (invocation is null && condition is not (PyNone or double or PyString or PyBytes or PyList or PyTuple or PyDict or PySet or PyRange) && !PyNumberOps.IsInteger(condition))')
plan = root / 'PLAN.md'
text = plan.read_text(encoding='utf-8').replace('   Initial producer/consumer proof covers addition/accumulation;',
'''   Compatibility obstacle found before promotion: LythonRunOptions documents
   BigInteger outputs from guest arithmetic, while ingress integral CLR types round
   trip. Raw Int64 outputs cannot ship unchanged. Keep a private prototype only to
   establish whether a contract-preserving wider representation migration merits
   its cost; preserve all failing public-contract cases, no relaxed assertions.
   Initial producer/consumer proof covers addition/accumulation;''')
plan.write_text(text, encoding='utf-8', newline='\n')
print('Private addition/consumer prototype applied; known public projection obstacle remains, no tests relaxed.')
