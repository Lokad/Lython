from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile

root = Path('D:/code/Lython')
home = Path(__file__).parent
refined = home / 'refined'
identity = json.loads((refined / 'identity.json').read_text(encoding='utf-8'))
for name, expected in identity['productionSources'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == expected, name
changed = list((home / 'before-source').rglob('*.cs'))
for before in changed:
    relative = before.relative_to(home / 'before-source')
    current = root / 'src/Lokad.Lython' / relative
    target = refined / 'source' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(current.read_bytes())
    current.write_bytes(before.read_bytes())  # fresh timestamps, never restore metadata
baseline = json.loads((home / 'baseline.json').read_text(encoding='utf-8'))
for name, expected in baseline['productionSources'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == expected, name
test = root / 'tests/Lokad.Lython.PublicApi.Tests/NumericIngressContractTests.cs'
shutil.copyfile(test, home / 'NumericIngressContractTests.cs')
prototype_test_dll = root / 'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0/Lokad.Lython.PublicApi.Tests.dll'
prototype_test_sha = hashlib.sha256(prototype_test_dll.read_bytes()).hexdigest()
shutil.copyfile(prototype_test_dll, home / 'prototype-public-tests.dll')

env = os.environ.copy()
env['DOTNET_ROOT'] = 'C:/Users/JoannesVermorel/.dotnet11'
env['PATH'] = env['DOTNET_ROOT'] + os.pathsep + env['PATH']
dotnet = env['DOTNET_ROOT'] + '/dotnet.exe'
checks = {}
for framework in ['net11.0', 'net10.0']:
    for label, args in [
        ('restore-build-'+framework, ['build', 'src/Lokad.Lython', '-c', 'Release', '-f', framework, '--no-restore', '--no-incremental']),
        ('retained-contract-'+framework, ['test', 'tests/Lokad.Lython.PublicApi.Tests', '-c', 'Release', '-f', framework, '--no-restore', '--filter', 'FullyQualifiedName~NumericIngressContractTests'])]:
        with (home / (label+'.log')).open('w', encoding='utf-8') as out:
            done = subprocess.run([dotnet, *args], env=env, stdout=out, stderr=subprocess.STDOUT)
        output = (home / (label+'.log')).read_text(encoding='utf-8')
        print(label, done.returncode, output[-350:], flush=True)
        assert done.returncode == 0, label
        checks[label] = dict(exitCode=0, tail=output[-500:])
checks.update(prototypeNumericPublicPassed=136, prototypeAdditionAdmissionPassed=42,
              prototypePublicProjectionFailed=2, testsRelaxed=0,
              finalTestSourceSHA256=hashlib.sha256(test.read_bytes()).hexdigest(),
              prototypeTestAssemblySHA256=prototype_test_sha,
              restoredTestAssemblySHA256=hashlib.sha256(prototype_test_dll.read_bytes()).hexdigest(),
              productionRestoredExactly=True, sourceRestoreUsedFreshTimestamps=True,
              limitations='No promoted runtime change. Full platforms/Stress/packages not repeated for discarded private prototypes. New tests check the existing documented public projection contract, not a storage architecture.')
(home / 'qualification.json').write_text(json.dumps(checks, indent=2)+'\n', encoding='utf-8')
target = root / 'benchmarks/results/2026-11-09-machine-integer-transport'
target.mkdir()
for src, dest in [(home/'desktop.json','original-desktop.json'), (refined/'desktop.json','refined-desktop.json'),
                  (home/'identity.json','original-identity.json'), (refined/'identity.json','refined-identity.json'),
                  (home/'qualification.json','qualification.json'), (home/'baseline.json','baseline.json')]:
    shutil.copyfile(src, target / dest)
with tarfile.open(target / 'source-checks.tar.xz', 'w:xz') as archive:
    for folder in [home, refined]:
        for item in sorted(folder.iterdir()):
            if item.is_file() and item.suffix in ['.py','.json','.log','.cs','.patch']:
                archive.add(item, arcname=item.relative_to(home).as_posix())
    for folder in [home/'before-source', home/'initial-source', refined/'source']:
        for item in sorted(folder.rglob('*.cs')):
            archive.add(item, arcname=item.relative_to(home).as_posix())
    for folder in [home/'warm-sync',home/'warm-async',refined/'warm-sync',refined/'warm-async']:
        for item in sorted(folder.iterdir()):
            archive.add(item, arcname=item.relative_to(home).as_posix())
    for item in [home/'images/candidate/Lokad.Lython.dll', refined/'images/candidate/Lokad.Lython.dll',home/'prototype-public-tests.dll']:
        archive.add(item, arcname=item.relative_to(home).as_posix())
(target/'README.md').write_text('''# Machine-sized integer transport — R174

2026-11-09. Private producer/consumer prototype after qualified cac4acf8, source
c0c543c8. Both nonincremental-original and source/refined identities are explicit;
all production files matched the R173 freeze before editing. Existing five complete
scripts, sync/async, two identical original roles, unchanged whole-job driver and
auxiliaries. Not a CPython comparison or CPU qualification.

The prototype emits existing CLR Int64 values from fitting exact additions, checks
signed overflow and enters existing BigInteger preflight/promotion. Shared native
eligibility recognizes CLR integer types; no cache, pool, tagged slots, ledger,
budget policy, weakened cancellation or unsafe code. It eliminates eight bytes per
fitting result box, not integer objects or their identity. Conservative storage
charges stay unchanged. Initial classification redundantly traversed integer kinds;
one justified source refinement narrows the changed producer to BigInteger/Int64.
All other ingress widths/bools retain their established numeric funnel.

Both variants pass full stdout/file goldens, isolation, funding/cleanup and owned
fixture gates. Original/refined allocation: text about−6.91%, CSV−1.48..1.49%,
report−0.77..0.79%, Unicode-index control−3.78..3.79%. Config near-zero differences
include one moving allocation control. Warm includes mediated I/O/output validation/
prior-result cleanup; startup/reset/protocol/final caches excluded. Compilation
not separately measured because this is not a promotable representation.

Original sync text+3.19..8.04%, async CSV+8.03..9.09%, async config+27.79..30.86%
are preserved. Refined sync text−0.59..+0.34%, async text−3.78..+0.19% overlap
controls; async CSV+3.60..4.25%, report sync+1.25..7.01%/async+2.61..2.82% remain
adverse. These short shared-process/JIT/GC observations establish uncertainty,
not CPU gain/equivalence or a permanent design veto. No quiet VM campaign.

More decisively, LythonRunOptions documents BigInteger results from guest arithmetic,
while unchanged host integral values retain their own CLR type. Raw Int64 results
violate that public contract. Two new externally observable projection regressions
fail the prototype with actual long/expected BigInteger;136existing numeric/protocol/
ownership cases and42addition admission/rollback cases pass.NET11. Passing Python
outputs alone would miss this boundary. Keep the tests unchanged.

**Decision: remove both prototypes completely; do not change public projection to
make them pass.** Allocation savings are real, but a contract-preserving wider
integer representation is a separate migration, not justified solely by these
mixed CPU observations. No blanket rejection of future scalar redesign. All nine
production files restored exactly with fresh timestamps, forced nonincremental
builds, retained NumericIngress contract checks pass actual.NET11/.NET10. Full
platform/Stress/package checks of unchanged production are not repeated. The two
new tests remain as public contract coverage. Continue ordinary call/operand
transport, which can remove VM work without changing Python or CLR value types.

[Original](original-desktop.json), [refined](refined-desktop.json),
[identities](original-identity.json), [refined identity](refined-identity.json),
[baseline](baseline.json), [checks](qualification.json),
[exact sources/cores/tests/raw/adverse logs](source-checks.tar.xz).
''', encoding='utf-8', newline='\n')
experiments = root / 'benchmarks/EXPERIMENTS.md'
text = experiments.read_text(encoding='utf-8')
marker = 'Combined delivery42684724223/source6d852edc'
assert text.count(marker) == 1
text = text.replace(marker, '''The [R174 private integer transport prototype](results/2026-11-09-machine-integer-transport/README.md)
demonstrates about6.91% less complete-text allocation, but violates the existing
BigInteger projection contract. Original and refined timings remain mixed/adverse;
no CPU claim.136numeric/protocol and42admission cases pass; two added public
projection cases fail the prototype and pass restored production on actual11/10.
Both runtime variants removed completely; exact evidence retained. This does not
close the performance objective or permanently veto a wider scalar design.

''' + marker)
experiments.write_text(text, encoding='utf-8', newline='\n')
plan = root / 'PLAN.md'
text = plan.read_text(encoding='utf-8')
start = text.index('1. **R174')
end = text.index('\n2. **Call/frame', start)
text = text[:start] + '''1. **R175 next: ordinary call inputs through existing compiler facts.**
   Hypothesis: current ForwardValues removes adjacent local/constant loads for
   operators, but Call still executes each leaf as an instruction then copies it
   into packet slots. Reuse that same preparation pass/facts; remove these dispatches
   while keeping existing admitted packet storage for callbacks/suspension.
   No new call engine, frame arena, value representation, budget or public option.
   Source assessment next: actual call shapes, cold unbound-read spans, stack
   capacity and constructor reentry. NativeBody proof uses its own operand domain;
   do not overwrite it with physical source facts. Original argument reads must
   occur once in order after target lookup, before binding, with precise errors.
   Populate retained packet once; resume/promotion must never reread changed locals
   or restart effects. Preserve managed stack/cancellation/first refusal/aliases.
   Define code removed and remaining metadata before prototyping; compare complete
   text/CSV/report/config, both APIs, unchanged controls, compilation separate.
   Bounded semantic/source proof then one usable source pair; refine with evidence.
   Finish/discard the migration and decide regression debt, not another permanent
   fast-path layer. No claimed speedup from inclusive VM samples.

   R174 complete, not promoted: about6.91% text allocation saving, mixed/adverse
   CPU diagnostics, two public BigInteger projection regressions. Both nine-file
   runtime prototypes removed exactly.136numeric/protocol/42admission passed,
   retained public contract checks pass actual11/10 after forced rebuild. Evidence
   in benchmarks/results/2026-11-09-machine-integer-transport/. Wider value-type
   migration remains possible only with projection/identity/consumer integration.
''' + text[end:]
text = text.replace('R174 private machine-integer producer/consumer prototype beginning; no promoted change.',
                    'R174 removed after measured allocation/public-contract assessment; R175 source phase next. No uncommitted runtime prototype.')
plan.write_text(text, encoding='utf-8', newline='\n')
print('R174 closed: exact production restore, retained public regressions green, evidence published; R175 source phase next.', flush=True)
