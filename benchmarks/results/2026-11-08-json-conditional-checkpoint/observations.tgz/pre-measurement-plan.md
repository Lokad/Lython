# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
An isolated experiment does not complete this objective. Current contracts belong
in docs; historical designs/adverse observations remain in
[EXPERIMENTS](benchmarks/EXPERIMENTS.md) and immutable linked results.

## Delivery status

- **Fully qualified:** shared compiler-fact correction, direct UTF-8 formatting/
  storage, original native helper returns and retained R62–R105 changes. Latest
  qualified runtime a7bd4103/coreaae80cc7, cached CI42488128858: Windows/Ubuntu
  actual .NET11/.NET10, original Stress and installed core consumers. Do not repeat.
- **R106 committed/pushed7265538c, full qualification active:** core1aa68ce9; four-file
  native return-tree proof removes single-block eligibility and unselected return
  spans. Reuses unchanged list factory through cold helper, no duplicate admission.
  205public/42internal Release peractual11/10 pass. B465 six jobs168.190s; all gates,
  raw archive/local verification pass; no users/fixtures. Guarded whole-script
  elapsed−13–17% both APIs, coarse CPU supports gain; warm allocation neutral.
  Initial67e/B464 CSV+3% did not recur (final−0.12to−1.92%, CPUflat/lower); cause
  unresolved, original source/data retained. CSVcompile+0.56to+1.48%, CPUmixed.
  Compiler allocation+0.08–0.53%; Windows compiler timing uncertain, all adverse
  originals/changed-order confirmation retained. No universal compiler gain.
- **Distinct measurement claims:** original native-return allocation−19.92/−19.31%,
  elapsed diagnostic. Formatting allocation−8.67%, controlled B102 elapsed/CPU−5–8%;
  original adverse15.125ms remains unexplained/preserved. R99 lower/upper split
  allocation−16.46/−11.88%, lower elapsed−14–17%sync/about−13%async, upper−8–12%sync.
  R105 JSON constructor/call transport eager allocation−27–28%/elapsed−9–12%,
  streamed allocation−24%/elapsed−6–7%; config coarseCPU+4–6% possible debt remains.
- **Primary external baseline:** R103/15c06863/core1674a06c versus CPython3.13.16,
  28jobs581.936s, separate compile/warm/compile-to-result. Exact revision, machine,
  mediated I/O, validation and cleanup boundaries in [BENCHMARKS](docs/BENCHMARKS.md).
  These tables describe15c, not HEAD. Startup/RSS/pending-I/O/embedding tail unmeasured.
- **Selection gates closed:** R100/R101/R104/R107 source already has executable
  imports, shared immutable builtins/signatures/lexical facts, direct argument
  projection/native workstate/final slots, unboxed64-bit sum, cheap small-counter
  admission and UInt128 integer parsing. No speculative lazy factory/value tags/
  per-object wrapper or I/O-host rewrite. Config552-sample profile: setup groups
  small/overlapping, host/kernel substantial; no setup dominance established.
- **Independent regex:** exact dev55/d6067925 development checks86internal/514public
  peractual11/10; supplied package hashes unchanged13:33UTC. Optional0.4 pin unchanged.
  Only affected final released-adapter qualification pending; core work independent.

Historical R76float/R79CSV/R95text/R96report/R102eager JSON and other source-pair
debts remain explicit. A newer favorable pair does not repay unrelated old debt.
Original bulk CSV6–8% evidence/control regression preserved; current shared keys,
array adoption and batch fields already remove its proposed copying phase.
Slower call-arena/control/wide-carrier designs remain rejected with their lessons.

## Prioritized deliverables

1. **R106 coherent delivery.** Refined source and initial/final evidence committed
   and pushed7265538c. One full Windows/Ubuntu actual11/10/original Stress/installed
   core qualification dispatched; pending independently. a7's cached green does not qualify1aa.
   Continue independent work while CI runs; record exact source/status without
   replaying unchanged qualification. No publication.

2. **R108 source/profile gate closed; R109 combined retained checkpoint next.**
   Current report1110guest samples/5.58CPU seconds/64unknown5.77%; formatting/JSON/
   dictionaries material, context0.72%leaf, call/frame3.96%leaf despite84%inclusive.
   Groups overlap; no packaging-dominance claim. Direct record prefix filling,
   completed parser loops, UTF8 windows and final-buffer formatting already exist.
   R26/c4729's native formatted-evaluator deletion fixes admission reentry changing
   later globals: preserve it, no upfront proof/cache/second engine revival.
   No speculative prototype selected; classifier corrected offline with originals
   retained, all gates/archive/local verification pass, no users/RAM. B466 cached.
   Refresh the maintained28-job CPython checkpoint at committed726/core1aa, grouping
   retained JSON-construction and guarded-return milestones. Same workers/catalog/
   protocol/settings; compilation/warm/compile-to-result boundaries unchanged.
   Preserve15c guide and adverse cases.620sowner+30stop+30margin. Fresh disk preflight
   with exact-byte maintenance only if needed; no deletion or new measurement suite.
   Qualification runs independently, not another completed-source CI replay.

3. **Substantial implementation roadmap, selected by that evidence.** Assess full
   call/frame construction and operand transport as complete boundaries, not another
   argument-array special case. For per-record collections investigate remaining
   enumeration/admission/final storage; do not revive already-removed CSV copying.
   For text/JSON remove an actual conversion/construction phase, preserving Unicode,
   hooks and suspendable callbacks. Frontend work must identify repeated facts in
   compile-to-result scripts before adding passes/caches/JIT. A selected milestone
   names displaced code for deletion, semantic tests, explicit completion and debt
   decision, then one bounded controlled before/after with unchanged controls.
   Temporary setbacks are acceptable within that declared coherent milestone.

4. **Combined CPython checkpoint after retained work.** Reuse maintained catalogs/
   worker/protocol; no per-edit external campaign. Refresh representative scripts
   at a combined retained boundary, separate compilation/warm/compile-to-result,
   exact source/core/reference/machine/date and included I/O/validation/cleanup.
   Keep inconclusive/adverse rows and all named-source historical guides. Do not
   imply startup, heap, embedding tails or pending-I/O latency were measured.

5. **Independent regex contract and implementation.** Continue Python-owned native
   UTF-8, byte ranges/scalar positions/original windows, flags/captures/replacements/
   errors, ownership/current cancellation and one frontend/runtime/import provider.
   Core has no backend edge; optional adapter nonpackable. Development producers
   and adapter-local bridges are valid. Exact dev55 gaps: DetailedData lacks a
   separate preparation/working owner; native names lack enumeration; cursor creation
   retains a token despite per-move tokens. Existing bridges remain justified.
   Qualify contract forwarding/unwind, semantics and actual backend performance
   separately. New released capabilities defer only affected final qualification;
   no sibling edits/builds or unchanged replay. Publication remains postponed.

## Acceptance and operating policy

Bounded confirmation, refinement and measurement correction are allowed. Timeout,
unstable unchanged controls and inconclusive data establish uncertainty, not failed
design. Size runs for usable quiet-VM observations, preserve adverse results and
original failed conditions. Percentages inform decisions rather than veto useful
simplification. Distinguish architecture, allocation, demonstrated CPU and latency.
Each retained redesign closes its deletion milestone and decides remaining debt.

AGENTS.md governs managed safety/stack admission, host mediation, cooperative tokens
and shared coarse admission/preflights/replacement overlap. No unsafe/Unsafe/native
probing, independent caps/fuel/quotas, heap tracing/weak reclamation/forced GC, silent
regex fallback or abandoned work. Retained aliases/results/cache/pending users stay
funded until awaited cleanup; first refusal is terminal, no admission retries.
Initial long streaming uses bounded host executions.

Focused Release semantics/cancellation/ownership iteration; no overlapping local
builds/tests/measurements. Force fresh builds after timestamp-preserving restores.
Batch Windows/Ubuntu actual11/10/original Stress/installed core consumers at delivery.
Explicit UTF-8. Only core Release pack into artifacts/nuget; no publication/tagging.
VM lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. Persistent evidence separate
from owned RAM: join, copy/verify maps, unmount, archive under lease, verify locally.
No evidence deletion. Core hardlinks require fresh exact-byte/inode proof.

B450–B465 terminal/cached/archived/locally verified, no active VM users/fixtures.
All recorded terminal CI runs are cached, including42484943603/15c and42488128858/a7;
never query again. R106 full delivery dispatched once at7265538c; observe per request file. CI observations>=5min,
no duplicate dispatch. Prior detailed active plans are retained in private history.
