from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
root = lab.parents[3]
quiet = lab/'comparison/quiet'
out = root/'benchmarks/results/2026-11-24-shared-match-bindings'
hash_path = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
identity = read(quiet/'identity.json')
assert identity['sourcePatchSHA256'] == hash_path(lab/'candidate.patch')
for role, files in identity['imageFiles'].items():
    assert {path.name: hash_path(path) for path in (lab/role).iterdir()} == files
for name in ('compile-allocation-summary.json', 'allocation-summary.json'):
    shutil.copyfile(lab/name, out/name)
shutil.copyfile(quiet/'identity.json', out/'identity.json')
logs = [f'{system}-{lane}.log' for system in ('windows', 'ubuntu') for lane in ('white', 'public', 'net10')]
assert all('Passed!' in (lab/name).read_text(encoding='utf-8-sig') for name in logs)
files = ['candidate.patch', 'prepare.py', 'prepare.log', 'adapt-collection.py', 'quiet.py', 'archive.py',
         'allocations.py', 'compile-allocation.py', 'package-evidence.py', 'reference-build.log',
         'reference-compiler-owner.json', 'candidate-compiler-owner.json', 'reference-allocation.json',
         'candidate-allocation.json', 'comparison/reference-verify.json', 'comparison/candidate-verify.json',
         'comparison/quiet/storage-custody.json', 'comparison/quiet/launch.log'] + logs
with tarfile.open(out/'procedures.tar.xz', 'w:xz') as bundle:
    for name in files:
        bundle.add(lab/name, arcname=name)
with tarfile.open(out/'procedures.tar.xz') as bundle:
    for name in files:
        assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest() == hash_path(lab/name)
