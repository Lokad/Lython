from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name('shared-function-definition-descriptor-20261124')
earlier = lab.with_name('shared-comprehension-facts-20261124')
quiet = lab / 'comparison/quiet'
quiet.mkdir(parents=True, exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
digest = lambda value: hashlib.sha256(value.encode('utf-8')).hexdigest()
def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')

base = read(donor/'comparison/quiet/identity.json')
old_image = base['imageFiles']['candidate']
assert len(old_image) == 32 and {path.name: sha(path) for path in (donor/'candidate').iterdir()} == old_image
core = 'Lokad.Lython.dll'
builds = {role: lab/f'{role}-windows/bin/Lokad.Lython/release_net11.0'/core for role in ('reference', 'candidate')}
images = {role: old_image | {core: sha(path)} for role, path in builds.items()}
assert images['reference'][core] != images['candidate'][core]
for role, files in images.items():
    image = lab/role
    image.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(builds[role] if name == core else donor/'candidate'/name, image/name)
    assert {path.name: sha(path) for path in image.iterdir()} == files

target = 'diagnostic.generated-record-classifier'
sparse = 'scripts.config-generated-guards.medium.bad-0.sparse-lexical'
manifest = 'scripts.config-manifest.small'
catalog = read(earlier/'comparison/quiet/representative.json')
controls = {item['id']: item for item in catalog['cases'] if item['id'] in (sparse, manifest)}
cases = []
for index in range(48):
    cases += [f"        case {{'kind': {index}, 'row': ([0, x, y] | [1, y, x]), 'rest': [head, *tail]}} if tail:",
              f"            return {index}, x + y + head + len(tail)"]
source = 'def classify(record):\n    match record:\n'+'\n'.join(cases)+'''\n        case {'kind': kind}: return kind, -1
        case _: return -1, 0

records = []
for kind in (0, 19, 47, 48):
    for sign in (0, 1, 2):
        records.append({'kind': kind, 'row': [sign, 5, 9], 'rest': [3, 8]})
records.append({})
records.append({'kind': 19, 'row': [0, 4, 6], 'rest': [3]})
print([classify(record) for record in records])
'''
python = Path('C:/Python313/python.exe')
golden = subprocess.run([python, '-I', '-S', '-X', 'utf8', '-'], input=source, encoding='utf-8',
                        capture_output=True, timeout=15, check=True)
assert not golden.stderr and golden.stdout.startswith('[(0, 18), (0, 18), (0, -1)'), golden.stdout
fixture = json.dumps({'size': 48, 'text': None}, separators=(',', ':'))
row = dict(id=target, family='scripts', category='whole-script', scale='small', size=48, source=source,
           fixtureJson=fixture, expectedOutput=golden.stdout, sourceUtf8Bytes=len(source.encode('utf-8')),
           expectedOutputUtf8Bytes=len(golden.stdout.encode('utf-8')), fixtureTextUtf8Bytes=0,
           fixtureTextCodePoints=0, sourceSha256=digest(source), fixtureSha256=digest(fixture),
           expectedOutputSha256=digest(golden.stdout))
catalog['cases'] = [row, controls[sparse], controls[manifest]]
catalog['fixtureEncoding'] = 'Existing sparse and manifest fixtures, no external files for the classifier.'
expected = quiet/'representative.json'
save(expected, catalog)
save(quiet/'jobs.json', {'warm': [[target, 'compile'], [sparse, 'compile'],
                                  [manifest, 'compile-run'], [target, 'compile-run']]})
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert head.startswith('83b45a413')
patch = lab/'candidate.patch'
patch.write_bytes(subprocess.check_output(['git', 'diff', '--binary', '--', 'src', 'tests', 'docs'], cwd=repo))
assert b'OrderedDictionary<string, string>? PreparedBindings' in patch.read_bytes()
identity = dict(sourceRevision=head, comparisonRevision=head, sourcePatchSHA256=sha(patch),
                purpose='Reuse validated structural-pattern captures in scope, flow and lowering', imageFiles=images,
                expectedCPythonSHA256=base['expectedCPythonSHA256'], cpythonWorkerSHA256=base['cpythonWorkerSHA256'],
                coreSHA256={role+suffix: files[core] for role, files in images.items() for suffix in ('', '-control')},
                catalogs={name: {'sha256': sha(quiet/name)} for name in ('representative.json', 'jobs.json')})
save(quiet/'identity.json', identity)
collector = (donor/'comparison/quiet/collect.py').read_text(encoding='utf-8')
collector = collector.replace('len(jobs) == 6', 'len(jobs) == 4').replace('b1647-fixtures', 'b1648-fixtures')
compile(collector, 'collect.py', 'exec')
(quiet/'collect.py').write_text(collector, encoding='utf-8', newline='\n')
shutil.copyfile(donor/'comparison/quiet/run.sh', quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
worker = repo/'benchmarks/cpython-worker.py'
assert sha(worker) == identity['cpythonWorkerSHA256']
for role in images:
    output = lab/'comparison'/f'{role}-verify.json'
    subprocess.run([dotnet, lab/role/'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog', expected,
                    '--dotnet', dotnet, '--python', python, '--python-worker', worker, '--out', output],
                   env=env, cwd=repo, check=True, timeout=60)
    checked = read(output)
    assert checked['state'] == 'Completed' and checked['caseCount'] == 3
    assert checked['catalogSha256'] == sha(expected) and checked['launched']['library']['sha256'] == images[role][core]

payload = quiet/'payload.tar.gz'
with tarfile.open(payload, 'w:gz', compresslevel=3) as package:
    for name in ('identity.json', 'jobs.json', 'representative.json', 'collect.py', 'run.sh'):
        package.add(quiet/name, arcname=name)
    for role, path in builds.items():
        package.add(path, arcname=f'{role}-core.dll')
save(quiet/'upload.json', dict(root='shared-match-bindings-b1648-20261124',
    reference='shared-function-definition-descriptor-b1647-20261124',
    payloadSHA256=sha(payload), payloadBytes=payload.stat().st_size))
