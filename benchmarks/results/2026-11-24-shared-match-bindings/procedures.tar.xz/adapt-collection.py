from pathlib import Path

lab = Path(__file__).resolve().parent
donor = lab.with_name('shared-function-definition-descriptor-20261124')
quiet = (donor/'quiet.py').read_text(encoding='utf-8')
quiet = quiet.replace('b1647', 'b1648').replace('shared-function-definition-descriptor', 'shared-match-bindings')
quiet = quiet.replace('a8edbf7d71eb5e7b3536469dde376f927415170b3b76ebc1de9ad619d2a3060e',
                      '5b21ecaea0e6899b270a05b769b19717a9ba2e598cfbeb108dd88c6f5a1a9345')
quiet = quiet.replace("'run.sh','collect.py','candidate-core.dll'", "'run.sh','collect.py','candidate-core.dll','reference-core.dll'")
quiet = quiet.replace("if name=='Lokad.Lython.dll' and role=='candidate':", "if name=='Lokad.Lython.dll':")
quiet = quiet.replace('RuntimeMaxSec=292', 'RuntimeMaxSec=228').replace('seconds=208', 'seconds=154')
quiet = quiet.replace("# Six bounded lanes write under 1 MiB of receipts.", "# Four bounded lanes write under 1 MiB of receipts.")
quiet = quiet.replace('needs one core, receipts and working room', 'needs two cores, receipts and working room')
assert "'reference-core.dll'" in quiet and "and role=='candidate'" not in quiet
archive = (donor/'archive.py').read_text(encoding='utf-8')
archive = archive.replace('2026-11-24-shared-function-definition-descriptor', '2026-11-24-shared-match-bindings')
archive = archive.replace('receipt["warmJobs"]==6', 'receipt["warmJobs"]==4').replace('timedBatches=168,lanes=6', 'timedBatches=112,lanes=4')
for name, source in (('quiet.py', quiet), ('archive.py', archive)):
    compile(source, name, 'exec')
    (lab/name).write_text(source, encoding='utf-8', newline='\n')
(lab/'verified-raw-replicas.json').write_text('[]\n', encoding='utf-8', newline='\n')
