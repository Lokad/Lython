from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
base=lab.parent
template=base/'closed-line-helper-cpython-20261124'
path=lab/'external'
path.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,o:write(p,json.dumps(o,indent=2)+'\n')
role=sys.argv[1]
assert role=='candidate'
full=read(lab/'comparison/identity.json')
assert full['candidate']==sha(lab/'candidate.patch')
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
change=subprocess.check_output(['git','diff','--binary',full['sourceRevision'], revision,'--','src','tests'],cwd=repo)
assert hashlib.sha256(change).hexdigest()==full['candidate']
files=full['imageFiles'][role]
assert len(files)==32 and {p.name:sha(p) for p in (lab/role).iterdir()}==files
catalog=read(lab/'catalog.json')
manifest='scripts.config-manifest.small'
sparse='scripts.config-generated-guards.medium.bad-0.sparse-lexical'
catalog['cases']=[c for c in catalog['cases'] if c['id'] in (manifest,sparse)]
save(path/'representative.json',catalog)
save(path/'jobs.json',[(manifest,'warm'),(manifest,'compile'),(sparse,'compile'),(manifest,'compile-run'),(sparse,'compile-run')])
location='abstract-compiler-cpython-b1614-20261124'
identity=dict(sourceRevision=revision,candidate=revision,productionSource=revision,imageFiles={'candidate':files},
    frozenImage='/home/lokad/lython-bench-checks/'+location+'/candidate',
    auxiliaryFiles={n:h for n,h in files.items() if n!='Lokad.Lython.dll'},
    coreSHA256={label:files['Lokad.Lython.dll'] for label in ('candidate','candidate-control')},
    expectedCPythonSHA256=full['expectedCPythonSHA256'],cpythonWorkerSHA256=full['cpythonWorkerSHA256'],
    catalogs={name:{'sha256':sha(path/name)} for name in ('representative.json','jobs.json')})
save(path/'identity.json',identity)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
worker=repo/'benchmarks/cpython-worker.py'
assert sha(worker)==full['cpythonWorkerSHA256']
subprocess.run([dotnet,lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',path/'representative.json',
    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',worker,'--out',path/'candidate-verify.json'],
    env=env,cwd=repo,check=True,timeout=65)
proof=read(path/'candidate-verify.json')
assert proof['caseCount']==2 and proof['state']=='Completed' and proof['launched']['library']['sha256']==files['Lokad.Lython.dll']
assert proof['catalogSha256']==sha(path/'representative.json')
shutil.copyfile(template/'external/run.sh',path/'run.sh')
assert b'\r' not in (path/'run.sh').read_bytes()
for name in ('collect.py','summarize.py'):
    value=(template/'external'/name).read_text(encoding='utf-8')
    value=value.replace('b1609-','b1614-').replace('len(jobs) == 4','len(jobs) == 5').replace('started<231','started<277')
    value=value.replace('len(raw["jobs"])==4 and receipt["warmJobs"]==4','len(raw["jobs"])==5 and receipt["warmJobs"]==5')
    value=value.replace('CPython checkpoint for the delivered short report and defaulted rules','CPython checkpoint for shared parser and collection analysis code')
    compile(value,name,'exec')
    write(path/name,value)
launcher=(template/'external.py').read_text(encoding='utf-8')
launcher=launcher.replace("quiet = lab.parent / 'closed-line-helper-20261124/comparison/quiet'", "quiet = lab / 'comparison/quiet'")
launcher=launcher.replace('lython-b1609-closed-line-helper-cpython-','lython-b1614-abstract-compiler-cpython-')
launcher=launcher.replace('closed-line-helper-cpython-b1609-20261124',location).replace('closed-line-helper-b1608-20261124','abstract-collection-graphs-b1613-20261124')
launcher=launcher.replace('RuntimeMaxSec=280','RuntimeMaxSec=335').replace('seconds=237','seconds=282')
launcher=launcher.replace('staged+3840*1024','staged+1400*1024').replace('3584*1024','1400*1024')
launcher=launcher.replace('assert shutil.disk_usage(base).free>=minimum','assert shutil.disk_usage(base).free>=minimum,(shutil.disk_usage(base).free,minimum)')
compile(launcher,'external.py','exec')
write(lab/'external.py',launcher)
print('Prepared five CPython checkpoint lanes and both unchanged goldens.')
