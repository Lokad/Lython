from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).resolve().parent
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
probe=lab/'probe-candidate'
probe.mkdir(exist_ok=True)
for path in (lab.parent/'callable-singleton-defaults-isolated-20261124/probe-candidate').iterdir():
    shutil.copyfile(lab/'candidate'/path.name if path.name=='Lokad.Lython.dll' else path,probe/path.name)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((lab/'identity.json').read_text(encoding='utf-8'))
assert sha(probe/'Lokad.Lython.dll')==identity['imageFiles']['candidate']['Lokad.Lython.dll']
snippets=[
    'def int(value): return "word"\nresult = int(1)\nprint(len(result))\n',
    'def len(value): return "word"\nresult = len("python")\nprint(result.upper())\n',
    'def len(value): return 23\nprint(len(1))\n',
    'def open(value): return [value]\nprint(open("name")[0])\n',
    'def bool(value): return [value]\nprint(len(bool(9)))\n',
    'def run(int):\n result = int(1)\n print(len(result))\nrun(lambda x: "ok")\n',
    'def maker(): return lambda value: "word"\nint = maker()\nprint(len(int(1)))\n',
    'from operator import index as str\nprint(str(7) + 1)\n',
]
(lab/'shadow-input.json').write_text(json.dumps(snippets,indent=2)+'\n',encoding='utf-8')
for mode in ('sync','async'):
    run=subprocess.run([sdk/'dotnet.exe',probe/'LythonProbe.dll','--batch-json','--compare-python','--python','C:/Python313/python.exe',*(['--async'] if mode=='async' else [])],
                       input=json.dumps(snippets),capture_output=True,text=True,encoding='utf-8',env=env,timeout=60)
    (lab/f'shadow-{mode}.jsonl').write_text(run.stdout,encoding='utf-8',newline='\n')
    results=[json.loads(line) for line in run.stdout.splitlines()]
    assert len(results)==len(snippets) and all(r['CPython']['Success'] for r in results)
    for row in results: print(mode,row['Index'],row['Lython']['Success'],[(d['Code'],d['Message']) for d in row['Lython']['Diagnostics']])
