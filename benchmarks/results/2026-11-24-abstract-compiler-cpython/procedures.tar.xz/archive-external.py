from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
root = lab.parents[3]
external = lab / "external"
out = root / "benchmarks/results/2026-11-24-abstract-compiler-cpython"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

terminal = read(external / "terminal-status.json")
receipt = terminal["receipt"]
assert not terminal["live"] and not terminal["fixtures"] and terminal["exitCode"] == "0"
assert all(receipt[field] for field in (
    "complete", "allWorkersJoined", "guestFixturesRemoved", "quietBeforeAndAfter", "archivedAndVerifiedUnderLease"
))
assert receipt["warmJobs"] == 5
assert digest(external / "observations.tar.xz") == receipt["archiveSHA256"]
identity = read(external / "identity.json")
summary = read(external / "summary.json")
assert identity["productionSource"].startswith("0bf516c79")
assert identity["sourceRevision"] == identity["productionSource"] == summary["source"]
assert summary["timedBatches"] == 140
assert summary["cpythonExecutableSHA256"] == identity["expectedCPythonSHA256"]
jobs = read(external / "jobs.json")
assert [(row["case"], row["lane"]) for row in summary["rows"]] == [tuple(job) for job in jobs]
verification = read(external / "candidate-verify.json")
assert verification["state"] == "Completed"
assert verification["caseCount"] == len({case for case, _ in jobs}) == 2
assert verification["catalogSha256"] == identity["catalogs"]["representative.json"]["sha256"]
assert verification["launched"]["library"]["sha256"] == identity["coreSHA256"]["candidate"]
assert len(identity["imageFiles"]["candidate"]) == 32
assert {path.name: digest(path) for path in (lab / "candidate").iterdir()} == identity["imageFiles"]["candidate"]

for name in ("shadow-sync.jsonl", "shadow-async.jsonl"):
    rows = [json.loads(line) for line in (lab / name).read_text(encoding="utf-8-sig").splitlines()]
    assert len(rows) == 8
    assert all(row["Compared"] and row["CPython"]["Success"] and not row["Lython"]["Success"] for row in rows)

out.mkdir(exist_ok=True)
for item in ("identity.json", "summary.json", "terminal-status.json", "observations.tar.xz"):
    shutil.copyfile(external / item, out / item)
    assert digest(out / item) == digest(external / item)
procedures = (
    "archive-external.py", "prepare-external.py", "external.py", "external/collect.py",
    "external/summarize.py", "external/representative.json", "external/jobs.json",
    "external/run.sh", "external/launch.log", "external/candidate-verify.json",
    "call-shadow-probe.py", "shadow-input.json", "shadow-sync.jsonl", "shadow-async.jsonl",
)
with tarfile.open(out / "procedures.tar.xz", "w:xz") as archive:
    for item in procedures:
        archive.add(lab / item, arcname=item)
with tarfile.open(out / "procedures.tar.xz") as archive:
    assert all(hashlib.sha256(archive.extractfile(item).read()).hexdigest() == digest(lab / item) for item in procedures)
print("Archived B1614 with 140 attested batches, exact image identity and builtin shadowing probes")
