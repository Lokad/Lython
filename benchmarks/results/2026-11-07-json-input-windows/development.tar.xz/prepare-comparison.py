from pathlib import Path
import hashlib,json,os,shutil
r=Path(__file__).parent;home=r.parent
for role in ['before','candidate']:
 target=r/'images'/role
 shutil.copytree(home/'admission-reentry-r53/images/candidate',target,copy_function=os.link)
 (target/'Lokad.Lython.dll').unlink()
 source=r/'net11.0.before.dll'if role=='before'else Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll')
 shutil.copy2(source,target/'Lokad.Lython.dll')
shutil.copy2(home/'module-bindings-r49/catalog.json',r/'catalog.json')
for name in ['measure.py','summarize.py']:shutil.copy2(home/'admission-reentry-r53'/name,r/name)
identity=dict(baseline='d04024ee R53 pending-admission correction; focused both-target gate passed, full CI independent',candidate='R54 immutable JSON input windows; exact source snapshot and core hash recorded before measurement',cores={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*.cs')if not any(x in ['bin','obj']for x in p.parts)},boundary='Unchanged R45 five-case complete-job diagnostic,32warmups,5rotated rounds*4jobs; sync/async separately. NormalGC/tiering, sharedCoreLib/hash seed/process GC, isolatedALCs. Includes reset/mediatedIO/fullgoldens/resultdisposal; no compile/startup/finalcachedteardown. Desktop elapsed diagnostic, no quietCPU claim.')
(r/'comparison-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for p in ['src/Lokad.Lython/Runtime/Text/PyString.cs','src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs']:shutil.copy2(p,r/(Path(p).name+'.prototype'))
print('R54 source/cores frozen for one short complete-script storage gate.')
