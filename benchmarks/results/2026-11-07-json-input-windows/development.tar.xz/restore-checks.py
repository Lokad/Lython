from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path(__file__).parent;n=r/'restored';n.mkdir()
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
original=json.loads((r.parent/'admission-reentry-r53/refined/focused.json').read_text(encoding='utf-8'))['productionSources']
for p,h in original.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
checks={}
for tfm in ['net11.0','net10.0']:
 steps=[('rebuild-'+tfm,['build','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',tfm,'-t:Rebuild','--no-restore'])]
 for project,selection in [
  ('Lokad.Lython.Tests','Category!=Stress&(FullyQualifiedName~Json|FullyQualifiedName~String|FullyQualifiedName~Utf8|FullyQualifiedName~Whitespace|FullyQualifiedName~Ownership)'),
  ('Lokad.Lython.PublicApi.Tests','Category!=Stress&(FullyQualifiedName~Json|FullyQualifiedName~String|FullyQualifiedName~Text|FullyQualifiedName~Utf8|FullyQualifiedName~Formatting|FullyQualifiedName~Memory|FullyQualifiedName~Ownership|FullyQualifiedName~Accounting|FullyQualifiedName~SharedBudget|FullyQualifiedName~Streaming|FullyQualifiedName~Cancellation|FullyQualifiedName~Refusal)')]:
  args=['test',f'tests/{project}/{project}.csproj','-c','Release','-f',tfm,'--no-build'if project=='Lokad.Lython.Tests'else'--no-restore','--filter',selection,'--logger','console;verbosity=minimal']
  steps.append((project+'-'+tfm,args))
 for name,args in steps:
  log=n/(name+'.log');start=time.monotonic()
  with log.open('w',encoding='utf-8')as stream:done=subprocess.run([env['DOTNET_HOST_PATH']]+args,env=env,stdout=stream,stderr=subprocess.STDOUT)
  text=log.read_text(encoding='utf-8');checks[name]=dict(exitCode=done.returncode,arguments=args,elapsedSeconds=time.monotonic()-start,tail=text[-1500:])
  (n/'progress.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8');print(name,text.splitlines()[-1],flush=True);assert done.returncode==0,text[-4000:]
cores={}
for tfm in ['net11.0','net10.0']:
 p=Path(f'src/Lokad.Lython/bin/Release/{tfm}/Lokad.Lython.dll');shutil.copy2(p,n/(tfm+'.dll'));cores[tfm]=hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in original.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
(n/'validation.json').write_text(json.dumps(dict(checks=checks,cores=cores,productionSources=original,qualification='Restored exact R53 production, full CI42393422539 terminalGREEN separately. Forced rebuild before focused restored actual11/10 checks. No R54 production/tests retained.'),indent=2)+'\n',encoding='utf-8');print('Exact source restoration and both actual-target focused validation complete.',flush=True)
