from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;home=r.parent;n=r/'b411';assert not n.exists();n.mkdir()
checks=json.loads((r/'focused.json').read_text(encoding='utf-8'))
for p,h in checks['productionSources'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
old=home/'wildcard-utf8-r51';prior=old/'b409'
catalog=json.loads((prior/'representative.json').read_text(encoding='utf-8'))
ids=['scripts.report-render.large','scripts.csv-summary-functions.large','scripts.text-summary-helpers.large']
catalog['cases']=[next(c for c in catalog['cases']if c['id']==name)for name in ids]
(n/'representative.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
name='json-input-storage-b411-20261107';unit='lython-b411-json-input-storage-20261107'
jobs=[(c,'warm')for c in ids]
s=(prior/'collect.py').read_text(encoding='utf-8').replace('retained-cpython-b409-20261107',name)
a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+"\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n"+s[b:]
s=s.replace("labels=['CPython','candidate','control']","labels=['reference','reference-control','candidate','control']")
s=s.replace("Representative R49/R50/R51 checkpoint: seven complete scripts vs CPython, separate compile/warm/compile-run; two labeled integer warm inputs; two wildcard source-pair warm jobs vs R50","R54 immutable JSON input windows; complete report warm plus unchanged CSV/text controls; R53 baseline, two old/two current processes")
s=s.replace('started < 540','started < 120').replace('Reserve60 seconds','Reserve30 seconds')
(n/'collect.py').write_text(s,encoding='utf-8',newline='\n');compile(s,'collect','exec')
s=(prior/'archive-owned.py').read_text(encoding='utf-8').replace('retained-cpython-b409-20261107',name).replace("len(r['jobs'])==23","len(r['jobs'])==3").replace('jobs=23','jobs=3').replace("'retirement.json','original-failure.json',",'')
(n/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n');compile(s,'archive','exec')
s=(prior/'run.sh').read_text(encoding='utf-8').replace('retained-cpython-b409-20261107',name);(n/'run.sh').write_text(s,encoding='utf-8',newline='\n')
baseline=json.loads((r/'baseline.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision=baseline['head']+' plus R54 prototype',sourceStatus='Uncommitted prototype; final focused actual11/10 pass. R53 delivery independently running. No publication.',coreSHA256={'reference':baseline['cores']['net11.0'],'reference-control':baseline['cores']['net11.0'],'candidate':checks['cores']['net11.0'],'control':checks['cores']['net11.0']},auxiliaryFiles=json.loads((prior/'identity.json').read_text(encoding='utf-8'))['auxiliaryFiles'],productionSources=checks['productionSources'],jobs=jobs,limitations='Report allocation about5% lower, ordinary text/CSV/search about3to4.5% higher due to larger PyString wrapper. JSON-lines under1% lower. Desktop elapsed unstable; original failures/controls preserved. This source pair determines normal-runtime warm CPU/elapsed only; no fresh/async/external-baseline claim.')
(n/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for src,dst in [(r/'net11.0.before.dll','before-core.dll'),(r/'cores/net11.0/Lokad.Lython.dll','current-core.dll'),(r/'focused.json','focused.json')]:shutil.copy2(src,n/dst)
(n/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src','tests']))
contract='R54 bounded confirmation: one report warm target plus unchanged CSV/text controls, existing original scripts/fixtures/goldens and frozen normal0.4 adapter/worker. Two old/two current processes, normalGC/tiering,5s warmup per role/job,7rotated150ms rounds. Keep every adverse allocation/elapsed control. Source simplification/allocation and demonstratedCPU are separate; no fixed percent veto, predicted gain or broad CPython refresh. Managed and ownership/cancellation gates already focused on both actual targets; final delivery independent.150s owner+30s stop+30s margin; observe after210s. Minimum256MiB persistent free; own separate tmpfs mount outside/dev/shm; all goldens/identities/quiet/Closed/exit/join/emptyfixture/unmount/persistent archive-under-lease and local verification required. No restart on timeout or unchanged favorable retiming.'
(n/'contract.md').write_text(contract+'\n',encoding='utf-8',newline='\n')
(n/'setup-contract.json').write_text(json.dumps(dict(jobs=3,ownerSeconds=150,stopSeconds=30,marginSeconds=30,observeAfterSeconds=210),indent=2)+'\n',encoding='utf-8')
shutil.copy2('PLAN.md',n/'pre-measurement-plan.md')
with tarfile.open(n/'payload.tgz','w:gz')as a:
 for p in n.iterdir():
  if p.is_file()and p.name!='payload.tgz':a.add(p,arcname=p.name)
s=(prior/'launch.py').read_text(encoding='utf-8').replace('retained-cpython-b409-20261107',name).replace('lython-b409-retained-cpython-20261107',unit).replace('retained-cpython-b409-launch.py','json-input-storage-b411-launch.py').replace('lython-b409-fixtures','lython-b411-fixtures')
a=s.index(" (root/'reference').symlink_to");b=s.index(" (root/'cpython-worker.py').symlink_to",a)
s=s[:a]+''' for role,core in [('reference','before-core.dll'),('candidate','current-core.dll')]:
  target=root/role;target.mkdir()
  for p in (base/'delivery-comparison-b406-20261107/candidate').iterdir():
   if p.is_file()and p.name!='Lokad.Lython.dll':(target/p.name).symlink_to(p)
  (root/core).rename(target/'Lokad.Lython.dll')
'''+s[b:]
s=s.replace('assert len(jobs)==23 ','assert len(jobs)==3 ').replace("len(r['jobs'])==23","len(r['jobs'])==3").replace('allTwentyThreeJobsValidated','allThreeJobsValidated').replace('ownerSeconds=600','ownerSeconds=150').replace('RuntimeMaxSec=600','RuntimeMaxSec=150').replace('seconds=660','seconds=210')
(n/'launch.py').write_text(s,encoding='utf-8',newline='\n');compile(s,'launch','exec')
s=(prior/'retrieve.py').read_text(encoding='utf-8').replace('retained-cpython-b409-20261107',name).replace('lython-b409-retained-cpython-20261107',unit).replace("['jobs']==23","['jobs']==3")
(n/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
shutil.copy2(home/'module-bindings-r49/b404/summarize.py',n/'summarize.py')
print(json.dumps(dict(payloadBytes=(n/'payload.tgz').stat().st_size,sourcePair=identity['coreSHA256'],jobs=jobs,observeAfterSeconds=210)))
