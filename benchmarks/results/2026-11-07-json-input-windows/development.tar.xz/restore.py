from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent
checks=json.loads((r/'focused.json').read_text(encoding='utf-8'))
for p,h in checks['productionSources'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
snapshot=r/'source-prototype';snapshot.mkdir()
files=['src/Lokad.Lython/Runtime/Text/PyString.cs','src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs','tests/Lokad.Lython.Tests/JsonPropertyNameStorageTests.cs','tests/Lokad.Lython.Tests/JsonStringTokenStorageTests.cs','tests/Lokad.Lython.Tests/JsonInputWindowOwnershipTests.cs']
for p in files:shutil.copy2(p,snapshot/Path(p).name)
(r/'prototype.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src','tests']))
for p in files[:2]:Path(p).write_bytes((r/(Path(p).name+'.before')).read_bytes())
for p in files[2:4]:
 original=subprocess.check_output(['git','show','HEAD:'+p]);Path(p).write_text(original.decode('utf-8'),encoding='utf-8',newline='\n')
Path(files[4]).unlink()
baseline=json.loads((r/'baseline.json').read_text(encoding='utf-8'))
for p,h in baseline['sources'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
assert not subprocess.check_output(['git','diff','--','src','tests'])
decision=dict(retained=False,reason='No established substantial report elapsed/CPU improvement in a controlled warm source pair, with larger wrappers raising all non-JSON control allocations and adding ownership state. This is a coherent cost decision, not a fixed percentage veto or permanent prohibition on shared immutable storage.',sourceSimplification='Prototype replaces zero-based array operations with memory windows but adds storage-charge transfer and a second constructor/factory; it does not remove parsing/scanning. None retained.',allocations='Report -4.978/-5.031% sync/async; JSON-lines -0.952/-0.943%; unchanged search/text/CSV about+3to4.5%. Private precise allocation probe confirms eight extra bytes per wrapper (empty factory80to88 inclarray; abc88to96).',elapsed='B412 report -5.00to+2.14%, baseline spread5.05%/current2.34%, candidateIQR3.96%; CPU roles adverse/coarse. CSV -2.32to+1.01% variable. Text -0.49to+7.80%, current spread6.23%; retain all adverse/uncertain evidence. No CPU gain claim.',originalFailure='B411 fails before sampling because symlinked worker loads83af401e from original directory rather than intended0c126b2e. Ready-only diagnosis proves loaded path/hash, Closed/exit0/no guest request. Original failure archive separately preserved; B412 corrects only auxiliary staging to hardlinks.',validation='Prototype979internal/4778public per actual11/10 pass. Initial8failures preserved; external/unowned buffer independence remains exercised, governing plain output admission matches real wrapper storage. All modified tests and four prototype-specific storage tests are restored/removed along with the discarded design; original governed-input copy/independence assertions remain.',vm='B412 all three jobs/goldens/actual core identities/normal runtime/quiet/Closed/exit/join/emptyfixtures/unmount/persistent archive-under-lease/localverification pass in86.7502s. B411/B412 terminal; never service-query again. No active collection or fixture mount.',restoration='Exact original production source restored. Force nonincremental rebuild before focused restored checks; pending.',wholeScriptObjective='Remains active; no dormant string-view machinery retained.',publication='postponed')
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
print('R54 production/tests restored exactly to HEAD; retained snapshots include original failure and all controls. Nonincremental restoration validation next.',flush=True)
