using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;

var observations = new List<object>();
foreach (var path in args)
{
    var image = new AssemblyLoadContext(Path.GetFileName(path), isCollectible: true);
    var core = image.LoadFromAssemblyPath(Path.GetFullPath(path));
    var type = core.GetType("Lokad.Lython.Runtime.Text.PyString", true)!;
    var create = type.GetMethod("FromString", [typeof(string)])!.CreateDelegate<Func<string, object>>();
    foreach (var input in new[] { "", "abc" })
    {
        for (var i = 0; i < 1024; i++) GC.KeepAlive(create(input));
        var start = GC.GetAllocatedBytesForCurrentThread();
        for (var i = 0; i < 10000; i++) GC.KeepAlive(create(input));
        observations.Add(new { path, input, bytesPerCall = (GC.GetAllocatedBytesForCurrentThread() - start) / 10000.0 });
    }
    image.Unload();
}
Console.WriteLine(JsonSerializer.Serialize(observations));
