from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-07-json-input-windows')
checks=json.loads((r/'restored/validation.json').read_text(encoding='utf-8'))
for p,h in checks['productionSources'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
decision=json.loads((r/'decision.json').read_text(encoding='utf-8'));decision['restoration']='Exact original R53 production/tests restored. Nonincremental rebuild and975internal/4778public focused checks per actual.NET11/.NET10 pass. Full retained-runtime CI42393422539 cachedGREEN separately, excluding withdrawn R54.'
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
for name in ['baseline.json','focused.json','local-summary.json']:shutil.copy2(r/name,out/name)
shutil.copy2(r/'restored/validation.json',out/'restored-validation.json')
for sub,names in [('b411',['failed-observations.tgz','failure-receipt.json','ready-diagnosis.json']),('b412',['observations.tgz','archive-receipt.json','comparison-summary.json','terminal-status.json'])]:
 (out/sub).mkdir(exist_ok=True)
 for name in names:shutil.copy2(r/sub/name,out/sub/name)
archive=out/'development.tar.xz'
with tarfile.open(archive,'w:xz')as a:
 for p in sorted(r.rglob('*')):
  relative=p.relative_to(r)
  if p.is_file()and relative.parts[0]!='images'and'obj'not in relative.parts and'retrieved'not in relative.parts and'failed-retrieved'not in relative.parts and p.name not in ['payload.tgz','observations.tgz','failed-observations.tgz']:a.add(p,arcname=str(relative).replace('\\','/'))
decision['archiveSHA256']=hashlib.sha256(archive.read_bytes()).hexdigest()
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(archiveBytes=archive.stat().st_size,archiveSHA256=decision['archiveSHA256'],restoredProductionSources=len(checks['productionSources']))),flush=True)
