from pathlib import Path
import fcntl,importlib.util,json,os,subprocess,tempfile
base=Path('/home/lokad/lython-bench-checks');root=base/'json-input-storage-b411-20261107'
with (base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 spec=importlib.util.spec_from_file_location('protocol',root/'cpython-worker.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
 env=os.environ.copy();dotnet='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet';env['DOTNET_ROOT']=str(Path(dotnet).parent)
 with tempfile.TemporaryDirectory(prefix='lython-ready-diagnosis-')as folder:
  with subprocess.Popen([dotnet,str(root/'reference/Lokad.Lython.Benchmarks.dll'),'--compare','worker','--catalog',str(root/'representative.json')],cwd=folder,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)as p:
   ready=protocol.read_frame(p.stdout)
   protocol.write_frame(p.stdin,dict(protocolVersion=2,requestId=1,operation='quit'))
   closed=protocol.read_frame(p.stdout);assert closed['status']=='Closed'
   code=p.wait(timeout=10);errors=p.stderr.read();assert code==0 and not errors
   assert not list(Path(folder).iterdir())
  print(json.dumps(dict(ready=ready,closed=closed,exitCode=code,fixtureRemoved=True,expected=json.loads((root/'identity.json').read_text())['coreSHA256']['reference'],scope='Ready/Closed only, no guest invocation or measurement. Diagnose frozen failed staging.')))
