from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'json-input-storage-b411-20261107'
reference=base/'delivery-comparison-b406-20261107/reference'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(3814146+1)
 assert len(payload)==3814146 and hashlib.sha256(payload).hexdigest()=='d8a4174957f153e0b400d1c6df5c0a44013615856ea449d394569410be332e8d'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+256*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 for role,core in [('reference','before-core.dll'),('candidate','current-core.dll')]:
  target=root/role;target.mkdir()
  for p in (base/'delivery-comparison-b406-20261107/candidate').iterdir():
   if p.is_file()and p.name!='Lokad.Lython.dll':(target/p.name).symlink_to(p)
  (root/core).rename(target/'Lokad.Lython.dll')
 (root/'cpython-worker.py').symlink_to(base/'prepared-call-layout-b384-20261107/cpython-worker.py')
 owned_ram=root/'guest-fixtures';assert not owned_ram.exists();owned_ram.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b411-fixtures',str(owned_ram)],check=True)
 identity=json.loads((root/'identity.json').read_text())
 for role in ['candidate','reference']:
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
  for name,digest in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 assert 'assert len(jobs)==3 ' in (root/'collect.py').read_text()
 assert "len(r['jobs'])==3" in (root/'archive-owned.py').read_text()
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndEveryAuxiliaryVerifiedInBothRoles=True,
  allThreeJobsValidated=True,ownerSeconds=150,stopSeconds=30,marginSeconds=30)
 assert setup['freeBytes']>256*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b411-json-input-storage-20261107','--property=User=lokad',
 '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30',
 '--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
