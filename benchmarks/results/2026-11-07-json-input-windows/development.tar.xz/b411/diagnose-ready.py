from pathlib import Path
import json,subprocess
r=Path(__file__).parent
remote=r'''from pathlib import Path
import fcntl,importlib.util,json,os,subprocess,tempfile
base=Path('/home/lokad/lython-bench-checks');root=base/'json-input-storage-b411-20261107'
with (base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 spec=importlib.util.spec_from_file_location('protocol',root/'cpython-worker.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
 env=os.environ.copy();dotnet='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet';env['DOTNET_ROOT']=str(Path(dotnet).parent)
 with tempfile.TemporaryDirectory(prefix='lython-ready-diagnosis-')as folder:
  with subprocess.Popen([dotnet,str(root/'reference/Lokad.Lython.Benchmarks.dll'),'--compare','worker','--catalog',str(root/'representative.json')],cwd=folder,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)as p:
   ready=protocol.read_frame(p.stdout)
   protocol.write_frame(p.stdin,dict(protocolVersion=2,requestId=1,operation='quit'))
   closed=protocol.read_frame(p.stdout);assert closed['status']=='Closed'
   code=p.wait(timeout=10);errors=p.stderr.read();assert code==0 and not errors
   assert not list(Path(folder).iterdir())
  print(json.dumps(dict(ready=ready,closed=closed,exitCode=code,fixtureRemoved=True,expected=json.loads((root/'identity.json').read_text())['coreSHA256']['reference'],scope='Ready/Closed only, no guest invocation or measurement. Diagnose frozen failed staging.')))
'''
(r/'diagnose-ready-command.py').write_text(remote,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=remote,text=True,encoding='utf-8',capture_output=True);assert done.returncode==0,done.stderr
data=json.loads(done.stdout);(r/'ready-diagnosis.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(expected=data['expected'],loaded=[v for v in data['ready']['libraries']if Path(v['path']).name=='Lokad.Lython.dll'],closed=data['closed']['status'],exitCode=data['exitCode'])))
