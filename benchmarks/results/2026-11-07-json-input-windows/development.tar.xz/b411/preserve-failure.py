from pathlib import Path
import hashlib,json,shlex,subprocess,tarfile
r=Path(__file__).parent
assert json.loads((r/'terminal-status.json').read_text(encoding='utf-8'))['exitCode']=='1'
remote=r'''from pathlib import Path
import fcntl,hashlib,json,os,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/json-input-storage-b411-20261107')
with (root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 journal=subprocess.check_output(['journalctl','-u','lython-b411-json-input-storage-20261107.service','--no-pager','-n','100'],text=True)
 (root/'failure-journal.txt').write_text(journal)
 fixture=root/'guest-fixtures';names=[str(p.relative_to(fixture))for p in fixture.rglob('*')]if fixture.exists()else[]
 assert not names,names
 if fixture.exists():
  subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 with tarfile.open(root/'failed-observations.tgz','w:gz')as a:
  for p in root.iterdir():
   if p.name not in ['reference','candidate','guest-fixtures','failed-observations.tgz','failure-receipt.json']:a.add(p.resolve(),arcname=p.name)
 with tarfile.open(root/'failed-observations.tgz')as a:assert a.extractfile('failure-journal.txt').read().decode()==journal
 receipt=dict(terminalFailure=True,archiveSHA256=hashlib.sha256((root/'failed-observations.tgz').read_bytes()).hexdigest(),allUsersEnded=True,ownedFixtureUnmountedAndRemoved=True,archivedAndVerifiedUnderMaintenanceLease=True,freeBytes=__import__('shutil').disk_usage(root).free)
 (root/'failure-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(dict(receipt=receipt,journal=journal)))
'''
(r/'preserve-failure-command.py').write_text(remote,encoding='utf-8',newline='\n');compile(remote,'maintenance','exec')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=remote,text=True,encoding='utf-8',capture_output=True)
(r/'failure-maintenance.log').write_text(done.stdout+done.stderr,encoding='utf-8');assert done.returncode==0,done.stderr
data=json.loads(done.stdout);print(data['journal'][-6000:],flush=True)
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['failed-observations.tgz','failure-receipt.json']:
 done=subprocess.run(scp+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/json-input-storage-b411-20261107/'+name,str(r/name)],capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
receipt=json.loads((r/'failure-receipt.json').read_text(encoding='utf-8'));assert hashlib.sha256((r/'failed-observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(r/'failed-observations.tgz')as a:a.extractall(r/'failed-retrieved',filter='data')
print('Original B411 failure archived/verified locally; no live users or fixture mount.',flush=True)
