from pathlib import Path
import fcntl,hashlib,json,os,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/json-input-storage-b411-20261107')
with (root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 journal=subprocess.check_output(['journalctl','-u','lython-b411-json-input-storage-20261107.service','--no-pager','-n','100'],text=True)
 (root/'failure-journal.txt').write_text(journal)
 fixture=root/'guest-fixtures';names=[str(p.relative_to(fixture))for p in fixture.rglob('*')]if fixture.exists()else[]
 assert not names,names
 if fixture.exists():
  subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 with tarfile.open(root/'failed-observations.tgz','w:gz')as a:
  for p in root.iterdir():
   if p.name not in ['reference','candidate','guest-fixtures','failed-observations.tgz','failure-receipt.json']:a.add(p.resolve(),arcname=p.name)
 with tarfile.open(root/'failed-observations.tgz')as a:assert a.extractfile('failure-journal.txt').read().decode()==journal
 receipt=dict(terminalFailure=True,archiveSHA256=hashlib.sha256((root/'failed-observations.tgz').read_bytes()).hexdigest(),allUsersEnded=True,ownedFixtureUnmountedAndRemoved=True,archivedAndVerifiedUnderMaintenanceLease=True,freeBytes=__import__('shutil').disk_usage(root).free)
 (root/'failure-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(dict(receipt=receipt,journal=journal)))
