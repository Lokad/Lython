from pathlib import Path
r=Path(__file__).parent
s=(r/'prepare-vm.py').read_text(encoding='utf-8').replace('b411','b412')
old="(target/p.name).symlink_to(p)"
assert old in s
s=s.replace(old,"__import__('os').link(p.resolve(),target/p.name)")
s=s.replace("contract='R54 bounded confirmation:","contract='B411 fails before sampling: symlinked worker resolves original83af401e core instead of staged reference0c126b2e. Ready-only diagnosis confirms actual original path/core; Closed/exit0, no guest request. Original failed archive verified under maintenance lease/locally, fixture mount removed. B412 corrects auxiliary staging to hardlinks, preserving intended source/core/worker/scripts/normal runtime and all original gates. R54 bounded confirmation:")
exec(compile(s,str(r/'prepare-vm.py'),'exec'),{'__file__':str(r/'prepare-vm.py')})
