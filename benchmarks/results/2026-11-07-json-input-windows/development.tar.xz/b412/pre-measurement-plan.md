# Lokad.Lython 0.11.0

Updated 2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Completing one experiment or qualification does not complete this objective.

## Actual delivery status

| Source | State |
| --- | --- |
| 8c9fd0d7 and earlier retained work | Fully qualified: Windows/Ubuntu Release, actual .NET 11/10, original Stress and installed core consumers. Cached CI42371564043 and earlier receipts; never query again. |
| R49 / 9990d591 | Committed/pushed and fully qualified CI42379372181. Declaration slots retain namespace publication across frames; shared import binding facts. Receipt committed4c739dcb. Initial29failures/correctness fix preserved. |
| R50 / 80833f6e | Committed/pushed and fully qualified CI42382037879 on4c739dcb. Native UInt128 accumulation replaces UInt64; exact promotion, >64bit output admission and cancellation retained. B405 gains/debt recorded below. Never query this terminal run again. |
| R51 / 55e510ff | Committed/pushed and fully qualified CI42383291690: Windows/Ubuntu actual11/10, original Stress and installed consumers. Shared UTF-8 wildcard translation replaces decoded inputs, segment copies, UTF-16/per-class builders and final encoding. B407 gains and adverse JSON debt remain below. Never query this terminal run again. |
| R46 JSON integer sharing | Withdrawn after10.5%/about28.5x allocation regressions; exact source restored/rebuilt. No runtime prototype survives. |
| Current checkpoint | B409 comparison and R52/B410 profile committed/pushed d7df3147. B410 terminal GREEN/archivefae990e8 verified locally. R53 ownership correction committed/pushed d04024ee: final 1,401 internal/1,652 public per actual11/10 pass, short comparison complete; full delivery dispatched16:51:53Z, earliest status16:56:53Z. No active VM collection. |

Completed qualification is evidence, not work to repeat. Historical source-pair
measurements must not be labeled as today's HEAD. Full receipts are beside their
immutable benchmark artifacts under benchmarks/results/.

## Established results and retained uncertainty

- Shared compiler-fact correction removes exponential inferred-value traversal;
  callback correctness is preserved. Fully qualified; no warm CPU claim.
- Native helper returns: allocation−19.92/19.31%, fully qualified. Earlier elapsed
  gains remain diagnostic; no remaining unchanged qualification campaign.
- Direct UTF-8 formatting/storage: allocation−8.67%; controlled B102 elapsed/CPU
  −5–8% supports retention. Original adverse15.125ms remains unexplained/preserved.
- R20/R25 CSV: shared keys/independent values and completed-storage transfer replace
  the old rigidly rejected bulk construction. Allocation−7.31/6.55%, native warm
  −7.72–8.04%; mixed controls remain. No automatic promotion of the old prototype.
- R35/R38 report/frontend and R40/R41 cursor/method work are qualified. Preserve
  report/Unicode/regex gains and original adverse controls; do not requalify them.
- R43 operand transport: smaller executable payload/fewer instructions; CPU gain
  unproved, mixed/adverse controls retained. R44 deletes twelve immediate duplicate
  checks. Wider guard hoisting has no complete cancellation/refusal/error proof.
- R49 B404: search−4.28–5.10%, text−2.10–5.66% (3.26%current spread), JSON
  −5.49–7.67%; extra48–96B admitted root capacity. Desktop30–50%text gains do not
  transfer to the quiet VM. Namespace publication correctness remains essential.
- R50 B405: numeric-string JSON warm−10.68–12.50%, allocation−12.492/12.487%.
  Padded CSV+0.99–1.16% (~0.047ms/job) is accepted debt. No second native rescue
  tier, JSON-parser change, universal CPU claim or arbitrary-large scaling claim.
- R51: complete-script allocation fnmatch−25.029/25.017%, glob−31.797/31.809%
  sync/async, controls within0.01%. Initial async glob+8% and refined unstable
  clocks remain inconclusive. Initial/refined source, cores and CRLF-golden failure
  are preserved. Useful initial capacity replaces repeated tiny growth admissions.
  B407 three-job quiet source pair supports fnmatch−12.33–13.34% and glob
  −15.55–16.92% warm elapsed. Ordinary JSON+4.16–7.43% is accepted unresolved
  control debt, not dismissed because its source is unchanged. No universal CPU
  or async elapsed claim. Archive39f94255 verified under lease and locally.

Narratives, failed conditions, source decisions and raw evidence belong in
benchmarks/EXPERIMENTS.md and benchmarks/results/, not docs/. This plan's preceding
detail is also frozen in the B406 pre-measurement snapshot and private agent notes.

## Immediate deliverable — pending admission ownership R53

Confirmed baseline bug: reentrant admission/scratch callbacks erase the pending
outer charge, permitting shared-budget overcommit while strings remain retained.
Retained correction publishes pending counters before host code, centralizes resize
publication, refunds only unused pending bytes and skips unchanged rollback/no-op
refunds. Before-publication same-governor allocation refuses terminally; independent
executions still share the root. No public signature change, retry, collector,
identity ledger, new owner or capacity policy. Contract/docs updated.

Ten small native cases cover retained aliases, scratch, callback failures/refunds,
first refusal and reuse. Final focused Release: 1,401 internal/1,652 public per
actual11/10 pass. Short complete-script diagnostic: goldens/funding/cleanup pass,
allocation within0.08%, mixed/adverse elapsed. This is a correctness fix, not a CPU
claim. Baseline and refinement failures preserved in
[R53 evidence](benchmarks/results/2026-11-07-admission-publication/README.md).
One full Windows/Ubuntu actual11/10, Stress and installed-consumer delivery is
running for d04024ee. Continue independent source work while it runs; no unchanged
retesting. Update receipt/status when terminal.

The representative CPython refresh is complete, committed d7df3147:
[current guide](docs/BENCHMARKS.md), [frozen checkpoint](benchmarks/results/2026-11-07-retained-checkpoint/README.md).
Source55e510ff remains explicit, not future HEAD. Seven compile/fresh/warm scripts
and two affected integer warm cases; I/O, cleanup, variable controls and unmeasured
startup/RSS/tails are explicit. No further unchanged primary-baseline campaign.
B406/B408 failures, B407 source pairs and storage maintenance remain in
[wildcard evidence](benchmarks/results/2026-11-07-wildcard-translation/README.md).
All B385–B410 terminal/archived/verified locally. No service requery. Preserve the
private133MB offloaded-build archive0f5c835f; production sources/evidence remain.
Future collection: persistent free space≥256MiB, atomic snapshots, owned separate
tmpfs outside /dev/shm; all users exit before unmount/archive verification/lease end.

## Following redesign roadmap

Use the coherent checkpoint's phase costs and existing profiles to choose a
substantial removable stage. Do not accumulate another list of narrow cases.
Each selected milestone must name its hypothesis, affected complete scripts,
eliminated work/storage, displaced code to delete, semantic gates, comparison and
regression-debt decision. A justified redesign can temporarily regress until its
explicit completion milestone.

| Boundary | Concrete next decision / acceptance / stopping condition |
| --- | --- |
| Complete calls and frames | Text/CSV/report helpers are affected. Native module helpers, direct operands/final slots, lazy namespaces, deferred contexts and the linear frame runner already exist; do not claim to remove them again. Current census: text/search/JSON helpers are native; CSV/report bodies are executable and can defer context. Inspect whole argument/binding/frame lifetime for a remaining material packaging phase before implementing. Preserve defaults/keywords/variadics, closures, recursion, evaluation order, exceptions, actual async callbacks and retained borrows. R48 entry leaves25/645samples do not show dominant removable admission; inclusive samples overlap. |
| Frontend consolidation | Use compile and compile-to-result for fresh config/report scripts. Shared lexical/class/parameter facts and R38 demand pruning already exist. Earlier current-compiler profile records LoweredScript20/774 and22/728 inclusive samples (2.6–3.0%); removing the whole intermediate tree is not established as dominant. Select only actual repeated analysis or a redundant retained representation; preserve invalid/dead-scope diagnostics, regex validation/effective flags, imports, annotations/classes/generators. Profile the selected phase before a compiler-wide rewrite. |
| Per-record construction | Shared keys and CSV value transfer exist; synchronous JSON remains separate after R46's CLR-versus-radix lesson. Select only a remaining extra copy/capacity phase, preserving hooks/order/reentry/alias/replacement funding and cancellation. No automatic replay of the old rejected bulk-record implementation. |
| Scalars / remaining text | R42 scalar-add self41samples alone does not justify universal tagged slots. Identify a real dominant conversion/dispatch stage in affected text/report work. Preserve exact promotion, identity, Unicode, hashes, callbacks and owners. R28 packed split storage was slower/variable after refinement and is withdrawn; input sharing cannot refund retained aliases. |
| Operand transport | R43 already removes ordinary transport work. Further changes need materially new evidence; CPU benefit remains unproved. Preserve physical storage/closure/generator ownership. |

The next gate is a bounded source/profile decision on a whole phase, followed by
one coherent prototype and controlled complete-script comparison with unchanged
controls. Do not redesign several boundaries at once. A negative or inconclusive
gate leaves explicit uncertainty; it is not permanent prohibition or completion
of the performance objective. Slower call-arena/call-control designs retain their
lessons and require materially different evidence before reconsideration.

### Selected next gate R52 — complete report execution phase

Use the current-source report gap to distinguish binding/frame work from actual
UTF-8 formatting, JSON construction and dictionary reads. Source confirms native
field formatting already appends directly to the final builder; ordinary calls
already use final slots/deferred contexts/linear frames. Do not propose removing
those completed mechanisms again. One maintained complete report runtime profile
through existing checked worker/perf tooling can attribute the residual cost;
reuse existing text/search profiles as context, not as current exact CPU shares.
No production instrumentation, new benchmark framework or runtime prototype yet.
Preserve all sample stacks/unknowns/inlining limits and all goldens/cancellation/
ownership contracts. Stop after identifying one materially removable phase or
recording why attribution is insufficient. A subsequent redesign must state the
displaced implementation/storage, semantic gates and a bounded source-pair report
comparison with unchanged CSV/text/JSON controls, plus a regression-debt decision.
No fixed saved-CPU percentage, universal tagged values or compiler-wide rewrite
is inferred from this gate. B410 terminal GREEN,927guest samples/4.67CPU seconds,
59unknown leaves, archivefae990e8 verified under lease/locally. No users/fixture
mounts remain; never service-query again. JSON strings66self, formatted handling/
append42self each, Monitor54combined self; binding13, workspace rent3, frame
advance3. Inclusive costs overlap. Existing native JSON/final-buffer formatting
remain; no dominant removable frame-packing phase established. Source follows
funding correctness as R53 above, then select a coherent JSON/text-storage phase
from real removable work rather than relabeling callee cost as call overhead.

### Selected prototype R54 — immutable JSON input storage

Hypothesis: plain JSON strings can keep byte windows over immutable input instead
of allocating/copying one array per token. R52 string reading66self/927 includes
useful scanning, so this predicts eliminated storage/copy, not a CPU percentage.
Affected: JSON-lines, JSON-to-Markdown, config edit/encode; text/CSV/search controls.
Use ReadOnlyMemory<byte> inside existing PyString; remove raw zero-offset array
assumptions, keep normal slices/casing/concatenation semantics. No packed token
table, new owner class, refcounts, ledger or second parser. R28 split packing and
B176 explicit reader costs do not justify replaying those mechanisms.

For input already governed by this execution, transfer its admitted backing charge
to the existing batch lifetime before a view can escape or admission can reenter;
source/token refunds then cover only their wrappers/caches. This is the same coarse
storage-transfer rule as shared record keys, without another reservation/owner.
Unowned/cross-execution inputs and escaped strings keep existing copies. This
avoids repeatedly charging entire documents during raw_decode. Tradeoff: unused
suffix/backing capacity remains charged until execution cleanup, even when a small
view is the survivor. Fund array overhead as well as capacity; never refund backing
when an individual token is discarded. No tracing or arbitrary-withdrawal recovery.

Acceptance: Python Unicode/empty/identity/hash/slice/replace/iteration behavior,
strict/lenient JSON and original scalar error offsets, duplicate/name reuse/hooks,
raw-prefix semantics, actual pending callbacks and retained aliases; cancellation,
terminal refusal before wrapper/publication, replacement peaks and shared-budget
reuse. Measure wrapper size and complete-script allocations, warm/fresh/async
diagnostics with unchanged controls before deciding. Keep all adverse outcomes.
One bounded source-pair follow-up on the quiet VM if the coherent prototype passes
the semantic/storage gate; justified refinement permitted, not favorable retiming.
Complete by retaining with explicit regression debt or restoring/rebuilding source;
no dormant alternative representation. Broader performance objective stays open.

R54 initial focused run8failures: governed raw-buffer mutation assumed decoded
copies and plain admission expected a copied payload. Preserve original logs.
External/unowned buffer independence still tested unchanged in effect; owned
input is immutable. Admission regression now denies all remaining output storage,
covering both real representations rather than the former exact byte threshold.
Final979internal/4,778public per actual11/10 pass. Four storage-transfer controls
retain full backing/header through nested views, source-shell refunds, admission
callbacks/refusal and other-owner cleanup. Short complete-job diagnostic passes
goldens/ownership; report allocation−4.98/5.03%, JSON under−1%, non-JSON controls
+3.0–4.5%. Wrapper size increase is a material cost, not hidden by target savings.
Desktop elapsed remains unstable, async report baseline drift72%; no CPU claim.
B411 bounded source pair running: report/CSV/text warm, two old/two current, normal
GC/tiering, unchanged workers/goldens.150s owner+30stop+30margin; observe only after
17:10:38Z. Persistent363.2MB free at launch, owned separate tmpfs, archive/cleanup
gates. No retiming unless evidence supports a changed source/measurement correction.

## Independent regex track

The core already owns Python/native UTF-8 semantics, byte ranges/scalar positions,
original-subject windows, captures/replacements/errors/cache ownership and current
tokens through actual work. R51 removes remaining wildcard translation conversions.
No Utf8Regex runtime dependency is restored. Optional nonpackable normal adapter0.4.0;
earlier dev48/f6b2175e qualification is historical, not current final certification.

Precise producer gaps: DetailedData lacks a separate Prepare working owner, native
names lack enumeration, cursors combine creation/current token authority. Supplied
producer6032b928/dev51 still requires adapter-local bridges/conservative funding.
Development producers/bridges support contract and semantic tests. Missing released
APIs defer only affected final adapter qualification, never core development or
independent performance work. Qualify immutable released inputs and managed safety
separately. No sibling edits, new memory infrastructure, dialect fallback, quotas
or abandoned background matching. Publication remains postponed.

## Iteration and constraints

Timeouts, unstable controls and inconclusive clocks establish uncertainty. Permit
bounded confirmation, refinement or measurement correction when evidence warrants;
preserve all original failed/adverse conditions. No blanket one-attempt/no-retiming/
permanently-closed rules. Percentages inform decisions, not automatic vetoes.
Distinguish architectural simplification, allocation reduction and demonstrated CPU.
Use existing tools, focused Release semantics/cancellation/ownership checks, then
batch actual11/10 Windows/Ubuntu, original Stress and installed-package checks.
No overlapping local builds/tests/measurements or repeated unchanged qualification.

AGENTS.md governs: fully managed/memory-safe; managed stack/nesting; host-mediated
capabilities; current cooperative cancellation; borrowed allowance, conservative
preflight/replacement overlap, retained aliases, deterministic awaited cleanup.
First refusal terminates the command. No unsafe/Unsafe/PInvoke, tracing/weak
reclamation/forced GC, fuel/quotas/caps or hidden allowance. Initial bounded streams
use host-driven batches; XML depth remains. All text read/write explicitly UTF-8.

VM lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. B385–B408 terminal, archived,
locally verified; never service-query again. Archive/verify RAM evidence under its
lease before removal; persistent evidence lives outside RAM. Record owner/stop/
margin before every new collection. Git-ignored PLAN stays out of commits; docs
describe the current implementation, with immutable historical evidence linked.
