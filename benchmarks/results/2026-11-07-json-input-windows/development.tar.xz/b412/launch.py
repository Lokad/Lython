from pathlib import Path
import datetime,hashlib,json,shlex,subprocess
root=Path(__file__).parent;payload=(root/'payload.tgz').read_bytes()
remote=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'json-input-storage-b412-20261107'
reference=base/'delivery-comparison-b406-20261107/reference'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(SIZE+1)
 assert len(payload)==SIZE and hashlib.sha256(payload).hexdigest()=='DIGEST'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+256*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 for role,core in [('reference','before-core.dll'),('candidate','current-core.dll')]:
  target=root/role;target.mkdir()
  for p in (base/'delivery-comparison-b406-20261107/candidate').iterdir():
   if p.is_file()and p.name!='Lokad.Lython.dll':__import__('os').link(p.resolve(),target/p.name)
  (root/core).rename(target/'Lokad.Lython.dll')
 (root/'cpython-worker.py').symlink_to(base/'prepared-call-layout-b384-20261107/cpython-worker.py')
 owned_ram=root/'guest-fixtures';assert not owned_ram.exists();owned_ram.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b412-fixtures',str(owned_ram)],check=True)
 identity=json.loads((root/'identity.json').read_text())
 for role in ['candidate','reference']:
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
  for name,digest in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 assert 'assert len(jobs)==3 ' in (root/'collect.py').read_text()
 assert "len(r['jobs'])==3" in (root/'archive-owned.py').read_text()
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndEveryAuxiliaryVerifiedInBothRoles=True,
  allThreeJobsValidated=True,ownerSeconds=150,stopSeconds=30,marginSeconds=30)
 assert setup['freeBytes']>256*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b412-json-input-storage-20261107','--property=User=lokad',
 '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30',
 '--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''.replace('SIZE',str(len(payload))).replace('DIGEST',hashlib.sha256(payload).hexdigest())
(root/'launch-command.py').write_text(remote,encoding='utf-8',newline='\n');compile(remote,'launch','exec')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem',
 '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/json-input-storage-b412-launch.py'
code='from pathlib import Path; import sys; p=Path('+repr(stage)+'); assert not p.exists(); p.write_bytes(sys.stdin.buffer.read())'
r=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=remote.encode('utf-8'),capture_output=True);assert r.returncode==0,r.stderr
r=subprocess.run(ssh+['python3 '+stage],input=payload,capture_output=True)
(root/'launch.log').write_bytes(r.stdout+b'\n'+r.stderr);print((r.stdout+r.stderr).decode('utf-8'),flush=True)
if r.returncode:raise SystemExit(r.returncode)
now=datetime.datetime.now(datetime.timezone.utc)
(root/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),
 doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=210)).isoformat(),ownerSeconds=150,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8')
print('Observe after '+(now+datetime.timedelta(seconds=210)).isoformat(),flush=True)
