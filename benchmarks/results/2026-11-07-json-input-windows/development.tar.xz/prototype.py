from pathlib import Path
import shutil
r=Path(__file__).parent
p=Path('src/Lokad.Lython/Runtime/Text/PyString.cs')
s=p.read_text(encoding='utf-8')
def replace(a,b):
 global s
 assert a in s,a
 s=s.replace(a,b)
replace('private readonly byte[] _utf8;\n    private readonly int _byteLength;',
'''private readonly ReadOnlyMemory<byte> _utf8;
    private int _ownedStorageBytes;
    private int _byteLength => _utf8.Length;''')
replace('''        _utf8 = utf8;
        _byteLength = byteLength;
        _memoryGovernor = governor;''','''        _utf8 = utf8.AsMemory(0, byteLength);
        _ownedStorageBytes = checked(32 + utf8.Length);
        _memoryGovernor = governor;''')
replace('private ReadOnlySpan<byte> Utf8Span => _utf8.AsSpan(0, _byteLength);','private ReadOnlySpan<byte> Utf8Span => _utf8.Span;')
replace('public ReadOnlyMemory<byte> Utf8Bytes => _utf8.AsMemory(0, _byteLength);','public ReadOnlyMemory<byte> Utf8Bytes => _utf8;')
replace('internal long CommittedOwnedBytes => EstimateApproximateBytes(_utf8.Length)','internal long CommittedOwnedBytes => 96L + _ownedStorageBytes')
replace('Buffer.BlockCopy(_utf8, 0, result, 0, _byteLength);','Utf8Span.CopyTo(result);')
replace('Buffer.BlockCopy(other._utf8, 0, result, _byteLength, other._byteLength);','other.Utf8Span.CopyTo(result.AsSpan(_byteLength));')
replace('Buffer.BlockCopy(_utf8, 0, result, i * _byteLength, _byteLength);','Utf8Span.CopyTo(result.AsSpan(i * _byteLength));')
replace('Buffer.BlockCopy(_utf8, start, result, offset, length);','Utf8Span.Slice(start, length).CopyTo(result.AsSpan(offset));')
replace('Buffer.BlockCopy(_utf8, start, bytes, 0, length);','Utf8Span.Slice(start, length).CopyTo(bytes);')
replace('Buffer.BlockCopy(_utf8, byteIndex, bytes, 0, runeLength);','Utf8Span.Slice(byteIndex, runeLength).CopyTo(bytes);')
replace('_utf8[start]','Utf8Span[start]')
replace('_utf8[byteIndex]','Utf8Span[byteIndex]')
replace('Utf8.GetString(_utf8, start, length)','Utf8.GetString(Utf8Span.Slice(start, length))')
replace('_utf8.AsSpan(byteIndex, runeLength)','Utf8Span.Slice(byteIndex, runeLength)')
replace('_utf8.AsSpan(offset, found)','Utf8Span.Slice(offset, found)')
needle='    public PyString Concat(PyString other)'
replace(needle,'''    // Immutable views use backing already admitted by this execution. Move its
    // charge to batch lifetime before any callback can refund the source shell.
    // Other owners retain independent copies; no reference tracking is required.
    internal PyString BorrowUtf8Window(int start, int length, MemoryGovernor governor, LythonSourceSpan? span)
    {
        var window = _utf8.Slice(start, length);
        if (length == 0) return Empty;
        if (!ReferenceEquals(_memoryGovernor, governor))
            return CopyFromUtf8(window.Span, governor, span);
        _ownedStorageBytes = 0;
        const long metadata = 96;
        governor.Reserve(metadata, span);
        try
        {
            var result = new PyString(window, governor);
            governor.Commit(metadata);
            return result;
        }
        catch { governor.ReleaseReserved(metadata); throw; }
    }

    private PyString(ReadOnlyMemory<byte> utf8, MemoryGovernor governor)
    {
        _utf8 = utf8;
        _memoryGovernor = governor;
    }

'''+needle)
assert 'Buffer.BlockCopy(_utf8'not in s and '_utf8.AsSpan'not in s
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs');s=p.read_text(encoding='utf-8')
old='var value = existing ?? PyString.CopyFromUtf8(token.Span[1..^1], context.MemoryGovernor, span);'
assert old in s
s=s.replace(old,'var value = existing ?? input.BorrowUtf8Window(position + 1, token.Length - 2, context.MemoryGovernor, span);')
p.write_text(s,encoding='utf-8',newline='\n')
shutil.copy2('PLAN.md',r/'prototype-contract.md')
print('R54 coherent input-window prototype applied; normal source/cross-owner copies unchanged.')
