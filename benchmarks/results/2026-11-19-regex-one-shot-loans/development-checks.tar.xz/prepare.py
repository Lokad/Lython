from pathlib import Path

lab = Path(__file__).resolve().parent
prior = lab.parent / "regex-cursor-loan-r594"
product = lab / "adapter"
product.mkdir(exist_ok=True)
source = (prior / "adapter/Utf8RegexProvider.cs").read_text(encoding="utf-8")
def replace(old, new):
    global source
    assert source.count(old) == 1, old
    source = source.replace(old, new)
def remove(first, after):
    global source
    start = source.index(first)
    end = source.index(after, start)
    source = source[:start] + source[end:]
remove("    private static void Resize(", "    private static PythonReCompileOptions Options(")
replace("EffectiveFlags(pattern.Span, options, cancellationToken), pattern.Length, owner", 
        "EffectiveFlags(pattern.Span, options, cancellationToken), owner")
replace("        internal readonly int PatternBytes;\n", "")
replace("int flags, int bytes,", "int flags,")
replace(" PatternBytes = bytes;", "")
replace("        private readonly ILythonMemoryReservation _storage;\n", "")
replace("        private ReadOnlyMemory<byte> BoundedInput => Input[.._endByte];\n", "")
replace("                _storage = Reserve(_owner, 0);\n", "")
remove("        private void Fund(", "        public bool TryMatch(")
start = source.index("            Fund(MatchBytes);")
end = source.index("        public ILythonRegexCursor Find(", start)
source = source[:start] + """            using var operation = _owner.CreateScope();
            var allowance = new CursorAllowance(Reserve(operation, 256));
            using var cursor = CreateCursor(mode, allowance, cancellationToken);
            return TryAdvance(cursor, captures, out lastIndex, cancellationToken);
        }

        private Utf8PythonMatchCursor CreateCursor(LythonRegexMatchMode mode,
            CursorAllowance allowance, CancellationToken token)
            => Backend(() => Pattern.Regex.CreateMatchCursor(Input, _startByte,
                token, workingMemoryAllowance: allowance, mode: mode switch
                {
                    LythonRegexMatchMode.Match => Utf8PythonMatchMode.Match,
                    LythonRegexMatchMode.FullMatch => Utf8PythonMatchMode.FullMatch,
                    _ => Utf8PythonMatchMode.Search,
                }, endOffsetInBytes: _endByte), token, patternSource: Pattern.Regex);

        private bool TryAdvance(Utf8PythonMatchCursor cursor, Span<LythonRegexCapture?> captures,
            out int? lastIndex, CancellationToken token)
        {
            lastIndex = null;
            try
            {
                if (!cursor.MoveNextRetained(out var funded, token)) return false;
                using (funded)
                {
                    var data = funded.Match;
                    CopyCaptures(data, captures, token);
                    lastIndex = data.LastIndex;
                }
                return true;
            }
            catch (Utf8MemoryAdmissionException error) { throw ProducerAdmission(error); }
            catch (PythonRePatternException error) { throw PatternError(error, token, patternSource: Pattern.Regex); }
            catch (ArgumentException error) { throw new LythonRegexException(LythonRegexFailure.Pattern, error.Message); }
        }

""" + source[end:]
start = source.index("                        _cursor = Backend(() => subject.Pattern.Regex.CreateMatchCursor")
end = source.index("                    }", start)
source = source[:start] + """                        _cursor = subject.CreateCursor(LythonRegexMatchMode.Search, allowance, _cancellation.Token);
""" + source[end:]
start = source.index("                    if (Advance(token, out var funded))")
end = source.index("                    Close(); return false;", start)
source = source[:start] + """                    if (_subject.TryAdvance(_cursor, captures, out lastIndex, token)) return true;
""" + source[end:]
remove("            private bool Advance(", "            private void Close()")
replace("PythonRe 0.4 does not support Python match with pos greater than endpos.", 
        "The PythonRe producer cannot match with pos greater than endpos.")
(product / "Utf8RegexProvider.cs").write_text(source, encoding="utf-8")
(product / "Adapter.csproj").write_text((prior / "adapter/Adapter.csproj").read_text(encoding="utf-8"), encoding="utf-8")
