using System.Buffers;
using System.Text;
using Lokad.Utf8Regex;
using Lokad.Utf8Regex.PythonRe;

namespace Lokad.Lython.Utf8Regex;

/// <summary>Optional PythonRe adapter with borrowed UTF-8 subjects and explicit storage owners.</summary>
public sealed class Utf8RegexProvider : ILythonRegexProvider
{
    /// <summary>Gets a stateless provider instance; patterns and working owners remain caller-local.</summary>
    public static Utf8RegexProvider Instance { get; } = new();

    /// <inheritdoc />
    public ILythonRegexPattern Compile(ReadOnlyMemory<byte> pattern, LythonRegexOptions options,
        ILythonMemoryBudget memoryOwner, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var owner = memoryOwner.CreateScope();
        Utf8PythonRegex? compiled = null;
        try
        {
            // Major retained compiler tables plus construction overlap. Count
            // possible slots before compilation; escaped parentheses may overpay.
            var slots = 1;
            for (var i = 0; i < pattern.Length; i++)
            {
                if ((i & 1023) == 0) cancellationToken.ThrowIfCancellationRequested();
                if (pattern.Span[i] == (byte)'(') slots++;
            }
            Reserve(owner, checked(65536L + 2048L * Math.Max(0, slots - 2) + 256L * Math.Max(0, pattern.Length - 64)));
            var backendOptions = Options(options.Flags);
            backendOptions = options.Verbose ? backendOptions | PythonReCompileOptions.Verbose : backendOptions & ~PythonReCompileOptions.Verbose;
            compiled = Backend(() => Utf8PythonRegex.Compile(pattern.Span, backendOptions,
                new Utf8RegexPolicy { MatchTimeout = Timeout.InfiniteTimeSpan }, cancellationToken), cancellationToken, utf8Pattern: pattern);
            cancellationToken.ThrowIfCancellationRequested();
            var prepared = new Pattern(compiled, EffectiveFlags(pattern.Span, options, cancellationToken), owner, cancellationToken);
            cancellationToken.ThrowIfCancellationRequested();
            compiled = null; // The completed pattern now owns backend cleanup.
            return prepared;
        }
        catch
        {
            try { compiled?.Dispose(); }
            finally { owner.Dispose(); }
            throw;
        }
    }

    // Native UTF-8 producers may decode Pattern on access. Read that text
    // only after an error, without allocating a deferred delegate per match.
    private static T Backend<T>(Func<T> work, CancellationToken token, ReadOnlyMemory<byte> utf8Pattern = default, Utf8PythonRegex? patternSource = null)
    {
        try { return work(); }
        catch (Utf8MemoryAdmissionException error)
        { throw ProducerAdmission(error); }
        catch (PythonRePatternException error)
        { throw PatternError(error, token, utf8Pattern, patternSource); }
        catch (ArgumentException error)
        { throw new LythonRegexException(LythonRegexFailure.Pattern, error.Message); }
    }

    private static LythonRegexException ProducerAdmission(Utf8MemoryAdmissionException error)
        => new(LythonRegexFailure.MemoryAdmission, error.Message,
            requestedBytes: error.RequestedBytes <= long.MaxValue ? (long)error.RequestedBytes : null);

    private static LythonRegexException PatternError(PythonRePatternException error, CancellationToken token,
        ReadOnlyMemory<byte> utf8Pattern = default, Utf8PythonRegex? patternSource = null)
    {
        token.ThrowIfCancellationRequested();
        return new LythonRegexException(LythonRegexFailure.Pattern, error.Message,
            ScalarErrorPosition(error.Position, utf8Pattern, patternSource?.Pattern, token));
    }

    // PythonRe 0.4 reports UTF-16 offsets/-1. Normalize only on failure,
    // borrowing compilation UTF-8 or the backend's existing original string.
    private static int? ScalarErrorPosition(int position, ReadOnlyMemory<byte> utf8Pattern,
        string? utf16Pattern, CancellationToken token)
    {
        if (position < 0) return null;
        var units = 0;
        var scalars = 0;
        for (var offset = 0; units < position;)
        {
            token.ThrowIfCancellationRequested();
            Rune rune;
            int consumed;
            var status = utf16Pattern is null
                ? Rune.DecodeFromUtf8(utf8Pattern.Span[offset..], out rune, out consumed)
                : Rune.DecodeFromUtf16(utf16Pattern.AsSpan(offset), out rune, out consumed);
            if (status != System.Buffers.OperationStatus.Done) return null;
            if (units + rune.Utf16SequenceLength > position) return scalars;
            units += rune.Utf16SequenceLength;
            offset += consumed;
            scalars++;
        }
        return scalars;
    }

    private static ILythonMemoryReservation Reserve(ILythonMemoryBudget owner, long bytes)
    {
        if (!owner.TryReserve(bytes, out var storage))
            throw new LythonRegexException(LythonRegexFailure.MemoryAdmission,
                "Shared memory budget refused regex storage.", requestedBytes: bytes);
        return storage;
    }

    private static PythonReCompileOptions Options(int flags)
    {
        var value = PythonReCompileOptions.None;
        if ((flags & 2) != 0) value |= PythonReCompileOptions.IgnoreCase;
        if ((flags & 8) != 0) value |= PythonReCompileOptions.Multiline;
        if ((flags & 16) != 0) value |= PythonReCompileOptions.DotAll;
        if ((flags & 64) != 0) value |= PythonReCompileOptions.Verbose;
        if ((flags & 256) != 0) value |= PythonReCompileOptions.Ascii;
        return value;
    }

    private static int EffectiveFlags(ReadOnlySpan<byte> pattern, LythonRegexOptions options, CancellationToken token)
    {
        // Reported Python flags can differ from dispatched parsing flags.
        // Read the validated global prefix directly from the original UTF-8.
        var flags = options.Flags;
        var verbose = options.Verbose;
        var offset = 0;
        while (offset < pattern.Length)
        {
            token.ThrowIfCancellationRequested();
            if (verbose && pattern[offset] is (byte)' ' or (byte)'\t' or (byte)'\r' or (byte)'\n' or (byte)'\v' or (byte)'\f') { offset++; continue; }
            if (verbose && pattern[offset] == (byte)'#')
            {
                while (offset < pattern.Length && pattern[offset] != (byte)'\n')
                {
                    token.ThrowIfCancellationRequested();
                    offset += pattern[offset] == (byte)'\\' && offset + 1 < pattern.Length ? 2 : 1;
                }
                continue;
            }
            if (pattern[offset..].StartsWith("(?#"u8))
            {
                offset += 3;
                while (offset < pattern.Length && pattern[offset] != (byte)')')
                {
                    token.ThrowIfCancellationRequested();
                    offset += pattern[offset] == (byte)'\\' && offset + 1 < pattern.Length ? 2 : 1;
                }
                offset++; continue;
            }
            if (!pattern[offset..].StartsWith("(?"u8)) break;
            var end = offset + 2;
            var nextFlags = flags;
            var nextVerbose = verbose;
            while (end < pattern.Length)
            {
                token.ThrowIfCancellationRequested();
                var flag = pattern[end] switch { (byte)'i' => 2, (byte)'m' => 8, (byte)'s' => 16, (byte)'x' => 64, (byte)'a' => 256, (byte)'u' => 32, _ => 0 };
                if (flag == 0) break;
                if (flag == 256) nextFlags &= ~32;
                if (flag == 32) nextFlags &= ~256;
                if (flag == 64) nextVerbose = true;
                nextFlags |= flag; end++;
            }
            if (end == offset + 2 || end == pattern.Length || pattern[end] != (byte)')') break;
            flags = nextFlags;
            verbose = nextVerbose;
            offset = end + 1;
        }
        return flags;
    }

    private sealed class Pattern : ILythonRegexPattern
    {
        private Utf8PythonRegex? _regex;
        internal Utf8PythonRegex Regex => _regex ?? throw new ObjectDisposedException(nameof(Pattern));
        private readonly ILythonMemoryScope _owner;
        public int Flags { get; }
        public int CaptureSlotCount { get; }
        private IReadOnlyList<LythonRegexNamedGroup>? _namedGroups;
        public IReadOnlyList<LythonRegexNamedGroup> NamedGroups => _namedGroups ?? throw new ObjectDisposedException(nameof(Pattern));

        internal Pattern(Utf8PythonRegex regex, int flags, ILythonMemoryScope owner, CancellationToken token)
        {
            _regex = regex; Flags = flags; _owner = owner;
            CaptureSlotCount = checked(regex.CaptureGroupCount + 1);
            var named = new List<LythonRegexNamedGroup>();
            byte[]? scratch = null;
            // Existing coarse pattern admission funds this bounded scratch,
            // retained name bytes/list capacity and construction overlap.
            for (var slot = 1; slot < CaptureSlotCount; slot++)
            {
                token.ThrowIfCancellationRequested();
                scratch ??= new byte[16];
                var status = regex.TryCopyGroupNameUtf8(slot, scratch, out var required, token);
                byte[] name;
                if (status == OperationStatus.Done && required > 0 && required <= scratch.Length)
                {
                    // Unnamed slots have ASCII decimal names. Python named
                    // captures are identifiers, so none can begin with a digit.
                    if (scratch[0] is >= (byte)'0' and <= (byte)'9') continue;
                    name = scratch.AsSpan(0, required).ToArray();
                }
                else if (status == OperationStatus.DestinationTooSmall && required > scratch.Length)
                {
                    // Longer identifiers go straight into their final storage;
                    // the small scratch is a chunk, never a name-size ceiling.
                    name = new byte[required];
                    if (regex.TryCopyGroupNameUtf8(slot, name, out var copied, token) != OperationStatus.Done || copied != required)
                        throw new InvalidOperationException("Regex producer returned inconsistent UTF-8 capture-name metadata.");
                }
                else throw new InvalidOperationException("Regex producer could not supply UTF-8 capture-name metadata.");
                token.ThrowIfCancellationRequested();
                named.Add(new(name, slot));
            }
            _namedGroups = named.AsReadOnly();
        }

        public ILythonRegexSubject Prepare(ReadOnlyMemory<byte> subject, LythonRegexWindow window, ILythonMemoryBudget memoryOwner, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            ObjectDisposedException.ThrowIf(_regex is null, this);
            return new Subject(this, subject, window, memoryOwner, cancellationToken);
        }

        public void Dispose()
        {
            // The caller has drained subjects/cursors and metadata borrows.
            if (Interlocked.Exchange(ref _regex, null) is not { } regex) return;
            try { regex.Dispose(); }
            finally { _namedGroups = null; _owner.Dispose(); }
        }
    }

    private sealed class Subject : ILythonRegexSubject
    {
        internal readonly Pattern Pattern;
        internal readonly ReadOnlyMemory<byte> Input;
        private readonly ILythonMemoryScope _owner;
        private readonly int _startByte, _endByte;
        private readonly LythonRegexWindow _window;
        private bool _disposed;

        internal Subject(Pattern pattern, ReadOnlyMemory<byte> input, LythonRegexWindow window, ILythonMemoryBudget owner, CancellationToken token)
        {
            Pattern = pattern; Input = input; _window = window;
            _startByte = window.StartByte; _endByte = window.EndByte;
            _owner = owner.CreateScope();
            try
            {
                token.ThrowIfCancellationRequested();
                ValidateWindow();
            }
            catch { _owner.Dispose(); throw; }
        }

        private void ValidateWindow()
        {
            if (_window.Pos < 0 || _window.EndPos < 0 ||
                (uint)_startByte > (uint)Input.Length || (uint)_endByte > (uint)Input.Length ||
                _startByte < Input.Length && (Input.Span[_startByte] & 0xc0) == 0x80 ||
                _endByte < Input.Length && (Input.Span[_endByte] & 0xc0) == 0x80)
                throw new ArgumentOutOfRangeException(nameof(_window), "Regex window bounds must be clamped to the original scalar length.");
        }

        public bool TryMatch(LythonRegexMatchMode mode, Span<LythonRegexCapture?> captures, out int? lastIndex,
            CancellationToken cancellationToken)
        {
            lastIndex = null;
            if (captures.Length != Pattern.CaptureSlotCount) throw new ArgumentException("Capture buffer length must equal CaptureSlotCount.", nameof(captures));
            cancellationToken.ThrowIfCancellationRequested();
            ObjectDisposedException.ThrowIf(_disposed, this);
            if (_window.Pos > _window.EndPos)
            {
                if (mode != LythonRegexMatchMode.Match) return false;
                throw new LythonRegexException(LythonRegexFailure.Capability,
                    "The PythonRe producer cannot match with pos greater than endpos.");
            }
            using var operation = _owner.CreateScope();
            var allowance = new CursorAllowance(Reserve(operation, 256));
            using var cursor = CreateCursor(mode, allowance, cancellationToken);
            return TryAdvance(cursor, captures, out lastIndex, cancellationToken);
        }

        private Utf8PythonMatchCursor CreateCursor(LythonRegexMatchMode mode,
            CursorAllowance allowance, CancellationToken token)
            => Backend(() => Pattern.Regex.CreateMatchCursor(Input, _startByte,
                token, workingMemoryAllowance: allowance, mode: mode switch
                {
                    LythonRegexMatchMode.Match => Utf8PythonMatchMode.Match,
                    LythonRegexMatchMode.FullMatch => Utf8PythonMatchMode.FullMatch,
                    _ => Utf8PythonMatchMode.Search,
                }, endOffsetInBytes: _endByte), token, patternSource: Pattern.Regex);

        private bool TryAdvance(Utf8PythonMatchCursor cursor, Span<LythonRegexCapture?> captures,
            out int? lastIndex, CancellationToken token)
        {
            lastIndex = null;
            try
            {
                if (!cursor.MoveNextRetained(out var funded, token)) return false;
                using (funded)
                {
                    var data = funded.Match;
                    CopyCaptures(data, captures, token);
                    lastIndex = data.LastIndex;
                }
                return true;
            }
            catch (Utf8MemoryAdmissionException error) { throw ProducerAdmission(error); }
            catch (PythonRePatternException error) { throw PatternError(error, token, patternSource: Pattern.Regex); }
            catch (ArgumentException error) { throw new LythonRegexException(LythonRegexFailure.Pattern, error.Message); }
        }

        public ILythonRegexCursor Find(CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            ObjectDisposedException.ThrowIf(_disposed, this);
            return new Cursor(this, cancellationToken);
        }

        private static void CopyCaptures(Utf8PythonRangeMatch data, Span<LythonRegexCapture?> captures, CancellationToken token)
        {
            var groups = data.Groups;
            for (var i = 0; i < captures.Length; i++)
            {
                token.ThrowIfCancellationRequested();
                var group = groups[i];
                captures[i] = group.Success ? new(group.StartOffsetInBytes, group.EndOffsetInBytes) : null;
            }
        }

        public void Dispose() { if (!_disposed) { _disposed = true; _owner.Dispose(); } }

        private sealed class CursorAllowance(ILythonMemoryReservation reservation) : IUtf8MemoryAllowance
        {
            private readonly object _gate = new();
            private readonly long _baseBytes = reservation.Bytes;
            private long _producerBytes;

            public bool TryReserve(ulong bytes)
            {
                lock (_gate)
                {
                    if (bytes > (ulong)(long.MaxValue - _baseBytes - _producerBytes)) return false;
                    var next = _producerBytes + (long)bytes;
                    if (next + _baseBytes > reservation.Bytes && !reservation.TryResize(next + _baseBytes))
                        return false;
                    _producerBytes = next;
                    return true;
                }
            }

            public void Release(ulong bytes)
            {
                lock (_gate)
                {
                    _producerBytes -= (long)bytes;
                    // The producer releases the exact amount it received. A host
                    // that declines a shrink leaves conservative funding until close.
                    reservation.TryResize(_baseBytes + _producerBytes);
                }
            }
        }

        private sealed class Cursor : ILythonRegexCursor
        {
            private readonly Subject _subject;
            private readonly ILythonMemoryScope _owner;
            private readonly CancellationTokenSource _cancellation;
            private Utf8PythonMatchCursor? _cursor;
            private bool _disposed;

            internal Cursor(Subject subject, CancellationToken token)
            {
                _subject = subject;
                _owner = subject._owner.CreateScope();
                _cancellation = new CancellationTokenSource();
                try
                {
                    if (subject._window.Pos > subject._window.EndPos) return;
                    // Admit the adapter cursor and its managed wrappers before producer setup.
                    var allowance = new CursorAllowance(Reserve(_owner, 256));
                    using (token.Register(static state => ((CancellationTokenSource)state!).Cancel(), _cancellation))
                    {
                        _cursor = subject.CreateCursor(LythonRegexMatchMode.Search, allowance, _cancellation.Token);
                    }
                    token.ThrowIfCancellationRequested();
                }
                catch (OperationCanceledException) when (token.IsCancellationRequested)
                { Dispose(); throw new OperationCanceledException(token); }
                catch { Dispose(); throw; }
            }

            public bool TryNext(Span<LythonRegexCapture?> captures, out int? lastIndex, CancellationToken token)
            {
                lastIndex = null;
                if (captures.Length != _subject.Pattern.CaptureSlotCount) throw new ArgumentException("Capture buffer length must equal CaptureSlotCount.", nameof(captures));
                token.ThrowIfCancellationRequested();
                ObjectDisposedException.ThrowIf(_disposed, this);
                if (_cursor is null) return false;
                try
                {
                    if (_subject.TryAdvance(_cursor, captures, out lastIndex, token)) return true;
                    Close(); return false;
                }
                catch (OperationCanceledException) when (token.IsCancellationRequested)
                { Close(); throw new OperationCanceledException(token); }
                catch { Close(); throw; }
            }

            private void Close()
            {
                _cursor?.Dispose(); _cursor = null;
                _owner.Dispose();
            }

            public void Dispose()
            {
                if (_disposed) return;
                _disposed = true;
                Close(); _cancellation.Dispose();
            }
        }
    }
}
