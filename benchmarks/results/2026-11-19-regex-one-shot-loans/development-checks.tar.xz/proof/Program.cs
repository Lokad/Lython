using System.Diagnostics.CodeAnalysis;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Utf8Regex;
using Lokad.Utf8Regex;
using Lokad.Utf8Regex.PythonRe;

if (args is [var stage]) return RegexCancellationFixture.Run(stage);

var programBudget = new LythonMemoryBudget();
var working = new ObservedBudget(new LythonMemoryBudget());
var input = "😀x尾"u8.ToArray();
var positive = new List<object>();
using (var pattern = Utf8RegexProvider.Instance.Compile("(?<=(😀))(?P<x>x)"u8.ToArray(), new(32, false), programBudget, default))
using (var subject = pattern.Prepare(input, new(1, 2, 4, 5), working, default))
{
    var captures = new LythonRegexCapture?[pattern.CaptureSlotCount];
    foreach (var mode in new[] { LythonRegexMatchMode.Match, LythonRegexMatchMode.Search, LythonRegexMatchMode.FullMatch })
    {
        Check(subject.TryMatch(mode, captures, out var lastIndex, default) && lastIndex == 2, mode.ToString());
        Check(captures.SequenceEqual(new LythonRegexCapture?[] { new(4, 5), new(0, 4), new(4, 5) }), "absolute ranges");
        Check(working.Current == 0, "working refund after match");
        positive.Add(new { mode = mode.ToString(), lastIndex, captures = captures.ToArray() });
    }
    Check(working.Growths > 0 && working.Shrinks > 0, "producer storage was admitted");
    working.RefuseGrowth = true;
    try
    {
        subject.TryMatch(LythonRegexMatchMode.Match, captures, out _, default);
        throw new InvalidOperationException("producer growth should have been refused");
    }
    catch (LythonRegexException e)
    {
        Check(e.Failure == LythonRegexFailure.MemoryAdmission && e.RequestedBytes == working.RefusedAmount, "first refusal");
    }
    finally { working.RefuseGrowth = false; }
    Check(working.Refusals == 1 && working.Current == 0, "refusal unwind");
    using var canceled = new CancellationTokenSource();
    canceled.Cancel();
    var before = working.Growths;
    try
    {
        subject.TryMatch(LythonRegexMatchMode.Match, captures, out _, canceled.Token);
        throw new InvalidOperationException("cancellation was missed");
    }
    catch (OperationCanceledException stop) { Check(stop.CancellationToken == canceled.Token, "active token"); }
    Check(working.Growths == before && working.Current == 0, "pre-canceling retains no storage");
    Check(subject.TryMatch(LythonRegexMatchMode.Match, captures, out _, default) && working.Current == 0, "owner reuse");
}
Check(programBudget.ReservedBytes == 0, "pattern refund");

var observedRejections = new List<string>();
using (var raw = Utf8PythonRegex.Compile(""u8, PythonReCompileOptions.None,
    new Utf8RegexPolicy { MatchTimeout = Timeout.InfiniteTimeSpan }))
{
    try { using var cursor = raw.CreateMatchCursor(input, 5, mode: Utf8PythonMatchMode.Match, endOffsetInBytes: 4); }
    catch (ArgumentOutOfRangeException e) { observedRejections.Add("cursor:" + e.ParamName); }
    try { _ = raw.Match(input, 5, mode: Utf8PythonMatchMode.Match, endOffsetInBytes: 4); }
    catch (ArgumentOutOfRangeException e) { observedRejections.Add("match:" + e.ParamName); }
}
Check(observedRejections.Count == 2, "record the remaining inverted-window behavior");
Console.WriteLine(JsonSerializer.Serialize(new { positive, observedRejections, working.Growths, working.Shrinks,
    working.Peak, working.Refusals, working.RefusedAmount, working.Current }));
return 0;

static void Check(bool value, string stage)
{
    if (!value) throw new InvalidOperationException(stage);
}

sealed class ObservedBudget(LythonMemoryBudget inner) : ILythonMemoryBudget
{
    public int Growths { get; private set; }
    public int Shrinks { get; private set; }
    public int Refusals { get; private set; }
    public long RefusedAmount { get; private set; }
    public long Current => inner.ReservedBytes;
    public long Peak { get; private set; }
    public bool RefuseGrowth { get; set; }

    public ILythonMemoryScope CreateScope() => new Scope(this, inner.CreateScope());
    public bool TryReserve(long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
        => Reserve(this, inner, bytes, out reservation);

    private static bool Reserve(ObservedBudget budget, ILythonMemoryBudget inner, long bytes,
        [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
    {
        reservation = inner.TryReserve(bytes, out var acquired) ? new Reservation(budget, acquired) : null;
        return reservation is not null;
    }

    private sealed class Scope(ObservedBudget budget, ILythonMemoryScope inner) : ILythonMemoryScope
    {
        public ILythonMemoryScope CreateScope() => new Scope(budget, inner.CreateScope());
        public bool TryReserve(long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
            => Reserve(budget, inner, bytes, out reservation);
        public void Dispose() => inner.Dispose();
    }

    private sealed class Reservation(ObservedBudget budget, ILythonMemoryReservation inner) : ILythonMemoryReservation
    {
        public long Bytes => inner.Bytes;
        public bool TryResize(long bytes)
        {
            var delta = bytes - inner.Bytes;
            if (delta > 0 && budget.RefuseGrowth)
            {
                budget.Refusals++;
                budget.RefusedAmount = delta;
                return false;
            }
            if (!inner.TryResize(bytes)) return false;
            if (delta > 0) budget.Growths++;
            if (delta < 0) budget.Shrinks++;
            budget.Peak = Math.Max(budget.Peak, budget.Current);
            return true;
        }
        public void Dispose() => inner.Dispose();
    }
}