import json
import subprocess
import sys
from pathlib import Path

lab = Path(__file__).resolve().parent
previous = lab.parent / 'prepared-local-destination-r707'
stage = (previous / 'stage-quiet.py').read_text(encoding='utf-8')
stage = stage.replace('prepared-local-destination-b1138', 'parse-annotation-frontiers-b1139')
stage = stage.replace('lython-b1138-prepared-local-destination', 'lython-b1139-parse-annotation-frontiers')
stage = stage.replace('lython-b1138-fixtures', 'lython-b1139-fixtures')
stage = stage.replace('R707 prepared local result destinations', 'R708 annotation bounds during parsing')
stage = stage.replace('Prepared local destination source pair', 'Annotation bounds source pair')
stage = stage.replace('Native integer transport").replace("323","350")',
                      'Annotation bounds source pair").replace("323","350")')
start = stage.index('        jobs = [')
end = stage.index('\n', start)
catalog = json.loads((lab / 'catalog.json').read_text(encoding='utf-8'))
jobs = [(case['id'], 'warm' if case['id'] == 'scripts.csv-invoice.large' else 'compile')
        for case in catalog['cases']]
jobs.append(('scripts.annotated-rule-closures', 'compile-run'))
assert len(jobs) == 6
stage = stage[:start] + '        jobs = ' + repr(jobs) + stage[end:]
proof = (previous / 'prove-quiet-space.py').read_text(encoding='utf-8')
start = proof.index('pairs = ')
end = proof.index('\n', start)
pairs = [('prepared-local-destination-r707/quiet', '2026-11-19-prepared-local-destination', 'candidate', 'measured-core.dll.gz')]
proof = proof[:start] + 'pairs = ' + repr(pairs) + proof[end:]
for name, contents in [('prove-quiet-space.py', proof), ('stage-quiet.py', stage)]:
    (lab / name).write_text(contents, encoding='utf-8', newline='\n')
    subprocess.run([sys.executable, '-X', 'utf8', lab / name], check=True)

