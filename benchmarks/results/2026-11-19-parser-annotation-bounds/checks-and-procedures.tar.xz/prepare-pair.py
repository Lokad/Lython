import ast
import json
import subprocess
import sys
from pathlib import Path

lab = Path(__file__).resolve().parent
previous = lab.parent / 'prepared-local-destination-r707'
load = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
catalog = load(lab.parent / 'one-abstract-fact-map-r672/catalog.json')
ids = ('scripts.annotated-rule-closures', 'scripts.config-generated-guards.medium', 'scripts.config-manifest.small')
catalog['cases'] = [case for case in catalog['cases'] if case['id'] in ids]
invoice, = (case for case in load(previous / 'catalog.json')['cases'] if case['id'] == 'scripts.csv-invoice.large')
helpers = load(lab.parent / 'annotation-frontier-b57/catalog.json')['cases']
helper = next(case for case in helpers if case['id'].startswith('scripts.csv-summary-helpers.'))
tree = ast.parse(helper['source'])
assert any(isinstance(node, ast.AnnAssign) or isinstance(node, ast.FunctionDef) and
    (node.returns is not None or any(arg.annotation is not None for arg in node.args.args)) for node in ast.walk(tree))
catalog['cases'].extend((helper, invoice))
assert len(catalog['cases']) == 5
(lab / 'catalog.json').write_text(json.dumps(catalog, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')

source = (previous / 'freeze-and-verify.py').read_text(encoding='utf-8')
source = source.replace('prepared-local-destination-r707', 'parse-annotation-frontiers-r708')
source = source.replace("origin=lab/role/'bin/Lokad.Lython/release_net11.0'/name", "origin=lab/'windows/bin/Lokad.Lython/release_net11.0'/name")
assert "trial=repo/'.git/agent-worktrees/parse-annotation-frontiers-r708'" in source
assert "origin=lab/'windows/bin/Lokad.Lython/release_net11.0'/name" in source
(lab / 'freeze-and-verify.py').write_text(source, encoding='utf-8', newline='\n')
subprocess.run([sys.executable, '-X', 'utf8', lab / 'freeze-and-verify.py'], check=True)
measurement = lab.parent / 'postfix-statement-r699/measure-compile-allocation.py'
subprocess.run([sys.executable, '-X', 'utf8', measurement, lab], check=True)

