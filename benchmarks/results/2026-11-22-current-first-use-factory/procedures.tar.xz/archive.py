from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=repo/'benchmarks/results/2026-11-22-current-first-use-factory'

def load(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

first,remaining=lab,lab/'remaining-phases'
expected=load(first/'identity.json')
assert expected['sourceRevision'].startswith('e961df912')
source=lab.parent/'numeric-extrema-standalone-20261122/frozen/candidate'
files=expected['imageFiles']['candidate']
assert len(files)==32 and {n:sha(source/n) for n in files}==files
for capture,complete in ((first,False),(remaining,True)):
    receipt=load(capture/'archive-receipt.json')
    terminal=load(capture/'terminal-status.json')
    assert receipt==terminal['receipt'] and terminal['exitCode']==('0' if complete else '1')
    assert receipt['complete']==complete and not terminal['remainingTrace'] and not terminal['remainingWorkers']
    assert sha(capture/'observations.tgz')==receipt['archiveSHA256']
    assert all(receipt[k] for k in ('allWorkersJoined','quietBeforeAndAfter','guestFixturesRemoved',
                                   'archivedAndVerifiedUnderLease','persistentTraceArchivedAndVerifiedBeforeUnmount'))
    assert load(capture/'identity.json')==expected
    verified=load(capture/'verify.json')
    assert verified['state']=='Completed' and verified['caseCount']==2
    assert verified['catalogSha256']==sha(capture/'catalog.json')==expected['catalogSHA256']
assert 'bounded warmup did not finish' in load(first/'terminal-status.json')['journal']
assert not (first/'retrieved/profiles/candidate-mixed-compile/perf.map.gz').exists()
rows=load(lab/'attribution.json')['rows']
assert len(rows)==4
for row,capture in zip(rows,[first,first,remaining,remaining],strict=True):
    record=load(capture/'retrieved/profiles'/row['label']/'record.json')
    assert record['workload']==row['case'] and record['lane']==row['lane']
    assert record['exitCode']==0 and record['closed']['status']=='Closed'
    assert record['verificationBefore']['status']==record['verificationAfter']['status']=='Equivalent'
    assert record['response']['completedInvocations']>0 and record['warmupSeconds']>=8
    expected_output=None if row['lane']=='compile' else record['verificationBefore']['actualOutputSha256']
    assert all(b['status']=='Completed' and b.get('actualOutputSha256')==expected_output for b in record['batches'])
out.mkdir(exist_ok=False)
for name in ('README.md','attribution.json'):
    shutil.copyfile(lab/name,out/name)
for label,capture in (('initial',first),('completion',remaining)):
    sub=out/label
    sub.mkdir()
    for name in ('archive-receipt.json','terminal-status.json','observations.tgz'):
        shutil.copyfile(capture/name,sub/name)
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for capture in (first,remaining):
        for path in sorted(capture.iterdir()):
            if path.is_file() and path.suffix!='.tgz':
                archive.add(path,arcname=path.relative_to(lab).as_posix())
print('B1340 verified four completed profiles and preserved the original incomplete archive.')

