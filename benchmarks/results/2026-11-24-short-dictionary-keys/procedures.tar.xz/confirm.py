from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

lab = Path(__file__).resolve().parent
quiet = lab / 'comparison/quiet'
output = lab / 'confirmation'
output.mkdir(exist_ok=True)
remote = '/home/lokad/lython-bench-checks'
unit = 'lython-b1548-confirm-short-dictionary-keys-20261124'
location = 'short-dictionary-keys-b1548-20261124'
original = 'short-dictionary-keys-b1547-20261124'
host = 'lokad@20.166.121.73'
common = ['-i', str(Path.home() / '.ssh/id_lython-bench.pem'), '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15']
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', *common, host, 'python3 -']
scp = ['C:/Windows/System32/OpenSSH/scp.exe', *common]
now = lambda: datetime.datetime.now(datetime.timezone.utc)
sha = lambda b: hashlib.sha256(b).hexdigest()
prefix = "from pathlib import Path\nimport json,fcntl,hashlib,os,subprocess,shutil\n"
prefix += f"base=Path({remote!r}).resolve(); root=base/{location!r}; original=base/{original!r}; unit={unit!r}\n"
prefix += "digest=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()\n"


def invoke(script):
    result = subprocess.run(ssh, input=prefix + script, encoding='utf-8', capture_output=True, timeout=35)
    assert result.returncode == 0, (result.stdout, result.stderr)
    return result.stdout


if sys.argv[1] == 'launch':
    status = json.loads((quiet / 'terminal-status.json').read_text(encoding='utf-8'))
    old = status['receipt']['archiveSHA256']
    assert status['exitCode'] == '1' and sha((quiet / 'observations.tar.xz').read_bytes()) == old
    worker = (quiet / 'collect.py').read_text(encoding='utf-8')
    worker = worker.replace('b1547-', 'b1548-').replace('len(jobs) == 4','len(jobs) == 3')
    worker = worker.replace('time.sleep(3)  # Outside clocks; settle after all worker/process cleanup.',
        'time.sleep(12)  # Outside clocks; settle after all worker/process cleanup.')
    worker = worker.replace('        time.sleep(3)\n', '        time.sleep(8)\n')
    worker = worker.replace("purpose=identity['purpose']", "purpose=identity['purpose'] + ' — B1548 bounded confirmation with longer quiet settling'")
    compile(worker, 'collect.py', 'exec')
    script = f"worker={worker!r}; previous_archive={old!r}\n" + """
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert digest(original/'observations.tar.xz')==previous_archive
 assert not (original/'guest-fixtures').exists()
 assert shutil.disk_usage(base).free>=10*1024*1024
 identity=json.loads((original/'identity.json').read_text())
 jobs=json.loads((original/'jobs.json').read_text())
 jobs['warm']=[jobs['warm'][i] for i in (3,2,0)]
 root.mkdir()
 (root/'candidate').mkdir()
 reference=base/'csv-unpack-bindings-b1544-20261124'/'reference'
 for role,files in identity['imageFiles'].items():
  for name,sha in files.items():
   image=original/'candidate' if role=='candidate' else reference
   assert digest(image/name)==sha
   if role=='candidate':os.link(image/name,root/'candidate'/name)
 for name in ('representative.json','cpython-worker.py','run.sh'):
  os.link(original/name,root/name)
 assert digest(root/'representative.json')==identity['catalogs']['representative.json']['sha256']
 assert digest(root/'cpython-worker.py')==identity['cpythonWorkerSHA256']
 (root/'jobs.json').write_text(json.dumps(jobs,indent=2)+'\\n')
 identity['catalogs']['jobs.json']['sha256']=digest(root/'jobs.json')
 (root/'identity.json').write_text(json.dumps(identity,indent=2)+'\\n')
 (root/'collect.py').write_text(worker,encoding='utf-8')
 assert bytes([13]) not in (root/'run.sh').read_bytes()
subprocess.run(['sudo','-n','systemd-run','--unit='+unit,'--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=295','--property=TimeoutStopSec=20','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
"""
    receipt = invoke(script)
    (output / 'launch.log').write_text(receipt, encoding='utf-8')
    (output / 'observe-not-before').write_text((now()+datetime.timedelta(seconds=230)).isoformat(), encoding='utf-8')
    print(unit, receipt)
else:
    assert sys.argv[1] == 'retrieve'
    assert now() >= datetime.datetime.fromisoformat((output / 'observe-not-before').read_text(encoding='utf-8'))
    state = invoke("""
service=subprocess.run(['systemctl','show',unit+'.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],capture_output=True,text=True).stdout
if 'ActiveState=active' in service:
 print(json.dumps(dict(live=True,service=service)))
else:
 with (base/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  outcome=root/'exit-code.txt'
  receipt=root/'archive-receipt.json'
  print(json.dumps(dict(live=False,service=service,exitCode=outcome.read_text().strip() if outcome.exists() else None,
   receipt=json.loads(receipt.read_text()) if receipt.exists() else None, fixtures=(root/'guest-fixtures').exists(),
   journal=subprocess.run(['journalctl','-u',unit+'.service','-n','36','--no-pager'],capture_output=True,text=True).stdout)))
""")
    status = json.loads(state)
    print(state)
    (output / ('status-' + now().strftime('%H%M%S') + '.json')).write_text(state, encoding='utf-8')
    if status.get('receipt') is not None:
        archive = output / 'observations.tar.xz'
        subprocess.run(scp+[host+':'+remote+'/'+location+'/'+archive.name,archive],check=True,timeout=35)
        assert sha(archive.read_bytes()) == status['receipt']['archiveSHA256']
        (output / 'terminal-status.json').write_text(state, encoding='utf-8')
