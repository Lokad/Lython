from pathlib import Path
import base64
import contextlib
import gzip
import hashlib
import importlib.util
import io
import json
import os
import subprocess
import sys
import tarfile
import tempfile

lab = Path(__file__).resolve().parent
previous = lab.with_name('isolated-local-transfer-20261124')
repo = lab.parents[3]
tree = repo / '.git/agent-worktrees/short-dictionary-keys-20261124'
comparison = lab / 'comparison'
quiet = comparison / 'quiet'
quiet.mkdir(parents=True, exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda b: hashlib.sha256(b).hexdigest()
digest = lambda p: sha(p.read_bytes())


def write(path, source):
    path.write_text(source, encoding='utf-8', newline='\n')


def save(path, value):
    write(path, json.dumps(value, indent=2, ensure_ascii=False) + '\n')


head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree).decode().strip()
parent = subprocess.check_output(['git', 'rev-parse', 'HEAD^'], cwd=tree).decode().strip()
assert parent.startswith('4af3c6e6e')


def prepare():
    catalog = read(previous / 'comparison/representative.json')
    distinct = dict(catalog['cases'][0])
    fixture = json.loads(distinct['fixtureJson'])
    original = base64.b64decode(fixture['inputFiles']['meters.csv']).splitlines(keepends=True)
    assert len(original) == 4097
    data = original[0] + b''.join(
        f'"{index:05x}",'.encode('ascii') + line.split(b',', 1)[1]
        for index, line in enumerate(original[1:]))
    fixture['inputFiles']['meters.csv'] = base64.b64encode(data).decode('ascii')
    protocol = repo / 'benchmarks/cpython-worker.py'
    spec = importlib.util.spec_from_file_location('comparison_protocol', protocol)
    worker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(worker)
    with tempfile.TemporaryDirectory(prefix='lython-meter-golden-') as name:
        folder = Path(name)
        (folder / 'meters.csv').write_bytes(data)
        captured = io.StringIO()
        with contextlib.chdir(folder), contextlib.redirect_stdout(captured):
            exec(compile(distinct['source'], 'meter.py', 'exec'), {'__name__': '__main__'})
        actual = (folder / 'summary.csv').read_bytes()
    assert captured.getvalue() == '4096 4096\n'
    fixture['outputFiles']['summary.csv'] = base64.b64encode(actual).decode('ascii')
    distinct.update(id='scripts.csv-meter-report.distinct-keys', expectedOutput=captured.getvalue(),
        expectedOutputUtf8Bytes=len(captured.getvalue().encode('utf-8')),
        fixtureJson=json.dumps(fixture, ensure_ascii=False, separators=(',', ':')),
        expectedFilesSha256=worker.file_digest({'summary.csv': actual}))
    distinct['expectedOutputSha256'] = sha(distinct['expectedOutput'].encode('utf-8'))
    distinct['fixtureSha256'] = sha(distinct['fixtureJson'].encode('utf-8'))
    save(comparison / 'distinct.json', distinct)
    source = (previous / 'prepare.py').read_text(encoding='utf-8').split('\nenum = ')[0]
    source = source.replace('csv-unpack-bindings-20261124', 'short-dictionary-keys-20261124')
    source = source.replace('9f898691314746af9f852059cde187d29a69c27f', head)
    start = source.index('assert set(git(')
    finish = source.index('\n\ncurrent', start)
    files = subprocess.check_output(['git','diff','--name-only','3e5826f7d',head,'--','src'],cwd=tree).decode().splitlines()
    assert len(files) == 6
    source = source[:start] + ('assert set(git("diff", "--name-only", reference, candidate, "--", "src").splitlines()) == ' + repr(set(files))) + source[finish:]
    source = source.replace("current['cases'] = [lookup[name] for name in names]",
        "distinct = read(comparison / 'distinct.json')\nnames += (distinct['id'],)\nlookup[names[-1]] = distinct\ncurrent['cases'] = [lookup[name] for name in names]")
    source = source.replace('(names[0], names[3], names[2])', '(names[0], names[4], names[2], names[3])')
    source = source.replace('B1546 complete fixed CSV unpack and parallel assignments with one slot transfer',
        'B1547 borrow deferred UTF-8 keys through exact dictionary reads and existing-key updates')
    write(lab / 'prepare.py', source)
    (lab / 'allocations.py').write_bytes((previous / 'allocations.py').read_bytes())


def stage():
    replicas = []
    for archive, remote in (
        ('2026-11-24-isolated-local-transfer', 'isolated-local-transfer-b1546-20261124'),
        ('2026-11-23-combined-cased-split-cpython', 'combined-cased-split-cpython-b1539-20261123'),
    ):
        location = 'benchmarks/results/' + archive + '/'
        def known(name):
            return subprocess.check_output(['git', 'show', 'origin/master:' + location + name], cwd=repo)
        try:
            receipt = json.loads(known('terminal-status.json'))['receipt']
            assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
            assert sha(known('observations.tar.xz')) == receipt['archiveSHA256']
            binary = sha(gzip.decompress(known('candidate-core.dll.gz')))
            assert binary == json.loads(known('identity.json'))['imageFiles']['candidate']['Lokad.Lython.dll']
        except (KeyError, subprocess.CalledProcessError):
            if not replicas:
                raise
            continue
        replicas.append(dict(path=remote + '/candidate/Lokad.Lython.dll', sha256=binary,
            observationSHA256=receipt['archiveSHA256'], trackedArchive=location))
    save(lab / 'verified-replicas.json', replicas)
    original = previous / 'comparison/quiet'
    worker = (original / 'collect.py').read_text(encoding='utf-8').replace('b1546-', 'b1547-')
    worker = worker.replace('len(jobs) == 3', 'len(jobs) == 4')
    compile(worker, 'collect.py', 'exec')
    write(quiet / 'collect.py', worker)
    (quiet / 'run.sh').write_bytes((original / 'run.sh').read_bytes())
    assert b'\r' not in (quiet / 'run.sh').read_bytes()
    payload = quiet / 'payload.tar.gz'
    with tarfile.open(payload, 'w:gz') as archive:
        for name in ('identity.json', 'representative.json', 'jobs.json'):
            archive.add(comparison / name, arcname=name)
        for name in ('collect.py', 'run.sh'):
            archive.add(quiet / name, arcname=name)
        archive.add(lab / 'candidate/Lokad.Lython.dll', arcname='candidate-core.dll')
    save(quiet / 'upload.json', dict(root='short-dictionary-keys-b1547-20261124',
        reference='csv-unpack-bindings-b1544-20261124', payloadSHA256=digest(payload), payloadBytes=payload.stat().st_size))
    launch = (previous / 'quiet.py').read_text(encoding='utf-8').replace(
        'b1546-isolated-local-transfer', 'b1547-short-dictionary-keys').replace('b1546-', 'b1547-')
    launch = launch.replace('seconds=215', 'seconds=255').replace('RuntimeMaxSec=275', 'RuntimeMaxSec=335')
    write(lab / 'quiet.py', launch)
    summary = (previous / 'summarize.py').read_text(encoding='utf-8').replace('receipt["warmJobs"] == 3',
        'receipt["warmJobs"] == 4').replace('len(warm["jobs"])==3', 'len(warm["jobs"])==4').replace('timedBatches=84', 'timedBatches=112')
    write(lab / 'summarize.py', summary)


{'prepare': prepare, 'stage': stage}[sys.argv[1]]()
