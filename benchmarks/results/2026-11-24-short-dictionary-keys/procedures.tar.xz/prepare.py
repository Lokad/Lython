from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
notes = lab.parent
tree = repo / '.git/agent-worktrees/short-dictionary-keys-20261124'
comparison = lab / 'comparison'
comparison.mkdir(exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')


def git(*args, cwd=repo):
    return subprocess.check_output(['git', *args], cwd=cwd).decode().strip()


donor = notes / 'regex-coordinate-tuples-20261124'
proof = read(donor / 'comparison/identity.json')
reference = proof['candidate']
candidate = git('rev-parse', 'HEAD', cwd=tree)
assert reference.startswith('3e5826f7d') and candidate.startswith('4e0ef9eb9f2b76d624da0b120d88c05d1bd3a747')
assert not git('status', '--porcelain', cwd=tree)
assert set(git("diff", "--name-only", reference, candidate, "--", "src").splitlines()) == {'src/Lokad.Lython/Frontend/ExecutableScript.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Inputs.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs', 'src/Lokad.Lython/Frontend/ExecutableStackLayout.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs', 'src/Lokad.Lython/Runtime/PyDict.Storage.cs'}

current = read(notes / 'current-csv-cpython-20261124/comparison/quiet/representative.json')
related = read(notes / 'marked-cased-split-20261123/comparison/representative.json')
names = ('scripts.csv-meter-report.explicit-float', 'scripts.csv-meter-report.typed-unicode',
    'scripts.csv-invoice.method-policy.quoted-control', 'diagnostic.text-summary.nonlocal-computed-width.large')
lookup = {item['id']: item for item in current['cases'] + related['cases']}
distinct = read(comparison / 'distinct.json')
names += (distinct['id'],)
lookup[names[-1]] = distinct
current['cases'] = [lookup[name] for name in names]
write(comparison / 'representative.json', current)
write(comparison / 'jobs.json', {'warm': [[name, 'warm'] for name in (names[0], names[4], names[2], names[3])]})

runtime = Path.home() / '.dotnet11'
dotnet = runtime / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(runtime), DOTNET_ROOT_X64=str(runtime))
protocol = repo / 'benchmarks/cpython-worker.py'
assert digest(protocol) == proof['cpythonWorkerSHA256']
core = 'Lokad.Lython.dll'
files = proof['imageFiles']['candidate']
assert len(files) == 32 and all(digest(donor / 'candidate' / name) == expected for name, expected in files.items())
actual, helpers = {}, {}
for role in ('reference', 'candidate'):
    image = lab / role
    image.mkdir(exist_ok=True)
    for name in files:
        source = lab / 'frozen/bin/Lokad.Lython/release_net11.0' / core if role == 'candidate' and name == core else donor / 'candidate' / name
        shutil.copyfile(source, image / name)
    for helper in ('ValidatedAllocation', 'Inspect'):
        for suffix in ('.dll', '.deps.json', '.runtimeconfig.json'):
            name = helper + suffix
            file = notes / 'marked-cased-split-20261123/candidate' / name
            shutil.copyfile(file, image / name)
            helpers[name] = digest(file)
            assert digest(image / name) == helpers[name]
    actual[role] = {name: digest(image / name) for name in files}
    verified = comparison / (role + '-verify.json')
    subprocess.run([dotnet, image / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog',
        comparison / 'representative.json', '--dotnet', dotnet, '--python', 'C:/Python313/python.exe',
        '--python-worker', protocol, '--out', verified], env=env, check=True, timeout=85)
    result = read(verified)
    assert result['state'] == 'Completed' and result['caseCount'] == len(names)
    assert result['launched']['library']['sha256'] == actual[role][core]
    subprocess.run([dotnet, image / 'Inspect.dll', comparison / 'representative.json', lab / (role + '-tape.json')],
        env=env, check=True, timeout=30)
    assert all(digest(image / name) == expected for name, expected in actual[role].items())
assert files == actual['reference']
assert [name for name in files if actual['reference'][name] != actual['candidate'][name]] == [core]
write(comparison / 'identity.json', dict(sourceRevision=reference, candidate=candidate,
    purpose='B1547 borrow deferred UTF-8 keys through exact dictionary reads and existing-key updates',
    imageFiles=actual, helperFiles=helpers, cpythonWorkerSHA256=proof['cpythonWorkerSHA256'],
    expectedCPythonSHA256=proof['expectedCPythonSHA256'],
    catalogs={name: {'sha256': digest(comparison / name)} for name in ('representative.json', 'jobs.json')},
    coreSHA256={label: hashes[core] for role, hashes in actual.items() for label in (role, role + '-control')}))
