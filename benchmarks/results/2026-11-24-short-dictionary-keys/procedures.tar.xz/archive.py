from io import BytesIO
from pathlib import Path
import gzip
import hashlib
import json
import re
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / '.git/agent-worktrees/short-dictionary-keys-20261124'
comparison = lab / 'comparison'
quiet = comparison / 'quiet'
record = repo / 'benchmarks/results/2026-11-24-short-dictionary-keys'
record.mkdir(exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(path.read_bytes())
identity = read(comparison / 'identity.json')
assert identity['candidate'].startswith('4e0ef9eb9')


def retain_run(folder, name, jobs, quiet_gate):
    status = read(folder / 'terminal-status.json')
    assert not status['live'] and not status['fixtures']
    receipt = status['receipt']
    assert receipt['archivedAndVerifiedUnderLease'] and receipt['guestFixturesRemoved']
    assert receipt['complete'] == receipt['quietBeforeAndAfter'] == quiet_gate
    bundle = folder / 'observations.tar.xz'
    assert digest(bundle) == receipt['archiveSHA256']
    with tarfile.open(bundle) as archive:
        unpack = lambda f: json.load(archive.extractfile(f))
        manifest = unpack('identity.json')
        assert manifest['imageFiles'] == identity['imageFiles']
        assert manifest['catalogs']['representative.json'] == identity['catalogs']['representative.json']
        gate = unpack('confirmation/machine-after.json')['gate']
        assert gate['quiet'] == quiet_gate
        if not quiet_gate: assert gate['reasons']
        observations = unpack('confirmation/confirmation.json')
        assert observations['complete'] == quiet_gate and len(observations['jobs']) == jobs
        assert all(j['workersJoinedAndFixturesRemoved'] and len(j['samples']) == 28 for j in observations['jobs'])
    shutil.copyfile(bundle, record / (name + '-observations.tar.xz'))
    shutil.copyfile(folder / 'terminal-status.json', record / (name + '-terminal.json'))
    summary = folder / ('summary.json' if quiet_gate else 'diagnostic-summary.json')
    assert len(read(summary)['rows']) == jobs
    shutil.copyfile(summary, record / (name + '-summary.json'))


retain_run(quiet, 'initial', 4, False)
confirmation = lab / 'confirmation'
if (confirmation / 'summary.json').is_file():
    retain_run(confirmation, 'confirmation', 3, True)
elif (confirmation / 'diagnostic-summary.json').is_file():
    retain_run(confirmation, 'confirmation', 3, False)

cases = [row['id'] for row in read(comparison / 'representative.json')['cases']]
assert len(cases) == 5
source = tree / 'src/Lokad.Lython/Frontend/ExecutableScript.cs'
enum = re.search(r'enum ExecutableOpCode\s*\{(.*?)\}',source.read_text(encoding='utf-8'),re.S).group(1)
instructions = [name.strip() for name in enum.split(',')]
markers = {}
for role, files in identity['imageFiles'].items():
    image = lab / role
    assert len(files) == 32 and all(digest(image / name) == checksum for name, checksum in files.items())
    assert all(digest(image / name) == checksum for name, checksum in identity['helperFiles'].items())
    smoke = read(comparison / (role + '-verify.json'))
    assert smoke['state'] == 'Completed' and smoke['caseCount'] == len(cases)
    assert smoke['launched']['library']['sha256'] == files['Lokad.Lython.dll']
    core = image / 'Lokad.Lython.dll'
    published = record / 'candidate-core.dll.gz' if role == 'candidate' else (
        repo / 'benchmarks/results/2026-11-24-csv-unpack-bindings/reference-core.dll.gz')
    if role == 'candidate': published.write_bytes(gzip.compress(core.read_bytes(), mtime=0))
    assert sha(gzip.decompress(published.read_bytes())) == files[core.name]
    local = read(lab / (role + '-allocation-six.json'))['rows']
    assert len(local) == len(cases) and all(row['sharedBudgetBaselineRestored'] for row in local)
    tape = read(lab / (role + '-tape.json'))
    assert tape['coreSHA256'] == files[core.name]
    markers[role] = {}
    for row in tape['rows']:
        markers[role][row['id']] = found = []
        for code in row['codes']:
            for ix, op in enumerate(code['tape']):
                opcode = instructions[op['<OpCode>k__BackingField']]
                if opcode == 'LoadDictionaryGetKey' or opcode == 'StoreSubscript' and op['_primaryOperand'] < 0:
                    found.append([code['name'], ix, opcode])
    counts = [len(markers[role][name]) for name in cases]
    assert counts == ([2,2,0,0,2] if role == 'candidate' else [0]*5)

allocation = read(lab / 'allocation-summary-six.json')
assert len(allocation) == len(cases) and all(row['peakAdmission'][0] == row['peakAdmission'][1] for row in allocation)
shutil.copyfile(lab / 'allocation-summary-six.json', record / 'allocation-summary.json')
shutil.copyfile(comparison / 'identity.json', record / 'identity.json')
(record / 'prepared-sites.json').write_text(json.dumps(markers, indent=2)+'\n', encoding='utf-8')
inputs = ['prepare.py','configure.py','quiet.py','summarize.py','summarize-diagnostic.py','confirm.py',
    'allocations.py','archive.py','verified-replicas.json','reference-tape.json','candidate-tape.json',
    'reference-allocation-six.json','candidate-allocation-six.json','comparison/quiet/launch.log',
    'comparison/reference-verify.json','comparison/candidate-verify.json']
for name in ('confirmation/launch.log','confirmation/summarize.py'):
    if (lab / name).is_file(): inputs.append(name)
patch = subprocess.check_output(['git','diff','--binary',identity['sourceRevision'],identity['candidate'],'--','src','tests'],cwd=tree)
with tarfile.open(record / 'procedures.tar.xz','w:xz') as archive:
    for name in inputs:
        archive.add(lab / name, arcname=name)
    entry = tarfile.TarInfo('changes.patch')
    entry.size = len(patch)
    archive.addfile(entry,BytesIO(patch))
with tarfile.open(record / 'procedures.tar.xz') as archive:
    assert set(archive.getnames()) == set(inputs) | {'changes.patch'}
    assert archive.extractfile('changes.patch').read() == patch
    assert all(sha(archive.extractfile(name).read()) == digest(lab / name) for name in inputs)
