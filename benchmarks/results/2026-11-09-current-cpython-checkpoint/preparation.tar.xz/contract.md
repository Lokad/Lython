R169 coherent external-baseline checkpoint: all five unchanged representative
CSV validation/text count/JSON report/file search/config-edit scripts.15jobs, compile,
warm and compile-to-result separately; four independent processes, two per engine,
5s warmup/role/seven rotated150ms rounds. Expected440s,540s owner/30s stop/30s margin.
Use existing checked workers/protocol and all output/ownership/quiet/Closed/cleanup
gates. Include guest RAM-file I/O, validation and previous-result cleanup, exclude
startup/reset/protocol/final cache teardown from execution clocks; coarse process
CPU wider. Normal tiering/GC and stock CPython3.13.16. Ratios span both controls,
not statistical confidence intervals. Keep adverse/control-limited rows visible;
no automatic rejection by percentage or repeated unchanged timing. Historical source
labels/evidence survive. Refresh primary CPython table, separate warm/compile/startup
and old-Lython improvements. No new framework or individual R167-gain attribution.
Runtime/core/catalog reuse verified persistent B516 images, source-equivalent to
43350e4f/220732b7, explicit precommit binary identity. R167 full delivery42661297753
proceeds independently; publication postponed. Only this affected final package
qualification is pending, not a blanket stop for producer APIs.
