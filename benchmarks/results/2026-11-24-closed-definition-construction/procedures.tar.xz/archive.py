from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
previous = lab.with_name("json-default-prefix-20261124")
quiet = lab / "comparison/quiet"
out = repo / "benchmarks/results/2026-11-24-closed-definition-construction"
out.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
reference = json.loads((quiet / "identity.json").read_text(encoding="utf-8"))
assert sha(lab / "candidate.patch") == reference["sourcePatchSHA256"]
patch = (lab / "candidate.patch").read_bytes()
expected_test_diff = patch[patch.index(b"diff --git a/tests/"):]
assert expected_test_diff == subprocess.check_output(["git", "diff", "--binary", "--", "tests"], cwd=repo)
for role, manifest in reference["imageFiles"].items():
    assert {p.name: sha(p) for p in (lab / role).iterdir()} == manifest
    for mode in ("sync", "async"):
        cases = [json.loads(line) for line in (lab / f"oracle-{role}-{mode}.jsonl").read_text(encoding="utf-8").splitlines()]
        assert len(cases) == 8 and all(case["Matches"] for case in cases)

for platform in ("windows", "ubuntu"):
    assert "Passed:   335" in (lab / (platform + "-white.log")).read_text(encoding="utf-8-sig")
    assert "Passed:  2117" in (lab / (platform + "-public.log")).read_text(encoding="utf-8-sig")
shutil.copyfile(quiet / "identity.json", out / "identity.json")
shutil.copyfile(lab / "allocation-summary.json", out / "allocation-summary.json")
shutil.copyfile(lab / "call-operand-tape.json", out / "call-operand-tape.json")
for platform in ("windows", "ubuntu"):
    assert "Passed:    21" in (lab / ("restored-" + platform + "-pair.log")).read_text(encoding="utf-8-sig")
with tarfile.open(out / "procedures.tar.xz", "w:xz") as archive:
    for name in ["archive.py", "archive-quiet.py", "prepare.py", "prepare-oracle.py", "allocations.py", "quiet.py",
                 "oracle.py", "oracle-input.json", "prepare.log", "oracle.log", "launch.log", "retrieve.log",
                 "candidate.patch", "windows-public.log", "windows-white.log", "ubuntu-public.log", "ubuntu-white.log",
                 "reference-allocation.json", "candidate-allocation.json", "allocation-summary.json",
                 "comparison/reference-verify.json", "comparison/candidate-verify.json",
                 "comparison/quiet/jobs.json", "comparison/quiet/representative.json", "comparison/quiet/collect.py",
                 "comparison/quiet/run.sh", "comparison/quiet/storage-custody.json", "withdraw.py", "inspect-tape.py",
                 "tape-inspector/tapes.json", "tape-inspector/catalog.json", "restored-windows-build.log",
                 "restored-ubuntu-build.log", "restored-windows-pair.log", "restored-ubuntu-pair.log"] + [
                  f"oracle-{role}-{mode}.jsonl" for role in ("reference", "candidate") for mode in ("sync", "async")]:
        archive.add(lab / name, arcname=name, recursive=False)
    inspect_source = lab.with_name("current-defaulted-report-cpu-20261124") / "tape-inspector/Program.cs"
    archive.add(inspect_source, arcname="tape-inspector/Program.cs", recursive=False)
