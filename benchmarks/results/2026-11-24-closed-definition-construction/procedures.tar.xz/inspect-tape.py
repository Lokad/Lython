from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
old=lab.with_name("current-defaulted-report-cpu-20261124")
probe=lab/"tape-inspector"
probe.mkdir(exist_ok=True)
source=old/"tape-inspector/bin/Release/net11.0"
sdk=Path.home()/".dotnet11"
for file in ("Inspect.deps.json","Inspect.dll","Inspect.runtimeconfig.json"):
    shutil.copyfile(source/file,probe/file)
shutil.copyfile(lab/"reference/Lokad.Lython.dll",probe/"Lokad.Lython.dll")
read=lambda x:json.loads(x.read_text(encoding="utf-8"))
identity=read(lab/"comparison/identity.json")
catalog=read(lab/"comparison/quiet/representative.json")
catalog["cases"]=[row for row in catalog["cases"] if row["id"]=="scripts.rule-default-closures"]
(probe/"catalog.json").write_text(json.dumps(catalog,indent=2)+"\n",encoding="utf-8")
subprocess.run([sdk/"dotnet.exe",probe/"Inspect.dll",probe/"catalog.json",probe/"tapes.json"],check=True,timeout=20,
    env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)))
output=read(probe/"tapes.json")
assert output["coreSHA256"]==identity["coreSHA256"]["reference"]
module=next(row for row in output["rows"][0]["codes"] if row["name"]=="<module>")
tape=module["tape"]
op=lambda i:i["<OpCode>k__BackingField"]
loop=[{"index":i,"line":op["<Span>k__BackingField"]["Line"],"forwarded":op["_secondaryOperand"]!=2147483647,
       "preceding":[a["<OpCode>k__BackingField"] for a in tape[i-2:i]],
       "following":tape[i+1]["<OpCode>k__BackingField"]}
       for i,op in enumerate(tape) if op["<OpCode>k__BackingField"]==42 and 8<op["<Span>k__BackingField"]["Line"]<=10]
assert len(loop)==3 and all(not row["forwarded"] and row["preceding"]==[2,2] for row in loop),loop
result={"coreSHA256":output["coreSHA256"],"callCountPerGroup":len(loop),"groups":2048,"loadsPerGroup":6,
        "scope":"Static opcode census of the existing complete script. No dynamic route or timing claim.","calls":loop}
(lab/"call-operand-tape.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps(result))
