from pathlib import Path
import hashlib, json, subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
archive = repo / "benchmarks/results/2026-11-24-closed-definition-construction"
identity = json.loads((archive / "identity.json").read_text(encoding="utf-8"))
binary_patch = subprocess.check_output(["git", "diff", "--binary", "--", "src", "tests"], cwd=repo)
assert binary_patch == (lab / "candidate.patch").read_bytes()
assert hashlib.sha256(binary_patch).hexdigest() == identity["sourcePatchSHA256"]
production = subprocess.check_output(["git", "diff", "--name-only", "--", "src"], cwd=repo, text=True).splitlines()
assert sorted(production) == [
    "src/Lokad.Lython/Runtime/LythonRuntime.Executable.PreparedDefinitions.cs",
    "src/Lokad.Lython/Runtime/PyExecutableFunction.cs"]
subprocess.run(["git", "restore", "--worktree", "--", *production], cwd=repo, check=True)
