from pathlib import Path
import subprocess, sys

lab = Path(__file__).resolve().parent
single = lab.with_name("callable-singleton-defaults-isolated-20261124")
prefix = (single / "oracle.py").read_text(encoding="utf-8")
i = prefix.index("request = json.dumps(cases)")
cases = [
    """def make(n):
    def inner(pos=n // 7, *, step=(n + 1) % 5):
        return pos, step
    return inner
for n in (-5, 0, 13, (1 << 63) - 1, -(1 << 63), 1 << 95):
    f, g = make(n), make(n)
    print(f(), f.__defaults__ is g.__defaults__, f.__kwdefaults__ is g.__kwdefaults__)
""",
    """def make(n):
    def inner(pos: Missing = 12 // n, *, step=n % 5):
        return pos, step
    return inner
for n in (0, 2):
    try:
        f = make(n)
    except (NameError, ZeroDivisionError) as e:
        print(type(e).__name__)
Missing = int
print(make(3)(), make(3).__annotations__['pos'] is int)
"""]
oracle = prefix[:i] + "cases += " + repr(cases) + "\n" + prefix[i:]
(lab / "oracle.py").write_text(oracle, encoding="utf-8", newline="\n")
subprocess.run([sys.executable, "-I", "-X", "utf8", lab / "oracle.py"], check=True)
