using System.Collections;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

const BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var rows = new List<object>();
object? Read(object item, string name) => item.GetType().GetProperty(name, flags)?.GetValue(item);
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var budget = new LythonMemoryBudget();
    using (var script = new LythonEngine().Compile(item.GetProperty("source").GetString()!, budget))
    {
        if (!script.IsValid) throw new InvalidOperationException(string.Join("|", script.Diagnostics));
        var target = ((Delegate)typeof(LythonCompiledScript).GetField("_runner", flags)!.GetValue(script)!).Target!;
        var executable = target.GetType().GetFields(flags).Single(f => f.FieldType.Name == "ExecutableScript").GetValue(target)!;
        var codes = new List<object>();
        var seen = new HashSet<object>(ReferenceEqualityComparer.Instance);
        void Visit(object code)
        {
            if (!seen.Add(code)) return;
            var counts = ((IEnumerable)Read(code, "Instructions")!).Cast<object>()
                .GroupBy(i => Read(i, "OpCode")!.ToString()!).ToDictionary(g => g.Key, g => g.Count());
            var sites = ((IEnumerable)Read(code, "CallSites")!).Cast<object>().ToArray();
            var capacity = (int)Read(code, "ValueStorageCapacity")!;
            var calls = ((IEnumerable)Read(code, "Instructions")!).Cast<object>()
                .Where(i => Read(i, "OpCode")!.ToString() == "Call").Select(i =>
                {
                    var site = sites[(int)Read(i, "CallSiteIndex")!];
                    var first = (int)Read(i, "InputStart")!;
                    var count = (int)Read(site, "ArgumentCount")!;
                    var offset = (int)Read(site, "ArgumentOffset")!;
                    return new { first, count, offset, deadTailCapacity = capacity - first - count - offset,
                        iteration = Read(site, "ConsumedByIteration"), split = Read(site, "SplitPrefix")?.GetType().Name, span = Read(site, "CallSpan")!.ToString() };
                }).ToArray();
            var pool = ((IEnumerable)Read(code, "Constants")!).Cast<object?>().ToArray();
            var firstTemp = (int)Read(code, "FirstTemporarySlot")!;
            string Source(int n)
                => n >= 0 ? (n < firstTemp ? "local" : "temporary")
                    : ~n < pool.Length ? (pool[~n]?.GetType().Name ?? "None") : "global";
            var arithmetic = ((IEnumerable)Read(code, "Instructions")!).Cast<object>().Select((i, index) => (i, index))
                .Where(a => Read(a.i, "OpCode")!.ToString() is "Binary" or "Augmented")
                .Select(a => new
                {
                    a.index, line = Read(a.i, "Span")!.GetType().GetProperty("Line")!.GetValue(Read(a.i, "Span")),
                    op = Read(a.i, "OpCode")!.ToString() == "Binary" ? Read(a.i, "BinaryOperator")!.ToString()
                        : Read(a.i, "AugmentedOperator")!.ToString(),
                    left = Source((int)Read(a.i, "InputStart")!), right = Source((int)Read(a.i, "SecondInput")!)
                }).ToArray();
            codes.Add(new { arithmetic, definitionPair = Read(code, "DefinitionPair")?.ToString(), directDefinitionReturn = Read(code, "DirectDefinitionReturn") is not null, directIntegerReturn = Read(code, "HasDirectIntegerReturn"), name = Read(code, "Name"), mirrors = Read(code, "RequiresLocalVariableMirroring"),
                native = Read(code, "CanRunNativeInstructions"), nativeEnd = Read(code, "NativePrefixEnd"), instructions = ((IEnumerable)Read(code, "Instructions")!).Cast<object>().Count(), capacity = Read(code, "ValueStorageCapacity"),
                locals = Read(code, "LocalNames"), captured = Read(code, "CapturedLocalSlots"),
                closures = Read(code, "ClosureNames"), opcodeCounts = counts, calls,
                entry = Read(code, "EntryIndex"), regions = Read(code, "ExceptionRegions"),
                operandReads = code.GetType().GetField("_operandReadSpans", flags)!.GetValue(code),
                tape = ((IEnumerable)Read(code, "Instructions")!).Cast<object>().Select(i =>
                    i.GetType().GetFields(flags).OrderBy(f => f.Name).ToDictionary(f => f.Name, f => f.GetValue(i))).ToArray() });
            foreach (var constant in (IEnumerable)Read(code, "Constants")!)
            {
                var child = constant?.GetType().Name switch
                {
                    "ExecutableCreateClass" => Read(constant, "Body"),
                    "ExecutableCreateFunction" or "ExecutableCreateLambda" or "ExecutableCreateGeneratorExpression" =>
                        Read(constant, "CodeObject"),
                    _ => null
                };
                if (child is not null) Visit(child);
            }
        }
        Visit(Read(executable, "EntryPoint")!);
        rows.Add(new { id = item.GetProperty("id").GetString(), codes });
    }
    if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compilation cleanup retained allowance.");
}
File.WriteAllText(args[1], JsonSerializer.Serialize(new { coreSHA256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))),
    purpose = "Known compiler metadata only, not guest heap traversal or CPU attribution", rows }, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"Inspected {rows.Count} matched scripts; all compilation owners returned to baseline.");
