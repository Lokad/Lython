from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-18-bindings-cpython-checkpoint';out.mkdir(exist_ok=False)
guide=repo/'docs/BENCHMARKS.md';shutil.copyfile(guide,out/'prior-BENCHMARKS.md')
for n in ['summary.json','catalog.json','preflight.json','preflight-reuse.json']:shutil.copyfile(r/n,out/n)
for n in ['identity.json','observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(r/'quiet'/n,out/n)
i=json.loads((out/'identity.json').read_text(encoding='utf-8'));source=repo/'benchmarks/results/2026-11-18-prepared-module-bindings/initial/candidate-sources.tar.xz';assert hashlib.sha256(source.read_bytes()).hexdigest()==i['sourceInputsArchiveSHA256']
with tarfile.open(out/'procedures.tar.xz','w:xz')as a:
 for p in r.rglob('*'):
  if p.is_file()and 'retrieved'not in p.relative_to(r).parts and p.suffix in ['.py','.json','.sh','.log']:a.add(p,arcname=p.relative_to(r).as_posix())
s=json.loads((out/'summary.json').read_text(encoding='utf-8'));names={'scripts.text-normalization.helper-list':'Helper text normalization','scripts.numeric-squared-error.floating.large':'Floating JSON numeric report'}
def fields(row):
 t=row['medianMilliseconds'];l=[t[x]for x in ['candidate','candidate-control']];c=[t[x]for x in ['CPython','CPython-control']]
 return [f'{min(l):.3f}–{max(l):.3f} ms',f'{min(c):.3f}–{max(c):.3f} ms',f"{min(row['ratioRange']):.2f}–{max(row['ratioRange']):.2f}×",f"Diagnostic3f/a503; controls L/C {row['lythonControlPercent']:.2f}/{row['cpythonControlPercent']:.2f}%; IQR≤{row['maxIqrPercent']:.2f}%"]
table=[];text=guide.read_text(encoding='utf-8');lines=text.splitlines()
for row in s['timing']:
 title=names[row['case']];phase={'compile':'Compilation only','warm':'Warm execution','compile-run':'Compile-to-result'}[row['lane']];table.append('| '+title+' | '+phase+' | '+' | '.join(fields(row))+' |')
 prefix='| '+title+' | '+('4,096'if row['lane']=='warm'else phase);positions=[j for j,line in enumerate(lines)if line.startswith(prefix)];assert len(positions)==1,(prefix,positions)
 size=('4,096 lines / 52,224 B'if 'text' in row['case']else'4,096 pairs / 56,495 B')if row['lane']=='warm'else phase
 lines[positions[0]]='| '+title+' | '+size+' | '+' | '.join(fields(row))+' |'
(out/'README.md').write_text('''# Prepared-binding CPython checkpoint

R522/B952, measured2026-11-18UTC: committed **3f873227 / frozen a5038a28** versus
stock **CPython3.13.16** (PGO/LTO,GIL,noJIT). Quiet AzureF4as_v7,4vCPU AMD EPYC9V45,
16GiB/Ubuntu24.04.4/.NET11RC3/defaultGC/tiering. Two complete scripts, three phases,
sixjobs226.44s; six-second full-request warmups/five rotated rounds/two processes
per engine. Full retained delivery44256409242 independently pending; no inherited
qualification. Existing workers/verified four-case catalog; no new framework.

| Complete script | Phase | Lython | CPython | Lython / CPython | Status |
| --- | --- | ---: | ---: | ---: | --- |
'''+ '\n'.join(table)+'''

Ratio above one means slower. Ranges combine all four process-median pairs, not
confidence intervals. Helper warm CPython control6.02% limits precision; helper
fresh CPython control3.48% remains visible. Floating warm Lython control2.52%,
fresh controls1.37/0.19%. No cross-collection causal source improvement is inferred.
The separate source-pair comparison supports a named floating warm/fresh gain;
the remaining CPython gap is still material. Earlier adverse/unqualified helper
measurements stay in [R517](../2026-11-18-helper-validation-cpython/README.md).

Helper input4,096lines/52,224B; floatingJSON4,096pairs/56,495B. Warm includes Run,
mediated RAM I/O, stdout/file goldens and previous-result cleanup. Fresh adds
compilation/compiled-owner disposal; compilation includes owner disposal. Startup,
fixture reset, request framing and final caches are outside guest clocks; process
CPU is wider. Separately warmed phases are not additive. CPython native files do
not provide equivalent containment/ownership. All32image files reverified; exact
four-case independent actual-image goldens reused, not repeated. Every worker
checks outputs/Closed; all users joined, quiet gates/SHAarchive passed before RAM
teardown. No replica retirement, space floors/current images remain unchanged.

[Summary](summary.json),[raw](observations.tgz),[identity](identity.json),
[catalog](catalog.json),[verification](preflight.json),[reuse](preflight-reuse.json),
[procedures](procedures.tar.xz),[previous guide](prior-BENCHMARKS.md).
Publication postponed; broader performance work continues.
''',encoding='utf-8',newline='\n')
text='\n'.join(lines)+'\n';a=text.index('Text/floating rows use committed retained');b=text.index('\nWarm clocks include',a)
text=text[:a]+'''Original text normalization keeps its qualified **2e585229 / 1bce52ad** measurement
of2026-11-18. [Sources and original controls](../benchmarks/results/2026-11-18-affected-cpython-checkpoint/README.md).

Helper text/floating rows now use committed retained **3f873227 / a5038a28**,
measured **2026-11-18** on the same machine/toolchains. Full44256409242 is pending.
Helper warm CPython control6.02% limits precision; helper fresh control3.48% and
floating warm Lython2.52% remain visible. [Exact source, boundaries and raw data](../benchmarks/results/2026-11-18-bindings-cpython-checkpoint/README.md).

CSV validation retains **7db1de02 / c0367d98**; its original full run failed entry-
error-context regressions. Later corrected source qualified independently; these
earlier timings are not relabelled. [Sources and limitation](../benchmarks/results/2026-11-18-helper-validation-cpython/README.md).
'''+text[b:]
text=text.replace("Floating fresh CPython's4.91%control movement limits precision; all medians remain\nvisible. Process startup was not measured.","Helper warm CPython's6.02%control movement limits precision; all medians remain\nvisible. Process startup was not measured.")
text=text.replace('The floating fresh CPython control, report IQR and other distributions stay','The helper warm/fresh controls, floating warm control, report IQR and distributions stay')
text=text.replace('Original adverse controls and failed conditions remain linked in the evidence.','Original adverse controls and failed conditions remain linked in the evidence.\nNew3f/a503 full qualification is pending independently; diagnostic ratios are\nspecific to that frozen source/image.')
guide.write_text(text,encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as a:a.write('''

R522/B952 [prepared-binding external checkpoint](results/2026-11-18-bindings-cpython-checkpoint/README.md), retained3f873227/a5038a28 versus stockCPython3.13.16: sixjobs226.44s,32files/actualcataloggoldenreuse/quiet/join/SHAarchive pass. Helpercompile1.05–1.06×/warm1.25–1.33×/fresh1.48–1.53×; warmCPcontrol6.02%/fresh3.48%limits precision. Floatingcompile.91–.92×/warm1.39–1.43×/fresh1.31–1.33×; warmLythcontrol2.52%. Exactsource/phase/IOboundaries retained, no causal sourcegain fromdifferentcollections. Full44256409242 pending; earlier R517failure source remains labelled, publication held.
''')
print('Archived current named baseline and refreshed six guide rows; adverse controls and exact revisions remain explicit.')
