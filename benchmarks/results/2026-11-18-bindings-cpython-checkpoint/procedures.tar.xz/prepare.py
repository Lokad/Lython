from pathlib import Path
import ast,hashlib,json,re,shutil,tarfile
r=Path(__file__).resolve().parent;prior=r.parent/'invocation-cost-r505';old=prior/'quiet';source=r.parent/'module-bindings-r520';q=r/'quiet';q.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((source/'frozen/identity.json').read_text(encoding='utf-8'));files=f['imageFiles']['candidate'];image=source/'frozen/candidate'
assert len(files)==32 and all(sha(image/n)==h for n,h in files.items())
assert files['Lokad.Lython.dll'].startswith('a5038a28')
assert json.loads((source/'candidate-measurement-preflight.json').read_text(encoding='utf-8'))
shutil.copyfile(source/'measurement-catalog.json',r/'catalog.json');catalog_hash=sha(r/'catalog.json')
shutil.copyfile(source/'candidate-measurement-preflight.json',r/'preflight.json')
(r/'preflight-reuse.json').write_text(json.dumps(dict(source='R510 actual copied32-file candidate/same unchanged four-case catalog; completed local verification includes independent CPython goldens',all32HashesReverified=True,catalogSHA256=catalog_hash,unchangedVerificationNotRepeated=True),indent=2)+'\n',encoding='utf-8')
identity=dict(sourceRevision='Committed retained3f873227 production/frozena5038a28 versus CPython3.13.16; full retained delivery independently pending.',purpose='Two affected complete helper-text/floating scripts, compilation/warm/fresh separately. Coherent external checkpoint after prepared live globals; existing tooling/verified catalog, no causal cross-collection source gain.',coreSHA256={role:files['Lokad.Lython.dll']for role in ['candidate','candidate-control']},imageFiles=dict(candidate=files),auxiliaryFiles={n:h for n,h in files.items()if n!='Lokad.Lython.dll'},sourceInputsArchiveSHA256=sha(source/'candidate-sources.tar.xz'),productionFiles=587,catalogSHA256=catalog_hash,normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
jobs=[[case,lane]for case in ['scripts.text-normalization.helper-list','scripts.numeric-squared-error.floating.large']for lane in ['compile','warm','compile-run']]
s=(old/'collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a)
s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==6 and all(case in cases for case,lane in jobs)\n'+s[b:];(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
shutil.copyfile(old/'archive-owned.py',q/'archive-owned.py')
remote='/home/lokad/lython-bench-checks/bindings-cpython-b952-20261118';unit='lython-b952-bindings-cpython-20261118';previous=json.loads((old/'config.json').read_text(encoding='utf-8'))
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace(previous['root'],remote),encoding='utf-8',newline='\n')
names=['collect.py','archive-owned.py','run.sh','identity.json']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in names:a.add(q/n,arcname=n)
c=dict(root=remote,unit=unit,source=json.loads((source/'quiet/config.json').read_text(encoding='utf-8'))['root'],sourceRole='candidate',sourceFiles=files,sourceCatalogSHA256=catalog_hash,catalogSHA256=catalog_hash,identity=identity,retireGroups=[],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
s=s.replace(" os.link(source/'cpython-worker.py',root/'cpython-worker.py')"," os.link(source/'cpython-worker.py',root/'cpython-worker.py')\n os.link(source/'representative.json',root/'representative.json')")
s=s.replace('lython-b929-fixtures','lython-b952-fixtures').replace('New five-case catalog passed actual committed-image golden verification.','Same six-case catalog already passed actual frozen-image verification.')
(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
for n in ['launch.py','summarize.py']:shutil.copyfile(prior/n,r/n)
(q/'retrieve.py').write_text((old/'retrieve.py').read_text(encoding='utf-8').replace('B929','B936'),encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
assert 'time.monotonic()-started < 270'in(q/'collect.py').read_text(encoding='utf-8')
print(json.dumps(dict(prepared=True,jobs=6,image=files['Lokad.Lython.dll'][:8],unchangedActualImagePreflightReused=True,collectorCap=270,serviceCap=330,retireGroups=[],unpackedBytes=c['unpackedBytes'])))
