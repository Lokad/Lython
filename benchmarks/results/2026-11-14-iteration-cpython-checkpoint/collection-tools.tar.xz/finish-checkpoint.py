from pathlib import Path
import base64,hashlib,json,shutil,tarfile
r=Path(__file__).parent;b=r/'b717';out=Path('benchmarks/results/2026-11-14-iteration-cpython-checkpoint');out.mkdir(exist_ok=True)
assert not (out/'README.md').exists(), 'Do not overwrite a finalized observation.'
summary=json.loads((b/'summary.json').read_text(encoding='utf-8'));assert summary['complete'] and summary['jobs']==9
terminal=json.loads((b/'terminal-status.json').read_text(encoding='utf-8'));assert terminal['receipt']['archivedAndVerifiedUnderLease'] and terminal['receipt']['allWorkersJoined']
shutil.copyfile('docs/BENCHMARKS.md',out/'prior-BENCHMARKS.md')
for name in ['summary.json','terminal-status.json','archive-receipt.json','identity.json','prospective.json','observations.tgz']:
 shutil.copyfile(b/name,out/name)
with tarfile.open(out/'collection-tools.tar.xz','w:xz')as t:
 for p in sorted(b.glob('*')):
  if p.is_file()and p.name not in ['observations.tgz','payload.tgz']:t.add(p,arcname='b717/'+p.name)
 t.add(r/'candidate-identity.json',arcname='candidate-identity.json')
 t.add(Path(__file__),arcname='finish-checkpoint.py')
rows=summary['timing'];catalog=json.loads((b/'catalog.json').read_text(encoding='utf-8'))
extra=next(c for c in catalog['cases']if c['id']=='scripts.csv-check-digits.for-text.large')
fixture=json.loads(extra['fixtureJson'])
input_sizes={k:len(base64.b64decode(v))for k,v in fixture['inputFiles'].items()}
(r/'case-details.json').write_text(json.dumps(dict(id=extra['id'],inputSizes=input_sizes,source=extra['source'],fixtureSize=fixture['size']),ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
header='''# Iteration delivery CPython checkpoint

2026-11-14 UTC, R347/B717: committed `009d236a` / frozen `8ae1ae5f`,
581 production inputs, stock CPython 3.13.16. Full Windows/Ubuntu .NET 11/10,
original stress and installed-package CI43563853239 is pending at collection.
This includes shared integer chains, native builtin-for prefixes, indexed cursors
and the explicit-LF fixture correction; it is not the earlier qualified1778 source.
Publication/tagging remain held.

| Complete script / phase | Lython ms | CPython ms | Lython / CPython | Lython/CPython process spread | Max IQR |
| --- | ---: | ---: | ---: | ---: | ---: |
'''
def interval(d,labels):
 v=[d[x]for x in labels];return f'{min(v):.6f}–{max(v):.6f}'
for row in rows:
 header+=f"|{row['case'].removeprefix('scripts.')} /{row['lane']}|{interval(row['medianMilliseconds'],['candidate','candidate-control'])}|{interval(row['medianMilliseconds'],['CPython','CPython-control'])}|{min(row['ratioRange']):.2f}–{max(row['ratioRange']):.2f}×|{row['lythonControlPercent']:.2f}/{row['cpythonControlPercent']:.2f}%|{row['maxIqrPercent']:.2f}%|\n"
header+='''
Ratio = Lython elapsed / CPython elapsed, above one means slower. All pairings of
two independent process medians produce the ranges, not confidence intervals.
Warm invoice/search process spreads3.47/4.05% and captured text6.57% remain
inconclusive stability. The earlier catalog and all adverse controls survive.
No gain or regression is attributed by subtracting these from older collections.

The quiet Azure F4as_v7 VM runs Ubuntu24.04.4, four EPYC9V45 vCPUs,
16GiB/no swap, .NET11RC3 ordinary workstation GC/tiering and stock Python GIL/GC.
Unchanged B685.NET/Python workers and optional0.4adapter verify all exact images,
stdout/files and shared-budget balances. Eight prior jobs retain their sources,
fixtures and independent goldens; the ninth is the identical4,096-row CSV script
used in R345/R346, independently checked under isolated CPython3.13.2.

Each job has two fresh processes per engine, five rotating0.5s batches sized by
complete-request wall time, five-second warmup (12s captured text/report).
Warm guest clocks include mediated RAM-file I/O, full stdout/file validation and
prior-result cleanup; they exclude compilation/startup, fixture reset/protocol
and final cache shutdown. Compilation alone includes compiled-owner disposal;
compile-to-result adds compilation/disposal to execution. Wider process CPU
includes reset/protocol. Independently warmed phases cannot be added/subtracted
as attribution. No startup/RSS/heap/shared-contention/pending-I/O/tail claim.

Nine jobs finish360.55s inside a480s owner (420s work guard). All source/image/
golden/balance/quiet/join/archive checks pass; no workers or RAM fixtures remain.
The frozen existing VM image is hardlinked, with every auxiliary checked and no
new core copy or evidence retirement. Disk floors remain unchanged.
Persistent raw SHA256:
`a3f6b61efc7cc751eb3659e002ca54a818301aabfcd0d0d5678b07727e832e79`.

[Raw observations](observations.tgz), [summary/identities](summary.json),
[tools/catalog](collection-tools.tar.xz), [previous guide](prior-BENCHMARKS.md).
The exact production source/core remains in the
[R346 archive](../2026-11-14-indexed-sequence-cursors/sources-checks-and-observations.tar.xz).
This checkpoint informs further complete-script redesign; it does not complete
the performance objective or claim a uniformly improved runtime.
'''
(out/'README.md').write_text(header,encoding='utf-8',newline='\n')
# Replace only measured rows and their revision/boundaries. Historical evidence
# and separate internal comparisons retain their own attribution.
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8')
ids=['csv-invoice','text-summary-helpers.nonlocal-counter','json-summary-helpers','file-search','report-render','csv-fulfillment']
labels=['CSV invoice / pricing helpers','Text / captured helper and counter','JSON-lines / aggregation helpers','File search / keyword-default helper','JSON-to-Markdown report','CSV fulfillment / pricing and validation']
inputs=['4,096 records /127,031 B','3,072 lines /35,840 B','4,096 records /110,592 B','2,049 lines /42,010 B; stop after1,025','3,072 records /189,441 B','4,096 records /126,821 B']
def display_interval(d,labels,unit='ms'):
 v=[d[x]for x in labels];scale=1000 if unit=='µs' else 1
 return f'{min(v)*scale:.3f}–{max(v)*scale:.3f} {unit}'
def table_row(label,input_text,row,unit='ms'):
 status='Variable'if row['lythonControlPercent']>3 or row['cpythonControlPercent']>3 else'Diagnostic'
 return f"| {label}|{input_text}|{display_interval(row['medianMilliseconds'],['candidate','candidate-control'],unit)}|{display_interval(row['medianMilliseconds'],['CPython','CPython-control'],unit)}|{min(row['ratioRange']):.2f}–{max(row['ratioRange']):.2f}×|{status}; spreads{row['lythonControlPercent']:.2f}/{row['cpythonControlPercent']:.2f}%; maxIQR{row['maxIqrPercent']:.2f}%|"
for name,label,input_text in zip(ids,labels,inputs):
 row=next(x for x in rows if x['case']=='scripts.'+name+'.large'and x['lane']=='warm')
 old=next(line for line in s.splitlines()if line.startswith('| '+label))
 s=s.replace(old,table_row(label,input_text,row,'µs'if name=='file-search'else'ms'))
new=next(x for x in rows if x['case']==extra['id'])
anchor=next(line for line in s.splitlines()if line.startswith('| Configuration JSON edit'))
s=s.replace(anchor,table_row('CSV validation / for-loop checksum',f"4,096 records /{sum(input_sizes.values()):,} B",new)+'\n'+anchor)
a=s.index('First five rows and fulfillment measured');bidx=s.index('The96 B configuration row',a)
s=s[:a]+'''First seven rows measured2026-11-14UTC: **009d236a / frozen8ae1ae5f**,
against stock**CPython3.13.16**. Full Windows/Ubuntu .NET11/10, original stress
and installed-package qualification is pending in
[43563853239](https://github.com/Lokad/Lython/actions/runs/43563853239).
[Exact sources, raw/wider CPU and controls](../benchmarks/results/2026-11-14-iteration-cpython-checkpoint/README.md).
Invoice/search warm process spreads3.47/4.05% and captured text6.57% remain
inconclusive stability despite smaller within-process IQRs. The prior measured
revision and adverse conditions stay in the linked evidence; cross-collection
differences do not attribute individual changes.
'''+s[bidx:]
for lane,label in [('compile','Invoice compilation alone'),('compile-run','Invoice compile and execute once')]:
 row=next(x for x in rows if x['case']=='scripts.csv-invoice.large'and x['lane']==lane)
 old=next(line for line in s.splitlines()if line.startswith('| '+label))
 med=row['medianMilliseconds'];unit='µs'if lane=='compile'else'ms'
 s=s.replace(old,f"| {label}|{display_interval(med,['candidate','candidate-control'],unit)}|{display_interval(med,['CPython','CPython-control'],unit)}|{min(row['ratioRange']):.2f}–{max(row['ratioRange']):.2f}×|Diagnostic; spreads{row['lythonControlPercent']:.2f}/{row['cpythonControlPercent']:.2f}%; maxIQR{row['maxIqrPercent']:.2f}%|")
p.write_text(s,encoding='utf-8',newline='\n')
history=Path('benchmarks/EXPERIMENTS.md');s=history.read_text(encoding='utf-8');anchor='[R346 indexed sequence cursors]'
s=s.replace(anchor,'''[R347 iteration CPython checkpoint](results/2026-11-14-iteration-cpython-checkpoint/README.md)
refreshes committed009d236a/frozen8ae1ae5f against stock3.13.16 in360.55s.
Invoice warm1.26–1.31×, compile1.08–1.10×, fresh1.21–1.24×; text1.48–1.59×,
search1.66–1.76×, JSON0.83×, report1.19–1.21×, fulfillment1.30–1.31× and
for-loop CSV1.28–1.29×. Invoice/search/text process spread remains uncertainty.
All exact image/output/balance/quiet/join/archive gates pass; full delivery is
pending. No attribution by comparing collections; prior evidence remains linked.

'''+anchor,1);history.write_text(s,encoding='utf-8',newline='\n')
print('Archived B717 and updated external guide; input sizes',input_sizes,flush=True)
