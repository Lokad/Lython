set -eu
root=/home/lokad/lython-bench-checks/positional-default-binding-b1101-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
