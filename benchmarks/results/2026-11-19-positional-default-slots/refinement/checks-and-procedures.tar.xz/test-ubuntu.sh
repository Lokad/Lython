set -eu
cd /mnt/d/code/Lython/.git/agent-worktrees/positional-default-slots-r669
notes=/mnt/d/code/Lython/.git/agent-notes/review-20261031/${1:-positional-default-slots-r669}
spec='(FullyQualifiedName~FunctionDefault|FullyQualifiedName~BoundMethodDefault|FullyQualifiedName~NativeTuple|FullyQualifiedName~ReturnedTuple|FullyQualifiedName~TupleConstruction|FullyQualifiedName~MachineInteger|FullyQualifiedName~Generator|FullyQualifiedName~BoundBox)&Category!=Stress'
status=0
for suite in Tests PublicApi.Tests; do
    log="$notes/ubuntu-net10-$suite.log"
    if ! ~/.dotnet/dotnet test "tests/Lokad.Lython.$suite" -c Release -f net10.0 --artifacts-path ~/lython-r669-artifacts --filter "$spec" > "$log" 2>&1; then
        status=1
    fi
    tail -n 8 "$log"
done
exit "$status"
