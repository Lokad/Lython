from pathlib import Path
import ast
import shutil

lab = Path(__file__).resolve().parent
previous = lab.parent / 'positional-default-slots-r669'

def read(path):
    return path.read_text(encoding='utf-8-sig')

def write(path, source):
    if path.suffix == '.py':
        ast.parse(source)
    path.write_text(source, encoding='utf-8', newline='\n')

shutil.copyfile(previous / 'catalog.json', lab / 'catalog.json')
freeze = read(previous / 'freeze-and-verify.py')
freeze = freeze.replace("previous=lab.parent/'child-declaration-preparation-r668'", "previous=lab.parent/'positional-default-slots-r669'")
freeze = freeze.replace("assert manifest['candidateCommit']==ref", "assert manifest['referenceCommit']==ref")
freeze = freeze.replace("source=previous/'frozen/candidate'", "source=previous/'frozen/reference'")
freeze = freeze.replace("files=manifest['images']['candidate']", "files=manifest['images']['reference']")
start = freeze.index("    with (lab/(role+'-verify.log'))")
freeze = freeze[:start] + '''    if role == 'reference':
        assert sha(catalog_path.read_bytes()) == manifest['casesSHA256']
        for kind in ('verify.json', 'verify.log', 'allocation.json', 'allocation.log'):
            shutil.copyfile(previous / ('reference-' + kind), lab / ('reference-' + kind))
        verified = load(lab/'reference-verify.json')
        assert verified['state']=='Completed' and verified['catalogSha256']==manifest['casesSHA256']
        images[role] = expected
        continue
''' + freeze[start:]
write(lab / 'freeze-and-verify.py', freeze)

stage = read(previous / 'stage-repeat.py')
stage = stage.replace('quiet-repeat', 'quiet').replace('positional-default-slots-repeat-b1100', 'positional-default-binding-b1101')
stage = stage.replace('b1100-positional-default-slots-repeat', 'b1101-positional-default-binding')
stage = stage.replace('b1100-fixtures', 'b1101-fixtures')
stage = stage.replace('R669 final positional default tuple from evaluated slots', 'R670 read final positional default slots directly')
stage = stage.replace('launch-repeat.py', 'launch-quiet.py').replace('summarize-repeat.py', 'summarize-quiet.py')
stage = stage.replace("script = script.replace(\"'quiet-summary.json'\", \"'repeat-summary.json'\")", "")
write(lab / 'stage-quiet.py', stage)
