from pathlib import Path

lab = Path(__file__).resolve().parent
previous = lab.parent / 'positional-default-slots-r669'
raw = (previous / 'archive-r669.py').read_text(encoding='utf-8')
base = raw[raw.index('original = (lab.parent'):raw.index('exec(compile(prefix, __file__,')]
exec(compile(base, __file__, 'exec'))
prefix = prefix.replace('2026-11-19-positional-default-slots")', '2026-11-19-positional-default-slots/refinement")')
exec(compile(prefix, __file__, 'exec'))

summary = verify('quiet', 5, 'quiet-summary.json')
before, after = [load(lab / f'{role}-allocation.json')['rows'] for role in ('reference', 'candidate')]
local = []
for left, right in zip(before, after, strict=True):
    assert left['id'] == right['id'] and left['sharedBudgetBaselineRestored'] and right['sharedBudgetBaselineRestored']
    a, b = [statistics.median(row['allocatedBytesPerInvocation']) for row in (left, right)]
    local.append(dict(case=left['id'], allocatedBytes=[a,b], allocatedChangePercent=100*(b/a-1),
                      accountedPeak=[left['peakExecutionMemoryBytes'], right['peakExecutionMemoryBytes']]))
summary['localWarmAllocation'] = local
summary['referenceDeliveredSource'] = 'f8a7920e7'
out.mkdir(exist_ok=False)
save(out / 'summary.json', summary)
quiet = lab / 'quiet'
for name in ('observations.tgz', 'archive-receipt.json', 'terminal-status.json'):
    shutil.copyfile(quiet / name, out / name)
core = lab / 'frozen/candidate/Lokad.Lython.dll'
assert digest(core) == images['candidate'][core.name]
(out / 'measured-core.dll.gz').write_bytes(gzip.compress(core.read_bytes(), mtime=0))
with tarfile.open(out / 'checks-and-procedures.tar.xz', 'w:xz', preset=6) as evidence:
    for name in ('config.json', 'identity.json', 'representative.json', 'remote-launch.py', 'retrieve.py',
                 'observe-not-before.json', 'launch.log', 'collect.py', 'archive-owned.py', 'run.sh'):
        evidence.add(quiet / name, arcname='quiet/' + name)
    for name in ('prepare-scripts.py', 'stage-quiet.py', 'launch-quiet.py', 'summarize-quiet.py',
                 'archive-r670.py', 'freeze-and-verify.py', 'frozen-identity.json', 'catalog.json',
                 'local-pair.log', 'measured-source.patch', 'reference-verify.json', 'candidate-verify.json',
                 'reference-allocation.json', 'candidate-allocation.json', 'frozen-win-net11-build.log',
                 'win-whitebox.log', 'win-public.log', 'ubuntu-net10-Tests.log',
                 'ubuntu-net10-PublicApi.Tests.log', 'retrieval.log'):
        evidence.add(lab / name, arcname=name)
    evidence.add(previous / 'test-ubuntu.sh', arcname='test-ubuntu.sh')
print('Verified 100 golden batches, exact refined source and images, and the archived lease receipt.')
