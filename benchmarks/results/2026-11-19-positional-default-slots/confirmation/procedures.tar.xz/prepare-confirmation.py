from pathlib import Path
import ast

lab = Path(__file__).resolve().parent
stage = (lab / 'stage-quiet.py').read_text(encoding='utf-8')
stage = stage.replace('quiet = lab / "quiet"', 'quiet = lab / "quiet-repeat"')
stage = stage.replace('positional-default-slots-b1099', 'positional-default-slots-repeat-b1100')
stage = stage.replace('b1099-positional-default-slots', 'b1100-positional-default-slots-repeat')
stage = stage.replace('b1099-fixtures', 'b1100-fixtures')
stage = stage.replace('==8', '==5').replace('jobs=8,', 'jobs=5,').replace('eight-job', 'five-job')
stage = stage.replace('"323","400"', '"323","350"').replace('timedelta(seconds=400)', 'timedelta(seconds=350)')
start, end = stage.index('        jobs = ['), stage.index('        source=source[:a]')
jobs = [('calls.defaults.computed','warm'), ('calls.defaults.computed','warm-async'),
        ('scripts.rule-default-closures','warm'), ('scripts.captured-rule-closures','warm'),
        ('calls.defaults.medium','warm')]
stage = stage[:start] + '        jobs = ' + repr(jobs) + '\n' + stage[end:]
start = stage.index('    if name == "archive-owned.py":')
stage = stage[:start] + '''    if name == "collect.py":
        source = source.replace('warmupSeconds=8', 'warmupSeconds=12')
        source = source.replace('accumulate8seconds', 'accumulate12seconds')
        source = source.replace('min(warmed)<8', 'min(warmed)<12').replace('warmed[i]>=8', 'warmed[i]>=12')
        source = source.replace('if job_index >= 2: labels.reverse()',
                                'if job_index % 2 == 0: labels.reverse()')
        assert 'assert len(jobs)==5' in source and 'min(warmed)<12' in source
''' + stage[start:]
stage = stage.replace('"launch-quiet.py", read(template', '"launch-repeat.py", read(template')
stage = stage.replace('"summarize-quiet.py", read(template', '"summarize-repeat.py", read(template')
stage = stage.replace('read(lab / \'summarize-quiet.py\')', 'read(lab / \'summarize-repeat.py\')')
stage = stage.replace('read(lab / \'launch-quiet.py\')', 'read(lab / \'launch-repeat.py\')')
stage += '''
for filename in ('launch-repeat.py', 'summarize-repeat.py'):
    path = lab / filename
    script = read(path).replace("/'quiet'", "/'quiet-repeat'").replace("'quiet/", "'quiet-repeat/")
    script = script.replace("'quiet-summary.json'", "'repeat-summary.json'")
    write(path, script)
'''
ast.parse(stage)
(lab / 'stage-repeat.py').write_text(stage, encoding='utf-8', newline='\n')
