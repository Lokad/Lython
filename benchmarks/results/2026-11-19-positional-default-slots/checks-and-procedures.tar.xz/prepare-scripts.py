from pathlib import Path
import ast
import hashlib
import json
import tarfile

lab = Path(__file__).resolve().parent
template = lab.parent / 'capture-charge-transfer-r666'
donor = lab.parent / 'child-declaration-preparation-r668'

def read(path):
    return path.read_text(encoding='utf-8-sig')

def write(path, source):
    if path.suffix == '.py':
        ast.parse(source)
    path.write_text(source, encoding='utf-8', newline='\n')

historical = Path('benchmarks/results/2026-11-19-funded-function-construction/checks-and-procedures.tar.xz')
with tarfile.open(historical) as evidence:
    catalog = json.load(evidence.extractfile('catalog.json'))
constant_default = 'calls.defaults.medium'
computed_default = 'calls.defaults.computed'
generated = dict(next(case for case in catalog['cases'] if case['id'] == constant_default))
original = 'def add(value, offset=3, *, scale=1):\n    return value + offset + scale\n'
replacement = ('def make(base):\n    def add(value, offset=base + 1, *, scale=1):\n'
               '        return value + offset + scale\n    return add\nadd = make(2)\n')
assert generated['source'].count(original) == 1
generated['source'] = generated['source'].replace(original, replacement)
generated['id'] = computed_default
generated['sourceUtf8Bytes'] = len(generated['source'].encode('utf-8'))
generated['sourceSha256'] = hashlib.sha256(generated['source'].encode('utf-8')).hexdigest()
catalog['cases'].append(generated)
write(lab / 'catalog.json', json.dumps(catalog, indent=2, ensure_ascii=False) + '\n')

freeze = read(template / 'freeze-and-verify.py')
freeze = freeze.replace('capture-charge-transfer-r666', 'positional-default-slots-r669')
freeze = freeze.replace("previous=lab.parent/'retained-runtime-cpython-r661'", "previous=lab.parent/'child-declaration-preparation-r668'")
freeze = freeze.replace("'06b40a712'", "'3156df3b9'")
freeze = freeze.replace("manifest=load(previous/'identity.json')", "manifest=load(previous/'frozen-identity.json')")
freeze = freeze.replace("assert manifest['sourceRevision']==ref", "assert manifest['candidateCommit']==ref\nassert not git('diff','--name-only',ref,'f8a7920e7','--','src','tests')")
freeze = freeze.replace("assert not git('diff','--name-only',ref,can,'--','benchmarks'", "assert not git('diff','--name-only','f8a7920e7',can,'--','benchmarks'")
freeze = freeze.replace("files=manifest['imageFiles']['candidate']", "files=manifest['images']['candidate']")
freeze = freeze.replace('== 6', '== 7').replace('all six', 'all seven')
write(lab / 'freeze-and-verify.py', freeze)

stage = read(template / 'stage-quiet.py')
stage = stage.replace('prior = lab.parent / "retained-runtime-cpython-r661"',
                      'prior = lab.parent / "child-declaration-preparation-r668" / "quiet"')
stage = stage.replace('capture-charge-transfer-b1096', 'positional-default-slots-b1099')
stage = stage.replace('b1096-capture-charge-transfer', 'b1099-positional-default-slots')
stage = stage.replace('b1096-fixtures', 'b1099-fixtures')
stage = stage.replace('R666 transfer the funded local capture cell', 'R669 final positional default tuple from evaluated slots')
stage = stage.replace('six-case', 'seven-case').replace('420', '400')
start, end = stage.index('        jobs = ['), stage.index('        source=source[:a]')
jobs = [
    ('scripts.rule-default-closures', 'warm'), ('scripts.annotated-rule-closures', 'warm'),
    ('scripts.captured-rule-closures', 'warm'), (computed_default, 'warm'),
    (computed_default, 'warm-async'), (constant_default, 'warm'),
    ('scripts.report-forwarding.expanded', 'compile-run'), ('scripts.annotated-rule-closures', 'compile-run'),
]
assert {case for case, lane in jobs} <= {case['id'] for case in catalog['cases']}
stage = stage[:start] + '        jobs = ' + repr(jobs) + '\n' + stage[end:]
stage += '''
staged = load(quiet / 'config.json')
assert sha(quiet / 'candidate' / core) == images['candidate'][core]
assert staged['sourceFiles'] == source_files and staged['sourceRole'] == 'candidate'
assert source_files == images['reference']
assert 'timedelta(seconds=400)' in read(lab / 'launch-quiet.py')
'''
write(lab / 'stage-quiet.py', stage)
