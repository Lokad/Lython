#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/regex-provider-state-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/regex-provider-state-20261122
artifact="$dir/ubuntu"
fixture="$artifact/tests/Lokad.Lython.WorkerFixture/bin/Release/net10.0"
public="$artifact/bin/Lokad.Lython.PublicApi.Tests/release_net10.0"
cp Directory.Build.props "$artifact/Directory.Build.props"
mkdir -p "$fixture" "$public/Fixtures/Workflows"
cp -a "$artifact/bin/Lokad.Lython.WorkerFixture/release_net10.0/." "$fixture/"
cp -a tests/Fixtures/Workflows/Fnmatch tests/Fixtures/Workflows/RegexRewrite "$public/Fixtures/Workflows/"
for name in Lokad.Lython Lokad.Lython.Utf8Regex Lokad.Utf8Regex Lokad.Utf8Regex.PythonRe; do
    cmp "$fixture/$name.dll" "$public/$name.dll"
done
filter='Category!=Stress&(FullyQualifiedName~Regex|FullyQualifiedName~PatternError|FullyQualifiedName~Fnmatch|FullyQualifiedName~Glob)'
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --no-build --filter "$filter" --artifacts-path "$artifact" --nologo 2>&1 | tee "$dir/public-ubuntu-rerun.log"
