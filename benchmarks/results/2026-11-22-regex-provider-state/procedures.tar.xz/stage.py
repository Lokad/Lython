from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
past=lab.parent/"prepared-histogram-refinement-20261122/comparison"
programs=lab.parent/"prepared-histogram-refinement-20261122/comparison"
out=lab/"comparison"
quiet=out/"quiet"
quiet.mkdir(exist_ok=True)
base="/home/lokad/lython-bench-checks"
root=base+"/regex-provider-state-b1403-20261122"
unit="lython-b1403-regex-provider-state-20261122"
core="Lokad.Lython.dll"
def read(path):return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(blob):return hashlib.sha256(blob).hexdigest()
def write(path,value):
    if path.suffix==".py":compile(value,str(path),"exec")
    path.write_text(value,encoding="utf-8",newline="\n")
def save(path,value):write(path,json.dumps(value,indent=2)+"\n")
def committed(relative):return subprocess.check_output(["git","show","origin/master:benchmarks/results/"+relative],cwd=repo)
refs=read(out/"images.json")
files=refs["imageFiles"]
previous=read(past/"quiet/config.json")
donor=previous["identity"]["imageFiles"]["reference"]
assert all(h==donor[n] for n,h in files["reference"].items() if n!=core)
for role,folder in (("reference",out/"frozen-reference"),("candidate",out/"frozen-candidate")):
    expected=files[role]
    assert len(expected)==32 and expected=={name:sha((folder/name).read_bytes())for name in expected}
    evidence=read(out/(role+"-verify.json"))
    assert evidence["state"]=="Completed" and evidence["caseCount"]==5 and evidence["catalogSha256"]==refs["catalogSHA256"]
archive_dir="2026-11-22-prepared-histogram-refined"
receipt=json.loads(committed(archive_dir+"/archive-receipt.json"))
assert all(receipt[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
assert sha(committed(archive_dir+"/observations.tgz"))==receipt["archiveSHA256"]
catalog=out/"catalog.json"
assert sha(catalog.read_bytes())==refs["catalogSHA256"]
identity=dict(sourceRevision=refs["reference"]+" versus "+refs["candidate"],reference=refs["reference"],candidate=refs["candidate"],
              purpose="Pass borrowed provider state without per-operation allocation in the core",
              normalAdapterPin="0.4.0",imageFiles=files,sourcePatchSHA256=refs["sourcePatchSHA256"],
              coreSHA256={role+suffix:values[core]for role,values in files.items()for suffix in ("","-control")},
              catalogs={"representative.json":{"sha256":refs["catalogSHA256"]}})
save(quiet/"identity.json",identity)
shutil.copyfile(catalog,quiet/"representative.json")
for role in ("candidate",):
    (quiet/role).mkdir(exist_ok=True)
    shutil.copyfile(out/f"frozen-{role}"/core,quiet/role/core)
ids=[row["id"] for row in read(catalog)["cases"]]
jobs=[(case,"warm") for case in ids]+[(ids[2],"compile-run")]
assert len(jobs)==6
program_config=read(programs/"quiet/config.json")
for name in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    data=(programs/"quiet"/name).read_text(encoding="utf-8").replace(program_config["root"],root).replace(program_config["unit"],unit).replace("B1402","B1403")
    data=data.replace("len(jobs)==5","len(jobs)==6").replace("len(raw['jobs'])==5","len(raw['jobs'])==6").replace("jobs=5,","jobs=6,").replace("['jobs']==5","['jobs']==6").replace("started < 295","started < 345")
    if name=="collect.py":
        start,end=data.index("\njob_catalog = "),data.index("\nassert len(jobs)")
        data=data[:start]+"\njob_catalog = "+repr({case:"representative.json"for case in ids})+"\njobs = "+repr(jobs)+data[end:]
    if name=="collect.py":
        data=data.replace("if job_index % 2 == 0: labels.reverse()", "if job_index % 2 != 0: labels.reverse()")
    write(quiet/name,data)
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py","candidate/"+core)
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz")as archive:
    for name in parts:archive.add(quiet/name,arcname=name)
unpacked=sum((quiet/name).stat().st_size for name in parts)
threshold=176160768+unpacked+640*1024
available={}
for path in (repo/"benchmarks/results").glob("*/observations.tgz"):
    if path.stat().st_size<8192:continue
    witness=path.parent/"archive-receipt.json"
    if not witness.exists():continue
    value=read(witness)
    if all(value.get(k)for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease")):
        available.setdefault(path.stat().st_size,[]).append((value["archiveSHA256"],path.parent.name))
query=f"""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat
b=Path({base!r})
known={available!r}
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
with (b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not any(p.is_mount() for p in b.glob('*/guest-fixtures'))
 observations=[]
 for p in b.glob('*/observations.tgz'):
  info=p.lstat()
  if(info.st_size not in known or p.resolve()!=p or info.st_nlink!=1 or not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid()
     or p.parent.name=={Path(previous["root"]).name!r}):continue
  digest=sha(p)
  for expected,canonical in known[info.st_size]:
   if digest==expected:observations.append((str(p.relative_to(b)),info.st_size,digest,canonical))
 print(json.dumps(dict(free=shutil.disk_usage(b).free,redundant=observations)))
"""
ssh=["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),"-o","BatchMode=yes","-o","ConnectTimeout=15","lokad@20.166.121.73"]
proof=json.loads(subprocess.check_output(ssh+["python3 -"],input=query.encode(),timeout=35))
save(out/"inventory.json",proof)
def check_archive(folder,digest):
    info=json.loads(committed(folder+"/archive-receipt.json"))
    assert all(info[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
    assert info["archiveSHA256"]==sha(committed(folder+"/observations.tgz"))==digest
retire=[]
free=proof["free"]
if free<=threshold:
    displaced=gzip.decompress(committed(archive_dir+"/candidate-core.dll.gz"))
    displaced_sha=sha(displaced)
    assert displaced_sha==previous["identity"]["imageFiles"]["candidate"][core]
    # Only the previous working candidate is displaced. Its immutable
    # archived binary is verified above and the reused reference remains.
    prior_path=Path(previous["root"]).name
    assert previous["sourceRole"]=="reference"
    retire.append(dict(paths=[prior_path+"/candidate/"+core],bytes=len(displaced),
        sha256=displaced_sha,links=1,
        archives={prior_path+"/observations.tgz":receipt["archiveSHA256"]}))
    free+=len(displaced)
for name,size,digest,folder in sorted(proof["redundant"],key=lambda row:-row[1]):
    if free>threshold+300*1024:break
    check_archive(folder,digest)
    retire.append(dict(paths=[name],bytes=size,sha256=digest,links=1,archives={}))
    free+=size
assert free>threshold,(free,threshold)
config=dict(root=root,unit=unit,identity=identity,source=previous["root"],sourceRole="reference",sourceFiles=donor,
            sourceCatalogSHA256=previous["identity"]["catalogs"]["representative.json"]["sha256"],donorArchiveSHA256=receipt["archiveSHA256"],
            protocolSource=previous["protocolSource"],protocolSHA256=refs["protocolSHA256"],retireGroups=retire,
            payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload.read_bytes()),unpackedBytes=unpacked)
save(quiet/"config.json",config)
data=(programs/"quiet/remote-launch.py").read_text(encoding="utf-8").replace("lython-b1402-fixtures","lython-b1403-fixtures").replace("RuntimeMaxSec=365","RuntimeMaxSec=405")
start,end=data.index("\nc=")+1,data.index("\nb=Path(")
write(quiet/"remote-launch.py",data[:start]+"c="+repr(config)+data[end:])
write(out/"launch.py",(programs/"launch.py").read_text(encoding="utf-8").replace("Refined prepared histogram comparison","Regex provider state comparison").replace("310","355"))
write(out/"summarize.py",(programs/"summarize.py").read_text(encoding="utf-8").replace("len(raw['jobs'])==5","len(raw['jobs'])==6"))
print("Staging verified frozen cores and five complete source goldens on the owned VM.",flush=True)
