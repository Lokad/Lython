from pathlib import Path
import hashlib, json, os, shutil, subprocess, textwrap

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
last = lab.parent / "inline-default-tuple-20261122/comparison"
worktree = repo / ".git/agent-worktrees/regex-provider-state-20261122"
old_words = lab.parent / "inline-cased-word-headers-20261122"
out = lab / "comparison"
out.mkdir(exist_ok=True)

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False)+"\n", encoding="utf-8", newline="\n")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

group_lab=lab.parent/"regex-prepared-group-current-20261122"
template_lab=lab.parent/"regex-template-source-ranges-20261122"
catalog=read(group_lab/"representative.json")
rows={row["id"]:row for row in catalog["cases"]}
rows.update((row["id"],row) for row in read(template_lab/"refined/catalog.json")["cases"])
ids=["scripts.regex-unicode-groups", "scripts.regex-ascii-groups", "diagnostic.regex-template.file",
     "diagnostic.regex-prepared-names.many-named-rules", "calls.positional.large"]
catalog["cases"]=[rows[id] for id in ids]
catalog["performanceQualified"]=False
catalog_path=out/"catalog.json"
write(catalog_path,catalog)

prior=lab.parent/"prepared-histogram-20261122/comparison"
prior_identity=read(prior/"images.json")
donor=prior/"frozen-reference"
donor_files=prior_identity["imageFiles"]["reference"]
assert len(donor_files)==32 and {leaf:sha(donor/leaf) for leaf in donor_files}==donor_files
core="Lokad.Lython.dll"
core_paths={"reference":donor/core, "candidate":worktree/"src/Lokad.Lython/bin/Release/net11.0"/core}
assert sha(core_paths["reference"]) != sha(core_paths["candidate"])
sdk = Path.home()/".dotnet11"
dotnet = sdk/"dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol = repo/"benchmarks/cpython-worker.py"
assert sha(protocol) == read(last/"images.json")["protocolSHA256"]
files = {}
for role,built_core in core_paths.items():
    image = out/f"frozen-{role}"
    image.mkdir(exist_ok=True)
    for leaf in donor_files:
        shutil.copyfile(built_core if leaf==core else donor/leaf,image/leaf)
    files[role] = {**donor_files, core:sha(built_core)}
    assert {leaf:sha(image/leaf) for leaf in donor_files}==files[role]
    receipt=out/f"{role}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog_path,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",receipt],
        cwd=repo,env=env,check=True,timeout=90)
    observed=read(receipt)
    assert observed["state"]=="Completed" and observed["caseCount"]==len(ids) and observed["catalogSha256"]==sha(catalog_path)
ref=subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
cand=subprocess.check_output(["git","rev-parse","HEAD"],cwd=worktree,text=True).strip()
assert ref.startswith("d97fc617c") and ref != cand
assert not subprocess.check_output(["git","diff",prior_identity["reference"],ref,"--","src"],cwd=repo)
assert not subprocess.check_output(["git","status","--porcelain","--untracked-files=no"],cwd=worktree)
patch=out/"source.patch"
patch.write_bytes(subprocess.check_output(["git","diff","--binary",ref,cand,"--","src","tests"],cwd=repo))
write(out/"images.json", dict(reference=ref,candidate=cand,imageFiles=files,protocolSHA256=sha(protocol),
    catalogSHA256=sha(catalog_path), sourcePatchSHA256=sha(patch)))
