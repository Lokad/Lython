using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Text;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.Tests;

public sealed class PreparedFunctionBindingBoundaryTests
{
    [Fact]
    public void NamedHostCallUsesPreparedSlotsBeforeItsBodyCanSuspend()
    {
        const string source = "def keep(value,*,marker='called'):\n globals().update(payload=None)\n with open('events.txt','a') as target: target.write(marker)\n return value\npayload=[]\nreturn keep(value=payload)";
        var syntax = LythonFrontend.Compile(source).Script!;
        var code = ExecutableScript.Compile(LoweredScript.Lower(syntax));
        var site = Assert.Single(code.EntryPoint.CallSites, s => s.PreparedParameterLayout is not null);
        Assert.Equal([0, -1], Assert.IsType<int[]>(site.PreparedParameterSources));
        Assert.Same(Assert.Single(code.EntryPoint.Functions).ParameterLayout, site.PreparedParameterLayout);
    }

    [Fact]
    public void MetadataAdmissionPrecedesPublicationAndPreservesRefusalOrigin()
    {
        const string source = "def pick(a=1,*,b=2): return a\npick(b=8)\n";
        var syntax = new Parser(PythonTokenization.Read(source)).Parse().Script!;
        var definition = Assert.IsType<FunctionDefinitionStatementSyntax>(syntax.Statements[0]);
        var call = Assert.IsType<CallExpressionSyntax>(Assert.IsType<ExpressionStatementSyntax>(syntax.Statements[1]).Expression);
        var budget = new LythonMemoryBudget(1024 * 1024);
        using (var owner = budget.CreateScope())
        {
            var hook = new AdmissionHookMemoryBudget(owner);
            var governor = new MemoryGovernor(hook);
            using var analysis = new StaticAnalysisContext(syntax, governor: governor);
            var before = budget.ReservedBytes;
            hook.RefuseGrowth = _ => true;
            var error = Assert.Throws<LythonRuntimeException>(() =>
                StaticBindingEngine.PrepareFunctionCallBinding(call, definition.ParameterLayout, 0, analysis));
            Assert.Same(governor.AdmissionFailure, error);
            Assert.Equal(LythonFailureReason.SharedMemoryAllowance, error.Attribution?.Reason);
            Assert.Same(call.Span, error.Span);
            Assert.Null(call.PreparedParameterLayout);
            Assert.Null(call.PreparedParameterSources);
            Assert.Equal(before, budget.ReservedBytes);
        }
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ProvenNamedCallNeedsNoRuntimeMappingStorageAndKeepsItsAlias(bool asynchronous)
    {
        const string source = "def pick(a=1,*,b=2): return b\narm(pick)\nreturn pick(b=payload)";
        var syntax = LythonFrontend.Compile(source).Script!;
        var code = ExecutableScript.Compile(LoweredScript.Lower(syntax));
        var site = Assert.Single(code.EntryPoint.CallSites, s => s.PreparedParameterLayout is not null);
        Assert.Equal([-1, 0], Assert.IsType<int[]>(site.PreparedParameterSources));
        Assert.Same(Assert.Single(code.EntryPoint.Functions).ParameterLayout, site.PreparedParameterLayout);
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        using (var owner = budget.CreateScope())
        {
            var hook = new AdmissionHookMemoryBudget(owner);
            var context = new LythonRuntime.ExecutionContext(new MockLythonHost(), new() { MemoryBudget = hook });
            var payload = PyString.FromString(new string('é', 8192), context.MemoryGovernor, null);
            context.Variables["payload"] = payload;
            context.Variables["arm"] = new Arm(hook);
            try
            {
                var value = asynchronous ? await LythonRuntime.ExecuteExecutableCodeObjectAsync(code.EntryPoint, context)
                    : LythonRuntime.ExecuteExecutableCodeObject(code.EntryPoint, context, default, null);
                Assert.Same(payload, value);
                Assert.Equal(new string('é', 8192), payload.AsString());
                Assert.True(budget.ReservedBytes > 0);
                Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
                Assert.Equal(0, context.State.CurrentRecursionDepth);
                Assert.Equal(0, context.State.CurrentInterpreterDepth);
            }
            finally { hook.RefuseGrowth = null; context.State.CloseResources(); }
        }
        Assert.Equal(0, budget.ReservedBytes);
    }

    private sealed class Arm(AdmissionHookMemoryBudget hook) : LythonRuntime.ICallable
    {
        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        {
            Assert.IsType<PyExecutableFunction>(Assert.Single(arguments).Value);
            hook.RefuseGrowth = _ => true;
            return PyNone.Instance;
        }
        public ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
            => new(Invoke(arguments, span, context));
    }
}
