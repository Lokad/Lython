from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
prior = lab.with_name('prepared-machine-constants-20261126')
local = lab/'local'
quiet = lab/'comparison/quiet'
quiet.mkdir(parents=True)

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    path.write_text(value, encoding='utf-8', newline='\n')

def save(path, value):
    write(path, json.dumps(value, indent=2)+'\n')

identity = read(local/'identity.json')
template = prior/'comparison/quiet'
donor_identity = read(template/'identity.json')
core = 'Lokad.Lython.dll'
for role, files in identity['imageFiles'].items():
    assert len(files) == 32 and {p.name: sha(p) for p in (local/role).iterdir()} == files
    assert all(donor_identity['imageFiles']['candidate'][name] == digest for name, digest in files.items() if name != core)
    smoke = read(lab/(role+'-verify.json'))
    assert smoke['state'] == 'Completed' and smoke['caseCount'] == 4
    assert smoke['catalogSha256'] == sha(local/'representative.json')
    assert smoke['launched']['library']['sha256'].lower() == files[core]
donor = read(template/'terminal-status.json')['receipt']
assert donor['complete'] and donor['allWorkersJoined'] and sha(template/'observations.tar.xz') == donor['archiveSHA256']
identity['expectedCPythonSHA256'] = donor_identity['expectedCPythonSHA256']
identity['donorImageFiles'] = donor_identity['imageFiles']['candidate']
identity['purpose'] = 'Quiet confirmation of compilation-owned literal default operands after conflicting local timings.'
ordinary = 'diagnostic.generated-ordinary-definitions'
rules = 'scripts.rule-default-closures'
control = 'diagnostic.shipment-routing-callbacks'
jobs = [[control,'warm-async'], [ordinary,'warm'], [rules,'warm'], [ordinary,'warm-async'], [ordinary,'compile-run']]
save(quiet/'jobs.json', dict(warm=jobs))
for name in ('representative.json','cpython-worker.py'):
    shutil.copyfile(local/name,quiet/name)
assert sha(quiet/'cpython-worker.py') == identity['cpythonWorkerSHA256']
identity['catalogs'] = {name: dict(sha256=sha(quiet/name)) for name in ('representative.json','jobs.json')}
save(quiet/'identity.json', identity)
collector = (template/'collect.py').read_text(encoding='utf-8')
for old, new in [('len(jobs) == 6', 'len(jobs) == 5'), ('lython-b1770-fixtures', 'lython-b1773-fixtures')]:
    assert collector.count(old) == 1
    collector = collector.replace(old,new)
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
shutil.copyfile(template/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
package = quiet/'stage.tar.gz'
entries = [(role+'-core.dll',local/role/core) for role in ('reference','candidate')]
entries.extend((name,quiet/name) for name in ('identity.json','representative.json','jobs.json','collect.py','run.sh','cpython-worker.py'))
with tarfile.open(package,'w:gz',compresslevel=6) as bundle:
    for name,path in entries:
        bundle.add(path,arcname=name,recursive=False)
save(quiet/'upload.json',dict(root='compiled-default-operands-b1773-20261126',payloadSHA256=sha(package),
    payloadBytes=package.stat().st_size,expandedBytes=sum(p.stat().st_size for _,p in entries),donorSHA256=donor['archiveSHA256']))
launcher = (prior/'quiet.py').read_text(encoding='utf-8')
start = launcher.index(" donor=base/")
end = launcher.index(" for role,files in image['imageFiles'].items():", start)
launcher = launcher[:start]+''' donor=base/'prepared-constants-b1770-20261126'/'candidate'
 assert donor.resolve()==donor and {p.name:sha(p) for p in donor.iterdir()}==image['donorImageFiles']
 donor_receipt=json.loads((donor.parent/'archive-receipt.json').read_text())
 assert donor_receipt['complete'] and donor_receipt['archiveSHA256']==cfg['donorSHA256']==sha(donor.parent/'observations.tar.xz')
 for role in ('candidate','reference'):
  (root/role).mkdir()
  for p in donor.iterdir():
   if p.name=='Lokad.Lython.dll': continue
   if p.name.startswith('Lokad.Lython.Benchmarks.'):
    shutil.copyfile(p,root/role/p.name)
   else:
    (root/role/p.name).symlink_to(p)
  (root/(role+'-core.dll')).rename(root/role/'Lokad.Lython.dll')
'''+launcher[end:]
for old,new in [('lython-b1770-prepared-constants-20261126','lython-b1773-compiled-default-operands-20261126'),
                ('len(frames)==7 and len(set(f.name for f in frames))==7','len(frames)==8 and len(set(f.name for f in frames))==8'),
                ('RuntimeMaxSec=325','RuntimeMaxSec=285'),('seconds=241','seconds=191')]:
    assert launcher.count(old)==1
    launcher=launcher.replace(old,new)
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
summarizer = (prior/'summarize-quiet.py').read_text(encoding='utf-8').replace('== 6','== 5').replace('timedBatches=168','timedBatches=140')
compile(summarizer,'summarize-quiet.py','exec')
write(lab/'summarize-quiet.py',summarizer)
