from pathlib import Path
from statistics import median
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.with_name('prepared-machine-constants-20261126')
source = lab.with_name('deferred-callable-locals-refined-20261125')
collector_source = lab.with_name('ready-json-decoder-entry-20261126')

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def write(path, value):
    path.write_text(value, encoding='utf-8', newline='\n')

def save(path, value):
    write(path, json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def hashes(path):
    return {p.name: digest(p) for p in sorted(path.iterdir())}

revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert revision.startswith('dc736119e')
patch = subprocess.check_output(['git', 'diff', '--binary', '--', 'src'], cwd=repo)
assert patch.count(b'\ndiff --git ') == 10
(lab/'candidate.patch').write_bytes(patch)
owner = read(prior/'frozen-identity.json')
donor = prior/'frozen/candidate'
assert len(owner['imageFiles']['candidate']) == 32 and hashes(donor) == owner['imageFiles']['candidate']
local = lab/'local'
local.mkdir()
core = 'Lokad.Lython.dll'
images = {}
for role, directory in [('reference', lab/'reference-source'), ('candidate', repo)]:
    image = local/role
    shutil.copytree(donor, image)
    assert hashes(image) == owner['imageFiles']['candidate']
    shutil.copyfile(directory/'src/Lokad.Lython/bin/Release/net11.0'/core, image/core)
    images[role] = hashes(image)
assert {name for name in images['reference'] if images['reference'][name] != images['candidate'][name]} == {core}

shutil.copyfile(source/'representative.json', local/'representative.json')
shutil.copyfile(repo/'benchmarks/cpython-worker.py', local/'cpython-worker.py')
assert digest(local/'cpython-worker.py') == owner['cpythonWorkerSHA256']
cases = read(local/'representative.json')['cases']
ordinary, rules, control, observer = ('diagnostic.generated-ordinary-definitions', 'scripts.rule-default-closures',
    'diagnostic.shipment-routing-callbacks', 'diagnostic.definition-locals-default')
assert {case['id'] for case in cases} == {ordinary, rules, control, observer}
jobs = [[control, 'warm-async'], [ordinary, 'warm'], [rules, 'compile-run'],
        [ordinary, 'warm-async'], [observer, 'warm'], [ordinary, 'compile-run'], [rules, 'warm']]
save(local/'jobs.json', {'warm': jobs})
identity = dict(sourceRevision=revision, sourcePatchSHA256=digest(lab/'candidate.patch'), imageFiles=images,
    coreSHA256={role+suffix: files[core] for role, files in images.items() for suffix in ('', '-control')},
    cpythonWorkerSHA256=digest(local/'cpython-worker.py'), catalogs={name: {'sha256': digest(local/name)}
        for name in ('representative.json', 'jobs.json')},
    purpose='Compare ordinary definition storage with literal defaults in declaration metadata.')
save(local/'identity.json', identity)

sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
allocation_tool = lab.with_name('json-traversal-20261124')/'reference'
compiler_tool = lab.with_name('shared-name-binding-roots-20261126')
tool_path = next((compiler_tool/'reference-compiler-owner').glob('*.runtimeconfig.json'))
allocations = {}
for role, files in images.items():
    image = local/role
    proof = lab/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',local/'representative.json',
                    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',local/'cpython-worker.py','--out',proof],
                   cwd=repo, env=env, check=True, timeout=88)
    report = read(proof)
    assert report['state'] == 'Completed' and report['caseCount'] == 4
    assert report['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
    assert report['launched']['library']['sha256'].lower() == files[core]
    allocated = lab/(role+'-allocated')
    shutil.copytree(image, allocated)
    assert hashes(allocated) == files
    for executable in allocation_tool.glob('ValidatedAllocation*'):
        shutil.copyfile(executable, allocated/executable.name)
    output = lab/(role+'-allocation.json')
    subprocess.run([dotnet, allocated/'ValidatedAllocation.dll', allocated, local/'representative.json', output],
                   cwd=repo, env=env, check=True, timeout=65)
    allocations[role] = read(output)['rows']
    inspect = lab/(role+'-shape')
    shutil.copytree(source/'inspect/bin/Release/net11.0', inspect)
    shutil.copyfile(image/core, inspect/core)
    result = subprocess.check_output([dotnet, inspect/'RouteProbe.dll', local/'representative.json'],
        cwd=repo, env=env, timeout=35, encoding='utf-8')
    shape = json.loads(result)
    assert shape['core'] == files[core] and shape['definitions'] == 96 and shape['deferredSites'] == 93
    save(lab/(role+'-shape.json'), shape)
    compiler = lab/(role+'-compiler-owner')
    shutil.copytree(tool_path.parent, compiler)
    shutil.copyfile(image/core, compiler/core)
    subprocess.run([dotnet, compiler/tool_path.name.replace('.runtimeconfig.json','.dll'), local/'representative.json',
                    lab/(role+'-compiler.json')], cwd=repo, env=env, check=True, timeout=85)

summary = []
for before, after in zip(allocations['reference'], allocations['candidate'], strict=True):
    assert before['id'] == after['id'] and before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
    summary.append(dict(case=before['id'], bytes=[median(row['allocatedBytesPerInvocation']) for row in (before, after)],
                        peak=[row['peakExecutionMemoryBytes'] for row in (before, after)]))
save(lab/'allocation-summary.json', summary)
print(json.dumps(summary))

collector = (collector_source/'local/collect.py').read_text(encoding='utf-8')
for old, new in [('len(jobs) == 4', 'len(jobs) == 7'), ('accumulate 4 seconds', 'accumulate 3 seconds'),
                 ('warmupSeconds=4, targetBatchSeconds=.35', 'warmupSeconds=3, targetBatchSeconds=.32'),
                 ('lython-json-ready-fixture-', 'lython-compiled-defaults-fixture-')]:
    assert collector.count(old) == 1
    collector = collector.replace(old, new)
compile(collector, 'collect.py', 'exec')
write(local/'collect.py', collector)
shutil.copyfile(collector_source/'local/run.sh', local/'run.sh')
runner = (prior/'run-local.sh').read_text(encoding='utf-8').replace(prior.name, lab.name)
write(lab/'run-local.sh', runner)
assert all(b'\r' not in p.read_bytes() for p in (lab/'run-local.sh', local/'run.sh'))
shutil.copyfile(prior/'summarize.py', lab/'summarize.py')
