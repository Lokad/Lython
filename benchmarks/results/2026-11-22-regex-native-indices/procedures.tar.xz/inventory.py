from pathlib import Path
import json
import subprocess

lab=Path(__file__).resolve().parent
ssh=["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),
     "-o","BatchMode=yes","-o","ConnectTimeout=15","lokad@20.166.121.73"]
source="""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat
b=Path('/home/lokad/lython-bench-checks')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
with (b/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not any(p.is_mount() for p in b.glob('*/guest-fixtures'))
 retired=b/'json-outer-frame-b1375-20261122/candidate/Lokad.Lython.dll'
 current=b/'json-direct-mapping-b1376-20261122/candidate/Lokad.Lython.dll'
 donor=b/'ordered-regex-group-metadata-b1342-20261122/representative.json'
 root=b/'ordered-regex-group-metadata-b1342-20261122'
 assert sha(root/'observations.tgz')==json.loads((root/'archive-receipt.json').read_text())['archiveSHA256']
 old=retired.lstat()
 paths=[]
 for p in b.glob('*/*/Lokad.Lython.dll'):
  m=p.lstat()
  if (old.st_dev,old.st_ino)==(m.st_dev,m.st_ino):
   assert p.resolve()==p and stat.S_ISREG(m.st_mode) and m.st_uid==os.getuid()
   paths.append(str(p.relative_to(b)))
 assert len(paths)==old.st_nlink
 archives={name+'/observations.tgz':sha(b/name/'observations.tgz') for name in {p.split('/')[0] for p in paths}}
 print(json.dumps(dict(free=shutil.disk_usage(b).free,bytes=old.st_size,sha256=sha(retired),
                       paths=sorted(paths),links=old.st_nlink,archives=archives,
                       current=sha(current),catalogSHA256=sha(donor))))
"""
remote=subprocess.run(ssh+["python3 -"],input=source.encode("utf-8"),capture_output=True,
                      timeout=45,check=True)
record=json.loads(remote.stdout)
(lab/"inventory.json").write_bytes(remote.stdout)
print(json.dumps(record,indent=2))
