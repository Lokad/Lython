from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
notes=lab.parent
previous=notes/"json-direct-mapping-20261122"
donor=previous/"quiet"
catalog_donor=notes/"ordered-regex-group-metadata-20261122"/"quiet"
out=lab/"quiet"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, text):
    if path.suffix==".py":compile(text,str(path),"exec")
    path.write_text(text,encoding="utf-8",newline="\n")

def save(path, obj):
    write(path,json.dumps(obj,indent=2)+"\n")

def pushed(name):
    return subprocess.check_output(["git","show","origin/master:benchmarks/results/"+name],cwd=repo)

inventory=read(lab/"inventory.json")
history={
    "json-outer-frame-b1375-20261122":"2026-11-22-json-outer-frame",
    "json-direct-mapping-b1376-20261122":"2026-11-22-json-direct-mapping",
    "json-positional-control-b1377-20261122":"2026-11-22-json-positional-control",
    "json-positional-fixed-tier-b1379-20261122":"2026-11-22-json-positional-fixed-tier",
    "positional-default-tier-b1380-20261122":"2026-11-22-positional-default-tier-attribution",
}
assert set(inventory["archives"])=={name+"/observations.tgz" for name in history}
for vm_name,local_name in history.items():
    receipt=json.loads(pushed(local_name+"/archive-receipt.json"))
    assert all(receipt[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
    assert sha(pushed(local_name+"/observations.tgz"))==inventory["archives"][vm_name+"/observations.tgz"]==receipt["archiveSHA256"]
canonical=gzip.decompress(pushed(history["json-outer-frame-b1375-20261122"]+"/candidate-core.dll.gz"))
assert len(canonical)==inventory["bytes"] and sha(canonical)==inventory["sha256"]
retire={k:inventory[k] for k in ("paths","links","bytes","sha256","archives")}
current=read(donor/"config.json")
receipt=read(donor/"archive-receipt.json")
assert all(receipt[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
assert sha((donor/"observations.tgz").read_bytes())==receipt["archiveSHA256"]
image=read(lab/"images.json")
files=image["imageFiles"]
core="Lokad.Lython.dll"
assert files["reference"]==current["identity"]["imageFiles"]["candidate"]
assert files["reference"][core]==inventory["current"]
old=read(catalog_donor/"config.json")
catalog=catalog_donor/"representative.json"
assert sha(catalog.read_bytes())==image["catalogSHA256"]==inventory["catalogSHA256"]
catalog_receipt=read(catalog_donor/"archive-receipt.json")
assert all(catalog_receipt[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
assert sha((catalog_donor/"observations.tgz").read_bytes())==catalog_receipt["archiveSHA256"]
assert image["protocolSHA256"]==current["protocolSHA256"]
for role, expected in files.items():
    assert len(expected)==32 and {n:sha((lab/"frozen"/role/n).read_bytes()) for n in expected}==expected
    proof=read(lab/f"{role}-verify.json")
    assert proof["state"]=="Completed" and proof["caseCount"]==5 and proof["catalogSha256"]==image["catalogSHA256"]
out.mkdir()
root="/home/lokad/lython-bench-checks/regex-inline-indices-b1381-20261122"
unit="lython-b1381-regex-inline-indices-20261122"
catalogs={"representative.json":dict(path=old["root"]+"/representative.json",sha256=image["catalogSHA256"])}
identity=dict(sourceRevision=image["reference"]+" versus "+image["candidate"],
              purpose="Use the existing dictionary integer slots for named capture indices",
              normalAdapterPin="0.4.0",imageFiles=files,catalogs=catalogs,
              coreSHA256={role+suffix:h[core] for role,h in files.items() for suffix in ("","-control")})
save(out/"identity.json",identity)
jobs=[(case["id"],"warm") for case in read(catalog)["cases"]]
assert len(jobs)==5
for name in ("collect.py","archive-owned.py","run.sh","retrieve.py"):
    text=(donor/name).read_text(encoding="utf-8").replace(current["root"],root).replace(current["unit"],unit).replace("B1376","B1381")
    if name=="collect.py":
        start,end=text.index("\njob_catalog = "),text.index("\nassert len(jobs)")
        mapping={case:"representative.json" for case,lane in jobs}
        text=text[:start]+"\njob_catalog = "+repr(mapping)+"\njobs = "+repr(jobs)+text[end:]
        text=text.replace("root / 'expansion.json'","root / 'representative.json'")
        text=text.replace("len(jobs)==4","len(jobs)==5").replace("started < 245","started < 290")
    elif name in ("archive-owned.py","retrieve.py"):
        text=text.replace("jobs=4,","jobs=5,").replace("['jobs']==4","['jobs']==5").replace("len(raw['jobs'])==4","len(raw['jobs'])==5")
    write(out/name,text)
assert b"\r" not in (out/"run.sh").read_bytes()
(out/"candidate").mkdir()
shutil.copyfile(lab/"frozen/candidate"/core,out/"candidate"/core)
parts=("identity.json","collect.py","archive-owned.py","run.sh","candidate/"+core)
payload=out/"payload.tgz"
with tarfile.open(payload,"w:gz") as a:
    for name in parts:a.add(out/name,arcname=name)
unpacked=sum((out/n).stat().st_size for n in parts)
assert inventory["free"]+retire["bytes"]>176160768+unpacked+640*1024
stage=dict(root=root,unit=unit,identity=identity,source=current["root"],sourceRole="candidate",
           sourceFiles=files["reference"],sourceCatalogSHA256=current["catalogs"]["expansion.json"]["sha256"],
           donorArchiveSHA256=receipt["archiveSHA256"],protocolSource=current["protocolSource"],
           protocolSHA256=current["protocolSHA256"],payloadBytes=payload.stat().st_size,
           payloadSHA256=sha(payload.read_bytes()),retireGroups=[retire],catalogs=catalogs,unpackedBytes=unpacked)
save(out/"config.json",stage)
remote=(donor/"remote-launch.py").read_text(encoding="utf-8")
start,end=remote.index("\nc=")+1,remote.index("\nb=Path(")
remote=remote[:start]+"c="+repr(stage)+remote[end:]
remote=remote.replace("sha(source/'representative.json')","sha(source/'expansion.json')").replace("RuntimeMaxSec=295","RuntimeMaxSec=342")
remote=remote.replace("lython-b1376-fixtures","lython-b1381-fixtures")
write(out/"remote-launch.py",remote)
write(lab/"launch.py",(previous/"launch.py").read_text(encoding="utf-8")
      .replace("Direct JSON keyword mapping comparison","Native named-index comparison").replace("255","315"))
write(lab/"summarize.py",(previous/"summarize.py").read_text(encoding="utf-8").replace("len(raw['jobs'])==4","len(raw['jobs'])==5"))
print("Staged both frozen images and five verified regex workloads.")
