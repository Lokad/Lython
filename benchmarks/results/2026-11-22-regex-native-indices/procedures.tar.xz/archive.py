from pathlib import Path
import gzip
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / "quiet"
result = repo / "benchmarks/results/2026-11-22-regex-native-indices"

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def save(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8", newline="\n")

def sha(data):
    return hashlib.sha256(data).hexdigest()

receipt = load(quiet / "archive-receipt.json")
status = load(quiet / "terminal-status.json")
assert status["receipt"] == receipt
assert all(receipt[key] for key in ("complete", "allWorkersJoined", "archivedAndVerifiedUnderLease", "quietBeforeAndAfter"))
assert receipt["jobs"] == 5 and sha((quiet / "observations.tgz").read_bytes()) == receipt["archiveSHA256"]
summary = load(quiet / "quiet-summary.json")
assert summary["complete"] and len(summary["rows"]) == 5
decision = sys.argv[1]
assert decision in ("retained", "private")
identity = load(lab / "images.json")
identity["productionRevision"] = sys.argv[2] if decision == "retained" else None
identity["outcome"] = decision
patch = subprocess.check_output(["git", "diff", identity["reference"], identity["candidate"], "--", "src", "tests"], cwd=repo)
root_patch = (lab / "source.patch").read_bytes()
assert sha(root_patch) == identity["sourcePatchSHA256"]
identity["measuredPatchSHA256"] = sha(patch)
(lab / "measured.patch").write_bytes(patch)
def normalize_hunk_locations(diff):
    return re.sub(rb"^@@ -\d+(,\d+)? \+\d+(,\d+)? @@", rb"@@ -x\1 +y\2 @@", re.sub(rb"^index [^\n]+\n", b"", diff, flags=re.M), flags=re.M)
# The already qualified key protocol changes the location of the LastGroup
# hunk and its containing blob, leaving every edited line and context intact.
assert normalize_hunk_locations(root_patch) == normalize_hunk_locations(patch)
if decision == "retained":
    delivery = subprocess.check_output(["git", "diff", identity["productionRevision"] + "^", identity["productionRevision"], "--", "src", "tests"], cwd=repo)
    assert delivery == root_patch
for role, files in identity["imageFiles"].items():
    assert len(files) == 32
    assert {name: sha((lab / "frozen" / role / name).read_bytes()) for name in files} == files
    verify = load(lab / (role + "-verify.json"))
    assert verify["state"] == "Completed" and verify["caseCount"] == 5 and verify["catalogSha256"] == identity["catalogSHA256"]

result.mkdir(exist_ok=True)
for name in ("observations.tgz", "archive-receipt.json", "terminal-status.json"):
    shutil.copyfile(quiet / name, result / name)
shutil.copyfile(lab / "allocation-summary.json", result / "allocation-summary.json")
save(result / "source.json", identity)
del summary["retentionDecisionPending"]
summary["outcome"] = decision
save(result / "summary.json", summary)
core = (quiet / "candidate/Lokad.Lython.dll").read_bytes()
assert sha(core) == identity["imageFiles"]["candidate"]["Lokad.Lython.dll"]
with (result / "candidate-core.dll.gz").open("wb") as output:
    with gzip.GzipFile(filename="", fileobj=output, mode="wb", mtime=0) as payload:
        payload.write(core)
assert gzip.decompress((result / "candidate-core.dll.gz").read_bytes()) == core
paths = (
    "source.patch", "measured.patch", "test.sh", "white-ubuntu.log", "public-ubuntu.log", "white-windows.log", "public-windows.log",
    "reference-verify.json", "candidate-verify.json", "reference-allocation.json", "candidate-allocation.json",
    "inventory.py", "inventory.json", "prepare.py", "measure.py", "launch.py", "summarize.py", "archive.py",
    "quiet/observe-not-before.json", "quiet/launch.log", "quiet/identity.json", "quiet/config.json",
    "quiet/remote-launch.py", "quiet/run.sh", "quiet/collect.py", "quiet/archive-owned.py", "quiet/retrieve.py",
)
for name in ("white-ubuntu.log", "public-ubuntu.log", "white-windows.log", "public-windows.log"):
    assert "Passed!" in (lab / name).read_text(encoding="utf-8-sig")
with tarfile.open(result / "procedures.tar.xz", "w:xz") as archive:
    for name in paths:
        archive.add(lab / name, arcname=name)
with tarfile.open(result / "procedures.tar.xz") as archive:
    assert set(archive.getnames()) == set(paths)
