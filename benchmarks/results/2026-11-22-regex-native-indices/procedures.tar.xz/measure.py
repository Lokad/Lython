from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
notes=lab.parent
donor=notes/"json-direct-mapping-20261122"
history=notes/"ordered-regex-group-metadata-20261122"
core="Lokad.Lython.dll"
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"

def load(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))

def save(p, v):
    p.write_text(json.dumps(v,indent=2)+"\n",encoding="utf-8",newline="\n")

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

identity=load(donor/"images.json")
baseline=identity["candidate"]
base=donor/"frozen/candidate"
expected=identity["imageFiles"]["candidate"]
assert len(expected)==32 and {n:sha(base/n) for n in expected}==expected
assert sha(protocol)==identity["protocolSHA256"]
trial=repo/".git/agent-worktrees/native-regex-indices-20261122"
reference=subprocess.check_output(["git","-C",trial,"rev-parse","HEAD^"],text=True).strip()
candidate=subprocess.check_output(["git","-C",trial,"rev-parse","HEAD"],text=True).strip()
assert reference==baseline and not subprocess.check_output(["git","-C",trial,"status","--porcelain"])
fresh=lab/"windows-image-build/bin/Lokad.Lython/release_net11.0"/core
catalog=history/"quiet/representative.json"
case_ids=[c["id"] for c in load(catalog)["cases"]]
assert len(case_ids)==5
images={}
allocations={}
for role in ("reference","candidate"):
    image=lab/"frozen"/role
    image.mkdir(parents=True)
    for name in expected:
        path=fresh if name==core and role=="candidate" else base/name
        shutil.copyfile(path,image/name)
    for path in base.glob("ValidatedAllocation.*"):
        shutil.copyfile(path,image/path.name)
    images[role]={n:sha(image/n) for n in expected}
    receipt=lab/f"{role}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",receipt],
        env=env,check=True,timeout=95)
    proof=load(receipt)
    assert proof["state"]=="Completed" and proof["caseCount"]==5 and proof["catalogSha256"]==sha(catalog)
    raw=lab/f"{role}-allocation.json"
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,catalog,raw],env=env,check=True,timeout=100)
    allocations[role]=load(raw)["rows"]
    assert all(row["sharedBudgetBaselineRestored"] for row in allocations[role])
    assert {n:sha(image/n) for n in expected}==images[role]
assert images["reference"]==expected
assert [n for n in expected if images["reference"][n]!=images["candidate"][n]]==[core]
rows=[]
for a,b in zip(allocations["reference"],allocations["candidate"],strict=True):
    assert a["id"]==b["id"]
    before,after=(statistics.median(row["allocatedBytesPerInvocation"]) for row in (a,b))
    rows.append(dict(case=a["id"],reference=before,candidate=after,allocationChange=100*(after/before-1),
                     admittedReference=a["peakExecutionMemoryBytes"],admittedCandidate=b["peakExecutionMemoryBytes"]))
save(lab/"allocation-summary.json",rows)
save(lab/"images.json",dict(reference=reference,candidate=candidate,imageFiles=images,catalogSHA256=sha(catalog),
                           protocolSHA256=sha(protocol),sourcePatchSHA256=sha(lab/"source.patch")))
for row in rows:print(row,flush=True)
