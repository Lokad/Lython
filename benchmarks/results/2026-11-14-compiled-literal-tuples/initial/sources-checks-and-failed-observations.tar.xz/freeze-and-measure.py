from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;prior=r.parent/'closure-scalars-r349';reference=json.loads((r/'reference-identity.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8'));assert len(checks)==4 and all(x['returncode']==0 for x in checks)
sources={p:sha(p)for p in reference['sources']};changed=[p for p in sources if sources[p]!=reference['sources'][p]];assert changed==['src/Lokad.Lython/Frontend/ExecutableScript.Expressions.cs']
env=dict(os.environ);originalPath=next(v for k,v in env.items()if k.casefold()=='path')
for key in list(env):
 if key.casefold()=='path':del env[key]
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+originalPath
with(r/'candidate-build.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0 and sources=={p:sha(p)for p in sources}
for role in ['reference','candidate']:shutil.copytree(prior/'candidate',r/role)
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll');shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),referenceProductionCommit='e235b18b',referenceQualification='GREEN43571864663 Windows/Ubuntu actual11/10, original stress and installed Release consumers;581source proof/16summaries cached.',coreSHA256={role:sha(r/role/'Lokad.Lython.dll')for role in ['reference','candidate']},sources=sources,productionFiles=len(sources),changedProductionInputs=changed,removedMechanisms=['per-evaluation immutable literal tuple backing/copy/construction admission','child LoadConst instructions plus MakeTuple for complete same-block immutable literal expressions','proposed extra purity syntax walk; existing emitted facts supply the proof'],newStorage='One immutable PyTuple and backing under existing coarse compilation admission. Dynamic tuples/starred displays retain real operations. No new memory owner/ledger/cache/policy.',auxiliaryFiles={role:{p.name:sha(p)for p in(r/role).iterdir()if p.is_file()and p.name!='Lokad.Lython.dll'}for role in ['reference','candidate']},qualified=False,sourceAndScriptDifferIntentionally=False)
assert identity['auxiliaryFiles']['reference']==identity['auxiliaryFiles']['candidate'];(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
 for p in sources:t.add(p,arcname=p)
catalog=json.loads((r.parent/'iteration-checkpoint-r347/b717/catalog.json').read_text(encoding='utf-8'));wanted=['scripts.csv-invoice.large','scripts.csv-fulfillment.large','scripts.text-summary-helpers.nonlocal-counter.large'];catalog['cases']=[next(c for c in catalog['cases']if c['id']==name)for name in wanted]
(r/'catalog.json').write_text(json.dumps(catalog,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
for role in ['reference','candidate']:shutil.copyfile(r/'catalog.json',r/('allocation-'+role+'-catalog.json'))
for name in ['verify-worker.py','measure-allocation.py']:shutil.copyfile(prior/name,r/name)
# Keep Windows environment names unique for descendant process lookup.
p=r/'measure-allocation.py';s=p.read_text(encoding='utf-8');old="env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH'];sdk=env['DOTNET_ROOT']+'/dotnet.exe'";assert old in s
s=s.replace(old,"env=dict(os.environ);originalPath=next(v for k,v in env.items()if k.casefold()=='path');env={k:v for k,v in env.items()if k.casefold()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+originalPath;sdk=env['DOTNET_ROOT']+'/dotnet.exe'")
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');row='| Active R351 prototype | Frozen`'+identity['coreSHA256']['candidate'][:8]+'`, one production file changed from qualifiede235/71ba. Existing builder replaces immutable emitted constant runs; no new pass/owner.135internal/476public per actual11/10 pass (1,222total), including11isolated Python controls and retained results. Initial six probe-launch failures are preserved; pinned child PATH/runtime fixes them without source/assertion changes. Allocation/CPU/compilation impact and full delivery unqualified. |\n'
anchor='| Current CPython comparison |';assert anchor in s;s=s.replace(anchor,row+anchor,1)
s=s.replace('   Existing coarse compilation admission funds literal/code storage;', '   Prototype is implemented in one file, with1,222focused actual11/10 cases green.\n   Before retention, quantify native constant-return unpacking as well as normal\n   invoice construction; existing dynamic helper-return optimization must survive.\n   Existing coarse compilation admission funds literal/code storage;');p.write_text(s,encoding='utf-8',newline='\n')
print('Frozen R351',identity['coreSHA256'],'581inputs/1changed; short allocation diagnostic next.',flush=True)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'verify-worker.py')],check=True,env=env)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'measure-allocation.py')],check=True,env=env)
