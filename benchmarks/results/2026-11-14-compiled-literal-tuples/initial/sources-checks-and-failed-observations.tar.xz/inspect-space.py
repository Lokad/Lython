from pathlib import Path
import base64,hashlib,json,subprocess,tarfile
r=Path(__file__).parent;canonical=Path('benchmarks/results/2026-11-14-shared-integer-chains/source-checks.tar.xz');commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
blob=subprocess.check_output(['git','show',commit+':'+canonical.as_posix()]);assert hashlib.sha256(blob).digest()==hashlib.sha256(canonical.read_bytes()).digest()
with tarfile.open(canonical)as t:core=t.extractfile('candidate-core.dll').read()
proof=dict(canonicalCommit=commit,canonicalArchive=canonical.as_posix(),canonicalArchiveSHA256=hashlib.sha256(blob).hexdigest(),member='candidate-core.dll',coreSHA256=hashlib.sha256(core).hexdigest(),coreBytes=len(core),reason='Superseded53 R341 working core only, canonical source/core/observations retained; fully qualified current71ba and8ae external baseline stay protected.')
assert proof['coreSHA256']=='53becdb661d8089c0bf76140cc6b6ee84172f4c5718944e279d3f83d6cfbe31e'
(r/'space-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
proof=PROOF
base=Path('/home/lokad/lython-bench-checks').resolve();anchor=base/'shared-arithmetic-b711-20261114/candidate/Lokad.Lython.dll'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert anchor.resolve()==anchor and hashlib.sha256(anchor.read_bytes()).hexdigest()==proof['coreSHA256']
 meta=anchor.lstat();assert stat.S_ISREG(meta.st_mode)and meta.st_uid==os.getuid()and meta.st_size==proof['coreBytes']
 aliases=[]
 for pattern in ['*/candidate/Lokad.Lython.dll','*/reference/Lokad.Lython.dll','*/candidate-core.dll','*/reference-core.dll','*/current-core.dll']:
  for p in base.glob(pattern):
   s=p.lstat()
   if(s.st_dev,s.st_ino)!=(meta.st_dev,meta.st_ino):continue
   root=p.parent.parent if p.parent.name in ['candidate','reference']else p.parent
   aliases.append(dict(path=str(p),root=str(root),resolved=str(p.resolve()),regular=stat.S_ISREG(s.st_mode),uid=s.st_uid,links=s.st_nlink,inode=s.st_ino,device=s.st_dev,bytes=s.st_size,exitCode=(root/'exit-code.txt').read_text().strip()if(root/'exit-code.txt').exists()else None,mountPresent=(root/'guest-fixtures').exists()))
 assert len(aliases)==meta.st_nlink and len({x['path']for x in aliases})==len(aliases),(meta.st_nlink,aliases)
 print(json.dumps(dict(readOnly=True,proof=proof,allAliases=aliases,freeBytes=shutil.disk_usage(base).free,current71baSHA256=hashlib.sha256((base/'captured-scalar-b720-20261114/candidate/Lokad.Lython.dll').read_bytes()).hexdigest(),current8aeSHA256=hashlib.sha256((base/'iteration-checkpoint-b717-20261114/candidate/Lokad.Lython.dll').read_bytes()).hexdigest())))
'''.replace('PROOF',repr(proof));compile(code,'inspection','exec');(r/'space-inspection-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=45);(r/'space-inspection.log').write_text(done.stdout+done.stderr,encoding='utf-8',newline='\n');assert done.returncode==0,done.stderr
(r/'space-inspection.json').write_text(done.stdout,encoding='utf-8',newline='\n');print(done.stdout,flush=True)
