from pathlib import Path
import ast,hashlib,json,subprocess
r=Path(__file__).parent;out=r/'return-control-corrected';out.mkdir(exist_ok=False)
catalog=json.loads((r/'return-control/allocation-reference-catalog.json').read_text(encoding='utf-8'))
for c in catalog['cases']:
 fixture=dict(size=c['size'],text='',inputFiles={},outputFiles={});c['fixtureJson']=json.dumps(fixture,separators=(',',':'));c['fixtureSha256']=hashlib.sha256(c['fixtureJson'].encode()).hexdigest()
for role in ['reference','candidate']:(out/('allocation-'+role+'-catalog.json')).write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8',newline='\n')
# Validate through the actual frozen worker protocol before any further VM run.
script=(r/'verify-worker.py').read_text(encoding='utf-8').replace("(r/'candidate-identity.json')","(r.parent/'candidate-identity.json')").replace("(r/role)","(r.parent/role)").replace('r/role/','r.parent/role/').replace("r.parent/'utf8-byte-ownership-r334","r.parent.parent/'utf8-byte-ownership-r334").replace("r/'catalog.json'","r/'allocation-reference-catalog.json'").replace('range(3)','range(len(cases))')
ast.parse(script);(out/'verify-worker.py').write_text(script,encoding='utf-8',newline='\n')
(out/'reason.json').write_text(json.dumps(dict(reason='B722 diagnostic catalog omitted required fixture size/text metadata. Preserve original invalid catalog/startup failures; correct only fixture metadata, keep source/stdout/file goldens and old frozen01fd/71ba bits. Actual worker Ready/verify now required before VM use.',sourceAndScriptDifferIntentionally=False),indent=2)+'\n',encoding='utf-8',newline='\n')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(out/'verify-worker.py')],check=True)
