from pathlib import Path
import shutil
r=Path(__file__).parent;old=r/'initial-public-controls';old.mkdir(exist_ok=False)
for source,name in [(r/'create-public-cases.py','create-public-cases.py'),(r/'python-controls.json','python-controls.json'),(Path('tests/Lokad.Lython.PublicApi.Tests/LiteralTupleExecutionTests.cs'),'LiteralTupleExecutionTests.cs')]:shutil.copyfile(source,old/name)
p=r/'create-public-cases.py';s=p.read_text(encoding='utf-8').replace('import hashlib,json,subprocess','import hashlib,json,subprocess,tempfile')
marker="}\nrecords=[]";assert marker in s
extra={
'slice-and-concat':"t=(1,2,3,4,5)\nprint(t[:],t[::-1],t[1::2],t[4:0:-2],t[8:],t[:0:-2])\nprint(t+(6,7),(8,)+t,t+(),()+t)\n",
'nested-derived-aliases':"a=((1,2),(3,4))\nb=a[::-1]+a\nprint(b,b[0] is a[1],b[2] is a[0],a)\n",
'slice-index-io':"class Bound:\n def __index__(self):\n  with open('bound.txt') as source:return int(source.read())\nt=(1,2,3,4)\nprint(t[Bound():],t[:Bound()])\n",
}
literal=''.join(repr(k)+':'+repr(v)+',\n'for k,v in extra.items());s=s.replace(marker,literal+marker,1)
s=s.replace(" done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],capture_output=True,timeout=10)"," with tempfile.TemporaryDirectory(prefix='lython-tuple-golden-')as folder:\n  Path(folder,'bound.txt').write_text('1',encoding='utf-8')\n  done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=folder,capture_output=True,timeout=10)")
s=s.replace('            using (var result = script.Run(new MockLythonHost()))', '''            var immediate = new MockLythonHost(); immediate.SeedFile("/bound.txt", "1");
            var delayed = new DelayedLythonHost(); delayed.SeedFile("/bound.txt", "1");
            using (var result = script.Run(immediate))''').replace('using (var result = await script.RunAsync(new MockLythonHost()))','using (var result = await script.RunAsync(delayed))').replace('            Assert.Equal(baseline, budget.ReservedBytes);\n        }','''            Assert.Equal(baseline, budget.ReservedBytes);
            if (name == "slice-index-io")
            {
                Assert.True(delayed.CompletedAsynchronously > 0);
                Assert.Equal(2, immediate.ClosedFileCount);
                Assert.Equal(2, delayed.ClosedFileCount);
            }
        }''',1)
p.write_text(s,encoding='utf-8',newline='\n')
print('Existing controls preserved; derived storage and actual asynchronous index goldens added.',flush=True)
