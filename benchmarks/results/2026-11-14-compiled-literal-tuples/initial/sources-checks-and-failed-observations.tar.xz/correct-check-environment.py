from pathlib import Path
import json,os,shutil,subprocess
r=Path(__file__).parent;failed=r/'initial-probe-environment-failure'
if not failed.exists():
 failed.mkdir()
 for name in ['focused-checks.json','check-related.py','probe-build-net11.0.log','Lokad.Lython.Tests-net11.0.log','Lokad.Lython.PublicApi.Tests-net11.0.log']:shutil.copyfile(r/name,failed/name)
 for name in ['Lokad.Lython.Tests-net11.0','Lokad.Lython.PublicApi.Tests-net11.0']:shutil.copytree(r/name,failed/name)
env=dict(os.environ);originalPath=next(v for k,v in env.items()if k.casefold()=='path')
for key in list(env):
 if key.casefold()=='path':del env[key]
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+originalPath
probe='tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll'
records=[]
for label,environment in [('original',None),('pinned',env)]:
 executable='dotnet'if environment is None else shutil.which('dotnet',path=environment['PATH'])
 done=subprocess.run([executable,probe,'--help'],env=environment,capture_output=True,text=True,encoding='utf-8',timeout=15)
 records.append(dict(environment=label,returncode=done.returncode,stdout=done.stdout,stderr=done.stderr))
assert records[0]['returncode']!=0 and records[1]['returncode']==0,records
(failed/'probe-launch-proof.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n')
setup="""env=dict(os.environ)
originalPath=next(v for k,v in env.items()if k.casefold()=='path')
for key in list(env):
 if key.casefold()=='path':del env[key]
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+originalPath
"""
s=(r/'check-related.py').read_text(encoding='utf-8').replace('import json,subprocess','import json,os,subprocess')
s='\n'.join(line for line in s.splitlines()if not line.startswith('env={'))+'\n'
if 'originalPath='not in s:s=s.replace("r=Path(__file__).parent;dotnet='C:/Users/JoannesVermorel/.dotnet11/dotnet.exe'", "r=Path(__file__).parent;dotnet='C:/Users/JoannesVermorel/.dotnet11/dotnet.exe'\n"+setup)
if 'env=env,stdout=f'not in s:s=s.replace('stdout=f,stderr=subprocess.STDOUT)', 'env=env,stdout=f,stderr=subprocess.STDOUT)')
(r/'check-related.py').write_text(s,encoding='utf-8',newline='\n')
print('Original probe failure preserved:',records[0]['returncode'],'; pinned launch:',records[1]['returncode'],flush=True)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'check-related.py')],check=True)
