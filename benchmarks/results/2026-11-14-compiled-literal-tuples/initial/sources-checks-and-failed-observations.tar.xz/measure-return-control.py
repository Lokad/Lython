from pathlib import Path
import ast,copy,hashlib,json,subprocess
r=Path(__file__).parent;out=r/'return-control';out.mkdir(exist_ok=False)
base=json.loads((r/'catalog.json').read_text(encoding='utf-8'));cases=[]
for name,definition,call in [('constant','def pair():return (1,2,3,4)','pair()'),('dynamic','def pair(x):return x,x+1,x+2,x+3','pair(i)')]:
 source=definition+'\ntotal=0\nfor i in range(4096):\n a,b,c,d='+call+'\n total+=a+b+c+d\nprint(total)\n'
 done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],capture_output=True,timeout=10);assert done.returncode==0,done.stderr
 expected=done.stdout.decode('utf-8').replace('\r\n','\n');fixture=json.dumps(dict(inputFiles={},outputFiles={}),separators=(',',':'))
 case=copy.deepcopy(base['cases'][0]);case.update(id='diagnostic.tuple-return.'+name,family='scripts',category='tuple-return',source=source,fixtureJson=fixture,expectedOutput=expected,sourceUtf8Bytes=len(source.encode()),expectedOutputUtf8Bytes=len(expected.encode()),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=hashlib.sha256(source.encode()).hexdigest(),fixtureSha256=hashlib.sha256(fixture.encode()).hexdigest(),expectedOutputSha256=hashlib.sha256(expected.encode()).hexdigest(),expectedFilesSha256=hashlib.sha256(bytes(4)).hexdigest());cases.append(case)
base['cases']=cases
for role in ['reference','candidate']:(out/('allocation-'+role+'-catalog.json')).write_text(json.dumps(base,indent=2)+'\n',encoding='utf-8',newline='\n')
script=(r/'measure-allocation.py').read_text(encoding='utf-8').replace("(r/'candidate-identity.json')","(r.parent/'candidate-identity.json')").replace("folder=(r/role).resolve()","folder=(r.parent/role).resolve()")
ast.parse(script);(out/'measure-allocation.py').write_text(script,encoding='utf-8',newline='\n')
(out/'purpose.json').write_text(json.dumps(dict(purpose='Constant native tuple-return/unpacking allocation exposure, with unchanged dynamic tuple-return control. Same source per reference/candidate and independent isolated CPython goldens; no local elapsed claim.',referenceCore='71ba421c',candidateCore='01fd9be0',fullGoldenSources=cases),indent=2)+'\n',encoding='utf-8',newline='\n')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(out/'measure-allocation.py')],check=True)
