from pathlib import Path
import json,subprocess
r=Path(__file__).parent
code=r'''from pathlib import Path
import fcntl,json,subprocess
r=Path('/home/lokad/lython-bench-checks/literal-tuples-b722-20261114')
with(r.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 print(json.dumps(dict(status=subprocess.check_output(['systemctl','show','lython-b722-literal-tuples-20261114.service','--property=ActiveState,MainPID,Result,ExecMainStatus'],text=True),exitCode=(r/'exit-code.txt').read_text(),log=(r/'collection.log').read_text(),confirmation=json.loads((r/'confirmation/confirmation.json').read_text())if(r/'confirmation/confirmation.json').exists()else None,traceEntries=[str(p.relative_to(r))for p in(r/'guest-fixtures').iterdir()],workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout)))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=30);assert done.returncode==0,done.stderr
(r/'failure-state.json').write_text(done.stdout,encoding='utf-8',newline='\n');d=json.loads(done.stdout);print(d['status'],d['log'][-5000:],'jobs=',len(d['confirmation']['jobs'])if d['confirmation']else None,'workers=',d['workers'],'RAM=',d['traceEntries'],flush=True)
