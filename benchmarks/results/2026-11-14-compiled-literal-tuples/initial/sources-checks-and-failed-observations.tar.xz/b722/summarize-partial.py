from pathlib import Path
import json,statistics
r=Path(__file__).parent;raw=json.loads((r/'failed-retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'));assert not raw['complete']and len(raw['jobs'])==4
rows=[]
for job in raw['jobs']:
 labels=list(job['identities']);med={k:statistics.median(1000*s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations']for s in job['samples']if s['engine']==k)for k in labels};cpu={k:statistics.median(1000*s['externalProcessCpuTicks']/s['externalCpuFrequency']/s['response']['completedInvocations']for s in job['samples']if s['engine']==k)for k in labels}
 row=dict(case=job['case'],lane=job['lane'],medianMilliseconds=med,widerCpuMedianMilliseconds=cpu,elapsedPercent=sorted(100*(med[a]/med[b]-1)for a in ['candidate','candidate-control']for b in ['reference','reference-control']),cpuPercent=sorted(100*(cpu[a]/cpu[b]-1)for a in ['candidate','candidate-control']for b in ['reference','reference-control']));rows.append(row)
 print(job['case'],job['lane'],'elapsed',row['elapsedPercent'],'CPU',row['cpuPercent'],flush=True)
(r/'partial-summary.json').write_text(json.dumps(dict(complete=False,diagnosticOnly=True,reference='71ba421c',candidate='01fd9be0',quietAfterMissing=True,controlsNotCompleted=True,sourceCorrectionRequired=True,noFinalCandidateClaim=True,originalFailurePreserved=True,rows=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
