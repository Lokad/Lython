from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent
code=r'''from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess,tarfile
r=Path('/home/lokad/lython-bench-checks/literal-tuples-b722-20261114')
with(r.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 service=subprocess.check_output(['systemctl','show','lython-b722-literal-tuples-20261114.service','--property=ActiveState,MainPID,Result,ExecMainStatus'],text=True)
 assert'MainPID=0'in service and'ActiveState=failed'in service and(r/'exit-code.txt').read_text().strip()=='1'
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 fixture=r/'guest-fixtures';assert fixture.is_dir()and not list(fixture.iterdir())
 raw=json.loads((r/'confirmation/confirmation.json').read_text());assert not raw['complete']and len(raw['jobs'])==4 and all(j['workersJoinedAndFixturesRemoved']for j in raw['jobs'])
 stderr={p.name:p.read_text()for p in(r/'confirmation').glob('*.stderr')}
 assert stderr
 files=[p for p in r.rglob('*')if p.is_file()and not{'candidate','reference','guest-fixtures'}&set(p.relative_to(r).parts)and p.name not in ['candidate-core.dll','failed-observations.tgz','failed-closure.json']]
 hashes={p.relative_to(r).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in files}
 with tarfile.open(r/'failed-observations.tgz','w:gz',dereference=True)as t:
  for p in files:t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
 with tarfile.open(r/'failed-observations.tgz')as t:
  for name,sha in hashes.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha
 assert shutil.disk_usage(r).free>252*1024*1024
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 receipt=dict(terminal='failed',service=service,completedJobs=4,complete=False,allWorkersJoined=True,guestFixturesRemoved=True,archivedAndVerifiedUnderLease=True,ramTraceWasEmptyAndVerifiedBeforeUnmount=True,archiveSHA256=hashlib.sha256((r/'failed-observations.tgz').read_bytes()).hexdigest(),failedStartupStderr=stderr,quietAfterNotMeasured=True,freeBytes=shutil.disk_usage(r).free,noAutomaticRestart=True)
 (r/'failed-closure.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=45);(r/'failed-closure.log').write_text(done.stdout+done.stderr,encoding='utf-8',newline='\n');assert done.returncode==0,done.stderr
(r/'failed-terminal-status.json').write_text(done.stdout,encoding='utf-8',newline='\n');receipt=json.loads(done.stdout)
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['failed-observations.tgz','failed-closure.json']:
 done=subprocess.run(scp+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/literal-tuples-b722-20261114/'+name,str(r/name)],capture_output=True,timeout=45);assert done.returncode==0,done.stderr
assert hashlib.sha256((r/'failed-observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
out=r/'failed-retrieved';out.mkdir(exist_ok=False)
with tarfile.open(r/'failed-observations.tgz')as t:t.extractall(out,filter='data')
print(json.dumps(receipt,indent=2),flush=True)
