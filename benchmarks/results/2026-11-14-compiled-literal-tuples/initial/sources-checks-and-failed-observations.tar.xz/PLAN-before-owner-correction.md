# Lokad.Lython 0.11.0

Updated 2026-11-14. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including freshly generated scripts. A delivered experiment is a checkpoint, not
completion. History and adverse evidence live in [EXPERIMENTS](benchmarks/EXPERIMENTS.md),
immutable results and saved plans, outside current-version docs.

## Delivery status

| State | Actual status and limits |
| --- | --- |
| Preceding qualified runtime | R346 `009d236a`, frozen `8ae1ae5f`, 581 production inputs. GREEN43563853239: Windows/Ubuntu actual .NET11/10, original stress, installed Release consumers; 16 summaries cached. Exact-sequence cursors share indexed advancement and remove CLR enumerators. List allocation−1.53%, elapsed−3.30..−5.20%, wider CPU−2.63..−4.58%. Text+0.69%allocation/small CPU adversity remains accepted debt. [Delivery](benchmarks/results/2026-11-14-indexed-sequence-cursors/delivery/README.md). |
| Retained regression fixture, qualified | `fc11817c` preserves R348 evidence and the independent reentrant-retirement fixture; production is byte-identical to qualified009d. The test change passes frozen8ae and restored nonincremental actual11/10, and combined full43571864663. |
| Latest fully qualified runtime | R349 `e235b18b` captured-cell scalar storage/publication, frozen `71ba421c`: 8 changed inputs, old dictionary-only preparation file retired, inventory still581. 1,826 focused actual11/10 cases pass, including independent Python values/identity, actual I/O, cancellation, first refusal and retained results. Allocation−18.00% on complete captured text, direct-text/CSV controls flat. B720 completes225.65s with all gates; captured warm−5.20..−7.60%/CPU−4.81..−6.89%, but faster variable direct controls make attribution uncertain. Frequent-read allocation+8B. GREEN43571864663: Windows/Ubuntu actual11/10, original stress and installed consumers.581input source proof/16summaries cached. [Delivery](benchmarks/results/2026-11-14-captured-scalar-storage/delivery/README.md). |
| Active R351 prototype | Frozen`01fd9be0`, one production file changed from qualifiede235/71ba. Existing builder replaces immutable emitted constant runs; no new pass/owner.135internal/476public per actual11/10 pass (1,222total), including11isolated Python controls and retained results. Initial six probe-launch failures are preserved; pinned child PATH/runtime fixes them without source/assertion changes. Local whole-script allocation−7.51%invoice/−4.68%fulfillment, captured-text control flat; all goldens/balances pass and users join. CPU/compilation/full delivery unqualified. |
| Current CPython comparison | R347/B717, 2026-11-14, runtime009d/frozen8ae versus stockCPython3.13.16: invoice warm1.26–1.31×, compile1.08–1.10×, compile-to-result1.21–1.24×; captured text1.48–1.59×, search1.66–1.76×, JSON0.83×, report1.19–1.21×, fulfillment1.30–1.31×, for-loopCSV1.28–1.29×. Invoice/search/text process spreads3.47/4.05/6.57% remain uncertainty. All image/golden/balance/quiet/join/archive gates pass; runtime fully qualified. Config retains its separately qualifiedcdd/f4 source. [Boundaries and results](docs/BENCHMARKS.md). |
| Withdrawn / unresolved | Both R348 inventory-removal forms withdrawn: coarse form rejects20KB/two words under1MiB; refined4311 has flat allocation and3–18%time adversity with CPU support. B718 unexplained stop/restart remains uncertainty; fresh same-bitB719 corrected the measurement. All original failures/cores survive. [Evidence](benchmarks/results/2026-11-14-streamed-cased-inventory-withdrawn/README.md). |

Completed foundations need no unchanged requalification:

- Shared compiler-fact/nonlocal correction, annotation demand and lowered-tree
  retention cleanup are delivered. [Evidence](benchmarks/results/2026-11-02-shared-compiler-facts/README.md).
- Direct UTF8 formatting/storage: allocation−8.67%original/−8.59%later pair;
  two controlled report CPU/elapsed confirmations support−5..−8%on their sources.
  Original15.125ms adversity remains unexplained and preserved. [Evidence](benchmarks/results/2026-11-02-formatting-confirmation/README.md).
- Native helper returns: whole-run allocation−19.92%CSVhelpers/−19.31%JSONhelpers,
  separate from diagnostic elapsed; corrected full delivery8f07764a complete.
  [Evidence](benchmarks/results/2026-11-02-native-function-returns/README.md).
- Bulk CSV's6–8%opportunity was selectively revisited: admitted array adoption/shared
  keys shipped. R308/R314 alternatives remain withdrawn, useful regressions retained.
  [Evidence](benchmarks/results/2026-11-02-native-csv-records/README.md).
- Final call slots/linear continuations/native prefixes, integer chains/counters,
  immutable builtins, native UTF8 JSON, incremental XML and builtin for-loops are
  delivered. R345 CSV allocation−25.31%/warm−14.71..−20.25%; confirmed
  compile-to-result−17.84..−19.94%. Original Windows CRLF failure stays failed;
  corrected descendant009d passes combined delivery. [Evidence](benchmarks/results/2026-11-14-native-for-prefixes/README.md).
- Slower call-arena/control designs remain lessons. R325/R327/R342 do not establish
  a dominant removable frame/packet; R338's frame-allocation explanation was
  corrected. R343/R348 cased-buffer/inventory alternatives are withdrawn. Historical
  failures and XML/report/search/helper control debt remain explicit in their
  evidence; do not add source-pair percentages or infer release-wide neutrality.

## Prioritized delivery

1. **R349 delivered; preserve its representation and explicit uncertainty.**
   Hypothesis: nonlocal increments box once per line; an authoritative existing cell
   can store an exact machine integer and publish one stable object when read.
   The source gate verified unmirrored owners, instruction extents and namespace
   publication through actual admission observers. Prototype removes per-update
   boxes and three-instruction temporary transport, reusing the machine kernel and
   existing compiler pass/unused metadata field. Three48Bcell preflights consolidate
   into96Bmetadata/current-value funding. Earlier tiny-budget denial is acceptable;
   old aliases never refund. No new policy, identity ledger, arena or tagged VM.
   Semantic acceptance: aliases/id/is, nonlocals, delete/unbound/rebind, namespace/
   lambda/comprehension exposure, exact promotion, protocols/error order, genuine
   suspension, cancellation/refusal, joined cleanup and retained results.
   Complete captured text versus unchanged direct-text/fulfillment controls separates
   allocation, warm elapsed and wider CPU. Preserve adverse medians and observable-
   read uncertainty. B720 and frequent-read exposure checks are complete; retain for18%allocation
   removal, with CPU attribution/frequent-read timing debt explicit. Current runtime
   docs describe the representation and conservative funding. Committede235b18b now passes full43571864663: Windows/Ubuntu actual11/10,
   original stress and installed Release consumers. All581inputs/16summaries are
   cached. No further unchanged qualification or retiming; advance the roadmap. No unchanged retiming is needed for this
   allocation decision. [Evidence](benchmarks/results/2026-11-14-captured-scalar-storage/README.md).

2. **R351: hoist immutable literal tuple construction into the compiled program.**
   R350 identifies actual tuple construction/admission work, without a removable CPU
   share. Source confirms invoice rebuilds(0,0,0,0)4,096times. Select one coherent
   frontend/storage change: compile children once, recognize an appended same-block
   run of immutable LoadConst values, replace the complete sequence/MakeTuple with
   one compiled constant. No second analysis pass, expression evaluator, general
   constant arithmetic, cache layer or universal value representation.
   Prototype is implemented in one file, with1,222focused actual11/10 cases green.
   Short allocation comparison completes: invoice−7.51%, fulfillment−4.68%, text
   control flat. Six worker/golden/balance verifications pass and all users join.
   Before retention, quantify native constant-return unpacking as well as normal
   invoice construction; existing dynamic helper-return optimization must survive.
   Existing coarse compilation admission funds literal/code storage; projected
   results acquire their existing independent owner. No per-literal ledger. Prove
   nested constants and all dynamic/mutable/starred/side-effect/error paths, current
   cancellation/refusal, shared execution reuse and retained results after compiler
   disposal. Literal identity reuse/earlier compilation denial are explicit tradeoffs.
   Remove per-run tuple arrays/copies/construction admission and child instructions;
   keep MakeTuple/display operations for their real dynamic callers. Compare complete
   invoice warm/allocation/compile/fresh with unchanged controls, bounded existing
   tooling, exact71ba reference and all adverse results. No speedup prediction.
   Constant-return allocation is flat, dynamic-return control exactly flat; timing
   remains necessary before changing its unpacking path. B722six targeted warm/
   compile/fresh/control jobs are active:420swork/480sowner, earliest observation
   08:25:28UTC. Fixed frozen01fd/71ba images and normal tiering/GC; no CPython timing.
   Only superseded53core six aliases and three duplicate working raw archives were
   retired after exact canonical Git/SHA/path/UID/all-alias/terminal proof; current
   images/evidence/floors survive. Prior VM free265,777,152B was below254MiBfloor. Do not stage
   another core without bounded canonical/all-alias proof for any retired superseded
   working core; protect current71ba/images/toolchain and all canonical evidence.
   Source/base delivery and active prototype status stay distinct. Never restart
   this owner solely because an observation times out; retain any failed conditions.

   **R350 source gate complete.**
   Committede235b18b/frozen71ba: B721 maps1,053invoice/742search guest leaves,
   96/142unknown and zero ambiguous. Every117/42native-body leaf maps to exact
   same-process Tier1 groups; useful/mixed work does not identify a large redundant
   activation. Final call slots, listless DictReader and combined CSV admission
   already exist. No new runtime prototype selected; do not duplicate those stages,
   infer removable shares or repeat unchanged captures. Continue dispatch/operand
   construction source analysis with a concrete displaced representation and
   identity/alias/promotion/pending-cleanup contract before implementation.
   [Evidence](benchmarks/results/2026-11-14-invoice-search-stage-attribution/README.md).
   Select work from demonstrated owning costs in representative scripts, not another
   isolated local tweak. Existing CPython gaps justify continued work but do not
   attribute them. Stop each source investigation when it selects/rejects a bounded
   coherent change; it need not exhaust every explanation.

   | Area / scripts | Work to eliminate; acceptance and displacement |
   | --- | --- |
   | Complete calls, frames, operand transport / helpers, search, invoices | Establish an actually redundant complete activation or storage stage; final slots and deferred prefixes already exist. Remove its displaced route. Preserve defaults/receivers, closure identity, exact errors, stack handoff, pending transfers and awaited cleanup. Do not revive a slower arena under another name. |
   | Per-record construction / CSV and JSON aggregates, reports | Existing CSV adoption/shared keys and iterative JSON are foundations. Eliminate a real record representation, copy or pass and retire its constructor. Preserve callbacks, mutation, aliases, pre-effect admission and replacement overlap. |
   | Scalar transport / counters, invoices, checksums | Decide R349 first. Select wider storage only with owning evidence; preserve exact promotion/identity/publication. A universal tagged VM is unselected. |
   | Remaining text conversions / file search, text summaries, reports | Remove an entire conversion/build stage. Preserve Unicode expansion/context, eager preflight, errors and real callback suspension; delete the superseded pipeline. R343/R348 scans are measured warnings, not permanent bans. |
   | Repeated frontend analysis / fresh generated scripts | Reuse proven repeated facts/retained IR with scopes, nonlocals, diagnostic order, cancellation and admission intact. Duplicate-name modeling accounted for only0.41–0.95%allocation; many visitors alone do not prove dominance. Remove displaced analysis rather than adding a cache layer. |

   Before each selected prototype record its hypothesis, eliminated work/storage,
   affected complete scripts, semantic/cancellation/ownership criteria, implementation
   to delete, bounded before/after/control comparison and regression-debt decision.
   Temporary setbacks are acceptable with a concrete completion milestone. Refresh
   representative CPython compilation/warm/fresh comparisons at a changed coherent
   checkpoint; state mediated I/O, reset, output, result cleanup and cache boundaries.
   Do not repeat B717 or completed qualification without a material change.

3. **Develop regex independently.**
   The Lython-owned Python/nativeUTF8/original-window/byte-scalar/capture/flags/error/
   current-token contract and existing owners/caches remain authoritative. Core has
   no backend edge; development producers and adapter-local bridges are allowed.
   Completed dev80/15b248dc checks (88internal/534public per actual11/10) are cached;
   normal29inputs/optional nonpackable0.4adapter stay unchanged. Producer06ef69e4
   leaves all three integration files byte-identical toae463cb4; dev84 package
   834162df is a separate immutable identity. Missing producer capabilities are
   separate one-match work/result owners, nativeUTF8group-name enumeration/copy,
   and token-independent cursor creation with cancellable preparation. Only the
   affected final adapter qualification defers. Select concrete contract/code/new-
   capability work; no repeated unchanged producer qualification. Distinguish
   contract correctness, semantic validation and real backend performance/safety.
   [Assessment](benchmarks/results/2026-11-14-regex-provider-capabilities/README.md).

## Evidence and lasting constraints

Separate architectural simplification, allocation reduction and demonstrated CPU
improvement. Percentages inform decisions, not automatic vetoes. A timeout,
unstable unchanged control or inconclusive observation establishes uncertainty.
Allow bounded confirmation, refinement and measurement correction for a stated
reason, preserving every adverse point and original failed condition. No blanket
one-attempt/no-retiming/permanently-closed rule or open-ended qualification campaign.

Focused Release correctness/cancellation/ownership checks during iteration; batch
Windows/Ubuntu actual11/10, original stress and installed Release consumers at
meaningful delivery checkpoints. Fully managed/memory-safe only: no unsafe/Unsafe,
pointers, P/Invoke or native probing. Preserve managed stack protection, host
capabilities/original paths+Cwd, cancellation, cycles/XML depth, checked representation
bounds and bounded I/O chunks. No fuel/quotas, hidden caps/default allowance, regex
work/time policies, tracing, weak reclamation, forced GC or abandoned users.
Borrowed allowance funds capacity/overlap, aliases/results/caches and pending users.
First refusal is terminal through suppression/finally: retain origin, await cleanup,
never retry. Long streams use bounded host commands. Force nonincremental builds
after restoration; copy/verify complete frozen images and sources. Persist evidence,
join users, preserve VM floors/current images. [AGENTS](AGENTS.md) remains binding.
