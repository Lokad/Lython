from pathlib import Path
import hashlib,json,os,shutil,subprocess,xml.etree.ElementTree as ET
r=Path(__file__).parent;out=r/'zip-copy-negative-control';out.mkdir(exist_ok=False);image=out/'image';source=Path('tests/Lokad.Lython.Tests/bin/Release/net11.0');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before={p.relative_to(source).as_posix():sha(p)for p in source.rglob('*')if p.is_file()};shutil.copytree(source,image)
assert before=={p.relative_to(source).as_posix():sha(p)for p in source.rglob('*')if p.is_file()}
assert before=={p.relative_to(image).as_posix():sha(p)for p in image.rglob('*')if p.is_file()}
assert sha(r/'candidate-core.dll')=='01fd9be06f864882ec3e48484779f37adea2bbb34864d0b009597ad68f5241d9'
shutil.copyfile(r/'candidate-core.dll',image/'Lokad.Lython.dll')
env=dict(os.environ);oldPath=next(v for k,v in env.items()if k.casefold()=='path');env={k:v for k,v in env.items()if k.casefold()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+oldPath
with(out/'check.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test',str(image/'Lokad.Lython.WhiteBox.Tests.dll'),'--filter','FullyQualifiedName~WrongTimestampLengthFailsWithoutCopyingItsInput','--logger','trx','--results-directory',str(out/'results')],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=60)
tree=ET.parse(next((out/'results').glob('*.trx')));ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};results=tree.findall('.//t:UnitTestResult',ns)
assert done.returncode!=0 and len(results)==2 and all(v.attrib['outcome']=='Failed'for v in results)
errors=[v.find('.//t:Message',ns).text for v in results];assert all('Invalid fixed-size metadata allocated'in error for error in errors),errors
(out/'proof.json').write_text(json.dumps(dict(purpose='Same new fixed-size input-copy regressions fail under exact uncorrected01fd; no threshold/assertion relaxation.',originalCoreSHA256=sha(r/'candidate-core.dll'),testAssemblySHA256=sha(image/'Lokad.Lython.WhiteBox.Tests.dll'),allAuxiliaryFilesCopiedAndVerified=True,expectedFailures=errors,returncode=done.returncode),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Negative control: exact01fd fails both unchanged copy guards as expected.',errors,flush=True)
