from pathlib import Path
import ast,base64,datetime,hashlib,json,subprocess,tarfile
r=Path(__file__).parent;prior=r.parent/'closure-scalars-r349/b720';out=r/'b722';out.mkdir(exist_ok=False)
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));aux=json.loads((prior/'identity.json').read_text(encoding='utf-8'))['candidateAuxiliaryFiles']
assert all(source['auxiliaryFiles'][role][name]==sha for role in ['reference','candidate']for name,sha in aux.items())
catalog=r.parent/'iteration-checkpoint-r347/b717/catalog.json';control=r/'return-control/allocation-reference-catalog.json'
identity=dict(sourceRevision='R351frozen01fd9be0 vs qualifiede235b18b/frozen71ba421c',purpose='Hoist immutable literal tuple construction into existing compiled constants. Same-source invoice warm/compile/compile-run, fulfillment warm, constant-return warm and unchanged captured-text control; no external baseline timing.',coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},candidateAuxiliaryFiles=aux,referenceAuxiliaryFiles=aux,catalogSHA256=hashlib.sha256(catalog.read_bytes()).hexdigest(),controlCatalogSHA256=hashlib.sha256(control.read_bytes()).hexdigest(),referenceCase='scripts.csv-invoice.large',variantCase='scripts.csv-invoice.large',controlCases=['scripts.text-summary-helpers.nonlocal-counter.large','diagnostic.tuple-return.constant'],sourceAndScriptDifferIntentionally=False)
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.csv-invoice.large','warm'],['scripts.csv-invoice.large','compile'],['scripts.csv-invoice.large','compile-run'],['scripts.csv-fulfillment.large','warm'],['diagnostic.tuple-return.constant','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(prior/name).read_text(encoding='utf-8').replace('captured-scalar-b720-20261114','literal-tuples-b722-20261114').replace('lython-b720-captured-scalar-20261114','lython-b722-literal-tuples-20261114').replace('B720','B722').replace('Captured-scalar source comparison','Literal-tuple source comparison')
 if name=='collect.py':
  s=s.replace("cases = {c['id']: c for c in json.loads(catalog.read_text())['cases']}","control_catalog = root / 'return-control.json'\ncases = {c['id']: c for p in [catalog,control_catalog] for c in json.loads(p.read_text())['cases']}")
  a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==6 and all(case in cases for case,lane in jobs)\n'+s[b:]
  s=s.replace('self.label, self.case, self.lane, self.sequence = label, case, lane, 0','self.label, self.case, self.lane, self.sequence = label, case, lane, 0\n        self.catalog = control_catalog if case["id"].startswith("diagnostic.") else catalog\n        self.manifest_hash = hashlib.sha256(self.catalog.read_bytes()).hexdigest()')
  s=s.replace("'--catalog', str(catalog)","'--catalog', str(self.catalog)").replace("self.identity['catalogSha256'] == manifest_hash","self.identity['catalogSha256'] == self.manifest_hash")
  s=s.replace('< 240','< 420').replace('Reserve60seconds','Reserve60seconds')
 if name=='archive-owned.py':s=s.replace("len(raw['jobs'])==3","len(raw['jobs'])==6").replace('jobs=3','jobs=6')
 if name=='retrieve.py':s=s.replace("['jobs']==3","['jobs']==6").replace("['elapsedSeconds']<300","['elapsedSeconds']<480").replace('three-job','six-job')
 if name=='summarize.py':s=s.replace("len(raw['jobs'])==3","len(raw['jobs'])==6").replace('jobs=3','jobs=6').replace('the identical complete CSV script has isolated CPython3.13.2 stdout/files goldens.', 'complete representative cases retain their existing isolated Python goldens; constant-return diagnostic has isolated CPython3.13.2 output.')
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
 for path,arc in [(r/'candidate-core.dll','candidate-core.dll'),(r/'candidate-identity.json','source-identity.json'),(control,'return-control.json')]:t.add(path,arcname=arc)
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
archives=[];commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for path,remote in [('benchmarks/results/2026-11-14-invoice-search-stage-attribution/observations.tgz','script-stage-b721-20261114/observations.tgz'),('benchmarks/results/2026-11-14-native-for-prefixes/b714/observations.tgz','native-for-b714-20261114/observations.tgz'),('benchmarks/results/2026-11-14-native-for-prefixes/b715/observations.tgz','native-for-b715-20261114/observations.tgz')]:
 blob=subprocess.check_output(['git','show',commit+':'+path]);assert hashlib.sha256(blob).digest()==hashlib.sha256(Path(path).read_bytes()).digest()
 archives.append(dict(canonicalCommit=commit,canonicalPath=path,remote=remote,sha256=hashlib.sha256(blob).hexdigest(),bytes=len(blob)))
inspection=json.loads((r/'space-inspection.json').read_text(encoding='utf-8'))
config=dict(root='/home/lokad/lython-bench-checks/literal-tuples-b722-20261114',sourceRoot='/home/lokad/lython-bench-checks/captured-scalar-b720-20261114',catalogRoot='/home/lokad/lython-bench-checks/iteration-checkpoint-b717-20261114',unit='lython-b722-literal-tuples-20261114',identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked,retireCore=inspection,retireArchives=archives)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();source=Path(config['sourceRoot']);root=Path(config['root']);catalogRoot=Path(config['catalogRoot']);digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert source.parent==base and source.resolve()==source and root.parent==base and not root.exists()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert(source/'exit-code.txt').read_text().strip()=='0'and not(source/'guest-fixtures').exists()
 assert digest(source/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['reference']
 for name,sha in config['identity']['referenceAuxiliaryFiles'].items():assert digest(source/'candidate'/name)==sha
 assert digest(catalogRoot/'representative.json')==config['identity']['catalogSHA256']
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 retire=[];inodes=set();aliases=config['retireCore']['allAliases'];proof=config['retireCore']['proof']
 for entry in aliases:
  p=Path(entry['path']);s=p.lstat();owned=Path(entry['root'])
  assert p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()
  assert s.st_size==proof['coreBytes']and digest(p)==proof['coreSHA256']and s.st_nlink==len(aliases)
  assert(owned/'exit-code.txt').read_text().strip()=='0'and not(owned/'guest-fixtures').exists()
  inodes.add((s.st_dev,s.st_ino));retire.append(p)
 assert len(inodes)==1
 for entry in config['retireArchives']:
  p=base/entry['remote'];s=p.lstat()
  assert p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
  assert s.st_size==entry['bytes']and digest(p)==entry['sha256']
  assert(p.parent/'exit-code.txt').read_text().strip()=='0'and not(p.parent/'guest-fixtures').exists()
  assert json.loads((p.parent/'archive-receipt.json').read_text())['complete'];retire.append(p)
 before=shutil.disk_usage(base).free
 assert before+proof['coreBytes']+sum(x['bytes']for x in config['retireArchives'])>254*1024*1024+config['unpackedBytes']+32768
 for p in retire:p.unlink()
 receipt=dict(freshIdleLease=True,allPathsHashesUidsAliasesVerifiedBeforeMutation=True,retiredOnly=[str(p)for p in retire],coreProof=proof,archiveProofs=config['retireArchives'],beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,current71ba8aeImagesCatalogsAndToolchainPreserved=True,floorsUnchanged=True)
 (base/'b722-proved-retirement-20261114.json').write_text(json.dumps(receipt,indent=2)+'\n')
 free=shutil.disk_usage(base).free;assert free>254*1024*1024+config['unpackedBytes']
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:t.extractall(root,filter='data')
 assert digest(root/'candidate-core.dll')==config['identity']['coreSHA256']['candidate']
 assert digest(root/'return-control.json')==config['identity']['controlCatalogSHA256']
 os.link(catalogRoot/'representative.json',root/'representative.json')
 os.link(source/'cpython-worker.py',root/'cpython-worker.py');os.link(source/'source-identity.json',root/'reference-source-identity.json')
 for role in ['reference','candidate']:
  (root/role).mkdir()
  for name in config['identity'][role+'AuxiliaryFiles']:os.link(source/'candidate'/name,root/role/name)
  os.link(source/'candidate/Lokad.Lython.dll'if role=='reference'else root/'candidate-core.dll',root/role/'Lokad.Lython.dll')
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True);assert shutil.disk_usage(base).free>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(beforeFreeBytes=free,afterFreeBytes=shutil.disk_usage(base).free,floorsUnchanged=True,retirementReceipt=receipt))+'\n')
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b722-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=480','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config));ast.parse(code);(out/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],input=(out/'payload.tgz').read_bytes(),capture_output=True,timeout=45)
(out/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc);(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=420)).isoformat(),ownerSeconds=480,stopSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8').replace('   Current VM free265,777,152B is below unchanged254MiBstaging floor.', '   Constant-return allocation is flat, dynamic-return control exactly flat; timing\n   remains necessary before changing its unpacking path. B722six targeted warm/\n   compile/fresh/control jobs are active:420swork/480sowner, earliest observation\n   '+(now+datetime.timedelta(seconds=420)).strftime('%H:%M:%S')+'UTC. Fixed frozen01fd/71ba images and normal tiering/GC; no CPython timing.\n   Only superseded53core six aliases and three duplicate working raw archives were\n   retired after exact canonical Git/SHA/path/UID/all-alias/terminal proof; current\n   images/evidence/floors survive. Prior VM free265,777,152B was below254MiBfloor.').replace('   No measurement user remains; source/base delivery and prototype status are distinct.', '   Source/base delivery and active prototype status stay distinct. Never restart\n   this owner solely because an observation times out; retain any failed conditions.');p.write_text(s,encoding='utf-8',newline='\n')
print((done.stdout+done.stderr).decode(),flush=True);print('Observe after',(now+datetime.timedelta(seconds=420)).isoformat(),flush=True)
