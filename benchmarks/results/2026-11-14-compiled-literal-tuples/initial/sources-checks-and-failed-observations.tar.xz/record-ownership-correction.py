from pathlib import Path
import json
r=Path(__file__).parent;p=Path('PLAN.md');s=p.read_text(encoding='utf-8');(r/'PLAN-before-owner-correction.md').write_text(s,encoding='utf-8',newline='\n')
record=dict(candidate='01fd9be0',finding='Prototype admits compiled literal storage, but source-owner allocation in tuple slicing/concatenation can derive ungoverned storage from its unowned immutable handle. This makes01fd unsuitable for promotion. Running B722 remains exact old-bit diagnostic evidence only.',reproduction='Add focused borrowed-literal slice/concat refusal and cancellation tests before correction. Preserve source aliases and root cleanup, verify runtime owner pays results while literal owner remains charged.',replacement=['Route contextual tuple slices to existing CreateTuple with known normalized count/indexes and current execution owner. No new ledger, allowance or per-node charge.','Route tuple-like concat to the same existing known-count tuple factory/current execution. Delete TupleLikeOwnership, source-governor selection, ungoverned concat branch and LINQ concat/growth materialization.','Check cancellation after shared tuple admission before allocating and during bounded copy/factory loops. Preserve current native helper return operations.','ZIP date_time is a fixed six-item consumer. Read the existing tuple/list through its readonly view and reject wrong count before copying; remove its ToArray snapshot instead of funding arbitrary invalid input.'],contract='Compiled immutable input stays funded by coarse compilation owner; new derived storage belongs to current execution, not a borrowed input owner. Earlier admission refusal/retention remains conservative; no tiny-budget identity promise.',scope='Three actual consumers exposed by unowned literal migration, not a general tuple/ownership audit. No heap tracing or root inventory. New frozen correction must receive focused qualification and a bounded final comparison; do not apply01fd timing to it.')
(r/'ownership-correction.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
anchor='   Existing coarse compilation admission funds literal/code storage;'
assert anchor in s;s=s.replace(anchor,'''   **Correction required before retention:** source review finds01fd's unowned
   compiled tuples can derive unadmitted slices/concats through source-owner-based
   allocation. Add refusal/cancellation regressions, then use the existing known-
   count governed tuple factory/current execution for those outputs. Delete source-
   owner selection/TupleLikeOwnership and LINQ concat materialization. Shared tuple
   construction must check cancellation after admission/before allocation and in
   its copy loop. ZIP's fixed six-item consumer should read the original readonly
   view and reject wrong count before copying, removing its ToArray snapshot.
   Keep this bounded to actual consumers exposed by literal migration; no ownership
   audit/tracing/ledger. B722 remains the original frozen01fd diagnostic, not final
   corrected-source qualification. Freeze/qualify a correction separately.
'''+anchor,1);s=s.replace('Allocation/CPU/compilation impact and full delivery unqualified.', '01fd has an identified derived-storage admission gap; promotion requires the recorded correction. CPU/compilation/full delivery unqualified.')
p.write_text(s,encoding='utf-8',newline='\n');print('Bounded ownership correction/deletions recorded before refinement.',flush=True)
