using System.Reflection;
using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Text;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.Tests;

/// <summary>
/// MG11: the ZipInfo factory owns the 128B constructed-value shell beside the
/// governed filename and date_time payloads; the date_time normalization
/// without a context stays free for the assignment path.
/// </summary>
public sealed class ZipInfoAccountingTests
{
    private static object InvokeZipInfo(LythonRuntime.ExecutionContext? context, LythonSourceSpan? span, CallArgumentValue[] arguments)
    {
        var type = typeof(LythonRuntime).GetNestedType("ZipInfoCallable", BindingFlags.NonPublic)
            ?? throw new InvalidOperationException("ZipInfoCallable not found.");
        var instance = type.GetField("Instance", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static)?.GetValue(null)
            ?? throw new InvalidOperationException("ZipInfoCallable.Instance not found.");
        var method = type.GetMethod("Invoke") ?? throw new InvalidOperationException("Invoke not found.");
        return method.Invoke(instance, [arguments, span, context])
            ?? throw new InvalidOperationException("Invoke returned null.");
    }

    [Fact]
    public void FactoryDefaultsCommitExactly()
    {
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        _ = InvokeZipInfo(context, span, []);
        // Shell (128) plus the NoName filename (128 + 6) plus the default
        // date_time backing (32 + 16 x 6), plus six 64B storage charges for the adopted
        // date_time fields (N06).
        Assert.Equal(390L + 6L * 64L, context.MemoryGovernor.CurrentCommittedBytes);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void WrongTimestampLengthFailsWithoutCopyingItsInput(bool list)
    {
        var context = new LythonRuntime.ExecutionContext(new MockLythonHost(), new LythonRunOptions());
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var items = Enumerable.Repeat<object>(PyNone.Instance, 4096).ToArray();
        object value = list ? new PyList(items) : PyTuple.FromOwnedArray(items);
        CallArgumentValue[] arguments = [CallArgumentValue.Positional(PyString.FromString("entry")), CallArgumentValue.Positional(value)];
        // Prime reflection and exception construction outside the measured window.
        _ = Record.Exception(() => InvokeZipInfo(context, span, arguments));
        var before = GC.GetAllocatedBytesForCurrentThread();
        var failure = Record.Exception(() => InvokeZipInfo(context, span, arguments));
        var allocated = GC.GetAllocatedBytesForCurrentThread() - before;
        var wrapped = Assert.IsType<TargetInvocationException>(failure);
        var error = Assert.IsType<LythonRuntimeException>(wrapped.InnerException);
        Assert.Equal("TypeError", error.ExceptionType);
        Assert.True(allocated < 16 * 1024, $"Invalid fixed-size metadata allocated {allocated} bytes.");
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }
}
