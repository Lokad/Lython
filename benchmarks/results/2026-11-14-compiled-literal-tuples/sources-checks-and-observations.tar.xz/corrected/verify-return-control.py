from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,tempfile
r=Path(__file__).parent
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
for role in ['reference','candidate']:
 expected=dict(identity['auxiliaryFiles'][role],**{'Lokad.Lython.dll':identity['coreSHA256'][role]})
 actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in(r/role).iterdir()if p.is_file()}
 assert actual==expected,(role,set(actual)^set(expected))
spec=importlib.util.spec_from_file_location('protocol',r.parent.parent/'utf8-byte-ownership-r334/b705/retrieved/cpython-worker.py')
protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
catalog=r/'return-control.json';cases=json.loads(catalog.read_text(encoding='utf-8'))['cases']
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
rows=[]
for role,index in [(role,index)for index in range(len(cases))for role in ['reference','candidate']]:
    case=cases[index]
    with tempfile.TemporaryDirectory(prefix='lython-comparison-files-')as folder:
        process=subprocess.Popen([env['DOTNET_ROOT']+'/dotnet.exe',str((r/role/'Lokad.Lython.Benchmarks.dll').resolve()),'--compare','worker','--catalog',str(catalog.resolve())],cwd=folder,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        try:
            ready=protocol.read_frame(process.stdout)
            if ready is None:
                errors=process.stderr.read();(r/('verify-startup-'+role+'.stderr')).write_bytes(errors)
                raise RuntimeError(errors.decode('utf-8',errors='replace'))
            assert ready['status']=='Ready',ready
            request={k:case[k]for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']}
            request.update(protocolVersion=2,requestId=1,operation='verify',caseId=case['id'],lane='warm',iterations=2)
            protocol.write_frame(process.stdin,request);response=protocol.read_frame(process.stdout)
            if response is None:
                errors=process.stderr.read();(r/('verify-request-'+role+'.stderr')).write_bytes(errors)
                raise RuntimeError(errors.decode('utf-8',errors='replace'))
            rows.append(dict(role=role,case=case['id'],ready=ready,response=response))
            (r/'return-worker-verification.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
            assert response['status']=='Equivalent',response
            assert response['actualOutputSha256']==case['expectedOutputSha256']
            assert response['actualFilesSha256']==case['expectedFilesSha256']
            protocol.write_frame(process.stdin,dict(protocolVersion=2,requestId=2,operation='quit'))
            assert protocol.read_frame(process.stdout)['status']=='Closed'
            assert process.wait(timeout=15)==0
            assert not process.stderr.read()
            print(role,case['id'],'Equivalent; exact stdout/files and budget reset.',flush=True)
        finally:
            if process.poll()is None:process.kill();process.wait()
            process.stdin.close();process.stdout.close();process.stderr.close()
