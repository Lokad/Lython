from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent;dotnet='C:/Users/JoannesVermorel/.dotnet11/dotnet.exe'
env=dict(os.environ)
originalPath=next(v for k,v in env.items()if k.casefold()=='path')
for key in list(env):
 if key.casefold()=='path':del env[key]
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+originalPath


jobs=[('Lokad.Lython.Tests','(FullyQualifiedName~Tuple|FullyQualifiedName~Literal|FullyQualifiedName~Constant|FullyQualifiedName~ExecutableFrameStorage|FullyQualifiedName~DictionaryCounting|FullyQualifiedName~CapturedScalar|FullyQualifiedName~ZipInfoAccounting)&Category!=Stress'),('Lokad.Lython.PublicApi.Tests','(FullyQualifiedName~Tuple|FullyQualifiedName~Literal|FullyQualifiedName~Constant|FullyQualifiedName~CapturedScalar|FullyQualifiedName~CooperativeCancellation|FullyQualifiedName~GovernedMemoryContract|FullyQualifiedName~MemoryDenialAttribution|FullyQualifiedName~NativeIntegerChain|FullyQualifiedName~ForHelper|FullyQualifiedName~ZipInfo|FullyQualifiedName~ZipFile)&Category!=Stress')]
checks=[]
for framework in ['net11.0','net10.0']:
 with(r/('probe-build-'+framework+'.log')).open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([dotnet,'build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f',framework],env=env,stdout=f,stderr=subprocess.STDOUT)
 assert done.returncode==0
 for project,filter_ in jobs:
  label=project+'-'+framework
  with(r/(label+'.log')).open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([dotnet,'test',f'tests/{project}/{project}.csproj','-c','Release','-f',framework,'--filter',filter_,'--logger','trx','--results-directory',str(r/label)],env=env,stdout=f,stderr=subprocess.STDOUT)
  checks.append(dict(project=project,target=framework,returncode=done.returncode,filter=filter_));(r/'focused-checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n')
  print((r/(label+'.log')).read_text(encoding='utf-8')[-2000:],flush=True);assert done.returncode==0,label
