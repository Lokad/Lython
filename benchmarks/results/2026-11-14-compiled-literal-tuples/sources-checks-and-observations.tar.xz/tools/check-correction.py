from pathlib import Path
import shutil,subprocess
r=Path(__file__).parent;old=r/'before-owner-correction-focused';old.mkdir(exist_ok=False)
for name in ['focused-checks.json','check-related.py','probe-build-net11.0.log','probe-build-net10.0.log','Lokad.Lython.Tests-net11.0.log','Lokad.Lython.Tests-net10.0.log','Lokad.Lython.PublicApi.Tests-net11.0.log','Lokad.Lython.PublicApi.Tests-net10.0.log']:shutil.copyfile(r/name,old/name)
for name in ['Lokad.Lython.Tests-net11.0','Lokad.Lython.Tests-net10.0','Lokad.Lython.PublicApi.Tests-net11.0','Lokad.Lython.PublicApi.Tests-net10.0']:shutil.copytree(r/name,old/name)
p=r/'check-related.py';s=p.read_text(encoding='utf-8').replace('FullyQualifiedName~CapturedScalar)&Category!=Stress','FullyQualifiedName~CapturedScalar|FullyQualifiedName~ZipInfoAccounting)&Category!=Stress').replace('FullyQualifiedName~ForHelper)&Category!=Stress','FullyQualifiedName~ForHelper|FullyQualifiedName~ZipInfo|FullyQualifiedName~ZipFile)&Category!=Stress');p.write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(p)],check=True)
