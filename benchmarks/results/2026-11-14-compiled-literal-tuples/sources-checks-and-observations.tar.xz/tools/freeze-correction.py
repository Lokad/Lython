from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;out=r/'corrected';out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
reference=json.loads((r/'reference-identity.json').read_text(encoding='utf-8'));checks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8'));assert len(checks)==4 and all(v['returncode']==0 for v in checks)
sources={p:sha(p)for p in reference['sources']};changed=[p for p in sources if sources[p]!=reference['sources'][p]];assert len(changed)==6,changed
env=dict(os.environ);oldPath=next(v for k,v in env.items()if k.casefold()=='path');env={k:v for k,v in env.items()if k.casefold()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+oldPath
with(out/'candidate-build.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0 and sources=={p:sha(p)for p in sources}
for role in ['reference','candidate']:shutil.copytree(r/'reference',out/role)
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',out/'candidate/Lokad.Lython.dll');shutil.copyfile(out/'candidate/Lokad.Lython.dll',out/'candidate-core.dll')
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),referenceProductionCommit='e235b18b',referenceQualification='GREEN43571864663 Windows/Ubuntu actual11/10, original stress and installed Release consumers,581source proof/16summaries cached.',coreSHA256={role:sha(out/role/'Lokad.Lython.dll')for role in ['reference','candidate']},sources=sources,productionFiles=len(sources),changedProductionInputs=changed,removedMechanisms=['repeated immutable literal tuple construction and child instruction transport','TupleLikeOwnership and source-governor allocation selection','unowned tuple concatenation branch and LINQ concat/growth materialization','contextual tuple slice temporary index/list/backing pipeline','arbitrary date_time ToArray snapshot before fixed-size validation'],newStorage='Literal tuple and backing share existing coarse compilation funding. Derived slices/concat use existing known-count tuple constructor and current execution owner; cancellation after admission/before allocation and within copies. ZIP reads its native input view after length validation. No new memory policy/ledger/cache/owner or engine.',auxiliaryFiles={role:{p.name:sha(p)for p in(out/role).iterdir()if p.is_file()and p.name!='Lokad.Lython.dll'}for role in ['reference','candidate']},qualified=False,sourceAndScriptDifferIntentionally=False)
assert identity['auxiliaryFiles']['reference']==identity['auxiliaryFiles']['candidate'];(out/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'candidate-sources.tar.xz','w:xz')as t:
 for p in sources:t.add(p,arcname=p)
for name in ['focused-checks.json','python-controls.json','ownership-correction.json']:shutil.copyfile(r/name,out/name)
shutil.copyfile(r/'catalog.json',out/'catalog.json')
for role in ['reference','candidate']:shutil.copyfile(out/'catalog.json',out/('allocation-'+role+'-catalog.json'))
for name in ['verify-worker.py','measure-allocation.py']:
 s=(r/name).read_text(encoding='utf-8').replace("r.parent/'utf8-byte-ownership-r334","r.parent.parent/'utf8-byte-ownership-r334")
 (out/name).write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('| Active R351 prototype |');b=s.index('\n| Current CPython comparison',a)
s=s[:a]+'''| Superseded R351 prototype | Frozen01fd hoists literal tuples but exposes derived-storage admission gaps: six focused regressions fail. B722 completes four diagnostic phases then fails malformed control-fixture startup; missing size/text metadata is corrected and verified through actual workers locally. All partial/failure/raw evidence is preserved, users join and RAM mount closes. No final CPU claim. |
| Corrected R351 prototype | Frozen`'''+identity['coreSHA256']['candidate'][:8]+'''`, six production inputs changed from qualifiede235/71ba. Current-owner slice/concat storage and pre-copy ZIP shape validation remove source-owner selection/LINQ/snapshot machinery.144internal/547public per actual11/10 pass (1,382total),14isolated Python controls, actual I/O, refusal/cancellation, retained derived results. Two copy guards also fail exact old01fd as expected. New corrected allocation/CPU/compilation/full delivery pending. |'''+s[b:]
s=s.replace('   Prototype is implemented in one file, with1,222focused actual11/10 cases green.', '   Corrected prototype is implemented in six files, with1,382focused actual11/10\n   cases green. Original01fd evidence remains separate; it is not promotion-ready.').replace('   **Correction required before retention:**','   **Ownership correction implemented; qualify the final frozen source:**').replace('   Keep this bounded to actual consumers exposed by literal migration; no ownership\n   audit/tracing/ledger. B722 remains the original frozen01fd diagnostic, not final\n   corrected-source qualification. Freeze/qualify a correction separately.', '   Keep this bounded to actual consumers exposed by literal migration; no ownership\n   audit/tracing/ledger. Six original failures now pass. Wrong-size ZIP input guards\n   pass current code and fail old01fd at34–36KB versus16KBguard. Final frozen'+identity['coreSHA256']['candidate'][:8]+'\n   has1,382focused cases green; its allocation/CPU/compile comparison remains pending.')
a=s.index('   Constant-return allocation is flat');b=s.index('\n\n   **R350 source gate complete.**',a)
s=s[:a]+'''   Original constant-return allocation is flat, dynamic-return control exactly flat;
   timing remains necessary. B722 failed on required control-fixture metadata after
   four completed phases; end quiet/control gates are missing. All original bits,
   data and failed conditions persist; no final corrected-source claims. Users joined
   and the empty RAM mount was archived/verified and closed. Corrected catalog now
   passes actual worker Ready/golden/balance checks before another VM run. No restart
   of the failed unit. Compare the final correction under a fresh bounded owner,
   preserving current images/canonical evidence and unchanged254/252MiBfloors.
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print('Frozen corrected R351',identity['coreSHA256'],'581inputs/6changed; focused1382; no final timing claim.',flush=True)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(out/'verify-worker.py')],check=True,env=env)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(out/'measure-allocation.py')],check=True,env=env)
