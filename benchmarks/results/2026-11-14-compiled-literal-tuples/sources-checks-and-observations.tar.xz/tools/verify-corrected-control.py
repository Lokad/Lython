from pathlib import Path
import ast,shutil,subprocess
r=Path(__file__).parent;out=r/'corrected'
shutil.copyfile(r/'return-control-corrected/allocation-reference-catalog.json',out/'return-control.json')
s=(out/'verify-worker.py').read_text(encoding='utf-8').replace("r/'catalog.json'","r/'return-control.json'").replace('range(3)','range(len(cases))').replace("r/'worker-verification.json'","r/'return-worker-verification.json'")
ast.parse(s);p=out/'verify-return-control.py';p.write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(p)],check=True)
