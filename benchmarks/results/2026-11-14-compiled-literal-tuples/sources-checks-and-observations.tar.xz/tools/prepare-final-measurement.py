from pathlib import Path
import ast,base64,datetime,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;stage=r/'corrected';prior=r/'b722';out=r/'b723';out.mkdir(exist_ok=False)
source=json.loads((stage/'candidate-identity.json').read_text(encoding='utf-8'));identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='R351corrected72c9a1e5 vs qualifiede235b18b/frozen71ba421c',purpose='Final literal tuple construction/current-owner correction: same-source invoice warm/compile/compile-run, fulfillment warm, constant-return warm and unchanged captured-text control. Earlier01fd gap/B722 malformed control preserved; no external timing.',coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},controlCatalogSHA256=hashlib.sha256((stage/'return-control.json').read_bytes()).hexdigest())
assert all(source['auxiliaryFiles'][role][name]==sha for role in ['reference','candidate']for name,sha in identity[role+'AuxiliaryFiles'].items())
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n');(out/'source-identity.json').write_text(json.dumps(source,separators=(',',':'))+'\n',encoding='utf-8',newline='\n')
assert json.loads((out/'source-identity.json').read_text(encoding='utf-8'))==source
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(prior/name).read_text(encoding='utf-8').replace('literal-tuples-b722-20261114','literal-tuples-b723-20261114').replace('lython-b722-literal-tuples-20261114','lython-b723-literal-tuples-20261114').replace('B722','B723')
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['identity.json','source-identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
 for path,name in [(stage/'candidate-core.dll','candidate-core.dll'),(stage/'return-control.json','return-control.json')]:t.add(path,arcname=name)
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
canonical=Path('benchmarks/results/2026-11-14-compiled-literal-tuples/initial/sources-checks-and-failed-observations.tar.xz');commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();blob=subprocess.check_output(['git','show',commit+':'+canonical.as_posix()]);assert hashlib.sha256(blob).digest()==hashlib.sha256(canonical.read_bytes()).digest()
with tarfile.open(canonical)as t:
 core=t.extractfile('candidate-core.dll').read();failed=t.extractfile('b722/failed-observations.tgz').read()
with tarfile.open(fileobj=io.BytesIO(failed),mode='r:gz')as t:
 extra={name:t.extractfile(name).read()for name in ['confirmation/confirmation.json','source-identity.json']}
proof=dict(canonicalCommit=commit,canonicalArchive=canonical.as_posix(),canonicalSHA256=hashlib.sha256(blob).hexdigest(),coreMember='candidate-core.dll',failedMember='b722/failed-observations.tgz',coreSHA256=hashlib.sha256(core).hexdigest(),coreBytes=len(core),files=[dict(path='failed-observations.tgz',sha256=hashlib.sha256(failed).hexdigest(),bytes=len(failed))]+[dict(path=name,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))for name,data in extra.items()],reason='Only discarded01fd working aliases and duplicate closed B722 data. Complete original bytes remain immutable in Git. Current71ba/8ae images/catalogs/toolchain/floors preserved.')
assert proof['coreSHA256']=='01fd9be06f864882ec3e48484779f37adea2bbb34864d0b009597ad68f5241d9'
(out/'retirement-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
config=dict(root='/home/lokad/lython-bench-checks/literal-tuples-b723-20261114',sourceRoot='/home/lokad/lython-bench-checks/captured-scalar-b720-20261114',catalogRoot='/home/lokad/lython-bench-checks/iteration-checkpoint-b717-20261114',oldRoot='/home/lokad/lython-bench-checks/literal-tuples-b722-20261114',unit='lython-b723-literal-tuples-20261114',identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked,proof=proof)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();source=Path(config['sourceRoot']);root=Path(config['root']);old=Path(config['oldRoot']);catalogRoot=Path(config['catalogRoot']);digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(p.parent==base and p.resolve()==p for p in [source,old,catalogRoot])and root.parent==base and not root.exists()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert json.loads((old/'failed-closure.json').read_text())['guestFixturesRemoved']and not(old/'guest-fixtures').exists()
 assert digest(source/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['reference']
 for name,sha in config['identity']['referenceAuxiliaryFiles'].items():assert digest(source/'candidate'/name)==sha
 assert digest(catalogRoot/'representative.json')==config['identity']['catalogSHA256']
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 proof=config['proof'];cores=[old/'candidate-core.dll',old/'candidate/Lokad.Lython.dll'];inodes=set();retired=[]
 for p in cores:
  s=p.lstat();assert p.resolve()==p and p.is_relative_to(old)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==2
  assert s.st_size==proof['coreBytes']and digest(p)==proof['coreSHA256'];inodes.add((s.st_dev,s.st_ino));retired.append(p)
 assert len(inodes)==1
 for entry in proof['files']:
  p=old/entry['path'];s=p.lstat();assert p.resolve()==p and p.is_relative_to(old)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
  assert s.st_size==entry['bytes']and digest(p)==entry['sha256'];retired.append(p)
 before=shutil.disk_usage(base).free;reclaim=proof['coreBytes']+sum(v['bytes']for v in proof['files'])
 assert before+reclaim>254*1024*1024+config['unpackedBytes'],(before,reclaim,config['unpackedBytes'])
 for p in retired:p.unlink()
 receipt=dict(proof=proof,freshIdleLease=True,allPathsUidsHashesAliasesProvedBeforeMutation=True,retiredOnly=[str(p)for p in retired],beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,current71ba8aeAndToolchainCatalogsPreserved=True,floorsUnchanged=True)
 (base/'b723-proved-retirement-20261114.json').write_text(json.dumps(receipt,indent=2)+'\n')
 free=shutil.disk_usage(base).free;assert free>254*1024*1024+config['unpackedBytes']
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:t.extractall(root,filter='data')
 assert digest(root/'candidate-core.dll')==config['identity']['coreSHA256']['candidate']
 assert digest(root/'return-control.json')==config['identity']['controlCatalogSHA256']
 os.link(catalogRoot/'representative.json',root/'representative.json');os.link(source/'cpython-worker.py',root/'cpython-worker.py');os.link(source/'source-identity.json',root/'reference-source-identity.json')
 for role in ['reference','candidate']:
  (root/role).mkdir()
  for name in config['identity'][role+'AuxiliaryFiles']:os.link(source/'candidate'/name,root/role/name)
  os.link(source/'candidate/Lokad.Lython.dll'if role=='reference'else root/'candidate-core.dll',root/role/'Lokad.Lython.dll')
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True);assert shutil.disk_usage(base).free>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(beforeFreeBytes=free,afterFreeBytes=shutil.disk_usage(base).free,floorsUnchanged=True,retirementReceipt=receipt))+'\n')
 fixture=root/'guest-fixtures';fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b723-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=480','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config));ast.parse(code);(out/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],input=(out/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(out/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc);(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=420)).isoformat(),ownerSeconds=480,stopSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'reason.json').write_text(json.dumps(dict(reason='Final-source correction and malformed-fixture measurement correction, not unchanged retiming. Original01fd source/failure/partial data are immutable in de05a889. Six local worker/golden main checks plus four actual corrected-control checks pass before VM use. Fixed72c9/71ba images, ordinary GC/tiering, same6jobs/12s full-request warmups/five1s batches.',workSeconds=420,ownerSeconds=480,noAutomaticRestart=True),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');anchor='   Compare the final correction under a fresh bounded owner,';s=s.replace(anchor,'   B723final72c9/71ba comparison is active:420swork/480sowner, earliest observation\n   '+(now+datetime.timedelta(seconds=420)).strftime('%H:%M:%S')+'UTC. Six targeted phases retain normalGC/tiering and all failed conditions.\n   Only discarded01fd working aliases/duplicate closed data were retired after\n   canonicalde05a889 Git/SHA/path/UID/all-alias proof; current images/floors stay.\n'+anchor);p.write_text(s,encoding='utf-8',newline='\n')
print((done.stdout+done.stderr).decode(),flush=True);print('Observe after',(now+datetime.timedelta(seconds=420)).isoformat(),flush=True)
