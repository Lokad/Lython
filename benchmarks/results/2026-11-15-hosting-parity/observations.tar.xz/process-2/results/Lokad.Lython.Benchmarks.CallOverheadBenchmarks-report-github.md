```

BenchmarkDotNet v0.16.0-preview.2, Windows 11 (10.0.26200.9911/25H2/2025Update/HudsonValley2)
Intel Core i7-14700KF 3.42GHz, 1 CPU, 28 logical and 20 physical cores
Memory: 63.72 GB Total, 11.9 GB Available
.NET SDK 11.0.100-rc.3.26522.148
  [Host]   : .NET 11.0.0 (11.0.0-rc.3.26522.148, 11.0.26.52348), X64 RyuJIT x86-64-v3
  ShortRun : .NET 11.0.0 (11.0.0-rc.3.26522.148, 11.0.26.52348), X64 RyuJIT x86-64-v3

Job=ShortRun  OutlierMode=DontRemove  Force=False  
Runtime=.NET 11.0  Toolchain=InProcessEmitToolchain  IterationCount=5  
IterationTime=100ms  LaunchCount=1  UnrollFactor=1  
WarmupCount=3  

```
| Method                                  | Mean     | Error     | StdDev    | Gen0    | Allocated |
|---------------------------------------- |---------:|----------:|----------:|--------:|----------:|
| &#39;10K positional identity calls&#39;         | 1.266 ms | 0.0296 ms | 0.0077 ms | 20.1342 |  324.2 KB |
| &#39;10K positional identity calls (async)&#39; | 1.433 ms | 0.0859 ms | 0.0223 ms | 28.5714 | 324.64 KB |
