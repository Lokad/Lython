from pathlib import Path
import hashlib
import json
import shutil
import tarfile

base = Path(__file__).parent
source = base / 'hosting-parity-r387'
target = Path('benchmarks/results/2026-11-15-hosting-parity')
target.mkdir(exist_ok=False)
summary = {'revision': '810379bed830f3d2baf2a8b0ddff57b60a60d3df',
           'coreSHA256': json.loads((source / 'identity.json').read_text(encoding='utf-8'))['imageBefore']['Lokad.Lython.dll'],
           'runtimeChanged': False, 'portablePerformanceClaim': False, 'groups': []}
for group, folder in [('initial', source), ('longer-warmup-confirmation', source / 'confirmation')]:
    identity = json.loads((folder / 'identity.json').read_text(encoding='utf-8'))
    assert identity['imageBefore'] == identity['imageAfter']
    rows = []
    for process in (1, 2):
        reports = list((folder / f'process-{process}' / 'results').glob('*-report-full-compressed.json'))
        assert len(reports) == 1
        data = json.loads(reports[0].read_text(encoding='utf-8'))
        assert len(data['Benchmarks']) == 2
        for benchmark in data['Benchmarks']:
            stats = benchmark['Statistics']
            rows.append({'process': process, 'method': benchmark['Method'],
                         'meanMilliseconds': stats['Mean'] / 1e6,
                         'medianMilliseconds': stats['Median'] / 1e6,
                         'iqrOverMedianPercent': 100 * stats['InterquartileRange'] / stats['Median'],
                         'originalMilliseconds': [v / 1e6 for v in stats['OriginalValues']]})
    sync = [r for r in rows if r['method'] == 'CallsIdentity10k']
    async_ = [r for r in rows if r['method'] == 'CallsIdentity10kAsync']
    summary['groups'].append({'name': group, 'rows': rows,
                             'meanAsyncOverSyncAllPairings': [a['meanMilliseconds'] / s['meanMilliseconds'] for a in async_ for s in sync],
                             'medianAsyncOverSyncAllPairings': [a['medianMilliseconds'] / s['medianMilliseconds'] for a in async_ for s in sync],
                             'totalHostSeconds': sum(r['elapsedSeconds'] for r in identity['runs']),
                             'completeImageVerifiedBeforeAfter': True})
with tarfile.open(target / 'observations.tar.xz', 'w:xz') as archive:
    for file in sorted(source.rglob('*')):
        if file.is_file(): archive.add(file, arcname=file.relative_to(source).as_posix())
    for name in ['run-hosting-parity-r387.py', 'confirm-hosting-parity-r387.py', 'save-hosting-parity-r387.py']:
        archive.add(base / name, arcname='procedures/' + name)
summary['archiveSHA256'] = hashlib.sha256((target / 'observations.tar.xz').read_bytes()).hexdigest()
(target / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(summary['groups'], indent=2))
