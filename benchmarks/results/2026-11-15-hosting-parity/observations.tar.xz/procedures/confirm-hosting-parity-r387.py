from pathlib import Path
import ast

source = Path(__file__).with_name('run-hosting-parity-r387.py').read_text(encoding='utf-8')
source = source.replace("out = notes / 'hosting-parity-r387'", "out = notes / 'hosting-parity-r387' / 'confirmation'")
source = source.replace("'--warmupCount', '3', '--iterationCount', '5'", "'--warmupCount', '20', '--iterationCount', '7'")
source = source.replace("'--iterationTime', '100'", "'--iterationTime', '500'")
ast.parse(source)
exec(compile(source, str(__file__), 'exec'))
