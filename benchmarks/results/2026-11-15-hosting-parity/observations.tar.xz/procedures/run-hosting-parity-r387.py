from pathlib import Path
import hashlib
import json
import platform
import subprocess
import time

root = Path.cwd()
notes = Path(__file__).parent
out = notes / 'hosting-parity-r387'
out.mkdir(exist_ok=True)
source = notes / 'function-slot-binding-r384'
image = source / 'candidate'
identity = json.loads((source / 'candidate-identity.json').read_text(encoding='utf-8'))
expected = identity['frozenFiles']['candidate']

def check_image():
    actual = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in image.iterdir() if p.is_file()}
    assert actual == expected, (actual.keys() ^ expected.keys(), 'frozen image mismatch')
    return actual

proof = {'imageBefore': check_image(), 'coreRevision': '810379bed830f3d2baf2a8b0ddff57b60a60d3df',
         'platform': platform.platform(), 'processor': platform.processor(),
         'boundary': 'Windows local diagnostic; two separate BDN host processes; frozen image, in-process toolchain; no new build or runtime patch',
         'createdUtc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'runs': []}
dotnet = 'C:/Users/JoannesVermorel/.dotnet11/dotnet.exe'
for process in (1, 2):
    artifacts = out / f'process-{process}'
    command = [dotnet, str(image / 'Lokad.Lython.Benchmarks.dll'),
               '--filter', '*CallOverheadBenchmarks.CallsIdentity10k*', '--inProcess',
               '--job', 'short', '--warmupCount', '3', '--iterationCount', '5',
               '--iterationTime', '100', '--unrollFactor', '1', '--outliers', 'DontRemove',
               '--noForcedGCs', '--artifacts', str(artifacts), '--exporters', 'JSON']
    start = time.perf_counter()
    with (out / f'process-{process}.log').open('w', encoding='utf-8', newline='\n') as log:
        result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT, timeout=180)
    proof['runs'].append({'process': process, 'command': command, 'exit': result.returncode,
                          'elapsedSeconds': time.perf_counter() - start})
    (out / 'identity.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(proof['runs'][-1]), flush=True)
    assert result.returncode == 0
proof['imageAfter'] = check_image()
(out / 'identity.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8')
