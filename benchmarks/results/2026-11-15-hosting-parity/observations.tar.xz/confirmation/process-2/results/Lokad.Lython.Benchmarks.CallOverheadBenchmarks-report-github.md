```

BenchmarkDotNet v0.16.0-preview.2, Windows 11 (10.0.26200.9911/25H2/2025Update/HudsonValley2)
Intel Core i7-14700KF 3.42GHz, 1 CPU, 28 logical and 20 physical cores
Memory: 63.72 GB Total, 13.6 GB Available
.NET SDK 11.0.100-rc.3.26522.148
  [Host]   : .NET 11.0.0 (11.0.0-rc.3.26522.148, 11.0.26.52348), X64 RyuJIT x86-64-v3
  ShortRun : .NET 11.0.0 (11.0.0-rc.3.26522.148, 11.0.26.52348), X64 RyuJIT x86-64-v3

Job=ShortRun  OutlierMode=DontRemove  Force=False  
Runtime=.NET 11.0  Toolchain=InProcessEmitToolchain  IterationCount=7  
IterationTime=500ms  LaunchCount=1  UnrollFactor=1  
WarmupCount=20  

```
| Method                                  | Mean     | Error     | StdDev    | Gen0    | Allocated |
|---------------------------------------- |---------:|----------:|----------:|--------:|----------:|
| &#39;10K positional identity calls&#39;         | 1.274 ms | 0.0103 ms | 0.0046 ms | 19.0476 | 324.23 KB |
| &#39;10K positional identity calls (async)&#39; | 1.351 ms | 0.1113 ms | 0.0494 ms | 19.7183 | 324.63 KB |
