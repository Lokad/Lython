from pathlib import Path
import os,subprocess
root=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
with (root/'catalog-verification.log').open('w',encoding='utf-8') as output:
    result=subprocess.run([env['DOTNET_HOST_PATH'],str(root/'images/candidate/Lokad.Lython.Benchmarks.dll'),'--compare','verify',
        '--catalog',str(root/'catalog.json'),'--dotnet',env['DOTNET_HOST_PATH'],'--python','C:/Python313/python.exe',
        '--python-worker',str(Path('benchmarks/cpython-worker.py').resolve()),'--out',str(root/'catalog-verification.json')],env=env,stdout=output,stderr=subprocess.STDOUT)
assert result.returncode==0,(root/'catalog-verification.log').read_text(encoding='utf-8')[-2500:]
print('Normal supervised .NET/CPython worker verification passed for all four cases, with joined cleanup.')
