from pathlib import Path
root=Path(__file__).parent
source=(root.parent/'cold-string-hash-r33/focused.py').read_text(encoding='utf-8-sig')
families=['Format','NativeReturn','NativeHelper','CompletedHelper','Deferred','InstructionFailure',
 'FunctionExecutionBoundary','ExecutableStorage','LocalAugmentedLifetime','CanonicalResult','Comprehension','Generator']
start=source.index('families=');end=source.index('\nselection=',start)
source=source[:start]+'families='+repr(families)+source[end:]
exec(compile(source,str(root/'focused-expanded.py'),'exec'))
