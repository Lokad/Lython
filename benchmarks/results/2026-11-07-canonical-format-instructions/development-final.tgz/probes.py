from pathlib import Path
import json,os,subprocess
root=Path(__file__).parent
sources=[
'''events=[]
class Value:
 def __repr__(self):
  events.append('repr')
  return 'é😀'
def spec():
 events.append('spec')
 return '^6'
def render(value):return f'prefix:{value!r:{spec()}}:suffix'
print(render(Value()),events)
''',
'''events=[]
class Value:
 def __repr__(self):
  events.append('repr')
  raise ValueError('stop')
def width():
 events.append('width')
 return 8
def render(value):return f'{value!r:>{width()}}/{missing}'
try:render(Value())
except ValueError as error:print(type(error).__name__,str(error),events)
''',
'''class Value:
 def __format__(self,spec):return str(sorted(locals()))+':'+spec
def render(value,width):return f'{width}/{value:>{width}}'
print(render(Value(),4))
''',
'''events=[]
target='before'
class Value:
 def __format__(self,spec):
  global target
  events.append(spec)
  target='after'
  return 'changed'
def render(value,width):return f'{value:>{width}}/{target}'
print(render(Value(),4),events)
''',
'''value=''.join(['é','😀'])
def plain(value):return f'{value}'
def dynamic(value,width):return f'{value:{width}}'
print(plain(value) is value,dynamic(value,0) is value)
for width in [0,3,8]:print(repr(dynamic(value,width)))
''',
'''def generate():
 yield f'prefix:{(yield 4):0{(yield 3)}d}:suffix'
g=generate()
print(next(g),g.send(7),g.send(5))
try:next(g)
except StopIteration:print('done')
''']
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
(root/'probe-sources.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for api in ['sync','async']:
 args=[env['DOTNET_ROOT']+'/dotnet.exe','tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll',
  '--batch-json','--compare-python','--python','C:/Python313/python.exe']
 if api=='async':args.append('--async')
 result=subprocess.run(args,input=json.dumps(sources,ensure_ascii=False),text=True,encoding='utf-8',env=env,capture_output=True,timeout=60)
 (root/('probes-'+api+'.jsonl')).write_text(result.stdout,encoding='utf-8')
 (root/('probes-'+api+'.stderr')).write_text(result.stderr,encoding='utf-8')
 assert result.returncode==0,result.stdout[-3000:]+result.stderr
 print(api,len(sources),'independent CPython comparisons pass',flush=True)
