from pathlib import Path
import hashlib,json,shutil,statistics,subprocess,tarfile
root=Path(__file__).parent;dest=Path('benchmarks/results/2026-11-07-canonical-format-instructions')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=json.loads((root/'focused-initial.json').read_text(encoding='utf-8'))
before=json.loads((root/'before.json').read_text(encoding='utf-8'))
identity=json.loads((root/'b387/identity.json').read_text(encoding='utf-8'))
for name,digest in identity['modifiedSourceSHA256'].items():assert sha(Path('src/Lokad.Lython')/name)==digest
for tfm,digest in checks['coreSHA256'].items():assert sha(Path('src/Lokad.Lython/bin/Release')/tfm/'Lokad.Lython.dll')==digest
with tarfile.open(dest/'checked-source-and-images-final.tgz','w:gz') as a:
 for name in before['source']:a.add(Path('src/Lokad.Lython')/name,arcname='source/'+name)
 a.add('tests/Lokad.Lython.Tests/DynamicFormattedOwnershipTests.cs',arcname='DynamicFormattedOwnershipTests.cs')
 for tfm in ['net11.0','net10.0']:a.add(Path('src/Lokad.Lython/bin/Release')/tfm/'Lokad.Lython.dll',arcname='images/'+tfm+'/Lokad.Lython.dll')
(dest/'b387').mkdir(exist_ok=False)
for name in ['observations.tgz','archive-receipt.json','terminal-status.json']:
 shutil.copyfile(root/'b387'/name,dest/'b387'/name)
shutil.copyfile(root/'focused-initial.json',dest/'focused-final.json')
shutil.copyfile(root/'comparison-b387-summary.json',dest/'comparison-b387-summary.json')
rows=[]
for api in ['sync','async']:
 data=json.loads((root/'refinement'/api/'measurements.json').read_text(encoding='utf-8'))
 assert all(data[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
 for case in data['observations']:
  amounts={role:statistics.median(s['allocatedBytes']/s['jobs'] for s in case['samples'] if s['image']==role) for role in ['before','candidate','before-control']}
  rows.append(dict(api=api,case=case['caseId'],allocatedBytes=amounts,changePercent=100*(amounts['candidate']/amounts['before']-1),
   admittedPeaks=case['admittedPeaks']))
(dest/'allocation-final.json').write_text(json.dumps(dict(rows=rows,allSemanticAndOwnershipGatesPassed=True,
 performanceQualified=False,note='Existing four-case warm process allocation, both APIs; shared ALC/CoreLib/GC. Desktop clocks diagnostic; separate B386 compile allocation reused because frontend source is unchanged.'),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(dest/'development-final.tgz','w:gz') as a:
 for p in root.iterdir():
  if p.is_file() and p.suffix in {'.py','.json','.jsonl','.log','.stderr','.md'}:a.add(p,arcname=p.name)
 for api in ['sync','async']:
  a.add(root/'refinement'/api,arcname='refinement/'+api)
 a.add(root/'refinement/identity.json',arcname='refinement/identity.json')
 for name in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh','contract.md','pre-measurement-plan.md','setup-contract.json','source.patch','observe-not-before.json','launch.py','launch-command.py','launch.log']:
  a.add(root/'b387'/name,arcname='b387/'+name)
# Keep old committed sidecars immutable. Correct only their manifest for Git's
# earlier newline normalization; original producer hashes/manifest stay archived.
manifest=json.loads((root/'original-b386-manifest.json').read_text(encoding='utf-8'))
corrected=[];prefix=str(dest).replace('\\','/')+'/'
for name,digest in manifest.items():
 raw=subprocess.check_output(['git','show','1746ba27:'+prefix+name])
 actual=hashlib.sha256(raw).hexdigest()
 if actual!=digest:
  corrected.append(name);(dest/name).write_bytes(raw);manifest[name]=actual
(dest/'sha256-b386.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
with (dest/'README.md').open('a',encoding='utf-8',newline='\n') as out:
 out.write('''
## Retained lifetime-helper refinement — B387

Final checked core6ab7367f/net1041b68d90; same original07a6530e reference, b94 worker,
normal0.4 adapter and five-job/capture conditions. Transient formatting bodies use
an ordinary non-inlined helper entered only for formatted opcodes; their generic
ApplyOperation classification remains deleted. No checks, owners or effects move.

| Workload/lane | Final elapsed change | Current / baseline role spread |
| --- | ---: | ---: |
| Static report warm |−4.68 to−1.57%|0.32% /2.93%|
| Static report fresh |−5.32 to+0.13%|5.23% /0.23%|
| Dynamic-width report warm |−13.19 to−10.09%|2.82% /0.64%|
| Unchanged text warm |−2.37 to+1.03%|1.40% /2.06%|
| Unchanged CSV warm |+0.13 to+2.36%|0.68% /1.53%|

All five jobs/gates pass in142.36s; observe only after06:22:26Z. Archive independently
retrieved/hash-verified; no remaining users/fixtures and no more service queries.
Dynamic process-CPU counters agree in direction; static/control CPU remains coarse
and mixed. Fresh current roles differ5.23%, so the static fresh result is inconclusive.
Text's initial adverse range is not consistently reproduced; its cause remains
unproved. This cross-capture result does not isolate register pressure as causal.

Retain the coherent instruction/record deletion, native dynamic context savings and
existing lifetime fence. Final complete-job warm allocation remains about−15.35%
for the dynamic report on both APIs; static report/text/CSV are essentially flat,
all admitted peaks/balances/goldens/cleanup pass. Frontend sources are unchanged
from B386, so its separate−160B/static and−760B/dynamic compile allocation is reused.
Do not transfer B386 fresh allocation or desktop elapsed into a new CPU claim.

Explicitly accept possible CSV+0.13–2.36% elapsed debt for this milestone. Text/fresh
uncertainty and earlier R31/R20/R26 debt remain visible, not parity or algebraically
repaid by percentages from other captures. No third unchanged retiming is selected;
future source evidence can justify another bounded redesign. The complete-script
objective remains active. Final full platform/original Stress/package qualification
is pending; publication/tagging remains postponed.

Focused203internal/1,141public per actual11/10 and six independent CPython probes
through both APIs pass on this refined source, including real suspended formatting
cleanup. [Final comparison](comparison-b387-summary.json), [raw capture](b387/observations.tgz),
[final allocation](allocation-final.json), [checked sources/images](checked-source-and-images-final.tgz),
[focused receipt](focused-final.json), [complete development evidence](development-final.tgz).

One expanded B386 core is retired only after matching its independently committed
1746ba27 archive, verifying its current hash, ended users and absent file/directory
link dependencies. Original bytes remain committed. The frozen B386 raw archives
are unchanged. Its sidecar hash manifest is corrected for Git newline conversion
on three JSON sidecars, with the original producer manifest/hashes retained in the
final development archive; the existing sidecar blobs and measurement values are
unchanged. The new byte-preservation attribute prevents that conversion in future.
''')
text=(dest/'README.md').read_text(encoding='utf-8').replace('This source is an active prototype; full delivery/retention pending.',
 'The lifetime-helper refinement is retained; full delivery is pending.')
(dest/'README.md').write_text(text,encoding='utf-8',newline='\n')
(dest/'sha256-final.json').write_text(json.dumps({str(p.relative_to(dest)).replace('\\','/'):sha(p) for p in dest.rglob('*') if p.is_file() and p.name not in {'sha256-final.json'}},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(finalImages=checks['coreSHA256'],correctedSidecarHashes=corrected,archive='checked-source-and-images-final.tgz')))
