from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');root=Path('/home/lokad/lython-bench-checks/config-cpu-b154-20261103');rows=[{'path': '/home/lokad/lython-bench-checks/config-cpu-b154-20261103/perf/config-warm/perf.map', 'bytes': 1290240, 'sha256': '3ffd031bf27f1a529fee98944a575b6d077f9537c99c1fcdc350af1e1a8cc5bb'}]
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 targets=set()
 for row in rows:
  p=Path(row['path'])
  assert p.resolve()==p and root in p.parents and p.is_file() and not p.is_symlink() and p.stat().st_nlink==1
  assert p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
  targets.add(p)
 for raw in subprocess.check_output(['find',str(base),'-type','l','-print0']).split(b'\0'):
  if raw:assert Path(os.fsdecode(raw)).resolve() not in targets
 for p in targets:p.unlink()
 print(json.dumps(dict(retiredExpandedFiles=rows,independentCommittedArchive='fffbbbab:benchmarks/results/2026-11-03-json-iterator-working-storage/profile/raw-capture.tar.gz',
  allUsersEnded=True,noSymlinkDependencies=True,freeBytes=shutil.disk_usage(base).free),indent=2))
