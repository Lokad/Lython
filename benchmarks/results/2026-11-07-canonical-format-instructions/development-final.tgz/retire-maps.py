from pathlib import Path
import subprocess,sys
root=Path(__file__).parent
source=(root.parent/'report-cost-r34/retire.py').read_text(encoding='utf-8-sig')
for label,folder in [('net10','published-net10'),('net11','foundation-net11')]:
 script=source.replace('published-net10/perf.data',folder+'/perf.map').replace(
  'retire-foundation-net10-command.py','retire-foundation-map-'+label+'-command.py').replace(
  'expanded-foundation-net10-retirement.json','expanded-foundation-map-'+label+'-retirement.json')
 p=root/('retire-map-'+label+'.py');p.write_text(script,encoding='utf-8',newline='\n')
 subprocess.run([sys.executable,'-X','utf8',str(p)],check=True)
