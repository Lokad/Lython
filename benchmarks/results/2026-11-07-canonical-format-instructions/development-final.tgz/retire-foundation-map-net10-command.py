from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');root=base/'foundation-cpu-pair-v2-20261029';rows=[{'path': '/home/lokad/lython-bench-checks/foundation-cpu-pair-v2-20261029/published-net10/perf.map', 'bytes': 1440047, 'sha256': '6ba0bb396229ce08801f5442e6e0db3b8b80587cd77bb4b31b29fbe51bc9d3ba'}]
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 targets=set()
 for row in rows:
  p=Path(row['path'])
  assert p.resolve()==p and root in p.parents and p.is_file() and not p.is_symlink() and p.stat().st_nlink==1
  digest=subprocess.check_output(['sudo','-n','sha256sum','--',str(p)],text=True).split()[0]
  assert p.stat().st_size==row['bytes'] and digest==row['sha256']
  targets.add(p)
 for raw in subprocess.check_output(['find',str(base),'-type','l','-print0']).split(b'\0'):
  if raw:assert Path(os.fsdecode(raw)).resolve() not in targets
 for p in targets:p.unlink()
 print(json.dumps(dict(retiredExpandedFiles=rows,independentCommittedArchive='81036f25:benchmarks/results/2026-10-29-foundation/foundation-profiles-20261029.tar.gz',
  allUsersEnded=True,noSymlinkDependencies=True,freeBytes=shutil.disk_usage(base).free),indent=2))
