from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path(__file__).parent
files=['Frontend/ExecutableScript.cs','Frontend/ExecutableScript.SuspendingExpressions.cs',
 'Frontend/ExecutableStackLayout.cs','Frontend/ExecutableScript.NativeReturns.cs',
 'Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs','Runtime/LythonRuntime.Executable.PreparedOperations.cs',
 'Runtime/LythonRuntime.Executable.NativeReturn.cs']
base=Path('src/Lokad.Lython')
with tarfile.open(root/'before-source-and-images.tgz','w:gz') as a:
 for name in files:a.add(base/name,arcname='source/'+name)
 for tfm in ['net11.0','net10.0']:
  a.add(base/'bin/Release'/tfm/'Lokad.Lython.dll',arcname='images/'+tfm+'/Lokad.Lython.dll')
before=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 source={name:hashlib.sha256((base/name).read_bytes()).hexdigest() for name in files},
 images={tfm:hashlib.sha256((base/'bin/Release'/tfm/'Lokad.Lython.dll').read_bytes()).hexdigest() for tfm in ['net11.0','net10.0']})
(root/'before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
def edit(name,fn):
 p=base/name;t=p.read_text(encoding='utf-8-sig');p.write_text(fn(t),encoding='utf-8',newline='\n')
def replace(t,old,new):
 assert t.count(old)==1,(old,t.count(old));return t.replace(old,new)
def instructions(t):
 t=replace(t,'    AbruptJump,\n','    AbruptJump,\n    StartFormattedString,\n    AppendFormattedText,\n    FinishFormattedString,\n    ConvertFormattedValue,\n    FormatField,\n')
 t=replace(t,'OpCode is ExecutableOpCode.LoadConst or ExecutableOpCode.ApplyOperation\n',
  'OpCode is ExecutableOpCode.LoadConst or ExecutableOpCode.ApplyOperation\n        or ExecutableOpCode.AppendFormattedText or ExecutableOpCode.FormatField\n')
 needle='    public int PairCount => ReadPrimaryOperand(ExecutableOpCode.MakeDict, nameof(PairCount));'
 t=replace(t,needle,needle+'\n    public int FormattedInitialCapacity => ReadPrimaryOperand(ExecutableOpCode.StartFormattedString, nameof(FormattedInitialCapacity));\n    public char FormattedConversion => (char)ReadPrimaryOperand(ExecutableOpCode.ConvertFormattedValue, nameof(FormattedConversion));')
 needle='    public static ExecutableInstruction StoreMember('
 index=t.index(needle)
 t=t[:index]+'''    public static ExecutableInstruction StartFormattedString(int capacity, LythonSourceSpan span)
        => new(ExecutableOpCode.StartFormattedString, span, capacity);

    public static ExecutableInstruction AppendFormattedText(int constantIndex, LythonSourceSpan span)
        => new(ExecutableOpCode.AppendFormattedText, span, constantIndex);

    public static ExecutableInstruction FinishFormattedString(LythonSourceSpan span)
        => new(ExecutableOpCode.FinishFormattedString, span);

    public static ExecutableInstruction ConvertFormattedValue(char conversion, LythonSourceSpan span)
        => new(ExecutableOpCode.ConvertFormattedValue, span, conversion);

    public static ExecutableInstruction FormatField(int constantIndex, LythonSourceSpan span)
        => new(ExecutableOpCode.FormatField, span, constantIndex);

'''+t[index:]
 return t
edit(files[0],instructions)
def frontend(t):
 t=replace(t,'internal sealed record ExecutableConvertFormattedValue(char Conversion) : ExecutableOperation;\n','')
 t=replace(t,'    LythonRuntime.InterpolatedFormatSpecifier? PreparedFormat) : ExecutableOperation;',
  '    LythonRuntime.InterpolatedFormatSpecifier? PreparedFormat);')
 for line in ['internal sealed record ExecutableStartFormattedString(int InitialCapacity) : ExecutableOperation;\n',
  'internal sealed record ExecutableAppendFormattedText(PyString Text) : ExecutableOperation;\n',
  'internal sealed record ExecutableFinishFormattedString : ExecutableOperation;\n']:
  t=replace(t,line,'')
 t=replace(t,'if (append) AddInstruction(block, ExecutableInstruction.ApplyOperation(-1, span));',
  'if (append) AddInstruction(block, ExecutableInstruction.StartFormattedString(0, span));')
 t=replace(t,'if (append) EmitOperation(new ExecutableAppendFormattedText(literal), span, block);',
  'if (append) AddInstruction(block, ExecutableInstruction.AppendFormattedText(InternConstant(literal), span));')
 t=replace(t,'EmitOperation(new ExecutableConvertFormattedValue(conversion), span, block);',
  'AddInstruction(block, ExecutableInstruction.ConvertFormattedValue(conversion, span));')
 t=replace(t,'EmitOperation(new ExecutableFormatField(field.FormatSpecifier, field.FormatSpecifierParts is not null, append, prepared), span, block);',
  'AddInstruction(block, ExecutableInstruction.FormatField(InternConstant(\n                        new ExecutableFormatField(field.FormatSpecifier, field.FormatSpecifierParts is not null, append, prepared)), span));')
 t=replace(t,'_blocks[startBlock].Instructions[startIndex] = ExecutableInstruction.ApplyOperation(\n                    InternConstant(new ExecutableStartFormattedString(initialCapacity)), span);\n                EmitOperation(new ExecutableFinishFormattedString(), span, block);',
  '_blocks[startBlock].Instructions[startIndex] = ExecutableInstruction.StartFormattedString(initialCapacity, span);\n                AddInstruction(block, ExecutableInstruction.FinishFormattedString(span));')
 return t
edit(files[1],frontend)
def layout(t):
 t=replace(t,'                    ExecutableOpCode.GetIter => inputStart,','                    ExecutableOpCode.GetIter => inputStart,\n                    ExecutableOpCode.StartFormattedString => resultSlot,')
 t=replace(t,'ExecutableStartClassHeader or ExecutableStartFormattedString => resultSlot,','ExecutableStartClassHeader => resultSlot,')
 t=replace(t,'else if (instruction.OpCode is ExecutableOpCode.ApplyOperation or ExecutableOpCode.ExecuteFallbackStatement',
  'else if (instruction.OpCode is ExecutableOpCode.ApplyOperation or ExecutableOpCode.ExecuteFallbackStatement\n                        or ExecutableOpCode.StartFormattedString or ExecutableOpCode.AppendFormattedText\n                        or ExecutableOpCode.FinishFormattedString or ExecutableOpCode.ConvertFormattedValue or ExecutableOpCode.FormatField')
 t=replace(t,'                ExecutableOpCode.ForNext => true,',
  '                ExecutableOpCode.ForNext or ExecutableOpCode.FinishFormattedString or ExecutableOpCode.ConvertFormattedValue => true,\n            ExecutableOpCode.FormatField => constants[instruction.ConstantIndex] is ExecutableFormatField { Append: false },')
 t=replace(t,'ExecutableFinishCall or ExecutableConvertFormattedValue or ExecutableCreateGeneratorExpression or\n                ExecutableFinishFormattedString or ExecutableCreateLambda or ExecutablePostponedAnnotation or\n                ExecutableAnnotationsEnabled or ExecutableFormatField { Append: false },',
  'ExecutableFinishCall or ExecutableCreateGeneratorExpression or\n                ExecutableCreateLambda or ExecutablePostponedAnnotation or ExecutableAnnotationsEnabled,')
 t=replace(t,'ExecutableOpCode.LoadGlobal or ExecutableOpCode.LoadName => (0, 1),',
  'ExecutableOpCode.LoadGlobal or ExecutableOpCode.LoadName or ExecutableOpCode.StartFormattedString => (0, 1),')
 t=replace(t,'ExecutableOpCode.Unary or ExecutableOpCode.MatchException or\n',
  'ExecutableOpCode.Unary or ExecutableOpCode.MatchException or\n                ExecutableOpCode.ConvertFormattedValue or ExecutableOpCode.FinishFormattedString or\n')
 t=replace(t,'            ExecutableOpCode.ApplyOperation => OperationEffect((ExecutableOperation)constants[instruction.ConstantIndex]!),',
  '            ExecutableOpCode.AppendFormattedText => (0, 0),\n            ExecutableOpCode.FormatField => constants[instruction.ConstantIndex] is ExecutableFormatField field\n                ? (field.DynamicSpecifier ? 2 : 1, field.Append ? 0 : 1)\n                : throw new InvalidOperationException("Missing formatted-field descriptor."),\n            ExecutableOpCode.ApplyOperation => OperationEffect((ExecutableOperation)constants[instruction.ConstantIndex]!),')
 t=replace(t,'            ExecutableOpCode.ForNext => 1,',
  '            ExecutableOpCode.ForNext or ExecutableOpCode.AppendFormattedText => 1,\n            ExecutableOpCode.FormatField when constants[instruction.ConstantIndex] is ExecutableFormatField { Append: true } => checked(pop + 1),')
 t=replace(t,'                ExecutableAppendFormattedText => 1,\n                ExecutableFormatField { Append: true } => checked(pop + 1),\n','')
 t=replace(t,' or ExecutableStartFormattedString => (0, 1),',' => (0, 1),')
 t=replace(t,' or ExecutableConvertFormattedValue or ExecutableCreateGeneratorExpression or ExecutableFinishFormattedString => (1, 1),',
  ' or ExecutableCreateGeneratorExpression => (1, 1),')
 t=replace(t,'        ExecutableFormatField field => (field.DynamicSpecifier ? 2 : 1, field.Append ? 0 : 1),\n        ExecutableAppendFormattedText => (0, 0),\n','')
 return t
edit(files[2],layout)
def native_compiler(t):
 t=replace(t,'''                case ExecutableOpCode.ApplyOperation:
                    operation = Constants[instruction.ConstantIndex] switch
                    {
                        ExecutableConvertFormattedValue => NativeReturnOperation.ConvertFormat,
                        ExecutableFormatField { DynamicSpecifier: false, Append: false } => NativeReturnOperation.FormatValue,
                        _ => NativeReturnOperation.Read
                    };''','''                case ExecutableOpCode.ConvertFormattedValue:
                case ExecutableOpCode.FormatField:
                    operation = instruction.OpCode == ExecutableOpCode.ConvertFormattedValue
                        ? NativeReturnOperation.ConvertFormat
                        : Constants[instruction.ConstantIndex] is ExecutableFormatField { DynamicSpecifier: false, Append: false }
                            ? NativeReturnOperation.FormatValue : NativeReturnOperation.Read;''')
 return t
edit(files[3],native_compiler)
def dispatch(t):
 t=replace(t,'                            if (TryExecuteImmediateFormatting(ref execution, scope, invocation, instruction)) break;\n','')
 index=t.index('                        case ExecutableOpCode.ApplyOperation:')
 t=t[:index]+'''                        case ExecutableOpCode.StartFormattedString:
                            var output = new GovernedByteBuilder(scope.MemoryGovernor, instruction.Span,
                                instruction.FormattedInitialCapacity, scope.State.CancellationToken);
                            try { PublishInstructionResult(ref execution, invocation, instruction, output); }
                            catch { output.Release(); throw; }
                            break;
                        case ExecutableOpCode.AppendFormattedText:
                            ((GovernedByteBuilder)execution.Stack[instruction.InputStart]).Append(
                                (PyString)execution.Code.Constants[instruction.ConstantIndex]!);
                            break;
                        case ExecutableOpCode.FinishFormattedString:
                            var formattedResult = ((GovernedByteBuilder)execution.Stack[instruction.InputStart]).ToPyStringAndRelease();
                            execution.Stack.RetireTo(instruction.ResultSlot);
                            PublishInstructionResult(ref execution, invocation, instruction, formattedResult);
                            break;
                        case ExecutableOpCode.ConvertFormattedValue:
                            if (IsImmediateFormattedValue(execution.Stack[instruction.InputStart]))
                            {
                                var converted = FormatInterpolatedStringPart(
                                    execution.Stack.TakeValue(instruction.InputStart, instruction.ResultSlot),
                                    instruction.FormattedConversion, null, invocation ?? scope, instruction.Span);
                                PublishInstructionResult(ref execution, invocation, instruction, converted);
                                break;
                            }
                            goto case ExecutableOpCode.FormatField;
                        case ExecutableOpCode.FormatField:
                            if (instruction.OpCode == ExecutableOpCode.FormatField &&
                                IsImmediateFormattedValue(execution.Stack[instruction.ResultSlot]))
                            {
                                var field = (ExecutableFormatField)execution.Code.Constants[instruction.ConstantIndex]!;
                                var specifier = field.DynamicSpecifier
                                    ? ((PyString)execution.Stack.TakeValue(instruction.ResultSlot + 1, instruction.ResultSlot + 1)).AsString()
                                    : field.FormatSpecifier;
                                var fieldValue = execution.Stack.TakeValue(instruction.ResultSlot, instruction.ResultSlot);
                                if (field.Append)
                                    AppendInterpolatedStringPart((GovernedByteBuilder)execution.Stack[instruction.InputStart],
                                        fieldValue, null, specifier, invocation ?? scope, instruction.Span, field.PreparedFormat);
                                else PublishInstructionResult(ref execution, invocation, instruction,
                                    FormatInterpolatedStringPart(fieldValue, null, specifier, invocation ?? scope, instruction.Span, field.PreparedFormat));
                                break;
                            }
                            if (invocation is null) return InstructionPause.ContextRequired;
                            if (!asynchronous) invocation.ExecuteFormattedValueAsync(instruction, false).GetAwaiter().GetResult();
                            else
                            {
                                pending = WithoutJump(invocation.ExecuteFormattedValueAsync(instruction, true));
                                if (!pending.IsCompleted) return PauseOperation(instruction.Span, out pendingSpan);
                                _ = ConsumeOperation(ref pending);
                            }
                            break;
'''+t[index:]
 return t
edit(files[4],dispatch)
def prepared(t):
 start=t.index('        // Formatting shares the ordinary operand slots and cleanup.')
 end=t.index('        private static bool IsImmediateFormattedValue',start)
 t=t[:start]+t[end:]
 t=replace(t,' or ExecutableConvertFormattedValue or ExecutableFormatField\n', '\n')
 start=t.index('                case ExecutableConvertFormattedValue conversion:')
 end=t.index('                case ExecutableCreateGeneratorExpression comprehension:',start)
 cases=t[start:end]
 t=t[:start]+t[end:]
 pos=t.index('        private ValueTask ExecutePreparedOperationAsync')
 method='''        // Only actual protocol values need the function context/async driver.
        // Already-evaluated native values and dynamic specs remain in the prefix.
        private async ValueTask ExecuteFormattedValueAsync(ExecutableInstruction instruction, bool asynchronous)
        {
            var span = instruction.Span;
            if (instruction.OpCode == ExecutableOpCode.ConvertFormattedValue)
            {
                var converted = await FormatSuspendedFieldAsync(
                    _execution.Stack.TakeValue(instruction.InputStart, instruction.ResultSlot),
                    instruction.FormattedConversion, null, this, span, asynchronous).ConfigureAwait(false);
                PublishInstructionResult(instruction, converted);
                return;
            }
            var field = (ExecutableFormatField)_execution.Code.Constants[instruction.ConstantIndex]!;
            var specifier = field.DynamicSpecifier
                ? ((PyString)_execution.Stack.TakeValue(instruction.ResultSlot + 1, instruction.ResultSlot + 1)).AsString()
                : field.FormatSpecifier;
            var value = _execution.Stack.TakeValue(instruction.ResultSlot, instruction.ResultSlot);
            if (field.Append)
            {
                var output = (GovernedByteBuilder)_execution.Stack[instruction.InputStart];
                if (value is PyInstance instance)
                    output.Append(await FormatInstanceFieldAsync(instance, null, specifier, this, span, asynchronous).ConfigureAwait(false));
                else AppendInterpolatedStringPart(output, value, null, specifier, this, span, field.PreparedFormat);
            }
            else PublishInstructionResult(instruction,
                await FormatSuspendedFieldAsync(value, null, specifier, this, span, asynchronous, field.PreparedFormat).ConfigureAwait(false));
        }

'''
 return t[:pos]+method+t[pos:]
edit(files[5],prepared)
def native_runtime(t):
 return replace(t,'''                    var conversion = (ExecutableConvertFormattedValue)code.Constants[instruction.ConstantIndex]!;
                    return FormatInterpolatedStringPart(first!, conversion.Conversion, null, context, instruction.Span);''',
 '''                    return FormatInterpolatedStringPart(first!, instruction.FormattedConversion, null, context, instruction.Span);''')
edit(files[6],native_runtime)
print('Migrated seven source files; baseline source/images retained.')
