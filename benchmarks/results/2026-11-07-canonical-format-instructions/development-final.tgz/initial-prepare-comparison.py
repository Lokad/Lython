from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
home=Path(__file__).parent;root=home/'b386';root.mkdir(exist_ok=False)
old=home.parent/'prepared-call-layout-r31/b384'
remote='/home/lokad/lython-bench-checks/canonical-format-instructions-b386-20261107'
old_remote='/home/lokad/lython-bench-checks/prepared-call-layout-b384-20261107'
checks=json.loads((home/'focused-initial.json').read_text(encoding='utf-8-sig'))
before=json.loads((home/'before.json').read_text(encoding='utf-8-sig'))
candidate=home/'images/candidate/Lokad.Lython.dll'
assert hashlib.sha256(candidate.read_bytes()).hexdigest()==checks['coreSHA256']['net11.0']
aux=json.loads((home.parent/'report-cost-r34/identity.json').read_text(encoding='utf-8-sig'))['auxiliaryFiles']
for name,digest in aux.items():assert hashlib.sha256((home/'images/candidate'/name).read_bytes()).hexdigest()==digest
identity=dict(sourceRevision='fffbbbab plus R35 canonical formatted instructions; checked frozen'+checks['coreSHA256']['net11.0'],
 referenceSourceRevision='fully qualified2f1f2715 production, frozen07a6530e; source-identical documentation commits',
 purpose='R35 static/dynamic complete report formatting, static fresh, text/CSV controls; two baseline/two current',qualification=checks,
 coreSHA256=dict(candidate=checks['coreSHA256']['net11.0'],control=checks['coreSHA256']['net11.0'],
  reference=before['images']['net11.0'],**{'reference-control':before['images']['net11.0']}),
 auxiliaryFiles=aux,modifiedSourceSHA256={n:hashlib.sha256((Path('src/Lokad.Lython')/n).read_bytes()).hexdigest() for n in before['source']})
(root/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(home/'catalog.json',root/'representative.json')
jobs=[('scripts.report-render.large','warm'),('scripts.report-render.large','compile-run'),
 ('scripts.dynamic-report-render.large','warm'),('scripts.text-summary-helpers.large','warm'),('scripts.csv-summary-functions.large','warm')]
collect=(old/'collect.py').read_text(encoding='utf-8-sig').replace(old_remote,remote)
start=collect.index('jobs=');end=collect.index('\nenv =',start)
collect=collect[:start]+'jobs='+repr(jobs)+'\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n'+collect[end:]
collect=collect.replace('R31 immutable function-call layout: class compile/warm/fresh and config-fresh/text-warm/CSV-warm controls, two baseline/two current',identity['purpose'])
collect=collect.replace('time.monotonic()-started < 190','time.monotonic()-started < 170')
(root/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
archive=(old/'archive-owned.py').read_text(encoding='utf-8-sig').replace(old_remote,remote).replace("len(r['jobs'])==6","len(r['jobs'])==5").replace('jobs=6','jobs=5')
(root/'archive-owned.py').write_text(archive,encoding='utf-8',newline='\n')
run=(old/'run.sh').read_text(encoding='utf-8-sig').replace(old_remote,remote)
(root/'run.sh').write_text(run,encoding='utf-8',newline='\n')
contract='''R35 deletes formatting's generic prepared-operation detour and four wrapper records, using the existing instruction engine and actual-user cleanup. Native already-evaluated dynamic specs no longer require context creation; actual protocols promote at their original instruction. Focused203internal/1141public per actual11/10 pass, including real suspended format cleanup and first refusal/retained aliases/cancellation. Complete .NET/CPython verification of four catalog cases passes. Precise process allocation: dynamic report-15.35%warm/-15.05%fresh, compile-760B; static report warm flat/compile-160B, controls flat. All peaks/goldens/balances/cleanup pass. Desktop static fresh and dynamic warm adverse observations remain diagnostic; no CPU forecast. Five complete checked jobs: static report warm/fresh, dynamic report warm, unchanged text/CSV warm. Two baseline/two current processes,5s warmup per role, seven rotated150ms rounds, normal GC/tiering/optional0.4, same b94 worker/host. Warm/fresh include mediated RAM I/O/full checks/prior-result cleanup; fresh adds compile/program disposal. Startup/staging/reset/final teardown excluded. All source/image/quiet/funding/Closed/joins/fixtures/persistent-under-lease archive gates required.210s owner+30s stop+40s margin: observe after280s. Keep every adverse/failed condition. Retention decides simplification/allocation/CPU/debt separately; no fixed improvement veto, publication or whole-objective completion.\n'''
(root/'contract.md').write_text(contract,encoding='utf-8',newline='\n')
(root/'pre-measurement-plan.md').write_bytes(Path('PLAN.md').read_bytes())
(root/'setup-contract.json').write_text(json.dumps(dict(reference='/home/lokad/lython-bench-checks/report-cost-b385-20261107/candidate',
 roles=['candidate','reference','control','reference-control'],ownerSeconds=210,stopSeconds=30,observeAfterSeconds=280,
 jobs=jobs,diskHeadroomBytes=1024*1024),indent=2)+'\n',encoding='utf-8')
(root/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src','tests/Lokad.Lython.Tests/DynamicFormattedOwnershipTests.cs']))
for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text(encoding='utf-8'))
assert json.loads((root/'setup-contract.json').read_text())['jobs']==[list(j) for j in jobs]
with tarfile.open(root/'payload.tgz','w:gz') as a:
 for name in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh','contract.md','pre-measurement-plan.md','setup-contract.json','source.patch']:a.add(root/name,arcname=name)
 a.add(candidate,arcname='current-core.dll')
print('Five jobs/canonical source, images and original adverse controls recorded; payload', (root/'payload.tgz').stat().st_size)
