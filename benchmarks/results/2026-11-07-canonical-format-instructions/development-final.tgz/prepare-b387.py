from pathlib import Path
import ast,subprocess,sys
home=Path(__file__).parent
t=(home/'prepare-comparison.py').read_text(encoding='utf-8')
t=t.replace("root=home/'b386'","root=home/'b387'").replace('canonical-format-instructions-b386-20261107','canonical-format-instructions-b387-20261107')
t=t.replace("candidate=home/'images/candidate/Lokad.Lython.dll'","candidate=home/'refinement/images/candidate/Lokad.Lython.dll'")
t=t.replace('fffbbbab plus R35 canonical formatted instructions','1746ba27 plus R35 canonical formatted instructions with transient-value lifetime helper')
t=t.replace('One source-justified refinement', 'One source-justified refinement')
start=t.index("contract='''");end=t.index("\n(root/'contract.md')",start)
old=t[start:end]
old=old.replace('R35 deletes formatting', 'R35 refined source deletes formatting').replace(
 'Native already-evaluated dynamic specs no longer require context creation;',
 'One bounded refinement moves formatting instruction bodies/guest temporaries into an ordinary non-inlined helper called only for formatting opcodes, preserving the existing shared-prefix lifetime-fence policy. Initial B386 dynamic elapsed-12.17–15.13%, static warm mixed/fresh favorable, text+1.11–3.00%, CSV mixed; original source/images/all conditions preserved in committed1746ba27 evidence. Reducing shared-loop register/code pressure is a hypothesis, not an established explanation of text timing. Native already-evaluated dynamic specs no longer require context creation;')
old=old.replace('Precise process allocation:', 'Initial B386 precise process allocation:').replace(
 'Desktop static fresh and dynamic warm adverse observations remain diagnostic; no CPU forecast.',
 'Refined warm four-case diagnostics on both APIs preserve all goldens/balances/peaks and dynamic allocation reduction; compiler sources are unchanged and its separate B386 compile allocation is reused rather than newly timed. Desktop static fresh and dynamic warm adverse observations remain diagnostic; no CPU forecast. This is the one changed-source comparison selected by the refinement; decide retention/debt afterward, no unchanged favorable retiming.')
t=t[:start]+old+t[end:]
ast.parse(t);p=home/'prepare-b387-expanded.py';p.write_text(t,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'-X','utf8',str(p)],check=True)
t=(home/'b386/launch.py').read_text(encoding='utf-8').replace('b386','b387')
ast.parse(t);(home/'b387/launch.py').write_text(t,encoding='utf-8',newline='\n')
for name in ['retrieve-b386.py','summarize-b386.py']:
 t=(home/name).read_text(encoding='utf-8').replace('b386','b387')
 if name.startswith('summarize'):t=t.replace("root/'comparison-summary.json'","root/'comparison-b387-summary.json'")
 (home/name.replace('b386','b387')).write_text(t,encoding='utf-8',newline='\n')
