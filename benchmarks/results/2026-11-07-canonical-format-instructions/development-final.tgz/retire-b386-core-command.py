from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');row={'path': '/home/lokad/lython-bench-checks/canonical-format-instructions-b386-20261107/candidate/Lokad.Lython.dll', 'bytes': 5625856, 'sha256': 'e1ee5f8a93db0b6746e595d469f5bedf5d6c33815b1e15f78d4571ea6f09371e'};p=Path(row['path'])
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py|[c]ollect.py'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert p.resolve()==p and p.is_file() and not p.is_symlink() and p.stat().st_nlink==1
 assert p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
 for raw in subprocess.check_output(['find',str(base),'-type','l','-print0']).split(b'\0'):
  if raw:
   link=Path(os.fsdecode(raw)).resolve()
   assert link!=p and link not in p.parents
 p.unlink()
 print(json.dumps(dict(retiredExpandedCore=row,independentCommittedArchive='1746ba27:benchmarks/results/2026-11-07-canonical-format-instructions/b386-checked-source-and-images.tgz',
 allUsersEnded=True,noFileOrDirectoryLinkDependencies=True,freeBytes=shutil.disk_usage(base).free),indent=2))
