from pathlib import Path
root=Path(__file__).parent;prior=root.parent/'prepared-call-layout-r31'
retrieve=(prior/'retrieve-b384.py').read_text(encoding='utf-8-sig').replace("/'b384'","/'b386'").replace(
 'prepared-call-layout-b384-20261107','canonical-format-instructions-b386-20261107').replace(
 'lython-b384-prepared-call-layout-20261107.service','lython-b386-canonical-format-20261107.service').replace(
 "status['receipt']['jobs']==6","status['receipt']['jobs']==5")
# The bound is an enforced precondition even when this file is invoked directly.
retrieve=retrieve.replace('import hashlib,json,subprocess,tarfile','import datetime,hashlib,json,subprocess,tarfile')
needle="root=Path(__file__).resolve().parent/'b386'"
retrieve=retrieve.replace(needle,needle+"\nb=json.loads((root/'observe-not-before.json').read_text())\nassert datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat(b['doNotObserveBeforeUTC'])")
(root/'retrieve-b386.py').write_text(retrieve,encoding='utf-8',newline='\n')
summary=(prior/'summarize-b384.py').read_text(encoding='utf-8-sig').replace('b384/retrieved','b386/retrieved')
(root/'summarize-b386.py').write_text(summary,encoding='utf-8',newline='\n')
print('Prepared bounded terminal retrieval and existing four-role summary.')
