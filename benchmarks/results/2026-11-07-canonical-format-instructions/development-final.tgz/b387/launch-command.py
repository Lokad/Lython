from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'canonical-format-instructions-b387-20261107'
reference=base/'report-cost-b385-20261107/candidate'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(1891126+1)
 assert len(payload)==1891126 and hashlib.sha256(payload).hexdigest()=='17b933ecaa64a97fb964614d264f6d49ac761ffb1bd2258574cd85cc453a0196'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+2*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 (root/'reference').symlink_to(reference,target_is_directory=True)
 (root/'cpython-worker.py').symlink_to(base/'prepared-call-layout-b384-20261107/cpython-worker.py')
 shutil.copytree(reference,root/'candidate',symlinks=True,copy_function=os.link)
 (root/'candidate/Lokad.Lython.dll').unlink()
 (root/'current-core.dll').replace(root/'candidate/Lokad.Lython.dll')
 identity=json.loads((root/'identity.json').read_text())
 for role in ['candidate','reference']:
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
  for name,digest in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 assert 'assert len(jobs)==5 ' in (root/'collect.py').read_text()
 assert "len(r['jobs'])==5" in (root/'archive-owned.py').read_text()
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndEveryAuxiliaryVerifiedInBothRoles=True,
  allFiveJobsValidated=True,ownerSeconds=210,stopSeconds=30,marginSeconds=40)
 assert setup['freeBytes']>2*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b387-canonical-format-20261107','--property=User=lokad',
 '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=210','--property=TimeoutStopSec=30',
 '--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
