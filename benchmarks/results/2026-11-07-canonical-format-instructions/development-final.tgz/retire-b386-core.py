from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path(__file__).parent
archive=Path('benchmarks/results/2026-11-07-canonical-format-instructions/b386-checked-source-and-images.tgz')
commit='1746ba27';name=str(archive).replace('\\','/')
assert archive.read_bytes()==subprocess.check_output(['git','show',commit+':'+name])
with tarfile.open(archive) as a:data=a.extractfile('images/net11.0/Lokad.Lython.dll').read()
row=dict(path='/home/lokad/lython-bench-checks/canonical-format-instructions-b386-20261107/candidate/Lokad.Lython.dll',
 bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
remote=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');row=ROW;p=Path(row['path'])
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py|[c]ollect.py'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert p.resolve()==p and p.is_file() and not p.is_symlink() and p.stat().st_nlink==1
 assert p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
 for raw in subprocess.check_output(['find',str(base),'-type','l','-print0']).split(b'\0'):
  if raw:
   link=Path(os.fsdecode(raw)).resolve()
   assert link!=p and link not in p.parents
 p.unlink()
 print(json.dumps(dict(retiredExpandedCore=row,independentCommittedArchive='1746ba27:benchmarks/results/2026-11-07-canonical-format-instructions/b386-checked-source-and-images.tgz',
 allUsersEnded=True,noFileOrDirectoryLinkDependencies=True,freeBytes=shutil.disk_usage(base).free),indent=2))
'''.replace('ROW',repr(row))
(root/'retire-b386-core-command.py').write_text(remote,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -']
r=subprocess.run(ssh,input=remote,text=True,encoding='utf-8',capture_output=True)
(root/'expanded-b386-core-retirement.json').write_text(r.stdout,encoding='utf-8')
assert r.returncode==0,r.stderr
print(r.stdout)
