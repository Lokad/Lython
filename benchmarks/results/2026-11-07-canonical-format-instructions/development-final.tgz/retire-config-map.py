from pathlib import Path
import subprocess,sys
root=Path(__file__).parent
t=(root.parent/'prepared-call-layout-r31/retire-expanded-maps.py').read_text(encoding='utf-8-sig')
t=t.replace('benchmarks/results/2026-11-06-remaining-runtime-cost/observations.tgz',
 'benchmarks/results/2026-11-03-json-iterator-working-storage/profile/raw-capture.tar.gz')
t=t.replace('49d40b00:','fffbbbab:').replace('remaining-cost-b340-20261106','config-cpu-b154-20261103')
t=t.replace("for case in ['class-record','text']:","for case in ['config-warm']:")
t=t.replace("for name in ['perf.map','perf-initial.map','perf-final.map']:","for name in ['perf.map']:")
t=t.replace('retire-expanded-maps-command.py','retire-config-map-command.py').replace('expanded-map-retirement.json','expanded-config-map-retirement.json')
p=root/'retire-config-map-expanded.py';p.write_text(t,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'-X','utf8',str(p)],check=True)
