from pathlib import Path
import ast,copy,hashlib,json,shutil,tarfile
root=Path(__file__).parent;prior=root.parent/'prepared-call-layout-r31'
(root/'tool').mkdir(exist_ok=False)
for name in ['Directory.Build.props','complete-jobs.csproj']:shutil.copyfile(prior/'tool'/name,root/'tool'/name)
program=(prior/'tool/Program.cs').read_text(encoding='utf-8-sig').replace(
 'Require class-factory, configuration, text and CSV cases.','Require static/dynamic report, text and CSV cases.').replace(
 'R31 prepared function-layout diagnostic','R35 canonical formatted-instruction diagnostic')
(root/'tool/Program.cs').write_text(program,encoding='utf-8',newline='\n')
catalog=json.loads((root.parent/'report-cost-r34/catalog.json').read_text(encoding='utf-8-sig'))
ids=['scripts.report-render.large','scripts.text-summary-helpers.large','scripts.csv-summary-functions.large']
cases=[copy.deepcopy(next(c for c in catalog['cases'] if c['id']==i)) for i in ids]
dynamic=copy.deepcopy(cases[0]);dynamic['id']='scripts.dynamic-report-render.large'
dynamic['source']='name_width=20\nname_precision=12\nstate_width=8\namount_width=8\n'+dynamic['source'].replace(
 ':<20.12s',':<{name_width}.{name_precision}s').replace(':^8s',':^{state_width}s').replace(':>8,d',':>{amount_width},d')
encoded=dynamic['source'].encode('utf-8');dynamic['sourceUtf8Bytes']=len(encoded);dynamic['sourceSha256']=hashlib.sha256(encoded).hexdigest()
cases.insert(1,dynamic);catalog['cases']=cases
(root/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
(root/'baseline').mkdir(exist_ok=False)
with tarfile.open(root/'before-source-and-images.tgz') as a:
 (root/'baseline/Lokad.Lython.dll').write_bytes(a.extractfile('images/net11.0/Lokad.Lython.dll').read())
measure=(root.parent/'compiler-class-facts-r30/measure.py').read_text(encoding='utf-8-sig')
measure=measure.replace("root.parent/'execution-transport-r29/allocation/candidate/Lokad.Lython.dll'","root/'baseline/Lokad.Lython.dll'")
measure=measure.replace("['baselineSHA256']","['images']['net11.0']").replace("root/'baseline.json'","root/'before.json'")
measure=measure.replace('one32-class-factory job and unchanged text control','static/dynamic reports with unchanged text/CSV controls')
measure=measure.replace("for phase in ['compile','warm']:","for phase in ['compile','warm','fresh']:")
ast.parse(measure);(root/'measure.py').write_text(measure,encoding='utf-8',newline='\n')
summary=(root.parent/'compiler-class-facts-r30/summarize.py').read_text(encoding='utf-8-sig').replace("['compile','warm']","['compile','warm','fresh']")
(root/'summarize.py').write_text(summary,encoding='utf-8',newline='\n')
verify=(prior/'verify-catalog.py').read_text(encoding='utf-8-sig').replace('for both cases','for all four cases')
(root/'verify-catalog.py').write_text(verify,encoding='utf-8',newline='\n')
print('Existing four-case compile/warm/fresh driver; two report variants and unchanged text/CSV controls.')
