from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
root=Path(__file__).parent;out=root/'original-core-test'
out.mkdir(exist_ok=False)
source=Path('tests/Lokad.Lython.Tests/bin/Release/net11.0')
for p in source.iterdir():
 if p.is_file():shutil.copyfile(p,out/p.name)
with tarfile.open(root/'before-source-and-images.tgz') as a:
 (out/'Lokad.Lython.dll').write_bytes(a.extractfile('images/net11.0/Lokad.Lython.dll').read())
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
with (root/'original-dynamic-cancellation.log').open('w',encoding='utf-8') as log:
 r=subprocess.run([env['DOTNET_HOST_PATH'],'vstest',str(out/'Lokad.Lython.WhiteBox.Tests.dll'),
  '/TestCaseFilter:FullyQualifiedName~DynamicFormattedOwnershipTests','/Framework:.NETCoreApp,Version=v11.0'],env=env,stdout=log,stderr=subprocess.STDOUT)
(root/'original-dynamic-cancellation.json').write_text(json.dumps(dict(exitCode=r.returncode,
 originalCoreSHA256=hashlib.sha256((out/'Lokad.Lython.dll').read_bytes()).hexdigest(),
 note='Current six-case new semantic fixture on the isolated original image; tests only, no source restoration.'),indent=2)+'\n',encoding='utf-8')
text=(root/'original-dynamic-cancellation.log').read_text(encoding='utf-8')
print(text[-1800:]);print('Baseline fixture return code',r.returncode)
