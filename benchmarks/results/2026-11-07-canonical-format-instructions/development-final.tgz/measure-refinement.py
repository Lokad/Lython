from pathlib import Path
import hashlib,json,os,shutil,subprocess
home=Path(__file__).parent;root=home/'refinement';root.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=json.loads((home/'focused-initial.json').read_text(encoding='utf-8'))
core=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll')
assert sha(core)==checks['coreSHA256']['net11.0']
images=root/'images';images.mkdir()
for role in ['before','candidate']:
 target=images/role;shutil.copytree(home/'images/before',target)
 if role=='candidate':shutil.copyfile(core,target/'Lokad.Lython.dll')
tool=home/'tool/out/complete-jobs.dll'
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
for api in ['sync','async']:
 folder=root/api;folder.mkdir()
 witness=folder/'hash-witness.json';witness.write_text(json.dumps(dict(source="return [hash('Lython-é😀'), hash((1, 2.0, True))]\n"),ensure_ascii=False)+'\n',encoding='utf-8')
 with (folder/'measurements.json').open('w',encoding='utf-8') as output,(folder/'stderr.txt').open('w',encoding='utf-8') as errors:
  r=subprocess.run([env['DOTNET_HOST_PATH'],str(tool),str(images/'before/Lokad.Lython.Benchmarks.dll'),
   str(images/'candidate/Lokad.Lython.Benchmarks.dll'),str(home/'catalog.json'),str(witness),'reverse','warm',api],env=env,stdout=output,stderr=errors)
 assert r.returncode==0,(folder/'stderr.txt').read_text(encoding='utf-8')[-3000:]
 data=json.loads((folder/'measurements.json').read_text(encoding='utf-8'))
 assert all(data[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
 print(api,'refined four-case warm allocation/semantic/ownership gates pass',flush=True)
(root/'identity.json').write_text(json.dumps(dict(coreSHA256=checks['coreSHA256'],
 baselineSHA256=sha(images/'before/Lokad.Lython.dll'),toolSHA256=sha(tool),
 boundary='Existing complete-job warm driver, both APIs, original/catalog/auxiliary bits unchanged. Shared ALC/process GC; desktop clocks diagnostic only.',
 compileReuse='Frontend sources unchanged from checked B386; its separate compile allocation is retained, not newly timed here.'),indent=2)+'\n',encoding='utf-8')
