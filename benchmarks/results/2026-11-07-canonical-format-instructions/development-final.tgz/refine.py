from pathlib import Path
import hashlib,json,shutil,tarfile
root=Path(__file__).parent;before=json.loads((root/'before.json').read_text(encoding='utf-8'))
base=Path('src/Lokad.Lython')
with tarfile.open(root/'b386-checked-source-and-images.tgz','w:gz') as a:
 for name in before['source']:a.add(base/name,arcname='source/'+name)
 a.add('tests/Lokad.Lython.Tests/DynamicFormattedOwnershipTests.cs',arcname='DynamicFormattedOwnershipTests.cs')
 for tfm in ['net11.0','net10.0']:a.add(base/'bin/Release'/tfm/'Lokad.Lython.dll',arcname='images/'+tfm+'/Lokad.Lython.dll')
for name in ['focused-initial.json','summary.json','comparison-summary.json']:
 shutil.copyfile(root/name,root/('b386-'+name))
dispatch=base/'Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs'
t=dispatch.read_text(encoding='utf-8');start=t.index('                        case ExecutableOpCode.StartFormattedString:');end=t.index('                        case ExecutableOpCode.ApplyOperation:',start)
old=t[start:end]
native=old[:old.index('                            if (invocation is null) return InstructionPause.ContextRequired;')]
# Keep opcode routing in the existing engine. The helper only runs a formatted
# instruction; false is the same read-only context-promotion boundary.
body=native.replace('                        case','                case').replace('                            ','                    ')
body=body.replace('                            ', '                    ')
body=body.replace('                            ', '                    ')
# Dedent by eight columns consistently, preserving nested relative indentation.
body='\n'.join(line[8:] if line.startswith('        ') else line for line in native.splitlines())+'\n'
body=body.replace('scope.MemoryGovernor','context.MemoryGovernor').replace('scope.State.CancellationToken','context.State.CancellationToken').replace('invocation ?? scope','context')
body=body.replace('                            break;', '                            return true;')
# The exact original indentation after dedent is twenty spaces for case bodies.
body=body.replace('                    break;', '                    return true;')
body += '                    return false;\n                default: throw new InvalidOperationException("Unknown formatted instruction.");\n'
replacement='''                        case ExecutableOpCode.StartFormattedString or ExecutableOpCode.AppendFormattedText
                            or ExecutableOpCode.FinishFormattedString or ExecutableOpCode.ConvertFormattedValue or ExecutableOpCode.FormatField:
                            if (TryExecuteFormattedInstruction(ref execution, invocation, instruction, invocation ?? scope)) break;
'''+old[old.index('                            if (invocation is null) return InstructionPause.ContextRequired;'):]
dispatch.write_text(t[:start]+replacement+t[end:],encoding='utf-8',newline='\n')
p=base/'Runtime/LythonRuntime.Executable.PreparedOperations.cs';t=p.read_text(encoding='utf-8')
t='using System.Runtime.CompilerServices;\n'+t
index=t.index('        private static bool IsImmediateFormattedValue')
helper='''        // Keep transient guest values outside the shared dispatch loop, as
        // result publication does. Only formatting opcodes enter this helper.
        [MethodImpl(MethodImplOptions.NoInlining)]
        private static bool TryExecuteFormattedInstruction(ref ExecutableWorkState execution,
            ExecutionContext? invocation, in ExecutableInstruction instruction, ExecutionContext context)
        {
            switch (instruction.OpCode)
            {
'''+body+'''            }
        }

'''
p.write_text(t[:index]+helper+t[index:],encoding='utf-8',newline='\n')
print('Preserved B386 sources/images and observations; moved formatting locals out of shared prefix.')
