param([string]$Target = 'net11.0')
$lab = Split-Path -Parent $MyInvocation.MyCommand.Path
$dotnet = Join-Path $env:USERPROFILE '.dotnet11/dotnet.exe'
$filter = 'Category!=Stress&(FullyQualifiedName~Closure|FullyQualifiedName~Nonlocal|FullyQualifiedName~Lambda|FullyQualifiedName~ScopeDirective|FullyQualifiedName~NameBinding|FullyQualifiedName~CompilerMemory|FullyQualifiedName~Annotations|FullyQualifiedName~Callable|FullyQualifiedName~FunctionParameters|FullyQualifiedName~AdmissionFailureCommandTests)'
foreach ($suite in @('Lokad.Lython.PublicApi.Tests','Lokad.Lython.Tests')) {
    & $dotnet test "tests/$suite/$suite.csproj" -c Release -f $Target --filter $filter --nologo --verbosity minimal 2>&1 | Tee-Object -FilePath "$lab/windows-$suite-$Target.log"
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}

