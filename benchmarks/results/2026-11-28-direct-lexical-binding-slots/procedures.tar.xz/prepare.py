from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
from statistics import median
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
pair = lab / "comparison"
notes = lab.parent
prior = notes / "positional-generator-operands-b1924-20261128/comparison"
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
git = lambda *args: subprocess.check_output(["git", *args], cwd=repo)
def image(folder):
    return {p.name: digest(p) for p in folder.iterdir()}
def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")

base = git("rev-parse", "HEAD").decode().strip()
original = read(prior / "identity.json")
assert sha256(git("diff", "--binary", original["sourceRevision"], base, "--", "src")).hexdigest() == original["sourcePatchSHA256"]
patch = git("diff", "--binary", base, "--", "src")
assert patch.count(b"diff --git ") == 2 and b"LocalBindings" in patch
(lab / "candidate.patch").write_bytes(patch)
(lab / "test.patch").write_bytes(git("diff", "--binary", base, "--", "tests"))
pair.mkdir()
assert image(prior / "candidate") == original["imageFiles"]["candidate"]
for role in ("reference", "candidate"):
    copytree(prior / "candidate", pair / role)
core = "Lokad.Lython.dll"
fresh = repo / "src/Lokad.Lython/bin/Release/net11.0" / core
assert digest(fresh) != original["imageFiles"]["candidate"][core]
copyfile(fresh, pair / "candidate" / core)
images = {role: image(pair / role) for role in ("reference", "candidate")}
assert [name for name, before in images["reference"].items() if images["candidate"][name] != before] == [core]
for name in ("cpython-worker.py", "run.sh"):
    copyfile(prior / name, pair / name)
assert digest(pair / "cpython-worker.py") == original["cpythonWorkerSHA256"]
assert b"\r" not in (pair / "run.sh").read_bytes()

def verified_catalog(folder):
    path = folder / "representative.json"
    assert digest(path) == read(folder / "identity.json")["catalogs"][path.name]["sha256"]
    return read(path)

catalog = verified_catalog(notes / "assignment-target-consolidation-20261127/comparison")
config_id = "diagnostic.generated-guarded-configuration"
keep = {"diagnostic.generated-ordinary-definitions", "diagnostic.generated-escaping-definitions",
        "diagnostic.generated-guarded-report", config_id}
cases = {row["id"]: row for row in catalog["cases"] if row["id"] in keep}
assert len(cases) == 4
catalog["cases"] = list(cases.values())
write(pair / "representative.json", catalog)
jobs = [["diagnostic.generated-ordinary-definitions", "compile"],
        [config_id, "compile"],
        ["diagnostic.generated-escaping-definitions", "compile-run"],
        ["diagnostic.generated-guarded-report", "compile"],
        ["diagnostic.generated-guarded-report", "compile-run"]]
write(pair / "jobs.json", {"warm": jobs})
identity = dict(sourceRevision=base, sourcePatchSHA256=digest(lab / "candidate.patch"),
                productionReference=base, imageFiles=images,
                coreSHA256={role + suffix: hashes[core] for role, hashes in images.items() for suffix in ("", "-control")},
                cpythonWorkerSHA256=original["cpythonWorkerSHA256"], cpythonPath=original["cpythonPath"],
                expectedCPythonSHA256=original["expectedCPythonSHA256"],
                purpose="Collect lexical slots directly and share the unchanged parameter prefix.",
                catalogs={name: {"sha256": digest(pair / name)} for name in ("representative.json", "jobs.json")})
write(pair / "identity.json", identity)
collector = (prior / "collect.py").read_text(encoding="utf-8").replace("lython-positional-generator-operands-", "lython-direct-lexical-binding-slots-")
compile(collector, "collect.py", "exec")
(pair / "collect.py").write_text(collector, encoding="utf-8", newline="\n")
print("Frozen", base, identity["sourcePatchSHA256"], flush=True)

