from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import io
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
pair = lab / "comparison"
report = repo / "benchmarks/results/2026-11-28-direct-lexical-binding-slots"
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
identity = read(pair / "identity.json")
summary = read(pair / "summary.json")
receipt = read(pair / "archive-receipt.json")

for tree, file in (("src", "candidate.patch"), ("tests", "test.patch")):
    patch = subprocess.check_output(["git", "diff", "--binary", identity["sourceRevision"], "--", tree], cwd=repo)
    assert patch == (lab / file).read_bytes(), tree
assert digest(lab / "candidate.patch") == identity["sourcePatchSHA256"] == summary["candidatePatchSHA256"]
assert summary["verifiedTimedBatches"] == 140 and summary["quietMachine"] is False
assert all(receipt[key] for key in ("complete", "allWorkersJoined", "guestFixturesRemoved", "archivedAndVerifiedUnderLease"))
assert receipt["archiveSHA256"] == digest(pair / "observations.tar.xz")
for role, expected in identity["imageFiles"].items():
    assert len(expected) == 32
    assert {x.name: digest(x) for x in (pair / role).iterdir()} == expected
    verification = read(pair / (role + "-verify.json"))
    assert verification["state"] == "Completed" and verification["caseCount"] == 4
reference, candidate = (identity["imageFiles"][role] for role in ("reference", "candidate"))
assert {name for name in reference if reference[name] != candidate[name]} == {"Lokad.Lython.dll"}

report.mkdir(exist_ok=True, parents=True)
for name in ("summary.json", "identity.json", "observations.tar.xz"):
    copyfile(pair / name, report / name)
parity = read(pair / "compiler-parity.json")
assert len(parity["cases"]) == 20 and len(parity["diagnostics"]) == 24
assert sum(row["budgetLevels"] for row in parity["cases"]) == 154
copyfile(pair / "compiler-parity.json", report / "compiler-parity.json")

files = [
    *[(lab / name, name) for name in ("archive.py", "prepare.py", "prepare.log", "candidate.patch", "test.patch",
                                    "summarize.py", "check-compiler.py", "compiler-checks.log", "test-ubuntu.sh", "test-windows.ps1")],
    *[(pair / name, name) for name in ("run.sh", "collect.py", "archive-receipt.json", "collection.log",
                                     "exit-code.txt", "reference-verify.json", "candidate-verify.json", "jobs.json", "representative.json")],
    *[(lab / "probe" / name, "probe/" + name) for name in ("CompilerFacts.csproj", "Program.cs")],
    *[(pair / ("probe-" + role) / name, ("probe-" + role) + "/" + name)
      for role in ("reference", "candidate") for name in ("observed.json", "cancellation.json", "diagnostics.json")],
    *[(path, path.name) for path in sorted(lab.glob("*net*.log"))],
]
with tarfile.open(report / "procedures.tar.xz", "w:xz") as bundle:
    for path, name in files:
        payload = path.read_bytes()
        info = tarfile.TarInfo(name)
        info.size = len(payload)
        bundle.addfile(info, io.BytesIO(payload))
with tarfile.open(report / "procedures.tar.xz") as bundle:
    assert all(bundle.extractfile(name).read() == path.read_bytes() for path, name in files)
assert digest(report / "observations.tar.xz") == receipt["archiveSHA256"]
print(f"{len(files)} procedure files verified, {sum(path.stat().st_size for path in report.iterdir())} evidence bytes")
