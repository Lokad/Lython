#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/demanded-jump-targets-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter 'FullyQualifiedName~CapturedScalarObservationTests' --verbosity quiet
