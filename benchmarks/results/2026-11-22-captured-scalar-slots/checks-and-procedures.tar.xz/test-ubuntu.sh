#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/captured-scalar-slots-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/captured-scalar-slots-20261122
white='Category!=Stress&(FullyQualifiedName~Captured|FullyQualifiedName~Closure|FullyQualifiedName~ExecutableCallTransfer|FullyQualifiedName~BoundInvocation)'
public='Category!=Stress&(FullyQualifiedName~Closure|FullyQualifiedName~Nonlocal|FullyQualifiedName~FramedFunctionExecution|FullyQualifiedName~Cancellation|FullyQualifiedName~MemoryBudget)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$white" --verbosity quiet > "$logs/white-ubuntu.log" 2>&1 || { tail -30 "$logs/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$public" --verbosity quiet > "$logs/public-ubuntu.log" 2>&1 || { tail -30 "$logs/public-ubuntu.log"; exit 1; }
grep -H "Passed!" "$logs/white-ubuntu.log" "$logs/public-ubuntu.log"
