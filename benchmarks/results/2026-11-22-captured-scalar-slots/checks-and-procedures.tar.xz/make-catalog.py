from pathlib import Path
import base64
import hashlib
import json
import tarfile

lab = Path(__file__).resolve().parent
root = lab.parents[3]
previous = root/"benchmarks/results/2026-11-14-captured-scalar-storage/sources-checks-and-observations.tar.xz"
with tarfile.open(previous) as archive:
    catalog = json.load(archive.extractfile("b720/retrieved/representative.json"))
original = next(case for case in catalog["cases"] if case["id"]=="scripts.text-summary-helpers.nonlocal-counter.large")
fixture = json.loads(original["fixtureJson"])
text = base64.b64decode(fixture["inputFiles"]["input.txt"],validate=True).decode("utf-8")
assert "\r" not in text and text.endswith("\n")
last_line_width = 1+len(text[:-1].rsplit("\n",1)[-1])
source = original["source"].replace("processed","latest_width")
source = source.replace("latest_width += 1","latest_width = len(line) * 2 + 1")
source = source.replace("assert latest_width == 3072",f"assert latest_width == {2 * last_line_width + 1}")
assert "latest_width = len(line)" in source and "3072" not in source
encoded = source.encode("utf-8")
replacement = dict(original,id="diagnostic.text-summary.nonlocal-computed-width.large",source=source,
    sourceUtf8Bytes=len(encoded),sourceSha256=hashlib.sha256(encoded).hexdigest())
factories = json.loads((lab.parent/"direct-default-instructions-20261122/representative.json").read_text(encoding="utf-8"))
ids = {"scripts.ordinary-fully-supplied-helper","scripts.annotated-rule-closures.literal-positional-dynamic-keyword"}
factory_cases = [case for case in factories["cases"] if case["id"] in ids]
assert len(factory_cases)==2
catalog["cases"] = [replacement, original] + factory_cases
(lab/"representative.json").write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
print("Prepared computed nonlocal stores, captured updates, a mixed factory and fully supplied calls.")
