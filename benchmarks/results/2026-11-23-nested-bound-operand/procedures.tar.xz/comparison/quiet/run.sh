set -eu
root=/home/lokad/lython-bench-checks/nested-bound-operand-b1439-20261123
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
