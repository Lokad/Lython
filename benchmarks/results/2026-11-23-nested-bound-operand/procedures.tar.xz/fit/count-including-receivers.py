from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/".git/agent-worktrees/native-transition-inventory-20261123"
out=lab/"including-receivers"
out.mkdir(exist_ok=False)
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])

def git(*args):
    return subprocess.check_output(["git",*args],cwd=tree)

def run(command,cwd=repo,**kwargs):
    subprocess.run(command,cwd=cwd,env=env,timeout=90,check=True,**kwargs)

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path,text):
    path.write_text(text,encoding="utf-8",newline="\n")

def save(path,value):
    write(path,json.dumps(value,ensure_ascii=False,indent=2)+"\n")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def insert_after(text,anchor,replacement):
    assert text.count(anchor)==1,anchor
    return text.replace(anchor,anchor+replacement,1)

revision=git("rev-parse","HEAD").decode().strip()
target="9fb7fdcfb"
assert revision.startswith("d97ddcce9") and not git("status","--porcelain")
assert not git("diff",target,"HEAD","--","src/Lokad.Lython")
runtime=tree/"src/Lokad.Lython/Runtime"
outer=runtime/"LythonRuntime.Executable.Calls.Invoke.cs"
inner=runtime/"LythonRuntime.Executable.NativePrefix.cs"
original={p:p.read_bytes() for p in (outer,inner)}
counters=("FramedCopied","FramedFit","FramedFitWithCleanupProof","FramedOldEligibility",
    "NestedCopied","NestedFitAt16","NestedFitCurrent","NestedFitAt16WithoutUnpack",
    "NestedFitAt16WithoutOwners","NestedFitAt16WithAllProofs","NestedBoundInteger")
try:
    code=outer.read_text(encoding="utf-8")
    code=insert_after(code,"    internal sealed partial class ExecutionContext\n    {\n",
        "\n".join(f"        internal static int Diagnostic{name};" for name in counters)+"\n\n")
    code=insert_after(code,"                    var unpackedReturn = PrepareUnpackedCallReturn(ref execution, call, start, out var originalExtent);\n",
        """                    if (completePositional && (functionReceiver is not null || !function.CodeObject.HasDirectIntegerReturn))
                    {
                        Interlocked.Increment(ref DiagnosticFramedCopied);
                        var position = start + call.ArgumentOffset - (functionReceiver is null ? 0 : 1);
                        var required = function.CodeObject.ValueStorageCapacity;
                        var argsEnd = start + call.ArgumentOffset + call.ArgumentCount;
                        if (originalExtent == argsEnd && position >= start && required <= execution.Code.ValueStorageCapacity - position)
                        {
                            Interlocked.Increment(ref DiagnosticFramedFit);
                            if (execution.Stack.CanRetireWithoutCleanup(position))
                            {
                                Interlocked.Increment(ref DiagnosticFramedFitWithCleanupProof);
                                if (functionReceiver is null && !call.HasReceiver && call.UnpackedReturnCount == 0)
                                    Interlocked.Increment(ref DiagnosticFramedOldEligibility);
                            }
                        }
                    }
""")
    write(outer,code)
    code=inner.read_text(encoding="utf-8")
    code=insert_after(code,"                var consumedByIteration = call.ConsumedByIteration || _consumedByIteration && call.ReturnedDirectly;\n",
        """                if (completePositional && (receiver is not null || !function.CodeObject.HasDirectIntegerReturn))
                {
                    Interlocked.Increment(ref ExecutionContext.DiagnosticNestedCopied);
                    var position = start + call.ArgumentOffset - (receiver is null ? 0 : 1);
                    var required = function.CodeObject.ValueStorageCapacity;
                    if (receiver is not null && function.CodeObject.HasDirectIntegerReturn
                        && call.ArgumentCount + 1 == function.CodeObject.FirstTemporarySlot)
                        Interlocked.Increment(ref ExecutionContext.DiagnosticNestedBoundInteger);
                    var argsEnd = start + call.ArgumentOffset + call.ArgumentCount;
                    if (LiveExtent == argsEnd && position >= start)
                    {
                        if (required <= Values.Length - position)
                            Interlocked.Increment(ref ExecutionContext.DiagnosticNestedFitCurrent);
                        if (required <= NativeValueCapacity - position)
                        {
                            Interlocked.Increment(ref ExecutionContext.DiagnosticNestedFitAt16);
                            if (call.UnpackedReturnCount == 0)
                                Interlocked.Increment(ref ExecutionContext.DiagnosticNestedFitAt16WithoutUnpack);
                            if (Code.LastOwnedTemporarySlot < position)
                            {
                                Interlocked.Increment(ref ExecutionContext.DiagnosticNestedFitAt16WithoutOwners);
                                if (call.UnpackedReturnCount == 0)
                                    Interlocked.Increment(ref ExecutionContext.DiagnosticNestedFitAt16WithAllProofs);
                            }
                        }
                    }
                }
""")
    write(inner,code)
    (out/"diagnostic.patch").write_bytes(git("diff","--binary","--","src"))
    with (out/"core-build.log").open("w",encoding="utf-8") as log:
        run([dotnet,"build","src/Lokad.Lython/Lokad.Lython.csproj","-c","Release","-f","net11.0",
             "--no-incremental","--artifacts-path",out/"artifacts","--nologo"],cwd=tree,stdout=log,stderr=subprocess.STDOUT)
finally:
    for path,data in original.items():path.write_bytes(data)
assert not git("status","--porcelain")

base=lab.parent/"single-owner-function-preflight-20261123/comparison"
donor=base/"frozen-reference"
info=read(base/"quiet/identity.json")
manifest=info["imageFiles"]["reference"]
assert len(manifest)==32 and {name:sha(donor/name) for name in manifest}==manifest
catalog_path=base/"quiet/representative.json"
assert sha(catalog_path)==info["catalogs"][catalog_path.name]["sha256"]
catalog=read(catalog_path)
assert len(catalog["cases"])==7
catalog["cases"]=[{**c,"id":c["id"]+(".async" if asynchronous else ""), "runAsync":asynchronous}
                  for c in catalog["cases"] for asynchronous in (False,True)]
case_path=out/"cases.json"
save(case_path,catalog)
image=out/"image"
image.mkdir()
for name in manifest:shutil.copyfile(donor/name,image/name)
shutil.copyfile(out/"artifacts/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll",image/"Lokad.Lython.dll")
hashes={name:sha(image/name) for name in manifest}
assert [n for n in hashes if hashes[n]!=manifest[n]]==["Lokad.Lython.dll"]

recipe=repo/"benchmarks/results/2026-11-22-native-operand-call-loan/route-procedures.tar.xz"
with tarfile.open(recipe) as recipes:
    cs=recipes.extractfile("Program.cs").read().decode("utf-8-sig")
    project=recipes.extractfile("RouteProbe.csproj").read().decode("utf-8-sig")
start=cs.index("var entries =")
end=cs.index("foreach (var item",start)
names=json.dumps(counters)
cs=cs[:start]+f'''string[] names = {names};
var runtime = typeof(LythonEngine).Assembly.GetType("Lokad.Lython.Runtime.LythonRuntime+ExecutionContext", true)!;
var fields = names.Select(name => runtime.GetField("Diagnostic" + name, all)!).ToArray();
'''+cs[end:]
start=cs.index("        entries.SetValue")
end=cs.index("        script.Dispose();",start)
cs=cs[:start]+'''        foreach (var field in fields) field.SetValue(null, 0);
        Run();
        rows.Add(new { id = item.GetProperty("id").GetString(), asynchronous,
            routes = names.Zip(fields, (name, field) => (name, value: (int)field.GetValue(null)!))
                .ToDictionary(item => item.name, item => item.value),
            peakExecutionMemoryBytes, allowanceReturned = true });
'''+cs[end:]
write(out/"Program.cs",cs)
write(out/"RouteProbe.csproj",project)
with (out/"probe-build.log").open("w",encoding="utf-8") as log:
    run([dotnet,"build",out/"RouteProbe.csproj","-c","Release","--no-incremental","--nologo"],stdout=log,stderr=subprocess.STDOUT)
for path in (out/"bin/Release/net11.0").glob("RouteProbe.*"):shutil.copyfile(path,image/path.name)
report=out/"routes.json"
run([dotnet,image/"RouteProbe.dll",image,case_path,report])
assert {n:sha(image/n) for n in hashes}==hashes
save(out/"identity.json",dict(equivalentCoreSource=target,instrumentedBaseRevision=revision,imageHashes=hashes,
                            stagedWorkerHashes=manifest,sourceCatalogSHA256=sha(catalog_path),
                            projectedCatalogSHA256=sha(case_path),instrumentationSHA256=sha(out/"diagnostic.patch")))
for row in read(report)["rows"]:
    print(row["id"],row["routes"],row["peakExecutionMemoryBytes"],flush=True)
