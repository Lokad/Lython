from pathlib import Path
import hashlib
import json
import tarfile

lab = Path(__file__).resolve().parent
initial = lab / "quiet"
confirmation = lab / "confirmation"

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, source):
    if path.suffix == ".py":
        compile(source, str(path), "exec")
    path.write_text(source, encoding="utf-8", newline="\n")

old = read(initial / "config.json")
identity = old["identity"]
receipt = read(initial / "archive-receipt.json")
assert receipt["complete"] and receipt["quietBeforeAndAfter"] and receipt["allWorkersJoined"]
assert sha(initial / "observations.tgz") == receipt["archiveSHA256"]
catalog = initial / "representative.json"
assert sha(catalog) == identity["catalogSHA256"]
for role, files in identity["imageFiles"].items():
    assert len(files) == 32 and all(sha(lab / "frozen" / role / n) == h for n, h in files.items())
    proof = read(lab / f"quiet-{role}-verify.json")
    assert proof["state"] == "Completed" and proof["caseCount"] == 5 and proof["catalogSha256"] == sha(catalog)

root = "/home/lokad/lython-bench-checks/direct-lexical-keyword-default-b1352-confirmation-20261122"
unit = "lython-b1352-direct-lexical-keyword-default-confirmation-20261122"
jobs = [
    ("scripts.annotated-rule-closures.nested-factories", "warm"),
    ("scripts.factory-observed-defaults", "warm"),
    ("scripts.annotated-rule-closures.literal-positional-dynamic-keyword", "compile-run"),
]
confirmation.mkdir()
write(confirmation / "identity.json", (initial / "identity.json").read_text(encoding="utf-8"))
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    source = (initial / name).read_text(encoding="utf-8").replace(old["root"], root).replace(old["unit"], unit)
    if name == "collect.py":
        start = source.index("\njobs = ")
        end = source.index("\nassert len(jobs)", start)
        source = source[:start] + "\njobs = " + repr(jobs) + source[end:]
        source = source.replace("len(jobs)==7", "len(jobs)==3")
        source = source.replace("job_index % 2 == 0", "job_index % 2 != 0").replace("started < 385", "started < 190")
    elif name == "archive-owned.py":
        source = source.replace("len(raw['jobs'])==7", "len(raw['jobs'])==3").replace("jobs=7,", "jobs=3,")
    elif name == "retrieve.py":
        source = source.replace("['jobs']==7", "['jobs']==3")
    write(confirmation / name, source)
assert b"\r" not in (confirmation / "run.sh").read_bytes()
parts = ("identity.json", "collect.py", "archive-owned.py", "run.sh")
payload = confirmation / "payload.tgz"
with tarfile.open(payload, "w:gz") as archive:
    for name in parts:
        archive.add(confirmation / name, arcname=name)

config = dict(old, root=root, unit=unit, source=old["root"], sourceFiles=identity["imageFiles"]["reference"],
    sourceCatalogSHA256=sha(catalog), donorArchiveSHA256=receipt["archiveSHA256"],
    protocolSource=old["root"] + "/cpython-worker.py", retireGroups=[],
    payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload),
    unpackedBytes=sum((confirmation / name).stat().st_size for name in parts))
write(confirmation / "config.json", json.dumps(config, indent=2) + "\n")
source = (initial / "remote-launch.py").read_text(encoding="utf-8")
start = source.index("\nc=") + 1
end = source.index("\nb=Path(", start)
source = source[:start] + "c=" + repr(config) + source[end:]
source = source.replace(" for n,h in c['sourceFiles'].items():assert sha(source/c['sourceRole']/n)==h,n",
    " for role,files in c['identity']['imageFiles'].items():\n  for n,h in files.items():assert sha(source/role/n)==h,n")
source = source.replace("os.link(source/c['sourceRole']/n,p)", "os.link(source/role/n,p)")
source = source.replace("lython-b1352-fixtures", "lython-b1352-confirmation-fixtures").replace("RuntimeMaxSec=455", "RuntimeMaxSec=245")
write(confirmation / "remote-launch.py", source)
source = (lab / "launch.py").read_text(encoding="utf-8")
source = source.replace("Path(__file__).parent/'quiet'", "Path(__file__).parent").replace("420", "200")
source = source.replace("Direct lexical keyword default comparison", "Direct lexical keyword default confirmation")
write(confirmation / "launch.py", source)
source = (lab / "summarize.py").read_text(encoding="utf-8")
source = source.replace("r/'quiet/", "r/'").replace("len(raw['jobs'])==7", "len(raw['jobs'])==3")
write(confirmation / "summarize.py", source)
print("Prepared reversed-order eager and observer warm controls and mixed time-to-result confirmation using the same frozen images and catalog.")
