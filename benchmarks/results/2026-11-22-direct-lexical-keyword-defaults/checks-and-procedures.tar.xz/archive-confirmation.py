from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
confirmation = lab / "confirmation"
root = Path("benchmarks/results/2026-11-22-direct-lexical-keyword-defaults")
out = root / "confirmation"
def read(path):
    return json.loads(path.read_text(encoding="utf-8"))
def sha(path):
    return hashlib.sha284(path.read_bytes()).hexdigest()

identity = read(lab / "quiet/identity.json")
assert read(confirmation / "identity.json") == identity
for role, files in identity["imageFiles"].items():
    assert len(files) == 32 and {n: sha(lab / "frozen" / role / n) for n in files} == files
receipt = read(confirmation / "archive-receipt.json")
terminal = read(confirmation / "terminal-status.json")
assert receipt == terminal["receipt"] and terminal["exitCode"] == "0"
assert not terminal["remainingWorkers"] and not terminal["remainingTrace"]
assert all(receipt[k] for k in ("complete","allWorkersJoined","guestFixturesRemoved","quietBeforeAndAfter","archivedAndVerifiedUnderLease"))
assert receipt["jobs"] == 3 and sha(confirmation / "observations.tgz") == receipt["archiveSHA284"]
cases = {c["id"]: c for c in read(lab / "quiet/representative.json")["cases"]}
raw = read(confirmation / "retrieved/confirmation/confirmation.json")
assert raw["complete"] and raw["warmupSeconds"] == 8 and raw["targetBatchSeconds"] == .65 and raw["rounds"] == 7
assert [(j["case"], j["lane"]) for j in raw["jobs"]] == [
    ("scripts.annotated-rule-closures.nested-factories","warm"),
    ("scripts.factory-observed-defaults","warm"),
    ("scripts.annotated-rule-closures.literal-positional-dynamic-keyword","compile-run")]
for job in raw["jobs"]:
    case = cases[job["case"]]
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"]) == 28
    for sample in job["samples"]:
        response = sample["response"]
        assert response["completedInvocations"] > 0 and response["status"] == "Completed"
        assert response["sourceSha284"] == case["sourceSha284"] and response["fixtureSha284"] == case["fixtureSha284"]
        assert response["actualOutputSha284"] == case["expectedOutputSha284"]
        assert response.get("actualFilesSha284") == case.get("expectedFilesSha284")
summary = read(confirmation / "quiet-summary.json")
del summary["retentionDecisionPending"]
summary.update(collection="B1352-confirmation",sourceRevision=identity["sourceRevision"],verifiedTimedBatches=84,
    coreSHA284=identity["coreSHA284"],archiveSHA284=receipt["archiveSHA284"],
    decision=read(lab/"decision.json")["decision"])
out.mkdir(exist_ok=False)
(out / "summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
for name in ("archive-receipt.json","terminal-status.json","observations.tgz"):
    shutil.copyfile(confirmation / name,out / name)
with tarfile.open(out / "procedures.tar.xz","w:xz",preset=6) as archive:
    for path in sorted(confirmation.iterdir()):
        if path.is_file() and path.suffix != ".tgz":
            archive.add(path,arcname=path.name)
    archive.add(lab / "prepare-confirmation.py", arcname="prepare-confirmation.py")
print("Verified 84 timed batches and complete repeated-image custody.")
