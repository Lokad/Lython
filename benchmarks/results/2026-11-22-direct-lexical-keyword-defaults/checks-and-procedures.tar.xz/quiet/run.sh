set -eu
root=/home/lokad/lython-bench-checks/direct-lexical-keyword-default-b1352-20261122
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
