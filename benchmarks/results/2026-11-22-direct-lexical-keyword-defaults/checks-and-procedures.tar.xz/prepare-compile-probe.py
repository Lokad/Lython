from pathlib import Path
import hashlib,json,shutil

lab=Path('.git/agent-notes/review-20261031/direct-lexical-keyword-default-20261122')
source=lab.parent/'direct-jump-layout-20261122/reference/compile'
original=json.loads((source.parents[1]/'inspection-identity.json').read_text(encoding='utf-8'))['workerImages']['reference']['compile']
core='Lokad.Lython.dll'
sha=lambda file:hashlib.sha256(file.read_bytes()).hexdigest()
assert {f.name:sha(f) for f in source.iterdir() if f.is_file()}==original
images={}
for role in ('reference','candidate'):
    dest=lab/role/'compile'
    dest.mkdir(parents=True,exist_ok=True)
    for name,digest in original.items():
        src=lab/'frozen'/role/core if name==core else source/name
        shutil.copyfile(src,dest/name)
        assert sha(src)==sha(dest/name)
    images[role]={'compile':{f.name:sha(f) for f in dest.iterdir() if f.is_file()}}
file_identity=json.loads((lab/'identity.json').read_text(encoding='utf-8'))
assert all(images[role]['compile'][core]==file_identity['imageFiles'][role][core] for role in images)
data=dict(workerImages=images,fixtureSHA256=sha(lab/'inspect-catalog.json'))
(lab/'inspection-identity.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')

