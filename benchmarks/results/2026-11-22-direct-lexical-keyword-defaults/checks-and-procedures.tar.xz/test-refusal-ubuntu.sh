#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/direct-lexical-keyword-default-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
log=/mnt/d/code/Lython/.git/agent-notes/review-20261031/direct-lexical-keyword-default-20261122/refusal-ubuntu.log
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter 'FullyQualifiedName~RefusingDirectKeywordDefaultStops' --verbosity quiet > "$log" 2>&1 || { tail -30 "$log"; exit 1; }
grep 'Passed!' "$log"
