from pathlib import Path
import os,subprocess
repo=Path('D:/code/Lython');r=repo/'.git/agent-notes/review-20261031/name-preparation-r524';project=r/'inspect';project.mkdir(parents=True,exist_ok=False);prior=r.parent/'discarded-results-r516/inspect-pair';s=(prior/'Program.cs').read_text(encoding='utf-8');s=s.replace('using Lokad.Lython.Frontend;','using Lokad.Lython.Frontend;\nusing Lokad.Lython.Runtime;')
s=s.replace('            instructions.Add(new {','''            var memberName = i.OpCode is ExecutableOpCode.LoadCallMember or ExecutableOpCode.LoadMember
                ? current.Names[i.NameIndex] : null;
            instructions.Add(new { MemberName = memberName,
                StringDefinition = memberName is null ? null : LythonRuntime.StringMembers.GetMethod(memberName)?.Signature.Name,
                DictionaryDefinition = memberName is null ? null : LythonRuntime.DictMembers.GetMethod(memberName)?.Signature.Name,''')
s=s.replace('        codes.Add(new { current.Name,','''        codes.Add(new { current.Names, current.ModuleGlobalSlots,
            CoarseCurrentNamePoolBytes = 64L + 12L * current.Names.Length,
            CoarseOnePoolTwoHintsBytes = 32L + 32L * current.Names.Length,
            CapacityFitsExistingNativeBuffer = current.ValueStorageCapacity <= LythonRuntime.NativeValueCapacity,
            current.Name,''')
(project/'Program.cs').write_text(s,encoding='utf-8',newline='\n');(project/'inspect.csproj').write_text((prior/'inspect.csproj').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');core=r.parent/'module-bindings-r520/frozen/candidate/Lokad.Lython.dll';env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
with(r/'build.log').open('w',encoding='utf-8')as log:p=subprocess.run([str(d),'build',str(project/'inspect.csproj'),'-c','Release','--no-incremental','-p:InspectionCorePath='+str(core)],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0,(r/'build.log').read_text(encoding='utf-8');print('Existing managed IR diagnostic extended for name/capacity facts; no guest execution.',flush=True)
with(r/'inspect.log').open('w',encoding='utf-8')as log:p=subprocess.run([str(d),str(project/'bin/Release/net11.0/Lokad.Lython.WhiteBox.Tests.dll'),str(r.parent/'module-bindings-r520/catalog.json'),str(r/'ir.json')],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
assert p.returncode==0,(r/'inspect.log').read_text(encoding='utf-8');print((r/'inspect.log').read_text(encoding='utf-8'),flush=True)
