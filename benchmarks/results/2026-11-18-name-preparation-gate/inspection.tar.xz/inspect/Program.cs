using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;

using var catalog = JsonDocument.Parse(File.ReadAllText(args[0], System.Text.Encoding.UTF8));
var workloads = new List<object>();
foreach (var workload in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var source = workload.GetProperty("source").GetString()!;
    var frontend = LythonFrontend.Compile(source);
    if (frontend.Diagnostics.Any(d => d.Severity == LythonDiagnosticSeverity.Error))
        throw new InvalidOperationException(string.Join("; ", frontend.Diagnostics));
    var code = ExecutableScript.Compile(LoweredScript.Lower(frontend.Script!)).EntryPoint;
    var codes = new List<object>();
    var visited = new HashSet<ExecutableCodeObject>(ReferenceEqualityComparer.Instance);
    Dump(code);
    workloads.Add(new { Id = workload.GetProperty("id").GetString(), Codes = codes });

    void Dump(ExecutableCodeObject current)
    {
        if (!visited.Add(current)) return;
        var instructions = new List<object>();
        for (var n = 0; n < current.Instructions.Length; n++)
        {
            var i = current.Instructions[n];
            object? call = null;
            if (i.OpCode == ExecutableOpCode.Call)
            {
                var site = current.CallSites[i.CallSiteIndex];
                call = new { site.ArgumentCount, site.ArgumentOffset, site.IsPositionalOnly,
                    site.ReturnedDirectly, site.ConsumedByIteration };
            }
            var memberName = i.OpCode is ExecutableOpCode.LoadCallMember or ExecutableOpCode.LoadMember
                ? current.Names[i.NameIndex] : null;
            instructions.Add(new { MemberName = memberName,
                StringDefinition = memberName is null ? null : LythonRuntime.StringMembers.GetMethod(memberName)?.Signature.Name,
                DictionaryDefinition = memberName is null ? null : LythonRuntime.DictMembers.GetMethod(memberName)?.Signature.Name, Position = n, OpCode = i.OpCode.ToString(), i.InputStart,
                RawSecondary = i.SecondInput, i.ResultSlot, i.LiveExtent, HasResultConsumer = i.HasResultConsumer,
                Local = i.OpCode is ExecutableOpCode.LoadLocal or ExecutableOpCode.StoreLocal ? i.LocalSlot : -1,
                FieldCache = i.OpCode is ExecutableOpCode.Subscript or ExecutableOpCode.LoadMember or ExecutableOpCode.LoadCallMember ? i.LookupCacheIndex : -1,
                Call = call, Source = i.Span.ToString() });
        }
        codes.Add(new { current.Names, current.ModuleGlobalSlots,
            CoarseCurrentNamePoolBytes = 64L + 12L * current.Names.Length,
            CoarseOnePoolTwoHintsBytes = 32L + 32L * current.Names.Length,
            CapacityFitsExistingNativeBuffer = current.ValueStorageCapacity <= LythonRuntime.NativeValueCapacity,
            current.Name, current.IsFunctionScope, current.RequiresLocalVariableMirroring,
            current.LocalNames, current.ClosureNames, current.FirstTemporarySlot, current.ValueStorageCapacity,
            current.LookupCacheCount, current.NativePrefixEnd, current.CanRunNativeInstructions,
            OpcodeCounts = current.Instructions.GroupBy(i => i.OpCode.ToString()).ToDictionary(g => g.Key, g => g.Count()),
            Instructions = instructions });
        foreach (var function in current.Functions) Dump(function.CodeObject);
        foreach (var generator in current.Constants.OfType<ExecutableCreateGeneratorExpression>()) Dump(generator.CodeObject);
    }
}
var loaded = typeof(LythonEngine).Assembly.Location;
var output = new { Boundary = "Static executable IR from the exact frozen core; no runtime or removable-cost measurement.",
    LoadedCore = loaded, CoreSha256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(loaded))),
    Workloads = workloads };
File.WriteAllText(args[1], JsonSerializer.Serialize(output, new JsonSerializerOptions { WriteIndented = true }) + "\n", System.Text.Encoding.UTF8);
Console.WriteLine($"Inspected {workloads.Count} exact catalog sources without running guest code.");
