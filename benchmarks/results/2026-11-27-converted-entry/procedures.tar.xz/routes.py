from pathlib import Path
from hashlib import sha256
from difflib import unified_diff
import json, os, shutil, subprocess, zipfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
work = lab/'route'
work.mkdir()
previous = lab.with_name('converted-dictionary-update-routes-20261126')
base = lab.with_name('ready-starmap-async-20261127')/'local'
ref = base/'candidate'
catalog = json.loads((lab/'representative.json').read_text(encoding='utf-8'))
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
digest = lambda p: sha256(p.read_bytes()).hexdigest()
def write(path,data): path.write_text(data,encoding='utf-8',newline='\n')
def git(*args): return subprocess.check_output(['git',*args],cwd=repo)
head = git('rev-parse','HEAD').decode().strip()
assert head.startswith('7bc13cd06') and not git('diff','42b3a04d9',head,'--','src')
original = read(base/'identity.json')['imageFiles']['candidate']
assert len(original)==32 and {p.name:digest(p) for p in ref.iterdir()}==original
patch = git('diff','--binary','HEAD','--','src')
(work/'source-candidate.patch').write_bytes(patch)
snapshot=work/'source.zip'
subprocess.run(['git','archive','--format=zip','--output',snapshot,head,'--','src','Directory.Build.props',
                'Directory.Build.targets','Directory.Build.rsp','Directory.Packages.props','global.json','NuGet.Config'],cwd=repo,check=True)
source=work/'source'
with zipfile.ZipFile(snapshot) as archive:
    assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in archive.namelist())
    archive.extractall(source)
changed=[line[6:] for line in patch.decode().splitlines() if line.startswith('+++ b/')]
assert len(changed)==5 and len(set(changed))==5 and all(p.startswith('src/Lokad.Lython/') for p in changed)
for name in changed:
    shutil.copyfile(repo/name,source/name)
    assert digest(repo/name)==digest(source/name)

name='src/Lokad.Lython/Runtime/LythonRuntime.Executable.DictionaryAccumulation.cs'
path=source/name
old=path.read_text(encoding='utf-8')
outer='internal sealed partial class LythonRuntime\n{'
success='            execution.InstructionIndex = index + 5;'
assert old.count(outer)==old.count(success)==1
new=old.replace(outer,outer+'\n    internal static int DiagnosticDirectConvertedUpdates;\n    internal static int DiagnosticCallConvertedUpdates;')
new=new.replace(success,'''            if (execution.InstructionIndex == index)
                Interlocked.Increment(ref DiagnosticCallConvertedUpdates);
            else
                Interlocked.Increment(ref DiagnosticDirectConvertedUpdates);
'''+success)
write(path,new)
write(work/'diagnostic.patch',''.join(unified_diff(old.splitlines(True),new.splitlines(True),'a/'+name,'b/'+name)))
program=(previous/'Program.cs').read_text(encoding='utf-8')
first=program.index('string[] names = ['); last=program.index(';',first)
write(work/'Program.cs',program[:first]+'string[] names = ["DirectConvertedUpdates", "CallConvertedUpdates"]'+program[last:])
shutil.copyfile(previous/'RouteProbe.csproj',work/'RouteProbe.csproj')
write(work/'cases.json',json.dumps(catalog|{'cases':[row|{'runAsync':mode} for mode in (False,True) for row in catalog['cases']]},
                                  ensure_ascii=False,indent=2)+'\n')
image=work/'image'
shutil.copytree(ref,image)
assert {p.name:digest(p) for p in image.iterdir()}==original
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
def run(args,log):
    with (work/log).open('wb') as stream:
        subprocess.run([dotnet,*args],stdout=stream,stderr=subprocess.STDOUT,env=env,cwd=repo,check=True,timeout=150)
run(['build',source/'src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-incremental','-o',work/'core'],'core.log')
shutil.copyfile(work/'core/Lokad.Lython.dll',image/'Lokad.Lython.dll')
run(['build',work/'RouteProbe.csproj','-c','Release','-o',work/'probe'],'probe.log')
for item in (work/'probe').glob('RouteProbe*'):
    shutil.copyfile(item,image/item.name)
run([image/'RouteProbe.dll',image,work/'cases.json',work/'routes.json'],'verify.log')
record=dict(sourceRevision=head,baseImage=original,diagnosticCoreSHA256=digest(image/'Lokad.Lython.dll'),
            sourcePatchSHA256=digest(work/'source-candidate.patch'),diagnosticPatchSHA256=digest(work/'diagnostic.patch'),
            casesSHA256=digest(work/'cases.json'))
write(work/'identity.json',json.dumps(record,indent=2)+'\n')
for row in read(work/'routes.json')['rows']:
    print(row['id'],row['asynchronous'],row['routes'])