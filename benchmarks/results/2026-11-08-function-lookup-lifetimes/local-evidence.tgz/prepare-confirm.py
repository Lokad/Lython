from pathlib import Path
import hashlib,json,subprocess,base64,ast,shutil,tarfile
r=Path('.git/agent-notes/review-20261031/function-lookup-lifetime-r121');old=r/'b479';b=r/'b480';b.mkdir();catalog=json.loads((old/'representative.json').read_text(encoding='utf-8'));extra=json.loads((r.parent/'current-cpython-r117/representative.json').read_text(encoding='utf-8'));original=next(c for c in extra['cases']if c['id']=='scripts.csv-validated-records.large');inline=dict(original);inline['id']='scripts.csv-validated-records-inline.large';inline['source']='''import csv

totals = {}
accepted = 0
with open('input.csv', newline='') as source:
    for row in csv.DictReader(source):
        amount = int(row['amount'])
        if amount < 0:
            continue
        if row['note'] == 'skip':
            continue
        kind = row['kind']
        totals[kind] = totals.get(kind, 0) + amount
        accepted += 1
with open('report.csv', 'w', newline='') as target:
    writer = csv.writer(target, lineterminator='\\n')
    writer.writerow(['kind', 'total'])
    for kind in sorted(totals):
        writer.writerow([kind, totals[kind]])
print(accepted)
''';inline['sourceSha256']=hashlib.sha256(inline['source'].encode()).hexdigest();inline['sourceUtf8Bytes']=len(inline['source'].encode());fixture=json.loads(inline['fixtureJson']);check=b/'independent-inline';check.mkdir()
for name,data in fixture['inputFiles'].items():
 p=check/name;assert p.resolve().is_relative_to(check.resolve());p.write_bytes(base64.b64decode(data))
done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',inline['source']],cwd=check,capture_output=True,text=True,encoding='utf-8');(b/'inline-cpython.stdout').write_text(done.stdout,encoding='utf-8');(b/'inline-cpython.stderr').write_text(done.stderr,encoding='utf-8');assert done.returncode==0 and done.stdout==inline['expectedOutput'] and not done.stderr
for name,data in fixture['outputFiles'].items():assert(check/name).read_bytes()==base64.b64decode(data)
assert not set(c['id']for c in catalog['cases'])&{original['id'],inline['id']};catalog['cases'] += [original,inline];catalog['performanceQualified']=False;(b/'representative.json').write_text(json.dumps(catalog,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8')
i=json.loads((old/'identity.json').read_text(encoding='utf-8'));baseline=json.loads((r/'baseline.json').read_text(encoding='utf-8'));reference=baseline['coreSHA256'];assert reference.startswith('9ae02fed');jobs=[['scripts.report-render.large','warm'],[original['id'],'warm'],[inline['id'],'warm'],['scripts.csv-float-accounting.large','warm-async']]
i.update(baselineSource='Retained ca835/core9ae focused, isolate R121; prior qualified19b8/c617 combined B479 preserved',coreSHA256={role:reference if role.startswith('reference')else i['coreSHA256']['candidate']for role in ['reference','reference-control','candidate','candidate-control']},jobs=jobs);(b/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf-8')
for n in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
 s=(old/n).read_text(encoding='utf-8').replace('function-lookups-b479-20261108','helper-confirm-b480-20261108').replace('lython-b479-function-lookups','lython-b480-helper-confirm').replace('function-lookups-b479-launch.py','helper-confirm-b480-launch.py').replace('lython-b479-fixtures','lython-b480-fixtures')
 if n=='collect.py':
  a=s.index('jobs=');z=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[z:];s=s.replace('assert len(jobs)==8','assert len(jobs)==4').replace('warmupSeconds=5','warmupSeconds=10').replace('time.monotonic()+5; rows=[]','time.monotonic()+10; rows=[]').replace('time.monotonic()-started < 240','time.monotonic()-started < 210');a=s.index("purpose='");z=s.index("',\n",a);s=s[:a]+"purpose='R121 bounded confirmation: report/helper validation and independently CPython-checked inline control, asyncfloat control, ca835/core9ae baseline isolates R121. Preserve B479 report8.35percent variation/floatasync+1-2percent possible debt and all initial/refined adverse data. No automatic promotion or permanent closure"+s[z:]
 if n=='archive-owned.py':s=s.replace("len(r['jobs'])==8","len(r['jobs'])==4").replace('jobs=8','jobs=4')
 if n=='retrieve.py':s=s.replace("status['receipt']['jobs']==8","status['receipt']['jobs']==4")
 if n=='launch.py':
  s=s.replace("reference=base/'record-fields-b478-20261108/candidate'","reference=base/'function-lookups-b479-20261108/candidate'")
  s=s.replace("assert hashlib.sha256((reference/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256']['reference']","assert hashlib.sha256((reference/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256']['candidate']")
  s=s.replace("os.link(reference/'Lokad.Lython.dll',root/'baseline-core.dll')","assert hashlib.sha256((root/'baseline-core.dll').read_bytes()).hexdigest()==identity['coreSHA256']['reference']\n os.link(reference/'Lokad.Lython.dll',root/'current-core.dll')")
  s=s.replace("assert 'assert len(jobs)==8 '","assert 'assert len(jobs)==4 '").replace('ownerSeconds=270','ownerSeconds=240').replace('RuntimeMaxSec=270','RuntimeMaxSec=240').replace('seconds=330','seconds=300')
 (b/n).write_text(s,encoding='utf-8',newline='\n')
 if n.endswith('.py'):ast.parse(s)
for src,name in [(r/'images/before/Lokad.Lython.dll','baseline-core.dll'),(r/'refined/identity.json','focused.json'),(r/'refined/source.patch','source.patch'),(r/'refined/pre-measurement-plan.md','pre-measurement-plan.md')]:shutil.copyfile(src,b/name)
(b/'baseline-source.json').write_text(json.dumps(baseline,indent=2)+'\n',encoding='utf-8');dynamic=sum((p.stat().st_size+4095)//4096*4096 for p in(old/'retrieved/confirmation').rglob('*')if p.is_file());estimate=(dynamic+(old/'observations.tgz').stat().st_size+(b/'representative.json').stat().st_size)*1.5;assert estimate<12*1024*1024
(b/'sizing.json').write_text(json.dumps(dict(priorRoundedDynamicBytes=dynamic,priorFullArchiveBytes=(old/'observations.tgz').stat().st_size,newCatalogBytes=(b/'representative.json').stat().st_size,estimateWith50PercentHeadroom=estimate,evidenceHeadroomBytes=12*1024*1024,osFloorBytes=240*1024*1024,candidateArchiveReused=True,noEvidenceDeleted=True),indent=2)+'\n',encoding='utf-8');(b/'setup-contract.json').write_text(json.dumps(dict(jobs=jobs,ownerSeconds=240,stopSeconds=30,marginSeconds=30,evidenceHeadroomMiB=12,osFloorMiB=240),indent=2)+'\n',encoding='utf-8')
(b/'contract.md').write_text('''R121 bounded four-job confirmation, actual ca835/core9ae -> same c617 refined source. B479 combined baseline19b8 report candidate8.35%spread/asyncfloat+1–2%debt and all adverse retained. Add existing primary CSV validated-record helper (5120rows), not a new synthetic framework, and an inline equivalent independently CPython-checked against its exact stdout/report bytes. Report and asyncfloat controls unchanged.10swarmup/7rotated150msrounds/two roles percore,4jobs,240sfiniteowner+30stop+30margin, lastjobadmission<210. Full existing semantic goldens/Ready/core/aux/zero balances/quiet/join/unmount/archive/local gates. Same normalGC/tiering/worker7cf/optional0.4. Actual payload and prior full raw/archive/newcatalog+50% <12MiBheadroom, floor240MiB. All evidence paths/bytes preserved. This isolates R121; no mixing source pairs, CPU claim from allocation or automatic promotion. Decide whether eliminated lookup work justifies added lifetime rules with explicit float/control debt; if still uncertain, record uncertainty rather than design failure/permanent closure. Full retained delivery at meaningful checkpoint, old CI never queried. Native guards unchanged, no new owner/ledger/framework/options, publication postponed.
''',encoding='utf-8')
with tarfile.open(b/'payload.tgz','w:gz')as t:
 for n in ['collect.py','run.sh','baseline-core.dll','representative.json','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','archive-owned.py','baseline-source.json','sizing.json']:t.add(b/n,arcname=n)
s=(r/'prepare-space.py').read_text(encoding='utf-8').replace('r121-core-dedup-proof.json','r121-confirm-core-dedup-proof.json').replace('.r121-identical-link','.r121-confirm-identical-link').replace('if saved>=8*1024*1024','if saved>=12*1024*1024').replace('assert 8*1024*1024<=saved<=14*1024*1024','assert 12*1024*1024<=saved<=20*1024*1024');(b/'prepare-space.py').write_text(s,encoding='utf-8')
print('B480 prepared',jobs,'inline goldens independently pass, evidence headroom',round(estimate/1024/1024,2),'MiB.',flush=True)
