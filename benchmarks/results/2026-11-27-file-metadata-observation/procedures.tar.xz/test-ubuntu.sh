set -eu
source_root=/mnt/d/code/Lython
target_root="$HOME/lython-starmap-rows-8066Vm"
test -d "$target_root"
for file in benchmarks/Lokad.Lython.Benchmarks/Comparison/ComparisonFileHost.cs benchmarks/Lokad.Lython.Benchmarks/Comparison/LythonComparisonWorker.cs tests/Lokad.Lython.PublicApi.Tests/ComparisonFileWorkerTests.cs; do
    cp -- "$source_root/$file" "$target_root/$file"
    cmp -- "$source_root/$file" "$target_root/$file"
done
cd "$target_root"
filter='Category!=Stress&(FullyQualifiedName~ComparisonFileWorkerTests|FullyQualifiedName~PositionalZipTests|FullyQualifiedName~NumericReportTests)'
"$HOME/.dotnet/dotnet" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --no-restore --filter "$filter"
