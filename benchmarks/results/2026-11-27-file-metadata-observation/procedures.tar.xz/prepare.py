from hashlib import sha256
from pathlib import Path
import json, os, shutil, subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
run=lab/'local'
run.mkdir()
source=lab.with_name('short-command-boundary-20261127')/'local'
previous=lab.with_name('deferred-proof-layout-20261127')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p):return sha256(p.read_bytes()).hexdigest()
def write(path,data):path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
pin=read(source/'identity.json')
base=pin['imageFiles']['control']
assert len(base)==32 and {p.name:digest(p) for p in (source/'control').iterdir()}==base
worker='Lokad.Lython.Benchmarks.dll'
core='Lokad.Lython.dll'
build=repo/'benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0'/worker
assert build.is_file()
images={}
for role in ('reference','candidate'):
    target=run/role
    shutil.copytree(source/'control',target)
    if role=='candidate':shutil.copyfile(build,target/worker)
    images[role]={p.name:digest(p) for p in target.iterdir()}
assert [name for name in base if images['candidate'][name]!=base[name]]==[worker]
for name in ('representative.json','cpython-worker.py','run.sh'):
    shutil.copyfile(source/name,run/name)
assert digest(run/'representative.json')==pin['catalogs']['representative.json']
assert digest(run/'cpython-worker.py')==pin['pythonWorkers']['cpython-worker.py']
jobs=read(source/'jobs.json')
assert len(jobs)==3
write(run/'jobs.json', {'warm':[[job,'warm'] for job in jobs]})
for path,name in [('benchmarks/Lokad.Lython.Benchmarks/Comparison/ComparisonFileHost.cs','candidate.patch'),
                  ('tests/Lokad.Lython.PublicApi.Tests/ComparisonFileWorkerTests.cs','regression.patch')]:
    (run/name).write_bytes(subprocess.check_output(['git','diff','--binary','HEAD','--',path],cwd=repo))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
identity=dict(sourceRevision=head,coreSourceRevision=pin['sourceRevision'],sourcePatchSHA256=digest(run/'candidate.patch'),
              imageFiles=images,cpythonWorkerSHA256=digest(run/'cpython-worker.py'),
              coreSHA256={role+suffix:im[core] for role,im in images.items() for suffix in ('','-control')},
              catalogs={name:{'sha256':digest(run/name)} for name in ('representative.json','jobs.json')},
              purpose='Substitute one managed metadata observation per comparison host path component.')
write(run/'identity.json',identity)
collector=(previous/'local/collect.py').read_text(encoding='utf-8')
for before,after in (('len(jobs) == 5','len(jobs) == 3'),('lython-deferred-proof-fixture-','lython-file-metadata-fixture-')):
    assert collector.count(before)==1,before
    collector=collector.replace(before,after)
compile(collector,'collect.py','exec')
(run/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
summarizer=(previous/'summarize.py').read_text(encoding='utf-8')
for before,after in (("receipt['warmJobs'] == 5","receipt['warmJobs'] == 3"),
                     ("len(raw['jobs']) == 5","len(raw['jobs']) == 3"),('timedBatches=140','timedBatches=84')):
    assert summarizer.count(before)==1,before
    summarizer=summarizer.replace(before,after)
(lab/'summarize.py').write_text(summarizer,encoding='utf-8',newline='\n')
stage=(previous/'stage.sh').read_text(encoding='utf-8').replace('lython-deferred-proof-','lython-file-metadata-')
(lab/'stage.sh').write_text(stage,encoding='utf-8',newline='\n')
assert b'\r' not in (run/'run.sh').read_bytes() and b'\r' not in (lab/'stage.sh').read_bytes()
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role in images:
    report=run/f'{role}-verify.json'
    subprocess.run([dotnet,run/role/worker,'--compare','verify','--catalog',run/'representative.json','--dotnet',dotnet,
                    '--python','C:/Python313/python.exe','--python-worker',run/'cpython-worker.py','--out',report],
                   cwd=repo,env=env,check=True,timeout=65)
    facts=read(report)
    assert facts['state']=='Completed' and facts['caseCount']==3
    assert facts['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert facts['launched']['library']['sha256']==base[core]
