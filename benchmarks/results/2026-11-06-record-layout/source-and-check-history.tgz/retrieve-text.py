from pathlib import Path
root=Path(__file__).resolve().parent
source=(root.parent/'delivery-comparison-b352/retrieve.py').read_text()
source=source.replace('root=Path(__file__).parent',"root=Path(__file__).resolve().parent/'b362'")
source=source.replace('delivery-comparison-b352','record-layout-b362').replace('lython-b352-delivery-comparison','lython-b362-record-layout-text')
source=source.replace("['jobs']==15","['jobs']==2")
exec(compile(source,str(Path(__file__).resolve()),'exec'),{'__file__':str(Path(__file__).resolve()),'__name__':'__main__'})
