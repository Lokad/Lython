from pathlib import Path
import hashlib,json,subprocess,tarfile
home=Path(__file__).resolve().parent;old=home/'b360';root=home/'b361';root.mkdir()
prior='/home/lokad/lython-bench-checks/record-layout-b360-20261106';remote=prior.replace('b360','b361')
catalog=json.loads((home/'b359/representative.json').read_text());ids={c['id'] for c in catalog['cases']}
jobs=[('scripts.report-render.large','warm'),('scripts.report-render.large','compile-run'),('scripts.json-summary-helpers.large','warm'),('scripts.csv-summary-functions.large','warm'),('scripts.text-summary-helpers.large','warm')]
assert all(c in ids for c,l in jobs)
for n in ['collect.py','archive-owned.py','run.sh']:
 s=(old/n).read_text().replace(prior,remote)
 if n=='collect.py':s=s.replace('scripts.csv-summary-helpers.large','scripts.csv-summary-functions.large').replace('assert len(jobs)==5','assert len(jobs)==5 and all(case in cases for case,lane in jobs)')
 with (root/n).open('w',encoding='utf-8',newline='\n') as f:f.write(s)
contract=dict(original='B360 completes report warm/fresh and JSON warm, then rejects a nonexistent CSV case name. Preserve every original sample; collection lacks immediate final quiet/archive gate and remains diagnostic. No runtime failure or adverse-result filtering.',correction='Use the actual CSV/functions catalog case and validate all IDs before worker launch. Same source pair, images, controls, worker/protocol, normal GC/tiering, warmups/rounds. One bounded complete collection supplies final gates and missing controls.',ownerSeconds=210,stopSeconds=30,observeAfterSeconds=240)
(root/'setup-contract.json').write_text(json.dumps(contract,indent=2)+'\n')
with tarfile.open(root/'payload.tgz','w:gz') as a:
 for n in ['collect.py','archive-owned.py','run.sh','setup-contract.json']:a.add(root/n,arcname=n)
data=(root/'payload.tgz').read_bytes()
script=r'''from pathlib import Path
import fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('REMOTE');old=Path('PRIOR')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (old/'exit-code.txt').read_text().strip()=='1' and not root.exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 r=json.loads((old/'confirmation/confirmation.json').read_text());assert not r['complete'] and len(r['jobs'])==3 and all(j['workersJoinedAndFixturesRemoved'] for j in r['jobs'])
 (old/'terminal-journal.txt').write_text(subprocess.check_output(['journalctl','--unit=lython-b360-record-layout-20261106','--no-pager'],text=True))
 with tarfile.open(old/'failed-observations.tgz','w:gz') as a:
  for n in ['confirmation','identity.json','terminal-journal.txt','exit-code.txt','started.utc','stopped.utc','collect.py','setup-contract.json','run.sh','verified-startup-identities.json']:a.add((old/n).resolve(),arcname=n)
 payload=sys.stdin.buffer.read(PAYLOADBYTES+1);assert len(payload)==PAYLOADBYTES and hashlib.sha256(payload).hexdigest()=='PAYLOADHASH'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:root.mkdir();a.extractall(root,filter='data')
 for n in ['identity.json','representative.json','pre-measurement-plan.md','source.patch','contract.md','cpython-worker.py','reference','candidate']:(root/n).symlink_to(old/n,target_is_directory=(old/n).is_dir())
 i=json.loads((root/'identity.json').read_text());cases={c['id'] for c in json.loads((root/'representative.json').read_text())['cases']}
 expected=['scripts.report-render.large','scripts.json-summary-helpers.large','scripts.csv-summary-functions.large','scripts.text-summary-helpers.large'];assert all(c in cases for c in expected)
 verified=json.loads((old/'verified-startup-identities.json').read_text())
 for role in ['candidate','reference']:
  core=next(v for v in verified[role]['libraries'] if Path(v['path']).name=='Lokad.Lython.dll')
  assert core['sha256'].lower()==i['coreSHA256'][role]
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][role]
 assert shutil.disk_usage(base).free>6*1024*1024
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,allCatalogJobsValidated=True,failedArchiveSHA256=hashlib.sha256((old/'failed-observations.tgz').read_bytes()).hexdigest())),flush=True)
'''.replace('REMOTE',remote).replace('PRIOR',prior).replace('PAYLOADBYTES',str(len(data))).replace('PAYLOADHASH',hashlib.sha256(data).hexdigest())
(root/'prepare.py').write_text(script)
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15']
scp=['C:/Windows/System32/OpenSSH/scp.exe',*ssh[1:]]
r=subprocess.run([*scp,str(root/'prepare.py'),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/b361-prepare.py'],capture_output=True);assert r.returncode==0,r.stderr
r=subprocess.run([*ssh,'lokad@20.166.121.73','python3 /home/lokad/lython-bench-checks/b361-prepare.py'],input=data,capture_output=True)
(root/'prepare.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,(r.stdout+r.stderr).decode()
print((r.stdout+r.stderr).decode(),flush=True)
for b in ['b359','b360']:
 p=home/b/'failed-observations.tgz'
 r=subprocess.run([*scp,'lokad@20.166.121.73:'+remote.replace('b361',b)+'/failed-observations.tgz',str(p)],capture_output=True);assert r.returncode==0,r.stderr
 with tarfile.open(p) as a:assert a.getmember('terminal-journal.txt').isfile()
r=subprocess.run([*ssh,'lokad@20.166.121.73','sudo -n systemd-run --unit=lython-b361-record-layout-20261106 --property=User=lokad --property=WorkingDirectory='+remote+' --property=RuntimeMaxSec=210 --property=TimeoutStopSec=30 --property=KillMode=control-group /bin/sh '+remote+'/run.sh'],capture_output=True)
(root/'launch.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,(r.stdout+r.stderr).decode()
print((r.stdout+r.stderr).decode(),flush=True)
