from pathlib import Path
import hashlib,json,subprocess,tarfile
home=Path(__file__).resolve().parent;old=home/'b361';root=home/'b362';root.mkdir()
prior='/home/lokad/lython-bench-checks/record-layout-b361-20261106';remote=prior.replace('b361','b362')
receipt=json.loads((old/'archive-receipt.json').read_text());assert receipt['complete'] and hashlib.sha256((old/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for n in ['collect.py','archive-owned.py','run.sh']:
 s=(old/n).read_text().replace(prior,remote)
 if n=='collect.py':
  a=s.index('jobs=[');b=s.index('\nenv =',a)
  s=s[:a]+"jobs=[('scripts.text-summary-helpers.large','warm')]*2\nassert len(jobs)==2 and all(case in cases for case,lane in jobs)\n"+s[b:]
  s=s.replace('< 175','< 70').replace('if job_index >= 2: labels.reverse()','if job_index % 2: labels.reverse()')
  a=s.index("purpose='")+len("purpose='");b=s.index("',",a);s=s[:a]+'Bounded unchanged-source text confirmation; B361 identical-current-role spread5.28percent exceeds source difference, retain original adverse observations'+s[b:]
 if n=='archive-owned.py':s=s.replace("len(r['jobs'])==5","len(r['jobs'])==2").replace('jobs=5','jobs=2')
 with (root/n).open('w',encoding='utf-8',newline='\n') as f:f.write(s)
(root/'setup-contract.json').write_text(json.dumps(dict(reason='B361 candidate text+5.01%, identical current control-0.53%,5.28%role spread. This is unresolved, not proof of a source regression. Keep all B360/B361 clocks including coarse adverse CSV CPU. Confirm text only in two independent blocks with reversed role creation; no source/binary/runtime/fixture/warmup/tiering changes.',stop='Two blocks then decide/record remaining debt; no report/JSON retiming.100sowner+30sstop; noSSH during capture.'),indent=2)+'\n')
with tarfile.open(root/'payload.tgz','w:gz') as a:
 for n in ['collect.py','archive-owned.py','run.sh','setup-contract.json']:a.add(root/n,arcname=n)
data=(root/'payload.tgz').read_bytes()
script=r'''from pathlib import Path
import fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('REMOTE');old=Path('PRIOR')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (old/'exit-code.txt').read_text().strip()=='0' and not root.exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert hashlib.sha256((old/'observations.tgz').read_bytes()).hexdigest()=='PRIORHASH'
 payload=sys.stdin.buffer.read(PAYLOADBYTES+1);assert len(payload)==PAYLOADBYTES and hashlib.sha256(payload).hexdigest()=='PAYLOADHASH'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:root.mkdir();a.extractall(root,filter='data')
 for n in ['identity.json','representative.json','pre-measurement-plan.md','source.patch','contract.md','cpython-worker.py','reference','candidate']:(root/n).symlink_to(old/n,target_is_directory=(old/n).is_dir())
 assert 'scripts.text-summary-helpers.large' in {c['id'] for c in json.loads((root/'representative.json').read_text())['cases']}
 assert shutil.disk_usage(base).free>6*1024*1024
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,priorArchiveVerified=True)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b362-record-layout-text-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=100','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''.replace('REMOTE',remote).replace('PRIORHASH',receipt['archiveSHA256']).replace('PRIOR',prior).replace('PAYLOADBYTES',str(len(data))).replace('PAYLOADHASH',hashlib.sha256(data).hexdigest())
(root/'launch.py').write_text(script)
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15']
r=subprocess.run(['C:/Windows/System32/OpenSSH/scp.exe',*ssh[1:],str(root/'launch.py'),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/b362-launch.py'],capture_output=True);assert r.returncode==0,r.stderr
r=subprocess.run([*ssh,'lokad@20.166.121.73','python3 /home/lokad/lython-bench-checks/b362-launch.py'],input=data,capture_output=True)
(root/'launch.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,(r.stdout+r.stderr).decode()
print((r.stdout+r.stderr).decode(),flush=True)
