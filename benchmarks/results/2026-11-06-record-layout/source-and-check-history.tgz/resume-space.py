from pathlib import Path
import hashlib,subprocess
root=Path(__file__).resolve().parent/'b359'
sha=hashlib.sha256((root.parent.parent/'invocation-metadata-b148/payload.tgz').read_bytes()).hexdigest()
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');p=base/'invocation-metadata-b148-20261103/payload.tgz'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert p.resolve()==p and p.parent.parent==base and not p.is_symlink() and p.stat().st_nlink==1
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert subprocess.run(['fuser',str(p)],capture_output=True).returncode==1
 assert not [q for q in base.rglob('*') if q.is_symlink() and q.resolve()==p]
 assert hashlib.sha256(p.read_bytes()).hexdigest()=='HASH'
 size=p.stat().st_size;p.unlink()
 print(json.dumps(dict(retiredRedundantUpload=str(p),bytes=size,independentLocalCopySHA256='HASH',rawObservationsAndExpandedImagesPreserved=True,freeBytes=shutil.disk_usage(base).free)))
'''.replace('HASH',sha)
r=subprocess.run([*ssh,'python3 -'],input=script,text=True,capture_output=True)
(root/'space-correction.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
print(r.stdout,flush=True)
r=subprocess.run([*ssh,'python3 /home/lokad/lython-bench-checks/b359-launch-corrected.py'],input=(root/'payload.tgz').read_bytes(),capture_output=True)
(root/'launch-final.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,(r.stdout+r.stderr).decode()
print((r.stdout+r.stderr).decode(),flush=True)
