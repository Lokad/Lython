from pathlib import Path
import fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('/home/lokad/lython-bench-checks/record-layout-b362-20261106');old=Path('/home/lokad/lython-bench-checks/record-layout-b361-20261106')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (old/'exit-code.txt').read_text().strip()=='0' and not root.exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert hashlib.sha256((old/'observations.tgz').read_bytes()).hexdigest()=='3feb1f17bc18e3b2b699814866ade153e25b9dc93ec3dfa312671521c5dcc0a7'
 payload=sys.stdin.buffer.read(4367+1);assert len(payload)==4367 and hashlib.sha256(payload).hexdigest()=='ec00ede4d4e356f03e34ef706bff472339e6691b6e5d81c130c61332dab681cb'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:root.mkdir();a.extractall(root,filter='data')
 for n in ['identity.json','representative.json','pre-measurement-plan.md','source.patch','contract.md','cpython-worker.py','reference','candidate']:(root/n).symlink_to(old/n,target_is_directory=(old/n).is_dir())
 assert 'scripts.text-summary-helpers.large' in {c['id'] for c in json.loads((root/'representative.json').read_text())['cases']}
 assert shutil.disk_usage(base).free>6*1024*1024
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,priorArchiveVerified=True)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b362-record-layout-text-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=100','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
