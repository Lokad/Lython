from pathlib import Path
root=Path(__file__).resolve().parent
source=(root.parent/'delivery-comparison-b352/retrieve.py').read_text()
source=source.replace('root=Path(__file__).parent',"root=Path(__file__).resolve().parent/'b361'")
source=source.replace('delivery-comparison-b352','record-layout-b361').replace('lython-b352-delivery-comparison','lython-b361-record-layout')
source=source.replace("['jobs']==15","['jobs']==5")
exec(compile(source,str(Path(__file__).resolve()),'exec'),{'__file__':str(Path(__file__).resolve()),'__name__':'__main__'})
