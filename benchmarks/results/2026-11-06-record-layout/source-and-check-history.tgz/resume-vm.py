from pathlib import Path
import json,subprocess
root=Path(__file__).resolve().parent/'b359'
(root/'initial-preflight.log').write_bytes((root/'launch.log').read_bytes())
script=(root/'launch.py').read_text().replace('import fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile','import fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile')
script=script.replace("  assert set(perf.rglob('*'))==set(removed)|{p for p in perf.rglob('*') if p.is_dir()}","""  pipes=set(perf.rglob('*'))-set(removed)-{p for p in perf.rglob('*') if p.is_dir()}
  assert pipes=={perf/d/n for d in ['report-warm','text-warm'] for n in ['ack','control']}
  assert all(stat.S_ISFIFO(p.lstat().st_mode) and not p.is_symlink() for p in pipes)
  for p in pipes:p.unlink()""")
(root/'launch-corrected.py').write_text(script)
(root/'preflight-correction.json').write_text(json.dumps(dict(original='Initial exact-copy inventory gate excluded four ended perf-control FIFOs; no data deleted, no owner launched, no measurements ran.',correction='Validate exactly ack/control FIFOs for the two ended users, unlink only those non-storage endpoints and verified redundant exact perf files. Preserve independent local and remote raw archives. No source/test/timing change.'),indent=2)+'\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15']
r=subprocess.run(['C:/Windows/System32/OpenSSH/scp.exe',*ssh[1:],str(root/'launch-corrected.py'),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/b359-launch-corrected.py'],capture_output=True);assert r.returncode==0,r.stderr
r=subprocess.run([*ssh,'lokad@20.166.121.73','python3 /home/lokad/lython-bench-checks/b359-launch-corrected.py'],input=(root/'payload.tgz').read_bytes(),capture_output=True)
(root/'launch-corrected.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,(r.stdout+r.stderr).decode()
print((r.stdout+r.stderr).decode(),flush=True)
