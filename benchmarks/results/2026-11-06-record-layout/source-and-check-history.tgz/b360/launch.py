from pathlib import Path
import contextlib,fcntl,hashlib,importlib.util,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('/home/lokad/lython-bench-checks/record-layout-b360-20261106');old=Path('/home/lokad/lython-bench-checks/record-layout-b359-20261106');source=base/'regex-capture-b355-20261106/candidate'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (old/'exit-code.txt').read_text().strip()=='1' and not root.exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 journal=subprocess.check_output(['journalctl','--unit=lython-b359-record-layout-20261106','--no-pager'],text=True)
 (old/'terminal-journal.txt').write_text(journal)
 with tarfile.open(old/'failed-observations.tgz','w:gz') as a:
  for n in ['confirmation','identity.json','terminal-journal.txt','exit-code.txt','started.utc','stopped.utc','collect.py','setup-contract.json','run.sh']:a.add(old/n,arcname=n)
 payload=sys.stdin.buffer.read(4411+1);assert len(payload)==4411 and hashlib.sha256(payload).hexdigest()=='a3aac88e7b75d8181876a2502f0fd603525e471800b90fdcca26c29d977c35b6'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:root.mkdir();a.extractall(root,filter='data')
 for n in ['identity.json','representative.json','pre-measurement-plan.md','source.patch','contract.md','cpython-worker.py']:(root/n).symlink_to(old/n)
 (root/'reference').symlink_to(source,target_is_directory=True)
 folder=root/'candidate';folder.mkdir()
 for f in source.iterdir():
  if f.suffix=='.pdb':continue
  if f.name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json']:os.link(f,folder/f.name)
  else:(folder/f.name).symlink_to(old/'Lokad.Lython.dll' if f.name=='Lokad.Lython.dll' else f.resolve(),target_is_directory=f.is_dir())
 i=json.loads((root/'identity.json').read_text())
 spec=importlib.util.spec_from_file_location('protocol',root/'cpython-worker.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
 dotnet=Path('/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet');env=os.environ.copy();env['DOTNET_ROOT']=str(dotnet.parent)
 actual={}
 for role in ['reference','candidate']:
  process=subprocess.Popen([str(dotnet),str(root/role/'Lokad.Lython.Benchmarks.dll'),'--compare','worker','--catalog',str(root/'representative.json')],env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  try:
   ready=protocol.read_frame(process.stdout)
   actual[role]=ready;assert ready['status']=='Ready'
   core=next(v for v in ready['libraries'] if Path(v['path']).name=='Lokad.Lython.dll')
   assert core['sha256'].lower()==i['coreSHA256'][role]
   protocol.write_frame(process.stdin,dict(protocolVersion=2,requestId=1,operation='quit'))
   assert protocol.read_frame(process.stdout)['status']=='Closed'
   assert process.wait(timeout=5)==0 and not process.stderr.read()
  finally:
   if process.poll() is None:process.kill();process.wait()
   process.stdin.close();process.stdout.close();process.stderr.close()
 (root/'verified-startup-identities.json').write_text(json.dumps(actual,indent=2)+'\n')
 free=shutil.disk_usage(base).free;assert free>6*1024*1024
 print(json.dumps(dict(freeBytes=free,actualWorkerIdentitiesVerified=True,failedArchiveSHA256=hashlib.sha256((old/'failed-observations.tgz').read_bytes()).hexdigest())),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b360-record-layout-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=210','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
