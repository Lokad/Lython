from pathlib import Path
import hashlib,json,os,shutil,subprocess
repo=Path('D:/code/Lython');root=Path(__file__).parent;out=root/'allocation';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=root/'baseline/net11.0/Lokad.Lython.dll'
candidate=repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
checks=json.loads((root/'focused-results.json').read_text(encoding='utf-8'))
assert sha(base)==json.loads((root/'baseline.json').read_text())['coreSHA256']['net11.0']
assert sha(candidate)==checks['checks']['net11.0']['coreSHA256']
aux=repo/'benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0'
for role,core in [('baseline',base),('candidate',candidate)]:
 folder=out/role;folder.mkdir()
 for p in aux.iterdir():
  if p.is_dir():shutil.copytree(p,folder/p.name)
  elif p.suffix=='.pdb':continue
  else:shutil.copyfile(core if p.name=='Lokad.Lython.dll' else p,folder/p.name)
 assert sha(folder/'Lokad.Lython.dll')==sha(core)
tools=[p for p in (root.parent/'fixed-text-construction-b194/tool').rglob('complete-jobs.dll') if 'obj' not in p.parts]
assert len(tools)==1
tool=tools[0];catalog=root.parent/'compact-fragments-b205/catalog.json'
assert len(json.loads(catalog.read_text())['cases'])==8
shutil.copyfile(catalog,out/'catalog.json')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
identity=dict(coreSHA256=dict(baseline=sha(base),candidate=sha(candidate)),toolSHA256=sha(tool),catalogSHA256=sha(catalog),boundary='Existing complete-job diagnostic includes fixture reset, mediated I/O, validation and prior-result cleanup. Precise process allocation with isolated images sharing CoreLib; busy Windows elapsed/CPU diagnostic only. Normal GC/tiering; no forced GC.',roles='Baseline/candidate/identical baseline control',normalPin='0.4.0')
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
for api in ['sync','async']:
 folder=out/api;folder.mkdir()
 witness=folder/'hash-witness.json';witness.write_text(json.dumps(dict(source="return [hash('Lython-é😀'), hash((1, 2.0, True))]\n"),ensure_ascii=False)+'\n',encoding='utf-8')
 with (folder/'measurements.json').open('w',encoding='utf-8') as output,(folder/'stderr.txt').open('w',encoding='utf-8') as errors:
  r=subprocess.run([env['DOTNET_HOST_PATH'],str(tool),str(out/'baseline/Lokad.Lython.Benchmarks.dll'),str(out/'candidate/Lokad.Lython.Benchmarks.dll'),str(out/'catalog.json'),str(witness),'reverse','warm',api],cwd=repo,env=env,stdout=output,stderr=errors)
 print(api,r.returncode,flush=True)
 if r.returncode:print((folder/'stderr.txt').read_text(encoding='utf-8'));raise SystemExit(r.returncode)
 result=json.loads((folder/'measurements.json').read_text(encoding='utf-8'))
 assert all(result[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
 print(api,'all complete-job allocation/semantic/ownership gates passed',flush=True)
