from pathlib import Path
import hashlib,json,os,re,subprocess,sys
root=Path(__file__).resolve().parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
selection='Category!=Stress&(FullyQualifiedName~Dict|FullyQualifiedName~Hash|FullyQualifiedName~Set|FullyQualifiedName~Json|FullyQualifiedName~Csv|FullyQualifiedName~RecordKey)'
checks={}
for framework in ['net11.0','net10.0']:
    for project in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
        log=root/f'focused-{project}-{framework}.log';assert not log.exists()
        with log.open('w',encoding='utf-8') as output:
            r=subprocess.run([env['DOTNET_HOST_PATH'],'test','tests/'+project,'-c','Release','-f',framework,'--no-build','--no-restore','--filter',selection,'--nologo','--tl:off'],env=env,stdout=output,stderr=subprocess.STDOUT)
        text=log.read_text(encoding='utf-8');print(project,framework,r.returncode,text[-1700:],flush=True)
        if r.returncode:sys.exit(r.returncode)
        m=re.search(r'Passed:\s+(\d+)',text);assert m,text[-300:]
        checks[project+'-'+framework]={'passed':int(m[1])}
    core=Path('src/Lokad.Lython/bin/Release')/framework/'Lokad.Lython.dll'
    checks[framework]={'coreSHA256':hashlib.sha256(core.read_bytes()).hexdigest()}
(root/'focused-results.json').write_text(json.dumps(dict(checks=checks,selection=selection,sourceBase='b542b601 runtime; db55033e HEAD plus R20 prototype'),indent=2)+'\n',encoding='utf-8')
