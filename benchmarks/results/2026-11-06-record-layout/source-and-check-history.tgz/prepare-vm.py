from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
home=Path(__file__).resolve().parent;root=home/'b359';root.mkdir()
old=home.parent/'regex-capture-u04/b357';oldpath='/home/lokad/lython-bench-checks/regex-capture-b357-20261106'
remote='/home/lokad/lython-bench-checks/record-layout-b359-20261106'
base='/home/lokad/lython-bench-checks/regex-capture-b355-20261106/candidate'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,s):
 with (root/n).open('w',encoding='utf-8',newline='\n') as f:f.write(s)
core=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll')
assert sha(core)==json.loads((home/'focused-results.json').read_text())['checks']['net11.0']['coreSHA256']
identity=json.loads((home.parent/'regex-capture-u04/b355/identity.json').read_text())
identity.update(sourceRevision='db55033e plus coherent R20 record storage prototype',referenceSourceRevision='b542b601 runtime; frozen U04 B355 image',purpose='Canonical record-key storage source pair; report warm/fresh and JSON/CSV/text warm, normal GC/tiering, identical candidate control')
identity['coreSHA256']=dict(candidate=sha(core),control=sha(core),reference='edf02bae4f70070011d3992cc9445506bcce54f44cf280a828deb44f14850126')
identity['auxiliaryFiles']['Lokad.Lython.Utf8Regex.dll']=identity['candidateAdapterSHA256']
identity.pop('deletedSourceFiles',None)
identity['qualification']=json.loads((home/'focused-results.json').read_text())
identity['sourceSHA256']={str(p).replace('\\','/'):sha(p) for p in Path('src/Lokad.Lython').rglob('*.cs') if not {'bin','obj'}.intersection(p.parts)}
write('identity.json',json.dumps(identity,indent=2)+'\n')
shutil.copyfile(core,root/core.name)
shutil.copyfile(home.parent/'delivery-comparison-b352/representative.json',root/'representative.json')
shutil.copyfile('PLAN.md',root/'pre-measurement-plan.md')
patch=subprocess.check_output(['git','-c','core.safecrlf=false','diff','--','src'])
for p in subprocess.check_output(['git','ls-files','--others','--exclude-standard','src'],text=True).splitlines():
 r=subprocess.run(['git','diff','--no-index','--','NUL',p],capture_output=True);assert r.returncode in [0,1];patch+=r.stdout
(root/'source.patch').write_bytes(patch)
write('setup-contract.json',json.dumps(dict(reference=base,boundary='Unchanged b94 worker/protocol, CPython3.13.16 and source pair, five5-second warmups/7rotated150ms batches; warm excludes compile, fresh includes compile/disposal. Complete mediated RAM I/O, validation and prior-result cleanup included; staging/startup/final fixture deletion excluded.',ownerSeconds=210,stopSeconds=30,jobStartLimitSeconds=175,observation='No SSH/status/profiling until240s after start; retain all failures/adverse data.'),indent=2)+'\n')
write('contract.md',(home.parent/'current-cpu-r19/selected-record-layout.md').read_text() if (home.parent/'current-cpu-r19/selected-record-layout.md').exists() else Path('benchmarks/results/2026-11-06-current-cpu-records/selected-record-layout.md').read_text())
for name in ['collect.py','run.sh','archive-owned.py']:
 s=(old/name).read_text().replace(oldpath,remote)
 if name=='collect.py':
  a=s.index('jobs=[');b=s.index('\nenv =',a)
  s=s[:a]+"jobs=[('scripts.report-render.large','warm'),('scripts.report-render.large','compile-run'),('scripts.json-summary-helpers.large','warm'),('scripts.csv-summary-helpers.large','warm'),('scripts.text-summary-helpers.large','warm')]\nassert len(jobs)==5\n"+s[b:]
  s=s.replace('< 110','< 175')
  a=s.index("purpose='")+len("purpose='");b=s.index("',",a);s=s[:a]+identity['purpose']+s[b:]
 if name=='archive-owned.py':s=s.replace("len(r['jobs'])==3","len(r['jobs'])==5").replace('jobs=3','jobs=5')
 write(name,s)
names=['Lokad.Lython.dll','identity.json','source.patch','representative.json','pre-measurement-plan.md','contract.md','setup-contract.json','collect.py','run.sh','archive-owned.py']
with tarfile.open(root/'payload.tgz','w:gz') as a:
 for name in names:a.add(root/name,arcname=name)
data=(root/'payload.tgz').read_bytes()
receipt=json.loads((home.parent/'current-cpu-r19/archive-receipt.json').read_text())
assert receipt['complete'] and receipt['allWorkersJoined'] and sha(home.parent/'current-cpu-r19/observations.tgz')==receipt['archiveSHA256']
script=r'''from pathlib import Path
import fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('REMOTE');source=Path('SOURCE');retired=base/'current-cpu-b358-20261106';perf=retired/'perf'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert hashlib.sha256((retired/'observations.tgz').read_bytes()).hexdigest()=='RAWARCHIVE'
 removed=[]
 if perf.exists():
  assert perf.resolve().is_relative_to(base) and not perf.is_symlink()
  assert not [p for p in base.rglob('*') if p.is_symlink() and p.resolve().is_relative_to(perf)]
  with tarfile.open(retired/'observations.tgz') as a:
   for m in a.getmembers():
    if m.isfile() and m.name.startswith('perf/'):
     p=retired/m.name;assert p.resolve().is_relative_to(perf) and not p.is_symlink() and p.stat().st_nlink==1
     assert p.read_bytes()==a.extractfile(m).read();removed.append(p)
  assert set(perf.rglob('*'))==set(removed)|{p for p in perf.rglob('*') if p.is_dir()}
  for p in removed:p.unlink()
  for p in sorted(perf.rglob('*'),key=lambda p:len(p.parts),reverse=True):p.rmdir()
  perf.rmdir()
 payload=sys.stdin.buffer.read(PAYLOADBYTES+1);assert len(payload)==PAYLOADBYTES and hashlib.sha256(payload).hexdigest()=='PAYLOADHASH'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  needed=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+128*1024
  assert shutil.disk_usage(base).free>needed+6*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 (root/'reference').symlink_to(source,target_is_directory=True)
 (root/'cpython-worker.py').symlink_to(base/'regex-capture-b357-20261106/cpython-worker.py')
 folder=root/'candidate';folder.mkdir()
 for f in source.iterdir():
  if f.suffix=='.pdb':continue
  (folder/f.name).symlink_to(root/f.name if f.name=='Lokad.Lython.dll' else f.resolve(),target_is_directory=f.is_dir())
 i=json.loads((root/'identity.json').read_text())
 for role in ['reference','candidate']:
  folder=root/role;assert hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][role]
  for name,digest in i['auxiliaryFiles'].items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest
 assert shutil.disk_usage(base).free>6*1024*1024
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,retiredExactExpandedPerfFiles=len(removed),independentLocalAndRemoteArchivePreserved=True)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b359-record-layout-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=210','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''.replace('REMOTE',remote).replace('SOURCE',base).replace('RAWARCHIVE',receipt['archiveSHA256']).replace('PAYLOADBYTES',str(len(data))).replace('PAYLOADHASH',hashlib.sha256(data).hexdigest())
write('launch.py',script)
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15']
r=subprocess.run(['C:/Windows/System32/OpenSSH/scp.exe',*ssh[1:],str(root/'launch.py'),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/b359-launch.py'],capture_output=True);assert r.returncode==0,r.stderr
r=subprocess.run([*ssh,'lokad@20.166.121.73','python3 /home/lokad/lython-bench-checks/b359-launch.py'],input=data,capture_output=True)
(root/'launch.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,(r.stdout+r.stderr).decode()
print((r.stdout+r.stderr).decode(),flush=True)
