import subprocess
script='''from pathlib import Path
import tarfile
p=Path('/home/lokad/lython-bench-checks/current-cpu-b358-20261106')
with tarfile.open(p/'observations.tgz') as a:
 have=set((p/'perf').rglob('*'))
 want={p/m.name for m in a.getmembers() if m.isfile() and m.name.startswith('perf/')}|{q for q in have if q.is_dir()}
 print('extra',have-want,'missing',want-have)
'''
r=subprocess.run(['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -'],input=script,text=True,capture_output=True)
print(r.returncode,r.stdout,r.stderr)
