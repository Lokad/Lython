from pathlib import Path
import json,statistics,sys
root=Path(__file__).resolve().parent
median=statistics.median
allocation={}
for api in ['sync','async']:
 r=json.loads((root/f'allocation/{api}/measurements.json').read_text())
 rows=[]
 for c in r['observations']:
  medians={role:median(s['allocatedBytes']/s['jobs'] for s in c['samples'] if s['image']==role) for role in ['before','candidate','before-control']}
  rows.append(dict(case=c['caseId'],allocatedBytesPerJob=medians,candidateChangePercent=100*(medians['candidate']/medians['before']-1),admittedPeaks=c['admittedPeaks']))
 allocation[api]=dict(rows=rows,allGoldensPassed=r['allGoldensPassed'],allBalancesZero=r['allBalancesZero'],ownedFixturesRemoved=r['ownedFixturesRemoved'],imageIsolationVerified=r['imageIsolationVerified'])
(root/'allocation-summary.json').write_text(json.dumps(allocation,indent=2)+'\n')
block=sys.argv[1] if len(sys.argv)>1 else 'b361'
f=root/block/'retrieved/confirmation/confirmation.json'
if f.exists():
 r=json.loads(f.read_text());rows=[]
 for j in r['jobs']:
  elapsed={};cpu={};iqr={}
  for role in ['candidate','control','reference','CPython']:
   samples=[s for s in j['samples'] if s['engine']==role]
   times=[s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations'] for s in samples]
   elapsed[role]=median(times)
   cpu[role]=median(s['externalProcessCpuTicks']/s['externalCpuFrequency']/s['response']['completedInvocations'] for s in samples)
   q=statistics.quantiles(times,n=4,method='inclusive');iqr[role]=100*(q[2]-q[0])/median(times)
  row=dict(case=j['case'],lane=j['lane'],elapsedMilliseconds={k:v*1000 for k,v in elapsed.items()},processCpuMilliseconds={k:v*1000 for k,v in cpu.items()},iqrPercent=iqr,
   candidateChangePercent={k:100*(elapsed[k]/elapsed['reference']-1) for k in ['candidate','control']},currentRoleDifferencePercent=100*abs(elapsed['control']-elapsed['candidate'])/elapsed['candidate'],CPythonRatio={k:elapsed[k]/elapsed['CPython'] for k in ['candidate','control']})
  rows.append(row);print(json.dumps(row),flush=True)
 (root/('text-summary.json' if block=='b362' else 'comparison-summary.json')).write_text(json.dumps(dict(rows=rows,complete=r['complete'],elapsedSeconds=r['elapsedSeconds']),indent=2)+'\n')
