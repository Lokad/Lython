from pathlib import Path
import fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('/home/lokad/lython-bench-checks/record-layout-b361-20261106');old=Path('/home/lokad/lython-bench-checks/record-layout-b360-20261106')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (old/'exit-code.txt').read_text().strip()=='1' and not root.exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 r=json.loads((old/'confirmation/confirmation.json').read_text());assert not r['complete'] and len(r['jobs'])==3 and all(j['workersJoinedAndFixturesRemoved'] for j in r['jobs'])
 (old/'terminal-journal.txt').write_text(subprocess.check_output(['journalctl','--unit=lython-b360-record-layout-20261106','--no-pager'],text=True))
 with tarfile.open(old/'failed-observations.tgz','w:gz') as a:
  for n in ['confirmation','identity.json','terminal-journal.txt','exit-code.txt','started.utc','stopped.utc','collect.py','setup-contract.json','run.sh','verified-startup-identities.json']:a.add((old/n).resolve(),arcname=n)
 payload=sys.stdin.buffer.read(4437+1);assert len(payload)==4437 and hashlib.sha256(payload).hexdigest()=='ed1355dbe33ff949231d1c7a03e41984b5a53179aa165fec6bbb95211615acd9'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:root.mkdir();a.extractall(root,filter='data')
 for n in ['identity.json','representative.json','pre-measurement-plan.md','source.patch','contract.md','cpython-worker.py','reference','candidate']:(root/n).symlink_to(old/n,target_is_directory=(old/n).is_dir())
 i=json.loads((root/'identity.json').read_text());cases={c['id'] for c in json.loads((root/'representative.json').read_text())['cases']}
 expected=['scripts.report-render.large','scripts.json-summary-helpers.large','scripts.csv-summary-functions.large','scripts.text-summary-helpers.large'];assert all(c in cases for c in expected)
 verified=json.loads((old/'verified-startup-identities.json').read_text())
 for role in ['candidate','reference']:
  core=next(v for v in verified[role]['libraries'] if Path(v['path']).name=='Lokad.Lython.dll')
  assert core['sha256'].lower()==i['coreSHA256'][role]
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][role]
 assert shutil.disk_usage(base).free>6*1024*1024
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,allCatalogJobsValidated=True,failedArchiveSHA256=hashlib.sha256((old/'failed-observations.tgz').read_bytes()).hexdigest())),flush=True)
