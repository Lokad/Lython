# Lokad.Lython 0.11.0

Updated 2026-11-06. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
An isolated experiment, allocation reduction or source gate does not complete it.

## Actual delivery status

- Earlier qualified runtime **b6650f09**: shared compiler facts, direct UTF8 storage/
  formatting, native returns, R13C/R14 context/dictionary provenance, R17 text
  provenance and P01 Excel number formats. CI42258608463 GREEN: Windows/Ubuntu,
  actual11/10, original Stress and installed consumers. Cached delivery-ci.json
  under benchmarks/results/2026-11-06-delivery-cpython/; never query it again.
- **Current fully qualified runtime b542b601**: caller-owned regex captures and lazy
  retained groups. Normal focused checks pass; full ordinary Release passes
  4,262 internal/16,195 public per actual11/10. Private immutabledev44 bridge passes
  84 internal/482 public per runtime. Pushed to origin; CI42279409059 GREEN:
  Windows/Ubuntu, actual11/10, original Stress and installed consumers. Local
  explicit Release installed consumers also pass both. Cached delivery-ci.json
  in U04 evidence; never query the terminal run again. No repeat qualification.
  e81aaa88 adds R19 evidence/design only; runtime source remains b542b601.
- B355–B357 are terminal; no live VM work. B355 fixture rejection and B356 original
  archive-only failure/observer interference remain. B357 undisturbed confirmation
  completes87.09s, exit0, goldens/quiet/funding/cleanup/archive gates pass. Never
  query these terminal services again. Explicit Release pack/installed checks now
  target b542b601; core dependencies empty, adapter nonpackable. No publication.

Historical plans/snapshots/raw handoffs: .git/agent-notes/review-20261031/.
Immutable evidence: benchmarks/results/; index benchmarks/EXPERIMENTS.md.
docs/ describes the current implementation only, without transient receipts.

## U04 delivered — preserve its simplification

Removed: public LythonRegexMatch/old Match/Next signatures, per-success adapter
carrier/capture arrays, per-match core delegates, eager ReCapture records and
whole/group payload preparation. TryMatch/TryNext fill caller-owned spans; one
admitted scratch buffer belongs to the prepared operation. Shared error mapping
preserves first refusal/current cancellation. No new memory layer, pool or backend.

Retained matches own immutable byte/scalar ranges over the original funded subject.
Partial strings are admitted on group access, full-subject groups alias the input,
and expansion reads ranges. Added regs; it was previously unsupported. Group-copy
failure moves to actual access, remains terminal through catch/finally-return;
copies are not cached. Preserve aliases, lookbehind/windows, unmatched/empty groups,
lastindex/lastgroup, callback suspension, effective flags, cache and awaited cleanup.
Provider implementations intentionally break for0.11; no compatibility stubs.

Independent CPython golden and competing shared-budget/reuse controls pass both
APIs. Real in-flight backend interruption remains covered. Same-producer direct
cursor allocation32,088→25,560B/64matches (−20.34%), including caller buffer and
admission. This excludes retained guest matches; local elapsed−3.87% diagnostic.
B357 complete extraction: warm−3.62–5.17%, fresh−4.58–6.40%, unchanged text control
−2.13% to+0.10%; current-role variation limits precision. No CPU/RSS/embedding-tail
claim. Optional0.4 regex remains about7x CPython. Evidence:
benchmarks/results/2026-11-06-regex-capture-ownership/.

Acceptance closed: explicit Release installed consumers and combined Windows/
Ubuntu/actual11/10/original Stress checkpoint pass. No old carrier/API consumers
or compatibility stubs remain. Publication deferred; keep independent work moving.

## Priority 1 — implement the non-regex record-storage redesign

B352 is the current general external baseline (b6650f09), compilation/warm/fresh
separate. Fresh CPython ratios: CSV1.31x, text1.75–1.83x, JSON1.12x, report1.44–1.46x,
config1.21–1.22x. Warm text1.80–1.82x remains the main gap. Actual mediated RAM I/O,
full result checks and prior-result cleanup are included; startup/staging/final
teardown excluded. No subtracting independent medians or inferring today's HEAD.

**R19 completed:** B358 captures14.41s of text/report guest work, full goldens,
immediate quiet gates and joined users. Both original workers exit0; owner archive
fails on root-owned perf data, then persistent raw evidence is recovered/verified
under an exclusive lease without retiming. Original failure/partial archive remain.
Text prefix including inlined work20.64%; ordinary calls/binding1.84/1.92% text/
report, native guards/evaluation4.91/12.67%, report JSON reading11.92%, unknown5–6%.
These are current leaf shares, not dispatch-only cost or promised savings. No new
capture scheduled. benchmarks/results/2026-11-06-current-cpu-records/.

**R20 active, uncommitted coherent prototype: immutable record keys, independent
row values.** Baseline source/actual binaries and contract are frozen under
.git/agent-notes/review-20261031/record-layout-r20/. Canonical native storage is
split into key metadata and values; sets omit the unused values array. JSON and
CSV reuse the same batch-owned immutable keys, with independently sized values.
Removed the old40B coupled entries and JsonRecordKeys sorted hint/comparer/lookup.
Value updates/deletions/clear need no key replacement; insertion admits private
replacement before effects. Protocol candidates remain snapshotted across awaits.
Prior wide schemas do not dictate the next row's values capacity. No new backend.

Focused actual11/10 Release:735 internal and2,400 public checks pass per runtime,
including a CPython mutation/order/protocol golden, real suspended equality and
cancellation, first-refusal-before-mutation, reentrant admission and retained cache
funding. Fixed a real cancellation gap: check the current token after replacement
admission before allocating/publishing even small tables. Full/platform/Stress/
package qualification still belongs to the retention checkpoint, not yet claimed.

Tradeoff: a second ordinary backing array adds shell/locality cost; changed capacity
estimates may reject earlier. Keep all shared metadata/aliases and replacement
peaks funded, no refcounts/tracing/credit layer. Complete canonical migration plus
JSON sharing/old-hint deletion before retention decision. Focused dictionary,
protocol/reentrancy/JSON/CSV/cancellation/ownership tests, then one short report/
JSON pair with ordinary text/CSV controls and separate allocation diagnostics.
Decide regression debt explicitly; no permanent half-migrated mode. Full source/
semantic/ownership/completion contract is selected-record-layout.md in R19 evidence.
Precise complete-job allocation diagnostics and one quiet controlled source pair
are next. No speedup or retention decision is claimed yet.

| Candidate / affected scripts | Source gate and work to eliminate | Acceptance / decision boundary |
| --- | --- | --- |
| Complete call/frame and operand path; text/CSV/JSON helpers | Final bound/local storage, receiver separation, borrowed native arguments, ForwardValues, deferred contexts and one instruction runner already exist. Inspect remaining native guard/evaluation walks versus ordinary dispatch; select a unified representation only if current cost supports it. | Preserve call order, binding/defaults/keywords, closures/classes/generators, native guards before effects, real suspension, first failure and funded aliases. Delete displaced routes, not add another fast backend. |
| Per-record construction; CSV/JSON/report | Bulk field admission, direct parser input, canonical containers and contextual native writes already exist. Reassess historical bulk-CSV6–8% plus adverse control against current source; require an actual remaining builder/copy/ownership boundary before confirmation. | Quoting/newlines/dialects, row types/order/errors, cancellation, refusal-before-mutation, cleanup and retained capacity. Do not automatically promote or replay delivered bulk admission. |
| Remaining text conversions; text/report/JSON | Casing already uses byte bounds/one mapping pass; whitespace ranges batch admission and plain JSON tokens bypass second parsing. Require a demonstrated remaining conversion/copy and a single final storage owner. | Unicode/context/expansion, byte/scalar offsets, hooks, identity, replacement overlap and retained aliases. Earlier shared-window/credit attempts remain adverse evidence. |
| Scalar convention; counters/aggregation | object/boxed BigInteger traffic is real but not causal attribution. R16 touched45 direct-type tests plus protocols/hash/identity/native proofs and public projection. No isolated long path or second convention. | Select only with current cost evidence and one compatible exact-promotion convention; otherwise explicitly deferred, not a tiny arithmetic patch series. |
| Frontend consolidation; fresh scripts | Shared lexical/compiler facts, executable imports/lambdas and immutable builtin metadata are delivered. Compilation44–72us in current guide does not establish dominance. | Reuse facts and remove a real duplicate analysis/retained representation; preserve diagnostics/class cells/scopes and compare compile plus full fresh script. |

For any selected implementation: write hypothesis, representative scripts, semantic
gate and exact displaced code first; then focused tests and one short controlled
source pair with unchanged controls. Separate allocation, elapsed and CPU evidence.
Temporary setbacks may be accepted toward an explicit completion milestone; decide
remaining regression debt at delivery, rather than accumulating narrow special cases.

## Independent regex continuation

Core UTF8/windows/flags/ownership/cancellation development does not wait for a
producer release. U04 applies to normal0.4 and the private immutabledev44 bridge.
The latter retains native cursor high-water working admission instead of the old
subject-size heuristic; independent owners and256KiB bounded matching qualify.
Direct working peak32,880→2,064B, allocation+128B/cursor and adverse local elapsed
+9.1% remain separate historical observations, not hidden speed claims.

Missing final adapter capabilities: one-shot DetailedData cannot choose Prepare's
independent working owner; its conservative preflight stays. Native UTF8 lookup
cannot enumerate names, so the adapter-local string-name bridge stays. Creation-
token coupling still needs per-operation forwarding through actual work. Normal0.4
reversed-window match fails explicitly. Keep these precise boundaries separate
from core semantics and final immutable released-producer/managed-safety checks.
Development packages/adapter-local bridges are allowed. No core package edges,
silent dialect changes, quotas, abandoned work or sibling edits.

## Completed measurements and retained decisions

- Native helper returns: allocation−19.92/−19.31% established and qualified at the
  recorded revisions; elapsed diagnostic, not a causal CPU claim. Do not repeat.
- Direct UTF8 formatting/storage: allocation−8.67%; controlledB102 elapsed/CPU−5–8%
  supports retention. Original adverse15.125ms is still unexplained and preserved;
  no automatic correction or prediction for today's HEAD from that clock.
- R17: PyString shell64→56B, birth-span/unused governing marker deleted; explicit
  operation provenance retained. Whole-job allocation drops, but text elapsed
  +1.6–2.2% is accepted debt. Full combined delivery already qualified.
- R18 shared-target prototypes withdrawn after two complete source pairs; source
  restored/freshly rebuilt/focused-qualified. Refined JSON improves but text gain
  does not recur and CSV CPU is adverse/coarse. Extra branches/forwarding were not
  justified. B61/B69 call-arena/call-control slower designs remain lessons.
- Preserve K01/F02–F05/Q01/Q02/R02–R14: canonical containers, explicit ownership,
  final call/local slots, shared instruction engine, structural/protocol paths,
  async hashing/class extraction/construction and measured native functions.

## Working rules

Timeouts, unstable unchanged controls and inconclusive observations establish
uncertainty. Allow bounded confirmation/refinement/measurement correction for a
stated reason; retain original failures/adverse data. Percentages inform decisions,
not automatic vetoes or permanent bans. No unchanged qualification loops.

Follow AGENTS.md: fully managed/memory-safe, no unsafe/Unsafe/pointers/PInvoke/native
stack probing. Keep managed stack/recursion, host mediation/contained paths, cycles,
active CancellationToken, shared admission/preflights/capacity/replacement/retained
aliases. First refusal fails the command, no retry/recovery. No fuel/quotas/hidden
caps/default allowance/tracing/weak reclamation/forced GC. Await all users/cleanup.
Initial streaming uses bounded host executions. XML depth constraint remains.

Focused Release iteration, both-platform/runtime/Stress/package checkpoints;
no overlapping local builds/tests. Nonincremental build after timestamp-preserving
source restore. Quiet VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem: owned
lease, hashes/quiet/goldens/funding/joins, no SSH during capture, persistent verified
archives. Disk nearly full: verify real headroom and retire only redundant exact
copies with independent verified backups and ended users/dependencies. Publication
and tagging remain postponed. Keep executing after a delivery or experiment.
