from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;out=r/'builder-refined';out.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources={p:sha(p)for p in subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()}
for role in ['reference','candidate']:shutil.copytree(r/'candidate',out/role,copy_function=os.link)
(out/'candidate/Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',out/'candidate/Lokad.Lython.dll')
assert sha(out/'reference/Lokad.Lython.dll')=='9e53b9fa4e62ba5aa6e7e5154ccbc10c2db086062cc420c8f54fe58483242a8f'
shutil.copyfile(out/'candidate/Lokad.Lython.dll',out/'candidate-core.dll')
identity=dict(head='917e01d8 plus R295 cold builder replacement/refund transaction',sources=sources,coreSHA256=sha(out/'candidate-core.dll'),referenceSHA256=sha(out/'reference/Lokad.Lython.dll'))
(out/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'candidate-sources.tar.xz','w:xz')as archive:
 for p in sources:archive.add(p,arcname=p)
shutil.copyfile(r/'catalog.json',out/'catalog.json');shutil.copytree(r/'tool',out/'tool',copy_function=os.link)
code=(r/'diagnostic.py').read_text(encoding='utf-8').replace("r.parent/'bulk-utf16-r276","r.parent.parent/'bulk-utf16-r276")
(out/'diagnostic.py').write_text(code,encoding='utf-8',newline='\n')
for phase in ['warm-sync']:subprocess.run(['python','-X','utf8',str(out/'diagnostic.py'),phase],check=True)
print('R295 frozen',identity['coreSHA256'],'seven full scripts/sync/ownership/cleanup pass; desktop clocks diagnostic only.',flush=True)
