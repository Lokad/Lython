from pathlib import Path
import os,subprocess,sys
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11')
env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
phase=sys.argv[1];label=sys.argv[2]if len(sys.argv)>2 else 'first'
if phase=='build': jobs=[('solution',[str(sdk/'dotnet.exe'),'build','Lokad.Lython.slnx','-c','Release'])]
else:
 names={
 'internal':['CasedSplitOwnership','WhitespaceStorageOwnership','WhitespaceSplitCancellation','SeparatedSplitOwnership','StringWindowOwnership','DirectStringSplit','PyStringOpsPrimitive','PyStringPrimitive','DictionaryCountingLoopAdmission','NativeWord','NativeClosure','ReturnedIteration'],
 'public':['ReturnedIteration','NativeWordBinding','DictionaryCountingLoop','NativeReceiverOperation','NativeClosureLifetime','OrderedFunctionContinuation','Representative']}
 if phase=='preallocation':names['internal']=['CancelledRangeAdmissionDoesNotAllocateBacking']
 if phase=='ownership':
  names={'internal':['MemoryBudget','Admission','CasedSplitOwnership','WhitespaceStorage','SeparatedSplitOwnership'],
   'public':['CooperativeCancellation','CallInputLifetime','ReturnedIteration','NativeWordBinding','SharedMemory','MemoryOwnership']}
 if phase=='builder':
  names={'internal':['ByteBuilderOwnershipTransaction','GovernedOutputCompletion','GovernedByteBuilderPrimitive','RuntimeStorageSubsystem','StringBuilderAdmission','TerminalStringStorage','JsonStringEmissionAdmission','CsvDenialOwnership','DynamicFormattedOwnership'],
   'public':['Format','NativeProducerTextWrite','TextFileWriteCall','HostFileOutputOwnership','OutputGrowthPreflight','HelperContinuationLifetime','CooperativeCancellation']}
 jobs=[]
 for framework in (['net11.0']if phase=='quick'else ['net11.0','net10.0']):
  for suite in ['internal','public']:
   if phase in ['growth','preallocation']and suite=='public':continue
   project='Lokad.Lython.Tests'if suite=='internal'else 'Lokad.Lython.PublicApi.Tests'
   filter='Category!=Stress&('+'|'.join('FullyQualifiedName~'+n for n in names[suite])+')'
   jobs.append((suite+'-'+framework,[str(sdk/'dotnet.exe'),'test',f'tests/{project}/{project}.csproj','-c','Release','-f',framework,'--no-build','--filter',filter]))
   if phase=='preallocation':jobs[-1][1].extend(['--logger','console;verbosity=detailed'])
for name,args in jobs:
 p=r/(phase+'-'+name+'-'+label+'.log');assert not p.exists()
 with p.open('w',encoding='utf-8',newline='\n')as log:done=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(p.name,'exit',done.returncode,flush=True);print(p.read_text(encoding='utf-8')[-9000:],flush=True)
 if done.returncode:sys.exit(done.returncode)
