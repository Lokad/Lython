from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent;src=r/'builder-refined';out=Path('benchmarks/results/2026-11-13-builder-refund-ownership/refined');out.mkdir()
s=(r/'builder-fixed/summarize.py').read_text(encoding='utf-8');(src/'summarize.py').write_text(s,encoding='utf-8',newline='\n');subprocess.run(['python','-X','utf8',str(src/'summarize.py')],check=True)
identity=json.loads((src/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
for framework in ['net11.0','net10.0']:
 for suite in ['internal','public']:assert 'Failed:     0'in(r/f'builder-{suite}-{framework}-refined.log').read_text(encoding='utf-8')
with tarfile.open(out/'source-checks.tar.xz','w:xz')as archive:
 for name in ['candidate-core.dll','candidate-identity.json','candidate-sources.tar.xz','diagnostic.py','summarize.py']:archive.add(src/name,arcname=name)
 archive.add('tests/Lokad.Lython.Tests/ByteBuilderOwnershipTransactionTests.cs',arcname='ByteBuilderOwnershipTransactionTests.cs')
 for p in r.iterdir():
  if p.is_file()and('refined'in p.name or p.name in ['build-solution-builder-cold-transaction.log','check.py']):archive.add(p,arcname='checks/'+p.name)
 for name in ['stdout.json','stderr.log','summary.json']:archive.add(src/'warm-sync'/name,arcname='warm-sync/'+name)
(out/'validation.json').write_text(json.dumps(dict(coreSHA256=identity['coreSHA256'],reference=identity['referenceSHA256'],focusedPerActualTarget=dict(internal=134,public=704),allSevenSyncScripts=True,fullQualificationPending=True,performanceQualified=False),indent=2)+'\n',encoding='utf-8',newline='\n')
p=out.parent/'README.md';text=p.read_text(encoding='utf-8');text=text.replace('Candidate core305fa32f /current570-file source inventory','First-form core305fa32f /570-file source inventory')
text+='''

## Bounded refinement

Final candidate **ed398473** separates the existing cold Grow transaction from
the capacity fast path. The first-form UTF16 sync report had a diagnostic elapsed
+9.84..+10.20% result with0.33% reference spread, while async improved and other
controls drifted. An exception-handler/inlining effect is a hypothesis, not a
measured explanation. Preserve that original adverse condition.

The refinement passes the same134internal/704public per actual target. Seven full
sync scripts/goldens/balances/cleanup pass; first-form async diagnostics remain
source-labelled separately. Allocation remains effectively flat. This is one
bounded short desktop confirmation; its clocks remain diagnostic, so neither CPU
equivalence nor a speedup is claimed. Full qualification of the final correction
is pending at the next delivery boundary, independently of917e01d8's GREEN result.

[Final source/checks and all seven raw sync rows](refined/source-checks.tar.xz),
[exact validation state](refined/validation.json).
''';p.write_text(text,encoding='utf-8',newline='\n')
print('Final R295 source ed398473 and bounded refinement evidence recorded.',flush=True)
