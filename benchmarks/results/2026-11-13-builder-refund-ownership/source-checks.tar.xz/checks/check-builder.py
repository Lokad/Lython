from pathlib import Path
import os,subprocess,sys
r=Path(__file__).parent;label=sys.argv[1];sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
args=[str(sdk/'dotnet.exe'),'test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f','net11.0','--filter','FullyQualifiedName~ByteBuilderOwnershipTransactionTests']
p=r/('builder-'+label+'.log');assert not p.exists()
with p.open('w',encoding='utf-8',newline='\n')as log:done=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
print(p.read_text(encoding='utf-8')[-9500:],flush=True);sys.exit(done.returncode)
