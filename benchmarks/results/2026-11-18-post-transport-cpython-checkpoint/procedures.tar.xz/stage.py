from pathlib import Path
import ast
import hashlib
import io
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
donor = lab.parent / "exact-keyword-transport-r579"
phase = lab.parent / "retained-cpython-r576"
quiet = donor / "quiet"
read = lambda path: path.read_text(encoding="utf-8")
load = lambda path: json.loads(read(path))
sha = lambda value: hashlib.sha256(value).hexdigest()

def write(path, data):
    if path.suffix == ".py":
        ast.parse(data)
    path.write_text(data, encoding="utf-8", newline="\n")

def save(path, data):
    write(path, json.dumps(data, indent=2, ensure_ascii=False) + "\n")

catalog = lab / "representative.json"
catalog_hash = sha(catalog.read_bytes())
verified = load(lab / "verify.json")
assert verified["state"] == "Completed" and verified["catalogSha256"] == catalog_hash
prior = load(quiet / "config.json")
files = prior["identity"]["imageFiles"]["candidate"]
assert len(files) == 32 and files["Lokad.Lython.dll"].startswith("d97f6f98")
assert {name: sha((donor / "frozen/candidate" / name).read_bytes()) for name in files} == files

root = "/home/lokad/lython-bench-checks/post-transport-cpython-b1006-20261118"
unit = "lython-b1006-post-transport-cpython-20261118"
script_hash = sha(Path("benchmarks/cpython-worker.py").read_bytes())
identity = dict(sourceRevision="03bb07cf5", purpose="Three retained-source workloads against stock CPython",
                imageFiles={"candidate": files}, auxiliaryFiles={k: v for k,v in files.items() if k != "Lokad.Lython.dll"},
                coreSHA256={role: files["Lokad.Lython.dll"] for role in ("candidate","candidate-control")},
                catalogSHA256=catalog_hash, cpythonWorkerSHA256=script_hash, normalAdapterPin="0.4.0")
save(lab / "identity.json", identity)
assert not subprocess.check_output(["git","diff","--name-only","1e7f1d526","03bb07cf5","--","src"])
jobs = [(row["id"], False) for row in load(catalog)["cases"]]
runner=read(phase/"collect.py").replace("B1002","B1006").replace("started<390","started<300")
a=runner.index("    for case_id,diagnostic in ")
b=runner.index(chr(10)+"        assert time.monotonic()",a)
runner=runner[:a]+"    for case_id,diagnostic in "+repr(jobs)+":"+runner[b:]
assert script_hash in runner
write(lab/"collect.py",runner)
write(lab/"archive-owned.py", read(phase/"archive-owned.py").replace("==5","==3").replace("jobs=5","jobs=3"))
write(lab/"run.sh", read(phase/"run.sh").replace("/home/lokad/lython-bench-checks/retained-cpython-b1002-20261118",root))
assert b"\r" not in (lab/"run.sh").read_bytes()
space=load(lab/"quiet-space.json")
payload = lab / "payload.tgz"
names = ["representative.json","identity.json","collect.py","archive-owned.py","run.sh"]
with tarfile.open(payload, "w:gz") as archive:
    for name in names:
        archive.add(lab / name, arcname=name)
unpacked = sum((lab / name).stat().st_size for name in names)
needed,available = 254*1024*1024 + unpacked + 512*1024, space["freeBytes"]
retire = []
for proof in sorted(space["replicas"],key=lambda it:-it["bytes"]):
    if available >= needed:break
    retire.append(proof)
    available += proof["bytes"]
assert available >= needed,(available,needed,space["replicas"])
config = dict(root=root,unit=unit,source=prior["root"],sourceRole="candidate",sourceFiles=files,
              sourceCatalogSHA256=prior["catalogSHA256"],catalogSHA256=catalog_hash,identity=identity,
              retireGroups=retire,payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload.read_bytes()),
              unpackedBytes=unpacked,cpythonWorkerSHA256=script_hash)
save(lab / "config.json",config)
launcher = read(quiet / "remote-launch.py")
a,b = launcher.index("\nc=")+1, launcher.index("\nb=Path(")
launcher = launcher[:a] + "c=" + repr(config) + launcher[b:]
launcher = launcher.replace("['reference','candidate']", "['candidate']").replace("lython-b1005-fixtures","lython-b1006-fixtures")
launcher = launcher.replace(" payload=sys.stdin", " assert sha(source/'cpython-worker.py')==c['cpythonWorkerSHA256']\n payload=sys.stdin")
write(lab / "remote-launch.py",launcher)
write(lab/"launch.py",read(phase/"launch.py").replace("seconds=345","seconds=235").replace("345 seconds","235 seconds").replace("B1002","B1006"))
write(lab/"retrieve.py",read(phase/"retrieve.py").replace("['jobs']==5","['jobs']==3").replace("B1002","B1006"))
print("Verified complete frozen image, three-case catalog.")
