from pathlib import Path
import hashlib
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
older = lab.parent / 'retained-cpython-r576'
donor = lab.parent / 'exact-keyword-transport-r579'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == '03bb07cf50074cb0b12b4a41a096353072987e95'
assert not subprocess.check_output(['git', 'diff','--name-only','9d9e7dab3',head,'--','src','tests'])
catalog = load(older / 'representative.json')
cases = {'scripts.text-normalization.helper-list','scripts.report-forwarding.expanded','scripts.rule-default-closures'}
catalog['cases'] = [case for case in catalog['cases'] if case['id'] in cases]
assert len(catalog['cases']) == 3
path = lab / 'representative.json'
path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
frozen = donor / 'frozen/candidate'
manifest = load(donor / 'frozen-identity.json')['images']['candidate']
assert len(manifest) == 32 and manifest['Lokad.Lython.dll'].startswith('d97f6f98')
assert {name: sha(frozen / name) for name in manifest} == manifest
sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab / 'verify.log').open('wb') as log:
    subprocess.run([dotnet, frozen / 'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',path,
                    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',
                    Path.cwd() / 'benchmarks/cpython-worker.py','--out',lab/'verify.json'],
                   env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=75)
verified = load(lab / 'verify.json')
assert verified['state'] == 'Completed' and verified['catalogSha256'] == sha(path)
terminal = load(donor / 'quiet/terminal-status.json')
assert terminal['receipt']['complete'] and not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert terminal['receipt']['archiveSHA256'] == sha(donor / 'quiet/observations.tgz')
(lab/'quiet-space.json').write_text(json.dumps(dict(freeBytes=terminal['receipt']['freeBytesAfterArchive'], replicas=[]))+'\n', encoding='utf-8')
template = (older / 'stage.py').read_text(encoding='utf-8')
template = template.replace('direct-function-defaults-r575', 'exact-keyword-transport-r579')
template = template.replace('representative-cpython-r567', 'retained-cpython-r576')
template = template.replace('6c4cb50a','d97f6f98').replace('sourceRevision="53df08565"','sourceRevision="03bb07cf5"')
template = template.replace('retained-cpython-b1002-20261118','post-transport-cpython-b1006-20261118')
template = template.replace('lython-b1002-retained-cpython-20261118','lython-b1006-post-transport-cpython-20261118')
template = template.replace('Five retained-source workloads against stock CPython','Three retained-source workloads against stock CPython')
template = template.replace('patch=subprocess.check_output(["git","diff","--binary","0cf1156c8","53df08565","--","src","tests"])\nassert patch==(donor/"final-source.patch").read_bytes()',
                            'assert not subprocess.check_output(["git","diff","--name-only","1e7f1d526","03bb07cf5","--","src"])')
template = template.replace('.replace("B993","B1002").replace("started<270","started<390")', '.replace("B1002","B1006").replace("started<390","started<300")')
template = template.replace('.replace("==4","==5").replace("jobs=4","jobs=5")', '.replace("==5","==3").replace("jobs=5","jobs=3")')
template = template.replace('/home/lokad/lython-bench-checks/retained-cpython-b993-20261118', '/home/lokad/lython-bench-checks/retained-cpython-b1002-20261118')
template = template.replace('lython-b1001-fixtures","lython-b1002-fixtures', 'lython-b1005-fixtures","lython-b1006-fixtures')
template = template.replace('seconds=265","seconds=345', 'seconds=345","seconds=235').replace('265 seconds","345 seconds', '345 seconds","235 seconds')
template = template.replace(".replace(\"['jobs']==4\",\"['jobs']==5\")", ".replace(\"['jobs']==5\",\"['jobs']==3\")")
template = template.replace('B993","B1002','B1002","B1006').replace('five-case catalog and archived replica paths', 'three-case catalog')
assert 'assert patch' not in template and 'b1006' in template
compile(template, 'stage.py', 'exec')
(lab/'stage.py').write_text(template,encoding='utf-8',newline='\n')
