from pathlib import Path

lab = Path(__file__).resolve().parent
prior = lab.parent / 'retained-cpython-r576'
script = (prior / 'archive.py').read_text(encoding='utf-8')
script = script.replace('2026-11-18-direct-defaults-cpython-checkpoint','2026-11-18-post-transport-cpython-checkpoint')
script = script.replace('53df08565', '03bb07cf5').replace('B1002','B1006')
script = script.replace('== 5','== 3')
assert "len(row" not in script
exec(compile(script,str(__file__),'exec'))
