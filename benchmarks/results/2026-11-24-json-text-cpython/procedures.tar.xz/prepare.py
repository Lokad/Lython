from pathlib import Path
import hashlib
import json
import os
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.parent/'json-encoding-flags-20261124'
prior=lab.parent/'combined-csv-cpython-20261124/comparison/quiet'
output=lab/'external'
output.mkdir(exist_ok=True)
read=lambda path:json.loads(path.read_text(encoding='utf-8'))
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, source):
    path.write_text(source,encoding='utf-8',newline='\n')


def save(path, data):
    write(path,json.dumps(data,indent=2,ensure_ascii=False)+'\n')


metadata=read(donor/'comparison/identity.json')
proof=read(donor/'comparison/quiet/terminal-status.json')['receipt']
assert proof['complete'] and proof['archivedAndVerifiedUnderLease']
assert digest(donor/'comparison/quiet/observations.tar.xz')==proof['archiveSHA256']
assert metadata['candidate'].startswith('eabbf02ed')
production=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()
assert production.startswith('000ab0632')
subprocess.run(['git','diff','--exit-code',metadata['candidate'],production,'--','src','tests'],cwd=repo,check=True)
identity=read(prior/'identity.json')
identity.update(sourceRevision=metadata['candidate'],candidate=metadata['candidate'],productionSource=production,
    imageFiles={'candidate':metadata['imageFiles']['candidate']},
    frozenImage='/home/lokad/lython-bench-checks/json-text-cpython-b1555-20261124/candidate',
    coreSHA256={role:metadata['coreSHA256']['candidate'] for role in ('candidate','candidate-control')})
assert len(identity['imageFiles']['candidate'])==32
assert all(digest(donor/'candidate'/name)==expected for name,expected in identity['imageFiles']['candidate'].items())

catalog=read(donor/'comparison/representative.json')
with tarfile.open(repo/'benchmarks/results/2026-11-23-combined-cased-split-cpython/observations.tar.xz') as archive:
    profiles=json.load(archive.extractfile('representative.json'))
text=next(item for item in profiles['cases'] if item['id']=='diagnostic.text-summary.nonlocal-computed-width.large')
expanded=catalog['cases'][0]
assert expanded['id']=='scripts.json-lines-shipment.expanded-options.large'
catalog['cases']=[expanded,text]
save(output/'representative.json',catalog)
save(output/'jobs.json',[[expanded['id'],'warm']]+[[text['id'],phase] for phase in ('warm','compile-run','compile')])
identity['catalogs']={name:{'sha256':digest(output/name)} for name in ('representative.json','jobs.json')}
save(output/'identity.json',identity)

dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
protocol=repo/'benchmarks/cpython-worker.py'
assert digest(protocol)==metadata['cpythonWorkerSHA256']==identity['cpythonWorkerSHA256']
subprocess.run([dotnet,donor/'candidate/Lokad.Lython.Benchmarks.dll','--compare','verify',
    '--catalog',output/'representative.json','--dotnet',dotnet,'--python','C:/Python313/python.exe',
    '--python-worker',protocol,'--out',output/'candidate-verify.json'],env=env,check=True,timeout=90)
verified=read(output/'candidate-verify.json')
assert verified['state']=='Completed' and verified['caseCount']==2
assert verified['catalogSha256']==identity['catalogs']['representative.json']['sha256']
assert verified['launched']['library']['sha256']==identity['coreSHA256']['candidate']

collector=(prior/'collect.py').read_text(encoding='utf-8').replace('b1549-','b1555-').replace('len(jobs) == 5','len(jobs) == 4')
collector=collector.replace('CPython checkpoint for retained short-key CSV execution and named regex delivery',
    'CPython checkpoint for expanded JSON and short nonlocal text')
compile(collector,'collect.py','exec')
write(output/'collect.py',collector)
summary=(prior/'summarize.py').read_text(encoding='utf-8').replace('len(raw["jobs"])==5 and receipt["warmJobs"]==5',
    'len(raw["jobs"])==4 and receipt["warmJobs"]==4')
write(output/'summarize.py',summary)

template=lab.parent/'typed-csv-text-20261124/external.py'
launch=template.read_text(encoding='utf-8')
launch=launch.replace("quiet = lab / 'comparison/quiet'", "quiet = lab.parent / 'json-encoding-flags-20261124/comparison/quiet'")
launch=launch.replace('b1551-typed-csv-cpython','b1555-json-text-cpython')
launch=launch.replace('typed-csv-cpython-b1551','json-text-cpython-b1555').replace('typed-csv-text-b1550','json-encoding-flags-b1553')
launch=launch.replace("('collect.py','identity.json','jobs.json')","('collect.py','identity.json','jobs.json','representative.json')")
launch=launch.replace("('representative.json','cpython-worker.py','run.sh')","('cpython-worker.py','run.sh')")
launch=launch.replace('seconds=117','seconds=215').replace('RuntimeMaxSec=170','RuntimeMaxSec=285')
compile(launch,'external.py','exec')
write(lab/'external.py',launch)
