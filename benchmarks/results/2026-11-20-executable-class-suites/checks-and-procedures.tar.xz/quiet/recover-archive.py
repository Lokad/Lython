from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

r = Path(__file__).resolve().parent
config = json.loads((r/'config.json').read_text(encoding='utf-8'))
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem',
       '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
terminal = json.loads(next(r.glob('observation-*.json')).read_text(encoding='utf-8'))
assert terminal['exitCode'] == '1' and 'archive-owned.py' in terminal['journal']
code = r"""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,sys,tarfile
root=Path(ROOT); unit=UNIT
assert root.parent==Path('/home/lokad/lython-bench-checks') and root.resolve()==root
with (root.parent/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    service=subprocess.check_output(['systemctl','show',unit+'.service','--property=ActiveState,MainPID,ExecMainStatus'],text=True)
    assert 'ActiveState=failed' in service and 'MainPID=0' in service and 'ExecMainStatus=1' in service
    assert (root/'exit-code.txt').read_text().strip()=='1'
    assert not (root/'guest-fixtures').exists()
    assert not any(os.path.ismount(p) for p in root.parent.glob('*/guest-fixtures'))
    assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).returncode==1
    archive=root/'observations.tgz'
    with tarfile.open(archive) as tar:
        for info in tar.getmembers():
            if info.isfile():
                with tar.extractfile(info) as member:
                    assert member.read()==(root/info.name).read_bytes(),info.name
        raw=json.loads(tar.extractfile('confirmation/confirmation.json').read())
        assert raw['complete'] and len(raw['jobs'])==5 and all(job['workersJoinedAndFixturesRemoved'] for job in raw['jobs'])
        assert all(json.loads(tar.extractfile('confirmation/'+name).read())['gate']['quiet'] for name in ('machine-before.json','machine-after.json'))
    free=shutil.disk_usage(root).free
    receipt=dict(complete=True,jobs=5,elapsedSeconds=raw['elapsedSeconds'],allWorkersJoined=True,guestFixturesRemoved=True,quietBeforeAndAfter=True,archivedAndVerifiedUnderLease=False,verifiedInRecoveryLease=True,rawMatchesPersistentRecords=True,archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),freeBytesAtRecovery=free,originalDiskFloorBytes=176160768,originalExitCode=1,performanceQualified=False)
    print(json.dumps(receipt),file=sys.stderr,flush=True)
    with archive.open('rb') as source: shutil.copyfileobj(source,sys.stdout.buffer)
""".replace('ROOT',repr(config['root'])).replace('UNIT',repr(config['unit']))
with (r/'observations.tgz').open('wb') as archive:
    done = subprocess.run(ssh+['python3 -'],input=code.encode('utf-8'),stdout=archive,stderr=subprocess.PIPE)
assert done.returncode == 0, done.stderr.decode('utf-8')
receipt = json.loads(done.stderr)
assert receipt['archiveSHA256'] == hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()
(r/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'terminal-status.json').write_text(json.dumps(terminal,indent=2)+'\n',encoding='utf-8',newline='\n')
out=r/'retrieved'
out.mkdir(exist_ok=False)
with tarfile.open(r/'observations.tgz') as archive:
    members=archive.getmembers()
    regular=[m for m in members if m.isfile() or m.isdir()]
    assert all(m.isfifo() and m.size==0 for m in members if m not in regular)
    archive.extractall(out,members=regular,filter='data')
print(json.dumps(receipt))
