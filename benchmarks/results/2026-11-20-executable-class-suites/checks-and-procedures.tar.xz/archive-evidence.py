from pathlib import Path
import gzip
import hashlib
import json
import shutil
import sys
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / 'quiet'
out = Path('benchmarks/results/2026-11-20-executable-class-suites')
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
terminal = load(quiet / 'terminal-status.json')
receipt = load(quiet / 'archive-receipt.json')
assert terminal['exitCode'] == '1' and terminal['receipt'] is None and not terminal['live']
assert 'archive-owned.py' in terminal['journal'] and '176160768' in terminal['journal']
assert not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert all(receipt[name] for name in ('complete','quietBeforeAndAfter','allWorkersJoined','guestFixturesRemoved','verifiedInRecoveryLease','rawMatchesPersistentRecords'))
assert not receipt['archivedAndVerifiedUnderLease']
assert receipt['jobs'] == 5 and receipt['archiveSHA256'] == sha(quiet / 'observations.tgz')

pair = load(lab / 'frozen-identity.json')
assert pair['referenceCommit'].startswith('2dad15d55') and pair['candidateCommit'].startswith('c1d49c4da')
assert pair['casesSHA256'] == sha(lab / 'catalog.json')
cases = {case['id']: case for case in load(lab / 'catalog.json')['cases']}
assert len(cases) == 5

for role, files in pair['images'].items():
    assert len(files) == 32 and {name: sha(lab / 'frozen' / role / name) for name in files} == files
    verified = load(lab / (role + '-verify.json'))
    assert verified['state'] == 'Completed' and verified['catalogSha256'] == pair['casesSHA256']
    assert all(row['sharedBudgetBaselineRestored'] for row in load(lab / (role+'-allocation.json'))['rows'])
    assert load(lab / (role+'-compile-allocation.log'))['coreSha256'] == files['Lokad.Lython.dll']
    for mode in (False, True):
        records = [json.loads(row) for row in (lab / f'probe-{role}-{mode}.jsonl').read_bytes().splitlines()]
        assert len(records) == 7 and all(r['Matches'] and r['Compared'] for r in records)

raw = load(quiet / 'retrieved/confirmation/confirmation.json')
assert raw['complete'] and raw['warmupSeconds'] >= 10 and len(raw['jobs']) == 5
batches = 0
for lane in raw['jobs']:
    assert lane['workersJoinedAndFixturesRemoved']
    case = cases[lane['case']]
    for label, worker in lane['identities'].items():
        files = pair['images'][label.split('-', 1)[0]]
        libraries = {Path(lib['path']).name: lib['sha256'].lower() for lib in worker['libraries']}
        assert libraries['Lokad.Lython.dll'] == files['Lokad.Lython.dll']
        assert all(libraries[name] == files[name] for name in libraries.keys() & files.keys())
    for sample in lane['samples']:
        response = sample['response']
        assert response['status'] == 'Completed' and response['completedInvocations'] > 0
        assert all(response[k] == case[k] for k in ('sourceSha256','fixtureSha256','expectedOutputSha256'))
        assert response.get('actualOutputSha256') == (None if lane['lane'] == 'compile' else case['expectedOutputSha256'])
        assert response.get('actualFilesSha256') == (None if lane['lane'] == 'compile' else case.get('expectedFilesSha256'))
        batches += 1
assert batches == 100

checks = ['Lokad.Lython.Tests-consolidated-win.log','Lokad.Lython.Tests-consolidated-ubuntu.log',
    'Lokad.Lython.PublicApi.Tests-consolidated-win.log','Lokad.Lython.PublicApi.Tests-consolidated-ubuntu.log']
for name, count in zip(checks, (4889,4889,1374,1374), strict=True):
    assert f'Failed:     0, Passed: {count:>5}' in (lab/name).read_text(encoding='utf-8-sig')

exact = ['Lokad.Lython.Tests-exact-win.log','Lokad.Lython.PublicApi.Tests-exact-win.log']
for name in exact:
    assert 'Failed:     0, Passed:' in (lab/name).read_text(encoding='utf-8-sig')

decision = sys.argv[1]
assert decision in ('retained', 'private', 'refine')
out.mkdir(exist_ok=False)
for name in ('archive-receipt.json','terminal-status.json','observations.tgz'):
    shutil.copyfile(quiet / name, out / name)
shutil.copyfile(lab / 'summary.json', out / 'allocation-summary.json')
summary = load(lab / 'quiet-summary.json')
summary.pop('retentionDecisionPending', None)
summary.update(retentionDecision=decision, reference=pair['referenceCommit'], candidate=pair['candidateCommit'],
    cores={role: files['Lokad.Lython.dll'] for role, files in pair['images'].items()}, archiveSHA256=receipt['archiveSHA256'],
    verifiedBatches=batches, originalServiceExitCode=1, archiveVerifiedInRecoveryLease=True,
    diskFloorBytes=receipt['originalDiskFloorBytes'], freeBytesAtRecovery=receipt['freeBytesAtRecovery'])
(out / 'summary.json').write_text(json.dumps(summary,indent=2)+'\n', encoding='utf-8', newline='\n')
reference = Path('benchmarks/results/2026-11-20-direct-statement-emission/measured-core.dll.gz')
assert hashlib.sha256(gzip.decompress(reference.read_bytes())).hexdigest() == pair['images']['reference']['Lokad.Lython.dll']
(out/'measured-core.dll.gz').write_bytes(gzip.compress((lab/'frozen/candidate/Lokad.Lython.dll').read_bytes(),mtime=0))
with tarfile.open(out / 'checks-and-procedures.tar.xz', 'w:xz', preset=6) as archive:
    for name in ('archive-evidence.py','stage-quiet.py','prove-quiet-space.py','freeze-and-verify.py',
                 'quiet-space.json','quiet-space.log','stage.log','launch-console.log',
                 'launch-quiet.py','summarize-quiet.py','measured-source.patch','catalog.json','frozen-identity.json',
                 'retrieval.log','recovery.log','reference-verify.json','candidate-verify.json','reference-allocation.json',
                 'candidate-allocation.json','reference-compile-allocation.log','candidate-compile-allocation.log',
                 'probe-win.log','probe-ubuntu.log','test-ubuntu.sh','production-migration-win.log',
                 'Lokad.Lython.Tests-first-consolidation-win.log','Lokad.Lython.Tests-first-runtime-win.log',
                 'freeze-first-final.log','reference-allocation-first-final.log','final-core-build-win.log',
                 'check-semantics.py','probe-cases.json','probe-reference-False.jsonl','probe-reference-True.jsonl',
                 'probe-candidate-False.jsonl','probe-candidate-True.jsonl',
                 'test-route-migration/Program.cs','test-route-migration/Rewrite.csproj',*checks,*exact):
        archive.add(lab/name,arcname=name)
    for file in sorted((lab/'initial-diagnostics').iterdir()):
        archive.add(file,arcname='initial-diagnostics/'+file.name)
    for observation in quiet.glob('observation-*.json'):
        archive.add(observation,arcname='quiet/'+observation.name)
    for name in ('identity.json','config.json','collect.py','archive-owned.py','run.sh','remote-launch.py',
                 'retrieve.py','recover-archive.py','launch.log','observe-not-before.json'):
        archive.add(quiet / name, arcname='quiet/'+name)
print('Verified both complete images, five CPython workload goldens, seven semantic probes in both modes, and 100 timed batches.')
