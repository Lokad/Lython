using System.Text;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

var files = 0;
foreach (var path in Directory.EnumerateFiles(args[0], "*.cs", SearchOption.TopDirectoryOnly))
{
    var text = File.ReadAllText(path, Encoding.UTF8);
    var root = CSharpSyntaxTree.ParseText(text, CSharpParseOptions.Default.WithLanguageVersion(LanguageVersion.Preview)).GetRoot();
    var changed = new DirectCompile().Visit(root).ToFullString();
    if (changed == text) continue;
    File.WriteAllText(path, changed, new UTF8Encoding(false));
    files++;
}
Console.WriteLine($"Removed redundant lowering at executable compile calls in {files} test files.");

sealed class DirectCompile : CSharpSyntaxRewriter
{
    public override SyntaxNode VisitInvocationExpression(InvocationExpressionSyntax node)
    {
        node = (InvocationExpressionSyntax)base.VisitInvocationExpression(node)!;
        if (node.Expression is not MemberAccessExpressionSyntax
            { Expression: IdentifierNameSyntax { Identifier.ValueText: "ExecutableScript" }, Name.Identifier.ValueText: "Compile" }
            || node.ArgumentList.Arguments.FirstOrDefault()?.Expression is not InvocationExpressionSyntax lower
            || lower.Expression is not MemberAccessExpressionSyntax
            { Expression: IdentifierNameSyntax { Identifier.ValueText: "LoweredScript" }, Name.Identifier.ValueText: "Lower" }
            || lower.ArgumentList.Arguments is not [var syntax]) return node;
        var first = node.ArgumentList.Arguments[0];
        return node.WithArgumentList(node.ArgumentList.WithArguments(node.ArgumentList.Arguments.Replace(first,
            first.WithExpression(syntax.Expression.WithTriviaFrom(lower)))));
    }
}
