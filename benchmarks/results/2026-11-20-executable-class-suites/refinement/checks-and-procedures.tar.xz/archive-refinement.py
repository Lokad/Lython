from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile

lab=Path(__file__).resolve().parent
old=lab.parent
quiet=lab/'quiet'
out=Path('benchmarks/results/2026-11-20-executable-class-suites/refinement')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=load(quiet/'archive-receipt.json')
terminal=load(quiet/'terminal-status.json')
assert terminal['exitCode']=='0' and terminal['receipt']==receipt and not terminal['live']
assert not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert all(receipt.get(k) for k in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['jobs']==4 and receipt['archiveSHA256']==sha(quiet/'observations.tgz')
assert receipt['freeBytesAfterArchive']>176160768
pair=load(lab/'frozen-identity.json')
assert pair['referenceCommit'].startswith('2dad15d55') and pair['candidateCommit'].startswith('cf059b2a2')
assert pair['casesSHA256']==sha(lab/'catalog.json')
cases={case['id']:case for case in load(lab/'catalog.json')['cases']}
assert len(cases)==5
for role,files in pair['images'].items():
    assert len(files)==32 and {name:sha(lab/'frozen'/role/name) for name in files}==files
    check=load(lab/(role+'-verify.json'))
    assert check['state']=='Completed' and check['catalogSha256']==pair['casesSHA256']
    assert all(row['sharedBudgetBaselineRestored'] for row in load(lab/(role+'-allocation.json'))['rows'])
    assert load(lab/(role+'-compile-allocation.log'))['coreSha256']==files['Lokad.Lython.dll']
    for mode in (False,True):
        rows=[json.loads(line) for line in (lab/f'probe-{role}-{mode}.jsonl').read_bytes().splitlines()]
        assert len(rows)==8 and all(row['Matches'] and row['Compared'] for row in rows)
raw=load(quiet/'retrieved/confirmation/confirmation.json')
assert raw['complete'] and raw['warmupSeconds']>=10 and len(raw['jobs'])==4
batches=0
for row in raw['jobs']:
    assert row['workersJoinedAndFixturesRemoved']
    case=cases[row['case']]
    assert len(row['samples'])==20
    for label,worker in row['identities'].items():
        files=pair['images'][label.split('-',1)[0]]
        libraries={Path(lib['path']).name:lib['sha256'].lower() for lib in worker['libraries']}
        assert libraries['Lokad.Lython.dll']==files['Lokad.Lython.dll']
        assert all(libraries[name]==files[name] for name in libraries.keys() & files.keys())
    for sample in row['samples']:
        response=sample['response']
        assert response['status']=='Completed' and response['completedInvocations']>0
        assert all(response[k]==case[k] for k in ('sourceSha256','fixtureSha256','expectedOutputSha256'))
        assert response.get('actualOutputSha256')==(None if row['lane']=='compile' else case['expectedOutputSha256'])
        assert response.get('actualFilesSha256')==(None if row['lane']=='compile' else case.get('expectedFilesSha256'))
        batches+=1
assert batches==80
checks={}
for suite,count in (('Lokad.Lython.Tests',4889),('Lokad.Lython.PublicApi.Tests',1369)):
    for os in ('ubuntu','win'):
        name=f'{suite}-reuse-block-{os}.log'
        assert f'Failed:     0, Passed: {count:>5}' in (old/name).read_text(encoding='utf-8-sig')
        checks[name]=count
decision=sys.argv[1]
assert decision in ('retained','private','refine')
out.mkdir(exist_ok=False)
for name in ('archive-receipt.json','terminal-status.json','observations.tgz'):
    shutil.copyfile(quiet/name,out/name)
shutil.copyfile(lab/'summary.json',out/'allocation-summary.json')
summary=load(lab/'quiet-summary.json')
summary.pop('retentionDecisionPending',None)
summary.update(retentionDecision=decision,reference=pair['referenceCommit'],candidate=pair['candidateCommit'],
    cores={role:files['Lokad.Lython.dll'] for role,files in pair['images'].items()},archiveSHA256=receipt['archiveSHA256'],
    verifiedBatches=batches,focusedReleaseChecks=checks,CPythonPerformanceMeasured=False)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
ref=Path('benchmarks/results/2026-11-20-direct-statement-emission/measured-core.dll.gz')
assert hashlib.sha256(gzip.decompress(ref.read_bytes())).hexdigest()==pair['images']['reference']['Lokad.Lython.dll']
(out/'measured-core.dll.gz').write_bytes(gzip.compress((lab/'frozen/candidate/Lokad.Lython.dll').read_bytes(),mtime=0))
with tarfile.open(out/'checks-and-procedures.tar.xz','w:xz',preset=6) as tar:
    for name in ('archive-refinement.py','stage-quiet.py','freeze-and-verify.py','launch-quiet.py','summarize-quiet.py',
                 'measured-source.patch','catalog.json','frozen-identity.json','reference-verify.json',
                 'candidate-verify.json','reference-allocation.json','candidate-allocation.json','reference-compile-allocation.log',
                 'candidate-compile-allocation.log','check-semantics.py','probe-cases.json','probe-reference-False.jsonl',
                 'probe-reference-True.jsonl','probe-candidate-False.jsonl','probe-candidate-True.jsonl'):
        tar.add(lab/name,arcname=name)
    for name in (*checks,'reuse-block-build.log','reuse-block-allocation.json','reuse-block-exact-build.log','reuse-block-exact-allocation.json',
                 'reuse-block-probe-win.log','reuse-block-probe-ubuntu.log','test-reuse-ubuntu.sh'):
        tar.add(old/name,arcname=name)
    for name in ('identity.json','config.json','collect.py','archive-owned.py','run.sh','remote-launch.py',
                 'retrieve.py','launch.log','observe-not-before.json'):
        tar.add(quiet/name,arcname='quiet/'+name)
    tar.add(old/'vm-build-output-archive/remote-generated-output-retirement.json',arcname='maintenance/remote-generated-output-retirement.json')
print('Verified both images, eight cross-engine probes in both modes, five goldens, all focused Release checks and 80 timed batches.')
