set -eu
export DOTNET_ROOT="$HOME/.dotnet"
lab=$PWD/.git/agent-notes/review-20261031/executable-class-suites
export PATH="$DOTNET_ROOT:$lab/../compiler-callback-ownership/tools:$PATH"
command -v python
cd .git/agent-worktrees/executable-class-suites
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 --no-incremental >"$lab/reuse-block-probe-ubuntu.log" 2>&1 || { tail -n 35 "$lab/reuse-block-probe-ubuntu.log"; exit 1; }
filter='(FullyQualifiedName~Class|FullyQualifiedName~Annotation|FullyQualifiedName~Dataclass|FullyQualifiedName~TypedDict|FullyQualifiedName~NamedTuple|FullyQualifiedName~TypeAlias|FullyQualifiedName~CompilerCancellation|FullyQualifiedName~AdmissionFailureCommand|FullyQualifiedName~Generator|FullyQualifiedName~ProtectedLoop|FullyQualifiedName~NamespaceView)&Category!=Stress'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/$suite-reuse-block-ubuntu.log"
    if [ "$suite" = Lokad.Lython.Tests ]; then suite_filter='Category!=Stress'; else suite_filter="$filter"; fi
    dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --filter "$suite_filter" >"$log" 2>&1 || { tail -n 75 "$log"; exit 1; }
    tail -n 7 "$log"
done
