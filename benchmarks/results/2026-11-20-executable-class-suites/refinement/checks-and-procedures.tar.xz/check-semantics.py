from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
cases={'class-annotation-namespace': 'outside: int\nclass C:\n    global __annotations__\n    item: str\nprint(list(__annotations__), list(C.__annotations__))\n', 'comprehension-lambda-cell': 'class C:\n    def owner(self):\n        return __class__\n    readers=[lambda: (x, __class__) for x in [1,2]]\nv,t=C.readers[0]()\nprint(v, t is C, C().owner() is t)\n', 'protected-class-body-control': "events=[]\nclass Region:\n    def __enter__(self):\n        events.append('begin')\n    def __exit__(self, *exc):\n        events.append('end')\nclass C:\n    for i in range(3):\n        with Region():\n            events.append(i)\n            if i==0:\n                continue\n            break\n    else:\n        events.append('loop completed')\nprint(C.i, events)\n", 'nested-method-class-cell': 'class Base:\n    def score(self):\n        return 10\ndef make(amount):\n    class Child(Base):\n        def score(self):\n            return super().score()+amount\n        def owner(self):\n            return __class__\n    return Child\nC=make(3)\nprint(C().score(), C().owner() is C)\n', 'class-lazy-type-alias': 'class C:\n    kind=int\n    type Kind=kind\n    kind=str\nprint(C.Kind.__value__ is str)\n', 'live-class-namespace': "class C:\n    history=locals()\n    value=7\n    del value\n    next=8\nprint('value' in C.history, C.history['next'])\n", 'prepared-decorator-order': "events=[]\ndef decor(marker):\n    events.append('eval '+marker)\n    def apply(target):\n        events.append('apply '+marker)\n        return target\n    return apply\n@decor('top')\n@decor('bottom')\nclass Defined:\n    events.append('body')\nprint(events)\n"}
cases['sibling-emission-ownership'] = "marks = []\ndef factory(seed):\n    def first(value='first'):\n        return value, seed\n    class A:\n        values = [x for x in (1, 2)]\n        try:\n            for n in values:\n                if n == 1:\n                    continue\n                marks.append(n)\n        finally:\n            marks.append('A')\n        def expose(self):\n            return __class__, seed\n    def second(value='second'):\n        return value, seed + 10\n    class B:\n        values = ['later']\n        size = len(values)\n    return first, second, A, B\nf, g, A, B = factory(4)\nC, seed = A().expose()\nprint(f(), g(), C is A, seed, B.values, B.size, marks)\n"
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
probe=Path('.git/agent-worktrees/executable-class-suites/tools/LythonProbe/bin/Release/net11.0')
pair=load(lab/'frozen-identity.json')
body=json.dumps(list(cases.values())).encode('utf-8')
(lab/'probe-cases.json').write_bytes(body)
for role,files in pair['images'].items():
    source=lab/'frozen'/role
    assert len(files)==32 and {n:sha(source/n) for n in files}==files
    image=lab/'probe'/role
    shutil.copytree(probe,image,dirs_exist_ok=True)
    for file in image.glob('Lokad.*.dll'):
        if file.name in files:
            shutil.copyfile(source/file.name,file)
            assert sha(file)==files[file.name]
    assert sha(image/'Lokad.Lython.dll')==files['Lokad.Lython.dll']
    for async_mode in (False,True):
        args=[sdk/'dotnet.exe',image/'LythonProbe.dll','--batch-json','--compare-python','--python','C:/Python313/python.exe']
        if async_mode:args.append('--async')
        process=subprocess.run(args,input=body,capture_output=True,timeout=55,env=env)
        (lab/f'probe-{role}-{async_mode}.jsonl').write_bytes(process.stdout)
        assert process.returncode==0,(role,async_mode,process.stderr.decode(),process.stdout.decode())
        reports=[json.loads(line) for line in process.stdout.splitlines()]
        assert len(reports)==len(cases) and all(row['Matches'] and row['Compared'] for row in reports)
print(f'{len(cases)} CPython semantic probes pass in sync and async modes for both source images.')
