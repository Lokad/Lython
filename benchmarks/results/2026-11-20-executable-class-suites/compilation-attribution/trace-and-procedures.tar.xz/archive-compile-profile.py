from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
data = lab/'compile-profile'
out = Path('benchmarks/results/2026-11-20-executable-class-suites/compilation-attribution')
out.mkdir(exist_ok=False)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = lab.parent / 'frontend-structure-b80/reader/Program.cs'
pair = json.loads((lab/'frozen-identity.json').read_text(encoding='utf-8-sig'))
identities = {}
for role, files in pair['images'].items():
    core = files['Lokad.Lython.dll']
    assert sha(lab/'frozen'/role/'Lokad.Lython.dll') == core
    allocations=json.loads((data/(role+'-allocations.json')).read_text(encoding='utf-8'))
    log=(data/(role+'-compile.log')).read_text(encoding='utf-8-sig')
    assert core in log
    identities[role]=dict(coreSHA256=core, traceSHA256=sha(data/(role+'.nettrace')),
        samples=allocations['compilerRootedTicks'])
assert identities['reference']['samples']==18309 and identities['candidate']['samples']==21550
summary=subprocess.check_output(['C:/Python313/python.exe','-X','utf8',lab/'summarize-compile-profile.py'],encoding='utf-8')
(out/'trigger-summary.txt').write_text(summary,encoding='utf-8',newline='\n')
(out/'identity.json').write_text(json.dumps(identities,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'trace-and-procedures.tar.xz','w:xz',preset=6) as archive:
    for name in ('profile-compile.py','summarize-compile-profile.py','archive-compile-profile.py','frozen-identity.json'):
        archive.add(lab/name,arcname=name)
    archive.add(source,arcname='reader/Program.cs')
    archive.add(source.with_name('Diagnostics.csproj'),arcname='reader/Diagnostics.csproj')
    for path in sorted(data.iterdir()):
        if path.suffix!='.etlx': archive.add(path,arcname='compile-profile/'+path.name)
with tarfile.open(out/'trace-and-procedures.tar.xz','r:xz') as archive:
    for role, expected in identities.items():
        with archive.extractfile('compile-profile/'+role+'.nettrace') as trace:
            assert hashlib.sha256(trace.read()).hexdigest()==expected['traceSHA256']
print(summary)
