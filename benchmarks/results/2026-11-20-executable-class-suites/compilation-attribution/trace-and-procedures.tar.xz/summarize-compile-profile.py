import json
from collections import Counter
from pathlib import Path

lab = Path(__file__).parent / 'compile-profile'
for role in ('reference','candidate'):
    data = json.loads((lab/(role+'-allocations.json')).read_text(encoding='utf-8'))
    buckets = Counter()
    methods = Counter()
    details = Counter()
    for item in data['allocations']:
        for origin, size in item['origins'].items():
            if 'Builder.CompileClassDefinition(' not in origin: continue
            phase = origin.split(' -> ')[0].split('(',1)[0].split('.')[-1]
            methods[phase] += size
            details[item['type']] += size
            for name, match in (
                ('body code construction', 'Builder.CompileCodeObject('),
                ('lowered expression prep', 'LoweredScript.LowerExpression('),
                ('instruction growth', 'Builder.AddInstruction('),
                ('opcode finalization', 'ExecutableCodeObject..ctor('),
                ('scope facts', 'ScopeDirectiveFactsCollector.ForClass('),
            ):
                if match in origin.partition('Builder.CompileClassDefinition(')[0]: buckets[name] += size
    print(role)
    for counter in (buckets,methods,details):
        print([(name,round(size/1048576,1)) for name,size in counter.most_common(10)])
