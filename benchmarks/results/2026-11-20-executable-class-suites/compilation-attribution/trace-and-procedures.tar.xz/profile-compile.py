from pathlib import Path
import datetime
import hashlib
import json
import os
import statistics
import subprocess

lab = Path(__file__).resolve().parent
work = lab/'compile-profile'
work.mkdir(exist_ok=False)
catalog = json.loads((lab/'catalog.json').read_text(encoding='utf-8-sig'))
case = next(case for case in catalog['cases'] if '.dataclass-' in case['id'])
catalog['cases'] = [case]*8  # The single-phase allocation helper accepts repeat cases.
(work/'inputs.json').write_text(json.dumps(catalog), encoding='utf-8')
pair = json.loads((lab/'frozen-identity.json').read_text(encoding='utf-8-sig'))
sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), DOTNET_TieredCompilation='0')
tool = Path.home()/'.dotnet/tools/dotnet-trace.exe'
reader = lab.parent/'frontend-structure-b80/reader/bin/Release/net11.0/Diagnostics.dll'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
utc = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
for role, files in pair['images'].items():
    image = lab/'frozen'/role
    assert {name:sha(image/name) for name in files}==files
    started=utc()
    trace=work/(role+'.nettrace')
    with (work/(role+'-compile.log')).open('wb') as log:
        subprocess.run([tool,'collect','--profile','gc-verbose','--show-child-io','--output',trace,'--',
                        dotnet,image/'CompileAllocation.dll',work/'inputs.json'],
                        stdout=log,stderr=subprocess.STDOUT,env=env,check=True,timeout=90)
    window = work/(role+'-window.json')
    window.write_text(json.dumps(dict(startedUtc=started,stoppedUtc=utc())),encoding='utf-8')
    with (work/(role+'-reader.log')).open('wb') as log:
        subprocess.run([dotnet,reader,trace,window,work/(role+'-allocations.json')],
                       stdout=log,stderr=subprocess.STDOUT,env=env,check=True,timeout=90)
    assert {name:sha(image/name) for name in files}==files
    diagnostic=json.loads((work/(role+'-allocations.json')).read_text(encoding='utf-8'))
    ticks=diagnostic['compilerRootedTicks']
    assert ticks>=200,ticks
    print(role,ticks,'rooted allocation samples')
    for group in diagnostic['allocations'][:18]:
        print(group['type'], round(group['approximateBytes']/1048576,2))
