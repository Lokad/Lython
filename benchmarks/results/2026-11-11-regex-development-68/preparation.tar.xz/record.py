from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,zipfile

repo=Path.cwd();r=Path(__file__).parent
before=json.loads((r/'normal-state-before.json').read_text(encoding='utf-8'))
after={name:hashlib.sha256((repo/name).read_bytes()).hexdigest()for name in before}
assert before==after
proof=dict(passed=True,fileCount=len(before),before=before,after=after,scope='Normal production source/pins/locks/assets and matching pre-existing outputs remain byte-identical; development feed/assets/cache/locks/outputs are isolated.')
(r/'normal-state-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
qualification=json.loads((r/'qualification.json').read_text(encoding='utf-8'))
loaded={}
for framework in ['net11.0','net10.0']:
    for suite,count in [('Lokad.Lython.Tests',86),('Lokad.Lython.PublicApi.Tests',532)]:
        assert qualification['checks'][suite+'-'+framework]['passed']==count
    loaded[framework]={}
    for name in ['Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
        filename=name+'.0.5.0-dev.68.nupkg'
        with zipfile.ZipFile(r/'feed'/filename)as a:data=a.read('lib/'+framework+'/'+name+'.dll')
        digest=hashlib.sha256(data).hexdigest()
        assert qualification['checks'][framework+'-loadedFiles'][name]==digest
        loaded[framework][name]=digest
sourceCommit='a7e985ed2c1bb4ac7d63a09c74e3ba0a74ccb9b9';priorCommit='d8eb14a52b2c044f4345af03469356992be58861'
changed=subprocess.check_output(['git','-C','D:/code/utf8regex','diff','--name-only',priorCommit,sourceCommit,'--','src/Lokad.Utf8Regex.PythonRe'],text=True).splitlines()
assert set(changed)=={'src/Lokad.Utf8Regex.PythonRe/'+name for name in ['PythonReScalarMatchCursor.cs','PythonReScalarMatchState.cs','README.md','Utf8PythonRegex.OneShotText.cs','Utf8PythonRegex.Utf8.cs']}
for name in ['Utf8PythonRegex.Cursor.cs']:
    path='src/Lokad.Utf8Regex.PythonRe/'+name
    assert subprocess.check_output(['git','-C','D:/code/utf8regex','show',priorCommit+':'+path])==subprocess.check_output(['git','-C','D:/code/utf8regex','show',sourceCommit+':'+path])
assessment=dict(immutableVersion='0.5.0-dev.68',immutableSource=sourceCommit,liveSiblingHeadNotUsed=True,
    sourceDelta='Private one-shot text materialization/validation facts and literal-family search differ. No relevant public producer signature changed; exact source diff retained, not inferred solely from XML equality.',
    missing=['Single-match working owner independent of retained result owner.','Native UTF-8 group-name enumeration.','Token-independent cursor creation with cancellable preparation.'],
    decision='Qualify the new immutable input with the unchanged Validate development bridge; no new core plumbing/bridge rewrite/normal-pin promotion justified. Three final producer gaps remain exact.',
    scope='86internal/532public on each actualtarget, loaded binaries match the pinned packages, normal-state proof passes. No whole-backend performance, final published producer or source-safety certification.',
    loaded=loaded)
(r/'capability-assessment.json').write_text(json.dumps(assessment,indent=2)+'\n',encoding='utf-8')
out=repo/'benchmarks/results/2026-11-11-regex-development-68';out.mkdir(exist_ok=True)
for name in ['identity.json','qualification.json','normal-state-proof.json','proposal.json','capability-assessment.json']:
    shutil.copyfile(r/name,out/name)
with tarfile.open(out/'preparation.tar.xz','w:xz')as a:
    for f in sorted(r.iterdir()):
        if f.is_file()and f.suffix in ['.py','.cs','.json','.log','.props','.Config','.patch']:a.add(f,arcname=f.name)
    for f in sorted((r/'feed').iterdir()):a.add(f,arcname='feed/'+f.name)
    for f in (r/'locks').iterdir():a.add(f,arcname='locks/'+f.name)
    for framework in ['net11.0','net10.0']:
        folder=r/'out/Lokad.Lython.PublicApi.Tests/Release'/framework
        for name in ['Lokad.Lython','Lokad.Lython.Utf8Regex','Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
            a.add(folder/(name+'.dll'),arcname='qualified/'+framework+'/'+name+'.dll')
f=out/'preparation.tar.xz'
with tarfile.open(f)as a:
    for m in a:
        if m.isfile():a.extractfile(m).read()
(out/'archive-identity.json').write_text(json.dumps(dict(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8')
(out/'README.md').write_text('''# R226 — immutable dev68 adapter input

2026-11-11. Lython committed runtime4aa2d46d, evidence revision331eb420; normal
optional adapter0.4 remains unchanged. Core stays independent/non-packable adapter.
Immutable producer0.5.0-dev.68 froma7e985ed is copied from its accepted candidate
feed, with exact package/dual-target assembly/nuspec-commit verification. Moving
sibling HEAD/live package outputs are not substituted. [Identity](identity.json).

**86internal/532public focused checks pass on each actual.NET11/.NET10**, including
contract/semantic/cancellation/refusal/ownership/window/cursor controls. The unchanged
development bridge uses Validate. Restored and loaded binary hashes match the
pinned packages; [qualification](qualification.json). All normal-state files remain
byte-identical: [exact proof](normal-state-proof.json). No sibling edit/build/repack,
normal source/pin change, new core dependency or publication.

The new producer changes private single-text materialization/validation facts and
literal-family search; this justified testing a new binary rather than replaying
unchangeddev67. It does not supply a new public contract to streamline Lython:

- Single-match working ownership remains inseparable from retained results.
- Native UTF-8 group-name enumeration is still absent; native lookup already exists.
- Cursor preparation still lacks the token-independent/cancellable creation shape;
  per-move tokens do not prove interruption during preparation.

[Capability/source assessment](capability-assessment.json) retains the exact diff;
XML member equality alone is not treated as completeness proof. No new bridge or
core abstraction is selected. Existing temporary conversions stay adapter-local.
Missing producer APIs defer affected final released-package qualification only.

This is development-input qualification, not whole-backend speed/safety, AssumeValid,
normal-pin promotion or final published-producer certification. Earlierdev67/Trusted
qualification remains historical and is not repeated. Core deliveryCI42953725339
on4aa is separate. [Proposal](proposal.json),[exact packages/bridge/commands/logs](preparation.tar.xz),
[archive identity](archive-identity.json). Publication remains postponed.
''',encoding='utf-8')
print(json.dumps(dict(normalStateFiles=len(before),loadedVerified=True,checks='86internal/532public per actualtarget',finalCapabilityGaps=assessment['missing'])))
