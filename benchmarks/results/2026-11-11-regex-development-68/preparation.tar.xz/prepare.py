from pathlib import Path
import hashlib,json,shutil,subprocess,xml.etree.ElementTree as ET,zipfile

repo=Path.cwd();r=Path(__file__).parent;old=r.parent/'regex-dev67-r215'
source=json.loads((repo/'benchmarks/results/2026-11-11-ordinary-return-consumption/source-identity.json').read_text(encoding='utf-8'))
for name,h in source['normalizedSource'].items():assert hashlib.sha256((repo/name).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==h,name
for name in ['Directory.Build.props','Directory.Packages.props','NuGet.Config','Utf8RegexProvider.cs','CursorAdmissionTests.cs','workflow-fixture-manifest.json','qualify.py']:
    s=(old/name).read_text(encoding='utf-8').replace('regex-dev67-r215','regex-dev68-r226').replace('0.5.0-dev.67','0.5.0-dev.68')
    (r/name).write_text(s,encoding='utf-8')
normal=json.loads((old/'normal-state-before.json').read_text(encoding='utf-8'))
(r/'normal-state-before.json').write_text(json.dumps({name:hashlib.sha256((repo/name).read_bytes()).hexdigest()for name in normal},indent=2)+'\n',encoding='utf-8')
origin=Path('D:/code/utf8regex/artifacts/package-candidates/0.5.0-dev.68')
manifest=json.loads((origin/'candidate.json').read_text(encoding='utf-8'))
commit='a7e985ed2c1bb4ac7d63a09c74e3ba0a74ccb9b9'
assert manifest['SourceRevision']==commit and manifest['CleanSource']and not manifest['Published']
(r/'feed').mkdir();packages={}
for name in ['Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
    filename=name+'.0.5.0-dev.68.nupkg';f=origin/'feed'/filename;data=f.read_bytes()
    rows=[x for x in manifest['Packages']if x['Id']==name]
    assert {x['TargetFramework']for x in rows}=={'net11.0','net10.0'}
    digest=hashlib.sha256(data).hexdigest();assert all(x['PackageSha256'].lower()==digest for x in rows)
    with zipfile.ZipFile(f)as a:
        nuspec=ET.fromstring(a.read(next(n for n in a.namelist()if n.endswith('.nuspec'))))
        assert next(e.attrib['commit']for e in nuspec.iter()if e.tag.endswith('repository'))==commit
        for row in rows:
            assert hashlib.sha256(a.read('lib/'+row['TargetFramework']+'/'+name+'.dll')).hexdigest()==row['AssemblySha256'].lower()
        deps=[e.attrib for e in nuspec.iter()if e.tag.endswith('dependency')]
    shutil.copyfile(f,r/'feed'/filename);packages[filename]=dict(sha256=digest,repositoryCommit=commit,dependencies=deps)
identity=dict(consumerRevision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),consumerRuntime='All568production hashes equal committed4aa2d46d;600internal/2653public focused eachtarget. FullCI42953725339 active separately.',
    producerVersion='0.5.0-dev.68',producerSourceHead='Immutable accepted candidate a7e985ed, never moving sibling HEAD/live artifacts/nuget.',packages=packages,
    bridge='Unchanged dev67/development bridge and cursor-admission controls; Validate default. Isolated package feed/cache/assets/locks/outputs; no normal pin/source change.',
    providerSourceSHA256=hashlib.sha256((r/'Utf8RegexProvider.cs').read_bytes()).hexdigest(),cursorTestSourceSHA256=hashlib.sha256((r/'CursorAdmissionTests.cs').read_bytes()).hexdigest(),
    limitations='Development semantic/cancellation/ownership qualification only; no normal pin promotion, final published producer qualification or safety/backend performance certification.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'producer-relevant.patch').write_bytes(subprocess.check_output(['git','-C','D:/code/utf8regex','diff','d8eb14a52b2c044f4345af03469356992be58861',commit,'--','src']))
(r/'proposal.json').write_text(json.dumps(dict(scope='One bounded qualification of new immutable dev68 on current Lython using the unchanged validated bridge; actual.NET11/.NET10 focused checks, normal29-file isolation proof.',
    rationale='Single-match text materialization and finite literal-family search differ. Public API equality alone cannot certify semantic/cancellation behavior of changed producer binaries.',
    capabilities='No public producer signature changes in relevant diff; group-name enumeration/working-owner/cursor-creation gaps remain. No new core plumbing or bridge extension selected.',
    stop='Stop after focused checks and exact package/loaded-image/normal-state proofs, or preserve failures and precise missing evidence. No performance campaign, sibling edit/build, repack or normal promotion.'),indent=2)+'\n',encoding='utf-8')
print('Pinned dev68 candidate packages/dual-target assembly hashes verified; unchanged Validate bridge isolated. Normal files untouched.')
