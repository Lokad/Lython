from pathlib import Path
import hashlib,json,os,subprocess,tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / "current-retained-linux-profile-20261122"
donor = lab.parent / "retained-current-cpython-b1406"
published = repo / "benchmarks/results/2026-11-22-current-source-cpython"
root = "/home/lokad/lython-bench-checks/current-retained-runtime-b1407-20261122"
unit = "lython-b1407-current-retained-runtime-20261122"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, content):
    if path.suffix == ".py":
        compile(content, str(path), "exec")
    path.write_text(content, encoding="utf-8", newline="\n")

def save(path, data):
    write(path, json.dumps(data, indent=2) + "\n")

old = read(prior / "config.json")
source = read(donor / "images.json")
lease = read(donor / "comparison/quiet/config.json")
receipt = read(published / "archive-receipt.json")
assert all(receipt[k] for k in ("complete", "allWorkersJoined", "guestFixturesRemoved", "archivedAndVerifiedUnderLease"))
assert sha(published / "observations.tgz") == receipt["archiveSHA256"]
assert source == read(published / "source.json")
image = donor / "frozen"
manifest = source["imageFiles"]["candidate"]
assert len(manifest) == 32 and {n: sha(image / n) for n in manifest} == manifest
assert source["imageFiles"] == lease["identity"]["imageFiles"]
catalog = read(prior / "catalog.json")
full = read(donor / "representative.json")
assert all(row == next(x for x in full["cases"] if x["id"] == row["id"]) for row in catalog["cases"])
save(lab / "catalog.json", catalog)
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
subprocess.run([
    dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
    "--catalog", lab / "catalog.json", "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
    "--python-worker", repo / "benchmarks/cpython-worker.py", "--out", lab / "verification.json",
], env=env, cwd=repo, check=True, timeout=90)
check = read(lab / "verification.json")
catalog_sha = sha(lab / "catalog.json")
assert check["state"] == "Completed" and check["caseCount"] == 2 and check["catalogSha256"] == catalog_sha
identity = dict(old["identity"], sourceRevision=source["revision"], productionRevision=source["revision"],
    coreSHA256={"candidate":manifest["Lokad.Lython.dll"]}, catalogSHA256=catalog_sha,
    imageFiles=source["imageFiles"])
save(lab / "identity.json", identity)
for name in ("ops-profile.py", "collect.py", "run.sh", "retrieve.py", "launch.py", "analyze.py"):
    data = (prior / name).read_text(encoding="utf-8")
    write(lab / name, data.replace(old["root"], root).replace(old["unit"], unit).replace("B1399", "B1407"))
assert b"\r" not in (lab / "run.sh").read_bytes()
parts = ("identity.json", "catalog.json", "collect.py", "ops-profile.py", "run.sh")
payload = lab / "payload.tgz"
with tarfile.open(payload, "w:gz") as bundle:
    for name in parts:
        bundle.add(lab / name, arcname=name)
config = dict(root=root, unit=unit, identity=identity, source=lease["root"], sourceFiles=source["imageFiles"],
    catalogSHA256=catalog_sha, donorArchive=receipt["archiveSHA256"], retireGroups=[],
    payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload), unpackedBytes=sum((lab / n).stat().st_size for n in parts))
save(lab / "config.json", config)
launcher = (prior / "remote-launch.py").read_text(encoding="utf-8").replace("b1399-fixtures", "b1407-fixtures")
start, end = launcher.index("\nc=") + 1, launcher.index("\nb=Path(")
write(lab / "remote-launch.py", launcher[:start] + "c=" + repr(config) + launcher[end:])
