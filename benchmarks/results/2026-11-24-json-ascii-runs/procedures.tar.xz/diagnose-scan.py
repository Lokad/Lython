import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/'.git/agent-worktrees/regex-wrapper-cache-20261124'
file='src/Lokad.Lython/Runtime/LythonRuntime.Json.Serialize.cs'
entry=tree/file
comparison=lab/'comparison'
identity=json.loads((comparison/'identity.json').read_text(encoding='utf-8'))
catalog=json.loads((comparison/'representative.json').read_text(encoding='utf-8'))
runtime=Path.home()/'.dotnet11'
dotnet=runtime/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(runtime),DOTNET_ROOT_X64=str(runtime))
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()

assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip()==identity['candidate']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=tree)
source=entry.read_text(encoding='utf-8')
declaration="""        private static class JsonAsciiRunDiagnostic
        {
            private static long _calls;
            private static long _searches;
            private static long _asciiBytes;
            private static long _otherScalars;

            static JsonAsciiRunDiagnostic()
            {
                AppDomain.CurrentDomain.ProcessExit += (_, _) =>
                    Console.Error.WriteLine($"JSON_ASCII_RUNS\t{_calls}\t{_searches}\t{_asciiBytes}\t{_otherScalars}");
            }

            internal static void Record(int searches, int asciiBytes, int otherScalars)
            {
                Interlocked.Increment(ref _calls);
                Interlocked.Add(ref _searches, searches);
                Interlocked.Add(ref _asciiBytes, asciiBytes);
                Interlocked.Add(ref _otherScalars, otherScalars);
            }
        }
"""
changes={
    '        internal static void AppendJsonString(':declaration+'\n        internal static void AppendJsonString(',
    '            var ordinaryAscii = ensureAscii ? JsonAsciiRun : JsonUtf8AsciiRun;':
        '            var ordinaryAscii = ensureAscii ? JsonAsciiRun : JsonUtf8AsciiRun;\n            int searches = 0, asciiBytes = 0, otherScalars = 0;',
    '                if (special < 0)':
        '                searches++;\n                asciiBytes += special < 0 ? checkpoint - position : special;\n                if (special < 0)',
    '                position += special;':
        '                position += special;\n                otherScalars++;',
    '            builder.Append(bytes[start..]);':
        '            JsonAsciiRunDiagnostic.Record(searches, asciiBytes, otherScalars);\n            builder.Append(bytes[start..]);',
}
for old,new in changes.items():
    assert source.count(old)==1
    source=source.replace(old,new)

try:
    entry.write_text(source,encoding='utf-8',newline='\n')
    patch=subprocess.check_output(['git','-c','core.safecrlf=false','diff','--binary','--',file],cwd=tree)
    (lab/'run-counts.patch').write_bytes(patch)
    build=lab/'route-build'
    subprocess.run([dotnet,'build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-incremental','--artifacts-path',build],
                   cwd=tree,env=env,check=True,stdout=subprocess.DEVNULL,timeout=80)
    image=lab/'route-image'
    image.mkdir(exist_ok=True)
    files=identity['imageFiles']['candidate'] | identity['helperFiles']
    for name,expected in files.items():
        assert digest(lab/'candidate'/name)==expected
        shutil.copyfile(lab/'candidate'/name,image/name)
    core='Lokad.Lython.dll'
    shutil.copyfile(build/'bin/Lokad.Lython/release_net11.0'/core,image/core)
    files[core]=digest(image/core)
    results={}
    for index,case in enumerate(catalog['cases']):
        incoming=lab/f'diagnostic-case-{index}.json'
        outgoing=lab/f'diagnostic-output-{index}.json'
        incoming.write_text(json.dumps(catalog|{'cases':[case]},ensure_ascii=False),encoding='utf-8',newline='\n')
        process=subprocess.run([dotnet,image/'ValidatedAllocation.dll',image,incoming,outgoing],
                               env=env,capture_output=True,encoding='utf-8',timeout=50)
        assert process.returncode==0,(process.stdout,process.stderr)
        proof,=json.loads(outgoing.read_text(encoding='utf-8'))['rows']
        assert proof['id']==case['id'] and proof['sharedBudgetBaselineRestored']
        if process.stderr:
            tag,*counts=process.stderr.strip().split('\t')
            assert tag=='JSON_ASCII_RUNS'
            outcomes=dict(zip(('calls','searches','asciiBytes','otherScalars'),map(int,counts),strict=True))
        else: outcomes={}
        results[case['id']]=outcomes
        print(case['id'],outcomes,flush=True)
    assert all(digest(image/name)==expected for name,expected in files.items())
    (lab/'run-counts.json').write_text(json.dumps(dict(source=identity['candidate'],imageFiles=files,cases=results),indent=2)+'\n',
                                      encoding='utf-8',newline='\n')
finally:
    subprocess.run(['git','restore','--',file],cwd=tree,check=True)
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=tree)
