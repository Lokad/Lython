from pathlib import Path
import gzip
import hashlib
import json
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.with_name('prepared-tuple-exit-20261124')
latest=lab.with_name('prepared-tuple-exit-refined-20261124')
core='Lokad.Lython.dll'
sha=lambda data:hashlib.sha256(data).hexdigest()

def emit(path, text):
    compile(text,str(path),'exec')
    path.write_text(text,encoding='utf-8',newline='\n')

def archive(path):
    return subprocess.check_output(['git','show','origin/master:benchmarks/results/'+path],cwd=repo)

prepare=(prior/'prepare.py').read_text(encoding='utf-8')
prepare=prepare.replace("lab.with_name('native-completed-call-workspace-20261124')","lab.with_name('prepared-tuple-exit-refined-20261124')")
prepare=prepare.replace("'b8c2aa8c8'","'ffa2f83f4'")
a=prepare.index("original=lab.with_name")
b=prepare.index("assert len(catalog['cases'])==5",a)
prepare=prepare[:a]+"""original=lab.with_name('json-scalar-windows-20261124')/'comparison'
representative=comparison/'representative.json'
catalog=read(original/'representative.json')
catalog['cases']=[case for case in catalog['cases'] if case['id'].startswith('scripts.json-lines-shipment.')]
controls=read(lab.with_name('prepared-tuple-exit-refined-20261124')/'comparison/representative.json')
control_ids={
    'diagnostic.text-summary.nonlocal-computed-width.large',
    'scripts.csv-invoice.method-policy.quoted-control',
}
catalog['cases'].extend(case for case in controls['cases'] if case['id'] in control_ids)
"""+prepare[b:]
prepare=prepare.replace('B1583 complete fixed tuple return during existing preparation',
                        'B1585 replace scalar JSON ASCII classifications with bounded byte runs')
emit(lab/'prepare.py',prepare)

stage=(prior/'stage.py').read_text(encoding='utf-8')
stage=stage.replace('b1583','b1585').replace('prepared-tuple-exit','json-ascii-runs')
emit(lab/'stage.py',stage)

parent='2026-11-24-prepared-tuple-exit'
root_b1583='prepared-tuple-exit-b1583-20261124'
root_b1584='prepared-tuple-exit-refined-b1584-20261124'
def core_copy(parent, role, aliases):
    source=f'{parent}/{role}-core.dll.gz'
    identity=sha(gzip.decompress(archive(source)))
    rows=[]
    for result, root, name in aliases:
        receipt=json.loads(archive(result+'/terminal-status.json'))['receipt']
        assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
        assert sha(archive(result+'/observations.tar.xz')) == receipt['archiveSHA256']
        assert json.loads(archive(result+'/identity.json'))['imageFiles'][name][core]==identity
        rows.append(dict(path=f'{root}/{name}/{core}',observationSHA256=receipt['archiveSHA256'],source=result))
    return dict(sha256=identity,coreArchive=source,aliases=rows)

replicas=[
    core_copy(parent+'/refinement','candidate',[(parent+'/refinement',root_b1584,'candidate')]),
    core_copy(parent,'reference',[(parent,root_b1583,'reference'),(parent+'/refinement',root_b1584,'reference')]),
]
(lab/'verified-replicas.json').write_text(json.dumps(replicas,indent=2)+'\n',encoding='utf-8',newline='\n')
