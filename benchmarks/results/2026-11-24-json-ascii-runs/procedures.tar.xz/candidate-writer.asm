; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+JsonModule:AppendJsonString(Lokad.Lython.Runtime.Text.GovernedByteBuilder,Lokad.Lython.Runtime.Text.PyString,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan) (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 14 inlinees with PGO data; 14 single block inlinees; 3 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 104
       xor      eax, eax
       mov      qword ptr [rsp+0x28], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x30], ymm4
       vmovdqa  xmmword ptr [rsp+0x50], xmm4
       mov      qword ptr [rsp+0x60], rax
       mov      rbx, rcx
       mov      rcx, rdx
       mov      edi, r8d
       mov      rsi, r9
       mov      rbp, gword ptr [rsp+0xD0]
 
G_M000_IG02:                ;; offset=0x0040
       lea      rdx, [rsp+0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      r14, bword ptr [rsp+0x58]
       mov      r15d, dword ptr [rsp+0x60]
       movzx    rdi, dil
       mov      rcx, 0x18DA30022A0
       mov      rdx, 0x18DA30022A8
       test     edi, edi
       mov      r13, gword ptr [rdx]
       cmovne   r13, gword ptr [rcx]
       mov      edx, dword ptr [rbx+0x28]
       cmp      edx, 0x7FFFFFFE
       jg       G_M000_IG38
       inc      edx
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], edx
       jge      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0092
       mov      rcx, rbx
       xor      r8, r8
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:Grow(int,System.Threading.CancellationToken):this]
 
G_M000_IG04:                ;; offset=0x009E
       mov      rcx, gword ptr [rbx+0x08]
       mov      eax, dword ptr [rbx+0x28]
       lea      edx, [rax+0x01]
       mov      dword ptr [rbx+0x28], edx
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG41
       mov      byte  ptr [rcx+rax+0x10], 34
       xor      r12d, r12d
       xor      eax, eax
       xor      edx, edx
       test     r15d, r15d
       je       G_M000_IG34
 
G_M000_IG05:                ;; offset=0x00C9
       mov      dword ptr [rsp+0x54], eax
       cmp      eax, edx
       jl       G_M000_IG10
 
G_M000_IG06:                ;; offset=0x00D5
       mov      rdx, gword ptr [rsi+0xA0]
       mov      gword ptr [rsp+0x20], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
       mov      rcx, gword ptr [rsp+0x20]
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG07:                ;; offset=0x00FE
       mov      eax, dword ptr [rsp+0x54]
       mov      edx, eax
       sub      edx, r12d
       mov      ecx, r12d
       mov      r8d, edx
       add      rcx, r8
       mov      r8d, r15d
       cmp      rcx, r8
       ja       G_M000_IG39
       mov      ecx, r12d
       add      rcx, r14
       mov      bword ptr [rsp+0x28], rcx
       mov      dword ptr [rsp+0x30], edx
       lea      rdx, [rsp+0x28]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:Append(System.ReadOnlySpan`1[byte]):this]
       mov      r12d, dword ptr [rsp+0x54]
       mov      eax, r12d
       mov      edx, r15d
       sub      edx, eax
       cmp      edx, 0x1000
       jl       SHORT G_M000_IG14
 
G_M000_IG08:                ;; offset=0x014E
       mov      r8d, 0x1000
 
G_M000_IG09:                ;; offset=0x0154
       lea      edx, [rax+r8]
       mov      r10d, edx
       mov      dword ptr [rsp+0x54], r12d
       mov      edx, r10d
       mov      r12d, eax
 
G_M000_IG10:                ;; offset=0x0166
       mov      dword ptr [rsp+0x50], edx
       mov      eax, dword ptr [rsp+0x54]
       mov      r10d, edx
       sub      r10d, eax
       mov      r8d, eax
       mov      ecx, r10d
       add      r8, rcx
       mov      ecx, r15d
       cmp      r8, rcx
       ja       G_M000_IG39
       mov      dword ptr [rsp+0x54], eax
       mov      ecx, eax
       add      rcx, r14
       mov      r8, 0x7FF9CCD48280
       cmp      qword ptr [r13], r8
       jne      SHORT G_M000_IG15
 
G_M000_IG11:                ;; offset=0x01A2
       lea      r8, bword ptr [r13+0x08]
       mov      edx, r10d
       call     [System.Buffers.IndexOfAnyAsciiSearcher:IndexOfAnyCore[int,System.Buffers.IndexOfAnyAsciiSearcher+Negate,System.Buffers.SearchValues+FalseConst,System.Buffers.IndexOfAnyAsciiSearcher+IndexOfAnyResultMapper`1[byte]](byref,int,byref):int]
 
G_M000_IG12:                ;; offset=0x01AF
       test     eax, eax
       jge      SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x01B3
       mov      edx, dword ptr [rsp+0x50]
       mov      ecx, edx
       jmp      G_M000_IG33
 
G_M000_IG14:                ;; offset=0x01BE
       mov      r8d, edx
       jmp      SHORT G_M000_IG09
 
G_M000_IG15:                ;; offset=0x01C3
       mov      bword ptr [rsp+0x28], rcx
       mov      dword ptr [rsp+0x30], r10d
       lea      rdx, [rsp+0x28]
       mov      rcx, r13
       mov      r8, qword ptr [r13]
       mov      r8, qword ptr [r8+0x40]
       call     [r8+0x38]System.Buffers.SearchValues`1[byte]:IndexOfAnyExcept(System.ReadOnlySpan`1[byte]):int:this
       jmp      SHORT G_M000_IG12
 
G_M000_IG16:                ;; offset=0x01E3
       mov      ecx, dword ptr [rsp+0x54]
       add      ecx, eax
       cmp      ecx, r15d
       jae      G_M000_IG41
       mov      edx, ecx
       movzx    rax, byte  ptr [r14+rdx]
       mov      dword ptr [rsp+0x40], 1
       cmp      eax, 128
       jl       SHORT G_M000_IG17
       cmp      ecx, r15d
       ja       G_M000_IG39
       mov      edx, ecx
       add      rdx, r14
       mov      dword ptr [rsp+0x54], ecx
       mov      r8d, r15d
       sub      r8d, ecx
       mov      bword ptr [rsp+0x28], rdx
       mov      dword ptr [rsp+0x30], r8d
       lea      rcx, [rsp+0x28]
       lea      rdx, [rsp+0x38]
       lea      r8, [rsp+0x40]
       call     [System.Text.Rune:DecodeFromUtf8(System.ReadOnlySpan`1[byte],byref,byref):int]
       test     eax, eax
       jne      G_M000_IG40
       mov      eax, dword ptr [rsp+0x38]
       mov      dword ptr [rsp+0x4C], eax
       test     edi, edi
       mov      eax, dword ptr [rsp+0x4C]
       mov      ecx, dword ptr [rsp+0x54]
       je       G_M000_IG32
 
G_M000_IG17:                ;; offset=0x025F
       mov      dword ptr [rsp+0x54], ecx
       mov      edx, ecx
       sub      edx, r12d
       mov      r8d, r12d
       mov      r10d, edx
       add      r8, r10
       mov      r10d, r15d
       cmp      r8, r10
       mov      dword ptr [rsp+0x4C], eax
       ja       G_M000_IG39
       mov      r8d, r12d
       add      r8, r14
       mov      bword ptr [rsp+0x28], r8
       mov      dword ptr [rsp+0x30], edx
       lea      rdx, [rsp+0x28]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:Append(System.ReadOnlySpan`1[byte]):this]
       mov      r12d, dword ptr [rsp+0x4C]
       lea      edx, [r12-0x08]
       cmp      edx, 5
       ja       SHORT G_M000_IG24
 
G_M000_IG18:                ;; offset=0x02AD
       mov      edx, edx
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rdx]
       lea      rax, G_M000_IG02
       add      rcx, rax
       jmp      rcx
 
G_M000_IG19:                ;; offset=0x02C5
       mov      rax, 0x1ADCC11C648
       mov      r8d, 2
       jmp      G_M000_IG28
 
G_M000_IG20:                ;; offset=0x02DA
       mov      rax, 0x1ADCC119E20
       mov      r8d, 2
       jmp      SHORT G_M000_IG28
 
G_M000_IG21:                ;; offset=0x02EC
       mov      rax, 0x1ADCC11C788
       mov      r8d, 2
       jmp      SHORT G_M000_IG28
 
G_M000_IG22:                ;; offset=0x02FE
       mov      rax, 0x1ADCC119D68
       mov      r8d, 2
       jmp      SHORT G_M000_IG28
 
G_M000_IG23:                ;; offset=0x0310
       mov      rax, 0x1ADCC11C9A0
       mov      r8d, 2
       jmp      SHORT G_M000_IG28
 
G_M000_IG24:                ;; offset=0x0322
       cmp      r12d, 34
       jne      SHORT G_M000_IG25
       mov      rax, 0x1ADCC119E40
       mov      r8d, 2
       jmp      SHORT G_M000_IG28
 
G_M000_IG25:                ;; offset=0x033A
       cmp      r12d, 92
       je       SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x0340
       xor      rax, rax
       xor      r8d, r8d
       jmp      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x0347
       mov      rax, 0x1ADCC11C8D0
       mov      r8d, 2
 
G_M000_IG28:                ;; offset=0x0357
       test     r8d, r8d
       jne      SHORT G_M000_IG30
       cmp      r12d, 0xFFFF
       jle      SHORT G_M000_IG29
       add      r12d, -0x10000
       mov      edx, r12d
       sar      edx, 10
       add      edx, 0xD800
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonModule:AppendJsonCodeUnit(Lokad.Lython.Runtime.Text.GovernedByteBuilder,int)]
       mov      edx, r12d
       and      edx, 0x3FF
       add      edx, 0xDC00
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonModule:AppendJsonCodeUnit(Lokad.Lython.Runtime.Text.GovernedByteBuilder,int)]
       jmp      SHORT G_M000_IG31
 
G_M000_IG29:                ;; offset=0x039B
       mov      rcx, rbx
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonModule:AppendJsonCodeUnit(Lokad.Lython.Runtime.Text.GovernedByteBuilder,int)]
       jmp      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x03A9
       mov      bword ptr [rsp+0x28], rax
       mov      dword ptr [rsp+0x30], r8d
       lea      rdx, [rsp+0x28]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:Append(System.ReadOnlySpan`1[byte]):this]
 
G_M000_IG31:                ;; offset=0x03C1
       mov      r12d, dword ptr [rsp+0x54]
       add      r12d, dword ptr [rsp+0x40]
       mov      eax, r12d
       mov      ecx, r12d
       mov      r12d, eax
       mov      edx, dword ptr [rsp+0x50]
       jmp      SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x03DA
       add      ecx, dword ptr [rsp+0x40]
       mov      edx, dword ptr [rsp+0x50]
 
G_M000_IG33:                ;; offset=0x03E2
       cmp      ecx, r15d
       mov      eax, ecx
       jl       G_M000_IG05
 
G_M000_IG34:                ;; offset=0x03ED
       cmp      r12d, r15d
       ja       G_M000_IG39
       mov      edx, r12d
       add      rdx, r14
       sub      r15d, r12d
       mov      bword ptr [rsp+0x28], rdx
       mov      dword ptr [rsp+0x30], r15d
       lea      rdx, [rsp+0x28]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:Append(System.ReadOnlySpan`1[byte]):this]
       mov      edx, dword ptr [rbx+0x28]
       cmp      edx, 0x7FFFFFFE
       jg       SHORT G_M000_IG38
       inc      edx
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], edx
       jge      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x042D
       mov      rcx, rbx
       xor      r8, r8
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:Grow(int,System.Threading.CancellationToken):this]
 
G_M000_IG36:                ;; offset=0x0439
       mov      rax, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rbx+0x28]
       lea      edx, [rcx+0x01]
       mov      dword ptr [rbx+0x28], edx
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG41
       mov      byte  ptr [rax+rcx+0x10], 34
 
G_M000_IG37:                ;; offset=0x0450
       add      rsp, 104
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG38:                ;; offset=0x0461
       mov      rdx, gword ptr [rbx+0x18]
       mov      rcx, 0x1ADC9A05AA0
       call     [Lokad.Lython.Runtime.RuntimeErrors:Runtime(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG39:                ;; offset=0x047E
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG40:                ;; offset=0x0485
       mov      rcx, 0x7FF9CCD51528
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rcx, r15
       mov      rdx, 0x1ADC9A07500
       call     [System.Text.DecoderFallbackException:.ctor(System.String):this]
       mov      rcx, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG41:                ;; offset=0x04B3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	000002D0h ; case G_M000_IG23
       	dd	000002BEh ; case G_M000_IG22
       	dd	000002ACh ; case G_M000_IG21
       	dd	00000300h ; case G_M000_IG26
       	dd	0000029Ah ; case G_M000_IG20
       	dd	00000285h ; case G_M000_IG19

; Total bytes of code 1209

