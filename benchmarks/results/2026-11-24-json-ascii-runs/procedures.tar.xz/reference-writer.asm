; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+JsonModule:AppendJsonString(Lokad.Lython.Runtime.Text.GovernedByteBuilder,Lokad.Lython.Runtime.Text.PyString,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan) (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; fully interruptible
; No PGO data
; 11 inlinees with PGO data; 10 single block inlinees; 3 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 104
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x30], ymm4
       vmovdqa  xmmword ptr [rsp+0x50], xmm4
       xor      eax, eax
       mov      qword ptr [rsp+0x60], rax
       mov      rbx, rcx
       mov      rcx, rdx
       mov      edi, r8d
       mov      rsi, r9
       mov      rbp, gword ptr [rsp+0xD0]
 
G_M000_IG02:                ;; offset=0x003B
       lea      rdx, [rsp+0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      r14, bword ptr [rsp+0x58]
       mov      r15d, dword ptr [rsp+0x60]
       mov      edx, dword ptr [rbx+0x28]
       cmp      edx, 0x7FFFFFFE
       jg       G_M000_IG35
       inc      edx
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], edx
       jge      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x006C
       mov      rcx, rbx
       xor      r8, r8
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:Grow(int,System.Threading.CancellationToken):this]
 
G_M000_IG04:                ;; offset=0x0078
       mov      rcx, gword ptr [rbx+0x08]
       mov      eax, dword ptr [rbx+0x28]
       lea      edx, [rax+0x01]
       mov      dword ptr [rbx+0x28], edx
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG38
       mov      byte  ptr [rcx+rax+0x10], 34
       xor      r13d, r13d
       xor      r12d, r12d
       xor      eax, eax
       test     r15d, r15d
       je       G_M000_IG31
 
G_M000_IG05:                ;; offset=0x00A4
       cmp      r12d, eax
       jl       G_M000_IG10
 
G_M000_IG06:                ;; offset=0x00AD
       mov      rax, gword ptr [rsi+0xA0]
       mov      gword ptr [rsp+0x28], rax
       cmp      byte  ptr [rax], al
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
       mov      rcx, gword ptr [rsp+0x28]
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG07:                ;; offset=0x00D6
       mov      edx, r12d
       sub      edx, r13d
       mov      ecx, r13d
       mov      eax, edx
       add      rcx, rax
       mov      eax, r15d
       cmp      rcx, rax
       ja       G_M000_IG36
       mov      ecx, r13d
       add      rcx, r14
       mov      bword ptr [rsp+0x30], rcx
       mov      dword ptr [rsp+0x38], edx
       lea      rdx, [rsp+0x30]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:Append(System.ReadOnlySpan`1[byte]):this]
       mov      r13d, r12d
       cmp      r13d, 0x7FFFEFFF
       jle      SHORT G_M000_IG08
       mov      eax, 0x7FFFFFFF
       jmp      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x0120
       lea      eax, [r13+0x1000]
 
G_M000_IG09:                ;; offset=0x0127
       mov      dword ptr [rsp+0x54], eax
       mov      eax, dword ptr [rsp+0x54]
 
G_M000_IG10:                ;; offset=0x012F
       cmp      r12d, r15d
       jae      G_M000_IG38
       mov      ecx, r12d
       movzx    r10, byte  ptr [r14+rcx]
       mov      dword ptr [rsp+0x48], 1
       cmp      r10d, 128
       jl       SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x0151
       cmp      r12d, r15d
       mov      dword ptr [rsp+0x54], eax
       ja       G_M000_IG36
       mov      ecx, r12d
       add      rcx, r14
       mov      edx, r15d
       sub      edx, r12d
       mov      bword ptr [rsp+0x30], rcx
       mov      dword ptr [rsp+0x38], edx
       lea      rcx, [rsp+0x30]
       lea      rdx, [rsp+0x40]
       lea      r8, [rsp+0x48]
       call     [System.Text.Rune:DecodeFromUtf8(System.ReadOnlySpan`1[byte],byref,byref):int]
       test     eax, eax
       jne      G_M000_IG37
       mov      r10d, dword ptr [rsp+0x40]
       mov      eax, r10d
       mov      r10d, eax
       mov      eax, dword ptr [rsp+0x54]
 
G_M000_IG12:                ;; offset=0x019F
       cmp      r10d, 32
       jl       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x01A5
       cmp      r10d, 34
       je       SHORT G_M000_IG14
       cmp      r10d, 92
       je       SHORT G_M000_IG14
       test     dil, dil
       je       G_M000_IG29
       mov      dword ptr [rsp+0x50], r10d
       cmp      r10d, 127
       mov      r10d, dword ptr [rsp+0x50]
       jl       G_M000_IG29
 
G_M000_IG14:                ;; offset=0x01CE
       mov      edx, r12d
       sub      edx, r13d
       mov      ecx, r13d
       mov      r8d, edx
       add      rcx, r8
       mov      r8d, r15d
       cmp      rcx, r8
       mov      dword ptr [rsp+0x50], r10d
       mov      dword ptr [rsp+0x54], eax
       ja       G_M000_IG36
       mov      ecx, r13d
       add      rcx, r14
       mov      bword ptr [rsp+0x30], rcx
       mov      dword ptr [rsp+0x38], edx
       lea      rdx, [rsp+0x30]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:Append(System.ReadOnlySpan`1[byte]):this]
       mov      r13d, dword ptr [rsp+0x50]
       lea      edx, [r13-0x08]
       cmp      edx, 5
       ja       SHORT G_M000_IG21
 
G_M000_IG15:                ;; offset=0x021D
       mov      edx, edx
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rdx]
       lea      rax, G_M000_IG02
       add      rcx, rax
       jmp      rcx
 
G_M000_IG16:                ;; offset=0x0235
       mov      rax, 0x2BECD00C538
       mov      r8d, 2
       jmp      G_M000_IG25
 
G_M000_IG17:                ;; offset=0x024A
       mov      rax, 0x2BECD009D10
       mov      r8d, 2
       jmp      SHORT G_M000_IG25
 
G_M000_IG18:                ;; offset=0x025C
       mov      rax, 0x2BECD00C678
       mov      r8d, 2
       jmp      SHORT G_M000_IG25
 
G_M000_IG19:                ;; offset=0x026E
       mov      rax, 0x2BECD009C58
       mov      r8d, 2
       jmp      SHORT G_M000_IG25
 
G_M000_IG20:                ;; offset=0x0280
       mov      rax, 0x2BECD00C890
       mov      r8d, 2
       jmp      SHORT G_M000_IG25
 
G_M000_IG21:                ;; offset=0x0292
       cmp      r13d, 34
       jne      SHORT G_M000_IG22
       mov      rax, 0x2BECD009D30
       mov      r8d, 2
       jmp      SHORT G_M000_IG25
 
G_M000_IG22:                ;; offset=0x02AA
       cmp      r13d, 92
       je       SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x02B0
       xor      rax, rax
       xor      r8d, r8d
       jmp      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x02B7
       mov      rax, 0x2BECD00C7C0
       mov      r8d, 2
 
G_M000_IG25:                ;; offset=0x02C7
       test     r8d, r8d
       jne      SHORT G_M000_IG27
       cmp      r13d, 0xFFFF
       jle      SHORT G_M000_IG26
       add      r13d, -0x10000
       mov      edx, r13d
       sar      edx, 10
       add      edx, 0xD800
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonModule:AppendJsonCodeUnit(Lokad.Lython.Runtime.Text.GovernedByteBuilder,int)]
       mov      edx, r13d
       and      edx, 0x3FF
       add      edx, 0xDC00
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonModule:AppendJsonCodeUnit(Lokad.Lython.Runtime.Text.GovernedByteBuilder,int)]
       jmp      SHORT G_M000_IG28
 
G_M000_IG26:                ;; offset=0x030B
       mov      rcx, rbx
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonModule:AppendJsonCodeUnit(Lokad.Lython.Runtime.Text.GovernedByteBuilder,int)]
       jmp      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x0319
       mov      bword ptr [rsp+0x30], rax
       mov      dword ptr [rsp+0x38], r8d
       lea      rdx, [rsp+0x30]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:Append(System.ReadOnlySpan`1[byte]):this]
 
G_M000_IG28:                ;; offset=0x0331
       add      r12d, dword ptr [rsp+0x48]
       mov      r13d, r12d
       mov      eax, dword ptr [rsp+0x54]
       jmp      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x033F
       add      r12d, dword ptr [rsp+0x48]
 
G_M000_IG30:                ;; offset=0x0344
       cmp      r12d, r15d
       jl       G_M000_IG05
 
G_M000_IG31:                ;; offset=0x034D
       cmp      r13d, r15d
       ja       G_M000_IG36
       mov      edx, r13d
       add      rdx, r14
       sub      r15d, r13d
       mov      bword ptr [rsp+0x30], rdx
       mov      dword ptr [rsp+0x38], r15d
       lea      rdx, [rsp+0x30]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:Append(System.ReadOnlySpan`1[byte]):this]
       mov      edx, dword ptr [rbx+0x28]
       cmp      edx, 0x7FFFFFFE
       jg       SHORT G_M000_IG35
       inc      edx
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], edx
       jge      SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x038D
       mov      rcx, rbx
       xor      r8, r8
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:Grow(int,System.Threading.CancellationToken):this]
 
G_M000_IG33:                ;; offset=0x0399
       mov      rcx, gword ptr [rbx+0x08]
       mov      eax, dword ptr [rbx+0x28]
       lea      edx, [rax+0x01]
       mov      dword ptr [rbx+0x28], edx
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG38
       mov      byte  ptr [rcx+rax+0x10], 34
 
G_M000_IG34:                ;; offset=0x03B0
       add      rsp, 104
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG35:                ;; offset=0x03C1
       mov      rdx, gword ptr [rbx+0x18]
       mov      rcx, 0x2BECA8F5AA0
       call     [Lokad.Lython.Runtime.RuntimeErrors:Runtime(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG36:                ;; offset=0x03DE
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG37:                ;; offset=0x03E5
       mov      rcx, 0x7FF9CCD41528
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2BECA8F7500
       call     [System.Text.DecoderFallbackException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG38:                ;; offset=0x0413
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000245h ; case G_M000_IG20
       	dd	00000233h ; case G_M000_IG19
       	dd	00000221h ; case G_M000_IG18
       	dd	00000275h ; case G_M000_IG23
       	dd	0000020Fh ; case G_M000_IG17
       	dd	000001FAh ; case G_M000_IG16

; Total bytes of code 1049

