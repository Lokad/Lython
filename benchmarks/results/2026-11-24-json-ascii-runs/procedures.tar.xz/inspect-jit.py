from pathlib import Path
import hashlib, json, os, re, subprocess

lab=Path(__file__).resolve().parent
identity=json.loads((lab/'comparison/identity.json').read_text(encoding='utf-8'))
dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent),
    DOTNET_TieredCompilation='0',DOTNET_JitDisasm='AppendJsonString')
rows=[]
for role, files in identity['imageFiles'].items():
    image=lab/role
    assert all(hashlib.sha256((image/name).read_bytes()).hexdigest()==expected for name,expected in (files|identity['helperFiles']).items())
    log=lab/(role+'-writer.asm')
    output=lab/(role+'-jit-verified.json')
    subprocess.run([dotnet,image/'ValidatedAllocation.dll',image,lab/'comparison/representative.json',output],
                   env=dict(env,DOTNET_JitStdOutFile=str(log)),timeout=100,check=True)
    assert all(row['sharedBudgetBaselineRestored'] for row in json.loads(output.read_text(encoding='utf-8'))['rows'])
    s=log.read_text(encoding='utf-8-sig')
    match,=re.findall(r'Total bytes of code (\d+)',s)
    calls=[line.strip() for line in s.splitlines() if 'call' in line and ('IndexOf' in line or 'DecodeFromUtf8' in line)]
    result=dict(role=role,coreSHA256=files['Lokad.Lython.dll'],emittedBytes=int(match),searchAndDecodeCalls=calls)
    print(result)
    rows.append(result)
(lab/'jit-summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
