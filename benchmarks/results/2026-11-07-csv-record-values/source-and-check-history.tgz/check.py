from pathlib import Path
root=Path(__file__).parent
previous=root.parent/'regex-program-artifacts-r23'
for name in ['build.py','focused.py']:
    s=(previous/name).read_text(encoding='utf-8')
    s=s.replace("families=['Regex','Fnmatch','Glob','GovernedMemory','StringPrimitive','PyStringPrimitive','StringCacheOwnership','SharedMemory']", "families=['Csv','RecordKey','GovernedMemory','SharedMemory']")
    (root/name).write_text(s,encoding='utf-8')
    exec(compile(s,str(root/name),'exec'),{'__file__':str(root/name)})
