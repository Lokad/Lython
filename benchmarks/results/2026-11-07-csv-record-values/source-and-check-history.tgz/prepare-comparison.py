from pathlib import Path
import ast,json,tarfile
home=Path(__file__).parent;previous=home.parent/'regex-program-artifacts-r23'
catalog=json.loads((previous/'comparison-catalog.json').read_text(encoding='utf-8'))
with tarfile.open('benchmarks/results/2026-11-05-private-csv-records/final/observations.tgz') as a:old=json.load(a.extractfile('catalog.json'))
cases={c['id']:c for c in catalog['cases']}
for c in old['cases']:
    if c['id'] in cases:
        for key in ['sourceSha256','fixtureSha256','expectedOutputSha256','expectedFilesSha256']:
            assert cases[c['id']].get(key)==c.get(key),(c['id'],key)
    else:catalog['cases'].append(c);cases[c['id']]=c
assert len(cases)==len(catalog['cases'])
(home/'comparison-catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
s=(previous/'prepare-comparison-expanded.py').read_text(encoding='utf-8')
s=s.replace("root=home/'b369'", "root=home/'b372'")
s=s.replace("old=home.parent/'invocation-definitions-r22/b368';prior='/home/lokad/lython-bench-checks/builtin-definitions-b368-20261106';remote='/home/lokad/lython-bench-checks/regex-programs-b369-20261106'", "old=home.parent/'regex-program-artifacts-r23/b369';prior='/home/lokad/lython-bench-checks/regex-programs-b369-20261106';remote='/home/lokad/lython-bench-checks/csv-record-values-b372-20261107'")
s=s.replace("home/'focused-updated.json'", "home/'focused-refined.json'")
s=s.replace("sourceRevision='41c25958 plus R23 compiled provider-program lifetime migration'", "sourceRevision='a48caba2/ec134e8c runtime plus R25 completed CSV record-value adoption'")
s=s.replace("referenceSourceRevision='41c25958 source, frozen B368 a87cd017; all baseline production source hashes identical'", "referenceSourceRevision='ec134e8c runtime, frozen B36923a0a257; all baseline production source hashes identical'")
s=s.replace('R23 program lifetime reuse: extraction warm/fresh, text warm and unaffected JSON compilation; not a CPython refresh','R25 direct completed-record values: ordinary/native CSV, public reader, text and JSON compile controls; not a CPython refresh')
before='R23 borrows validated immutable provider programs from the funded compiled-script owner; per-run names, wrappers, module identity, purge, tokens and cleanup remain independent. Larger retained compilation baseline and earlier denial are deliberate tradeoffs.'
s=s.replace(before,'R25 transfers funded complete CSV row arrays into canonical dictionaries under shared native keys, validates exact header identities after shell admission and keeps conservative row headroom. No parser fusion, extra owner, replacement array, per-field publication or refund/re-reserve of live storage on that path.')
s=s.replace('Four complete jobs: regex extraction warm/fresh, text warm, JSON compilation control.', 'Five complete jobs: native CSV, ordinary CSV, public reader, text and JSON compilation control.')
s=s.replace("ownerSeconds=150,stopSeconds=30,observeAfterSeconds=180", "ownerSeconds=150,stopSeconds=30,observeAfterSeconds=190")
s=s.replace('no SSH before180s', 'no SSH before190s')
start=s.index("for name in ['collect.py'");end=s.index("shutil.copyfile(home/'comparison-catalog.json'",start)
s=s[:start]+'''for name in ['collect.py','archive-owned.py','run.sh']:
    content=(old/name).read_text(encoding='utf-8').replace(prior,remote)
    before="jobs=[('scripts.regex-capture-summary.large','warm'),('scripts.regex-capture-summary.large','compile-run'),('scripts.text-summary-helpers.large','warm'),('scripts.json-summary-helpers.large','compile')]"
    after="jobs=[('scripts.csv-summary-helpers.large','warm'),('scripts.csv-summary-functions.large','warm'),('scripts.csv-summary-reader.large','warm'),('scripts.text-summary-helpers.large','warm'),('scripts.json-summary-helpers.large','compile')]"
    content=content.replace(before,after).replace('len(jobs)==4','len(jobs)==5').replace("len(r['jobs'])==4","len(r['jobs'])==5").replace('jobs=4','jobs=5')
    content=content.replace('R23 program lifetime reuse: extraction warm/fresh, text warm and unaffected JSON compilation; not a CPython refresh',identity['purpose'])
    write(name,content)
'''+s[end:]
s=s.replace("status['receipt']['jobs']==4", "status['receipt']['jobs']==5")
s=s.replace("['scripts.regex-capture-summary.large','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large']", "['scripts.csv-summary-helpers.large','scripts.csv-summary-functions.large','scripts.csv-summary-reader.large','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large']")
s=s.replace('allFourCatalogJobsValidated','allFiveCatalogJobsValidated')
s=s.replace('lython-b369-regex-programs-20261106','lython-b372-csv-record-values-20261107').replace('b369-launch.py','b372-launch.py')
ast.parse(s);(home/'prepare-comparison-expanded.py').write_text(s,encoding='utf-8')
exec(compile(s,str(home/'prepare-comparison-expanded.py'),'exec'))
