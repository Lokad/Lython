from pathlib import Path
import hashlib,json,os,re,subprocess,sys
root=Path(__file__).parent;env=os.environ.copy()
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
families=['Csv','RecordKey','GovernedMemory','SharedMemory']
selection='Category!=Stress&('+'|'.join('FullyQualifiedName~'+name for name in families)+')';checks={}
for tfm in ['net11.0','net10.0']:
    for suite in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
        key=suite+'-'+tfm;log=root/('focused-initial-'+key+'.log');assert not log.exists()
        cmd=[env['DOTNET_HOST_PATH'],'test',f'tests/{suite}/{suite}.csproj','-c','Release','-f',tfm,'--no-build','--no-restore','--nologo','--tl:off','--filter',selection]
        with log.open('w',encoding='utf-8') as out:p=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT)
        content=log.read_text(encoding='utf-8');print(key,p.returncode,content[-2000:],flush=True)
        checks[key]={'exitCode':p.returncode,'summaries':re.findall(r'(?:Passed!|Failed!)\s+[^\r\n]+',content)}
        (root/'focused-initial.json').write_text(json.dumps({'checks':checks,'selection':selection},indent=2)+'\n',encoding='utf-8')
        if p.returncode:sys.exit(p.returncode)
result={'checks':checks,'selection':selection,'coreSHA256':{tfm:hashlib.sha256(Path(f'src/Lokad.Lython/bin/Release/{tfm}/Lokad.Lython.dll').read_bytes()).hexdigest() for tfm in ['net11.0','net10.0']}}
(root/'focused-initial.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')

