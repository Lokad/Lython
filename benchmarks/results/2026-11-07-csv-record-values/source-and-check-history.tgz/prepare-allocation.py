from pathlib import Path
root=Path(__file__).parent
s=(root.parent/'invocation-definitions-r22/measure-allocation.py').read_text(encoding='utf-8')
s=s.replace("root/'focused-results.json'", "root/'focused-refined.json'")
s=s.replace("json.loads((root/'baseline.json').read_text())['net11.0']", "json.loads((root/'baseline.json').read_text())['coreSHA256']['net11.0']")
(root/'measure-allocation.py').write_text(s,encoding='utf-8')
exec(compile(s,str(root/'measure-allocation.py'),'exec'),{'__file__':str(root/'measure-allocation.py'),'__name__':'__main__'})
