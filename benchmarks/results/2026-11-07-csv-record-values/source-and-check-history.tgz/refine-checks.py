from pathlib import Path
import os,subprocess
root=Path(__file__).parent
design=(root/'design.md').read_text(encoding='utf-8');(root/'design-initial.md').write_text(design,encoding='utf-8')
design=design.replace('so32+8n extra headroom is conservatively retained until clear/disposal.', 'so32+8n extra headroom is conservatively retained with the capacity, including\n+clear; execution-owner disposal returns it.')
design=design.replace('full clear returns all nonshell funding.', 'clear retains backing and funding; execution disposal returns all funding.')
design+='\nInitial focused check corrected a source-gate/test assumption: dictionary Clear retains backing capacity; the nearby ClearSetStorage path relinquishes it only for sets. Preserve the original failed less-than assertion; use exact balance equality and empty contents to enforce live-capacity funding. No production refund/clear behavior changed.\n'
(root/'design.md').write_text(design,encoding='utf-8')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
with (root/'build-refined-tests.log').open('w',encoding='utf-8') as output:
    p=subprocess.run([env['DOTNET_HOST_PATH'],'build','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','--no-restore','--nologo','--tl:off'],env=env,stdout=output,stderr=subprocess.STDOUT)
if p.returncode:raise SystemExit(p.returncode)
s=(root/'focused.py').read_text(encoding='utf-8-sig').replace('focused-initial','focused-refined')
(root/'focused-refined.py').write_text(s,encoding='utf-8')
exec(compile(s,str(root/'focused-refined.py'),'exec'),{'__file__':str(root/'focused-refined.py')})
