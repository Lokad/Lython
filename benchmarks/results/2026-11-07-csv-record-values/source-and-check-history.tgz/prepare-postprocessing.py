from pathlib import Path
import ast
root=Path(__file__).parent;previous=root.parent/'regex-program-artifacts-r23'
s=(previous/'retrieve-comparison.py').read_text(encoding='utf-8-sig')
s=s.replace('regex-programs-b369-20261106','csv-record-values-b372-20261107').replace('lython-b369-regex-programs-20261106','lython-b372-csv-record-values-20261107').replace('b369','b372').replace("['jobs']==4","['jobs']==5")
ast.parse(s);(root/'retrieve-comparison.py').write_text(s,encoding='utf-8')
s=(root.parent/'text-operands-r21/summarize-comparison.py').read_text(encoding='utf-8')
s=s[:s.index('a=json.loads')].replace('b366/retrieved/confirmation','b372/retrieved/confirmation')
ast.parse(s);(root/'summarize-comparison.py').write_text(s,encoding='utf-8')
