from pathlib import Path
import json,shutil
root=Path(__file__).parent;prior=root.parent/'regex-program-artifacts-r23'
ci=json.loads((prior/'delivery-ci-fifth.json').read_text(encoding='utf-8-sig'))
assert ci['status']=='completed' and ci['conclusion']=='success' and ci['headSha']=='ec134e8cc539edfbbda4b4b362c8e9bfe3250ecf'
names={'Test Release (.NET 11)','Test Release (.NET 10 checkpoint)','Verify Release package consumer','Test original stress scales'}
assert len(ci['jobs'])==2
for j in ci['jobs']:
    assert j['conclusion']=='success' and {s['name'] for s in j['steps'] if s['conclusion']=='success'}>=names
out=Path('benchmarks/results/2026-11-06-regex-program-reuse')
(out/'delivery-ci.json').write_text(json.dumps(ci,indent=2)+'\n',encoding='utf-8')
p=out/'README.md';s=p.read_text(encoding='utf-8');s=s.replace('Full Windows/Ubuntu/\noriginal Stress delivery remains separate and pending.', 'Full delivery42316074240 on ec134e8c is terminal GREEN: all eight Windows/Ubuntu\nactual11/10/original Stress/installed-package gates verified in\n[delivery-ci.json](delivery-ci.json). Later CSV prototypes are separately qualified.')
p.write_text(s,encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');s=s.replace('Combined delivery42316074240 started2026-11-07~00:05UTC;\n  Windows/Ubuntu actual11/10/original Stress/package qualification is running.\n  Do not duplicate local full/stress checks; query minutes apart and keep working.', 'Fully qualified GREEN42316074240/all eight platform/runtime/original Stress/\n  installed-package gates, cached in regex-program-reuse/delivery-ci.json. Terminal;\n  never query that run again. Later CSV prototype is not covered by this receipt.')
s=s.replace('is running above. Keep working while CI runs.', 'is terminal GREEN above. Continue independent work.')
s=s.replace('diagnostic is running. No timing/delivery claim yet.', 'diagnostic passes both APIs/all goldens/balances/isolation: CSV allocation\n−7.31/−6.55%, admitted peak3,737,138→3,671,314B. Five-job B372 source pair\n(native/ordinary CSV, public reader, text and JSON compilation) is running,150s\nowner+30sstop with observation after190s from00:31:32UTC. No SSH before00:34:50.\nNo timing/delivery claim yet.')
p.write_text(s,encoding='utf-8')
print('Verified all eight R23 delivery gates; cached terminal outcome, no further queries.')
