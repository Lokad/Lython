from pathlib import Path
import json,statistics
root=Path(__file__).parent;rows=[]
for api in ['sync','async']:
    data=json.loads((root/'allocation'/api/'measurements.json').read_text(encoding='utf-8'))
    assert all(data[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
    for case in data['observations']:
        med={role:statistics.median(s['allocatedBytes']/s['jobs'] for s in case['samples'] if s['image']==role) for role in ['before','candidate','before-control']}
        row=dict(api=api,case=case['caseId'],allocatedBytesPerJob=med,candidateChangePercent=100*(med['candidate']/med['before']-1),admittedPeaks=case['admittedPeaks']);rows.append(row)
        if 'csv-' in row['case']:print(json.dumps(row),flush=True)
(root/'allocation-summary.json').write_text(json.dumps(dict(rows=rows,allSemanticAndBalanceGatesPassed=True,limitations='Complete-job process allocation includes reset/background work. Desktop clocks are diagnostic. Retained capacity estimates remain conservative, not heap/RSS measurements.'),indent=2)+'\n',encoding='utf-8')
