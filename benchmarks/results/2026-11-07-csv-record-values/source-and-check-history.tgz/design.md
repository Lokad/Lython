# R25 — completed CSV values adoption, source/ownership gate

Baseline a48caba2 evidence / ec134e8c runtime, actual production hashes match
B369/R24 frozen23a0a257. No prototype or speed claim yet. Source gate complete:
DictReader still fills an independent values array from its already-funded row;
public reader adoption alone did not eliminate that work. R20's canonical split
storage now permits actual values-array transfer without a second mapping backend.

Selected invariant: existing RecordKeys owner is the current execution governor,
row.Length == layout.Count == native headers.Count, and every header object is
ReferenceEquals to the corresponding stored PyString key. This preserves Python
key identity, not just equality. Missing/excess/duplicate/replaced/non-string
headers retain the existing builder/protocol path. Exact array values are nonnull
CSV guest values; the parser already guarantees exclusive final-array transfer.

Check that invariant before admission to avoid admitting a known mismatch;
reserve dictionary shell before allocation, check cancellation/terminal refusal,
then revalidate headers after admission hooks can mutate/reenter. Failed ordinary
revalidation returns through existing semantics, never recovery after refusal.
No guest callback or admission is needed between final proof and construction.

Construct the ordinary shared-key PyDict over this array, with count/sequence
initialized consistently. Stop private-row finally-release only after actual
transfer. Keep its original conservative funded capacity in _nativeCommittedBytes
along with admitted shell: list estimate64+80n versus canonical values32+72n,
so32+8n extra headroom is conservatively retained with the capacity, including
clear; execution-owner disposal returns it. Do not
refund/re-reserve live storage or introduce a transfer ledger/refcount/owner.

Existing NativeExtent is min(layout.Count, values.Length), so exact shorter-than-
rounded capacity is representable. EnsureRecordValueCapacity and private-key
replacement already account for actual values capacity; test mutation/delete/
clear/copy/new-key growth and independent rows. Replacement may retain that small
headroom difference conservatively; clear retains backing and funding; execution disposal returns all funding.

Displaced ordinary work: new object?[] values, field-by-field SetRecordItem writes
and their publication bookkeeping, followed by private row retirement. One
canonical dictionary remains; first/new/mismatched layouts still use required
general construction. No parse-time fusion, new policies/allowances/configuration,
parser callbacks/backend, global cache or dormant variants.

Implementation map: PyDict.Records RecordKeys direct adopted construction; one
CsvDictReader transfer branch and finally handoff. Keep all Python pull/line_num/
header/restfield order and genuine async I/O before it. Validate existing focused
CSV/record/cancellation/refusal/lifetime tests and add independent behavior gaps,
especially admission-hook header mutation and retained rows through cleanup.

Then existing short whole-job allocation driver and one bounded ordinary/native
CSV + public-reader source pair, with unaffected text/JSON controls, same owner/
hash/golden/funding/quiet/joins/archive gates and normal runtime. Document resident
and regression debt; do not predict a CPU fraction, silently revive old thresholds
or call an isolated result completion of the larger performance objective.

Initial focused check corrected a source-gate/test assumption: dictionary Clear retains backing capacity; the nearby ClearSetStorage path relinquishes it only for sets. Preserve the original failed less-than assertion; use exact balance equality and empty contents to enforce live-capacity funding. No production refund/clear behavior changed.
