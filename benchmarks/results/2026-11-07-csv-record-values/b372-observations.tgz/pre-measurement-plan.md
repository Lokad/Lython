# Lokad.Lython 0.11.0

Updated2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
A single experiment, allocation saving or delivery checkpoint does not finish it.

## Delivery status

- Committed/pushed41c25958: R22 canonical builtin metadata initialization.
  Fully qualified GREEN42310347889: all eight Windows/Ubuntu actual.NET11/10,
  original Stress and installed-package gates. Cached terminal receipt in
  benchmarks/results/2026-11-06-builtin-initialization/delivery-ci.json; never
  query that completed run again. Earlier completed delivery remains in evidence.
- R23 committed/pushedec134e8c: validated regex programs belong to the
  existing compiled owner; exact runtime requests borrow them. Release0warnings,
  focused95internal/497public plus cached-cancellation control per actual target;
  complete4274internal/16205public per actual11/10 pass. Explicit installed Release
  consumers pass both. Combined delivery42316074240 started2026-11-07~00:05UTC;
  Windows/Ubuntu actual11/10/original Stress/package qualification is running.
  Do not duplicate local full/stress checks; query minutes apart and keep working.
- Primary CPython guide measures4fad63c5/B367, not later HEAD. Source-pair R22/R23
  results are separate. Unresolved: warm-text gap/possible R20 debt, coarse adverse
  CSV CPU, startup/suspended-I/O/RSS/embedding-tail impact and final adapter release.

Current guides are in docs/; historical evidence is outside it under
benchmarks/results/, indexed by benchmarks/EXPERIMENTS.md. Older full plans and
source investigations: .git/agent-notes/review-20261031/, including R23's
PLAN-before-checkpoint-condense.md and the immutable source-pair premeasurement plan.
Do not repeat completed qualification merely to refresh its date.

## Completed work and measurement decisions

Preserve shared compiler facts/correction, direct UTF8 formatting/storage, native
helper returns, final call/local slots, native functions, executable imports/
lambdas, genuine suspension and the K01/F02–F05/Q01/Q02/R02–R14 milestones.
Native-return allocation−19.92/−19.31% is established; elapsed remains diagnostic.
Formatting allocation−8.67% is established; controlledB102 elapsed/CPU−5–8%
supports retention. Original adverse15.125ms remains unexplained and preserved.
These are completed questions, not current-HEAD speed claims.

- R20 canonical record keys/independent values removes coupled entries, the sorted
  JSON hint/comparer/matched flags and set value storage. Full-job allocation
  CSV−12.73/−11.57%, JSON~−15%, report~−9.43%; quiet B361 JSON warm−10.9–12.5%,
  report warm−5.4–8.8%/fresh−8.5–10.5%. CSV elapsed modest, CPU adverse. B362 text
  remains−1.21% to+5.53% across blocks: **possible text regression is accepted
  debt**, not parity. Fully delivered; every adverse/failure condition preserved.
- R21 removes per-instruction pending-error/return polling at actual resumption
  boundaries, preserving all guards/cleanup/spans. Allocation flat; B366 warm
  text−3.00–5.59%, fresh almost flat, unchanged compile also improves. Fully
  delivered; no general CPU gain or proof of closed R20 debt.
- R22 prepares fixed builtin definitions/signatures once, preserves private type/
  exception/namespace state and current module identities. Factory−2,688B/run;
  whole scripts usually under0.2% allocation savings, large config~1.17%.
  B36888s: config warm−1.13–2.44%, fresh−1.43% to+0.13%; text role spread4.10%.
  Retained lifetime simplification, not a broad CPU result. Fully delivered above.
- U04 replaces provider match carriers/arrays with caller spans and retained
  ranges; direct cursor allocation−20.34%, extraction warm−3.62–5.17%/fresh
  −4.58–6.40%. Fully delivered, separate from R23. Core stays provider-independent.

B367 primary comparison, all15jobs/312s: fresh CSV1.25–1.26x,text1.77–1.79x,
JSON1.08–1.11x,report1.50–1.53x,config1.21–1.22x CPython; warm1.31–1.32/
1.88–1.90/1.08–1.09/1.32–1.37/1.28–1.29x. Compile44–73us separate.
JSON/report role variation remains explicit. Includes mediated RAM I/O, full
validation and prior-result cleanup; excludes startup/staging/final teardown.
Do not subtract independent medians to infer I/O/cleanup costs. Refresh again
at a material non-regex delivery milestone, not after every local change.

## Priority1 — deliver R23, continue the non-regex roadmap

R23 removes duplicate frontend/runtime provider compilation for identical native
requests, even compile-once/run-once. Only immutable programs cross executions;
Python wrappers, cache/purge identities and mutable group-name caches stay run-
owned. Invalid compilation/standalone/import analysis closes immediately; borrowed
programs are never put on run disposal lists. Native keys preserve exact normalized
flags/verbose protocols and active-token hash checkpoints. Dynamic misses compile
normally. No global cache, new budget, tracing or refcount layer.

Verified probe3compiles/3disposals→1compile retained through two runs, then1close/
root0 at script disposal. Compiled baseline39,397→105,481B is explicit longer-
retention/earlier-denial cost. Await all runs before script disposal. Initial name
sharing was corrected before timing because lazy guest caches could otherwise
use the compile governor concurrently. Original failures/probe image-selection
mistake and package's old disposal assertion are retained, not discarded evidence.

B369 completes88.55s/all gates. Extraction warm−8.34–9.64%, compile-to-result
−6.47–6.53%; current spreads1.43/0.07%. Text control−0.99/−3.74%/2.78%spread,
unchanged compilation−1.66/−0.18%; precise causal CPU gain is not established.
Retain useful duplicate-work elimination and elapsed evidence with documented
resident cost. Evidence benchmarks/results/2026-11-06-regex-program-reuse/.
Source/tests/docs/evidence committed; one full platform/Stress/package delivery
is running above. Keep working while CI runs. No producer publication dependency.

**R24 next: choose a substantial non-regex redesign from current complete-script
costs.** R19 profiling predates record layout and R21 prefix changes; its20.64%
text prefix includes useful inlined work, not removable dispatch. Ordinary calls/
binding were under2%, report JSON~11.9%; do not replay call arenas or predict a
speedup from those shares. The limited later diagnostic lacks full provenance.
An initial bounded current text/report profile through the existing worker/perf
tooling is justified by the delivered changes: roughly3s guest capture per case,
normal runtime, active-thread/maps/goldens/funding/quiet/joins/persistent archive
gates. No new profiling framework or broad benchmark campaign. Preserve unknowns
and failures; allow a specifically justified bounded correction when needed.
R24 gate complete: B371~5guestCPU seconds/546text+451report samples. Calls~2%,
text prefix21%including useful inlining, report JSON~10%; no new arena/scalar
justification or predicted speedup. B370 export failure and B371 prelaunch path
error remain preserved. Observer retrieval was slightly short of strict proof of
the180s conservative delay, after actual archive/join at00:13:34; no claim that
full observation bound was met. Evidence benchmarks/results/2026-11-07-current-script-cpu/.

| Design candidate | Eliminated work / affected scripts | Acceptance and displaced implementation |
| --- | --- | --- |
| Complete call/frame/operand construction | Existing final slots, borrowed ordinary args and native returns already remove major packaging. Select further unification only if current CPU/storage demonstrates a distinct cost in text/helpers/report. | One executable route, evaluation/binding/default/keyword order, closures/generators/classes, actual suspension, original spans and funded operands. Remove displaced storage/routes; no second backend or guard-fusion tweak series. |
| Scalar/operand convention | Boxed BigInteger counters/aggregation are real; current causation is incomplete. R16's45 direct-type assumptions show migration cost. | A single exact-promotion, identity/type/hash/protocol/projection convention and coherent completion milestone; no isolated second integer path. Decide remaining regression debt after full affected scripts/ordinary controls. |
| Record construction | R20 shares actual key metadata; current CSV already scans bulk, transfers rows and avoids list copies. Earlier6–8% bulk-record proposal missed rigid thresholds, but its duplicated work is now mostly gone. | Preserve mutable headers/rows, key order/protocols, hooks, independent values, reentrant mutation and cancellation/refusal before publication. Reopen only for distinct remaining eliminated work, not automatic promotion or a permanent threshold ban. |
| Text and JSON final storage | Case mapping already writes native UTF8; plain JSON tokens avoid backend reparsing. General windows add8B/object and measured slower; current split fragments still own payloads. | Require a different storage/copy model, Unicode/context/offset semantics, original-subject alias funding, replacement overlap and current cancellation. Remove displaced conversions/representations; no dormant variants. |
| Shared frontend facts | Lexical facts/precedence consolidation delivered; compile costs matter for fresh config, but are small in larger scripts. | Reuse actual facts, preserve diagnostics/scoping/nesting/cancellation, remove a duplicate walk/representation with measured compile-to-result controls. No general compiler rewrite without dominant-cost evidence. |

R24 stopping criterion: select and write one coherent eliminated-work model with
semantic acceptance and a bounded before/after script comparison, then implement
to its explicit completion point and decide remaining debt. A useful source gate
does not finish the objective. If dominant cost is unresolved, retain uncertainty
and identify the smallest missing observation; do not manufacture a tiny rescue.
Keep slower B61/B69 call-arena/control, operand-read and shared-window lessons.

**R25 active prototype — adopt completed CSV record values.**
Public csv.reader already adopts its row; DictReader still allocates a separate
dictionary values array and fills every field from the private funded row. R20's
shared keys enable a distinct whole-record storage transfer for unchanged unique
native headers, not the previously rejected bulk-copy implementation. Remove the
extra values allocation/copy/per-field publication in that ordinary case; keep
the canonical dictionary and existing dynamic header/protocol path. No parse-time
fusion, new backend, ownership layer, refcount, pool or configuration.

Before prototype, prove the exact native header/layout/row-length invariant and
preflight shell storage, then revalidate mutable headers after admission callbacks.
Keep the row's original conservative funding through transfer; end private-row
release only after successful dictionary ownership. Never refund/re-reserve still-
retained storage. Existing capacity estimates may conservatively retain a small
headroom difference; identical tiny thresholds are not required. On a normal
shape mismatch use existing semantics; admission refusal remains terminal.

Acceptance: independent row values/retained aliases; mutation/delete/clear/copy/
growth with actual short values capacity; duplicate/non-string/mutable headers,
missing/excess fields/restkey/defaults, lazy pulls/EOF/errors/line numbers;
shared-reader reentry and admission-hook header mutation; current cancellation,
refusal-before-publication and awaited cleanup/root reuse through both APIs.
First write a focused failure where needed, then migrate one ownership path and
remove displaced common-case construction. Source-level transfer proof precedes
any timing claim. Existing short whole-job allocation driver plus one bounded
CSV ordinary/native/reader comparison with unaffected text/JSON controls; no
new framework. Decide retain/revise/debt at that coherent point and continue
the still-open text/performance roadmap. Further confirmation is evidence-led.
Prototype passes Release solution build0warnings/errors. Initial focused123pass/
2fail: the two new clear tests incorrectly expected a refund although ordinary
dictionary clear retains capacity. Correct the test/source-gate assumption to
require unchanged funding and empty contents; no production clear/refund change.
Admission-header mutation, cancellation and refusal controls pass. Refined focused
125internal/389public per actual11/10 pass; short existing whole-job allocation
diagnostic is running. No timing/delivery claim yet. Baseline a48caba2
source/ec134e8c runtime frozen under csv-record-values-r25/.

## Independent regex track

Continue Lython-owned Python semantics/native UTF8/byte ranges/scalar windows,
explicit ownership and current cancellation without waiting for a release.
Normal adapter remains pinned0.4/nonpackable; no backend types/dependencies enter
core. Private immutable dev46 compatibility (source6957b35a) passed85internal/
482public per actual target, same U04 bridge as44; evidence
benchmarks/results/2026-11-06-regex-dev46-compatibility/. No production promotion.

Only final affected adapter qualification waits for released producer capabilities:
DetailedData lacks independent Prepare working owner (keep conservative preflight);
native names cannot be enumerated (adapter-local conversion remains); native
cursors combine creation/per-operation tokens (qualified synthetic CTS bridge
already provides current-token semantics; removal is a simplification opportunity).
Normal0.4 reversed windows fail explicitly. Dev producers/adapter-local bridges
support independent implementation/tests; qualify final immutable package and
managed-safety compliance separately. No sibling edits, dialect fallback or quotas.

## Working and measurement contract

Unstable unchanged controls, timeouts and inconclusive observations establish
uncertainty, not a failed design. Allow bounded confirmation/refinement/measurement
correction when evidence justifies it. Retain original conditions and adverse
results. Percentages inform decisions, not automatic vetoes/permanent closures.
Separate architecture, allocation, elapsed and demonstrated CPU; accept temporary
debt only with an explicit completion milestone and remaining-regression decision.

Follow AGENTS.md: fully managed/memory-safe, no unsafe/Unsafe/pointers/PInvoke/
native stack probing. Preserve managed stack/recursion, host mediation/contained
paths, cycles, host cancellation, shared allowance/capacity/replacement/escaping
aliases and awaited cleanup. First admission refusal fails the command, no retry.
No fuel/quotas/hidden caps/default allowance/tracing/weak reclamation/forced GC.
Initial streaming uses bounded host executions; XML depth constraint remains.

Focused Release iteration, no overlapping local builds/tests. Nonincremental build
after timestamp-preserving restores. Batch actual11/10/Windows/Ubuntu/original
Stress/installed consumers at coherent boundaries; never repeat terminal CI
queries. Quiet VM lokad@20.166.121.73,key~/.ssh/id_lython-bench.pem: exclusive owned
lease, actual Ready images, honest controls/quiet/goldens/funding/joins and verified
persistent archives. No SSH before owner+stop bound. Disk near full: retire only
exact redundant copies after independent backup/user/dependency checks. Publication
and tagging remain postponed; continue after individual experiments/delivery.
