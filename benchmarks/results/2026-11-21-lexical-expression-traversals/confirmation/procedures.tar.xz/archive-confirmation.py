from pathlib import Path
import hashlib, json, shutil, tarfile
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
run=lab/"confirmation"
out=repo/"benchmarks/results/2026-11-21-lexical-expression-traversals/confirmation"
load=lambda p: json.loads(p.read_text(encoding="utf-8"))
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
receipt=load(run/"archive-receipt.json")
terminal=load(run/"terminal-status.json")
summary=load(run/"quiet-summary.json")
assert receipt["jobs"]==2 and receipt==terminal["receipt"] and terminal["exitCode"]=="0"
assert all(receipt[k] for k in ("complete","allWorkersJoined","quietBeforeAndAfter",
                               "guestFixturesRemoved","archivedAndVerifiedUnderLease"))
assert sha(run/"observations.tgz")==receipt["archiveSHA256"]
assert load(run/"identity.json")["imageFiles"]==load(lab/"quiet/identity.json")["imageFiles"]==load(lab/"identity.json")["imageFiles"]
assert len(summary["rows"])==2 and summary["staging"]["retiredOnly"]==[]
out.mkdir(exist_ok=False)
for name in ("observations.tgz","archive-receipt.json","terminal-status.json"):
    shutil.copyfile(run/name,out/name)
summary.pop("retentionDecisionPending",None)
(out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
with tarfile.open(out/"procedures.tar.xz","w:xz") as dst:
    for name in ("prepare-confirmation.py","launch-confirmation.py","summarize-confirmation.py",
                 "archive-confirmation.py"):
        dst.add(lab/name,arcname=name)
    for name in ("config.json","identity.json","collect.py","archive-owned.py","run.sh",
                 "retrieve.py","remote-launch.py","launch.log","observe-not-before.json"):
        dst.add(run/name,arcname="confirmation/"+name)
print("Archived B1264 exact-image control confirmation")
