#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/d/code/Lython
cd "$repo/.git/agent-worktrees/skip-inert-lexical-expressions"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs="$repo/.git/agent-notes/review-20261031/skip-inert-lexical-expressions"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Annotation|FullyQualifiedName~Scope|FullyQualifiedName~Comprehension|FullyQualifiedName~Super|FullyQualifiedName~ClassCell|FullyQualifiedName~NamedExpression|FullyQualifiedName~Walrus|FullyQualifiedName~MatchPattern|FullyQualifiedName~ModernTyping|FullyQualifiedName~StaticNameBinding)&Category!=Stress' -v quiet 2>&1 | tee "$logs/public-ubuntu.log"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Parser|FullyQualifiedName~Lexical|FullyQualifiedName~Frontend|FullyQualifiedName~Static|FullyQualifiedName~Semantic|FullyQualifiedName~Compilation)&Category!=Stress' -v quiet 2>&1 | tee "$logs/white-ubuntu.log"
