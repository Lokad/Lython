set -eu
root=/home/lokad/lython-bench-checks/skip-inert-lexical-expressions-b1263-20261121
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
