from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
cases={
    'sparse-key-order': """def repeat(seed):
    def inner(*, a=seed, required, z=9): return a, required, z
    return inner
first, second = repeat(2), repeat(5)
try: first()
except TypeError: print('required')
print(first(required=3), second(required=7))
saved = first.__kwdefaults__
print(list(saved), saved is first.__kwdefaults__)
del saved['a']
saved['a'] = 11
print(first(required=13), second(required=17), list(saved))
""",
    'unobserved-replacement': """kept = []
def f(*, value=kept): return value
print(f() is kept)
f.__kwdefaults__ = {'value': ['replacement']}
print(f(), kept)
""",
    'observed-replacement': """kept = []
def f(*, value=kept): return value
saved = f.__kwdefaults__
f.__kwdefaults__ = None
try: f()
except TypeError: print('missing')
print(saved['value'] is kept)
f.__kwdefaults__ = saved
print(f() is kept, f.__kwdefaults__ is saved)
""",
    'decorator-observation': """seen = []
def decorate(f):
    seen.append(f.__kwdefaults__)
    f.__kwdefaults__['key'] = 3
    return f
@decorate
def f(*, key=1): return key
print(f(), f.__kwdefaults__ is seen[0])
""",
    'decorator-replacement': """def decorate(f):
    f.__kwdefaults__ = {'key': 3}
    return f
@decorate
def f(*, key=1): return key
print(f(), list(f.__kwdefaults__))
""",
    'generator-defaults': """def f(*, a=1, z=2):
    yield a+z
values = f()
f.__kwdefaults__['a'] = 9
print(next(values), next(f()))
""",
}
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
probe=lab.parent/'lexical-annotation-boundary/probe-build/bin/LythonProbe/release_net11.0'
pair=load(lab/'frozen-identity.json')
body=json.dumps(list(cases.values())).encode('utf-8')
(lab/'probe-cases.json').write_bytes(body)
for role,files in pair['images'].items():
    source=lab/'frozen'/role
    assert len(files)==32 and {n:sha(source/n) for n in files}==files
    image=lab/'probe'/role
    shutil.copytree(probe,image,dirs_exist_ok=True)
    for file in image.glob('Lokad.*.dll'):
        if file.name in files:
            shutil.copyfile(source/file.name,file)
            assert sha(file)==files[file.name]
    assert sha(image/'Lokad.Lython.dll')==files['Lokad.Lython.dll']
    for async_mode in (False,True):
        args=[sdk/'dotnet.exe',image/'LythonProbe.dll','--batch-json','--compare-python','--python','C:/Python313/python.exe']
        if async_mode:args.append('--async')
        process=subprocess.run(args,input=body,capture_output=True,timeout=55,env=env)
        (lab/f'probe-{role}-{async_mode}.jsonl').write_bytes(process.stdout)
        assert process.returncode==0,(role,async_mode,process.stderr.decode(),process.stdout.decode())
        reports=[json.loads(line) for line in process.stdout.splitlines()]
        assert len(reports)==len(cases) and all(row['Matches'] and row['Compared'] for row in reports)
print(f'{len(cases)} CPython semantic probes pass in sync and async modes for both source images.')
