using Lokad.Lython.Frontend;
using System.Collections;
using Lokad.Lython.Runtime.Text;
using System.Text.RegularExpressions;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private static PyDict ExecuteExecutableMakeDict(ref ExecutableValueStack stack, int pairCount, LythonSourceSpan span, ExecutionContext context)
    {
        var valueCount = checked(pairCount * 2);
        if (valueCount < 0 || stack.Count < valueCount)
        {
            throw RuntimeErrors.Runtime("executable stack underflow", span);
        }

        var start = stack.Count - valueCount;
        var dict = new PyDict(context.MemoryGovernor, span);
        using var _ambientScope = PyStructuralGuard.PushAmbient(context, span);
        for (var i = 0; i < valueCount; i += 2)
        {
            var key = ValidateDictionaryKey(stack[start + i], span);
            dict.SetItem(key, stack[start + i + 1]);
        }

        stack.RemoveTail(valueCount);

        context.CheckExecution(span);
        return dict;
    }

    private static PySet ExecuteExecutableMakeSet(ref ExecutableValueStack stack, int count, LythonSourceSpan span, ExecutionContext context)
    {
        if (count < 0 || stack.Count < count)
        {
            throw RuntimeErrors.Runtime("executable stack underflow", span);
        }

        var start = stack.Count - count;
        var set = new PySet(context.MemoryGovernor, span);
        using var _ambientScope = PyStructuralGuard.PushAmbient(context, span);
        try
        {
            for (var i = start; i < stack.Count; i++)
            {
                set.Add(ValidateSetItem(stack[i], span));
            }

            stack.RemoveTail(count);

            context.CheckExecution(span);
        }
        catch
        {
            set.ReleaseUnpublishedStorage();
            throw;
        }
        return set;
    }

    private static IPyContextManager PopContextManager(ref ExecutableValueStack stack, LythonSourceSpan span)
    {
        var value = Pop(ref stack, span);
        if (value is IPyContextManager manager)
        {
            return manager;
        }

        throw RuntimeErrors.Type("'" + RuntimeErrors.OperandTypeName(value) + "' object does not support the context manager protocol", span);
    }

    private static object ExecuteExecutableSlice(ref ExecutableValueStack stack, ExecutableSliceParts parts, LythonSourceSpan span, ExecutionContext context)
    {
        var (start, end, step) = ReadExecutableSliceBounds(in stack, parts, out var first);
        var target = stack[first - 1];
        return ReadSliceValue(target, start, end, step, span, context);
    }

    private static (object? Start, object? End, object? Step) ReadExecutableSliceBounds(in ExecutableValueStack stack, ExecutableSliceParts parts, out int first)
    {
        first = stack.Count;
        var step = (parts & ExecutableSliceParts.Step) != 0 ? stack[--first] : null;
        var end = (parts & ExecutableSliceParts.End) != 0 ? stack[--first] : null;
        var start = (parts & ExecutableSliceParts.Start) != 0 ? stack[--first] : null;
        return (start, end, step);
    }

    private static (object? Start, object? End, object? Step) PopExecutableSliceBounds(ref ExecutableValueStack stack, ExecutableSliceParts parts, LythonSourceSpan span)
    {
        var bounds = ReadExecutableSliceBounds(in stack, parts, out var first);
        while (stack.Count != first) _ = Pop(ref stack, span);
        return bounds;
    }

    private static bool CanCacheRuntimeMemberTarget(object target)
        => target is not IPyContextualDynamicAttributes &&
           target is (PyString
               or PyBytes
               or PyList
               or PyTuple
               or PyDict
               or PySet
               or PyDecimal
               or PyDate
               or PyTime
               or PyDateTime
               or PyTimedelta
               or PyTimezone
               or RePatternObject
               or ReMatchObject
               or PyPath
               or PyModule
               or HashlibHashObject
               or StatisticsModule.PyNormalDist
               or PyDeque
               or PkgutilLoaderObject
               or PyDirEntryObject);

    // Only immediate calls may reuse a bound callable: an ordinary attribute
    // read must preserve the identity of the freshly resolved method object.
    // Instances, types, super objects and functions keep mutable lookup rules:
    // user-level rebinding, deletion and descriptors resolve anew on every access.
    private static bool CanCacheRuntimeMemberValue(object target, object value, bool isCallTarget = false)
        => (isCallTarget || value is not ICallable) &&
           (CanCacheRuntimeMemberTarget(target) ||
           (value is ICallable &&
            target is not PyInstance &&
            target is not PyType &&
            target is not PySuper &&
            target is not PyFunctionBase &&
            target is not IPyContextualDynamicAttributes));

    private static object Pop(ref ExecutableValueStack stack, LythonSourceSpan span)
    {
        if (stack.Count == 0)
        {
            throw RuntimeErrors.Runtime("executable stack underflow", span);
        }

        return stack.Pop();
    }

    private static object Peek(ref ExecutableValueStack stack, LythonSourceSpan span)
    {
        if (stack.Count == 0)
        {
            throw RuntimeErrors.Runtime("executable stack underflow", span);
        }

        return stack.Peek();
    }

    private static PyList CreateListFromStack(ref ExecutableValueStack stack, int count, LythonSourceSpan span, ExecutionContext context)
    {
        if (count < 0 || stack.Count < count)
        {
            throw RuntimeErrors.Runtime("executable stack underflow", span);
        }

        var start = stack.Count - count;
        using var preflight6491 = context.MemoryGovernor.ReserveTemporary(EstimateObjectArrayBytes(count), span);
        var items = new object[count];
        for (var i = 0; i < count; i++)
        {
            items[i] = stack[start + i];
        }

        stack.RemoveTail(count);
        var list = new PyList(items, context.MemoryGovernor, span);
        return list;
    }

    private static PyTuple CreateTupleFromStack(ref ExecutableValueStack stack, int count, LythonSourceSpan span, ExecutionContext context)
    {
        if (count < 0 || stack.Count < count)
        {
            throw RuntimeErrors.Runtime("executable stack underflow", span);
        }

        if (count == 0) return PyTuple.Empty;

        var start = stack.Count - count;
        using var preflight7249 = context.MemoryGovernor.ReserveTemporary(PyTuple.EstimateApproximateBytes(count), span);
        var items = new object[count];
        for (var i = 0; i < count; i++)
        {
            items[i] = stack[start + i];
        }

        stack.RemoveTail(count);
        var tuple = new PyTuple(items, context.MemoryGovernor, span);
        return tuple;
    }

    private static object EvaluateExecutableUnary(ExecutableUnaryOperator op, object operand, ExecutionContext context, LythonSourceSpan span)
        => EvaluateUnaryOperator(MapExecutableUnary(op), operand, context, span);

    private static UnaryOperatorSyntax MapExecutableUnary(ExecutableUnaryOperator op)
        => op switch
        {
            ExecutableUnaryOperator.Not => UnaryOperatorSyntax.Not,
            ExecutableUnaryOperator.Plus => UnaryOperatorSyntax.Plus,
            ExecutableUnaryOperator.Minus => UnaryOperatorSyntax.Minus,
            ExecutableUnaryOperator.BitwiseNot => UnaryOperatorSyntax.BitwiseNot,
            _ => throw new InvalidOperationException($"Executable IR contains unknown unary operator {op}."),
        };

    private static object EvaluateExecutableAugmented(ExecutableAugmentedOperator op, object currentValue, object right, ExecutionContext context, LythonSourceSpan span)
        => EvaluateAugmentedAssignment(currentValue, right, MapExecutableAugmented(op), context, span);

    private static AugmentedAssignmentOperatorSyntax MapExecutableAugmented(ExecutableAugmentedOperator op)
        => op switch
            {
                ExecutableAugmentedOperator.Add => AugmentedAssignmentOperatorSyntax.Add,
                ExecutableAugmentedOperator.Subtract => AugmentedAssignmentOperatorSyntax.Subtract,
                ExecutableAugmentedOperator.Multiply => AugmentedAssignmentOperatorSyntax.Multiply,
                ExecutableAugmentedOperator.MatrixMultiply => AugmentedAssignmentOperatorSyntax.MatrixMultiply,
                ExecutableAugmentedOperator.Divide => AugmentedAssignmentOperatorSyntax.Divide,
                ExecutableAugmentedOperator.FloorDivide => AugmentedAssignmentOperatorSyntax.FloorDivide,
                ExecutableAugmentedOperator.Modulo => AugmentedAssignmentOperatorSyntax.Modulo,
                ExecutableAugmentedOperator.Power => AugmentedAssignmentOperatorSyntax.Power,
                ExecutableAugmentedOperator.BitwiseOr => AugmentedAssignmentOperatorSyntax.BitwiseOr,
                ExecutableAugmentedOperator.BitwiseXor => AugmentedAssignmentOperatorSyntax.BitwiseXor,
                ExecutableAugmentedOperator.BitwiseAnd => AugmentedAssignmentOperatorSyntax.BitwiseAnd,
                ExecutableAugmentedOperator.LeftShift => AugmentedAssignmentOperatorSyntax.LeftShift,
                ExecutableAugmentedOperator.RightShift => AugmentedAssignmentOperatorSyntax.RightShift,
                _ => throw new InvalidOperationException($"Executable IR contains unknown augmented operator {op}."),
            };
}
