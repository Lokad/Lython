from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
sdk = Path.home()/'.dotnet11'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ['PATH'])
source=["def parts(text):return text.rstrip('\\n').split(',')\nprint(parts('café,😀\\n'), parts('\\n'), parts('tail'))", "x=('é'*36).rstrip('\\n');print(x.rstrip('\\n').split(',')[0] is x)", "print('f:é😀::\\n'.rstrip('\\n').split('::'),'a😀b😀\\n'.rstrip('\\n').split('😀'))", "text='start,tail\\r\\n';print(text.rstrip('\\n').split(','))", "a,b='x,y\\n'.rstrip('\\n').split(',');print(a,b)", "def run(text):\n a,b=text.rstrip('\\n').split(',')\n return a,b\nfor text in ['a,b\\n','a\\n','a,b,c\\n']:\n try:print(run(text))\n except ValueError as e:print(type(e).__name__,str(e))", "def strip(text,chars):return text.rstrip(chars).split(',')\nprint(strip('a,bé','é'),strip('a,b\\n',''),strip('a,b  ',None))", "class Receiver:\n def rstrip(self,chars):\n  print('trim',chars=='\\n')\n  return 'a,b'\nprint(Receiver().rstrip('\\n').split(','))", "events=[]\ndef chars():events.append(1);return '\\n'\ndef sep():events.append(2);return ','\nprint('a,b\\n'.rstrip(chars()).split(sep()),events)", "try: print('a,b\\n'.rstrip('\\n').split(''))\nexcept ValueError as e: print(str(e))", "text='é,漢字,😀\\n';print([x for x in text.rstrip('\\n').split(',')]);print(text)", "text='a,b\\x00';print(text.rstrip('\\x00').split(','))", "def f(text):return text.upper().split()\nprint(f('alpha café'))", "def f(text):return text.rstrip('\\n').split(',')\nfirst=f(('é'*32)+',tail\\n'); second=f('x,y\\n');first.append('last');print(first[0][-2:],first[1:],second)"]
(lab/'probes.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
inputs = (lab/'probes.json').read_bytes()
driver = Path('tools/LythonProbe/bin/Release/net11.0')
identity = json.loads((lab/'frozen-identity.json').read_text(encoding='utf-8'))['images']
work = lab/'probe'
work.mkdir(exist_ok=True)
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def all_hashes(path):
    return {entry.name:digest(entry) for entry in path.iterdir() if entry.is_file()}
matches=[]
for role in ('reference','candidate'):
    image = work/role
    image.mkdir(exist_ok=True)
    for entry in driver.iterdir():
        if entry.is_file() and entry.suffix != '.pdb': shutil.copyfile(entry,image/entry.name)
    for name in ['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']:
        shutil.copyfile(lab/'frozen'/role/name, image/name)
        assert digest(image/name)==identity[role][name]
common=all_hashes(work/'reference')
assert common | {'Lokad.Lython.dll':identity['candidate']['Lokad.Lython.dll']} == all_hashes(work/'candidate')
for mode in ('sync','async'):
    results=[]
    for role in ('reference','candidate'):
        args=[sdk/'dotnet.exe',work/role/'LythonProbe.dll','--batch-json']+(['--async'] if mode=='async' else [])
        completed=subprocess.run(args,env=env,input=inputs,capture_output=True,timeout=60)
        (lab/f'probe-{role}-{mode}.jsonl').write_bytes(completed.stdout)
        (lab/f'probe-{role}-{mode}.stderr').write_bytes(completed.stderr)
        records=[json.loads(line) for line in completed.stdout.decode('utf-8-sig').splitlines()]
        assert len(records)==len(source), (role, mode, completed.returncode, completed.stderr)
        semantics=('Success','StandardOutput','StandardError','ExitCode','Diagnostics','Failure')
        results.append([{key:record['Lython'][key] for key in semantics} for record in records])
    assert results[0]==results[1], [i for i,pair in enumerate(zip(*results)) if pair[0]!=pair[1]]
    matches.append(dict(mode=mode, matching=len(source)))
(lab/'probe-summary.json').write_text(json.dumps(dict(results=matches, referenceImage=common),indent=2)+'\n',encoding='utf-8',newline='\n')
print(matches)
