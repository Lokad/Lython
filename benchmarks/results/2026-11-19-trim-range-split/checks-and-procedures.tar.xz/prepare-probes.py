from pathlib import Path
import ast
lab=Path(__file__).resolve().parent
template=(lab.parent/'standalone-capture-prefix-r675/compare-probes.py').read_text(encoding='utf-8-sig')
a,b=template.index('source = ['),template.index("(lab/'probes.json')")
cases=[
 "def parts(text):return text.rstrip('\\n').split(',')\nprint(parts('café,😀\\n'), parts('\\n'), parts('tail'))",
 "x=('é'*36).rstrip('\\n');print(x.rstrip('\\n').split(',')[0] is x)",
 "print('f:é😀::\\n'.rstrip('\\n').split('::'),'a😀b😀\\n'.rstrip('\\n').split('😀'))",
 "text='start,tail\\r\\n';print(text.rstrip('\\n').split(','))",
 "a,b='x,y\\n'.rstrip('\\n').split(',');print(a,b)",
 "def run(text):\n a,b=text.rstrip('\\n').split(',')\n return a,b\nfor text in ['a,b\\n','a\\n','a,b,c\\n']:\n try:print(run(text))\n except ValueError as e:print(type(e).__name__,str(e))",
 "def strip(text,chars):return text.rstrip(chars).split(',')\nprint(strip('a,bé','é'),strip('a,b\\n',''),strip('a,b  ',None))",
 "class Receiver:\n def rstrip(self,chars):\n  print('trim',chars=='\\n')\n  return 'a,b'\nprint(Receiver().rstrip('\\n').split(','))",
 "events=[]\ndef chars():events.append(1);return '\\n'\ndef sep():events.append(2);return ','\nprint('a,b\\n'.rstrip(chars()).split(sep()),events)",
 "try: print('a,b\\n'.rstrip('\\n').split(''))\nexcept ValueError as e: print(str(e))",
 "text='é,漢字,😀\\n';print([x for x in text.rstrip('\\n').split(',')]);print(text)",
 "text='a,b\\x00';print(text.rstrip('\\x00').split(','))",
 "def f(text):return text.upper().split()\nprint(f('alpha café'))",
 "def f(text):return text.rstrip('\\n').split(',')\nfirst=f(('é'*32)+',tail\\n'); second=f('x,y\\n');first.append('last');print(first[0][-2:],first[1:],second)",
]
template=template[:a]+'source='+repr(cases)+'\n'+template[b:]
template=template.replace("results.append([record['Lython'] for record in records])",
 "semantics=('Success','StandardOutput','StandardError','ExitCode','Diagnostics','Failure')\n        results.append([{key:record['Lython'][key] for key in semantics} for record in records])")
ast.parse(template)
(lab/'compare-probes.py').write_text(template,encoding='utf-8',newline='\n')
