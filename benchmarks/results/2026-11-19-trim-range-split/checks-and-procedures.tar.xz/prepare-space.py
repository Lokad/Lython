from pathlib import Path
import ast

lab=Path(__file__).resolve().parent
prior=lab.parent/'standalone-capture-prefix-r675'
source=(prior/'prove-quiet-space.py').read_text(encoding='utf-8-sig')
start,end=source.index('pairs=['),source.index('records=[]')
source=source[:start]+"""pairs=[
    ('standalone-capture-prefix-r675','2026-11-19-standalone-capture-prefix','reference','reference-core.dll.gz'),
    ('split-range-reuse-r655','2026-11-19-fixed-split-ranges','candidate','measured-core.dll.gz'),
    ('combined-operand-preparation-r638','2026-11-19-combined-operand-preparation','candidate','measured-core.dll.gz'),
]
"""+source[end:]
source=source.replace('for folder, evidence in pairs:','for folder, evidence, role, image in pairs:')
source=source.replace("local+'/measured-core.dll.gz'","local+'/'+image").replace("recorded('measured-core.dll.gz')","recorded(image)")
source=source.replace("['cores']['candidate']","['cores'][role]").replace("+'/candidate/Lokad.Lython.dll'","+'/'+role+'/Lokad.Lython.dll'")
ast.parse(source)
(lab/'prove-quiet-space.py').write_text(source,encoding='utf-8',newline='\n')
