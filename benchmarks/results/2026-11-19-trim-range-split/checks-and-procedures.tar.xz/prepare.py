from pathlib import Path
import ast
import json

lab=Path(__file__).resolve().parent
previous=lab.parent/'standalone-capture-prefix-r675'
read=lambda p:p.read_text(encoding='utf-8-sig')
load=lambda p:json.loads(read(p))
def write(name,data):
    if name.endswith('.py'):
        ast.parse(data)
    (lab/name).write_text(data,encoding='utf-8',newline='\n')

catalog=load(lab.parent/'retained-defaults-cpython-b1102/representative.json')
wanted={'scripts.rule-default-closures','scripts.report-forwarding.inline-dynamic-keys',
        'scripts.report-forwarding.expanded','scripts.csv-invoice.large'}
catalog['cases']=[c for c in catalog['cases'] if c['id'] in wanted]
extra=load(lab.parent/'split-range-reuse-r655/catalog.json')
case=next(c for c in extra['cases'] if 'normalization' in c['id'] or 'normalize' in c['id'])
catalog['cases'].append(case)
assert len(catalog['cases'])==5
write('catalog.json',json.dumps(catalog,indent=2,ensure_ascii=False)+'\n')
source=read(previous/'freeze-and-verify.py')
source=source.replace("'token-source-cpython-b1106'","'standalone-capture-prefix-r675'")
source=source.replace('standalone-capture-prefix-r675\'\nload','standalone-capture-prefix-r675\'\nload')
source=source.replace("trial=repo/'.git/agent-worktrees/standalone-capture-prefix-r675'",
                      "trial=repo/'.git/agent-worktrees/trim-range-split-r676'")
source=source.replace("'2166c7295'","'9407f4fb7'").replace("'34072680e'","'70b05f5cc'")
source=source.replace("manifest=load(previous/'identity.json')","manifest=load(previous/'frozen-identity.json')")
source=source.replace("assert manifest['sourceRevision'].startswith('27f68744b')","assert manifest['candidateCommit']==ref")
source=source.replace("files=manifest['imageFiles']['candidate']","files=manifest['images']['candidate']")
source=source.replace("if name==core:\n            build = 'build-win' if role=='candidate' else 'build-reference'\n            origin=lab/build/'bin/Lokad.Lython/release_net11.0'/name",
                      "if role=='candidate' and name==core:\n            origin=lab/'build-win/bin/Lokad.Lython/release_net11.0'/name")
source=source.replace('== 6','== 5').replace('all six','all five')
assert "old_selector=lab.parent/'native-format-selectors-r615'" in source
assert "previous=lab.parent/'standalone-capture-prefix-r675'" in source
assert "role=='candidate' and name==core" in source
write('freeze-and-verify.py',source)

stage=read(previous/'stage-quiet.py')
stage=stage.replace('"token-source-cpython-b1106"','"standalone-capture-prefix-r675" / "quiet"')
stage=stage.replace('R675 standalone captured locals in deferred invocations','R676 split a private right-trimmed UTF-8 range')
stage=stage.replace('standalone-capture-prefix-b1107','trim-range-split-b1108')
stage=stage.replace('b1107-standalone-capture-prefix','b1108-trim-range-split').replace('b1107-fixtures','b1108-fixtures')
stage=stage.replace('Standalone capture prefix source pair','Trimmed UTF-8 range source pair')
stage=stage.replace('for role in ("reference", "candidate"):','for role in ("candidate",):')
stage=stage.replace('"reference/" + core, "candidate/" + core]','"candidate/" + core]')
stage=stage.replace("assert sha(quiet / 'reference' / core) == images['reference'][core]",'assert source_files == images["reference"]')
stage=stage.replace('six-case, seven-job','five-case, six-job')
stage=stage.replace('==7','==6').replace('jobs=7,','jobs=6,').replace('398','347')
stage=stage.replace('}) == 6','}) == 5')
jobs=[('scripts.report-forwarding.expanded','warm'),('scripts.report-forwarding.inline-dynamic-keys','warm'),
      ('scripts.report-forwarding.expanded','compile-run'),(case['id'],'warm'),
      ('scripts.csv-invoice.large','warm'),('scripts.rule-default-closures','warm')]
a,b=stage.index('        jobs = '),stage.index('        source=source[:a]')
stage=stage[:a]+"        jobs = "+repr(jobs)+"\n"+stage[b:]
write('stage-quiet.py',stage)
print([c['id'] for c in catalog['cases']])
