from pathlib import Path
import gzip
import hashlib
import json
import shutil
import statistics
import subprocess
import tarfile
import sys

lab=Path(__file__).resolve().parent
read=lambda path:path.read_text(encoding='utf-8-sig')
previous=read(lab.parent/'keyword-copy-path-r662/archive-r662.py')
prefix=previous[:previous.index('initial = verify(')]
prefix=prefix.replace('2026-11-19-keyword-copy-path','2026-11-19-trim-range-split')
a=prefix.index('    independently_retained = ')
b=prefix.index('\ncases = ')
prefix=prefix[:a]+'    assert not changed(candidate, retained, "src", "tests")\n'+prefix[b:]
exec(compile(prefix,__file__,'exec'))

summary=verify('quiet',6,'quiet-summary.json')
summary['referenceDeliveredSource']='70b05f5cc'
assert not subprocess.check_output(['git','diff','--name-only',base,summary['referenceDeliveredSource'],'--','src','tests'])
summary['warmAllocation']=[]
before,after=(load(lab/f'{role}-allocation.json')['rows'] for role in ('reference','candidate'))
for left,right in zip(before,after,strict=True):
    assert left['id']==right['id'] and left['sharedBudgetBaselineRestored'] and right['sharedBudgetBaselineRestored']
    a,b=(statistics.median(row['allocatedBytesPerInvocation']) for row in (left,right))
    summary['warmAllocation'].append(dict(case=left['id'],allocatedBytes=[a,b],allocatedChangePercent=100*(b/a-1),
        accountedPeak=[left['peakExecutionMemoryBytes'],right['peakExecutionMemoryBytes']]))
out.mkdir(exist_ok=False)
save(out/'summary.json',summary)
quiet=lab/'quiet'
for name in ('observations.tgz','archive-receipt.json','terminal-status.json'):
    shutil.copyfile(quiet/name,out/name)
for role,target in [('candidate','measured-core.dll.gz')]:
    core=lab/'frozen'/role/'Lokad.Lython.dll'
    assert digest(core)==images[role][core.name]
    (out/target).write_bytes(gzip.compress(core.read_bytes(),mtime=0))
with tarfile.open(out/'checks-and-procedures.tar.xz','w:xz',preset=6) as evidence:
    for name in ('config.json','identity.json','representative.json','remote-launch.py','retrieve.py',
                 'observe-not-before.json','launch.log','collect.py','archive-owned.py','run.sh'):
        evidence.add(quiet/name,arcname='quiet/'+name)
    for name in ('prepare.py','prepare-space.py','stage-quiet.py','launch-quiet.py','summarize-quiet.py',
                 'quiet-space.json','prove-quiet-space.py','preflight.json','archive.py','freeze-and-verify.py',
                 'frozen-identity.json','catalog.json','reference-verify.json','candidate-verify.json',
                 'reference-allocation.json','candidate-allocation.json','local-pair.log','measured-source.patch',
                 'frozen-win-net11-build.log','win-whitebox.log','win-public.log','initial-win-public.log','initial-ubuntu-net10.log',
                 'ubuntu-net10.log','retrieval.log','prepare-probes.py','compare-probes.py','probes.json','probe-summary.json',
                 'probe-reference-sync.jsonl','probe-reference-async.jsonl','probe-candidate-sync.jsonl','probe-candidate-async.jsonl'):
        evidence.add(lab/name,arcname=name)
print('Verified 120 batches, both exact worker images and the verified VM archive.')


