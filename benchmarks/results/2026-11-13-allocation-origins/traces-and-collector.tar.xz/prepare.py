from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).parent;image=r/'image';image.mkdir(exist_ok=True)
source=r.parent/'zip-positional-r319/candidate'
for p in source.iterdir():
 if p.is_file():shutil.copyfile(p,image/p.name)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(image/'Lokad.Lython.dll')=='97bbeff306c9c5123454614493be668f0cf0290b8f9cae4acd1eb726b952d2e5'
shutil.copyfile(r.parent/'next-profile-r321/catalog.json',r/'catalog.json')
reader=r/'reader';reader.mkdir(exist_ok=True);shutil.copyfile(r.parent/'activation-storage-b170/Diagnostics.csproj',reader/'Diagnostics.csproj')
(r/'identity.json').write_text(json.dumps(dict(source='Qualified976f9439/frozen97bb; Windows local allocation attribution, not VM CPU/timing comparison',files={p.name:sha(p)for p in image.iterdir()if p.is_file()},catalogSHA256=sha(r/'catalog.json')),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');needle='   Each selected milestone names the hypothesis,';assert needle in s
s=s.replace(needle,'''   **R323 next source gate:** reuse the existing EventPipe/offline stack reader for
   one short warmed allocation capture per captured-text/search shape on qualified
   97bb. Local allocation attribution needs no VM elapsed claim. Stop with actual
   constructor/call/frame/operand/storage origins or a precise unresolved boundary;
   allocation ticks are sampled triggers, not exact per-type bytes or CPU shares.
   No tracing/collector machinery enters production. A new redesign must eliminate
   a demonstrated substantial representation/pass; do not manufacture a second
   dictionary, tagged-value scheme or another arena from owning-frame percentages.
'''+needle)
p.write_text(s,encoding='utf-8',newline='\n');print('Frozen local allocation image and2existing scripts; no production changes')
