from pathlib import Path
import shutil
r=Path(__file__).parent;(r/'confirmed-readiness').mkdir();shutil.copyfile(r/'reader/Diagnostics.csproj',r/'collector/Diagnostics.csproj')
s=(r/'collect.py').read_text(encoding='utf-8').replace("fixture=r/'fixtures'","fixture=r/'confirmed-readiness/fixtures'").replace("folder=r/label","folder=r/'confirmed-readiness'/label")
needle=" for label,case_id,count in ["
pos=s.index(needle)
s=s[:pos]+''' with(r/'collector-build.log').open('w',encoding='utf-8',newline='\\n')as f:done=subprocess.run([sdk,'build',str(r/'collector/Diagnostics.csproj'),'-c','Release','--nologo'],env=env,stdout=f,stderr=subprocess.STDOUT)
 assert done.returncode==0,(r/'collector-build.log').read_text(encoding='utf-8')[-2500:]
'''+s[pos:]
a=s.index("cmd=['C:/Users/");z=s.index("\n   record['captureBeginUtc']",a)
s=s[:a]+'''cmd=[sdk,str(r/'collector/bin/Release/net11.0/Diagnostics.dll'),str(w.pid),str(output)]
   record['traceCommand']=cmd;t=subprocess.Popen(cmd,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace');owned.append(t)
   messages=queue.Queue()
   def read_trace():
    for line in t.stdout:
     trace_log.write(line);trace_log.flush();messages.put(line)
   reader_thread=threading.Thread(target=read_trace);reader_thread.start()
   attached=json.loads(messages.get(timeout=7));assert attached['status']=='Attached'and attached['targetPid']==w.pid
   record['collectorAttached']=attached
'''+s[z:]
s=s.replace("t.stdin.write('\\n')","t.stdin.write('stop\\n')").replace("r/'receipt.json'","r/'confirmed-readiness/receipt.json'")
(r/'collect-ready.py').write_text(s,encoding='utf-8',newline='\n')
print('Preserved original CLI readiness failure; existing managed session now signals Attached explicitly')
