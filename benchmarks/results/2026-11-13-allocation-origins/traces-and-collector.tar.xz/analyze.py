from pathlib import Path
import json
r=Path(__file__).parent
for name in ['captured','search']:
 p=r/'confirmed-readiness'/name/'origins.json'
 if not p.exists():continue
 d=json.loads(p.read_text(encoding='utf-8'));print(name,'resolved',d['productionStackTicks'],'/',d['ticks'])
 for row in d['allocations'][:10]:
  print(row['type'],row['ticks'],round(row['ticks']/d['productionStackTicks']*100,2))
  for v in row['origins'][:2]:print(' ',v['ticks'],v['frames'][:360])
