from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;run=r/'confirmed-readiness';fixture=run/'fixtures'
inspection=json.loads((run/'cleanup-inspection.json').read_text(encoding='utf-8'));assert all(not x['isFile']for x in inspection)
dirs=sorted(fixture.rglob('*'),key=lambda p:len(p.parts),reverse=True)
for p in dirs:
 assert p.resolve().is_relative_to(fixture.resolve())and p.is_dir()and not p.is_symlink()and not list(p.iterdir())
 p.rmdir()
assert not list(fixture.iterdir());fixture.rmdir()
records=[json.loads((run/name/'record.json').read_text(encoding='utf-8'))for name in ['captured','search']]
assert all(x['allGoldensPassed']and x['workerAndTraceJoined']for x in records)
receipt=dict(completeCaptures=True,allActualUsersJoined=True,guestAndDiagnosticFixturesRemoved=True,originalFinalCheckFailedOnlyOnEmptyToolBuildDirectories=True,samplingNotExactBytesOrCpu=True,eventLossNotInferredAbsent=True,source='Qualified976f9439/frozen97bb; Windows local allocation origins, no timing comparison')
(run/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
out=Path('benchmarks/results/2026-11-13-allocation-origins');out.mkdir()
for name in ['captured','search']:
 target=out/name;target.mkdir()
 for f in ['record.json','origins.json']:shutil.copyfile(run/name/f,target/f)
shutil.copyfile(run/'receipt.json',out/'receipt.json')
with tarfile.open(out/'traces-and-collector.tar.xz','w:xz')as t:
 for name in ['identity.json','catalog.json','collect.py','collect-ready.py','prepare-ready.py','prepare.py','reader-build.log','collector-build.log','inspect-cleanup.py','finish.py','analyze.py']:
  t.add(r/name,arcname=name)
 for tool in ['reader','collector']:
  for name in ['Program.cs','Diagnostics.csproj']:t.add(r/tool/name,arcname=tool+'/'+name)
 for phase in ['captured','confirmed-readiness']:
  for p in sorted((r/phase).rglob('*')):
   if p.is_file()and p.suffix!='.etlx':t.add(p,arcname=phase+'/'+p.relative_to(r/phase).as_posix())
(out/'README.md').write_text('''# Complete-script allocation origins

2026-11-13. Qualified976f9439/frozen97bb on local Windows/.NET11RC3. The full image
hashes are preserved, independently of the VM's earlier CPU images. Two existing
complete scripts receive four guest seconds warmup, then256captured-text or1024search
invocations. Goldens, actual worker/collector joins and fixture cleanup pass. This
is sampled allocation attribution; it is not a CPU/timing comparison, exact type
allocation total or retained-memory measurement. Event loss is not inferred absent.

| Script | Sampled triggers | Resolved production stacks | Leading triggering types |
| --- | ---: | ---: | --- |
| Captured text |2016|1989|PyString703; prepared-word cursor490; BigInteger377; temporary reservation244 |
| Search |1408|1286|PyString639; byte arrays259; BigInteger256; output builder120 |

The type names identify allocations triggering a periodic sample. They do not own
all bytes since the prior sample and cannot be called exact allocated-byte shares.
Other/unresolved ticks remain visible. Captures cover the complete worker request;
production-stack selection excludes ordinary fixture/protocol-only allocations,
while context construction, host I/O, result cleanup and executed helpers remain.

Per-line prepared-word cursors and reservation wrappers are a concrete text storage
opportunity. Current range arrays already use an execution-owned single-idle cache;
consider consolidating buffer ownership and private cursor state into that same loan,
removing the per-line cursor packet/transaction wrapper rather than adding a second
pool. Search allocation does not support a new call arena: line strings, byte input
and exact counter updates dominate its observed triggers. Existing frame optimizations
stay intact; these observations do not resolve the search's unknown CPU fraction.

The first dotnet-trace CLI attempt had no redirected readiness marker and produced
no usable capture; its command/log/partial trace remain archived. The corrected
collector reuses the managed diagnostics API, explicitly signals Attached, writes
the event stream and waits for method metadata rundown. Keywords0x8003 match the
installed tool's gc-verbose profile. It observes allocations/GC events and method
metadata; it does not request a collection, heap dump or guest/root walk. No profiler
or collector code/dependency enters production. Offline TraceLog resolves stacks.
The corrected collector's last assertion found six empty MSBuild/NuGet temp folders,
after both users/traces had joined. Their original inspection and checked empty-only
cleanup are preserved; this is a cleanup-check correction, not a repeated capture.
''',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('   **R323 next source gate:**');b=s.index('   Each selected milestone',a)
s=s[:a]+'''   **R323 allocation gate complete:** local qualified97bb has1989/2016resolved
   captured-text triggers and1286/1408search triggers. Text repeatedly allocates
   cursor/temporary reservation packets; search mainly line text/bytes/counter
   values. Sample triggers are not per-type byte or CPU shares; loss is unknown.
   [Raw streams, initial readiness failure and cleanup correction](benchmarks/results/2026-11-13-allocation-origins/README.md).
   **R324 selected design, after R322 delivery correction:** consolidate the existing
   execution-owned word-range buffer loan and private cased-word cursor state.
   Remove per-line cursor construction, the separate word-array cache entry and
   its per-line transaction wrapper; do not add another cursor pool or return
   dispatch framework. Reuse the existing one-idle-buffer policy, with conservative
   full capacity/replacement admission and eager word preflight. Idle loans clear
   guest/source references; active/nested loans stay funded through actual cleanup.
   Preserve Unicode/sigma/whitespace, eager failure order, final bindings, dynamic
   fallback, genuine suspension, cancellation/refusal and retained word aliases.
   Validate nested/reentrant/late-return/ended-cache lifetimes plus existing text
   regressions; compare one complete captured-text script with unchanged search.
   Stop at a coherent storage/lifetime removal and a decision on any measured debt.
''' +s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
print('Preserved two usable allocation captures and original observation/cleanup failures; R324 proposed')
