using Microsoft.Diagnostics.Tracing.Etlx;
using System.Text;
using System.Text.Json;

using var record = JsonDocument.Parse(File.ReadAllText(args[1], Encoding.UTF8));
var begin = DateTime.Parse(record.RootElement.GetProperty("captureBeginUtc").GetString()!).ToUniversalTime();
var end = DateTime.Parse(record.RootElement.GetProperty("captureEndUtc").GetString()!).ToUniversalTime();
var converted = Path.ChangeExtension(args[0], ".eventpipe.etlx");
if (!File.Exists(converted)) TraceLog.CreateFromEventPipeDataFile(args[0], converted, new TraceLogOptions());
using var trace = new TraceLog(converted);
var groups = new Dictionary<string, Dictionary<string, (long Ticks, long TriggerBytes)>>();
var threads = new Dictionary<int, int>();
var ticks = 0; var production = 0;
foreach (var entry in trace.Events)
{
    var at = entry.TimeStamp.ToUniversalTime();
    if (at < begin || at > end || !entry.EventName.Contains("AllocationTick")) continue;
    ticks++;
    var frames = new List<string>();
    for (var stack = entry.CallStack(); stack is not null; stack = stack.Caller)
    {
        var method = stack.CodeAddress.FullMethodName;
        if (method.StartsWith("Lokad.Lython.Runtime.", StringComparison.Ordinal)) frames.Add(method);
    }
    if (frames.Count == 0) continue;
    production++;
    threads[entry.ThreadID] = threads.GetValueOrDefault(entry.ThreadID) + 1;
    object? Payload(string key) => entry.PayloadNames.Contains(key) ? entry.PayloadByName(key) : null;
    var type = Payload("TypeName")?.ToString() ?? "unknown";
    var size = Convert.ToInt64(Payload("ObjectSize") ?? 0L);
    var origin = string.Join(" -> ", frames.Take(6));
    if (!groups.TryGetValue(type, out var owners)) groups[type] = owners = new();
    var before = owners.GetValueOrDefault(origin);
    owners[origin] = (before.Ticks + 1, before.TriggerBytes + size);
}
var summary = new { ticks, productionStackTicks = production, otherOrUnresolvedTicks = ticks - production, threads,
    note = "Sampled allocation triggers with resolved production stacks during the request; not exact per-type allocated bytes, retained memory, CPU or elapsed comparison. Other/unresolved ticks remain explicit. Event loss is not inferred absent.",
    allocations = groups.Select(x => new { type = x.Key, ticks = x.Value.Values.Sum(v => v.Ticks), origins = x.Value.OrderByDescending(v => v.Value.Ticks).Select(v => new { frames = v.Key, ticks = v.Value.Ticks, triggerObjectBytes = v.Value.TriggerBytes }) }).OrderByDescending(x => x.ticks) };
File.WriteAllText(args[2], JsonSerializer.Serialize(summary, new JsonSerializerOptions { WriteIndented = true }), new UTF8Encoding(false));
Console.WriteLine(JsonSerializer.Serialize(new { ticks, productionStackTicks = production, types = groups.Count }));
