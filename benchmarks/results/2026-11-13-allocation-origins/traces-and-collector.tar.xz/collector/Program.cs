using System.Diagnostics.Tracing;
using System.Text.Json;
using Microsoft.Diagnostics.NETCore.Client;

var pid = int.Parse(args[0]);
var client = new DiagnosticsClient(pid);
// Same observed gc-verbose keywords as installed dotnet-trace. Allocation
// samples and method rundown only; no collection request or heap/root walk.
using var session = client.StartEventPipeSession(
    [new EventPipeProvider("Microsoft-Windows-DotNETRuntime", EventLevel.Verbose, 0x8003)],
    requestRundown: true, circularBufferMB: 16);
await using var file = File.Create(args[1]);
var copying = session.EventStream.CopyToAsync(file);
Console.WriteLine(JsonSerializer.Serialize(new { status = "Attached", targetPid = pid, keywords = "0x8003", requestRundown = true }));
Console.Out.Flush();
try
{
    if (await Console.In.ReadLineAsync() != "stop") throw new InvalidDataException("Expected owned stop command.");
}
finally
{
    session.Stop();
    await copying.WaitAsync(TimeSpan.FromSeconds(15));
    await file.FlushAsync();
}
