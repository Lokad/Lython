from pathlib import Path
import json
r=Path(__file__).parent;fixture=r/'confirmed-readiness/fixtures'
rows=[]
for p in fixture.rglob('*'):
 assert p.resolve().is_relative_to(fixture.resolve())and not p.is_symlink()
 rows.append(dict(path=str(p.relative_to(fixture)),isFile=p.is_file(),bytes=p.stat().st_size if p.is_file()else None))
(r/'confirmed-readiness/cleanup-inspection.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Retained diagnostic temp entries:',rows[:15],';total',len(rows))
