from pathlib import Path
import datetime,hashlib,importlib.util,json,os,queue,shutil,subprocess,threading,time
r=Path(__file__).parent;identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH'];sdk=env['DOTNET_ROOT']+'/dotnet.exe'
assert all(hashlib.sha256((r/'image'/p).read_bytes()).hexdigest()==sha for p,sha in identity['files'].items())
spec=importlib.util.spec_from_file_location('protocol',Path('benchmarks/cpython-worker.py').resolve());protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
catalog=(r/'catalog.json').resolve();cases=json.loads(catalog.read_text(encoding='utf-8'))['cases'];fixture=r/'confirmed-readiness/fixtures';fixture.mkdir();env['TEMP']=str(fixture.resolve());env['TMP']=str(fixture.resolve())
owned=[];timeout=False
def terminate():
 global timeout
 timeout=True
 for p in owned:
  if p.poll()is None:p.kill()
timer=threading.Timer(120,terminate);timer.start();records=[]
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
 with(r/'reader-build.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'build',str(r/'reader/Diagnostics.csproj'),'-c','Release','--nologo'],env=env,stdout=f,stderr=subprocess.STDOUT)
 assert done.returncode==0,(r/'reader-build.log').read_text(encoding='utf-8')[-2500:]
 with(r/'collector-build.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'build',str(r/'collector/Diagnostics.csproj'),'-c','Release','--nologo'],env=env,stdout=f,stderr=subprocess.STDOUT)
 assert done.returncode==0,(r/'collector-build.log').read_text(encoding='utf-8')[-2500:]
 for label,case_id,count in [('captured','scripts.text-summary-helpers.nonlocal-counter.large',256),('search','scripts.file-search.large',1024)]:
  case=next(c for c in cases if c['id']==case_id);folder=r/'confirmed-readiness'/label;folder.mkdir();cwd=fixture/('lython-comparison-files-'+label);cwd.mkdir()
  log=(folder/'worker.stderr').open('wb');trace_log=(folder/'trace.log').open('w',encoding='utf-8',newline='\n');w=t=None;reader_thread=None
  try:
   w=subprocess.Popen([sdk,str((r/'image/Lokad.Lython.Benchmarks.dll').resolve()),'--compare','worker','--catalog',str(catalog)],cwd=cwd,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=log);owned.append(w)
   ready=protocol.read_frame(w.stdout);assert ready['status']=='Ready'and ready['catalogSha256']==identity['catalogSHA256']and not ready['serverGc']and not any(ready['runtimeOverrides'].values())
   assert next(v for v in ready['libraries']if Path(v['path']).name=='Lokad.Lython.dll')['sha256']==identity['files']['Lokad.Lython.dll']
   sequence=0
   def request(operation,n):
    global sequence
    sequence+=1;message={k:case[k]for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']};message.update(protocolVersion=2,requestId=sequence,operation=operation,caseId=case_id,lane='warm',iterations=n)
    protocol.write_frame(w.stdin,message);reply=protocol.read_frame(w.stdout);assert reply['requestId']==sequence
    if operation=='quit':assert reply['status']=='Closed'
    else:
     assert reply['status']==('Equivalent'if operation=='verify'else'Completed')and reply['completedInvocations']==n,reply
     assert reply['actualOutputSha256']==case['expectedOutputSha256']and reply['actualFilesSha256']==case['expectedFilesSha256']
    return reply
   record=dict(case=case_id,identity=ready,captureInvocations=count,performanceComparison=False)
   record['verificationBefore']=request('verify',2);warm=0
   while warm<4:
    reply=request('batch',32);warm+=reply['elapsedTicks']/reply['clockFrequency']
   record['warmGuestSeconds']=warm
   output=(folder/'profile.nettrace').resolve();cmd=[sdk,str(r/'collector/bin/Release/net11.0/Diagnostics.dll'),str(w.pid),str(output)]
   record['traceCommand']=cmd;t=subprocess.Popen(cmd,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace');owned.append(t)
   messages=queue.Queue()
   def read_trace():
    for line in t.stdout:
     trace_log.write(line);trace_log.flush();messages.put(line)
   reader_thread=threading.Thread(target=read_trace);reader_thread.start()
   attached=json.loads(messages.get(timeout=7));assert attached['status']=='Attached'and attached['targetPid']==w.pid
   record['collectorAttached']=attached

   record['captureBeginUtc']=utc();record['captureResponse']=request('batch',count);record['captureEndUtc']=utc()
   t.stdin.write('stop\n');t.stdin.flush();assert t.wait(timeout=15)==0;reader_thread.join(timeout=5);assert not reader_thread.is_alive()
   record['verificationAfter']=request('verify',2);request('quit',0);assert w.wait(timeout=10)==0
   record['allGoldensPassed']=True;record['workerAndTraceJoined']=True
   (folder/'record.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
   with(folder/'reader.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,str(r/'reader/bin/Release/net11.0/Diagnostics.dll'),str(output),str((folder/'record.json').resolve()),str((folder/'origins.json').resolve())],env=env,stdout=f,stderr=subprocess.STDOUT)
   assert done.returncode==0,(folder/'reader.log').read_text(encoding='utf-8')[-2000:]
   record['origins']=json.loads((folder/'origins.json').read_text(encoding='utf-8'));records.append(record);print(label,(folder/'reader.log').read_text(encoding='utf-8').strip(),flush=True)
  finally:
   for p in [t,w]:
    if p is None:continue
    if p.poll()is None:p.kill()
    p.wait(timeout=10);p.stdin.close();p.stdout.close()
   if reader_thread is not None:reader_thread.join(timeout=5);assert not reader_thread.is_alive()
   log.close();trace_log.close();assert cwd.resolve().parent==fixture.resolve()and cwd.name.startswith('lython-comparison-files-');shutil.rmtree(cwd)
finally:
 timer.cancel()
 for p in owned:
  if p.poll()is None:p.kill()
  p.wait(timeout=10)
assert not timeout and not list(fixture.iterdir())
(r/'confirmed-readiness/receipt.json').write_text(json.dumps(dict(complete=True,records=records,allActualUsersJoined=True,fixturesRemoved=True,platform='Windows/.NET11RC3',diagnosticOnly=True,noAllocationOrCpuImprovementClaim=True,eventLossNotInferredAbsent=True),indent=2)+'\n',encoding='utf-8',newline='\n')
