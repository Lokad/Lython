# Lokad.Lython 0.11.0

Updated2026-11-09 (Paris). Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Completing one experiment does not complete this objective. Current contracts belong
in docs; [history](benchmarks/EXPERIMENTS.md) and immutable results preserve earlier
variants, failed conditions, adverse evidence and completed qualification.

## Actual delivery status

| Work | Source/status | Qualification / remaining uncertainty |
| --- | --- | --- |
| Shared compiler-fact correction, direct UTF8 formatting/storage, native helper returns | Committed | Fully qualified; do not repeat unchanged qualification. Allocation and CPU claims are separate below. |
| R119–R121 record/lookup facts; R125 pending text funding; R126 liveness cleanup; R127 declaration metadata; R129 literal construction | Committed6f76/3109/9f2e/847/459 | Cached Windows/Ubuntu actual11/10, original Stress both and installed-core consumers pass. |
| R132 direct native inputs/shared local-prefix facts | Committedc343/core95fc | Fully qualified CI42552506089success; terminal cached, never requery. Search elapsed−2.45–3.40%; broader CPU/control debt retained. |
| R133 canonical static-call syntax facts | Committed9db/core36fd | Focused47internal/206public eachactual11/10 pass. Compile allocation−2.59–4.14%; CPU/complete-config uncertainty remains. |
| R134 allocation attribution/R135 native Boolean storage and id/is correction | Committed6d73/core76d | Focused97internal/385public eachactual11/10 pass. Warm allocationCSV−9.09%,search−11.5–11.7%; no general CPU gain, report possible debt. |
| R136 current CPython checkpoint | Committed03314122, measured6d73/freshea65 | Nine quiet jobs188.968s/all measurement and cleanup gates pass; every row source-labelled. No per-change gain attribution. |
| R137 timed native-hash fixture correction | Committed748493f7 |16/16eachactual11/10 after fresh builds; mutation removing only loop checks fails both native cases. Full corrected Windows delivery pending. |
| R138 closed nested helpers | Committeddf3bc92d, measured345f | Broad68internal/279public peractual11/10 + final36/76 pass. B497 complete169.171s/all measurement gates/local SHA; full CI failed two class-scope semantics, correction active. |
| R124 prepared maps, earlier call arenas/control and string windows | Held prototypes, production restored | Added machinery/slower results retained in history; not permanent design bans. Useful independent regressions survive. |

CI42558487979/source6d73 is terminal/cached. Ubuntu full actual11/10, original Stress
both and package consumers pass. Windows actual11 passes4437internal/16853public,
fails one64MiB native-hash fixture at its IsCompleted assertion before requesting
cancellation; later Windows stages skipped. Original log retained in
[R137](benchmarks/results/2026-11-09-hash-cancellation/README.md). R137 arms1ms
cancellation on the hashing worker, moves only timed scans to Stress, preserves
same input/deadline/cache/attribution/refund assertions and awaits actual users.
Small deterministic checks remain ordinary; this remains a concurrent observation.
Do not call6d73 fully qualified or silently rerun green. Full CI42563792033/df3 is also terminal/cached: both platforms pass4446internal,
16857public and fail two existing class-scope tests; later stages skipped. Never
requery. R139a fixes the native lexical proof before further timing: LoadName is
not a global fact, decline it and delete the parent-depth heuristic. Existing
failures reproduce35pass/two fail; correction+active R139 passes101public each11/10.
R139a committed/pushed a58ca859; native proof declines LoadName and the runtime
scope-depth heuristic is deleted. A fresh corrected baseline is being built from
that commit without R139; independent37class/global controls must pass. Then
restore exact R139 prototype bytes and force nonincremental candidate builds.
Retain prototype4e94 diagnostics: allocationCSV−38.67%,report−26.1%,text unchanged;
asyncCSV+60–64%/asyncReport+11.7–17.7% adverse with variable controls. Both sides of
the corrected comparison must contain the proof fix; no unchanged retiming. Full corrected delivery remains
required at the next coherent source checkpoint.

## Measurement conclusions

[CPython guide](docs/BENCHMARKS.md) separates compile, warm and compile-to-result.
Current validatedCSV/text/report complete ratios versus3.13.16 are1.15–1.16x /
1.44–1.45x /1.35–1.38x; report and compile rows variable. Earlier ordinaryCSV/JSON
and config/search/manifest stay explicitly historical. Included: guest mediated
RAM-file I/O, full output validation and prior-result cleanup. Startup, staging,
reset/protocol and final cache teardown excluded; wider processCPU differs.
Large-tree throughput, RSS, pending I/O and embedding latency tails remain unmeasured.

Native helper-return allocation−19.92/19.31% is established independently of original
diagnostic elapsed gains. Formatting allocation−8.67% is established; controlled
B102 elapsed/CPU−5–8% supports retention. Original adverse15.125ms remains unexplained
and preserved. No unchanged replay selected; uncertainty is not a permanent closure.

R128 compilation attribution: parsing26–43%, abstract analysis19–29%, executable
construction~19%, lexical7–8%, lowering2–4%; these include useful work. R131 separates
guest work from caller/reset/protocol/tiering; builtin setup is not dominant.
R134 allocation associations are not exact typebytes or CPU dominance: text
PyString35.13%/BigInteger24.63%, CSV Boolean9.05%. Do not justify a universal scalar
rewrite or reconstruct already-removed phases from these inclusive counts.

## Prioritized deliverables

1. **Complete R138 and delivery qualification.** Remove two lexical-parent invocation
   barriers; compiler capture facts already exclude cells from native proofs. Reuse
   existing native/deferred paths, preserve defining closure ownership and promotion
   before scope-sensitive work. No new binder/frame arena/cache/option. Three complete
   main()-wrapped CSV/text/report scripts exercise the removed invocation phase;
   original JSON/search are controls. Captures/classes/annotations/type-parameter
   scopes retain existing handling. Acceptance: locals/globals/unbound lookup, live
   cells, class barriers, async protocols, cancellation/first refusal, retained aliases,
   capacity admission and managed-depth cleanup. Actual warm allocation fallsCSV38.67%,
   text46.5%,report28.5%; compile allocation0%change. Desktop async report+2.25–10.25%
   adverse/variable controls remain. B497six jobs169.171s/all gates/local SHA pass:
   CSV−8.16–8.39%,text−19.62–20.04%,report−10.50–13.22%,asyncReport−6.24–7.68%
   elapsed, supporting CPU. Report candidate spread2.98%/search reference2.49%
   remain variable; no universal gain. Retain phase elimination/affected benefit,
   original desktop adversity preserved, no unchanged retiming selected. Committed/
   pusheddf3bc92d; full delivery dispatched as above. Next work is milestone2 below.
   [Evidence](benchmarks/results/2026-11-09-closed-nested-helpers/README.md).

2. **R139 explicit lexical operands, implementation active.** Hypothesis:
   captured reads still force eager contexts although work state already holds their
   cells. Inspect direct reads/promotion; eliminate the frame-dependent cell-read
   bridge only if existing state carries the same semantics. Affected scripts: main()
   helpers reading shared configuration/predicates. Preserve nonlocal writes, late
   rebinding, escaped closures, class barriers, annotations, generators, locals,
   async protocols, cancellation/refusal and ownership. Captured local-cell creation
   currently associates the defining context: keep that restriction. Source gate
   finds one LoadClosure reader routed through CurrentExecutableFrame despite the
   work state's existing ClosureCells; StoreClosure has a separate real context
   consumer. Selected bounded implementation: read present cells from work state,
   promote before missing/nonlocal fallback and all writes; remove only capture-count
   eager admission, not captured-local/class/handler restrictions. Share one read
   implementation and retire the old context-only reader, no parallel dispatch.
   Source gate selected: one work-state TryLoadClosure replaces the context-only
   reader/transfer branch; missing cells promote before fallback, writes still
   promote. Incoming-cell eager guard removed; all outgoing-cell/special-scope
   restrictions remain. Four independent Python goldens and captured-return/
   pending-protocol/admission variants added. Focused78internal/285public plus
   final64public peractual11/10 pass; final checks cover free-variable span/trace
   before namespace promotion. Candidate4e94 frozen after nonincremental build;
   original4e94 diagnostics retained. R139a proof correction committeda58; both
   fresh corrected sources now frozen0216/a063 after nonincremental builds.
   Baseline37class/global controls pass; candidate606internal/323public each11/10
   pass. Corrected warm allocationCSV−38.67%,report−26.1%,text unchanged because
   split(separator) still promotes. DesktopCSV+12.7–20.1%sync/+12.1–14.4%async
   adverse, controls variable; no CPU claim. B498 selects seven finite quiet jobs,
   including both asyncCSV/report; all original conditions stay archived.
   Stop after20min source/invariant gate without a complete deletion target. If
   justified, focused checks plus one bounded whole-script pair/unchanged controls;
   explicitly decide remaining CPU/compilation regression debt at completion.

3. **Remaining roadmap, select from demonstrated work.** Ordinary calls already
   borrow operands into final locals; universal operand/value replacement is not
   selected from boxing alone. Current CSV adopts rows/shared layouts, displacing
   the old bulk-CSV6–8% copying premise. Reconsider only a newly demonstrated per-record
   construction phase, including its adverse control; no automatic promotion or
   rigid percentage veto. Text already uses bulk casing/split/final UTF8 formatting
   and native JSON construction. Remaining conversions require one bounded source/
   profile gate on retained whole scripts, not a sequence of isolated intrinsics.
   Frontend passes do useful work; repeated binding facts/lowered call wrappers have
   class-header/prepared-definition consumers to inspect. No replacement carrier or
   registry without a coherent deletion. Each selected redesign must name eliminated
   work/storage, affected scripts, semantic/cancellation/ownership acceptance, one
   controlled comparison, displaced code removal and a completion/debt decision.

## Independent regex delivery

Core owns Python/nativeUTF8 names, byte ranges/scalar positions/original windows,
effective flags/errors/replacements, current tokens, one frontend/runtime/import
provider and explicit owners. Development and contract tests do not wait for
publication; adapter-local bridges/pinned development producers are allowed.
Optional nonpackable adapter ordinary pin0.4; Dev55/d6067925 focused86internal/
514public peractual11/10 already pass. No unchanged replay/sibling edits or builds.
Final released-package qualification still needs DetailedData with distinct
preparation/working owners, native-name enumeration and cursor creation without
an earlier caller token. Only affected adapter qualification defers. Keep contract
forwarding/unwind, semantic validation and real-backend performance separate.

## Iteration and lasting constraints

Timeouts, unstable unchanged controls and inconclusive measurements establish
uncertainty, not failed designs. Allow bounded confirmation/refinement/correction
when source-specific evidence warrants it; size runs for useful quiet-VM observations.
Preserve every adverse result and original failed condition. Percentages inform
choices, not vetoes. Architectural simplification, allocation reduction and measured
CPU gains are distinct. Temporary setbacks require an explicit completion milestone
and regression-debt decision. Focused Release checks while developing; batch full
platform/original Stress/installed-package checks at meaningful delivery boundaries.

AGENTS.md is authoritative: fully managed safety/validated stack admission; host
mediation/current cancellation; coarse borrowed shared admission, preflights and
replacement overlap; funded aliases/results/caches/pending users and awaited cleanup.
Refusal terminal. No unsafe/native probing, quotas/caps/hidden allowance, heaptracing/
weak reclaim/forcedGC, silent regex fallback or abandoned work. Estimates stay
conservative; exact tiny-budget precision/GC reachability are not requirements.
No overlapping local build/test/timing. Fresh nonincremental builds after restored
snapshots; explicit UTF8. Only core Release packages in artifacts/nuget; no publication.

VMlokad@20.166.121.73/key~/.ssh/id_lython-bench.pem. ThroughB497 terminal/cached/local
verified, no users/fixtures; never requery. No live VM collection. Persistent
catalog/worker/raw evidence separate from owned RAM; join/unmount/archive under
lease/local SHA. Space recovery requires fresh idle exact bytes/all inode aliases/
SHA/UID/GID/mode/writable-parent proof and persisted pre-mutation plan. Preserve
all paths and bytes; resource floors/headroom stay unchanged.
