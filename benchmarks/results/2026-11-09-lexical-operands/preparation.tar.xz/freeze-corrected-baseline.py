from pathlib import Path
import os,subprocess,shutil,hashlib,json
r=Path(__file__).parent;env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH'];dotnet=env['DOTNET_ROOT']+'/dotnet.exe'
files=['src/Lokad.Lython/Runtime/LythonRuntime.Executable.Binding.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs', 'src/Lokad.Lython/Runtime/PyExecutableFunction.cs']
backup={f:(r/'prototype-source-before-baseline'/f).read_bytes()for f in files}
def run(args,log):
 with(r/log).open('w',encoding='utf-8')as o:done=subprocess.run([dotnet,*args],env=env,stdout=o,stderr=subprocess.STDOUT)
 print(log,done.returncode,flush=True)
 assert done.returncode==0,(r/log).read_text(encoding='utf-8')[-4000:]
try:
 for f in files:Path(f).write_bytes(subprocess.check_output(['git','show','HEAD:'+f]))
 proof=dict(revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),sourceSHA256={f:hashlib.sha256(Path(f).read_bytes()).hexdigest()for f in files},scope='Corrected committed a58 baseline only; incoming-cell prototype temporarily absent, tests still contain independent new semantics.')
 run(['build','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f','net11.0','--no-incremental','--no-restore'],'corrected-baseline-tests-build.log')
 run(['test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f','net11.0','--no-build','--filter','FullyQualifiedName~PreparedGlobalLookupTests|FullyQualifiedName~ClassScopeDirectiveTests'],'corrected-baseline-class-tests.log')
 run(['build','benchmarks/Lokad.Lython.Benchmarks/Lokad.Lython.Benchmarks.csproj','-c','Release','-f','net11.0','--no-incremental','--no-restore'],'corrected-baseline-benchmark-build.log')
 images=r/'images-corrected';images.mkdir();shutil.copytree(r.parent/'closed-nested-r138/images/candidate',images/'before')
 shutil.copyfile('benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0/Lokad.Lython.dll',images/'before/Lokad.Lython.dll')
 proof['coreSHA256']=hashlib.sha256((images/'before/Lokad.Lython.dll').read_bytes()).hexdigest()
 (r/'corrected-baseline.json').write_text(json.dumps(proof,indent=2),encoding='utf-8');print(proof['coreSHA256'],flush=True)
finally:
 for f,b in backup.items():Path(f).write_bytes(b)
 assert all(Path(f).read_bytes()==b for f,b in backup.items())
 print('Exact incoming-cell prototype sources restored; fresh nonincremental candidate builds required.',flush=True)
