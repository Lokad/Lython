# Explicit lexical reads: bounded next milestone

Source gate afterdf3bc92d,2026-11-09. Existing ExecutableWorkState already contains
ClosureCells and carries them through lazy promotion. PyExecutableFunction's
CanDeferInvocationContext still excludes every nonempty incoming cell list. The
only LoadClosure operation reads through CurrentExecutableFrame/TryGetClosureCell.
That frame dependency can disappear; the separate StoreClosure/nonlocal fallback
requires a real lexical context and must keep it. Native proof still excludes
ClosureNames; do not extend its expression evaluator here.

Keep CapturedLocalSlots exclusion: CreateExecutableWorkState creates new outgoing
cells associated with its supplied context, so removing that guard without a real
invocation could associate them with an enclosing frame. Keep mirroring, class,
annotation/type-parameter, handler and exception-region exclusions. Do not redesign
cell ownership, retarget retained closure parents or add caches/arenas/dispatch.

Proposed small migration: one work-state-based cell-read helper, shared by both
APIs. Existing present cells return current Value/raise original free-variable
error on UninitializedLocal. Without cells, null invocation requests promotion
before ResolveName/nonlocal fallback; normal invocation uses existing fallback.
Move LoadClosure from frame-only transfer group to ordinary prefix handler and
delete displaced context-only read. Remove incoming-closure-count exclusion from
CanDefer only after these semantics are covered. Writes retain existing promotion.

Acceptance: live rebinding/deletion, explicit nonlocal mutation, escaped closure
returns/input aliases funded through result/code disposal, locals reflection after
promotion, class barriers/annotations/generators, true pending protocols/cancellation,
first admission refusal, awaited cleanup, shared-budget reuse and managed depth.
Affected scripts: main helpers reading captured configuration/separators/predicates.
Use existing focused suites + new independent boundary cases only where needed.
One short before/after allocation/elapsed diagnostic plus controlled VM source pair
when it materially resolves a debt; preserve failed conditions/control variability.
No runtime implementation or timing claims yet. R138 measured345f stays frozen;
CI42563792033 qualifiesdf3 only, not this future change.
