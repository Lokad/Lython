from pathlib import Path
import hashlib, json, subprocess, tarfile

r = Path(__file__).parent
v = r / 'b498'
out = Path('benchmarks/results/2026-11-09-lexical-operands')
out.mkdir(exist_ok=True)
for target, source in [
    ('observations.tgz', v/'observations.tgz'), ('summary.json', v/'assessment.json'),
    ('identity.json', r/'identity-corrected.json'), ('terminal.json', v/'terminal.json'),
    ('local-summary.json', r/'assessment-corrected.json'),
    ('prior-prototype-summary.json', r/'assessment-local.json'),
    ('compile-allocation.json', r/'compile-corrected-summary.json'),
    ('captured-sources.json', r/'captured-sources.json'),
    ('corrected-baseline.json', r/'corrected-baseline.json'), ('selection.md', r/'selection.md'),
    ('space-initial.json', r/'space-initial.json'), ('space-additional.json', r/'space.json')]:
    (out/target).write_bytes(source.read_bytes())
(out/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary']))
sources = [Path('src/Lokad.Lython/Runtime')/name for name in [
    'LythonRuntime.Executable.Binding.cs', 'LythonRuntime.Executable.Interpreter.Dispatch.cs',
    'LythonRuntime.Executable.Interpreter.cs', 'PyExecutableFunction.cs']]
(out/'validation.json').write_text(json.dumps(dict(
    frameworks=['net11.0','net10.0'], internalPerFramework=606, publicPerFramework=323,
    baselineClassGlobal=37, independentPythonGoldens=4,
    sourceRestore='Exact prototype bytes restored in finally; fresh nonincremental builds before final checks/freeze.',
    acceptance='Live/deleted cells, nonlocal writes, locals promotion, unbound read span/trace, retained captured returns after code disposal, genuine pending protocols, cancellation/first refusal, alias funding, awaited cleanup/budget reuse and managed depth.',
    sourceSHA256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}), indent=2), encoding='utf-8')
names = '''source-gate.md pre-edit-plan.md python-cases.json selection.md captured-sources.json catalog.json
identity.json identity-corrected.json source.patch assessment-local.json assessment-corrected.json
compile-corrected-summary.json freeze-corrected-baseline.py corrected-baseline.json
corrected-baseline-tests-build.log corrected-baseline-class-tests.log corrected-baseline-benchmark-build.log
class-barriers-before-proof-fix.log class-barriers-proof-fix-net11.0.log class-barriers-proof-fix-net10.0.log
corrected-final-internal-net11.0.log corrected-final-internal-net10.0.log
corrected-final-public-net11.0.log corrected-final-public-net10.0.log
corrected-final-internal-build-net11.0.log corrected-final-internal-build-net10.0.log
corrected-final-public-build-net11.0.log corrected-final-public-build-net10.0.log
corrected-candidate-benchmark-build.log corrected-measure.py corrected-measure-compile.py assess-corrected.py
warm-sync warm-async compile-sync corrected-warm-sync corrected-warm-async corrected-compile-sync
space.py space.log space-payload-headroom.py space-initial.json space.json csv-capacity-source-gate.md'''.split()
vm_names = '''launch.py launch-after-space.py launch-command.py launch-first-space-refusal.log launch.log
observe-not-before.json collect.py archive-owned.py contract.md setup-contract.json sizing.json focused.json
identity.json baseline-source.json source.patch pre-measurement-plan.md'''.split()
assert all((r/n).exists() for n in names)
assert all((v/n).exists() for n in vm_names)
with tarfile.open(out/'preparation.tar.xz','w:xz') as archive:
    for name in names: archive.add(r/name,arcname=name)
    for name in vm_names: archive.add(v/name,arcname='b498/'+name)
    archive.add(r/'images/candidate/Lokad.Lython.dll',arcname='prior-prototype4e94/Lokad.Lython.dll')
    archive.add(__file__,arcname='finalize.py')
with tarfile.open(out/'preparation.tar.xz') as archive:
    assert set(names) <= set(archive.getnames())
(out/'README.md').write_text('''# Explicit incoming lexical reads

R139/B498, 2026-11-09. Corrected committed a58/core0216 versus candidate a063.
Both sources contain the explicit-global native proof correction. The corrected
baseline is freshly built without incoming-cell changes and passes 37 class/global
controls. Exact prototype sources are then restored; nonincremental builds precede
606 internal/323 public focused checks on each actual .NET 11/10 and candidate freeze.

One work-state cell reader replaces the frame-only reader and stack-transfer branch.
Existing incoming cells no longer force eager invocation contexts. Missing cells
promote before lexical fallback; writes still promote. New local-cell construction,
mirroring, class/annotation/type-parameter/handler/exception restrictions remain.
Read live cell Value once, preserving original unbound-variable errors/spans.
No new native proof, dispatch, cache, binder, owner or public option. Managed stack,
current cancellation, coarse preflights and surviving alias funding remain.

Existing complete main-wrapped CSV/text/report scripts now read captured parser/skip
marker, separator and newline. Fixtures/full goldens unchanged; explicit source hashes
differ from R138. Ordinary JSON/search are controls. This compares identical scripts
between Lython revisions, not script shapes or CPython ratios.

| Warm complete script | Actual allocation, both APIs | Quiet elapsed change | Wider process CPU change |
| --- | ---: | ---: | ---: |
| Captured CSV | −38.66–38.67% | −7.31–7.93% | −6.45–12.30% |
| Captured CSV, completed-I/O async | −38.66% | −7.50–11.93% | −7.14–10.71% |
| Captured report | −26.06–26.07% | −4.97–9.14% | −1.16–4.88% |
| Captured report, completed-I/O async | −26.06% | −5.67–7.65% | −0.58–7.32% |

Four independent roles, 5s warmups, seven rotated 150ms rounds, normal GC/tiering
on quiet F4as_v7/.NET11RC3. Seven jobs/196.580s. Ranges span both candidate process
medians against both references, not confidence intervals. Report reference spread
3.51%/candidate1.05%; asyncCSV reference3.38%/candidate1.48% remain variable.
All affected elapsed/CPU comparisons favor candidate. JSON control elapsed
−.15..−.30%/CPU0%; search−8.15..+4.29% (reference8.66%,candidate4.50%) inconclusive.
No universal gain/neutrality claim.

Captured text allocation is unchanged; elapsed−3.13..+4.49% is inconclusive
(reference5.39%,candidate2.34%). Its explicit split(separator) still needs a context
in existing receiver dispatch; this read migration does not remove that construction.
Do not add a method special case merely to change this observation. Compile allocation
is unchanged across all five; compile CPU/startup/pending I/O remain unmeasured.
Warm clocks include mediated RAM-file I/O, full stdout/file validation and prior-result
cleanup; exclude compilation/startup/reset/protocol/final cache teardown. CPU is wider.

Original prototype4e94 versus uncorrected345f is retained: desktop asyncCSV+60..64%,
asyncReport+11.7..17.7%, variable controls. Corrected desktop CSV still+12.7..20.1%sync/
12.1..14.4%async, other controls drift up13.34%. Quiet comparisons do not reproduce
that CSV regression consistently; original adversity remains evidence. Retain the
removed phase, allocation reduction and affected-script quiet benefit. Text/control
uncertainty remains debt. No unchanged retiming selected or permanent closure.

All core/auxiliary/source/golden/budget/quiet/Closed/join/RAM-unmount/archive-under-
lease/local-SHA gates pass. Archive8ead6be5724daabc6212db4b61f40779bb1196d9e9d5f329101f1836a399c025.
Terminal cached, no users/fixtures. Initial setup refused headroom before workers.
Fresh exact duplicate-file proofs recovered14,016,512B then6,995,968B; every original
path/byte/alias/owner/group/mode and pre-mutation plan remains. Floors unchanged.

CSV source gate confirms ordinary record bytes/descriptors are already staged and
all ordinary field payloads/row capacity admitted once. No duplicate scope layer or
automatic promotion of historical bulk-copy work. Full platform/original Stress/
installed-package qualification batches after commit, including the lexical-name
fix. Publication postponed; broader performance and independent regex work remain.

[Quiet medians/variability](summary.json), [raw/both exact cores/protocol](observations.tgz),
[corrected local adversity](local-summary.json), [original prototype](prior-prototype-summary.json),
[compile allocation](compile-allocation.json), [focused validation](validation.json),
[corrected baseline](corrected-baseline.json), [captured sources](captured-sources.json),
[identities](identity.json), [terminal/archive receipt](terminal.json),
[preparation/all failed conditions/builds/restores](preparation.tar.xz),
[initial space proof](space-initial.json), [additional space proof](space-additional.json).
''', encoding='utf-8')

p=Path('docs/RUNTIME.md');s=p.read_text(encoding='utf-8-sig')
s=s.replace('Other closed helpers can begin with their owned local/operand storage and\nthe same instruction dispatch, without a lexical context.',
'''Eligible helpers begin with their owned local/operand storage and existing
incoming cells in the same instruction dispatch, without an invocation context.
Cell reads observe live values directly from that work state; unbound reads keep
their Python error/span. Missing-cell fallback and writes first create the ordinary
lexical context.''')
s=s.replace('not replayed. Protected and capturing bodies start with their normal context.',
'''not replayed. Protected bodies and functions creating captured local cells start
with their normal context.''')
s=s.replace('observe function locals or invoke guest protocols. Genuine captures and special\nclass, annotation and type-parameter scopes keep their existing lexical handling.',
'''observe function locals or invoke guest protocols. Incoming cells retain their
defining owners; class, annotation and type-parameter scopes keep their existing
lexical handling.''');p.write_text(s,encoding='utf-8')
p=Path('CHANGELOG.md');s=p.read_text(encoding='utf-8-sig');s=s.replace('## 0.11.0 - Unreleased\n\n',
'''## 0.11.0 - Unreleased

- Read incoming closure cells from existing executable work state, deferring the
  invocation context until scope-sensitive work. Preserve live rebinding, nonlocal
  writes, captured return ownership and asynchronous cleanup.

''',1);p.write_text(s,encoding='utf-8')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8-sig');a=s.index('| Closed nested helpers /')
s=s[:a]+'''| Incoming lexical reads / captured CSV and report helpers | Warm elapsed −7.3–7.9% /−5.0–9.1%; allocation −38.7% /−26.1%, supporting CPU | Async improves; captured text/search control inconclusive. Both sources include the lexical-name proof correction; original desktop adversity retained. [R139](../benchmarks/results/2026-11-09-lexical-operands/README.md) |
'''+s[a:];p.write_text(s,encoding='utf-8')
p=Path('tests/README.md');s=p.read_text(encoding='utf-8-sig');a=s.index('[Completed helper ownership]');b=s.index('\n\n',a)
s=s[:b]+''' Captured helpers also
exercise current incoming cells, retained returns through code disposal, original
unbound-read spans/traces and promotion before genuinely suspended protocols.'''+s[b:];p.write_text(s,encoding='utf-8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8-sig');s+='''

## Explicit incoming lexical operands (2026-11-09 Paris)

[R139/B498](results/2026-11-09-lexical-operands/README.md),correcteda58/core0216
versusa063, native global proof fix on both sides. Work-state cell reader replaces
frame-only read/transfer; no incoming-cell eager context. Writes/missing fallback/
local-cell construction/special scopes keep contexts.606internal/323public each
actual11/10 after exact source restoration/nonincremental builds; baseline37class/
global regressions pass. WarmallocationCSV−38.67%,report−26.1%,text unchanged (explicit
split still promotes), compile0%. Original4e94asyncCSV+60..64/report+11.7..17.7%desktop
and corrected CSV+12.7..20.1/asyncCSV+12.1..14.4%adverse/control drift preserved.
Seven quiet jobs196.580s/allgates: CSV−7.31..7.93/asyncCSV−7.50..11.93/report−4.97..9.14/
asyncReport−5.67..7.65%elapsed, supportingCPU. Text−3.13..+4.49/search−8.15..+4.29
controls inconclusive; JSONclose. Retain phase removal/allocation/affectedbenefit,
no universal gain. Terminalcached/localSHA/joins/RAMremoved. Initial setup refuses
space before workers; fresh exact2+1duplicate proofs preserve everypath/byte/
metadata/alias, floors unchanged. CSV field storage already admitted once; no new
scope layer or automatic bulk-copy revival. Full corrected delivery batches;
publication postponed, broader performance objective remains open.
''';p.write_text(s,encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8-sig');s=s.replace(
'   explicitly decide remaining CPU/compilation regression debt at completion.',
'''   explicitly decide remaining CPU/compilation regression debt at completion.
   B498 complete196.580s/sevenjobs/all identity/golden/ownership/quiet/join/RAM/
   archive/local-SHA gates pass. CSV−7.31–7.93%,asyncCSV−7.50–11.93%,report−4.97–9.14%,
   asyncReport−5.67–7.65%elapsed with supportingCPU. Text/search controls inconclusive;
   JSONclose. Retain phase removal/allocation/affected benefit, no universal gain.
   Original adverse desktop diagnostics stay archived; no unchanged retiming selected.
   [Evidence](benchmarks/results/2026-11-09-lexical-operands/README.md).
   Commit and batch corrected full qualification next.''')
s=s.replace('ThroughB497','ThroughB498');p.write_text(s,encoding='utf-8')
print('Evidence archive checked; current contracts and plan updated.')
