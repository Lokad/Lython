from pathlib import Path
import tarfile,subprocess
root=Path("/home/lokad/lython-bench-checks/key-suspension-b334-20261106");root.mkdir(exist_ok=False)
with tarfile.open('/home/lokad/lython-bench-checks/b334-payload.tgz') as archive:archive.extractall(root,filter='data')
subprocess.run(['python3',str(root/'setup.py')],check=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b334-key-suspension-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=130','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
