from pathlib import Path
import hashlib,json,os,re,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/"native-stack-initialization-20261123/comparison"
reference=lab.parent/"dispatch-known-call-semantics-20261123/comparison"
source=json.loads((reference/"identity.json").read_text(encoding="utf-8"))
baseline=reference/"frozen-candidate"
worktree=repo/".git/agent-worktrees/direct-native-return-entry-20261123"
core_name="Lokad.Lython.dll"
current=worktree/"src/Lokad.Lython/bin/Release/net11.0"/core_name
expected=source["imageFiles"]["candidate"]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(baseline/n)==digest for n,digest in expected.items())
dotnet=Path.home()/".dotnet11/dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
catalog=prior/"representative.json"
assert catalog.exists()
summaries=[]
for role in ("reference","candidate"):
    image=lab/role
    image.mkdir()
    for name in expected:
        shutil.copyfile(current if name==core_name and role=="candidate" else baseline/name,image/name)
    files={n:sha(image/n) for n in expected}
    assert [n for n in expected if expected[n]!=files[n]]==([core_name] if role=="candidate" else [])
    for n in ("ValidatedAllocation.dll","ValidatedAllocation.deps.json","ValidatedAllocation.runtimeconfig.json"):
        shutil.copyfile(prior/"frozen-reference"/n,image/n)
    log=lab/(role+".asm")
    output=lab/(role+"-diagnostic.json")
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,catalog,output],cwd=repo,check=True,timeout=100,
        env=dict(env,DOTNET_JitDisasm="StartNativeCall TryStartNativeIntegerReturn TryExecuteNativeCall CallFunction",
                 DOTNET_JitStdOutFile=str(log.resolve())))
    assert {n:sha(image/n) for n in expected}==files
    results=json.loads(output.read_text(encoding="utf-8"))["rows"]
    assert len(results)==8 and all(r["sharedBudgetBaselineRestored"] for r in results)
    decoded=log.read_text(encoding="utf-8-sig")
    methods=[]
    for entry in decoded.split("; Assembly listing for method ")[1:]:
        signature,body=entry.split("\n",1)
        if not signature.endswith("(Tier1)"):
            continue
        method=signature.split(":",1)[1].split("(",1)[0]
        if method not in {"StartNativeCall","TryStartNativeIntegerReturn","TryExecuteNativeCall","CallFunction"}:
            continue
        stack=re.search(r"\bsub\s+rsp,\s*(\d+)\b",body)
        counts=re.search(r"Total bytes of code (\d+)",body)
        calls=re.findall(r"(?:call|jmp)\s+\[.*PyExecutableFunction:(StartNativeCall|TryStartNativeIntegerReturn|TryStartDirectIntegerReturn)(?:\[|\()",body)
        methods.append(dict(method=method,stack=int(stack[1]) if stack else 0,bytes=int(counts[1]),calls=calls))
    assert any(m["method"]=="StartNativeCall" for m in methods), role
    summaries.append(dict(role=role,coreSHA256=files[core_name],methods=methods))
    print(role,methods)
(lab/"native-jit-summary.json").write_text(json.dumps(summaries,indent=2)+"\n",encoding="utf-8")
