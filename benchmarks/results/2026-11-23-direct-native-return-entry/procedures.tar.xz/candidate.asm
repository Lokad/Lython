; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x460
       lea      rbp, [rsp+0x460]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x400], xmm4
       mov      rax, -0x3F0
 
G_M000_IG85:                ;; offset=0x0026
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG85
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x004D
       mov      rax, bword ptr [rbp+0x40]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
       mov      rdx, gword ptr [rbp+0x38]
       mov      rcx, 0x7FFA02847388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x268], rax
       mov      rdx, gword ptr [rbp-0x268]
       mov      rcx, 0x7FFA026F6F40
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x00B8
       xor      rax, rax
       mov      gword ptr [rbp-0x128], rax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00C3
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x128], rax
 
G_M000_IG05:                ;; offset=0x00E1
       mov      rax, gword ptr [rbp-0x128]
       mov      gword ptr [rbp-0x10], rax
       mov      rdx, gword ptr [rbp+0x38]
       mov      rcx, 0x7FFA0286D848
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x18], rax
       cmp      gword ptr [rbp-0x18], 0
       je       SHORT G_M000_IG06
       mov      rcx, gword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Function():Lokad.Lython.Runtime.LythonRuntime+ICallable:this]
       mov      gword ptr [rbp-0x270], rax
       mov      rdx, gword ptr [rbp-0x270]
       mov      rcx, 0x7FFA02847388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x20], 0
       je       SHORT G_M000_IG06
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Receiver():System.Object:this]
       mov      gword ptr [rbp-0x10], rax
 
G_M000_IG06:                ;; offset=0x0158
       cmp      gword ptr [rbp-0x08], 0
       je       G_M000_IG35
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG35
       lea      r9, [rbp-0x28]
       mov      rcx, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r8, gword ptr [rbp-0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG08
       xor      eax, eax
 
G_M000_IG07:                ;; offset=0x018C
       add      rsp, 0x460
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0195
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
 
G_M000_IG09:                ;; offset=0x019A
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x278], rax
       mov      rdx, gword ptr [rbp-0x278]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x2C], 1
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x280], rax
       mov      rdx, gword ptr [rbp-0x280]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x208], rax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rbp-0x20C], eax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x284], eax
       mov      r9d, dword ptr [rbp-0x284]
       lea      rdx, [rbp-0x98]
       mov      r8d, dword ptr [rbp-0x20C]
       mov      rcx, bword ptr [rbp-0x208]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:Slice(int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       lea      rdx, [rbp-0x40]
       lea      rcx, [rbp-0x98]
       call     [System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_Span():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       cmp      gword ptr [rbp-0x10], 0
       jne      G_M000_IG16
 
G_M000_IG10:                ;; offset=0x0267
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x298], xmm0
 
G_M000_IG11:                ;; offset=0x0274
       lea      rdx, [rbp-0x298]
       lea      rcx, [rbp-0x258]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG12:                ;; offset=0x0288
       vmovdqu  xmm0, xmmword ptr [rbp-0x258]
       vmovdqu  xmmword ptr [rbp-0x2A8], xmm0
 
G_M000_IG13:                ;; offset=0x0298
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2B0], rax
       movzx    rax, byte  ptr [rbp-0x28]
       mov      dword ptr [rsp+0x28], eax
       lea      rax, [rbp-0x50]
       mov      qword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp-0x2B0]
       mov      gword ptr [rsp+0x20], rax
       lea      r8, [rbp-0x2A8]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r9, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartNativeIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG16
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG31
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x2C8], rax
 
G_M000_IG14:                ;; offset=0x0329
       vmovdqu  xmm0, xmmword ptr [rbp-0x50]
       vmovdqu  xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG15:                ;; offset=0x0336
       mov      r8, bword ptr [rbp-0x2C8]
       lea      r9, [rbp-0x2C0]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0x9C], 1
       jmp      G_M000_IG32
 
G_M000_IG16:                ;; offset=0x0361
       lea      rax, [rbp-0x68]
       mov      qword ptr [rsp+0x20], rax
       lea      rcx, [rbp-0x60]
       mov      rdx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PrepareUnpackedCallReturn(byref,Lokad.Lython.Frontend.ExecutableCallSite,int,byref):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG17:                ;; offset=0x0380
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x2D8], xmm0
 
G_M000_IG18:                ;; offset=0x038D
       lea      rdx, [rbp-0x2D8]
       lea      rcx, [rbp-0x220]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x228], rax
 
G_M000_IG19:                ;; offset=0x03B4
       vmovdqu  xmm0, xmmword ptr [rbp-0x220]
       vmovdqu  xmmword ptr [rbp-0x2E8], xmm0
 
G_M000_IG20:                ;; offset=0x03C4
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CallResultConsumedByIteration(byref,Lokad.Lython.Frontend.ExecutableCallSite):bool]
       mov      dword ptr [rbp-0x2FC], eax
       movzx    rax, byte  ptr [rbp-0x28]
       mov      dword ptr [rbp-0x300], eax
 
G_M000_IG21:                ;; offset=0x03E2
       vmovdqu  xmm0, xmmword ptr [rbp-0x60]
       vmovdqu  xmmword ptr [rbp-0x2F8], xmm0
 
G_M000_IG22:                ;; offset=0x03EF
       lea      rax, [rbp-0x70]
       mov      qword ptr [rsp+0x48], rax
       lea      rax, [rbp-0x80]
       mov      qword ptr [rsp+0x50], rax
       lea      rax, [rbp-0x88]
       mov      qword ptr [rsp+0x58], rax
       mov      eax, dword ptr [rbp-0x2FC]
       mov      dword ptr [rsp+0x30], eax
       lea      r8, [rbp-0x2E8]
       mov      eax, dword ptr [rbp-0x300]
       mov      dword ptr [rsp+0x38], eax
       lea      rax, [rbp-0x2F8]
       mov      qword ptr [rsp+0x40], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rsp+0x28], rax
       mov      rcx, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r9, gword ptr [rbp-0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       movzx    rax, byte  ptr [rbp-0x70]
       test     eax, eax
       jne      SHORT G_M000_IG23
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp-0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RestoreNativeExtent(int):this]
 
G_M000_IG23:                ;; offset=0x047C
       cmp      gword ptr [rbp-0x88], 0
       je       G_M000_IG26
 
G_M000_IG24:                ;; offset=0x048A
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterExecutableSlots():this]
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x230], rax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x238], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x308], rax
       mov      rax, gword ptr [rbp-0x308]
       mov      gword ptr [rsp+0x30], rax
       mov      rdx, gword ptr [rbp-0x230]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [rbp+0x30]
       mov      rax, gword ptr [rbp-0x238]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp+0x20]
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AttachPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.LythonSourceSpan,int,Lokad.Lython.Runtime.MemoryGovernor):this]
       nop      
 
G_M000_IG25:                ;; offset=0x0512
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, gword ptr [rbp-0x88]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       mov      dword ptr [rbp-0x9C], 1
       jmp      G_M000_IG33
 
G_M000_IG26:                ;; offset=0x0536
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       movzx    rax, byte  ptr [rbp-0x70]
       test     eax, eax
       je       SHORT G_M000_IG27
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8d, dword ptr [rbp+0x30]
       mov      r9d, dword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteUnpackedCallReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,int)]
       jmp      SHORT G_M000_IG30
 
G_M000_IG27:                ;; offset=0x0567
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG31
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x328], rax
 
G_M000_IG28:                ;; offset=0x0594
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x320], xmm0
 
G_M000_IG29:                ;; offset=0x05A1
       mov      r8, bword ptr [rbp-0x328]
       lea      r9, [rbp-0x320]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
 
G_M000_IG30:                ;; offset=0x05BD
       mov      dword ptr [rbp-0x9C], 1
       jmp      SHORT G_M000_IG34
 
G_M000_IG31:                ;; offset=0x05C9
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG32:                ;; offset=0x05CF
       call     G_M000_IG77
       jmp      G_M000_IG69
 
G_M000_IG33:                ;; offset=0x05D9
       call     G_M000_IG77
       jmp      G_M000_IG69
 
G_M000_IG34:                ;; offset=0x05E3
       call     G_M000_IG77
       jmp      G_M000_IG69
 
G_M000_IG35:                ;; offset=0x05ED
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG61
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       je       G_M000_IG61
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG38
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x338], rax
       mov      rdx, gword ptr [rbp-0x338]
       mov      rcx, 0x7FFA0286DD10
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xB0], rax
       cmp      gword ptr [rbp-0xB0], 0
       je       SHORT G_M000_IG38
       mov      rax, bword ptr [rbp+0x10]
       mov      bword ptr [rbp-0x1F8], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x200], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG36
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x200], rax
 
G_M000_IG36:                ;; offset=0x068C
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp-0x1F8]
       mov      rdx, gword ptr [rbp-0x200]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteCasedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCasedSplit,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG38
       mov      eax, 1
 
G_M000_IG37:                ;; offset=0x06C4
       add      rsp, 0x460
       pop      rbp
       ret      
 
G_M000_IG38:                ;; offset=0x06CD
       mov      rdx, gword ptr [rbp+0x38]
       mov      rcx, 0x7FFA0286E138
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xB8], rax
       cmp      gword ptr [rbp-0xB8], 0
       jne      SHORT G_M000_IG40
       xor      eax, eax
 
G_M000_IG39:                ;; offset=0x06F4
       add      rsp, 0x460
       pop      rbp
       ret      
 
G_M000_IG40:                ;; offset=0x06FD
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x340], rax
       mov      rdx, gword ptr [rbp-0x340]
       mov      rcx, 0x7FFA0286E440
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xC0], rax
       cmp      gword ptr [rbp-0xC0], 0
       je       SHORT G_M000_IG41
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteTrimmedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG41
       mov      dword ptr [rbp-0x9C], 1
       jmp      G_M000_IG69
 
G_M000_IG41:                ;; offset=0x077D
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rbp-0x150], rax
       mov      rax, gword ptr [rbp-0x148]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x348], rax
       mov      rdx, gword ptr [rbp-0x348]
       lea      rcx, [rbp-0x168]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 24
       mov      bword ptr [rbp-0x170], rax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rbp-0x178], rax
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rbp-0x17C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x188], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG42
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x188], rax
 
G_M000_IG42:                ;; offset=0x081C
       vmovdqu  xmm0, xmmword ptr [rbp-0x168]
       vmovdqu  xmmword ptr [rbp-0x358], xmm0
 
G_M000_IG43:                ;; offset=0x082C
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp-0x17C]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp-0x188]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x38], rax
       lea      r8, [rbp-0x358]
       mov      rdx, gword ptr [rbp-0x158]
       mov      rcx, gword ptr [rbp-0x150]
       mov      r9, bword ptr [rbp-0x170]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG46
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG60
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x370], rax
 
G_M000_IG44:                ;; offset=0x08B1
       vmovdqu  xmm0, xmmword ptr [rbp-0xD0]
       vmovdqu  xmmword ptr [rbp-0x368], xmm0
 
G_M000_IG45:                ;; offset=0x08C1
       mov      r8, bword ptr [rbp-0x370]
       lea      r9, [rbp-0x368]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0x9C], 1
       jmp      G_M000_IG69
 
G_M000_IG46:                ;; offset=0x08EC
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0xD8], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x190], rax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rbp-0x194], eax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x374], eax
       mov      r9d, dword ptr [rbp-0x374]
       lea      rdx, [rbp-0x98]
       mov      r8d, dword ptr [rbp-0x194]
       mov      rcx, bword ptr [rbp-0x190]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:Slice(int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       lea      rdx, [rbp-0xE8]
       lea      rcx, [rbp-0x98]
       call     [System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_Span():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG51
       mov      rcx, 0x7FFA0286E738
       call     [CORINFO_HELP_GET_GCSTATIC_BASE]
       mov      rax, 0x27B38C01C60
       mov      rax, gword ptr [rax]
       cmp      rax, gword ptr [rbp-0xB8]
       jne      G_M000_IG51
       mov      rdx, gword ptr [rbp-0xD8]
       mov      rcx, 0x7FFA025ACB28
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xF0], rax
       cmp      gword ptr [rbp-0xF0], 0
       je       G_M000_IG51
       cmp      dword ptr [rbp-0xE0], 2
       jg       G_M000_IG51
 
G_M000_IG47:                ;; offset=0x09F3
       vmovdqu  xmm0, xmmword ptr [rbp-0xE8]
       vmovdqu  xmmword ptr [rbp-0x388], xmm0
 
G_M000_IG48:                ;; offset=0x0A03
       lea      rdx, [rbp-0x388]
       lea      rcx, [rbp-0x1E8]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, gword ptr [rbp-0xF0]
       mov      gword ptr [rsp+0x28], rax
 
G_M000_IG49:                ;; offset=0x0A2A
       vmovdqu  xmm0, xmmword ptr [rbp-0x1E8]
       vmovdqu  xmmword ptr [rbp-0x398], xmm0
 
G_M000_IG50:                ;; offset=0x0A3A
       lea      rax, [rbp-0x398]
       mov      qword ptr [rsp+0x30], rax
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp+0x18]
       mov      r9, gword ptr [rbp+0x28]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSplitUnpack(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool]
       test     eax, eax
       je       SHORT G_M000_IG51
       mov      dword ptr [rbp-0x9C], 1
       jmp      G_M000_IG69
 
G_M000_IG51:                ;; offset=0x0A6F
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_AccumulatesDictionary():bool:this]
       test     eax, eax
       je       G_M000_IG53
       mov      eax, dword ptr [rbp-0xE0]
       mov      dword ptr [rbp-0x104], eax
       cmp      dword ptr [rbp-0x104], 1
       je       SHORT G_M000_IG52
       cmp      dword ptr [rbp-0x104], 2
       jne      G_M000_IG53
 
G_M000_IG52:                ;; offset=0x0AA5
       mov      rcx, 0x7FFA0286E738
       call     [CORINFO_HELP_GET_GCSTATIC_BASE]
       mov      rax, 0x27B38C01C30
       mov      rax, gword ptr [rax]
       cmp      rax, gword ptr [rbp-0xB8]
       jne      G_M000_IG53
       mov      rdx, gword ptr [rbp-0xD8]
       mov      rcx, 0x7FFA02607AA0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xF8], rax
       cmp      gword ptr [rbp-0xF8], 0
       je       G_M000_IG53
       cmp      dword ptr [rbp-0xE0], 0
       jbe      G_M000_IG60
       mov      rcx, bword ptr [rbp-0xE8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x3A0], rax
       mov      rdx, gword ptr [rbp-0x3A0]
       mov      rcx, gword ptr [rbp-0xF8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG53
       cmp      dword ptr [rbp-0xE0], 0
       jbe      G_M000_IG60
       mov      rcx, bword ptr [rbp-0xE8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x3A8], rax
       mov      rdx, gword ptr [rbp-0x3A8]
       mov      rcx, 0x7FFA025ACB28
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x3B0], rax
       mov      rax, gword ptr [rbp-0x3B0]
       mov      gword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [rbp+0x30]
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryAccumulation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.PyDict,Lokad.Lython.Runtime.Text.PyString):bool]
       test     eax, eax
       je       SHORT G_M000_IG53
       mov      dword ptr [rbp-0x9C], 1
       jmp      G_M000_IG69
 
G_M000_IG53:                ;; offset=0x0BBA
       vmovdqu  xmm0, xmmword ptr [rbp-0xE8]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG54:                ;; offset=0x0BCA
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rbp-0x1B0], rax
       mov      rax, gword ptr [rbp-0xD8]
       mov      gword ptr [rbp-0x1B8], rax
 
G_M000_IG55:                ;; offset=0x0BE6
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A8]
       vmovdqu  xmmword ptr [rbp-0x1C8], xmm0
 
G_M000_IG56:                ;; offset=0x0BF6
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x1D8], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG57
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x1D8], rax
 
G_M000_IG57:                ;; offset=0x0C26
       vmovdqu  xmm0, xmmword ptr [rbp-0x1C8]
       vmovdqu  xmmword ptr [rbp-0x3C0], xmm0
 
G_M000_IG58:                ;; offset=0x0C36
       mov      rax, gword ptr [rbp-0x1D8]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x100]
       mov      qword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x3C0]
       mov      rdx, gword ptr [rbp-0x1B8]
       mov      rcx, gword ptr [rbp-0x1B0]
       mov      r9, gword ptr [rbp-0x1D0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG59
       xor      eax, eax
       mov      dword ptr [rbp-0x9C], eax
       jmp      G_M000_IG69
 
G_M000_IG59:                ;; offset=0x0C81
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG60
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x3C8], rax
       mov      r8, bword ptr [rbp-0x3C8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp-0x100]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       mov      dword ptr [rbp-0x9C], 1
       jmp      G_M000_IG69
 
G_M000_IG60:                ;; offset=0x0CD9
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG61:                ;; offset=0x0CDF
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x3D0], rax
       mov      rdx, gword ptr [rbp-0x3D0]
       lea      rcx, [rbp-0x138]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG62:                ;; offset=0x0D0E
       vmovdqu  xmm0, xmmword ptr [rbp-0x138]
       vmovdqu  xmmword ptr [rbp-0x3E0], xmm0
 
G_M000_IG63:                ;; offset=0x0D1E
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       cmp      gword ptr [rbp+0x20], 0
       setne    al
       movzx    rax, al
       mov      dword ptr [rsp+0x28], eax
       lea      rax, [rbp-0x118]
       mov      qword ptr [rsp+0x30], rax
       lea      r8, [rbp-0x3E0]
       mov      rdx, gword ptr [rbp+0x38]
       mov      rcx, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG64
       xor      eax, eax
       mov      dword ptr [rbp-0x9C], eax
       jmp      G_M000_IG69
 
G_M000_IG64:                ;; offset=0x0D6C
       lea      rcx, [rbp-0x118]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x3E8], rax
       mov      rdx, gword ptr [rbp-0x3E8]
       mov      rcx, 0x7FFA024EE760
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x120], rax
       cmp      gword ptr [rbp-0x120], 0
       je       SHORT G_M000_IG66
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, gword ptr [rbp-0x120]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0x9C], 1
       jmp      SHORT G_M000_IG69
 
G_M000_IG65:                ;; offset=0x0DDB
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG66:                ;; offset=0x0DE1
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG65
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x400], rax
 
G_M000_IG67:                ;; offset=0x0E0E
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x3F8], xmm0
 
G_M000_IG68:                ;; offset=0x0E1E
       mov      r8, bword ptr [rbp-0x400]
       lea      r9, [rbp-0x3F8]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0x9C], 1
 
G_M000_IG69:                ;; offset=0x0E44
       mov      eax, dword ptr [rbp-0x9C]
 
G_M000_IG70:                ;; offset=0x0E4A
       add      rsp, 0x460
       pop      rbp
       ret      
 
G_M000_IG71:                ;; offset=0x0E53
       sub      rsp, 104
 
G_M000_IG72:                ;; offset=0x0E57
       mov      gword ptr [rbp-0x240], rcx
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x248], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x310], rax
       mov      rdx, gword ptr [rbp-0x310]
       mov      rcx, gword ptr [rbp-0x248]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AbortPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG73:                ;; offset=0x0EA4
       sub      rsp, 104
 
G_M000_IG74:                ;; offset=0x0EA8
       mov      gword ptr [rbp-0x260], rcx
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x330], rax
       mov      rdx, gword ptr [rbp-0x330]
       lea      r8, [rbp-0xA8]
       mov      rcx, gword ptr [rbp-0x260]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x0EF8
       mov      rcx, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG76:                ;; offset=0x0F05
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG77:                ;; offset=0x0F0B
       sub      rsp, 104
 
G_M000_IG78:                ;; offset=0x0F0F
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG79
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG79:                ;; offset=0x0F21
       nop      
 
G_M000_IG80:                ;; offset=0x0F22
       add      rsp, 104
       ret      
 
G_M000_IG81:                ;; offset=0x0F27
       sub      rsp, 104
 
G_M000_IG82:                ;; offset=0x0F2B
       mov      gword ptr [rbp-0x1F0], rcx
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG83:                ;; offset=0x0F4F
       sub      rsp, 104
 
G_M000_IG84:                ;; offset=0x0F53
       mov      gword ptr [rbp-0x140], rcx
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 3959

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TryStartNativeIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 128
       lea      rbp, [rsp+0x80]
       xor      eax, eax
       mov      qword ptr [rbp-0x48], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqa  xmmword ptr [rbp-0x20], xmm4
       mov      qword ptr [rbp-0x10], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0038
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x0060
       add      rsp, 128
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x0069
       movzx    rax, byte  ptr [rbp+0x38]
       test     eax, eax
       jne      SHORT G_M000_IG08
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x0075
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x28], xmm0
 
G_M000_IG06:                ;; offset=0x007E
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x28]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       nop      
 
G_M000_IG07:                ;; offset=0x00A7
       add      rsp, 128
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x00B0
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x04], eax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x04]
       jne      SHORT G_M000_IG14
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG09:                ;; offset=0x00D8
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x38], xmm0
 
G_M000_IG10:                ;; offset=0x00E1
       lea      rdx, [rbp-0x38]
       lea      rcx, [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
 
G_M000_IG11:                ;; offset=0x00EF
       vmovdqu  xmm0, xmmword ptr [rbp-0x18]
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
 
G_M000_IG12:                ;; offset=0x00F9
       lea      rdx, [rbp-0x48]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x30]
       mov      r9, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       nop      
 
G_M000_IG13:                ;; offset=0x0110
       add      rsp, 128
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x0119
       xor      eax, eax
 
G_M000_IG15:                ;; offset=0x011B
       add      rsp, 128
       pop      rbp
       ret      
 
; Total bytes of code 292

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 624
       lea      rbp, [rsp+0x270]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x220], xmm4
       mov      rax, -528
 
G_M000_IG21:                ;; offset=0x0026
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG21
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x004D
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
       vmovdqu  ymmword ptr [rbp-0xE0], ymm0
       vmovdqu  ymmword ptr [rbp-0xC0], ymm0
       vmovdqu  ymmword ptr [rbp-0xA0], ymm0
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  ymmword ptr [rbp-0x40], ymm0
       vmovdqu  ymmword ptr [rbp-0x20], ymm0
       lea      rdx, [rbp-0x100]
       lea      rcx, [rbp-0x110]
       mov      r8d, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x198], eax
       mov      r9d, dword ptr [rbp-0x198]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x110]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       je       G_M000_IG06
       xor      eax, eax
       mov      dword ptr [rbp-0x114], eax
       cmp      gword ptr [rbp+0x28], 0
       je       SHORT G_M000_IG03
       mov      eax, dword ptr [rbp-0x114]
       mov      dword ptr [rbp-0x194], eax
       mov      eax, dword ptr [rbp-0x114]
       inc      eax
       mov      dword ptr [rbp-0x114], eax
       mov      eax, dword ptr [rbp-0x108]
       cmp      dword ptr [rbp-0x194], eax
       jae      G_M000_IG20
       mov      eax, dword ptr [rbp-0x194]
       shl      rax, 4
       mov      rcx, rax
       add      rcx, bword ptr [rbp-0x110]
       mov      rdx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG03:                ;; offset=0x013D
       lea      rdx, [rbp-0x190]
       lea      rcx, [rbp-0x110]
       mov      r8d, dword ptr [rbp-0x114]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG04:                ;; offset=0x0158
       vmovdqu  xmm0, xmmword ptr [rbp-0x190]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG05:                ;; offset=0x0168
       lea      rdx, [rbp-0x1A8]
       mov      rcx, bword ptr [rbp+0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG12
 
G_M000_IG06:                ;; offset=0x017E
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x1AC], eax
       mov      r9d, dword ptr [rbp-0x1AC]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x170]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG07:                ;; offset=0x01B8
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0x1C0], xmm0
 
G_M000_IG08:                ;; offset=0x01C8
       vmovdqu  xmm0, xmmword ptr [rbp-0x128]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG09:                ;; offset=0x01D8
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG10:                ;; offset=0x01FD
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
 
G_M000_IG11:                ;; offset=0x0209
       lea      rcx, [rbp-0x1C0]
       lea      rdx, [rbp-0x1D0]
       lea      rax, [rbp-0x1E0]
       mov      qword ptr [rsp+0x40], rax
       mov      r9, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG12:                ;; offset=0x0231
       vmovdqu  xmm0, xmmword ptr [rbp-0x110]
       vmovdqu  xmmword ptr [rbp-0x180], xmm0
 
G_M000_IG13:                ;; offset=0x0241
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
 
G_M000_IG14:                ;; offset=0x024D
       vmovdqu  xmm0, xmmword ptr [rbp-0x180]
       vmovdqu  xmmword ptr [rbp-0x1F0], xmm0
 
G_M000_IG15:                ;; offset=0x025D
       vmovdqu  ymm0, ymmword ptr [rbp-0x160]
       vmovdqu  ymmword ptr [rbp-0x210], ymm0
 
G_M000_IG16:                ;; offset=0x026D
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG17:                ;; offset=0x0279
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x220], xmm0
 
G_M000_IG18:                ;; offset=0x0285
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rax
       lea      rax, [rbp-0x140]
       mov      qword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0x1F0]
       lea      r8, [rbp-0x210]
       lea      rax, [rbp-0x220]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp+0x38]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG19:                ;; offset=0x02D5
       vzeroupper 
       add      rsp, 624
       pop      rbp
       ret      
 
G_M000_IG20:                ;; offset=0x02E1
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 743

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x470
       lea      rbp, [rsp+0x470]
       xor      eax, eax
       mov      qword ptr [rbp-0x408], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x400], xmm4
       mov      rax, -0x3F0
 
G_M000_IG103:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG103
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0056
       mov      rax, bword ptr [rbp+0x40]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
       mov      rdx, gword ptr [rbp+0x38]
       mov      rcx, 0x7FFA02847388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG04
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x270], rax
       mov      rdx, gword ptr [rbp-0x270]
       mov      rcx, 0x7FFA026F6F40
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x00C1
       mov      rcx, 0x7FFA029462D8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00D0
       xor      rax, rax
       mov      gword ptr [rbp-0x128], rax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x00DB
       mov      rcx, 0x7FFA029462DC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x128], rax
 
G_M000_IG06:                ;; offset=0x0108
       mov      rax, gword ptr [rbp-0x128]
       mov      gword ptr [rbp-0x10], rax
       mov      rdx, gword ptr [rbp+0x38]
       mov      rcx, 0x7FFA0286D848
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x18], rax
       cmp      gword ptr [rbp-0x18], 0
       je       SHORT G_M000_IG07
       mov      rcx, gword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Function():Lokad.Lython.Runtime.LythonRuntime+ICallable:this]
       mov      gword ptr [rbp-0x278], rax
       mov      rdx, gword ptr [rbp-0x278]
       mov      rcx, 0x7FFA02847388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x20], 0
       je       G_M000_IG10
       mov      rcx, 0x7FFA029462E0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Receiver():System.Object:this]
       mov      gword ptr [rbp-0x10], rax
 
G_M000_IG07:                ;; offset=0x0192
       cmp      gword ptr [rbp-0x08], 0
       je       G_M000_IG39
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG09
       lea      r9, [rbp-0x28]
       mov      rcx, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r8, gword ptr [rbp-0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG11
       mov      rcx, 0x7FFA029462E4
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG08:                ;; offset=0x01D1
       add      rsp, 0x470
       pop      rbp
       ret      
 
G_M000_IG09:                ;; offset=0x01DA
       mov      rcx, 0x7FFA029462E8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG39
 
G_M000_IG10:                ;; offset=0x01EE
       mov      rcx, 0x7FFA029462EC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG07
 
G_M000_IG11:                ;; offset=0x01FF
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
 
G_M000_IG12:                ;; offset=0x0204
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x280], rax
       mov      rdx, gword ptr [rbp-0x280]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x2C], 1
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x288], rax
       mov      rdx, gword ptr [rbp-0x288]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x208], rax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rbp-0x20C], eax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x28C], eax
       mov      r9d, dword ptr [rbp-0x28C]
       lea      rdx, [rbp-0x98]
       mov      r8d, dword ptr [rbp-0x20C]
       mov      rcx, bword ptr [rbp-0x208]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:Slice(int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       lea      rdx, [rbp-0x40]
       lea      rcx, [rbp-0x98]
       call     [System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_Span():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       cmp      gword ptr [rbp-0x10], 0
       jne      G_M000_IG20
 
G_M000_IG13:                ;; offset=0x02D1
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG14:                ;; offset=0x02DE
       lea      rdx, [rbp-0x2A0]
       lea      rcx, [rbp-0x258]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG15:                ;; offset=0x02F2
       vmovdqu  xmm0, xmmword ptr [rbp-0x258]
       vmovdqu  xmmword ptr [rbp-0x2B0], xmm0
 
G_M000_IG16:                ;; offset=0x0302
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2B8], rax
       movzx    rax, byte  ptr [rbp-0x28]
       mov      dword ptr [rsp+0x28], eax
       lea      rax, [rbp-0x50]
       mov      qword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp-0x2B8]
       mov      gword ptr [rsp+0x20], rax
       lea      r8, [rbp-0x2B0]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r9, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartNativeIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,byref):bool:this]
       test     eax, eax
       je       G_M000_IG19
       mov      rcx, 0x7FFA029462F0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG35
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x2D0], rax
 
G_M000_IG17:                ;; offset=0x03A6
       vmovdqu  xmm0, xmmword ptr [rbp-0x50]
       vmovdqu  xmmword ptr [rbp-0x2C8], xmm0
 
G_M000_IG18:                ;; offset=0x03B3
       mov      r8, bword ptr [rbp-0x2D0]
       lea      r9, [rbp-0x2C8]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0x9C], 1
       jmp      G_M000_IG36
 
G_M000_IG19:                ;; offset=0x03DE
       mov      rcx, 0x7FFA029462F4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG20:                ;; offset=0x03ED
       lea      rax, [rbp-0x68]
       mov      qword ptr [rsp+0x20], rax
       lea      rcx, [rbp-0x60]
       mov      rdx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PrepareUnpackedCallReturn(byref,Lokad.Lython.Frontend.ExecutableCallSite,int,byref):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG21:                ;; offset=0x040C
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG22:                ;; offset=0x0419
       lea      rdx, [rbp-0x2E0]
       lea      rcx, [rbp-0x220]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x228], rax
 
G_M000_IG23:                ;; offset=0x0440
       vmovdqu  xmm0, xmmword ptr [rbp-0x220]
       vmovdqu  xmmword ptr [rbp-0x2F0], xmm0
 
G_M000_IG24:                ;; offset=0x0450
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CallResultConsumedByIteration(byref,Lokad.Lython.Frontend.ExecutableCallSite):bool]
       mov      dword ptr [rbp-0x304], eax
       movzx    rax, byte  ptr [rbp-0x28]
       mov      dword ptr [rbp-0x308], eax
 
G_M000_IG25:                ;; offset=0x046E
       vmovdqu  xmm0, xmmword ptr [rbp-0x60]
       vmovdqu  xmmword ptr [rbp-0x300], xmm0
 
G_M000_IG26:                ;; offset=0x047B
       lea      rax, [rbp-0x70]
       mov      qword ptr [rsp+0x48], rax
       lea      rax, [rbp-0x80]
       mov      qword ptr [rsp+0x50], rax
       lea      rax, [rbp-0x88]
       mov      qword ptr [rsp+0x58], rax
       mov      eax, dword ptr [rbp-0x304]
       mov      dword ptr [rsp+0x30], eax
       lea      r8, [rbp-0x2F0]
       mov      eax, dword ptr [rbp-0x308]
       mov      dword ptr [rsp+0x38], eax
       lea      rax, [rbp-0x300]
       mov      qword ptr [rsp+0x40], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rsp+0x28], rax
       mov      rcx, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r9, gword ptr [rbp-0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       movzx    rax, byte  ptr [rbp-0x70]
       test     eax, eax
       jne      SHORT G_M000_IG27
       mov      rcx, 0x7FFA029462F8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp-0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RestoreNativeExtent(int):this]
 
G_M000_IG27:                ;; offset=0x0517
       cmp      gword ptr [rbp-0x88], 0
       je       G_M000_IG30
 
G_M000_IG28:                ;; offset=0x0525
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterExecutableSlots():this]
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x230], rax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x238], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x310], rax
       mov      rax, gword ptr [rbp-0x310]
       mov      gword ptr [rsp+0x30], rax
       mov      rdx, gword ptr [rbp-0x230]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [rbp+0x30]
       mov      rax, gword ptr [rbp-0x238]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp+0x20]
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AttachPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.LythonSourceSpan,int,Lokad.Lython.Runtime.MemoryGovernor):this]
       nop      
 
G_M000_IG29:                ;; offset=0x05AD
       mov      rcx, 0x7FFA029462FC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, gword ptr [rbp-0x88]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       mov      dword ptr [rbp-0x9C], 1
       jmp      G_M000_IG37
 
G_M000_IG30:                ;; offset=0x05E0
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       movzx    rax, byte  ptr [rbp-0x70]
       test     eax, eax
       je       SHORT G_M000_IG31
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8d, dword ptr [rbp+0x30]
       mov      r9d, dword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteUnpackedCallReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,int)]
       jmp      SHORT G_M000_IG34
 
G_M000_IG31:                ;; offset=0x0611
       mov      rcx, 0x7FFA02946300
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG35
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x330], rax
 
G_M000_IG32:                ;; offset=0x064D
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x328], xmm0
 
G_M000_IG33:                ;; offset=0x065A
       mov      r8, bword ptr [rbp-0x330]
       lea      r9, [rbp-0x328]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
 
G_M000_IG34:                ;; offset=0x0676
       mov      rcx, 0x7FFA02946304
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x9C], 1
       jmp      SHORT G_M000_IG38
 
G_M000_IG35:                ;; offset=0x0691
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG36:                ;; offset=0x0697
       call     G_M000_IG95
       jmp      G_M000_IG87
 
G_M000_IG37:                ;; offset=0x06A1
       call     G_M000_IG95
       jmp      G_M000_IG87
 
G_M000_IG38:                ;; offset=0x06AB
       call     G_M000_IG95
       jmp      G_M000_IG87
 
G_M000_IG39:                ;; offset=0x06B5
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG79
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       je       G_M000_IG44
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG45
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x340], rax
       mov      rdx, gword ptr [rbp-0x340]
       mov      rcx, 0x7FFA0286DD10
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xB0], rax
       cmp      gword ptr [rbp-0xB0], 0
       je       G_M000_IG43
       mov      rax, bword ptr [rbp+0x10]
       mov      bword ptr [rbp-0x1F8], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x200], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG40
       mov      rcx, 0x7FFA02946310
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x200], rax
 
G_M000_IG40:                ;; offset=0x0767
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp-0x1F8]
       mov      rdx, gword ptr [rbp-0x200]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteCasedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCasedSplit,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG42
       mov      rcx, 0x7FFA02946314
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG41:                ;; offset=0x07AE
       add      rsp, 0x470
       pop      rbp
       ret      
 
G_M000_IG42:                ;; offset=0x07B7
       mov      rcx, 0x7FFA02946318
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG45
 
G_M000_IG43:                ;; offset=0x07C8
       mov      rcx, 0x7FFA0294631C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG45
 
G_M000_IG44:                ;; offset=0x07D9
       mov      rcx, 0x7FFA02946320
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG79
 
G_M000_IG45:                ;; offset=0x07ED
       mov      rdx, gword ptr [rbp+0x38]
       mov      rcx, 0x7FFA0286E138
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xB8], rax
       cmp      gword ptr [rbp-0xB8], 0
       jne      SHORT G_M000_IG47
       mov      rcx, 0x7FFA02946324
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG46:                ;; offset=0x0823
       add      rsp, 0x470
       pop      rbp
       ret      
 
G_M000_IG47:                ;; offset=0x082C
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x348], rax
       mov      rdx, gword ptr [rbp-0x348]
       mov      rcx, 0x7FFA0286E440
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xC0], rax
       cmp      gword ptr [rbp-0xC0], 0
       je       SHORT G_M000_IG49
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteTrimmedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG48
       mov      rcx, 0x7FFA02946328
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x9C], 1
       jmp      G_M000_IG87
 
G_M000_IG48:                ;; offset=0x08BB
       mov      rcx, 0x7FFA0294632C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG49:                ;; offset=0x08CA
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rbp-0x150], rax
       mov      rax, gword ptr [rbp-0x148]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x350], rax
       mov      rdx, gword ptr [rbp-0x350]
       lea      rcx, [rbp-0x168]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 24
       mov      bword ptr [rbp-0x170], rax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rbp-0x178], rax
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rbp-0x17C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x188], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG50
       mov      rcx, 0x7FFA02946330
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x188], rax
 
G_M000_IG50:                ;; offset=0x0978
       vmovdqu  xmm0, xmmword ptr [rbp-0x168]
       vmovdqu  xmmword ptr [rbp-0x360], xmm0
 
G_M000_IG51:                ;; offset=0x0988
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp-0x17C]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp-0x188]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x38], rax
       lea      r8, [rbp-0x360]
       mov      rdx, gword ptr [rbp-0x158]
       mov      rcx, gword ptr [rbp-0x150]
       mov      r9, bword ptr [rbp-0x170]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG54
       mov      rcx, 0x7FFA02946334
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG78
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x378], rax
 
G_M000_IG52:                ;; offset=0x0A1C
       vmovdqu  xmm0, xmmword ptr [rbp-0xD0]
       vmovdqu  xmmword ptr [rbp-0x370], xmm0
 
G_M000_IG53:                ;; offset=0x0A2C
       mov      r8, bword ptr [rbp-0x378]
       lea      r9, [rbp-0x370]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0x9C], 1
       jmp      G_M000_IG87
 
G_M000_IG54:                ;; offset=0x0A57
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0xD8], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x190], rax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rbp-0x194], eax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x37C], eax
       mov      r9d, dword ptr [rbp-0x37C]
       lea      rdx, [rbp-0x98]
       mov      r8d, dword ptr [rbp-0x194]
       mov      rcx, bword ptr [rbp-0x190]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:Slice(int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       lea      rdx, [rbp-0xE8]
       lea      rcx, [rbp-0x98]
       call     [System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_Span():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG63
       mov      rcx, 0x7FFA0286E738
       call     [CORINFO_HELP_GET_GCSTATIC_BASE]
       mov      rax, 0x27B38C01C60
       mov      rax, gword ptr [rax]
       cmp      rax, gword ptr [rbp-0xB8]
       jne      G_M000_IG62
       mov      rdx, gword ptr [rbp-0xD8]
       mov      rcx, 0x7FFA025ACB28
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xF0], rax
       cmp      gword ptr [rbp-0xF0], 0
       je       G_M000_IG61
       cmp      dword ptr [rbp-0xE0], 2
       jg       G_M000_IG60
 
G_M000_IG55:                ;; offset=0x0B5E
       vmovdqu  xmm0, xmmword ptr [rbp-0xE8]
       vmovdqu  xmmword ptr [rbp-0x390], xmm0
 
G_M000_IG56:                ;; offset=0x0B6E
       lea      rdx, [rbp-0x390]
       lea      rcx, [rbp-0x1E8]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, gword ptr [rbp-0xF0]
       mov      gword ptr [rsp+0x28], rax
 
G_M000_IG57:                ;; offset=0x0B95
       vmovdqu  xmm0, xmmword ptr [rbp-0x1E8]
       vmovdqu  xmmword ptr [rbp-0x3A0], xmm0
 
G_M000_IG58:                ;; offset=0x0BA5
       lea      rax, [rbp-0x3A0]
       mov      qword ptr [rsp+0x30], rax
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp+0x18]
       mov      r9, gword ptr [rbp+0x28]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSplitUnpack(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool]
       test     eax, eax
       je       SHORT G_M000_IG59
       mov      rcx, 0x7FFA02946338
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x9C], 1
       jmp      G_M000_IG87
 
G_M000_IG59:                ;; offset=0x0BE9
       mov      rcx, 0x7FFA0294633C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG60:                ;; offset=0x0BFA
       mov      rcx, 0x7FFA02946340
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG61:                ;; offset=0x0C0B
       mov      rcx, 0x7FFA02946344
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG62:                ;; offset=0x0C1C
       mov      rcx, 0x7FFA02946348
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG63:                ;; offset=0x0C2B
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_AccumulatesDictionary():bool:this]
       test     eax, eax
       je       G_M000_IG71
       mov      eax, dword ptr [rbp-0xE0]
       mov      dword ptr [rbp-0x104], eax
       cmp      dword ptr [rbp-0x104], 1
       je       SHORT G_M000_IG65
       cmp      dword ptr [rbp-0x104], 2
       jne      G_M000_IG70
 
G_M000_IG64:                ;; offset=0x0C61
       mov      rcx, 0x7FFA0294634C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG65:                ;; offset=0x0C70
       mov      rcx, 0x7FFA0286E738
       call     [CORINFO_HELP_GET_GCSTATIC_BASE]
       mov      rax, 0x27B38C01C30
       mov      rax, gword ptr [rax]
       cmp      rax, gword ptr [rbp-0xB8]
       jne      G_M000_IG69
       mov      rdx, gword ptr [rbp-0xD8]
       mov      rcx, 0x7FFA02607AA0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xF8], rax
       cmp      gword ptr [rbp-0xF8], 0
       je       G_M000_IG68
       cmp      dword ptr [rbp-0xE0], 0
       jbe      G_M000_IG78
       mov      rcx, bword ptr [rbp-0xE8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x3A8], rax
       mov      rdx, gword ptr [rbp-0x3A8]
       mov      rcx, gword ptr [rbp-0xF8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG67
       cmp      dword ptr [rbp-0xE0], 0
       jbe      G_M000_IG78
       mov      rcx, bword ptr [rbp-0xE8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x3B0], rax
       mov      rdx, gword ptr [rbp-0x3B0]
       mov      rcx, 0x7FFA025ACB28
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x3B8], rax
       mov      rax, gword ptr [rbp-0x3B8]
       mov      gword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [rbp+0x30]
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryAccumulation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.PyDict,Lokad.Lython.Runtime.Text.PyString):bool]
       test     eax, eax
       je       SHORT G_M000_IG66
       mov      rcx, 0x7FFA02946350
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x9C], 1
       jmp      G_M000_IG87
 
G_M000_IG66:                ;; offset=0x0D94
       mov      rcx, 0x7FFA02946354
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG71
 
G_M000_IG67:                ;; offset=0x0DA5
       mov      rcx, 0x7FFA02946358
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG71
 
G_M000_IG68:                ;; offset=0x0DB6
       mov      rcx, 0x7FFA0294635C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG71
 
G_M000_IG69:                ;; offset=0x0DC7
       mov      rcx, 0x7FFA02946360
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG71
 
G_M000_IG70:                ;; offset=0x0DD8
       mov      rcx, 0x7FFA02946364
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG71:                ;; offset=0x0DE7
       vmovdqu  xmm0, xmmword ptr [rbp-0xE8]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG72:                ;; offset=0x0DF7
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rbp-0x1B0], rax
       mov      rax, gword ptr [rbp-0xD8]
       mov      gword ptr [rbp-0x1B8], rax
 
G_M000_IG73:                ;; offset=0x0E13
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A8]
       vmovdqu  xmmword ptr [rbp-0x1C8], xmm0
 
G_M000_IG74:                ;; offset=0x0E23
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x1D8], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG75
       mov      rcx, 0x7FFA02946368
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x1D8], rax
 
G_M000_IG75:                ;; offset=0x0E62
       vmovdqu  xmm0, xmmword ptr [rbp-0x1C8]
       vmovdqu  xmmword ptr [rbp-0x3C8], xmm0
 
G_M000_IG76:                ;; offset=0x0E72
       mov      rax, gword ptr [rbp-0x1D8]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x100]
       mov      qword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x3C8]
       mov      rdx, gword ptr [rbp-0x1B8]
       mov      rcx, gword ptr [rbp-0x1B0]
       mov      r9, gword ptr [rbp-0x1D0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG77
       mov      rcx, 0x7FFA0294636C
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x9C], eax
       jmp      G_M000_IG87
 
G_M000_IG77:                ;; offset=0x0ECC
       mov      rcx, 0x7FFA02946370
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG78
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x3D0], rax
       mov      r8, bword ptr [rbp-0x3D0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp-0x100]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       mov      dword ptr [rbp-0x9C], 1
       jmp      G_M000_IG87
 
G_M000_IG78:                ;; offset=0x0F33
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG79:                ;; offset=0x0F39
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x3D8], rax
       mov      rdx, gword ptr [rbp-0x3D8]
       lea      rcx, [rbp-0x138]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG80:                ;; offset=0x0F68
       vmovdqu  xmm0, xmmword ptr [rbp-0x138]
       vmovdqu  xmmword ptr [rbp-0x3E8], xmm0
 
G_M000_IG81:                ;; offset=0x0F78
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       cmp      gword ptr [rbp+0x20], 0
       setne    al
       movzx    rax, al
       mov      dword ptr [rsp+0x28], eax
       lea      rax, [rbp-0x118]
       mov      qword ptr [rsp+0x30], rax
       lea      r8, [rbp-0x3E8]
       mov      rdx, gword ptr [rbp+0x38]
       mov      rcx, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG82
       xor      eax, eax
       mov      dword ptr [rbp-0x9C], eax
       jmp      G_M000_IG87
 
G_M000_IG82:                ;; offset=0x0FC6
       lea      rcx, [rbp-0x118]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x268], rax
       mov      rcx, gword ptr [rbp-0x268]
       mov      rdx, 0x7FFA02946378
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x268]
       mov      gword ptr [rbp-0x3F0], rax
       mov      rdx, gword ptr [rbp-0x3F0]
       mov      rcx, 0x7FFA024EE760
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x120], rax
       cmp      gword ptr [rbp-0x120], 0
       je       SHORT G_M000_IG84
       mov      rcx, 0x7FFA02946480
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, gword ptr [rbp-0x120]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0x9C], 1
       jmp      SHORT G_M000_IG87
 
G_M000_IG83:                ;; offset=0x1068
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG84:                ;; offset=0x106E
       mov      rcx, 0x7FFA02946484
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG83
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x408], rax
 
G_M000_IG85:                ;; offset=0x10AA
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x400], xmm0
 
G_M000_IG86:                ;; offset=0x10BA
       mov      r8, bword ptr [rbp-0x408]
       lea      r9, [rbp-0x400]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0x9C], 1
 
G_M000_IG87:                ;; offset=0x10E0
       mov      rcx, 0x7FFA02946488
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x9C]
 
G_M000_IG88:                ;; offset=0x10F5
       add      rsp, 0x470
       pop      rbp
       ret      
 
G_M000_IG89:                ;; offset=0x10FE
       sub      rsp, 104
 
G_M000_IG90:                ;; offset=0x1102
       mov      gword ptr [rbp-0x240], rcx
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x248], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x318], rax
       mov      rdx, gword ptr [rbp-0x318]
       mov      rcx, gword ptr [rbp-0x248]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AbortPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG91:                ;; offset=0x114F
       sub      rsp, 104
 
G_M000_IG92:                ;; offset=0x1153
       mov      gword ptr [rbp-0x260], rcx
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x338], rax
       mov      rdx, gword ptr [rbp-0x338]
       lea      r8, [rbp-0xA8]
       mov      rcx, gword ptr [rbp-0x260]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG94
 
G_M000_IG93:                ;; offset=0x11A3
       mov      rcx, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG94:                ;; offset=0x11B0
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG95:                ;; offset=0x11B6
       sub      rsp, 104
 
G_M000_IG96:                ;; offset=0x11BA
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG97
       mov      rcx, 0x7FFA02946308
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG97:                ;; offset=0x11DB
       mov      rcx, 0x7FFA0294630C
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG98:                ;; offset=0x11EB
       add      rsp, 104
       ret      
 
G_M000_IG99:                ;; offset=0x11F0
       sub      rsp, 104
 
G_M000_IG100:                ;; offset=0x11F4
       mov      gword ptr [rbp-0x1F0], rcx
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG101:                ;; offset=0x1218
       sub      rsp, 104
 
G_M000_IG102:                ;; offset=0x121C
       mov      gword ptr [rbp-0x140], rcx
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 4672

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TryStartNativeIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 128
       lea      rbp, [rsp+0x80]
       xor      eax, eax
       mov      qword ptr [rbp-0x48], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqa  xmmword ptr [rbp-0x20], xmm4
       mov      qword ptr [rbp-0x10], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0038
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       mov      rcx, 0x7FFA029468D0
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x006F
       add      rsp, 128
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x0078
       movzx    rax, byte  ptr [rbp+0x38]
       test     eax, eax
       jne      SHORT G_M000_IG08
       mov      rcx, 0x7FFA029468D4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x0093
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x28], xmm0
 
G_M000_IG06:                ;; offset=0x009C
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x28]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       nop      
 
G_M000_IG07:                ;; offset=0x00C5
       add      rsp, 128
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x00CE
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x04], eax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x04]
       jne      SHORT G_M000_IG14
       mov      rcx, 0x7FFA029468D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG09:                ;; offset=0x0105
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x38], xmm0
 
G_M000_IG10:                ;; offset=0x010E
       lea      rdx, [rbp-0x38]
       lea      rcx, [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
 
G_M000_IG11:                ;; offset=0x011C
       vmovdqu  xmm0, xmmword ptr [rbp-0x18]
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
 
G_M000_IG12:                ;; offset=0x0126
       lea      rdx, [rbp-0x48]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x30]
       mov      r9, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       nop      
 
G_M000_IG13:                ;; offset=0x013D
       add      rsp, 128
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x0146
       mov      rcx, 0x7FFA029468DC
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG15:                ;; offset=0x0157
       add      rsp, 128
       pop      rbp
       ret      
 
; Total bytes of code 352

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 624
       lea      rbp, [rsp+0x270]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x220], xmm4
       mov      rax, -528
 
G_M000_IG22:                ;; offset=0x0026
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG22
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x004D
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
       vmovdqu  ymmword ptr [rbp-0xE0], ymm0
       vmovdqu  ymmword ptr [rbp-0xC0], ymm0
       vmovdqu  ymmword ptr [rbp-0xA0], ymm0
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  ymmword ptr [rbp-0x40], ymm0
       vmovdqu  ymmword ptr [rbp-0x20], ymm0
       lea      rdx, [rbp-0x100]
       lea      rcx, [rbp-0x110]
       mov      r8d, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x198], eax
       mov      r9d, dword ptr [rbp-0x198]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x110]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       je       G_M000_IG06
       xor      eax, eax
       mov      dword ptr [rbp-0x114], eax
       cmp      gword ptr [rbp+0x28], 0
       je       SHORT G_M000_IG03
       mov      rcx, 0x7FFA02947E18
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x114]
       mov      dword ptr [rbp-0x194], eax
       mov      eax, dword ptr [rbp-0x114]
       inc      eax
       mov      dword ptr [rbp-0x114], eax
       mov      eax, dword ptr [rbp-0x108]
       cmp      dword ptr [rbp-0x194], eax
       jae      G_M000_IG21
       mov      eax, dword ptr [rbp-0x194]
       shl      rax, 4
       mov      rcx, rax
       add      rcx, bword ptr [rbp-0x110]
       mov      rdx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG03:                ;; offset=0x014C
       lea      rdx, [rbp-0x190]
       lea      rcx, [rbp-0x110]
       mov      r8d, dword ptr [rbp-0x114]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG04:                ;; offset=0x0167
       vmovdqu  xmm0, xmmword ptr [rbp-0x190]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG05:                ;; offset=0x0177
       lea      rdx, [rbp-0x1A8]
       mov      rcx, bword ptr [rbp+0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG12
 
G_M000_IG06:                ;; offset=0x018D
       mov      rcx, 0x7FFA02947E1C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x1AC], eax
       mov      r9d, dword ptr [rbp-0x1AC]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x170]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG07:                ;; offset=0x01D6
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0x1C0], xmm0
 
G_M000_IG08:                ;; offset=0x01E6
       vmovdqu  xmm0, xmmword ptr [rbp-0x128]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG09:                ;; offset=0x01F6
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG10:                ;; offset=0x021B
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
 
G_M000_IG11:                ;; offset=0x0227
       lea      rcx, [rbp-0x1C0]
       lea      rdx, [rbp-0x1D0]
       lea      rax, [rbp-0x1E0]
       mov      qword ptr [rsp+0x40], rax
       mov      r9, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG12:                ;; offset=0x024F
       mov      rcx, 0x7FFA02947E20
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG13:                ;; offset=0x025E
       vmovdqu  xmm0, xmmword ptr [rbp-0x110]
       vmovdqu  xmmword ptr [rbp-0x180], xmm0
 
G_M000_IG14:                ;; offset=0x026E
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
 
G_M000_IG15:                ;; offset=0x027A
       vmovdqu  xmm0, xmmword ptr [rbp-0x180]
       vmovdqu  xmmword ptr [rbp-0x1F0], xmm0
 
G_M000_IG16:                ;; offset=0x028A
       vmovdqu  ymm0, ymmword ptr [rbp-0x160]
       vmovdqu  ymmword ptr [rbp-0x210], ymm0
 
G_M000_IG17:                ;; offset=0x029A
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG18:                ;; offset=0x02A6
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x220], xmm0
 
G_M000_IG19:                ;; offset=0x02B2
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rax
       lea      rax, [rbp-0x140]
       mov      qword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0x1F0]
       lea      r8, [rbp-0x210]
       lea      rax, [rbp-0x220]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp+0x38]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG20:                ;; offset=0x0302
       vzeroupper 
       add      rsp, 624
       pop      rbp
       ret      
 
G_M000_IG21:                ;; offset=0x030E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 788

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 23860
; 26 inlinees with PGO data; 132 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 424
       lea      rbp, [rsp+0x1E0]
       xor      eax, eax
       mov      qword ptr [rbp-0x158], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x150], xmm4
       vmovdqa  xmmword ptr [rbp-0x140], xmm4
       mov      rax, -240
 
G_M000_IG142:                ;; offset=0x0042
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG142
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x28], r9
       mov      rbx, r8
       mov      rsi, gword ptr [rbp+0x38]
 
G_M000_IG02:                ;; offset=0x006D
       xor      rdx, rdx
       mov      rdi, bword ptr [rbp+0x40]
       mov      gword ptr [rdi], rdx
       test     rsi, rsi
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x007B
       mov      rdx, 0x7FFA02847388
       cmp      qword ptr [rsi], rdx
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x008A
       mov      gword ptr [rbp-0x160], rsi
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0093
       xor      rdx, rdx
       mov      gword ptr [rbp-0x160], rdx
 
G_M000_IG06:                ;; offset=0x009C
       cmp      byte  ptr [r9+0x30], 0
       jne      G_M000_IG88
 
G_M000_IG07:                ;; offset=0x00A7
       xor      r14, r14
 
G_M000_IG08:                ;; offset=0x00AA
       test     rsi, rsi
       je       SHORT G_M000_IG14
 
G_M000_IG09:                ;; offset=0x00AF
       mov      rdx, 0x7FFA0286D848
       cmp      qword ptr [rsi], rdx
       jne      SHORT G_M000_IG14
 
G_M000_IG10:                ;; offset=0x00BE
       mov      rdx, gword ptr [rsi+0x10]
       test     rdx, rdx
       je       SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x00C7
       mov      rax, 0x7FFA02847388
       xor      r8, r8
       cmp      qword ptr [rdx], rax
       cmovne   rdx, r8
 
G_M000_IG12:                ;; offset=0x00DB
       test     rdx, rdx
       je       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x00E0
       mov      gword ptr [rbp-0x160], rdx
       mov      r14, gword ptr [rsi+0x08]
 
G_M000_IG14:                ;; offset=0x00EB
       cmp      gword ptr [rbp-0x160], 0
       je       G_M000_IG89
 
G_M000_IG15:                ;; offset=0x00F9
       test     rbx, rbx
       je       G_M000_IG92
       mov      rdx, gword ptr [rbp-0x160]
       mov      rdx, gword ptr [rdx+0x40]
       cmp      byte  ptr [rdx+0xDF], 0
       je       G_M000_IG90
       mov      rax, gword ptr [rbp-0x160]
       mov      rax, gword ptr [rax+0x28]
       cmp      byte  ptr [rax+0xFA], 0
       jne      G_M000_IG90
       cmp      byte  ptr [rax+0xFB], 0
       jne      G_M000_IG90
       cmp      byte  ptr [rax+0xFC], 0
       jne      G_M000_IG90
       cmp      gword ptr [rax+0xC0], 0
       jne      G_M000_IG90
       cmp      dword ptr [rdx+0xD4], 16
       jg       G_M000_IG90
       mov      r9, gword ptr [rbp+0x28]
       cmp      byte  ptr [r9+0x34], 0
       je       G_M000_IG93
       mov      edx, dword ptr [r9+0x28]
       mov      rax, gword ptr [rbp-0x160]
       mov      rax, gword ptr [rax+0x08]
       cmp      byte  ptr [rax+0x54], 0
       je       G_M000_IG83
 
G_M000_IG16:                ;; offset=0x018F
       mov      eax, dword ptr [rax+0x3C]
       test     r14, r14
       setne    r8b
       movzx    r8, r8b
       sub      eax, r8d
       cmp      eax, edx
       sete     sil
       movzx    rsi, sil
 
G_M000_IG17:                ;; offset=0x01AA
       test     esi, esi
       je       G_M000_IG84
 
G_M000_IG18:                ;; offset=0x01B2
       mov      rcx, bword ptr [rbp+0x10]
       xor      edx, edx
       mov      dword ptr [rbp-0x3C], edx
 
G_M000_IG19:                ;; offset=0x01BB
       mov      r9, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [r9+0x18]
       mov      r15, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [r15+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x3C], 1
       mov      r9, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [r9+0x18]
       mov      rcx, gword ptr [r15+0x98]
       mov      rax, gword ptr [rcx+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG61
       mov      rax, gword ptr [rcx+0x180]
       test     rax, rax
       jne      G_M000_IG60
 
G_M000_IG20:                ;; offset=0x020E
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x20]
       mov      r9, gword ptr [rbp+0x28]
       cmp      byte  ptr [r9+0x30], 0
       setne    al
       movzx    rax, al
       mov      r8d, dword ptr [rbp+0x30]
       lea      r13d, [r8+rax+0x01]
       mov      r12d, dword ptr [r9+0x28]
       mov      rdx, gword ptr [rdx]
       test     rdx, rdx
       je       G_M000_IG62
       mov      r8d, dword ptr [rbp+0x30]
       mov      eax, r13d
       mov      r10d, r12d
       add      rax, r10
       mov      r10d, dword ptr [rdx+0x08]
       cmp      rax, r10
       ja       G_M000_IG63
       mov      rax, rdx
 
G_M000_IG21:                ;; offset=0x025B
       xor      r10, r10
       xor      r11d, r11d
       test     rax, rax
       je       SHORT G_M000_IG24
 
G_M000_IG22:                ;; offset=0x0266
       mov      r10, qword ptr [rax]
       test     dword ptr [r10], 0xFFFFFFFF80000000
       je       G_M000_IG65
       lea      r10, bword ptr [rax+0x10]
       mov      r11d, dword ptr [rax+0x08]
 
G_M000_IG23:                ;; offset=0x027E
       and      r13d, 0x7FFFFFFF
       mov      edx, r13d
       mov      eax, r12d
       add      rax, rdx
       mov      r11d, r11d
       cmp      rax, r11
       ja       G_M000_IG63
       shl      rdx, 4
       add      r10, rdx
       mov      bword ptr [rbp-0x178], r10
       mov      r11d, r12d
       mov      r10, bword ptr [rbp-0x178]
 
G_M000_IG24:                ;; offset=0x02B2
       test     r14, r14
       jne      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x02B7
       mov      r9, gword ptr [rbp+0x28]
       mov      r13, gword ptr [r9+0x18]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
       mov      rdx, gword ptr [rbp-0x160]
       mov      rdx, gword ptr [rdx+0x40]
       cmp      byte  ptr [rdx+0xE0], 0
       jne      G_M000_IG37
 
G_M000_IG26:                ;; offset=0x02E0
       mov      r8d, dword ptr [rbp+0x30]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r13d, dword ptr [rcx+0x60]
       mov      r9, gword ptr [rbp+0x28]
       cmp      dword ptr [r9+0x2C], 0
       jne      G_M000_IG71
 
G_M000_IG27:                ;; offset=0x02FB
       mov      r9, gword ptr [rbp+0x28]
       xor      rdx, rdx
       xor      r12d, r12d
 
G_M000_IG28:                ;; offset=0x0304
       mov      rax, gword ptr [r9+0x18]
       cmp      byte  ptr [r9+0x31], 0
       jne      G_M000_IG76
       cmp      byte  ptr [rcx+0x1C], 0
       jne      G_M000_IG75
       xor      edi, edi
 
G_M000_IG29:                ;; offset=0x031F
       mov      bword ptr [rbp-0x148], r10
       mov      dword ptr [rbp-0x140], r11d
       mov      gword ptr [rsp+0x20], r15
       mov      gword ptr [rsp+0x28], rax
       mov      dword ptr [rsp+0x30], edi
       mov      dword ptr [rsp+0x38], esi
       mov      bword ptr [rbp-0x128], rdx
       mov      dword ptr [rbp-0x120], r12d
       lea      rdx, [rbp-0x58]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x68]
       mov      qword ptr [rsp+0x50], rdx
       lea      rdx, [rbp-0x70]
       mov      qword ptr [rsp+0x58], rdx
       lea      r8, [rbp-0x148]
       lea      rdx, [rbp-0x128]
       mov      qword ptr [rsp+0x40], rdx
       mov      rcx, gword ptr [rbp-0x160]
       mov      r9, r14
       mov      rdx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       cmp      byte  ptr [rbp-0x58], 0
       jne      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x0395
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x60], r13d
 
G_M000_IG31:                ;; offset=0x039D
       cmp      gword ptr [rbp-0x70], 0
       jne      G_M000_IG77
       mov      r9, gword ptr [r15+0x98]
       mov      rdx, qword ptr [r9+0x160]
       test     rdx, rdx
       jle      SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x03BB
       dec      rdx
       mov      qword ptr [r9+0x160], rdx
 
G_M000_IG33:                ;; offset=0x03C5
       xor      r9d, r9d
       mov      dword ptr [rbp-0x3C], r9d
       cmp      byte  ptr [rbp-0x58], 0
       jne      G_M000_IG80
 
G_M000_IG34:                ;; offset=0x03D6
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x88]
       mov      edx, dword ptr [rcx+0x18]
       cmp      edx, dword ptr [r9+0x08]
       jae      G_M000_IG79
       shl      rdx, 5
       lea      r12, bword ptr [r9+rdx+0x10]
       mov      rsi, gword ptr [rbp-0x68]
       mov      rdi, qword ptr [rbp-0x60]
       cmp      dword ptr [r12+0x18], 0
       jge      G_M000_IG51
 
G_M000_IG35:                ;; offset=0x040E
       mov      gword ptr [rbp-0x138], rsi
       mov      qword ptr [rbp-0x130], rdi
       lea      r9, [rbp-0x138]
       mov      rdx, rbx
       mov      r8, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
 
G_M000_IG36:                ;; offset=0x042F
       mov      eax, 1
       jmp      G_M000_IG82
 
G_M000_IG37:                ;; offset=0x0439
       test     esi, esi
       jne      G_M000_IG69
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
       cmp      byte  ptr [r9+0x34], 0
       je       G_M000_IG67
       mov      rdx, gword ptr [rbp-0x160]
       mov      rdx, gword ptr [rdx+0x08]
       mov      rdx, gword ptr [rdx+0x08]
       mov      edx, dword ptr [rdx+0x08]
       mov      rax, gword ptr [rbp-0x160]
       mov      rax, gword ptr [rax+0x40]
       cmp      edx, dword ptr [rax+0xC4]
       jne      G_M000_IG67
       mov      bword ptr [rbp-0x178], r10
       mov      rcx, gword ptr [rbp-0x160]
       mov      dword ptr [rbp-0xC4], r11d
       mov      edx, r11d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       G_M000_IG66
       mov      r12, gword ptr [r15+0x98]
       cmp      byte  ptr [r12], r12b
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       G_M000_IG68
 
G_M000_IG38:                ;; offset=0x04C0
       mov      r9, gword ptr [rbp-0x160]
       mov      gword ptr [rbp-0xF0], r9
       mov      r12, bword ptr [rbp-0x178]
       mov      bword ptr [rbp-0xE8], r12
       mov      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rbp-0xE0], eax
       lea      r9, [rbp-0x50]
       lea      rdx, [rbp-0xF0]
       mov      rcx, gword ptr [rbp-0x160]
       mov      r8, r13
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      r8d, dword ptr [rbp+0x30]
 
G_M000_IG39:                ;; offset=0x0507
       test     eax, eax
       mov      r10, r12
       mov      r11d, dword ptr [rbp-0xC4]
       je       G_M000_IG26
 
G_M000_IG40:                ;; offset=0x0519
       mov      rcx, gword ptr [r15+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       xor      r9d, r9d
       mov      dword ptr [rbp-0x3C], r9d
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x88]
       mov      edx, dword ptr [rcx+0x18]
       cmp      edx, dword ptr [r9+0x08]
       jae      G_M000_IG79
       shl      rdx, 5
       lea      rsi, bword ptr [r9+rdx+0x10]
       mov      r14, gword ptr [rbp-0x50]
       mov      rdi, qword ptr [rbp-0x48]
       cmp      dword ptr [rsi+0x18], 0
       jge      SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x0561
       mov      gword ptr [rbp-0x138], r14
       mov      qword ptr [rbp-0x130], rdi
       lea      r9, [rbp-0x138]
       mov      rdx, rbx
       mov      r8, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG36
 
G_M000_IG42:                ;; offset=0x0587
       lea      rbx, bword ptr [rcx+0x20]
       mov      eax, dword ptr [rsi+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x0593
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG70
 
G_M000_IG44:                ;; offset=0x05A7
       mov      r13d, dword ptr [rsi+0x14]
 
G_M000_IG45:                ;; offset=0x05AB
       mov      esi, dword ptr [rsi+0x18]
       test     esi, esi
       jge      SHORT G_M000_IG50
 
G_M000_IG46:                ;; offset=0x05B2
       not      esi
 
G_M000_IG47:                ;; offset=0x05B4
       cmp      esi, dword ptr [rbx+0x40]
       jge      SHORT G_M000_IG49
 
G_M000_IG48:                ;; offset=0x05B9
       mov      rcx, rbx
       mov      edx, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG49:                ;; offset=0x05C4
       mov      rdx, gword ptr [rbx]
       cmp      r13d, dword ptr [rdx+0x08]
       jae      G_M000_IG79
       mov      eax, r13d
       shl      rax, 4
       lea      r13, bword ptr [rdx+rax+0x10]
       mov      rcx, r13
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r13+0x08], rdi
       mov      dword ptr [rbx+0x40], esi
       jmp      G_M000_IG36
 
G_M000_IG50:                ;; offset=0x05F4
       jmp      SHORT G_M000_IG47
 
G_M000_IG51:                ;; offset=0x05F6
       lea      rbx, bword ptr [rcx+0x20]
       mov      eax, dword ptr [r12+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x0604
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG81
 
G_M000_IG53:                ;; offset=0x0618
       mov      r14d, dword ptr [r12+0x14]
 
G_M000_IG54:                ;; offset=0x061D
       mov      r13d, dword ptr [r12+0x18]
       test     r13d, r13d
       jge      SHORT G_M000_IG59
 
G_M000_IG55:                ;; offset=0x0627
       not      r13d
 
G_M000_IG56:                ;; offset=0x062A
       cmp      r13d, dword ptr [rbx+0x40]
       jge      SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x0630
       mov      rcx, rbx
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG58:                ;; offset=0x063C
       mov      rdx, gword ptr [rbx]
       cmp      r14d, dword ptr [rdx+0x08]
       jae      G_M000_IG79
       mov      eax, r14d
       shl      rax, 4
       lea      r14, bword ptr [rdx+rax+0x10]
       mov      rcx, r14
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r14+0x08], rdi
       mov      dword ptr [rbx+0x40], r13d
       jmp      G_M000_IG36
 
G_M000_IG59:                ;; offset=0x066D
       jmp      SHORT G_M000_IG56
 
G_M000_IG60:                ;; offset=0x066F
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG20
 
G_M000_IG61:                ;; offset=0x0681
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG20
 
G_M000_IG62:                ;; offset=0x068C
       mov      r8d, dword ptr [rbp+0x30]
       mov      eax, r13d
       or       eax, r12d
       je       SHORT G_M000_IG64
 
G_M000_IG63:                ;; offset=0x0698
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG64:                ;; offset=0x069F
       xor      rax, rax
       xor      r13d, r13d
       xor      r12d, r12d
       jmp      G_M000_IG21
 
G_M000_IG65:                ;; offset=0x06AC
       lea      rdx, [rbp-0xD8]
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r10, bword ptr [rbp-0xD8]
       mov      rcx, r10
       mov      r11d, dword ptr [rbp-0xD0]
       mov      eax, r11d
       mov      r10, rcx
       mov      r11d, eax
       mov      r8d, dword ptr [rbp+0x30]
       jmp      G_M000_IG23
 
G_M000_IG66:                ;; offset=0x06E3
       mov      r8d, dword ptr [rbp+0x30]
       mov      r10, bword ptr [rbp-0x178]
       mov      r11d, dword ptr [rbp-0xC4]
 
G_M000_IG67:                ;; offset=0x06F5
       xor      eax, eax
       mov      dword ptr [rbp-0xC4], r11d
       mov      r12, r10
       jmp      G_M000_IG39
 
G_M000_IG68:                ;; offset=0x0706
       mov      rcx, r12
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG38
 
G_M000_IG69:                ;; offset=0x0717
       mov      rdx, gword ptr [rbp-0x160]
       mov      rdx, gword ptr [rdx+0x40]
       cmp      r11d, dword ptr [rdx+0xC4]
       jne      G_M000_IG26
       mov      bword ptr [rbp-0x178], r10
       mov      bword ptr [rbp-0x158], r10
       mov      dword ptr [rbp-0xC4], r11d
       mov      dword ptr [rbp-0x150], r11d
       lea      rdx, [rbp-0x158]
       lea      r9, [rbp-0x50]
       mov      rcx, gword ptr [rbp-0x160]
       mov      r8, r13
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       mov      r10, bword ptr [rbp-0x178]
       mov      r11d, dword ptr [rbp-0xC4]
       je       G_M000_IG26
       jmp      G_M000_IG40
 
G_M000_IG70:                ;; offset=0x0781
       mov      rcx, rsi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r13d, eax
       jmp      G_M000_IG45
 
G_M000_IG71:                ;; offset=0x0792
       cmp      dword ptr [r9+0x28], 16
       jg       G_M000_IG27
       mov      dword ptr [rbp-0xC4], r11d
       mov      bword ptr [rbp-0x178], r10
       add      rcx, 32
       mov      edx, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:CanRetireWithoutCleanup(int):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG72
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8d, dword ptr [rbp+0x30]
       mov      r10, bword ptr [rbp-0x178]
       mov      r11d, dword ptr [rbp-0xC4]
       jmp      G_M000_IG27
 
G_M000_IG72:                ;; offset=0x07D7
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x20]
       mov      r9, gword ptr [rbp+0x28]
       mov      edx, dword ptr [r9+0x2C]
       test     rax, rax
       jne      SHORT G_M000_IG73
       mov      r8d, dword ptr [rbp+0x30]
       or       edx, r8d
       jne      G_M000_IG63
       xor      rdx, rdx
       xor      r12d, r12d
       jmp      SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x0800
       mov      r8d, dword ptr [rbp+0x30]
       mov      r10d, r8d
       mov      r11d, edx
       add      r10, r11
       mov      r11d, dword ptr [rax+0x08]
       cmp      r10, r11
       ja       G_M000_IG63
       mov      r10d, r8d
       shl      r10, 4
       lea      rax, bword ptr [rax+r10+0x10]
       mov      r12d, edx
       mov      rdx, rax
 
G_M000_IG74:                ;; offset=0x082C
       lea      rax, bword ptr [rcx+0x20]
       lea      r10d, [r8+r12]
       cmp      r13d, r10d
       cmovge   r10d, r13d
       mov      dword ptr [rax+0x40], r10d
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8d, dword ptr [rbp+0x30]
       mov      r9, gword ptr [rbp+0x28]
       mov      r10, bword ptr [rbp-0x178]
       mov      r11d, dword ptr [rbp-0xC4]
       jmp      G_M000_IG28
 
G_M000_IG75:                ;; offset=0x085E
       movzx    rdi, byte  ptr [r9+0x32]
       jmp      G_M000_IG29
 
G_M000_IG76:                ;; offset=0x0868
       mov      edi, 1
       jmp      G_M000_IG29
 
G_M000_IG77:                ;; offset=0x0872
       mov      rcx, gword ptr [rbp-0x70]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterExecutableSlots():this]
       mov      rdx, gword ptr [rbp-0x70]
       mov      r9, gword ptr [rbp+0x28]
       mov      rcx, gword ptr [r9+0x18]
       mov      r8, gword ptr [rbp-0x160]
       mov      r8, gword ptr [r8+0x28]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      rcx, gword ptr [r8+0x98]
       mov      rcx, gword ptr [rcx+0x88]
       mov      gword ptr [rsp+0x30], rcx
       mov      rcx, rbx
       mov      r8, r9
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AttachPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.LythonSourceSpan,int,Lokad.Lython.Runtime.MemoryGovernor):this]
       nop      
 
G_M000_IG78:                ;; offset=0x08C4
       mov      rdx, gword ptr [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x40]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      dword ptr [rbp-0x3C], ecx
       jmp      G_M000_IG36
 
G_M000_IG79:                ;; offset=0x08DB
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG80:                ;; offset=0x08E1
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, r15
       mov      r8d, dword ptr [rbp+0x30]
       mov      r9d, r12d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteUnpackedCallReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,int)]
       jmp      G_M000_IG36
 
G_M000_IG81:                ;; offset=0x08FA
       mov      rcx, r12
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       jmp      G_M000_IG54
 
G_M000_IG82:                ;; offset=0x090B
       add      rsp, 424
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG83:                ;; offset=0x091F
       xor      esi, esi
       jmp      G_M000_IG17
 
G_M000_IG84:                ;; offset=0x0926
       mov      rdx, gword ptr [rbp-0x160]
       mov      rax, gword ptr [rdx+0x08]
       mov      rdx, gword ptr [rax+0x08]
       cmp      dword ptr [rdx+0x08], 16
       jg       G_M000_IG90
       cmp      dword ptr [rax+0x4C], 0
       jge      G_M000_IG90
       cmp      dword ptr [rax+0x50], 0
       jge      G_M000_IG90
       mov      rdx, gword ptr [rbp-0x160]
       mov      rdx, gword ptr [rdx+0x18]
       test     rdx, rdx
       je       SHORT G_M000_IG87
 
G_M000_IG85:                ;; offset=0x0963
       mov      rax, rdx
       mov      r8, 0x7FFA0287EAC0
       cmp      qword ptr [rax], r8
       jne      G_M000_IG94
 
G_M000_IG86:                ;; offset=0x0979
       test     rax, rax
       je       SHORT G_M000_IG90
 
G_M000_IG87:                ;; offset=0x097E
       mov      rcx, gword ptr [rbp-0x160]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       test     rax, rax
       je       G_M000_IG18
       jmp      G_M000_IG95
 
G_M000_IG88:                ;; offset=0x0999
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FFA026F6F40
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       mov      rcx, bword ptr [rbp+0x10]
       jne      G_M000_IG07
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      r14, rax
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG08
 
G_M000_IG89:                ;; offset=0x09E0
       mov      rdi, bword ptr [rbp+0x40]
       jmp      SHORT G_M000_IG96
 
G_M000_IG90:                ;; offset=0x09E6
       xor      eax, eax
 
G_M000_IG91:                ;; offset=0x09E8
       add      rsp, 424
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG92:                ;; offset=0x09FC
       mov      rdi, bword ptr [rbp+0x40]
       jmp      SHORT G_M000_IG96
 
G_M000_IG93:                ;; offset=0x0A02
       xor      esi, esi
       jmp      G_M000_IG17
 
G_M000_IG94:                ;; offset=0x0A09
       mov      rcx, 0x7FFA027D1128
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG86
 
G_M000_IG95:                ;; offset=0x0A21
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       sete     cl
       movzx    rcx, cl
       test     ecx, ecx
       je       G_M000_IG18
       jmp      SHORT G_M000_IG90
 
G_M000_IG96:                ;; offset=0x0A3C
       mov      r9, gword ptr [rbp+0x28]
       cmp      byte  ptr [r9+0x30], 0
       je       G_M000_IG117
 
G_M000_IG97:                ;; offset=0x0A4B
       cmp      byte  ptr [r9+0x34], 0
       je       G_M000_IG117
       cmp      dword ptr [r9+0x28], 0
       jne      SHORT G_M000_IG99
       mov      rdx, gword ptr [r9+0x20]
       mov      rcx, 0x7FFA0286DD10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG99
       mov      rdx, rbx
       test     rdx, rdx
       mov      r15, gword ptr [rbp+0x18]
       cmove    rdx, r15
       mov      r9d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], r9d
       mov      gword ptr [rsp+0x28], rsi
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, rbx
       mov      r9, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteCasedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCasedSplit,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG99
       mov      eax, 1
 
G_M000_IG98:                ;; offset=0x0AAA
       add      rsp, 424
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG99:                ;; offset=0x0ABE
       mov      r15, gword ptr [rbp+0x18]
       mov      rdx, rsi
       mov      rcx, 0x7FFA0286E138
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       je       G_M000_IG90
 
G_M000_IG100:                ;; offset=0x0AE0
       mov      r8, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [r8+0x20]
       mov      rcx, 0x7FFA0286E440
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG102
       mov      r8, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], r8
       mov      r9d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], r9d
       mov      gword ptr [rsp+0x30], rsi
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, r15
       mov      r8, rbx
       mov      r9, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteTrimmedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG102
 
G_M000_IG101:                ;; offset=0x0B2A
       mov      eax, 1
       jmp      G_M000_IG82
 
G_M000_IG102:                ;; offset=0x0B34
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       jne      SHORT G_M000_IG103
       xor      r9, r9
       xor      r8d, r8d
       jmp      SHORT G_M000_IG104
 
G_M000_IG103:                ;; offset=0x0B4C
       lea      r9, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
 
G_M000_IG104:                ;; offset=0x0B54
       lea      rax, bword ptr [rcx+0x18]
       mov      r10, rbx
       test     r10, r10
       cmove    r10, r15
       mov      bword ptr [rbp-0x148], r9
       mov      dword ptr [rbp-0x140], r8d
       mov      r8, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], r8
       mov      r9d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], r9d
       mov      gword ptr [rsp+0x30], r10
       lea      r10, [rbp-0x98]
       mov      qword ptr [rsp+0x38], r10
       lea      r8, [rbp-0x148]
       mov      rcx, rdi
       mov      r9, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG107
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx]
       mov      r8, gword ptr [r8+0x88]
       mov      r9d, dword ptr [rcx+0x18]
       cmp      r9d, dword ptr [r8+0x08]
       jae      G_M000_IG116
       shl      r9, 5
       lea      r8, bword ptr [r8+r9+0x10]
 
G_M000_IG105:                ;; offset=0x0BCF
       vmovdqu  xmm0, xmmword ptr [rbp-0x98]
       vmovdqu  xmmword ptr [rbp-0x138], xmm0
 
G_M000_IG106:                ;; offset=0x0BDF
       lea      r9, [rbp-0x138]
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG101
 
G_M000_IG107:                ;; offset=0x0BF4
       mov      rcx, bword ptr [rbp+0x10]
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rsi, rax
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x20]
       mov      r8, gword ptr [rbp+0x28]
       cmp      byte  ptr [r8+0x30], 0
       setne    r9b
       movzx    r9, r9b
       mov      eax, dword ptr [rbp+0x30]
       lea      r8d, [rax+r9+0x01]
       mov      rdx, gword ptr [rdx]
       mov      r14, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [r14+0x28]
       lea      rcx, [rbp-0x80]
       call     [System.MemoryExtensions:AsMemory[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       xor      r13, r13
       xor      r12d, r12d
       mov      rcx, gword ptr [rbp-0x80]
       mov      eax, dword ptr [rbp-0x78]
       mov      dword ptr [rbp-0x114], eax
       mov      r8d, dword ptr [rbp-0x74]
       mov      dword ptr [rbp-0x118], r8d
       test     rcx, rcx
       je       SHORT G_M000_IG111
       mov      rdx, qword ptr [rcx]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       je       SHORT G_M000_IG108
       lea      r13, bword ptr [rcx+0x10]
       mov      r12d, dword ptr [rcx+0x08]
       jmp      SHORT G_M000_IG109
 
G_M000_IG108:                ;; offset=0x0C76
       lea      rdx, [rbp-0x100]
       mov      r10, qword ptr [rcx]
       mov      r10, qword ptr [r10+0x40]
       call     [r10+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r13, bword ptr [rbp-0x100]
       mov      r12d, dword ptr [rbp-0xF8]
 
G_M000_IG109:                ;; offset=0x0C96
       mov      eax, dword ptr [rbp-0x114]
       and      eax, 0x7FFFFFFF
       mov      r8d, dword ptr [rbp-0x118]
       mov      ecx, r8d
       add      rcx, rax
       mov      edx, r12d
       cmp      rcx, rdx
       jbe      SHORT G_M000_IG110
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG110:                ;; offset=0x0CBD
       shl      rax, 4
       add      r13, rax
       mov      r12d, r8d
 
G_M000_IG111:                ;; offset=0x0CC7
       cmp      dword ptr [r14+0x2C], 0
       je       G_M000_IG112
       mov      rcx, 0x7FFA0286E738
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       mov      rdx, 0x27B38C01C60
       cmp      rdi, gword ptr [rdx]
       jne      G_M000_IG112
       mov      rdx, rsi
       mov      rcx, 0x7FFA025ACB28
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x168], rax
       test     rax, rax
       je       SHORT G_M000_IG112
       cmp      r12d, 2
       jg       SHORT G_M000_IG112
       mov      bword ptr [rbp-0x128], r13
       mov      dword ptr [rbp-0x120], r12d
       lea      rdx, [rbp-0x128]
       lea      rcx, [rbp-0xC0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      r9d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], r9d
       mov      rcx, gword ptr [rbp-0x168]
       mov      gword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xC0]
       mov      qword ptr [rsp+0x30], rcx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, rbx
       mov      r8, r15
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSplitUnpack(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool]
       test     eax, eax
       jne      G_M000_IG101
 
G_M000_IG112:                ;; offset=0x0D76
       cmp      byte  ptr [r14+0x33], 0
       je       G_M000_IG114
       cmp      r12d, 1
       je       SHORT G_M000_IG113
       cmp      r12d, 2
       jne      G_M000_IG114
 
G_M000_IG113:                ;; offset=0x0D91
       mov      rcx, 0x7FFA0286E738
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       mov      rdx, 0x27B38C01C30
       cmp      rdi, gword ptr [rdx]
       jne      G_M000_IG114
       mov      rdx, rsi
       mov      rcx, 0x7FFA02607AA0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x170], rax
       test     rax, rax
       je       SHORT G_M000_IG114
       test     r12d, r12d
       je       G_M000_IG116
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, gword ptr [rbp-0x170]
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG114
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FFA025ACB28
       call     CORINFO_HELP_CHKCASTCLASS
       mov      gword ptr [rsp+0x28], rax
       mov      rdx, r15
       mov      r8, r14
       mov      r9d, dword ptr [rbp+0x30]
       mov      rcx, gword ptr [rbp-0x170]
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryAccumulation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.PyDict,Lokad.Lython.Runtime.Text.PyString):bool]
       test     eax, eax
       jne      G_M000_IG101
 
G_M000_IG114:                ;; offset=0x0E3F
       mov      r9, gword ptr [r14+0x18]
       mov      r8, rbx
       test     r8, r8
       cmove    r8, r15
       mov      bword ptr [rbp-0x128], r13
       mov      dword ptr [rbp-0x120], r12d
       mov      gword ptr [rsp+0x20], r8
       lea      r8, [rbp-0xA0]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0x128]
       mov      rdx, rsi
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG115
       xor      eax, eax
       jmp      G_M000_IG82
 
G_M000_IG115:                ;; offset=0x0E8A
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx]
       mov      rdx, gword ptr [rdx+0x88]
       mov      eax, dword ptr [rcx+0x18]
       cmp      eax, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG116
       shl      rax, 5
       lea      r15, bword ptr [rdx+rax+0x10]
       mov      rdx, gword ptr [rbp-0xA0]
       lea      rcx, [rbp-0x110]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x110]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, rbx
       mov      r8, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG101
 
G_M000_IG116:                ;; offset=0x0ED9
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG117:                ;; offset=0x0EDF
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       jne      SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x0EE8
       xor      rdx, rdx
       xor      r8d, r8d
       jmp      SHORT G_M000_IG120
 
G_M000_IG119:                ;; offset=0x0EEF
       lea      rdx, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
 
G_M000_IG120:                ;; offset=0x0EF7
       mov      bword ptr [rbp-0x128], rdx
       mov      dword ptr [rbp-0x120], r8d
       mov      r15, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], r15
       test     rbx, rbx
       setne    r8b
       movzx    r8, r8b
       mov      dword ptr [rsp+0x28], r8d
       lea      r8, [rbp-0xB0]
       mov      qword ptr [rsp+0x30], r8
       lea      r8, [rbp-0x128]
       mov      rdx, rsi
       mov      rcx, r9
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG121
       xor      eax, eax
       jmp      G_M000_IG82
 
G_M000_IG121:                ;; offset=0x0F4C
       mov      rdx, gword ptr [rbp-0xB0]
       mov      rcx, 0x7FFA024EE760
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       test     r15, r15
       je       SHORT G_M000_IG123
       mov      rcx, bword ptr [rbp+0x10]
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, rdi
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG122:                ;; offset=0x0F86
       mov      eax, 1
       jmp      G_M000_IG82
 
G_M000_IG123:                ;; offset=0x0F90
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx]
       mov      r8, gword ptr [r8+0x88]
       mov      r9d, dword ptr [rcx+0x18]
       cmp      r9d, dword ptr [r8+0x08]
       jae      SHORT G_M000_IG126
       shl      r9, 5
       lea      r8, bword ptr [r8+r9+0x10]
 
G_M000_IG124:                ;; offset=0x0FB1
       vmovdqu  xmm0, xmmword ptr [rbp-0xB0]
       vmovdqu  xmmword ptr [rbp-0x138], xmm0
 
G_M000_IG125:                ;; offset=0x0FC1
       lea      r9, [rbp-0x138]
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      SHORT G_M000_IG122
 
G_M000_IG126:                ;; offset=0x0FD3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG127:                ;; offset=0x0FD9
       sub      rsp, 104
 
G_M000_IG128:                ;; offset=0x0FDD
       mov      rbx, gword ptr [rbp-0x70]
       mov      rcx, gword ptr [rbp-0x160]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      rdx, rax
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AbortPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG129:                ;; offset=0x100B
       sub      rsp, 104
 
G_M000_IG130:                ;; offset=0x100F
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       lea      r8, [rbp-0x88]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG132
 
G_M000_IG131:                ;; offset=0x1046
       mov      rcx, gword ptr [rbp-0x88]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG132:                ;; offset=0x1053
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG133:                ;; offset=0x1059
       sub      rsp, 104
 
G_M000_IG134:                ;; offset=0x105D
       cmp      dword ptr [rbp-0x3C], 0
       je       SHORT G_M000_IG136
 
G_M000_IG135:                ;; offset=0x1063
       mov      r15, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [r15+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
 
G_M000_IG136:                ;; offset=0x1076
       nop      
 
G_M000_IG137:                ;; offset=0x1077
       add      rsp, 104
       ret      
 
G_M000_IG138:                ;; offset=0x107C
       sub      rsp, 104
 
G_M000_IG139:                ;; offset=0x1080
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG140:                ;; offset=0x1099
       sub      rsp, 104
 
G_M000_IG141:                ;; offset=0x109D
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 4278

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TryStartNativeIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Dynamic PGO
; rsp based frame
; partially interruptible
; with Dynamic PGO: fgCalledCount is 28196
; 2 inlinees with PGO data; 13 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r14
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 80
       xor      eax, eax
       mov      qword ptr [rsp+0x28], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x30], ymm4
       mov      rbx, rcx
       mov      rsi, r9
       mov      rdi, bword ptr [rsp+0xB0]
 
G_M000_IG02:                ;; offset=0x0029
       mov      rbp, bword ptr [r8]
       mov      r14d, dword ptr [r8+0x08]
       xor      ecx, ecx
       mov      qword ptr [rdi], rcx
       mov      qword ptr [rdi+0x08], rcx
       mov      rcx, gword ptr [rbx+0x40]
       cmp      byte  ptr [rcx+0xE0], 0
       jne      SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0046
       xor      eax, eax
 
G_M000_IG04:                ;; offset=0x0048
       add      rsp, 80
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       ret      
 
G_M000_IG05:                ;; offset=0x0053
       cmp      byte  ptr [rsp+0xA8], 0
       jne      G_M000_IG11
       xor      ecx, ecx
       mov      qword ptr [rdi], rcx
       mov      qword ptr [rdi+0x08], rcx
       cmp      byte  ptr [rdx+0x34], 0
       je       SHORT G_M000_IG09
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       mov      rdx, gword ptr [rbx+0x40]
       cmp      ecx, dword ptr [rdx+0xC4]
       jne      SHORT G_M000_IG09
       mov      rcx, rbx
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG09
       mov      rsi, gword ptr [rsi+0x98]
       cmp      byte  ptr [rsi], sil
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG10
 
G_M000_IG06:                ;; offset=0x00AE
       mov      gword ptr [rsp+0x38], rbx
       mov      bword ptr [rsp+0x40], rbp
       mov      dword ptr [rsp+0x48], r14d
       lea      rdx, [rsp+0x38]
       mov      rcx, rbx
       mov      r8, gword ptr [rsp+0xA0]
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
 
G_M000_IG07:                ;; offset=0x00D6
       nop      
 
G_M000_IG08:                ;; offset=0x00D7
       add      rsp, 80
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       ret      
 
G_M000_IG09:                ;; offset=0x00E2
       xor      eax, eax
       jmp      SHORT G_M000_IG07
 
G_M000_IG10:                ;; offset=0x00E6
       mov      rcx, rsi
       mov      rdx, gword ptr [rsp+0xA0]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      SHORT G_M000_IG06
 
G_M000_IG11:                ;; offset=0x00F9
       mov      rdx, gword ptr [rbx+0x40]
       cmp      r14d, dword ptr [rdx+0xC4]
       jne      G_M000_IG03
       mov      bword ptr [rsp+0x28], rbp
       mov      dword ptr [rsp+0x30], r14d
       lea      rdx, [rsp+0x28]
       mov      rcx, rbx
       mov      r8, gword ptr [rsp+0xA0]
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       nop      
 
G_M000_IG12:                ;; offset=0x012E
       add      rsp, 80
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       ret      
 
; Total bytes of code 313

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 32928
; 5 inlinees with PGO data; 11 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 448
       lea      rbp, [rsp+0x1E0]
       xor      eax, eax
       mov      qword ptr [rbp-0x188], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x180], xmm4
       mov      rax, -336
 
G_M000_IG14:                ;; offset=0x0034
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm4
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG14
       mov      rbx, rcx
       mov      rsi, bword ptr [rbp+0x50]
 
G_M000_IG02:                ;; offset=0x0052
       mov      rax, bword ptr [r8]
       mov      edi, dword ptr [r8+0x08]
       mov      rcx, gword ptr [rbx+0x40]
       mov      r14d, dword ptr [rcx+0xD4]
       cmp      r14d, 16
       ja       G_M000_IG06
       cmp      byte  ptr [rbp+0x48], 0
       je       G_M000_IG11
       xor      ecx, ecx
       test     r9, r9
       jne      G_M000_IG07
 
G_M000_IG03:                ;; offset=0x0083
       cmp      ecx, r14d
       ja       G_M000_IG06
       lea      rdx, bword ptr [rbp-0x120]
       mov      r8d, ecx
       shl      r8, 4
       add      r8, rdx
       mov      edx, r14d
       sub      edx, ecx
       cmp      edi, edx
       ja       G_M000_IG10
       mov      ecx, edi
       shl      rcx, 4
       mov      r10, rcx
       cmp      r10, 0x4000
       ja       G_M000_IG09
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa620d2aa8)], 0
       jne      G_M000_IG08
 
G_M000_IG04:                ;; offset=0x00DB
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x158], ymm0
       lea      rdx, bword ptr [rbp-0x120]
       mov      bword ptr [rbp-0x168], rdx
       mov      dword ptr [rbp-0x160], r14d
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      bword ptr [rsp+0x28], rsi
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rsi
       mov      rsi, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rsi
       mov      rsi, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rsi
       lea      rdx, [rbp-0x138]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x168]
       lea      r8, [rbp-0x158]
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG05:                ;; offset=0x014C
       add      rsp, 448
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x015A
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG07:                ;; offset=0x0161
       mov      ecx, 1
       test     r14d, r14d
       je       G_M000_IG13
       mov      gword ptr [rbp-0x120], r9
       xor      edx, edx
       mov      qword ptr [rbp-0x118], rdx
       jmp      G_M000_IG03
 
G_M000_IG08:                ;; offset=0x0184
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG04
 
G_M000_IG09:                ;; offset=0x018E
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG04
 
G_M000_IG10:                ;; offset=0x01A2
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG11:                ;; offset=0x01A9
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      ecx, r14d
       ja       SHORT G_M000_IG06
       lea      r8, bword ptr [rbp-0x120]
       mov      bword ptr [rbp-0x168], r8
       mov      dword ptr [rbp-0x160], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x178], rcx
 
G_M000_IG12:                ;; offset=0x01D6
       mov      dword ptr [rbp-0x170], ecx
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], r9
       mov      gword ptr [rsp+0x38], rdx
       mov      bword ptr [rbp-0x188], rax
       mov      dword ptr [rbp-0x180], edi
       lea      rcx, [rbp-0x168]
       lea      rdx, [rbp-0x178]
       lea      r9, [rbp-0x188]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, rbx
       mov      r8, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
       jmp      G_M000_IG04
 
G_M000_IG13:                ;; offset=0x022E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 564

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 576
       lea      rbp, [rsp+0x240]
       xor      eax, eax
       mov      qword ptr [rbp-0x1D8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x1D0], xmm4
       vmovdqa  xmmword ptr [rbp-0x1C0], xmm4
       mov      rax, -432
 
G_M000_IG50:                ;; offset=0x0037
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG50
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      dword ptr [rbp+0x20], r8d
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x005E
       mov      rax, 0x27B38C012C8
       mov      rdx, gword ptr [rax]
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0x1D8], rax
       mov      rcx, bword ptr [rbp-0x1D8]
       mov      rdx, gword ptr [rbp-0x80]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0x1D8]
       mov      rcx, qword ptr [rbp-0x78]
       mov      qword ptr [rax+0x08], rcx
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CurrentRecursionDepth():long:this]
       cmp      rax, 8
       jl       SHORT G_M000_IG04
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x00C2
       add      rsp, 576
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x00CB
       mov      rdx, gword ptr [rbp+0x28]
       mov      rcx, 0x7FFA02847388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0x108], rax
       mov      rax, bword ptr [rbp-0x108]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp+0x20], eax
       jae      G_M000_IG45
       mov      rax, bword ptr [rbp-0x108]
       mov      ecx, dword ptr [rbp+0x20]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x118], rax
       mov      rdx, gword ptr [rbp-0x118]
       mov      rcx, 0x7FFA026F6F40
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0153
       xor      rax, rax
       mov      gword ptr [rbp-0x88], rax
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x015E
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0x110], rax
       mov      rax, bword ptr [rbp-0x110]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp+0x20], eax
       jae      G_M000_IG45
       mov      rax, bword ptr [rbp-0x110]
       mov      ecx, dword ptr [rbp+0x20]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x88], rax
 
G_M000_IG07:                ;; offset=0x01A4
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x10], rax
       mov      rdx, gword ptr [rbp+0x28]
       mov      rcx, 0x7FFA0286D848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x18], rax
       cmp      gword ptr [rbp-0x18], 0
       je       SHORT G_M000_IG08
       mov      rcx, gword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Function():Lokad.Lython.Runtime.LythonRuntime+ICallable:this]
       mov      gword ptr [rbp-0x120], rax
       mov      rdx, gword ptr [rbp-0x120]
       mov      rcx, 0x7FFA02847388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x20], 0
       je       SHORT G_M000_IG08
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Receiver():System.Object:this]
       mov      gword ptr [rbp-0x10], rax
 
G_M000_IG08:                ;; offset=0x0219
       cmp      gword ptr [rbp-0x08], 0
       je       SHORT G_M000_IG09
       lea      r9, [rbp-0x28]
       mov      rcx, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp-0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x023C
       xor      eax, eax
 
G_M000_IG10:                ;; offset=0x023E
       add      rsp, 576
       pop      rbp
       ret      
 
G_M000_IG11:                ;; offset=0x0247
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x90], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x128], rax
       mov      rdx, gword ptr [rbp-0x128]
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x2C], 1
 
G_M000_IG12:                ;; offset=0x0286
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0x98], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp+0x20]
       mov      dword ptr [rbp-0x9C], eax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x12C], eax
       mov      r9d, dword ptr [rbp-0x12C]
       lea      rdx, [rbp-0x40]
       mov      r8d, dword ptr [rbp-0x9C]
       mov      rcx, bword ptr [rbp-0x98]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       cmp      gword ptr [rbp-0x10], 0
       jne      G_M000_IG17
 
G_M000_IG13:                ;; offset=0x02EC
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG14:                ;; offset=0x02F9
       lea      rdx, [rbp-0x140]
       lea      rcx, [rbp-0xF8]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x100], rax
 
G_M000_IG15:                ;; offset=0x031C
       vmovdqu  xmm0, xmmword ptr [rbp-0xF8]
       vmovdqu  xmmword ptr [rbp-0x150], xmm0
 
G_M000_IG16:                ;; offset=0x032C
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x158], rax
       movzx    rax, byte  ptr [rbp-0x28]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rsp+0x20], rax
       lea      r8, [rbp-0x150]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r9, gword ptr [rbp-0x100]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartNativeIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,byref):bool:this]
       test     eax, eax
       je       G_M000_IG22
       mov      dword ptr [rbp-0x54], 1
       jmp      G_M000_IG38
 
G_M000_IG17:                ;; offset=0x038E
       movzx    rax, byte  ptr [rbp-0x28]
       test     eax, eax
       je       G_M000_IG22
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       jne      SHORT G_M000_IG22
 
G_M000_IG18:                ;; offset=0x03AA
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x168], xmm0
 
G_M000_IG19:                ;; offset=0x03B7
       lea      rdx, [rbp-0x168]
       lea      rcx, [rbp-0xE8]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG20:                ;; offset=0x03CB
       vmovdqu  xmm0, xmmword ptr [rbp-0xE8]
       vmovdqu  xmmword ptr [rbp-0x178], xmm0
 
G_M000_IG21:                ;; offset=0x03DB
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x180], rax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x180]
       lea      rdx, [rbp-0x178]
       mov      r8, gword ptr [rbp-0x10]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartBoundIntegerReturn(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG22
       mov      dword ptr [rbp-0x54], 1
       jmp      G_M000_IG39
 
G_M000_IG22:                ;; offset=0x0425
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG24
       mov      rax, bword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x48]
       test     eax, eax
       je       SHORT G_M000_IG23
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0xA0], eax
       jmp      SHORT G_M000_IG25
 
G_M000_IG23:                ;; offset=0x0455
       xor      eax, eax
       mov      dword ptr [rbp-0xA0], eax
       jmp      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x045F
       mov      dword ptr [rbp-0xA0], 1
 
G_M000_IG25:                ;; offset=0x0469
       movzx    rax, byte  ptr [rbp-0xA0]
       mov      dword ptr [rbp-0x44], eax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG30
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_LastOwnedTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp+0x20]
       jge      G_M000_IG30
 
G_M000_IG26:                ;; offset=0x04A0
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x190], xmm0
 
G_M000_IG27:                ;; offset=0x04AD
       lea      rdx, [rbp-0x190]
       lea      rcx, [rbp-0xD8]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG28:                ;; offset=0x04C1
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rbp-0x1A0], xmm0
 
G_M000_IG29:                ;; offset=0x04D1
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp+0x20]
       mov      dword ptr [rsp+0x28], eax
       mov      eax, dword ptr [rbp-0x44]
       mov      dword ptr [rsp+0x30], eax
       movzx    rax, byte  ptr [rbp-0x28]
       mov      dword ptr [rsp+0x38], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x40], rax
       lea      rax, [rbp-0x50]
       mov      qword ptr [rsp+0x48], rax
       lea      r9, [rbp-0x1A0]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8, gword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StartNativeFixedReturn(Lokad.Lython.Runtime.PyExecutableFunction,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,int,bool,bool,byref,byref):this]
       jmp      G_M000_IG36
 
G_M000_IG30:                ;; offset=0x0520
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x1B0], xmm0
 
G_M000_IG31:                ;; offset=0x052D
       lea      rdx, [rbp-0x1B0]
       lea      rcx, [rbp-0xB0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0xB8], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xC0], rax
       movzx    rax, byte  ptr [rbp-0x28]
       mov      dword ptr [rbp-0xC4], eax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG32:                ;; offset=0x0576
       vmovdqu  xmm0, xmmword ptr [rbp-0xB0]
       vmovdqu  xmmword ptr [rbp-0x1C0], xmm0
 
G_M000_IG33:                ;; offset=0x0586
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp-0xC0]
       mov      gword ptr [rsp+0x28], rax
       mov      eax, dword ptr [rbp-0x44]
       mov      dword ptr [rsp+0x30], eax
       mov      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rsp+0x38], eax
 
G_M000_IG34:                ;; offset=0x05AF
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG35:                ;; offset=0x05BC
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x48], rax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x50], rax
       lea      rax, [rbp-0x50]
       mov      qword ptr [rsp+0x58], rax
       lea      r8, [rbp-0x1C0]
       lea      rax, [rbp-0x1D0]
       mov      qword ptr [rsp+0x40], rax
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9, gword ptr [rbp-0x10]
       mov      rdx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
 
G_M000_IG36:                ;; offset=0x05FE
       cmp      gword ptr [rbp-0x50], 0
       je       SHORT G_M000_IG37
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rbp-0x50]
       mov      gword ptr [rax+0x20], rcx
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      gword ptr [rcx+0x28], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x54], eax
       jmp      SHORT G_M000_IG40
 
G_M000_IG37:                ;; offset=0x063C
       call     G_M000_IG46
       jmp      SHORT G_M000_IG41
 
G_M000_IG38:                ;; offset=0x0643
       call     G_M000_IG46
       jmp      SHORT G_M000_IG43
 
G_M000_IG39:                ;; offset=0x064A
       call     G_M000_IG46
       jmp      SHORT G_M000_IG43
 
G_M000_IG40:                ;; offset=0x0651
       call     G_M000_IG46
       jmp      SHORT G_M000_IG43
 
G_M000_IG41:                ;; offset=0x0658
       mov      eax, 1
 
G_M000_IG42:                ;; offset=0x065D
       add      rsp, 576
       pop      rbp
       ret      
 
G_M000_IG43:                ;; offset=0x0666
       mov      eax, dword ptr [rbp-0x54]
 
G_M000_IG44:                ;; offset=0x0669
       add      rsp, 576
       pop      rbp
       ret      
 
G_M000_IG45:                ;; offset=0x0672
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG46:                ;; offset=0x0678
       sub      rsp, 104
 
G_M000_IG47:                ;; offset=0x067C
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG48
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG48:                ;; offset=0x0692
       nop      
 
G_M000_IG49:                ;; offset=0x0693
       add      rsp, 104
       ret      
 
; Total bytes of code 1688

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 576
       lea      rbp, [rsp+0x240]
       xor      eax, eax
       mov      qword ptr [rbp-0x1D8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x1D0], xmm4
       vmovdqa  xmmword ptr [rbp-0x1C0], xmm4
       mov      rax, -432
 
G_M000_IG57:                ;; offset=0x0037
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG57
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      dword ptr [rbp+0x20], r8d
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x005E
       mov      rax, 0x27B38C012C8
       mov      rdx, gword ptr [rax]
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0x1D8], rax
       mov      rcx, bword ptr [rbp-0x1D8]
       mov      rdx, gword ptr [rbp-0x80]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0x1D8]
       mov      rcx, qword ptr [rbp-0x78]
       mov      qword ptr [rax+0x08], rcx
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CurrentRecursionDepth():long:this]
       cmp      rax, 8
       jl       SHORT G_M000_IG04
       mov      rcx, 0x7FFA02E74D78
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x00D1
       add      rsp, 576
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x00DA
       mov      rdx, gword ptr [rbp+0x28]
       mov      rcx, 0x7FFA02847388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG06
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0x108], rax
       mov      rax, bword ptr [rbp-0x108]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp+0x20], eax
       jae      G_M000_IG52
       mov      rax, bword ptr [rbp-0x108]
       mov      ecx, dword ptr [rbp+0x20]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x118], rax
       mov      rdx, gword ptr [rbp-0x118]
       mov      rcx, 0x7FFA026F6F40
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG07
 
G_M000_IG05:                ;; offset=0x0162
       mov      rcx, 0x7FFA02E74D7C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG06:                ;; offset=0x0171
       xor      rax, rax
       mov      gword ptr [rbp-0x88], rax
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x017C
       mov      rcx, 0x7FFA02E74D80
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0x110], rax
       mov      rax, bword ptr [rbp-0x110]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp+0x20], eax
       jae      G_M000_IG52
       mov      rax, bword ptr [rbp-0x110]
       mov      ecx, dword ptr [rbp+0x20]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x88], rax
 
G_M000_IG08:                ;; offset=0x01D1
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x10], rax
       mov      rdx, gword ptr [rbp+0x28]
       mov      rcx, 0x7FFA0286D848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x18], rax
       cmp      gword ptr [rbp-0x18], 0
       je       SHORT G_M000_IG09
       mov      rcx, gword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Function():Lokad.Lython.Runtime.LythonRuntime+ICallable:this]
       mov      gword ptr [rbp-0x120], rax
       mov      rdx, gword ptr [rbp-0x120]
       mov      rcx, 0x7FFA02847388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x20], 0
       je       SHORT G_M000_IG13
       mov      rcx, 0x7FFA02E74D84
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Receiver():System.Object:this]
       mov      gword ptr [rbp-0x10], rax
 
G_M000_IG09:                ;; offset=0x0255
       cmp      gword ptr [rbp-0x08], 0
       je       SHORT G_M000_IG11
       lea      r9, [rbp-0x28]
       mov      rcx, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp-0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG14
 
G_M000_IG10:                ;; offset=0x0278
       mov      rcx, 0x7FFA02E74D88
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x0287
       mov      rcx, 0x7FFA02E74D8C
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG12:                ;; offset=0x0298
       add      rsp, 576
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x02A1
       mov      rcx, 0x7FFA02E74D90
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG09
 
G_M000_IG14:                ;; offset=0x02B2
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x90], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x128], rax
       mov      rdx, gword ptr [rbp-0x128]
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x2C], 1
 
G_M000_IG15:                ;; offset=0x02F1
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0x98], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp+0x20]
       mov      dword ptr [rbp-0x9C], eax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x12C], eax
       mov      r9d, dword ptr [rbp-0x12C]
       lea      rdx, [rbp-0x40]
       mov      r8d, dword ptr [rbp-0x9C]
       mov      rcx, bword ptr [rbp-0x98]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       cmp      gword ptr [rbp-0x10], 0
       jne      G_M000_IG20
 
G_M000_IG16:                ;; offset=0x0357
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG17:                ;; offset=0x0364
       lea      rdx, [rbp-0x140]
       lea      rcx, [rbp-0xF8]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x100], rax
 
G_M000_IG18:                ;; offset=0x0387
       vmovdqu  xmm0, xmmword ptr [rbp-0xF8]
       vmovdqu  xmmword ptr [rbp-0x150], xmm0
 
G_M000_IG19:                ;; offset=0x0397
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x158], rax
       movzx    rax, byte  ptr [rbp-0x28]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rsp+0x20], rax
       lea      r8, [rbp-0x150]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r9, gword ptr [rbp-0x100]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartNativeIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,byref):bool:this]
       test     eax, eax
       je       G_M000_IG28
       mov      rcx, 0x7FFA02E74D94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x54], 1
       jmp      G_M000_IG45
 
G_M000_IG20:                ;; offset=0x0408
       movzx    rax, byte  ptr [rbp-0x28]
       test     eax, eax
       je       G_M000_IG27
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       jne      G_M000_IG26
 
G_M000_IG21:                ;; offset=0x0428
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x168], xmm0
 
G_M000_IG22:                ;; offset=0x0435
       lea      rdx, [rbp-0x168]
       lea      rcx, [rbp-0xE8]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG23:                ;; offset=0x0449
       vmovdqu  xmm0, xmmword ptr [rbp-0xE8]
       vmovdqu  xmmword ptr [rbp-0x178], xmm0
 
G_M000_IG24:                ;; offset=0x0459
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x180], rax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x180]
       lea      rdx, [rbp-0x178]
       mov      r8, gword ptr [rbp-0x10]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartBoundIntegerReturn(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG25
       mov      rcx, 0x7FFA02E74D98
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x54], 1
       jmp      G_M000_IG46
 
G_M000_IG25:                ;; offset=0x04B2
       mov      rcx, 0x7FFA02E74D9C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG28
 
G_M000_IG26:                ;; offset=0x04C3
       mov      rcx, 0x7FFA02E74DA0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x04D4
       mov      rcx, 0x7FFA02E74DA4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG28:                ;; offset=0x04E3
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG30
       mov      rax, bword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x48]
       test     eax, eax
       je       SHORT G_M000_IG29
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0xA0], eax
       jmp      SHORT G_M000_IG31
 
G_M000_IG29:                ;; offset=0x0513
       mov      rcx, 0x7FFA02E74DA8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0xA0], eax
       jmp      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x052C
       mov      rcx, 0x7FFA02E74DAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xA0], 1
 
G_M000_IG31:                ;; offset=0x0545
       movzx    rax, byte  ptr [rbp-0xA0]
       mov      dword ptr [rbp-0x44], eax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG37
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_LastOwnedTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp+0x20]
       jge      G_M000_IG36
       mov      rcx, 0x7FFA02E74DB0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG32:                ;; offset=0x058B
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x190], xmm0
 
G_M000_IG33:                ;; offset=0x0598
       lea      rdx, [rbp-0x190]
       lea      rcx, [rbp-0xD8]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG34:                ;; offset=0x05AC
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rbp-0x1A0], xmm0
 
G_M000_IG35:                ;; offset=0x05BC
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp+0x20]
       mov      dword ptr [rsp+0x28], eax
       mov      eax, dword ptr [rbp-0x44]
       mov      dword ptr [rsp+0x30], eax
       movzx    rax, byte  ptr [rbp-0x28]
       mov      dword ptr [rsp+0x38], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x40], rax
       lea      rax, [rbp-0x50]
       mov      qword ptr [rsp+0x48], rax
       lea      r9, [rbp-0x1A0]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8, gword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StartNativeFixedReturn(Lokad.Lython.Runtime.PyExecutableFunction,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,int,bool,bool,byref,byref):this]
       jmp      G_M000_IG43
 
G_M000_IG36:                ;; offset=0x060B
       mov      rcx, 0x7FFA02E74DB4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG37:                ;; offset=0x061A
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x1B0], xmm0
 
G_M000_IG38:                ;; offset=0x0627
       lea      rdx, [rbp-0x1B0]
       lea      rcx, [rbp-0xB0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0xB8], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xC0], rax
       movzx    rax, byte  ptr [rbp-0x28]
       mov      dword ptr [rbp-0xC4], eax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG39:                ;; offset=0x0670
       vmovdqu  xmm0, xmmword ptr [rbp-0xB0]
       vmovdqu  xmmword ptr [rbp-0x1C0], xmm0
 
G_M000_IG40:                ;; offset=0x0680
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp-0xC0]
       mov      gword ptr [rsp+0x28], rax
       mov      eax, dword ptr [rbp-0x44]
       mov      dword ptr [rsp+0x30], eax
       mov      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rsp+0x38], eax
 
G_M000_IG41:                ;; offset=0x06A9
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG42:                ;; offset=0x06B6
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x48], rax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x50], rax
       lea      rax, [rbp-0x50]
       mov      qword ptr [rsp+0x58], rax
       lea      r8, [rbp-0x1C0]
       lea      rax, [rbp-0x1D0]
       mov      qword ptr [rsp+0x40], rax
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9, gword ptr [rbp-0x10]
       mov      rdx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
 
G_M000_IG43:                ;; offset=0x06F8
       cmp      gword ptr [rbp-0x50], 0
       je       SHORT G_M000_IG44
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rbp-0x50]
       mov      gword ptr [rax+0x20], rcx
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      gword ptr [rcx+0x28], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x54], eax
       jmp      SHORT G_M000_IG47
 
G_M000_IG44:                ;; offset=0x0736
       call     G_M000_IG53
       jmp      SHORT G_M000_IG48
 
G_M000_IG45:                ;; offset=0x073D
       call     G_M000_IG53
       jmp      SHORT G_M000_IG50
 
G_M000_IG46:                ;; offset=0x0744
       call     G_M000_IG53
       jmp      SHORT G_M000_IG50
 
G_M000_IG47:                ;; offset=0x074B
       call     G_M000_IG53
       jmp      SHORT G_M000_IG50
 
G_M000_IG48:                ;; offset=0x0752
       mov      rcx, 0x7FFA02E74DC0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG49:                ;; offset=0x0766
       add      rsp, 576
       pop      rbp
       ret      
 
G_M000_IG50:                ;; offset=0x076F
       mov      rcx, 0x7FFA02E74DC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x54]
 
G_M000_IG51:                ;; offset=0x0781
       add      rsp, 576
       pop      rbp
       ret      
 
G_M000_IG52:                ;; offset=0x078A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG53:                ;; offset=0x0790
       sub      rsp, 104
 
G_M000_IG54:                ;; offset=0x0794
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG55
       mov      rcx, 0x7FFA02E74DB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG55:                ;; offset=0x07B9
       mov      rcx, 0x7FFA02E74DBC
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG56:                ;; offset=0x07C9
       add      rsp, 104
       ret      
 
; Total bytes of code 1998

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 86352
; 9 inlinees with PGO data; 68 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 200
       lea      rbp, [rsp+0x100]
       xor      eax, eax
       mov      qword ptr [rbp-0x98], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      bword ptr [rbp+0x10], rcx
       mov      rbx, rdx
       mov      esi, r8d
       mov      rdi, r9
       mov      r14, bword ptr [rbp+0x30]
 
G_M000_IG02:                ;; offset=0x004B
       mov      rdx, 0x27B38C012C8
       mov      rdx, gword ptr [rdx]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x18]
       mov      rax, gword ptr [rax+0x98]
       cmp      qword ptr [rax+0x158], 8
       jge      G_M000_IG55
       test     rdi, rdi
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0088
       mov      rax, 0x7FFA02847388
       cmp      qword ptr [rdi], rax
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0097
       mov      r15, rdi
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x009C
       xor      r15, r15
 
G_M000_IG06:                ;; offset=0x009F
       cmp      byte  ptr [rbx+0x30], 0
       je       G_M000_IG45
 
G_M000_IG07:                ;; offset=0x00A9
       lea      rax, bword ptr [rcx+0x50]
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG60
       mov      edx, esi
       shl      rdx, 4
       add      rdx, bword ptr [rax]
       mov      rax, gword ptr [rdx]
       mov      r8, 0x27B38C01C18
       mov      r13, gword ptr [r8]
       cmp      rax, r13
       je       G_M000_IG43
 
G_M000_IG08:                ;; offset=0x00D8
       mov      r8, 0x27B38C01C20
       cmp      rax, gword ptr [r8]
       je       G_M000_IG48
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG49
 
G_M000_IG09:                ;; offset=0x00F6
       test     rax, rax
       jne      G_M000_IG44
 
G_M000_IG10:                ;; offset=0x00FF
       mov      rcx, bword ptr [rbp+0x10]
       lea      rax, bword ptr [rcx+0x50]
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG60
       mov      edx, esi
       shl      rdx, 4
       add      rdx, bword ptr [rax]
       mov      r12, gword ptr [rdx]
       cmp      r12, r13
       je       G_M000_IG46
 
G_M000_IG11:                ;; offset=0x0125
       mov      rax, 0x27B38C01C20
       cmp      r12, gword ptr [rax]
       je       G_M000_IG50
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG51
 
G_M000_IG12:                ;; offset=0x0143
       test     rdi, rdi
       je       SHORT G_M000_IG18
 
G_M000_IG13:                ;; offset=0x0148
       mov      rdx, 0x7FFA0286D848
       cmp      qword ptr [rdi], rdx
       jne      SHORT G_M000_IG18
 
G_M000_IG14:                ;; offset=0x0157
       mov      rdx, gword ptr [rdi+0x10]
       test     rdx, rdx
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0160
       mov      rax, 0x7FFA02847388
       xor      r8, r8
       cmp      qword ptr [rdx], rax
       cmovne   rdx, r8
 
G_M000_IG16:                ;; offset=0x0174
       test     rdx, rdx
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0179
       mov      r15, rdx
       mov      r12, gword ptr [rdi+0x08]
 
G_M000_IG18:                ;; offset=0x0180
       test     r15, r15
       je       G_M000_IG55
       mov      rdx, gword ptr [r15+0x40]
       cmp      byte  ptr [rdx+0xDF], 0
       je       G_M000_IG55
       mov      rax, gword ptr [r15+0x28]
       cmp      byte  ptr [rax+0xFA], 0
       jne      G_M000_IG55
       cmp      byte  ptr [rax+0xFB], 0
       jne      G_M000_IG55
       cmp      byte  ptr [rax+0xFC], 0
       jne      G_M000_IG55
       cmp      gword ptr [rax+0xC0], 0
       jne      G_M000_IG55
       cmp      dword ptr [rdx+0xD4], 16
       jg       G_M000_IG55
       cmp      byte  ptr [rbx+0x34], 0
       je       G_M000_IG52
       mov      edx, dword ptr [rbx+0x28]
       mov      rax, gword ptr [r15+0x08]
       cmp      byte  ptr [rax+0x54], 0
       je       G_M000_IG47
 
G_M000_IG19:                ;; offset=0x01FB
       mov      eax, dword ptr [rax+0x3C]
       test     r12, r12
       setne    r8b
       movzx    r8, r8b
       sub      eax, r8d
       cmp      eax, edx
       sete     dil
       movzx    rdi, dil
 
G_M000_IG20:                ;; offset=0x0216
       test     edi, edi
       jne      SHORT G_M000_IG25
 
G_M000_IG21:                ;; offset=0x021A
       mov      rax, gword ptr [r15+0x08]
       mov      rdx, gword ptr [rax+0x08]
       cmp      dword ptr [rdx+0x08], 16
       jg       G_M000_IG55
       cmp      dword ptr [rax+0x4C], 0
       jge      G_M000_IG55
       cmp      dword ptr [rax+0x50], 0
       jge      G_M000_IG55
       mov      rdx, gword ptr [r15+0x18]
       test     rdx, rdx
       je       SHORT G_M000_IG24
 
G_M000_IG22:                ;; offset=0x0249
       mov      rax, rdx
       mov      r8, 0x7FFA0287EAC0
       cmp      qword ptr [rax], r8
       jne      G_M000_IG53
 
G_M000_IG23:                ;; offset=0x025F
       test     rax, rax
       je       G_M000_IG55
 
G_M000_IG24:                ;; offset=0x0268
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       test     rax, rax
       jne      G_M000_IG54
 
G_M000_IG25:                ;; offset=0x027A
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x18]
       mov      rax, gword ptr [rbx+0x18]
       mov      rcx, gword ptr [rdx+0x98]
       mov      rdx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x3C], 1
 
G_M000_IG26:                ;; offset=0x029F
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x50]
       cmp      byte  ptr [rbx+0x30], 0
       setne    r8b
       movzx    r8, r8b
       lea      r8d, [rsi+r8+0x01]
       mov      r13d, dword ptr [rbx+0x28]
       mov      r9d, r8d
       mov      eax, r13d
       add      r9, rax
       mov      eax, dword ptr [rdx+0x08]
       cmp      r9, rax
       ja       G_M000_IG29
       mov      eax, r8d
       shl      rax, 4
       add      rax, bword ptr [rdx]
       mov      bword ptr [rbp-0xA0], rax
       test     r12, r12
       je       SHORT G_M000_IG30
 
G_M000_IG27:                ;; offset=0x02E7
       test     edi, edi
       je       G_M000_IG31
       cmp      dword ptr [rbx+0x2C], 0
       jne      G_M000_IG31
       mov      r8, gword ptr [rbx+0x18]
       xor      edx, edx
       mov      qword ptr [r14], rdx
       mov      qword ptr [r14+0x08], rdx
       mov      rdx, gword ptr [r15+0x40]
       cmp      byte  ptr [rdx+0xE0], 0
       je       G_M000_IG31
       lea      r9d, [r13+0x01]
       cmp      r9d, dword ptr [rdx+0xC4]
       jne      SHORT G_M000_IG31
       mov      gword ptr [rbp-0x78], r12
       mov      bword ptr [rbp-0x70], rax
       mov      dword ptr [rbp-0x68], r13d
       lea      rdx, [rbp-0x78]
       mov      rcx, r15
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+BoundIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+BoundIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       mov      rax, bword ptr [rbp-0xA0]
       je       SHORT G_M000_IG31
 
G_M000_IG28:                ;; offset=0x034B
       mov      eax, 1
       jmp      G_M000_IG39
 
G_M000_IG29:                ;; offset=0x0355
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG30:                ;; offset=0x035C
       mov      bword ptr [rbp-0x88], rax
       mov      dword ptr [rbp-0x80], r13d
       mov      r8, gword ptr [rbx+0x18]
       mov      gword ptr [rsp+0x20], r8
       mov      dword ptr [rsp+0x28], edi
       mov      bword ptr [rsp+0x30], r14
       lea      r8, [rbp-0x88]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx+0x18]
       mov      rdx, rbx
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartNativeIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,byref):bool:this]
       test     eax, eax
       mov      rax, bword ptr [rbp-0xA0]
       jne      SHORT G_M000_IG28
 
G_M000_IG31:                ;; offset=0x039F
       cmp      byte  ptr [rbx+0x31], 0
       jne      SHORT G_M000_IG33
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx+0x48], 0
       je       SHORT G_M000_IG32
       movzx    r8, byte  ptr [rbx+0x32]
       jmp      SHORT G_M000_IG34
 
G_M000_IG32:                ;; offset=0x03B6
       xor      r8d, r8d
       jmp      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x03BB
       mov      r8d, 1
       mov      rcx, bword ptr [rbp+0x10]
 
G_M000_IG34:                ;; offset=0x03C5
       mov      dword ptr [rbp-0x40], r8d
       cmp      dword ptr [rbx+0x2C], 0
       je       SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x03CF
       mov      rdx, gword ptr [rcx+0x08]
       cmp      dword ptr [rdx+0xC8], esi
       jge      SHORT G_M000_IG36
       mov      bword ptr [rbp-0x98], rax
       mov      dword ptr [rbp-0x90], r13d
       lea      rdx, [rbp-0x98]
       lea      rcx, [rbp-0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      gword ptr [rsp+0x20], r12
       mov      dword ptr [rsp+0x28], esi
       mov      r12d, dword ptr [rbp-0x40]
       mov      dword ptr [rsp+0x30], r12d
       mov      dword ptr [rsp+0x38], edi
       mov      bword ptr [rsp+0x40], r14
       lea      r9, [rbp-0x48]
       mov      qword ptr [rsp+0x48], r9
       lea      r9, [rbp-0x60]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, r15
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StartNativeFixedReturn(Lokad.Lython.Runtime.PyExecutableFunction,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,int,bool,bool,byref,byref):this]
       jmp      SHORT G_M000_IG38
 
G_M000_IG36:                ;; offset=0x0434
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx+0x18]
       mov      rdx, gword ptr [rbx+0x18]
       mov      bword ptr [rbp-0x88], rax
       mov      dword ptr [rbp-0x80], r13d
       mov      gword ptr [rsp+0x20], r9
       mov      gword ptr [rsp+0x28], rdx
       mov      r8d, dword ptr [rbp-0x40]
       mov      dword ptr [rsp+0x30], r8d
       mov      dword ptr [rsp+0x38], edi
       xor      r8, r8
       mov      bword ptr [rbp-0x98], r8
 
G_M000_IG37:                ;; offset=0x046C
       mov      dword ptr [rbp-0x90], r8d
       lea      r8, [rbp-0x50]
       mov      qword ptr [rsp+0x48], r8
       mov      bword ptr [rsp+0x50], r14
       lea      r8, [rbp-0x48]
       mov      qword ptr [rsp+0x58], r8
       lea      r8, [rbp-0x88]
       lea      r9, [rbp-0x98]
       mov      qword ptr [rsp+0x40], r9
       mov      rcx, r15
       mov      r9, r12
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
 
G_M000_IG38:                ;; offset=0x04AC
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG57
       mov      rax, gword ptr [rbp-0x48]
       mov      rcx, bword ptr [rbp+0x10]
       mov      gword ptr [rcx+0x20], rax
       mov      rax, gword ptr [r15+0x28]
       mov      rax, gword ptr [rax+0x98]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rcx+0x28], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG39:                ;; offset=0x04DE
       cmp      dword ptr [rbp-0x3C], 0
       je       SHORT G_M000_IG42
 
G_M000_IG40:                ;; offset=0x04E4
       mov      rcx, bword ptr [rbp+0x10]
       mov      rbx, gword ptr [rcx+0x18]
       mov      rsi, gword ptr [rbx+0x98]
       mov      rcx, qword ptr [rsi+0x160]
       test     rcx, rcx
       jle      SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x04FF
       dec      rcx
       mov      qword ptr [rsi+0x160], rcx
 
G_M000_IG42:                ;; offset=0x0509
       add      rsp, 200
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG43:                ;; offset=0x051D
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       jmp      G_M000_IG09
 
G_M000_IG44:                ;; offset=0x052B
       mov      rdx, 0x7FFA026F6F40
       cmp      qword ptr [rax], rdx
       jne      G_M000_IG10
 
G_M000_IG45:                ;; offset=0x053E
       mov      rcx, bword ptr [rbp+0x10]
       xor      r12, r12
       jmp      G_M000_IG12
 
G_M000_IG46:                ;; offset=0x054A
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG12
 
G_M000_IG47:                ;; offset=0x055B
       xor      edi, edi
       jmp      G_M000_IG20
 
G_M000_IG48:                ;; offset=0x0562
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       jmp      G_M000_IG09
 
G_M000_IG49:                ;; offset=0x0570
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       jmp      G_M000_IG09
 
G_M000_IG50:                ;; offset=0x057E
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG12
 
G_M000_IG51:                ;; offset=0x058F
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG12
 
G_M000_IG52:                ;; offset=0x05A0
       xor      edi, edi
       jmp      G_M000_IG20
 
G_M000_IG53:                ;; offset=0x05A7
       mov      rcx, 0x7FFA027D1128
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       jmp      G_M000_IG23
 
G_M000_IG54:                ;; offset=0x05BB
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       sete     cl
       movzx    rcx, cl
       test     ecx, ecx
       je       G_M000_IG25
 
G_M000_IG55:                ;; offset=0x05D4
       xor      eax, eax
 
G_M000_IG56:                ;; offset=0x05D6
       add      rsp, 200
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG57:                ;; offset=0x05EA
       call     G_M000_IG61
       nop      
 
G_M000_IG58:                ;; offset=0x05F0
       mov      eax, 1
 
G_M000_IG59:                ;; offset=0x05F5
       add      rsp, 200
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG60:                ;; offset=0x0609
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG61:                ;; offset=0x060F
       sub      rsp, 104
 
G_M000_IG62:                ;; offset=0x0613
       cmp      dword ptr [rbp-0x3C], 0
       je       SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x0619
       mov      rcx, bword ptr [rbp+0x10]
       mov      rbx, gword ptr [rcx+0x18]
       mov      rsi, gword ptr [rbx+0x98]
       mov      rax, qword ptr [rsi+0x160]
       test     rax, rax
       jle      SHORT G_M000_IG65
 
G_M000_IG64:                ;; offset=0x0634
       dec      rax
       mov      qword ptr [rsi+0x160], rax
 
G_M000_IG65:                ;; offset=0x063E
       add      rsp, 104
       ret      
 
; Total bytes of code 1603

