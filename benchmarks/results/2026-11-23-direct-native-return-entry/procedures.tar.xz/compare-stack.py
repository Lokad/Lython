from pathlib import Path
import json
import subprocess

lab = Path(__file__).resolve().parent
old = lab.parent / "native-stack-initialization-20261123"
rows = []
for role in ("reference", "candidate"):
    for kind, folder in (("earlier", old / ("deep-continuation-" + role)), ("current", lab / ("stack-" + role))):
        root = "/mnt/d/" + folder.relative_to(folder.anchor).as_posix()
        dotnet = "/home/vermorel/.dotnet"
        result = subprocess.run(["wsl.exe", "--", "env", "DOTNET_ROOT=" + dotnet,
            "DOTNET_HOST_PATH=" + dotnet + "/dotnet", "DOTNET_PROCESSOR_COUNT=1", "timeout", "24s",
            dotnet + "/dotnet", root + "/Lokad.Lython.WorkerFixture.dll", "stack-guard",
            root + "/Lokad.Lython.dll", "native-call-continuation"], capture_output=True, encoding="utf-8", timeout=30)
        row = {"role": role, "source": kind, "exitCode": result.returncode, "stdout": result.stdout, "stderr": result.stderr}
        rows.append(row)
        print(row)
(lab / "stack-control-rerun.json").write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8", newline="\n")
