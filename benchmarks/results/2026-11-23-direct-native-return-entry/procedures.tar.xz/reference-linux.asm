; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 944
       lea      rbp, [rsp+0x3B0]
       xor      eax, eax
       mov      qword ptr [rbp-0x368], rax
       vxorps   xmm8, xmm8, xmm8
       mov      rax, -816
 
G_M000_IG69:                ;; offset=0x0028
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG69
       mov      bword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
       mov      gword ptr [rbp-0x20], rcx
       mov      dword ptr [rbp-0x24], r8d
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x0058
       mov      rax, bword ptr [rbp+0x10]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdi, 0x7F4B841ACE90
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x38], rax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG03
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x2D8], rax
       mov      rsi, gword ptr [rbp-0x2D8]
       mov      rdi, 0x7F4B83F35F20
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x00C3
       xor      rax, rax
       mov      gword ptr [rbp-0x148], rax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00CE
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x148], rax
 
G_M000_IG05:                ;; offset=0x00EC
       mov      rax, gword ptr [rbp-0x148]
       mov      gword ptr [rbp-0x40], rax
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdi, 0x7F4B841D33F8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       SHORT G_M000_IG06
       mov      rdi, gword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Function():Lokad.Lython.Runtime.LythonRuntime+ICallable:this]
       mov      gword ptr [rbp-0x2E0], rax
       mov      rsi, gword ptr [rbp-0x2E0]
       mov      rdi, 0x7F4B841ACE90
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       je       SHORT G_M000_IG06
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x38], rax
       mov      rdi, gword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Receiver():System.Object:this]
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG06:                ;; offset=0x0163
       cmp      gword ptr [rbp-0x38], 0
       je       G_M000_IG25
       cmp      gword ptr [rbp-0x18], 0
       je       G_M000_IG25
       lea      rcx, [rbp-0x58]
       mov      rdi, gword ptr [rbp-0x38]
       mov      rsi, gword ptr [rbp-0x20]
       mov      rdx, gword ptr [rbp-0x40]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG08
       xor      eax, eax
 
G_M000_IG07:                ;; offset=0x0197
       add      rsp, 944
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x01A0
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
 
G_M000_IG09:                ;; offset=0x01A5
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2E8], rax
       mov      rsi, gword ptr [rbp-0x2E8]
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x5C], 1
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2F0], rax
       mov      rsi, gword ptr [rbp-0x2F0]
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 32
       mov      bword ptr [rbp-0x258], rax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x25C], eax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x2F4], eax
       mov      edx, dword ptr [rbp-0x2F4]
       mov      esi, dword ptr [rbp-0x25C]
       mov      rdi, bword ptr [rbp-0x258]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:Slice(int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      gword ptr [rbp-0x270], rax
       mov      qword ptr [rbp-0x268], rdx
 
G_M000_IG10:                ;; offset=0x025B
       vmovdqu  xmm0, xmmword ptr [rbp-0x270]
       vmovdqu  xmmword ptr [rbp-0xB8], xmm0
 
G_M000_IG11:                ;; offset=0x026B
       lea      rdi, [rbp-0xB8]
       call     [System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_Span():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x280], rax
       mov      qword ptr [rbp-0x278], rdx
 
G_M000_IG12:                ;; offset=0x0286
       vmovdqu  xmm0, xmmword ptr [rbp-0x280]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG13:                ;; offset=0x0293
       lea      rcx, [rbp-0x88]
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x20]
       mov      edx, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PrepareUnpackedCallReturn(byref,Lokad.Lython.Frontend.ExecutableCallSite,int,byref):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x290], rax
       mov      qword ptr [rbp-0x288], rdx
 
G_M000_IG14:                ;; offset=0x02B9
       vmovdqu  xmm0, xmmword ptr [rbp-0x290]
       vmovdqu  xmmword ptr [rbp-0x80], xmm0
 
G_M000_IG15:                ;; offset=0x02C6
       mov      rdi, bword ptr [rbp-0x70]
       mov      rsi, qword ptr [rbp-0x68]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x2A0], rax
       mov      qword ptr [rbp-0x298], rdx
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2A8], rax
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CallResultConsumedByIteration(byref,Lokad.Lython.Frontend.ExecutableCallSite):bool]
       mov      dword ptr [rbp-0x2F8], eax
       movzx    rax, byte  ptr [rbp-0x58]
       mov      dword ptr [rsp+0x10], eax
       lea      rdi, [rsp+0x18]
       lea      rsi, [rbp-0x80]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x18], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rax, [rbp-0x90]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0xA0]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0xA8]
       mov      qword ptr [rsp+0x38], rax
       mov      eax, dword ptr [rbp-0x2F8]
       mov      dword ptr [rsp+0x08], eax
       mov      rdx, bword ptr [rbp-0x2A0]
       mov      rcx, qword ptr [rbp-0x298]
       mov      rsi, gword ptr [rbp-0x20]
       mov      r8, gword ptr [rbp-0x40]
       mov      r9, gword ptr [rbp-0x10]
       mov      rax, gword ptr [rbp-0x2A8]
       mov      gword ptr [rsp], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       movzx    rax, byte  ptr [rbp-0x90]
       test     eax, eax
       jne      SHORT G_M000_IG16
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x88]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RestoreNativeExtent(int):this]
 
G_M000_IG16:                ;; offset=0x03B0
       cmp      gword ptr [rbp-0xA8], 0
       je       G_M000_IG19
 
G_M000_IG17:                ;; offset=0x03BE
       mov      rdi, gword ptr [rbp-0xA8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterExecutableSlots():this]
       mov      rax, gword ptr [rbp-0xA8]
       mov      gword ptr [rbp-0x2B0], rax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2B8], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x300], rax
       mov      rax, gword ptr [rbp-0x300]
       mov      gword ptr [rsp], rax
       mov      rsi, gword ptr [rbp-0x2B0]
       mov      rdx, gword ptr [rbp-0x20]
       mov      ecx, dword ptr [rbp-0x24]
       mov      r8, gword ptr [rbp-0x2B8]
       mov      rdi, gword ptr [rbp-0x18]
       xor      r9d, r9d
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AttachPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.LythonSourceSpan,int,Lokad.Lython.Runtime.MemoryGovernor):this]
       nop      
 
G_M000_IG18:                ;; offset=0x043C
       mov      rdi, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       mov      dword ptr [rbp-0xBC], 1
       jmp      G_M000_IG23
 
G_M000_IG19:                ;; offset=0x0460
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       movzx    rax, byte  ptr [rbp-0x90]
       test     eax, eax
       je       SHORT G_M000_IG20
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      edx, dword ptr [rbp-0x24]
       mov      ecx, dword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteUnpackedCallReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,int)]
       jmp      SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x0492
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG22
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x310], rax
       mov      rdx, bword ptr [rbp-0x310]
       mov      rcx, gword ptr [rbp-0xA0]
       mov      r8, qword ptr [rbp-0x98]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
 
G_M000_IG21:                ;; offset=0x04E2
       mov      dword ptr [rbp-0xBC], 1
       jmp      SHORT G_M000_IG24
 
G_M000_IG22:                ;; offset=0x04EE
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG23:                ;; offset=0x04F4
       call     G_M000_IG61
       jmp      G_M000_IG53
 
G_M000_IG24:                ;; offset=0x04FE
       call     G_M000_IG61
       jmp      G_M000_IG53
 
G_M000_IG25:                ;; offset=0x0508
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG49
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       je       G_M000_IG49
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG28
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x320], rax
       mov      rsi, gword ptr [rbp-0x320]
       mov      rdi, 0x7F4B841D38C0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xD0], rax
       cmp      gword ptr [rbp-0xD0], 0
       je       SHORT G_M000_IG28
       mov      rax, bword ptr [rbp-0x08]
       mov      bword ptr [rbp-0x248], rax
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x250], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG26
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rbp-0x250], rax
 
G_M000_IG26:                ;; offset=0x05A7
       mov      rdi, bword ptr [rbp-0x248]
       mov      rsi, gword ptr [rbp-0x250]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0xD0]
       mov      r8d, dword ptr [rbp-0x24]
       mov      r9, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteCasedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCasedSplit,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG28
       mov      eax, 1
 
G_M000_IG27:                ;; offset=0x05D7
       add      rsp, 944
       pop      rbp
       ret      
 
G_M000_IG28:                ;; offset=0x05E0
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdi, 0x7F4B841D3CE8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xD8], rax
       cmp      gword ptr [rbp-0xD8], 0
       jne      SHORT G_M000_IG30
       xor      eax, eax
 
G_M000_IG29:                ;; offset=0x0607
       add      rsp, 944
       pop      rbp
       ret      
 
G_M000_IG30:                ;; offset=0x0610
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x328], rax
       mov      rsi, gword ptr [rbp-0x328]
       mov      rdi, 0x7F4B841D3FF0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xE0], rax
       cmp      gword ptr [rbp-0xE0], 0
       je       SHORT G_M000_IG31
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp], rax
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0xE0]
       mov      r8, gword ptr [rbp-0x20]
       mov      r9d, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteTrimmedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG31
       mov      dword ptr [rbp-0xBC], 1
       jmp      G_M000_IG53
 
G_M000_IG31:                ;; offset=0x0687
       mov      rax, bword ptr [rbp-0x08]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x168], rax
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      rdi, rax
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x178], rax
       mov      qword ptr [rbp-0x170], rdx
       mov      rax, gword ptr [rbp-0xD8]
       mov      gword ptr [rbp-0x180], rax
       mov      rax, gword ptr [rbp-0x168]
       mov      gword ptr [rbp-0x188], rax
 
G_M000_IG32:                ;; offset=0x06DC
       vmovdqu  xmm0, xmmword ptr [rbp-0x178]
       vmovdqu  xmmword ptr [rbp-0x198], xmm0
 
G_M000_IG33:                ;; offset=0x06EC
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 24
       mov      bword ptr [rbp-0x1A0], rax
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rbp-0x1A8], rax
       mov      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x1AC], eax
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x1B8], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG34
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rbp-0x1B8], rax
 
G_M000_IG34:                ;; offset=0x0732
       mov      eax, dword ptr [rbp-0x1AC]
       mov      dword ptr [rsp], eax
       mov      rax, gword ptr [rbp-0x1B8]
       mov      gword ptr [rsp+0x08], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x10], rax
       mov      rdx, bword ptr [rbp-0x198]
       mov      rcx, qword ptr [rbp-0x190]
       mov      rdi, gword ptr [rbp-0x180]
       mov      rsi, gword ptr [rbp-0x188]
       mov      r8, bword ptr [rbp-0x1A0]
       mov      r9, gword ptr [rbp-0x1A8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG35
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG48
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x330], rax
       mov      rdx, bword ptr [rbp-0x330]
       mov      rcx, gword ptr [rbp-0xF0]
       mov      r8, qword ptr [rbp-0xE8]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0xBC], 1
       jmp      G_M000_IG53
 
G_M000_IG35:                ;; offset=0x07EA
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0xF8], rax
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 32
       mov      bword ptr [rbp-0x1C0], rax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x1C4], eax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x334], eax
       mov      edx, dword ptr [rbp-0x334]
       mov      esi, dword ptr [rbp-0x1C4]
       mov      rdi, bword ptr [rbp-0x1C0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:Slice(int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      gword ptr [rbp-0x1D8], rax
       mov      qword ptr [rbp-0x1D0], rdx
 
G_M000_IG36:                ;; offset=0x086B
       vmovdqu  xmm0, xmmword ptr [rbp-0x1D8]
       vmovdqu  xmmword ptr [rbp-0xB8], xmm0
 
G_M000_IG37:                ;; offset=0x087B
       lea      rdi, [rbp-0xB8]
       call     [System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_Span():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1E8], rax
       mov      qword ptr [rbp-0x1E0], rdx
 
G_M000_IG38:                ;; offset=0x0896
       vmovdqu  xmm0, xmmword ptr [rbp-0x1E8]
       vmovdqu  xmmword ptr [rbp-0x108], xmm0
 
G_M000_IG39:                ;; offset=0x08A6
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG40
       mov      rdi, 0x7F4B841D42E8
       call     [CORINFO_HELP_GET_GCSTATIC_BASE]
       mov      rax, 0x7F3BD9801350
       mov      rax, gword ptr [rax]
       cmp      rax, gword ptr [rbp-0xD8]
       jne      G_M000_IG40
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7F4B83C33B28
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x110], rax
       cmp      gword ptr [rbp-0x110], 0
       je       SHORT G_M000_IG40
       cmp      dword ptr [rbp-0x100], 2
       jg       SHORT G_M000_IG40
       mov      rdi, bword ptr [rbp-0x108]
       mov      rsi, qword ptr [rbp-0x100]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x238], rax
       mov      qword ptr [rbp-0x230], rdx
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x238]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdx, gword ptr [rbp-0x10]
       mov      rcx, gword ptr [rbp-0x20]
       mov      r8d, dword ptr [rbp-0x24]
       mov      r9, gword ptr [rbp-0x110]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSplitUnpack(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool]
       test     eax, eax
       je       SHORT G_M000_IG40
       mov      dword ptr [rbp-0xBC], 1
       jmp      G_M000_IG53
 
G_M000_IG40:                ;; offset=0x0987
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_AccumulatesDictionary():bool:this]
       test     eax, eax
       je       G_M000_IG42
       mov      eax, dword ptr [rbp-0x100]
       mov      dword ptr [rbp-0x124], eax
       cmp      dword ptr [rbp-0x124], 1
       je       SHORT G_M000_IG41
       cmp      dword ptr [rbp-0x124], 2
       jne      G_M000_IG42
 
G_M000_IG41:                ;; offset=0x09BD
       mov      rdi, 0x7F4B841D42E8
       call     [CORINFO_HELP_GET_GCSTATIC_BASE]
       mov      rax, 0x7F3BD9801320
       mov      rax, gword ptr [rax]
       cmp      rax, gword ptr [rbp-0xD8]
       jne      G_M000_IG42
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7F4B83CFEB00
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x118], rax
       cmp      gword ptr [rbp-0x118], 0
       je       G_M000_IG42
       cmp      dword ptr [rbp-0x100], 0
       jbe      G_M000_IG48
       mov      rdi, bword ptr [rbp-0x108]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x340], rax
       mov      rsi, gword ptr [rbp-0x340]
       mov      rdi, gword ptr [rbp-0x118]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG42
       cmp      dword ptr [rbp-0x100], 0
       jbe      G_M000_IG48
       mov      rdi, bword ptr [rbp-0x108]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x348], rax
       mov      rsi, gword ptr [rbp-0x348]
       mov      rdi, 0x7F4B83C33B28
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x350], rax
       mov      r9, gword ptr [rbp-0x350]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rdx, gword ptr [rbp-0x20]
       mov      ecx, dword ptr [rbp-0x24]
       mov      r8, gword ptr [rbp-0x118]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryAccumulation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.PyDict,Lokad.Lython.Runtime.Text.PyString):bool]
       test     eax, eax
       je       SHORT G_M000_IG42
       mov      dword ptr [rbp-0xBC], 1
       jmp      G_M000_IG53
 
G_M000_IG42:                ;; offset=0x0AC3
       vmovdqu  xmm0, xmmword ptr [rbp-0x108]
       vmovdqu  xmmword ptr [rbp-0x1F8], xmm0
 
G_M000_IG43:                ;; offset=0x0AD3
       mov      rax, gword ptr [rbp-0xD8]
       mov      gword ptr [rbp-0x200], rax
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0x208], rax
 
G_M000_IG44:                ;; offset=0x0AEF
       vmovdqu  xmm0, xmmword ptr [rbp-0x1F8]
       vmovdqu  xmmword ptr [rbp-0x218], xmm0
 
G_M000_IG45:                ;; offset=0x0AFF
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x220], rax
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x228], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG46
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rbp-0x228], rax
 
G_M000_IG46:                ;; offset=0x0B2F
       lea      rax, [rbp-0x120]
       mov      qword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x218]
       mov      rcx, qword ptr [rbp-0x210]
       mov      rdi, gword ptr [rbp-0x200]
       mov      rsi, gword ptr [rbp-0x208]
       mov      r8, gword ptr [rbp-0x220]
       mov      r9, gword ptr [rbp-0x228]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG47
       xor      eax, eax
       mov      dword ptr [rbp-0xBC], eax
       jmp      G_M000_IG53
 
G_M000_IG47:                ;; offset=0x0B7B
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG48
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x358], rax
       mov      rdx, bword ptr [rbp-0x358]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdi, bword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       mov      dword ptr [rbp-0xBC], 1
       jmp      G_M000_IG53
 
G_M000_IG48:                ;; offset=0x0BD3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG49:                ;; offset=0x0BD9
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      rdi, rax
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x158], rax
       mov      qword ptr [rbp-0x150], rdx
       cmp      gword ptr [rbp-0x18], 0
       setne    al
       movzx    rax, al
       mov      dword ptr [rsp], eax
       lea      rax, [rbp-0x138]
       mov      qword ptr [rsp+0x08], rax
       mov      rdx, bword ptr [rbp-0x158]
       mov      rcx, qword ptr [rbp-0x150]
       mov      rdi, gword ptr [rbp-0x20]
       mov      rsi, gword ptr [rbp-0x30]
       mov      r8d, dword ptr [rbp-0x24]
       mov      r9, gword ptr [rbp-0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG50
       xor      eax, eax
       mov      dword ptr [rbp-0xBC], eax
       jmp      G_M000_IG53
 
G_M000_IG50:                ;; offset=0x0C53
       lea      rdi, [rbp-0x138]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x360], rax
       mov      rsi, gword ptr [rbp-0x360]
       mov      rdi, 0x7F4B8389BB68
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x140], rax
       cmp      gword ptr [rbp-0x140], 0
       je       SHORT G_M000_IG52
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rdi, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp-0x140]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xBC], 1
       jmp      SHORT G_M000_IG53
 
G_M000_IG51:                ;; offset=0x0CC2
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG52:                ;; offset=0x0CC8
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG51
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x368], rax
       mov      rdx, bword ptr [rbp-0x368]
       mov      rcx, gword ptr [rbp-0x138]
       mov      r8, qword ptr [rbp-0x130]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0xBC], 1
 
G_M000_IG53:                ;; offset=0x0D22
       mov      eax, dword ptr [rbp-0xBC]
 
G_M000_IG54:                ;; offset=0x0D28
       add      rsp, 944
       pop      rbp
       ret      
 
G_M000_IG55:                ;; offset=0x0D31
       sub      rsp, 72
 
G_M000_IG56:                ;; offset=0x0D35
       mov      gword ptr [rbp-0x2C0], rdi
       mov      rax, gword ptr [rbp-0xA8]
       mov      gword ptr [rbp-0x2C8], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x308], rax
       mov      rsi, gword ptr [rbp-0x308]
       mov      rdi, gword ptr [rbp-0x2C8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AbortPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG57:                ;; offset=0x0D82
       sub      rsp, 72
 
G_M000_IG58:                ;; offset=0x0D86
       mov      gword ptr [rbp-0x2D0], rdi
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x318], rax
       mov      rsi, gword ptr [rbp-0x318]
       lea      rdx, [rbp-0xC8]
       mov      rdi, gword ptr [rbp-0x2D0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG60
 
G_M000_IG59:                ;; offset=0x0DD6
       mov      rdi, gword ptr [rbp-0xC8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG60:                ;; offset=0x0DE3
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG61:                ;; offset=0x0DE9
       sub      rsp, 72
 
G_M000_IG62:                ;; offset=0x0DED
       cmp      dword ptr [rbp-0x5C], 0
       je       SHORT G_M000_IG63
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG63:                ;; offset=0x0DFF
       nop      
 
G_M000_IG64:                ;; offset=0x0E00
       add      rsp, 72
       ret      
 
G_M000_IG65:                ;; offset=0x0E05
       sub      rsp, 72
 
G_M000_IG66:                ;; offset=0x0E09
       mov      gword ptr [rbp-0x240], rdi
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG67:                ;; offset=0x0E2D
       sub      rsp, 72
 
G_M000_IG68:                ;; offset=0x0E31
       mov      gword ptr [rbp-0x160], rdi
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 3669

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 592
       lea      rbp, [rsp+0x250]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x200], xmm8
       vmovdqa  xmmword ptr [rbp-0x1F0], xmm8
       mov      rax, -432
 
G_M000_IG18:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG18
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x005F
       cmp      gword ptr [rbp-0x28], 0
       jne      G_M000_IG07
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       G_M000_IG07
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       jne      SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x20]
       mov      rcx, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x30]
       mov      r9, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x1EC], eax
       jmp      SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x00BD
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x1E8], eax
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x1E8]
       jne      SHORT G_M000_IG04
       mov      rsi, bword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       lea      rdi, [rbp-0x200]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       mov      rsi, bword ptr [rbp-0x200]
       mov      rdx, qword ptr [rbp-0x1F8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x1EC], eax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0120
       xor      eax, eax
       mov      dword ptr [rbp-0x1EC], eax
 
G_M000_IG05:                ;; offset=0x0128
       cmp      dword ptr [rbp-0x1EC], 0
       je       SHORT G_M000_IG07
       mov      rax, bword ptr [rbp+0x38]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x48]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG06:                ;; offset=0x0141
       add      rsp, 592
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x014A
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x130], ymm0
       vmovdqu  ymmword ptr [rbp-0x110], ymm0
       vmovdqu  ymmword ptr [rbp-0xF0], ymm0
       vmovdqu  ymmword ptr [rbp-0xD0], ymm0
       vmovdqu  ymmword ptr [rbp-0xB0], ymm0
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
       vmovdqu  ymmword ptr [rbp-0x70], ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
       lea      rdi, [rbp-0x130]
       mov      esi, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x1A0], rax
       mov      qword ptr [rbp-0x198], rdx
 
G_M000_IG08:                ;; offset=0x01A8
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG09:                ;; offset=0x01B8
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x204], eax
       mov      edx, dword ptr [rbp-0x204]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1B0], rax
       mov      qword ptr [rbp-0x1A8], rdx
 
G_M000_IG10:                ;; offset=0x01F6
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG11:                ;; offset=0x0206
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       je       G_M000_IG13
       xor      eax, eax
       mov      dword ptr [rbp-0x144], eax
       cmp      gword ptr [rbp-0x28], 0
       je       SHORT G_M000_IG12
       mov      eax, dword ptr [rbp-0x144]
       mov      dword ptr [rbp-0x1E4], eax
       mov      eax, dword ptr [rbp-0x144]
       inc      eax
       mov      dword ptr [rbp-0x144], eax
       mov      eax, dword ptr [rbp-0x138]
       cmp      dword ptr [rbp-0x1E4], eax
       jae      G_M000_IG17
       mov      eax, dword ptr [rbp-0x1E4]
       shl      rax, 4
       mov      rdi, rax
       add      rdi, bword ptr [rbp-0x140]
       mov      rsi, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG12:                ;; offset=0x026B
       lea      rdi, [rbp-0x140]
       mov      esi, dword ptr [rbp-0x144]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1E0], rax
       mov      qword ptr [rbp-0x1D8], rdx
       mov      rsi, bword ptr [rbp-0x1E0]
       mov      rdx, qword ptr [rbp-0x1D8]
       lea      rdi, [rbp-0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG14
 
G_M000_IG13:                ;; offset=0x02A9
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x208], eax
       mov      edx, dword ptr [rbp-0x208]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1C0], rax
       mov      qword ptr [rbp-0x1B8], rdx
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x08], eax
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rsp+0x18], rax
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp-0x20]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, bword ptr [rbp-0x1C0]
       mov      rsi, qword ptr [rbp-0x1B8]
       mov      rdx, bword ptr [rbp-0x158]
       mov      rcx, qword ptr [rbp-0x150]
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG14:                ;; offset=0x034D
       vmovdqu  xmm0, xmmword ptr [rbp-0x140]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG15:                ;; offset=0x035D
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x190], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x190]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], rax
       lea      rax, [rbp-0x170]
       mov      qword ptr [rsp+0x40], rax
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rsi, bword ptr [rbp-0x1D0]
       mov      rdx, qword ptr [rbp-0x1C8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG16:                ;; offset=0x03F7
       add      rsp, 592
       pop      rbp
       ret      
 
G_M000_IG17:                ;; offset=0x0400
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1030

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 944
       lea      rbp, [rsp+0x3B0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x370], xmm8
       mov      rax, -816
 
G_M000_IG86:                ;; offset=0x0027
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG86
       mov      bword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
       mov      gword ptr [rbp-0x20], rcx
       mov      dword ptr [rbp-0x24], r8d
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x0057
       mov      rax, bword ptr [rbp+0x10]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdi, 0x7F4B841ACE90
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x38], rax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG04
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x2E0], rax
       mov      rsi, gword ptr [rbp-0x2E0]
       mov      rdi, 0x7F4B83F35F20
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x00C2
       mov      rdi, 0x7F4B84589C50
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00D1
       xor      rax, rax
       mov      gword ptr [rbp-0x148], rax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x00DC
       mov      rdi, 0x7F4B84589C54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x148], rax
 
G_M000_IG06:                ;; offset=0x0109
       mov      rax, gword ptr [rbp-0x148]
       mov      gword ptr [rbp-0x40], rax
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdi, 0x7F4B841D33F8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       SHORT G_M000_IG07
       mov      rdi, gword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Function():Lokad.Lython.Runtime.LythonRuntime+ICallable:this]
       mov      gword ptr [rbp-0x2E8], rax
       mov      rsi, gword ptr [rbp-0x2E8]
       mov      rdi, 0x7F4B841ACE90
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       je       G_M000_IG10
       mov      rdi, 0x7F4B84589C58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x38], rax
       mov      rdi, gword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Receiver():System.Object:this]
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG07:                ;; offset=0x0193
       cmp      gword ptr [rbp-0x38], 0
       je       G_M000_IG28
       cmp      gword ptr [rbp-0x18], 0
       je       SHORT G_M000_IG09
       lea      rcx, [rbp-0x58]
       mov      rdi, gword ptr [rbp-0x38]
       mov      rsi, gword ptr [rbp-0x20]
       mov      rdx, gword ptr [rbp-0x40]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG11
       mov      rdi, 0x7F4B84589C5C
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG08:                ;; offset=0x01D2
       add      rsp, 944
       pop      rbp
       ret      
 
G_M000_IG09:                ;; offset=0x01DB
       mov      rdi, 0x7F4B84589C60
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG28
 
G_M000_IG10:                ;; offset=0x01EF
       mov      rdi, 0x7F4B84589C64
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG07
 
G_M000_IG11:                ;; offset=0x0200
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
 
G_M000_IG12:                ;; offset=0x0205
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2F0], rax
       mov      rsi, gword ptr [rbp-0x2F0]
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x5C], 1
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2F8], rax
       mov      rsi, gword ptr [rbp-0x2F8]
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 32
       mov      bword ptr [rbp-0x258], rax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x25C], eax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x2FC], eax
       mov      edx, dword ptr [rbp-0x2FC]
       mov      esi, dword ptr [rbp-0x25C]
       mov      rdi, bword ptr [rbp-0x258]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:Slice(int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      gword ptr [rbp-0x270], rax
       mov      qword ptr [rbp-0x268], rdx
 
G_M000_IG13:                ;; offset=0x02BB
       vmovdqu  xmm0, xmmword ptr [rbp-0x270]
       vmovdqu  xmmword ptr [rbp-0xB8], xmm0
 
G_M000_IG14:                ;; offset=0x02CB
       lea      rdi, [rbp-0xB8]
       call     [System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_Span():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x280], rax
       mov      qword ptr [rbp-0x278], rdx
 
G_M000_IG15:                ;; offset=0x02E6
       vmovdqu  xmm0, xmmword ptr [rbp-0x280]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG16:                ;; offset=0x02F3
       lea      rcx, [rbp-0x88]
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x20]
       mov      edx, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PrepareUnpackedCallReturn(byref,Lokad.Lython.Frontend.ExecutableCallSite,int,byref):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x290], rax
       mov      qword ptr [rbp-0x288], rdx
 
G_M000_IG17:                ;; offset=0x0319
       vmovdqu  xmm0, xmmword ptr [rbp-0x290]
       vmovdqu  xmmword ptr [rbp-0x80], xmm0
 
G_M000_IG18:                ;; offset=0x0326
       mov      rdi, bword ptr [rbp-0x70]
       mov      rsi, qword ptr [rbp-0x68]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x2A0], rax
       mov      qword ptr [rbp-0x298], rdx
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2A8], rax
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CallResultConsumedByIteration(byref,Lokad.Lython.Frontend.ExecutableCallSite):bool]
       mov      dword ptr [rbp-0x300], eax
       movzx    rax, byte  ptr [rbp-0x58]
       mov      dword ptr [rsp+0x10], eax
       lea      rdi, [rsp+0x18]
       lea      rsi, [rbp-0x80]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x18], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rax, [rbp-0x90]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0xA0]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0xA8]
       mov      qword ptr [rsp+0x38], rax
       mov      eax, dword ptr [rbp-0x300]
       mov      dword ptr [rsp+0x08], eax
       mov      rdx, bword ptr [rbp-0x2A0]
       mov      rcx, qword ptr [rbp-0x298]
       mov      rsi, gword ptr [rbp-0x20]
       mov      r8, gword ptr [rbp-0x40]
       mov      r9, gword ptr [rbp-0x10]
       mov      rax, gword ptr [rbp-0x2A8]
       mov      gword ptr [rsp], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       movzx    rax, byte  ptr [rbp-0x90]
       test     eax, eax
       jne      SHORT G_M000_IG19
       mov      rdi, 0x7F4B84589C68
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x88]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RestoreNativeExtent(int):this]
 
G_M000_IG19:                ;; offset=0x041F
       cmp      gword ptr [rbp-0xA8], 0
       je       G_M000_IG22
 
G_M000_IG20:                ;; offset=0x042D
       mov      rdi, gword ptr [rbp-0xA8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterExecutableSlots():this]
       mov      rax, gword ptr [rbp-0xA8]
       mov      gword ptr [rbp-0x2B0], rax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2B8], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x308], rax
       mov      rax, gword ptr [rbp-0x308]
       mov      gword ptr [rsp], rax
       mov      rsi, gword ptr [rbp-0x2B0]
       mov      rdx, gword ptr [rbp-0x20]
       mov      ecx, dword ptr [rbp-0x24]
       mov      r8, gword ptr [rbp-0x2B8]
       mov      rdi, gword ptr [rbp-0x18]
       xor      r9d, r9d
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AttachPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.LythonSourceSpan,int,Lokad.Lython.Runtime.MemoryGovernor):this]
       nop      
 
G_M000_IG21:                ;; offset=0x04AB
       mov      rdi, 0x7F4B84589C6C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       mov      dword ptr [rbp-0xBC], 1
       jmp      G_M000_IG26
 
G_M000_IG22:                ;; offset=0x04DE
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       movzx    rax, byte  ptr [rbp-0x90]
       test     eax, eax
       je       SHORT G_M000_IG23
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      edx, dword ptr [rbp-0x24]
       mov      ecx, dword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteUnpackedCallReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,int)]
       jmp      SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x0510
       mov      rdi, 0x7F4B84589C70
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG25
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x318], rax
       mov      rdx, bword ptr [rbp-0x318]
       mov      rcx, gword ptr [rbp-0xA0]
       mov      r8, qword ptr [rbp-0x98]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
 
G_M000_IG24:                ;; offset=0x056F
       mov      rdi, 0x7F4B84589C74
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xBC], 1
       jmp      SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x058A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG26:                ;; offset=0x0590
       call     G_M000_IG78
       jmp      G_M000_IG70
 
G_M000_IG27:                ;; offset=0x059A
       call     G_M000_IG78
       jmp      G_M000_IG70
 
G_M000_IG28:                ;; offset=0x05A4
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG66
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       je       G_M000_IG33
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG34
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x328], rax
       mov      rsi, gword ptr [rbp-0x328]
       mov      rdi, 0x7F4B841D38C0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xD0], rax
       cmp      gword ptr [rbp-0xD0], 0
       je       G_M000_IG32
       mov      rax, bword ptr [rbp-0x08]
       mov      bword ptr [rbp-0x248], rax
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x250], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG29
       mov      rdi, 0x7F4B84589C80
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rbp-0x250], rax
 
G_M000_IG29:                ;; offset=0x0656
       mov      rdi, bword ptr [rbp-0x248]
       mov      rsi, gword ptr [rbp-0x250]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0xD0]
       mov      r8d, dword ptr [rbp-0x24]
       mov      r9, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteCasedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCasedSplit,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG31
       mov      rdi, 0x7F4B84589C84
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG30:                ;; offset=0x0695
       add      rsp, 944
       pop      rbp
       ret      
 
G_M000_IG31:                ;; offset=0x069E
       mov      rdi, 0x7F4B84589C88
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG34
 
G_M000_IG32:                ;; offset=0x06AF
       mov      rdi, 0x7F4B84589C8C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x06C0
       mov      rdi, 0x7F4B84589C90
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG66
 
G_M000_IG34:                ;; offset=0x06D4
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdi, 0x7F4B841D3CE8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xD8], rax
       cmp      gword ptr [rbp-0xD8], 0
       jne      SHORT G_M000_IG36
       mov      rdi, 0x7F4B84589C94
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG35:                ;; offset=0x070A
       add      rsp, 944
       pop      rbp
       ret      
 
G_M000_IG36:                ;; offset=0x0713
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x330], rax
       mov      rsi, gword ptr [rbp-0x330]
       mov      rdi, 0x7F4B841D3FF0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xE0], rax
       cmp      gword ptr [rbp-0xE0], 0
       je       SHORT G_M000_IG38
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp], rax
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0xE0]
       mov      r8, gword ptr [rbp-0x20]
       mov      r9d, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteTrimmedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG37
       mov      rdi, 0x7F4B84589C98
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xBC], 1
       jmp      G_M000_IG70
 
G_M000_IG37:                ;; offset=0x0799
       mov      rdi, 0x7F4B84589C9C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG38:                ;; offset=0x07A8
       mov      rax, bword ptr [rbp-0x08]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x168], rax
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      rdi, rax
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x178], rax
       mov      qword ptr [rbp-0x170], rdx
       mov      rax, gword ptr [rbp-0xD8]
       mov      gword ptr [rbp-0x180], rax
       mov      rax, gword ptr [rbp-0x168]
       mov      gword ptr [rbp-0x188], rax
 
G_M000_IG39:                ;; offset=0x07FD
       vmovdqu  xmm0, xmmword ptr [rbp-0x178]
       vmovdqu  xmmword ptr [rbp-0x198], xmm0
 
G_M000_IG40:                ;; offset=0x080D
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 24
       mov      bword ptr [rbp-0x1A0], rax
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rbp-0x1A8], rax
       mov      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x1AC], eax
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x1B8], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG41
       mov      rdi, 0x7F4B84589CA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rbp-0x1B8], rax
 
G_M000_IG41:                ;; offset=0x0862
       mov      eax, dword ptr [rbp-0x1AC]
       mov      dword ptr [rsp], eax
       mov      rax, gword ptr [rbp-0x1B8]
       mov      gword ptr [rsp+0x08], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x10], rax
       mov      rdx, bword ptr [rbp-0x198]
       mov      rcx, qword ptr [rbp-0x190]
       mov      rdi, gword ptr [rbp-0x180]
       mov      rsi, gword ptr [rbp-0x188]
       mov      r8, bword ptr [rbp-0x1A0]
       mov      r9, gword ptr [rbp-0x1A8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG42
       mov      rdi, 0x7F4B84589CA4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG65
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x338], rax
       mov      rdx, bword ptr [rbp-0x338]
       mov      rcx, gword ptr [rbp-0xF0]
       mov      r8, qword ptr [rbp-0xE8]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0xBC], 1
       jmp      G_M000_IG70
 
G_M000_IG42:                ;; offset=0x0929
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0xF8], rax
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 32
       mov      bword ptr [rbp-0x1C0], rax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x1C4], eax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x33C], eax
       mov      edx, dword ptr [rbp-0x33C]
       mov      esi, dword ptr [rbp-0x1C4]
       mov      rdi, bword ptr [rbp-0x1C0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:Slice(int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      gword ptr [rbp-0x1D8], rax
       mov      qword ptr [rbp-0x1D0], rdx
 
G_M000_IG43:                ;; offset=0x09AA
       vmovdqu  xmm0, xmmword ptr [rbp-0x1D8]
       vmovdqu  xmmword ptr [rbp-0xB8], xmm0
 
G_M000_IG44:                ;; offset=0x09BA
       lea      rdi, [rbp-0xB8]
       call     [System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_Span():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1E8], rax
       mov      qword ptr [rbp-0x1E0], rdx
 
G_M000_IG45:                ;; offset=0x09D5
       vmovdqu  xmm0, xmmword ptr [rbp-0x1E8]
       vmovdqu  xmmword ptr [rbp-0x108], xmm0
 
G_M000_IG46:                ;; offset=0x09E5
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG51
       mov      rdi, 0x7F4B841D42E8
       call     [CORINFO_HELP_GET_GCSTATIC_BASE]
       mov      rax, 0x7F3BD9801350
       mov      rax, gword ptr [rax]
       cmp      rax, gword ptr [rbp-0xD8]
       jne      G_M000_IG50
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7F4B83C33B28
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x110], rax
       cmp      gword ptr [rbp-0x110], 0
       je       G_M000_IG49
       cmp      dword ptr [rbp-0x100], 2
       jg       G_M000_IG48
       mov      rdi, bword ptr [rbp-0x108]
       mov      rsi, qword ptr [rbp-0x100]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x238], rax
       mov      qword ptr [rbp-0x230], rdx
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x238]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdx, gword ptr [rbp-0x10]
       mov      rcx, gword ptr [rbp-0x20]
       mov      r8d, dword ptr [rbp-0x24]
       mov      r9, gword ptr [rbp-0x110]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSplitUnpack(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool]
       test     eax, eax
       je       SHORT G_M000_IG47
       mov      rdi, 0x7F4B84589CA8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xBC], 1
       jmp      G_M000_IG70
 
G_M000_IG47:                ;; offset=0x0ADD
       mov      rdi, 0x7F4B84589CAC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG51
 
G_M000_IG48:                ;; offset=0x0AEE
       mov      rdi, 0x7F4B84589CB0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG51
 
G_M000_IG49:                ;; offset=0x0AFF
       mov      rdi, 0x7F4B84589CB4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG51
 
G_M000_IG50:                ;; offset=0x0B10
       mov      rdi, 0x7F4B84589CB8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:                ;; offset=0x0B1F
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_AccumulatesDictionary():bool:this]
       test     eax, eax
       je       G_M000_IG59
       mov      eax, dword ptr [rbp-0x100]
       mov      dword ptr [rbp-0x124], eax
       cmp      dword ptr [rbp-0x124], 1
       je       SHORT G_M000_IG53
       cmp      dword ptr [rbp-0x124], 2
       jne      G_M000_IG58
 
G_M000_IG52:                ;; offset=0x0B55
       mov      rdi, 0x7F4B84589CBC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG53:                ;; offset=0x0B64
       mov      rdi, 0x7F4B841D42E8
       call     [CORINFO_HELP_GET_GCSTATIC_BASE]
       mov      rax, 0x7F3BD9801320
       mov      rax, gword ptr [rax]
       cmp      rax, gword ptr [rbp-0xD8]
       jne      G_M000_IG57
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7F4B83CFEB00
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x118], rax
       cmp      gword ptr [rbp-0x118], 0
       je       G_M000_IG56
       cmp      dword ptr [rbp-0x100], 0
       jbe      G_M000_IG65
       mov      rdi, bword ptr [rbp-0x108]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x348], rax
       mov      rsi, gword ptr [rbp-0x348]
       mov      rdi, gword ptr [rbp-0x118]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG55
       cmp      dword ptr [rbp-0x100], 0
       jbe      G_M000_IG65
       mov      rdi, bword ptr [rbp-0x108]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x350], rax
       mov      rsi, gword ptr [rbp-0x350]
       mov      rdi, 0x7F4B83C33B28
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x358], rax
       mov      r9, gword ptr [rbp-0x358]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rdx, gword ptr [rbp-0x20]
       mov      ecx, dword ptr [rbp-0x24]
       mov      r8, gword ptr [rbp-0x118]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryAccumulation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.PyDict,Lokad.Lython.Runtime.Text.PyString):bool]
       test     eax, eax
       je       SHORT G_M000_IG54
       mov      rdi, 0x7F4B84589CC0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xBC], 1
       jmp      G_M000_IG70
 
G_M000_IG54:                ;; offset=0x0C7D
       mov      rdi, 0x7F4B84589CC4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG59
 
G_M000_IG55:                ;; offset=0x0C8E
       mov      rdi, 0x7F4B84589CC8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG59
 
G_M000_IG56:                ;; offset=0x0C9F
       mov      rdi, 0x7F4B84589CCC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG59
 
G_M000_IG57:                ;; offset=0x0CB0
       mov      rdi, 0x7F4B84589CD0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x0CC1
       mov      rdi, 0x7F4B84589CD4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG59:                ;; offset=0x0CD0
       vmovdqu  xmm0, xmmword ptr [rbp-0x108]
       vmovdqu  xmmword ptr [rbp-0x1F8], xmm0
 
G_M000_IG60:                ;; offset=0x0CE0
       mov      rax, gword ptr [rbp-0xD8]
       mov      gword ptr [rbp-0x200], rax
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0x208], rax
 
G_M000_IG61:                ;; offset=0x0CFC
       vmovdqu  xmm0, xmmword ptr [rbp-0x1F8]
       vmovdqu  xmmword ptr [rbp-0x218], xmm0
 
G_M000_IG62:                ;; offset=0x0D0C
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x220], rax
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x228], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG63
       mov      rdi, 0x7F4B84589CD8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rbp-0x228], rax
 
G_M000_IG63:                ;; offset=0x0D4B
       lea      rax, [rbp-0x120]
       mov      qword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x218]
       mov      rcx, qword ptr [rbp-0x210]
       mov      rdi, gword ptr [rbp-0x200]
       mov      rsi, gword ptr [rbp-0x208]
       mov      r8, gword ptr [rbp-0x220]
       mov      r9, gword ptr [rbp-0x228]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG64
       mov      rdi, 0x7F4B84589CDC
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0xBC], eax
       jmp      G_M000_IG70
 
G_M000_IG64:                ;; offset=0x0DA6
       mov      rdi, 0x7F4B84589CE0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG65
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x360], rax
       mov      rdx, bword ptr [rbp-0x360]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdi, bword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       mov      dword ptr [rbp-0xBC], 1
       jmp      G_M000_IG70
 
G_M000_IG65:                ;; offset=0x0E0D
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG66:                ;; offset=0x0E13
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      rdi, rax
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x158], rax
       mov      qword ptr [rbp-0x150], rdx
       cmp      gword ptr [rbp-0x18], 0
       setne    al
       movzx    rax, al
       mov      dword ptr [rsp], eax
       lea      rax, [rbp-0x138]
       mov      qword ptr [rsp+0x08], rax
       mov      rdx, bword ptr [rbp-0x158]
       mov      rcx, qword ptr [rbp-0x150]
       mov      rdi, gword ptr [rbp-0x20]
       mov      rsi, gword ptr [rbp-0x30]
       mov      r8d, dword ptr [rbp-0x24]
       mov      r9, gword ptr [rbp-0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG67
       xor      eax, eax
       mov      dword ptr [rbp-0xBC], eax
       jmp      G_M000_IG70
 
G_M000_IG67:                ;; offset=0x0E8D
       lea      rdi, [rbp-0x138]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x2D8], rax
       mov      rdi, gword ptr [rbp-0x2D8]
       mov      rsi, 0x7F4B84589CE8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x2D8]
       mov      gword ptr [rbp-0x368], rax
       mov      rsi, gword ptr [rbp-0x368]
       mov      rdi, 0x7F4B8389BB68
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x140], rax
       cmp      gword ptr [rbp-0x140], 0
       je       SHORT G_M000_IG69
       mov      rdi, 0x7F4B84589DF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rdi, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp-0x140]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xBC], 1
       jmp      SHORT G_M000_IG70
 
G_M000_IG68:                ;; offset=0x0F2F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG69:                ;; offset=0x0F35
       mov      rdi, 0x7F4B84589DF4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG68
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x370], rax
       mov      rdx, bword ptr [rbp-0x370]
       mov      rcx, gword ptr [rbp-0x138]
       mov      r8, qword ptr [rbp-0x130]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0xBC], 1
 
G_M000_IG70:                ;; offset=0x0F9E
       mov      rdi, 0x7F4B84589DF8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xBC]
 
G_M000_IG71:                ;; offset=0x0FB3
       add      rsp, 944
       pop      rbp
       ret      
 
G_M000_IG72:                ;; offset=0x0FBC
       sub      rsp, 72
 
G_M000_IG73:                ;; offset=0x0FC0
       mov      gword ptr [rbp-0x2C0], rdi
       mov      rax, gword ptr [rbp-0xA8]
       mov      gword ptr [rbp-0x2C8], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x310], rax
       mov      rsi, gword ptr [rbp-0x310]
       mov      rdi, gword ptr [rbp-0x2C8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AbortPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG74:                ;; offset=0x100D
       sub      rsp, 72
 
G_M000_IG75:                ;; offset=0x1011
       mov      gword ptr [rbp-0x2D0], rdi
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x320], rax
       mov      rsi, gword ptr [rbp-0x320]
       lea      rdx, [rbp-0xC8]
       mov      rdi, gword ptr [rbp-0x2D0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG77
 
G_M000_IG76:                ;; offset=0x1061
       mov      rdi, gword ptr [rbp-0xC8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG77:                ;; offset=0x106E
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG78:                ;; offset=0x1074
       sub      rsp, 72
 
G_M000_IG79:                ;; offset=0x1078
       cmp      dword ptr [rbp-0x5C], 0
       je       SHORT G_M000_IG80
       mov      rdi, 0x7F4B84589C78
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG80:                ;; offset=0x1099
       mov      rdi, 0x7F4B84589C7C
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG81:                ;; offset=0x10A9
       add      rsp, 72
       ret      
 
G_M000_IG82:                ;; offset=0x10AE
       sub      rsp, 72
 
G_M000_IG83:                ;; offset=0x10B2
       mov      gword ptr [rbp-0x240], rdi
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG84:                ;; offset=0x10D6
       sub      rsp, 72
 
G_M000_IG85:                ;; offset=0x10DA
       mov      gword ptr [rbp-0x160], rdi
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 4350

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 592
       lea      rbp, [rsp+0x250]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x200], xmm8
       vmovdqa  xmmword ptr [rbp-0x1F0], xmm8
       mov      rax, -432
 
G_M000_IG21:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG21
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x005F
       cmp      gword ptr [rbp-0x28], 0
       jne      G_M000_IG09
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG03
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x20]
       mov      rcx, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x30]
       mov      r9, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x1EC], eax
       jmp      G_M000_IG06
 
G_M000_IG03:                ;; offset=0x00BC
       mov      rdi, 0x7F4B8458A2E0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG09
 
G_M000_IG04:                ;; offset=0x00D0
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x1E8], eax
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x1E8]
       jne      SHORT G_M000_IG05
       mov      rdi, 0x7F4B8458A2E4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, bword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       lea      rdi, [rbp-0x200]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       mov      rsi, bword ptr [rbp-0x200]
       mov      rdx, qword ptr [rbp-0x1F8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x1EC], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0142
       mov      rdi, 0x7F4B8458A2E8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x1EC], eax
 
G_M000_IG06:                ;; offset=0x0159
       cmp      dword ptr [rbp-0x1EC], 0
       je       SHORT G_M000_IG08
       mov      rdi, 0x7F4B8458A2EC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x38]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x48]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG07:                ;; offset=0x0181
       add      rsp, 592
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x018A
       mov      rdi, 0x7F4B8458A2F0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG09:                ;; offset=0x0199
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x130], ymm0
       vmovdqu  ymmword ptr [rbp-0x110], ymm0
       vmovdqu  ymmword ptr [rbp-0xF0], ymm0
       vmovdqu  ymmword ptr [rbp-0xD0], ymm0
       vmovdqu  ymmword ptr [rbp-0xB0], ymm0
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
       vmovdqu  ymmword ptr [rbp-0x70], ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
       lea      rdi, [rbp-0x130]
       mov      esi, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x1A0], rax
       mov      qword ptr [rbp-0x198], rdx
 
G_M000_IG10:                ;; offset=0x01F7
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG11:                ;; offset=0x0207
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x204], eax
       mov      edx, dword ptr [rbp-0x204]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1B0], rax
       mov      qword ptr [rbp-0x1A8], rdx
 
G_M000_IG12:                ;; offset=0x0245
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG13:                ;; offset=0x0255
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       je       G_M000_IG15
       xor      eax, eax
       mov      dword ptr [rbp-0x144], eax
       cmp      gword ptr [rbp-0x28], 0
       je       SHORT G_M000_IG14
       mov      rdi, 0x7F4B8458A2F4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x144]
       mov      dword ptr [rbp-0x1E4], eax
       mov      eax, dword ptr [rbp-0x144]
       inc      eax
       mov      dword ptr [rbp-0x144], eax
       mov      eax, dword ptr [rbp-0x138]
       cmp      dword ptr [rbp-0x1E4], eax
       jae      G_M000_IG20
       mov      eax, dword ptr [rbp-0x1E4]
       shl      rax, 4
       mov      rdi, rax
       add      rdi, bword ptr [rbp-0x140]
       mov      rsi, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG14:                ;; offset=0x02C9
       lea      rdi, [rbp-0x140]
       mov      esi, dword ptr [rbp-0x144]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1E0], rax
       mov      qword ptr [rbp-0x1D8], rdx
       mov      rsi, bword ptr [rbp-0x1E0]
       mov      rdx, qword ptr [rbp-0x1D8]
       lea      rdi, [rbp-0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0307
       mov      rdi, 0x7F4B8458A2F8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x208], eax
       mov      edx, dword ptr [rbp-0x208]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1C0], rax
       mov      qword ptr [rbp-0x1B8], rdx
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x08], eax
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rsp+0x18], rax
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp-0x20]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, bword ptr [rbp-0x1C0]
       mov      rsi, qword ptr [rbp-0x1B8]
       mov      rdx, bword ptr [rbp-0x158]
       mov      rcx, qword ptr [rbp-0x150]
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG16:                ;; offset=0x03BA
       mov      rdi, 0x7F4B8458A2FC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:                ;; offset=0x03C9
       vmovdqu  xmm0, xmmword ptr [rbp-0x140]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG18:                ;; offset=0x03D9
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x190], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x190]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], rax
       lea      rax, [rbp-0x170]
       mov      qword ptr [rsp+0x40], rax
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rsi, bword ptr [rbp-0x1D0]
       mov      rdx, qword ptr [rbp-0x1C8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG19:                ;; offset=0x0473
       add      rsp, 592
       pop      rbp
       ret      
 
G_M000_IG20:                ;; offset=0x047C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1154

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 16580
; 19 inlinees with PGO data; 108 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 248
       lea      rbp, [rsp+0x120]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x90], ymm8
       vmovdqu  ymmword ptr [rbp-0x70], ymm8
       vmovdqu  ymmword ptr [rbp-0x50], ymm8
       mov      bword ptr [rbp-0xB0], rdi
       mov      gword ptr [rbp-0xB8], rsi
       mov      gword ptr [rbp-0xC0], rcx
       mov      dword ptr [rbp-0x2C], r8d
       mov      r15, rdx
       mov      rbx, r9
 
G_M000_IG02:                ;; offset=0x004F
       xor      rsi, rsi
       mov      r14, bword ptr [rbp+0x10]
       mov      gword ptr [r14], rsi
       test     rbx, rbx
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x005D
       mov      rsi, 0x7F4B841ACE90
       cmp      qword ptr [rbx], rsi
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x006C
       mov      gword ptr [rbp-0xC8], rbx
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0075
       xor      rsi, rsi
       mov      gword ptr [rbp-0xC8], rsi
 
G_M000_IG06:                ;; offset=0x007E
       cmp      byte  ptr [rcx+0x30], 0
       jne      G_M000_IG76
 
G_M000_IG07:                ;; offset=0x0088
       xor      r13, r13
 
G_M000_IG08:                ;; offset=0x008B
       test     rbx, rbx
       je       SHORT G_M000_IG14
 
G_M000_IG09:                ;; offset=0x0090
       mov      rsi, 0x7F4B841D33F8
       cmp      qword ptr [rbx], rsi
       jne      SHORT G_M000_IG14
 
G_M000_IG10:                ;; offset=0x009F
       mov      rsi, gword ptr [rbx+0x10]
       test     rsi, rsi
       je       SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x00A8
       mov      rax, 0x7F4B841ACE90
       xor      rdx, rdx
       cmp      qword ptr [rsi], rax
       cmovne   rsi, rdx
 
G_M000_IG12:                ;; offset=0x00BB
       test     rsi, rsi
       je       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x00C0
       mov      gword ptr [rbp-0xC8], rsi
       mov      r13, gword ptr [rbx+0x08]
 
G_M000_IG14:                ;; offset=0x00CB
       cmp      gword ptr [rbp-0xC8], 0
       je       G_M000_IG61
 
G_M000_IG15:                ;; offset=0x00D9
       test     r15, r15
       je       G_M000_IG79
       mov      rsi, gword ptr [rbp-0xC8]
       mov      rsi, gword ptr [rsi+0x40]
       cmp      byte  ptr [rsi+0xDF], 0
       je       G_M000_IG77
       mov      rax, gword ptr [rbp-0xC8]
       mov      rax, gword ptr [rax+0x28]
       cmp      byte  ptr [rax+0xFA], 0
       jne      G_M000_IG77
       cmp      byte  ptr [rax+0xFB], 0
       jne      G_M000_IG77
       cmp      byte  ptr [rax+0xFC], 0
       jne      G_M000_IG77
       cmp      gword ptr [rax+0xC0], 0
       jne      G_M000_IG77
       cmp      dword ptr [rsi+0xD4], 16
       jg       G_M000_IG77
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      byte  ptr [rcx+0x34], 0
       je       G_M000_IG80
       mov      esi, dword ptr [rcx+0x28]
       mov      rax, gword ptr [rbp-0xC8]
       mov      rax, gword ptr [rax+0x08]
       cmp      byte  ptr [rax+0x54], 0
       je       G_M000_IG72
 
G_M000_IG16:                ;; offset=0x0170
       mov      eax, dword ptr [rax+0x3C]
       test     r13, r13
       setne    dl
       movzx    rdx, dl
       sub      eax, edx
       cmp      eax, esi
       sete     bl
       movzx    rbx, bl
 
G_M000_IG17:                ;; offset=0x0186
       test     ebx, ebx
       je       G_M000_IG73
 
G_M000_IG18:                ;; offset=0x018E
       mov      rdi, bword ptr [rbp-0xB0]
       xor      esi, esi
       mov      dword ptr [rbp-0x30], esi
 
G_M000_IG19:                ;; offset=0x019A
       mov      rcx, gword ptr [rbp-0xC0]
       mov      rsi, gword ptr [rcx+0x18]
       mov      r9, gword ptr [rbp-0xB8]
       mov      rdi, gword ptr [r9+0x98]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x30], 1
       mov      rcx, gword ptr [rbp-0xC0]
       mov      rsi, gword ptr [rcx+0x18]
       mov      r9, gword ptr [rbp-0xB8]
       mov      rdi, gword ptr [r9+0x98]
       mov      rax, gword ptr [rdi+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG45
       mov      rax, gword ptr [rdi+0x180]
       test     rax, rax
       jne      G_M000_IG44
 
G_M000_IG20:                ;; offset=0x01FD
       mov      rdi, bword ptr [rbp-0xB0]
       lea      rax, bword ptr [rdi+0x20]
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      byte  ptr [rcx+0x30], 0
       setne    dl
       movzx    rdx, dl
       mov      esi, dword ptr [rbp-0x2C]
       lea      r12d, [rsi+rdx+0x01]
       mov      edx, dword ptr [rcx+0x28]
       mov      rax, gword ptr [rax]
       test     rax, rax
       je       G_M000_IG46
       mov      r8d, r12d
       mov      r10d, edx
       add      r8, r10
       mov      r10d, dword ptr [rax+0x08]
       cmp      r8, r10
       ja       G_M000_IG47
       mov      r8d, edx
 
G_M000_IG21:                ;; offset=0x0249
       xor      rdx, rdx
       xor      r10d, r10d
       test     rax, rax
       je       SHORT G_M000_IG24
 
G_M000_IG22:                ;; offset=0x0253
       mov      rdx, qword ptr [rax]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       je       G_M000_IG49
       lea      rdx, bword ptr [rax+0x10]
       mov      r10d, dword ptr [rax+0x08]
 
G_M000_IG23:                ;; offset=0x026A
       and      r12d, 0x7FFFFFFF
       mov      eax, r12d
       mov      r11d, r8d
       add      r11, rax
       mov      r10d, r10d
       cmp      r11, r10
       ja       G_M000_IG47
       shl      rax, 4
       add      rdx, rax
       mov      bword ptr [rbp-0xE0], rdx
       mov      dword ptr [rbp-0x94], r8d
       mov      rdx, bword ptr [rbp-0xE0]
       mov      r10d, dword ptr [rbp-0x94]
 
G_M000_IG24:                ;; offset=0x02A9
       mov      rdi, bword ptr [rbp-0xB0]
       mov      r12d, dword ptr [rdi+0x60]
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx+0x2C], 0
       jne      G_M000_IG50
 
G_M000_IG25:                ;; offset=0x02C5
       mov      rcx, gword ptr [rbp-0xC0]
       xor      r8, r8
       xor      eax, eax
 
G_M000_IG26:                ;; offset=0x02D1
       mov      r11, gword ptr [rcx+0x18]
       cmp      byte  ptr [rcx+0x31], 0
       jne      G_M000_IG55
       cmp      byte  ptr [rdi+0x1C], 0
       jne      G_M000_IG54
       xor      r14d, r14d
 
G_M000_IG27:                ;; offset=0x02EC
       mov      gword ptr [rsp], r11
       mov      dword ptr [rsp+0x08], r14d
       mov      dword ptr [rsp+0x10], ebx
       mov      bword ptr [rsp+0x18], r8
       mov      dword ptr [rbp-0x9C], eax
       mov      dword ptr [rsp+0x20], eax
       lea      r8, [rbp-0x38]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0x48]
       mov      qword ptr [rsp+0x30], r8
       lea      r8, [rbp-0x50]
       mov      qword ptr [rsp+0x38], r8
       mov      ecx, r10d
       mov      rdi, gword ptr [rbp-0xC8]
       mov      rsi, gword ptr [rbp-0xC0]
       mov      r8, r13
       mov      r9, gword ptr [rbp-0xB8]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       cmp      byte  ptr [rbp-0x38], 0
       jne      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x034A
       mov      rdi, bword ptr [rbp-0xB0]
       mov      dword ptr [rdi+0x60], r12d
 
G_M000_IG29:                ;; offset=0x0355
       cmp      gword ptr [rbp-0x50], 0
       jne      G_M000_IG56
       mov      r9, gword ptr [rbp-0xB8]
       mov      rcx, gword ptr [r9+0x98]
       mov      r8, qword ptr [rcx+0x160]
       test     r8, r8
       mov      r9, gword ptr [rbp-0xB8]
       jle      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x0381
       dec      r8
       mov      qword ptr [rcx+0x160], r8
 
G_M000_IG31:                ;; offset=0x038B
       xor      ecx, ecx
       mov      dword ptr [rbp-0x30], ecx
       cmp      byte  ptr [rbp-0x38], 0
       jne      G_M000_IG59
 
G_M000_IG32:                ;; offset=0x039A
       mov      rdi, bword ptr [rbp-0xB0]
       mov      rcx, gword ptr [rdi]
       mov      rcx, gword ptr [rcx+0x88]
       mov      r8d, dword ptr [rdi+0x18]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG58
       shl      r8, 5
       lea      rbx, bword ptr [rcx+r8+0x10]
       mov      r14, gword ptr [rbp-0x48]
       mov      r13, qword ptr [rbp-0x40]
       cmp      dword ptr [rbx+0x18], 0
       jge      SHORT G_M000_IG35
 
G_M000_IG33:                ;; offset=0x03D0
       mov      rcx, r14
       mov      r8, r13
       mov      rsi, r15
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
 
G_M000_IG34:                ;; offset=0x03E2
       mov      eax, 1
       jmp      G_M000_IG71
 
G_M000_IG35:                ;; offset=0x03EC
       lea      r15, bword ptr [rdi+0x20]
       mov      eax, dword ptr [rbx+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x03F8
       mov      rcx, 0x7FFFFFFFFF9FF
       bt       rcx, rax
       jae      G_M000_IG60
 
G_M000_IG37:                ;; offset=0x040C
       mov      r12d, dword ptr [rbx+0x14]
 
G_M000_IG38:                ;; offset=0x0410
       mov      ebx, dword ptr [rbx+0x18]
       test     ebx, ebx
       jge      SHORT G_M000_IG43
 
G_M000_IG39:                ;; offset=0x0417
       not      ebx
 
G_M000_IG40:                ;; offset=0x0419
       cmp      ebx, dword ptr [r15+0x40]
       jge      SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x041F
       mov      rdi, r15
       mov      esi, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG42:                ;; offset=0x042A
       mov      rsi, gword ptr [r15]
       cmp      r12d, dword ptr [rsi+0x08]
       jae      G_M000_IG58
       mov      eax, r12d
       shl      rax, 4
       lea      r12, bword ptr [rsi+rax+0x10]
       mov      rdi, r12
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r12+0x08], r13
       mov      dword ptr [r15+0x40], ebx
       jmp      SHORT G_M000_IG34
 
G_M000_IG43:                ;; offset=0x0459
       jmp      SHORT G_M000_IG40
 
G_M000_IG44:                ;; offset=0x045B
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG20
 
G_M000_IG45:                ;; offset=0x046D
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG20
 
G_M000_IG46:                ;; offset=0x0478
       mov      eax, r12d
       or       eax, edx
       je       SHORT G_M000_IG48
 
G_M000_IG47:                ;; offset=0x047F
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG48:                ;; offset=0x0486
       xor      rax, rax
       xor      r12d, r12d
       xor      r8d, r8d
       mov      dword ptr [rbp-0x98], r8d
       mov      r8d, dword ptr [rbp-0x98]
       jmp      G_M000_IG21
 
G_M000_IG49:                ;; offset=0x04A1
       mov      dword ptr [rbp-0x98], r8d
       mov      rdi, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r10d, edx
       mov      rdi, rax
       mov      eax, r10d
       mov      rdx, rdi
       mov      r10d, eax
       mov      r8d, dword ptr [rbp-0x98]
       jmp      G_M000_IG23
 
G_M000_IG50:                ;; offset=0x04D0
       cmp      dword ptr [rcx+0x28], 16
       jg       G_M000_IG25
       mov      bword ptr [rbp-0xE0], rdx
       mov      dword ptr [rbp-0x94], r10d
       add      rdi, 32
       mov      esi, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:CanRetireWithoutCleanup(int):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG51
       mov      rdx, bword ptr [rbp-0xE0]
       mov      rdi, bword ptr [rbp-0xB0]
       mov      r10d, dword ptr [rbp-0x94]
       jmp      G_M000_IG25
 
G_M000_IG51:                ;; offset=0x0513
       mov      rdi, bword ptr [rbp-0xB0]
       mov      rax, gword ptr [rdi+0x20]
       mov      rcx, gword ptr [rbp-0xC0]
       mov      edx, dword ptr [rcx+0x2C]
       test     rax, rax
       jne      SHORT G_M000_IG52
       mov      esi, dword ptr [rbp-0x2C]
       or       edx, esi
       jne      G_M000_IG47
       xor      rdx, rdx
       xor      r8d, r8d
       jmp      SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x053F
       mov      esi, dword ptr [rbp-0x2C]
       mov      r8d, esi
       mov      r9d, edx
       add      r8, r9
       mov      r9d, dword ptr [rax+0x08]
       cmp      r8, r9
       ja       G_M000_IG47
       mov      r8d, esi
       shl      r8, 4
       lea      rax, bword ptr [rax+r8+0x10]
       mov      r8d, edx
       mov      rdx, rax
 
G_M000_IG53:                ;; offset=0x056A
       lea      rax, bword ptr [rdi+0x20]
       lea      r9d, [rsi+r8]
       cmp      r12d, r9d
       cmovge   r9d, r12d
       mov      dword ptr [rax+0x40], r9d
       mov      eax, r8d
       mov      r8, rdx
       mov      rcx, gword ptr [rbp-0xC0]
       mov      rdx, bword ptr [rbp-0xE0]
       mov      rdi, bword ptr [rbp-0xB0]
       mov      r10d, dword ptr [rbp-0x94]
       jmp      G_M000_IG26
 
G_M000_IG54:                ;; offset=0x05A4
       movzx    r14, byte  ptr [rcx+0x32]
       jmp      G_M000_IG27
 
G_M000_IG55:                ;; offset=0x05AE
       mov      r14d, 1
       jmp      G_M000_IG27
 
G_M000_IG56:                ;; offset=0x05B9
       mov      rdi, gword ptr [rbp-0x50]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterExecutableSlots():this]
       mov      rsi, gword ptr [rbp-0x50]
       mov      rcx, gword ptr [rbp-0xC0]
       mov      r8, gword ptr [rcx+0x18]
       mov      rdi, gword ptr [rbp-0xC8]
       mov      rdi, gword ptr [rdi+0x28]
       mov      rdi, gword ptr [rdi+0x98]
       mov      rdi, gword ptr [rdi+0x88]
       mov      gword ptr [rsp], rdi
       mov      rdi, r15
       mov      rdx, rcx
       mov      ecx, dword ptr [rbp-0x2C]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AttachPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.LythonSourceSpan,int,Lokad.Lython.Runtime.MemoryGovernor):this]
       nop      
 
G_M000_IG57:                ;; offset=0x0604
       mov      rsi, gword ptr [rbp-0x50]
       mov      rdi, bword ptr [rbp+0x10]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      edi, edi
       mov      dword ptr [rbp-0x30], edi
       jmp      G_M000_IG34
 
G_M000_IG58:                ;; offset=0x061B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG59:                ;; offset=0x0621
       mov      rdi, bword ptr [rbp-0xB0]
       mov      rsi, r9
       mov      edx, dword ptr [rbp-0x2C]
       mov      ecx, dword ptr [rbp-0x9C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteUnpackedCallReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,int)]
       jmp      G_M000_IG34
 
G_M000_IG60:                ;; offset=0x063F
       mov      rdi, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r12d, eax
       mov      r9, gword ptr [rbp-0xB8]
       jmp      G_M000_IG38
 
G_M000_IG61:                ;; offset=0x0657
       mov      r14, bword ptr [rbp+0x10]
 
G_M000_IG62:                ;; offset=0x065B
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      byte  ptr [rcx+0x30], 0
       jne      G_M000_IG83
 
G_M000_IG63:                ;; offset=0x066C
       mov      rdx, gword ptr [rdi+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG66
 
G_M000_IG64:                ;; offset=0x0675
       lea      rsi, bword ptr [rdx+0x10]
       mov      r8d, dword ptr [rdx+0x08]
 
G_M000_IG65:                ;; offset=0x067D
       test     r15, r15
       setne    dl
       movzx    rdx, dl
       mov      dword ptr [rsp], edx
       lea      rdx, [rbp-0x90]
       mov      qword ptr [rsp+0x08], rdx
       mov      rdx, rsi
       mov      ecx, r8d
       mov      rdi, gword ptr [rbp-0xC0]
       mov      rsi, rbx
       mov      r8d, dword ptr [rbp-0x2C]
       mov      r9, gword ptr [rbp-0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG67
       xor      eax, eax
       jmp      G_M000_IG71
 
G_M000_IG66:                ;; offset=0x06C1
       xor      rsi, rsi
       xor      r8d, r8d
       jmp      SHORT G_M000_IG65
 
G_M000_IG67:                ;; offset=0x06C8
       mov      rsi, gword ptr [rbp-0x90]
       mov      rdi, 0x7F4B8389BB68
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbx, rax
       test     rbx, rbx
       je       SHORT G_M000_IG69
       mov      rdi, bword ptr [rbp-0xB0]
       add      rdi, 32
       mov      esi, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rdi, r14
       mov      rsi, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG68:                ;; offset=0x0705
       mov      eax, 1
       jmp      SHORT G_M000_IG71
 
G_M000_IG69:                ;; offset=0x070C
       mov      rdi, bword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rdi]
       mov      rdx, gword ptr [rdx+0x88]
       mov      ecx, dword ptr [rdi+0x18]
       cmp      ecx, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG70
       shl      rcx, 5
       lea      rdx, bword ptr [rdx+rcx+0x10]
       mov      rcx, gword ptr [rbp-0x90]
       mov      r8, qword ptr [rbp-0x88]
       mov      rsi, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      SHORT G_M000_IG68
 
G_M000_IG70:                ;; offset=0x0747
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG71:                ;; offset=0x074D
       add      rsp, 248
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG72:                ;; offset=0x075F
       xor      ebx, ebx
       jmp      G_M000_IG17
 
G_M000_IG73:                ;; offset=0x0766
       mov      rsi, gword ptr [rbp-0xC8]
       mov      rax, gword ptr [rsi+0x08]
       mov      rsi, gword ptr [rax+0x08]
       cmp      dword ptr [rsi+0x08], 16
       jg       G_M000_IG77
       cmp      dword ptr [rax+0x4C], 0
       jge      G_M000_IG77
       cmp      dword ptr [rax+0x50], 0
       jge      G_M000_IG77
       mov      rsi, gword ptr [rbp-0xC8]
       mov      rsi, gword ptr [rsi+0x18]
       test     rsi, rsi
       je       SHORT G_M000_IG75
       mov      rax, rsi
       mov      rdx, 0x7F4B841F4450
       cmp      qword ptr [rax], rdx
       jne      G_M000_IG81
 
G_M000_IG74:                ;; offset=0x07B9
       test     rax, rax
       je       SHORT G_M000_IG77
 
G_M000_IG75:                ;; offset=0x07BE
       mov      rdi, gword ptr [rbp-0xC8]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       test     rax, rax
       je       G_M000_IG18
       jmp      G_M000_IG82
 
G_M000_IG76:                ;; offset=0x07D9
       cmp      byte  ptr [rdi], dil
       add      rdi, 32
       mov      esi, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rsi, rax
       mov      rdi, 0x7F4B83F35F20
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       mov      rdi, bword ptr [rbp-0xB0]
       jne      G_M000_IG07
       add      rdi, 32
       mov      esi, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      r13, rax
       mov      rdi, bword ptr [rbp-0xB0]
       jmp      G_M000_IG08
 
G_M000_IG77:                ;; offset=0x0827
       xor      eax, eax
 
G_M000_IG78:                ;; offset=0x0829
       add      rsp, 248
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG79:                ;; offset=0x083B
       mov      r14, bword ptr [rbp+0x10]
       jmp      G_M000_IG62
 
G_M000_IG80:                ;; offset=0x0844
       xor      ebx, ebx
       jmp      G_M000_IG17
 
G_M000_IG81:                ;; offset=0x084B
       mov      rdi, 0x7F4B840108D0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, bword ptr [rbp-0xB0]
       jmp      G_M000_IG74
 
G_M000_IG82:                ;; offset=0x0866
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       sete     dil
       movzx    rdi, dil
       test     edi, edi
       je       G_M000_IG18
       jmp      SHORT G_M000_IG77
 
G_M000_IG83:                ;; offset=0x0883
       cmp      byte  ptr [rcx+0x34], 0
       je       G_M000_IG63
       cmp      dword ptr [rcx+0x28], 0
       jne      SHORT G_M000_IG85
       mov      rsi, gword ptr [rcx+0x20]
       mov      rdi, 0x7F4B841D38C0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG85
       mov      rsi, r15
       test     rsi, rsi
       cmove    rsi, gword ptr [rbp-0xB8]
       mov      rdi, bword ptr [rbp-0xB0]
       mov      rdx, r15
       mov      rcx, rax
       mov      r8d, dword ptr [rbp-0x2C]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteCasedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCasedSplit,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG85
       mov      eax, 1
 
G_M000_IG84:                ;; offset=0x08DC
       add      rsp, 248
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG85:                ;; offset=0x08EE
       mov      rsi, rbx
       mov      rdi, 0x7F4B841D3CE8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       test     r14, r14
       je       G_M000_IG77
 
G_M000_IG86:                ;; offset=0x090C
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rsi, gword ptr [rdx+0x20]
       mov      rdi, 0x7F4B841D3FF0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG88
       mov      gword ptr [rsp], rbx
       mov      rdi, bword ptr [rbp-0xB0]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, r15
       mov      rcx, rax
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteTrimmedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x0958
       mov      eax, 1
       jmp      G_M000_IG71
 
G_M000_IG88:                ;; offset=0x0962
       mov      rdi, bword ptr [rbp-0xB0]
       mov      rsi, gword ptr [rdi]
       mov      rdx, gword ptr [rdi+0x20]
       test     rdx, rdx
       jne      SHORT G_M000_IG89
       xor      rcx, rcx
       xor      r8d, r8d
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x097C
       lea      rcx, bword ptr [rdx+0x10]
       mov      r8d, dword ptr [rdx+0x08]
 
G_M000_IG90:                ;; offset=0x0984
       lea      r9, bword ptr [rdi+0x18]
       mov      rdx, r15
       test     rdx, rdx
       cmove    rdx, gword ptr [rbp-0xB8]
       mov      eax, dword ptr [rbp-0x2C]
       mov      dword ptr [rsp], eax
       mov      gword ptr [rsp+0x08], rdx
       lea      rdx, [rbp-0x78]
       mov      qword ptr [rsp+0x10], rdx
       mov      rdx, rcx
       mov      ecx, r8d
       mov      rdi, r14
       mov      r8, r9
       mov      r9, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG91
       mov      rdi, bword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rdi]
       mov      rdx, gword ptr [rdx+0x88]
       mov      ecx, dword ptr [rdi+0x18]
       cmp      ecx, dword ptr [rdx+0x08]
       jae      G_M000_IG100
       shl      rcx, 5
       lea      rdx, bword ptr [rdx+rcx+0x10]
       mov      rcx, gword ptr [rbp-0x78]
       mov      r8, qword ptr [rbp-0x70]
       mov      rsi, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG87
 
G_M000_IG91:                ;; offset=0x0A03
       mov      rdi, bword ptr [rbp-0xB0]
       add      rdi, 32
       mov      esi, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rbx, rax
       mov      rdi, bword ptr [rbp-0xB0]
       lea      rdx, bword ptr [rdi+0x20]
       mov      r8, gword ptr [rbp-0xC0]
       cmp      byte  ptr [r8+0x30], 0
       setne    sil
       movzx    rsi, sil
       mov      eax, dword ptr [rbp-0x2C]
       lea      esi, [rax+rsi+0x01]
       mov      rdi, gword ptr [rdx]
       mov      edx, dword ptr [r8+0x28]
       call     [System.MemoryExtensions:AsMemory[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      gword ptr [rbp-0x60], rax
       mov      qword ptr [rbp-0x58], rdx
       xor      r13, r13
       xor      r12d, r12d
       mov      rdi, gword ptr [rbp-0x60]
       mov      eax, dword ptr [rbp-0x58]
       mov      dword ptr [rbp-0xA0], eax
       mov      ecx, dword ptr [rbp-0x54]
       mov      dword ptr [rbp-0xA4], ecx
       test     rdi, rdi
       je       SHORT G_M000_IG95
       mov      rdx, qword ptr [rdi]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       je       SHORT G_M000_IG92
       lea      r13, bword ptr [rdi+0x10]
       mov      r12d, dword ptr [rdi+0x08]
       jmp      SHORT G_M000_IG93
 
G_M000_IG92:                ;; offset=0x0A8B
       mov      rdx, qword ptr [rdi]
       mov      rdx, qword ptr [rdx+0x40]
       call     [rdx+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r13, rax
       mov      r12d, edx
 
G_M000_IG93:                ;; offset=0x0A9B
       mov      eax, dword ptr [rbp-0xA0]
       and      eax, 0x7FFFFFFF
       mov      ecx, dword ptr [rbp-0xA4]
       mov      edx, ecx
       add      rdx, rax
       mov      edi, r12d
       cmp      rdx, rdi
       jbe      SHORT G_M000_IG94
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG94:                ;; offset=0x0AC0
       shl      rax, 4
       add      r13, rax
       mov      r12d, ecx
 
G_M000_IG95:                ;; offset=0x0ACA
       mov      r8, gword ptr [rbp-0xC0]
       cmp      dword ptr [r8+0x2C], 0
       je       G_M000_IG96
       mov      rdi, 0x7F4B841D42E8
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       mov      rsi, 0x7F3BD9801350
       cmp      r14, gword ptr [rsi]
       jne      SHORT G_M000_IG96
       mov      rsi, rbx
       mov      rdi, 0x7F4B83C33B28
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0xD0], rax
       test     rax, rax
       je       SHORT G_M000_IG96
       cmp      r12d, 2
       jg       SHORT G_M000_IG96
       mov      rdi, r13
       mov      esi, r12d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rsp], rax
       mov      dword ptr [rsp+0x08], edx
       mov      rdi, bword ptr [rbp-0xB0]
       mov      rsi, r15
       mov      rdx, gword ptr [rbp-0xB8]
       mov      rcx, gword ptr [rbp-0xC0]
       mov      r8d, dword ptr [rbp-0x2C]
       mov      r9, gword ptr [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSplitUnpack(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool]
       test     eax, eax
       jne      G_M000_IG87
 
G_M000_IG96:                ;; offset=0x0B63
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      byte  ptr [rcx+0x33], 0
       je       G_M000_IG98
       cmp      r12d, 1
       je       SHORT G_M000_IG97
       cmp      r12d, 2
       jne      G_M000_IG98
 
G_M000_IG97:                ;; offset=0x0B84
       mov      rdi, 0x7F4B841D42E8
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       mov      rsi, 0x7F3BD9801320
       cmp      r14, gword ptr [rsi]
       jne      G_M000_IG98
       mov      rsi, rbx
       mov      rdi, 0x7F4B83CFEB00
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0xD8], rax
       test     rax, rax
       je       SHORT G_M000_IG98
       test     r12d, r12d
       je       G_M000_IG100
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rsi, rax
       mov      rdi, gword ptr [rbp-0xD8]
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG98
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rsi, rax
       mov      rdi, 0x7F4B83C33B28
       call     CORINFO_HELP_CHKCASTCLASS
       mov      r9, rax
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      ecx, dword ptr [rbp-0x2C]
       mov      r8, gword ptr [rbp-0xD8]
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryAccumulation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.PyDict,Lokad.Lython.Runtime.Text.PyString):bool]
       test     eax, eax
       jne      G_M000_IG87
 
G_M000_IG98:                ;; offset=0x0C35
       mov      rcx, gword ptr [rbp-0xC0]
       mov      r8, gword ptr [rcx+0x18]
       mov      r9, r15
       test     r9, r9
       cmove    r9, gword ptr [rbp-0xB8]
       lea      rdx, [rbp-0x80]
       mov      qword ptr [rsp], rdx
       mov      rdx, r13
       mov      ecx, r12d
       mov      rdi, r14
       mov      rsi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG99
       xor      eax, eax
       jmp      G_M000_IG71
 
G_M000_IG99:                ;; offset=0x0C73
       mov      rdi, bword ptr [rbp-0xB0]
       mov      rax, gword ptr [rdi]
       mov      rax, gword ptr [rax+0x88]
       mov      ecx, dword ptr [rdi+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG100
       shl      rcx, 5
       lea      rbx, bword ptr [rax+rcx+0x10]
       mov      rax, gword ptr [rbp-0x80]
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rcx, rax
       mov      r8, rdx
       mov      rdi, bword ptr [rbp-0xB0]
       mov      rsi, r15
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG87
 
G_M000_IG100:                ;; offset=0x0CC0
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG101:                ;; offset=0x0CC6
       sub      rsp, 72
 
G_M000_IG102:                ;; offset=0x0CCA
       mov      r15, gword ptr [rbp-0x50]
       mov      rdi, gword ptr [rbp-0xC8]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      rsi, rax
       mov      rdi, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AbortPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG103:                ;; offset=0x0CF8
       sub      rsp, 72
 
G_M000_IG104:                ;; offset=0x0CFC
       mov      rbx, rdi
       mov      rdi, bword ptr [rbp-0xB0]
       cmp      byte  ptr [rdi], dil
       add      rdi, 32
       mov      esi, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rdi, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rsi, rax
       lea      rdx, [rbp-0x68]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG106
 
G_M000_IG105:                ;; offset=0x0D37
       mov      rdi, gword ptr [rbp-0x68]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG106:                ;; offset=0x0D41
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG107:                ;; offset=0x0D47
       sub      rsp, 72
 
G_M000_IG108:                ;; offset=0x0D4B
       cmp      dword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG110
 
G_M000_IG109:                ;; offset=0x0D51
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, gword ptr [rsi+0x98]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
 
G_M000_IG110:                ;; offset=0x0D67
       nop      
 
G_M000_IG111:                ;; offset=0x0D68
       add      rsp, 72
       ret      
 
G_M000_IG112:                ;; offset=0x0D6D
       sub      rsp, 72
 
G_M000_IG113:                ;; offset=0x0D71
       mov      rdi, bword ptr [rbp-0xB0]
       cmp      byte  ptr [rdi], dil
       add      rdi, 32
       mov      esi, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG114:                ;; offset=0x0D8E
       sub      rsp, 72
 
G_M000_IG115:                ;; offset=0x0D92
       mov      rdi, bword ptr [rbp-0xB0]
       cmp      byte  ptr [rdi], dil
       add      rdi, 32
       mov      esi, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 3503

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 27678
; 7 inlinees with PGO data; 24 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 440
       lea      rbp, [rsp+0x1E0]
       xor      eax, eax
       mov      qword ptr [rbp-0x178], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x170], xmm8
       vmovdqa  xmmword ptr [rbp-0x160], xmm8
       mov      rax, -288
 
G_M000_IG27:                ;; offset=0x0041
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG27
       mov      qword ptr [rbp-0x30], rax
       mov      bword ptr [rbp-0x190], rdx
       mov      rbx, rdi
       mov      r13, rsi
       mov      r14d, ecx
       mov      r15, r8
       mov      r12, r9
       mov      rcx, bword ptr [rbp+0x40]
 
G_M000_IG02:                ;; offset=0x0077
       test     r15, r15
       jne      G_M000_IG17
 
G_M000_IG03:                ;; offset=0x0080
       mov      rdi, gword ptr [rbx+0x40]
       cmp      byte  ptr [rdi+0xE0], 0
       jne      G_M000_IG10
 
G_M000_IG04:                ;; offset=0x0091
       mov      rax, bword ptr [rbp-0x190]
 
G_M000_IG05:                ;; offset=0x0098
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x128], ymm0
       vmovdqu  ymmword ptr [rbp-0x108], ymm0
       vmovdqu  ymmword ptr [rbp-0xE8], ymm0
       vmovdqu  ymmword ptr [rbp-0xC8], ymm0
       vmovdqu  ymmword ptr [rbp-0xA8], ymm0
       vmovdqu  ymmword ptr [rbp-0x88], ymm0
       vmovdqu  ymmword ptr [rbp-0x68], ymm0
       vmovdqu  ymmword ptr [rbp-0x48], ymm0
       mov      rdi, gword ptr [rbx+0x40]
       mov      r8d, dword ptr [rdi+0xD4]
       mov      dword ptr [rbp-0x17C], r8d
       cmp      r8d, 16
       ja       G_M000_IG20
       cmp      byte  ptr [rbp+0x20], 0
       je       G_M000_IG25
       xor      edi, edi
       test     r15, r15
       jne      G_M000_IG21
 
G_M000_IG06:                ;; offset=0x0107
       cmp      edi, r8d
       ja       G_M000_IG20
       lea      rsi, bword ptr [rbp-0x128]
       mov      edx, edi
       shl      rdx, 4
       add      rdx, rsi
       mov      esi, r8d
       sub      esi, edi
       cmp      r14d, esi
       ja       G_M000_IG24
       mov      edi, r14d
       shl      rdi, 4
       mov      r9, rdi
       cmp      r9, 0x4000
       ja       G_M000_IG23
       mov      bword ptr [rbp+0x40], rcx
       mov      rdi, rdx
       mov      rsi, rax
       mov      rdx, r9
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7f4c01471818)], 0
       jne      G_M000_IG22
 
G_M000_IG07:                ;; offset=0x0164
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x160]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      r15, bword ptr [rbp+0x28]
       mov      bword ptr [rsp+0x20], r15
       mov      r14d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], r14d
       mov      r15, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], r15
       mov      r13, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], r13
       lea      rsi, [rbp-0x140]
       mov      qword ptr [rsp+0x40], rsi
       lea      rsi, bword ptr [rbp-0x128]
       mov      edx, dword ptr [rbp-0x17C]
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rdi, rbx
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
 
G_M000_IG08:                ;; offset=0x01F2
       nop      
 
G_M000_IG09:                ;; offset=0x01F3
       add      rsp, 440
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x0205
       cmp      byte  ptr [rbp+0x20], 0
       jne      G_M000_IG19
       xor      edi, edi
       mov      bword ptr [rbp+0x40], rcx
       mov      qword ptr [rcx], rdi
       mov      qword ptr [rcx+0x08], rdi
       cmp      byte  ptr [r13+0x34], 0
       je       G_M000_IG16
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      edi, dword ptr [rdi+0x08]
       mov      rsi, gword ptr [rbx+0x40]
       cmp      edi, dword ptr [rsi+0xC4]
       jne      G_M000_IG15
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       G_M000_IG13
       mov      rax, gword ptr [r12+0x98]
       mov      gword ptr [rbp-0x188], rax
       cmp      byte  ptr [rax], al
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       G_M000_IG18
 
G_M000_IG11:                ;; offset=0x0278
       mov      gword ptr [rbp-0x178], rbx
       mov      rax, bword ptr [rbp-0x190]
       mov      bword ptr [rbp-0x170], rax
       mov      dword ptr [rbp-0x168], r14d
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x178]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, rbx
       mov      rsi, gword ptr [rbp+0x10]
       mov      rdx, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
 
G_M000_IG12:                ;; offset=0x02D1
       test     eax, eax
       mov      rax, bword ptr [rbp-0x190]
       mov      rcx, bword ptr [rbp+0x40]
       je       G_M000_IG05
       mov      r13, bword ptr [rbp+0x38]
       mov      byte  ptr [r13], 0
       xor      rdx, rdx
       mov      r13, bword ptr [rbp+0x48]
       mov      gword ptr [r13], rdx
       jmp      G_M000_IG08
 
G_M000_IG13:                ;; offset=0x02FC
       mov      rax, bword ptr [rbp-0x190]
 
G_M000_IG14:                ;; offset=0x0303
       xor      esi, esi
       mov      bword ptr [rbp-0x190], rax
       mov      eax, esi
       jmp      SHORT G_M000_IG12
 
G_M000_IG15:                ;; offset=0x0310
       mov      rax, bword ptr [rbp-0x190]
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x0319
       mov      rax, bword ptr [rbp-0x190]
       jmp      SHORT G_M000_IG14
 
G_M000_IG17:                ;; offset=0x0322
       mov      rax, bword ptr [rbp-0x190]
       jmp      G_M000_IG05
 
G_M000_IG18:                ;; offset=0x032E
       mov      rdi, gword ptr [rbp-0x188]
       mov      rsi, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG11
 
G_M000_IG19:                ;; offset=0x0344
       mov      rax, bword ptr [rbp-0x190]
       mov      rsi, gword ptr [rbx+0x40]
       cmp      r14d, dword ptr [rsi+0xC4]
       jne      G_M000_IG05
       mov      bword ptr [rbp+0x40], rcx
       mov      bword ptr [rbp-0x190], rax
       mov      rsi, rax
       mov      edx, r14d
       mov      rdi, rbx
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      G_M000_IG12
 
G_M000_IG20:                ;; offset=0x0383
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG21:                ;; offset=0x038A
       mov      edi, 1
       test     r8d, r8d
       je       G_M000_IG26
       mov      gword ptr [rbp-0x128], r15
       xor      esi, esi
       mov      qword ptr [rbp-0x120], rsi
       jmp      G_M000_IG06
 
G_M000_IG22:                ;; offset=0x03AD
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG07
 
G_M000_IG23:                ;; offset=0x03B7
       mov      bword ptr [rbp+0x40], rcx
       mov      rdi, rdx
       mov      rsi, rax
       mov      rdx, r9
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG07
 
G_M000_IG24:                ;; offset=0x03CF
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG25:                ;; offset=0x03D6
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      esi, dword ptr [rdi+0x08]
       cmp      esi, r8d
       mov      bword ptr [rbp+0x40], rcx
       ja       SHORT G_M000_IG20
       mov      gword ptr [rsp], r12
       xor      edi, edi
       mov      dword ptr [rsp+0x08], edi
       mov      gword ptr [rsp+0x10], r15
       mov      gword ptr [rsp+0x18], r13
       mov      bword ptr [rsp+0x20], rax
       mov      dword ptr [rsp+0x28], r14d
       lea      rdi, bword ptr [rbp-0x128]
       xor      rdx, rdx
       xor      ecx, ecx
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
       jmp      G_M000_IG07
 
G_M000_IG26:                ;; offset=0x0425
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1067

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 432
       lea      rbp, [rsp+0x1B0]
       xor      eax, eax
       mov      qword ptr [rbp-0x168], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x160], xmm8
       mov      rax, -288
 
G_M000_IG33:                ;; offset=0x0030
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG33
       mov      qword ptr [rbp-0x30], rax
       mov      bword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      dword ptr [rbp-0x14], edx
       mov      gword ptr [rbp-0x20], rcx
       mov      bword ptr [rbp-0x28], r8
 
G_M000_IG02:                ;; offset=0x005F
       mov      rax, 0x7F3BD98009B0
       mov      rdi, gword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      gword ptr [rbp-0xA8], rax
       mov      qword ptr [rbp-0xA0], rdx
       mov      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rbp-0x168], rax
       mov      rdi, bword ptr [rbp-0x168]
       mov      rsi, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0x168]
       mov      rcx, qword ptr [rbp-0xA0]
       mov      qword ptr [rax+0x08], rcx
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CurrentRecursionDepth():long:this]
       cmp      rax, 8
       jl       SHORT G_M000_IG04
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x00D3
       add      rsp, 432
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x00DC
       mov      rsi, gword ptr [rbp-0x20]
       mov      rdi, 0x7F4B841ACE90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x30], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0x130], rax
       mov      rax, bword ptr [rbp-0x130]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x14], eax
       jae      G_M000_IG28
       mov      rax, bword ptr [rbp-0x130]
       mov      ecx, dword ptr [rbp-0x14]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x140], rax
       mov      rsi, gword ptr [rbp-0x140]
       mov      rdi, 0x7F4B83F35F20
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0167
       xor      rax, rax
       mov      gword ptr [rbp-0xB0], rax
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0172
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0x138], rax
       mov      rax, bword ptr [rbp-0x138]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x14], eax
       jae      G_M000_IG28
       mov      rax, bword ptr [rbp-0x138]
       mov      ecx, dword ptr [rbp-0x14]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0xB0], rax
 
G_M000_IG07:                ;; offset=0x01BB
       mov      rax, gword ptr [rbp-0xB0]
       mov      gword ptr [rbp-0x38], rax
       mov      rsi, gword ptr [rbp-0x20]
       mov      rdi, 0x7F4B841D33F8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x40], rax
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG08
       mov      rdi, gword ptr [rbp-0x40]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Function():Lokad.Lython.Runtime.LythonRuntime+ICallable:this]
       mov      gword ptr [rbp-0x148], rax
       mov      rsi, gword ptr [rbp-0x148]
       mov      rdi, 0x7F4B841ACE90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       SHORT G_M000_IG08
       mov      rax, gword ptr [rbp-0x48]
       mov      gword ptr [rbp-0x30], rax
       mov      rdi, gword ptr [rbp-0x40]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Receiver():System.Object:this]
       mov      gword ptr [rbp-0x38], rax
 
G_M000_IG08:                ;; offset=0x0230
       cmp      gword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG09
       lea      rcx, [rbp-0x50]
       mov      rdi, gword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rdx, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0253
       xor      eax, eax
 
G_M000_IG10:                ;; offset=0x0255
       add      rsp, 432
       pop      rbp
       ret      
 
G_M000_IG11:                ;; offset=0x025E
       mov      rax, bword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x150], rax
       mov      rsi, gword ptr [rbp-0x150]
       mov      rdi, gword ptr [rbp-0xB8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x54], 1
 
G_M000_IG12:                ;; offset=0x029D
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0xC0], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x14]
       mov      dword ptr [rbp-0xC4], eax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x154], eax
       mov      edx, dword ptr [rbp-0x154]
       mov      esi, dword ptr [rbp-0xC4]
       mov      rdi, bword ptr [rbp-0xC0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0xD8], rax
       mov      qword ptr [rbp-0xD0], rdx
 
G_M000_IG13:                ;; offset=0x0300
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rbp-0x68], xmm0
 
G_M000_IG14:                ;; offset=0x030D
       movzx    rax, byte  ptr [rbp-0x50]
       cmp      gword ptr [rbp-0x38], 0
       setne    cl
       movzx    rcx, cl
       and      eax, ecx
       test     eax, eax
       je       SHORT G_M000_IG15
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       jne      SHORT G_M000_IG15
       mov      rdi, bword ptr [rbp-0x68]
       mov      rsi, qword ptr [rbp-0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x128], rax
       mov      qword ptr [rbp-0x120], rdx
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x160], rax
       mov      r8, gword ptr [rbp-0x160]
       mov      rsi, bword ptr [rbp-0x128]
       mov      rdx, qword ptr [rbp-0x120]
       mov      rcx, gword ptr [rbp-0x38]
       mov      rdi, gword ptr [rbp-0x30]
       mov      r9, bword ptr [rbp-0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartBoundIntegerReturn(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG15
       mov      dword ptr [rbp-0x7C], 1
       jmp      G_M000_IG22
 
G_M000_IG15:                ;; offset=0x039A
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG17
       mov      rax, bword ptr [rbp-0x08]
       movzx    rax, byte  ptr [rax+0x48]
       test     eax, eax
       je       SHORT G_M000_IG16
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0xDC], eax
       jmp      SHORT G_M000_IG18
 
G_M000_IG16:                ;; offset=0x03CA
       xor      eax, eax
       mov      dword ptr [rbp-0xDC], eax
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x03D4
       mov      dword ptr [rbp-0xDC], 1
 
G_M000_IG18:                ;; offset=0x03DE
       movzx    rax, byte  ptr [rbp-0xDC]
       mov      dword ptr [rbp-0x6C], eax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG19
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_LastOwnedTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x14]
       jge      SHORT G_M000_IG19
       mov      rdi, bword ptr [rbp-0x68]
       mov      rsi, qword ptr [rbp-0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x118], rax
       mov      qword ptr [rbp-0x110], rdx
       mov      eax, dword ptr [rbp-0x14]
       mov      dword ptr [rsp], eax
       mov      eax, dword ptr [rbp-0x6C]
       mov      dword ptr [rsp+0x08], eax
       movzx    rax, byte  ptr [rbp-0x50]
       mov      dword ptr [rsp+0x10], eax
       mov      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rsp+0x18], rax
       lea      rax, [rbp-0x78]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp-0x118]
       mov      r8, qword ptr [rbp-0x110]
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdx, gword ptr [rbp-0x10]
       mov      r9, gword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StartNativeFixedReturn(Lokad.Lython.Runtime.PyExecutableFunction,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,int,bool,bool,byref,byref):this]
       jmp      G_M000_IG20
 
G_M000_IG19:                ;; offset=0x047D
       mov      rdi, bword ptr [rbp-0x68]
       mov      rsi, qword ptr [rbp-0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0xF0], rax
       mov      qword ptr [rbp-0xE8], rdx
       mov      rax, bword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0xF8], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x100], rax
       movzx    rax, byte  ptr [rbp-0x50]
       mov      dword ptr [rbp-0x104], eax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
       mov      rax, gword ptr [rbp-0x100]
       mov      gword ptr [rsp], rax
       mov      eax, dword ptr [rbp-0x6C]
       mov      dword ptr [rsp+0x08], eax
       mov      eax, dword ptr [rbp-0x104]
       mov      dword ptr [rsp+0x10], eax
       lea      rdi, [rsp+0x18]
       lea      rsi, [rbp-0x98]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x18], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rax, [rbp-0x88]
       mov      qword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x78]
       mov      qword ptr [rsp+0x38], rax
       mov      rdx, bword ptr [rbp-0xF0]
       mov      rcx, qword ptr [rbp-0xE8]
       mov      rdi, gword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x38]
       mov      r9, gword ptr [rbp-0xF8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
 
G_M000_IG20:                ;; offset=0x0552
       cmp      gword ptr [rbp-0x78], 0
       je       SHORT G_M000_IG21
       mov      rax, bword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp-0x78]
       mov      gword ptr [rax+0x20], rcx
       mov      rdi, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      gword ptr [rcx+0x28], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x54], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x7C], eax
       jmp      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x0590
       call     G_M000_IG29
       jmp      SHORT G_M000_IG24
 
G_M000_IG22:                ;; offset=0x0597
       call     G_M000_IG29
       jmp      SHORT G_M000_IG26
 
G_M000_IG23:                ;; offset=0x059E
       call     G_M000_IG29
       jmp      SHORT G_M000_IG26
 
G_M000_IG24:                ;; offset=0x05A5
       mov      eax, 1
 
G_M000_IG25:                ;; offset=0x05AA
       add      rsp, 432
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x05B3
       mov      eax, dword ptr [rbp-0x7C]
 
G_M000_IG27:                ;; offset=0x05B6
       add      rsp, 432
       pop      rbp
       ret      
 
G_M000_IG28:                ;; offset=0x05BF
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG29:                ;; offset=0x05C5
       sub      rsp, 72
 
G_M000_IG30:                ;; offset=0x05C9
       cmp      dword ptr [rbp-0x54], 0
       je       SHORT G_M000_IG31
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG31:                ;; offset=0x05DF
       nop      
 
G_M000_IG32:                ;; offset=0x05E0
       add      rsp, 72
       ret      
 
; Total bytes of code 1509

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 432
       lea      rbp, [rsp+0x1B0]
       xor      eax, eax
       mov      qword ptr [rbp-0x168], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x160], xmm8
       mov      rax, -288
 
G_M000_IG39:                ;; offset=0x0030
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG39
       mov      qword ptr [rbp-0x30], rax
       mov      bword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      dword ptr [rbp-0x14], edx
       mov      gword ptr [rbp-0x20], rcx
       mov      bword ptr [rbp-0x28], r8
 
G_M000_IG02:                ;; offset=0x005F
       mov      rax, 0x7F3BD98009B0
       mov      rdi, gword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      gword ptr [rbp-0xA8], rax
       mov      qword ptr [rbp-0xA0], rdx
       mov      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rbp-0x168], rax
       mov      rdi, bword ptr [rbp-0x168]
       mov      rsi, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0x168]
       mov      rcx, qword ptr [rbp-0xA0]
       mov      qword ptr [rax+0x08], rcx
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CurrentRecursionDepth():long:this]
       cmp      rax, 8
       jl       SHORT G_M000_IG04
       mov      rdi, 0x7F4B84ADBA70
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x00E2
       add      rsp, 432
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x00EB
       mov      rsi, gword ptr [rbp-0x20]
       mov      rdi, 0x7F4B841ACE90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x30], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG06
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0x130], rax
       mov      rax, bword ptr [rbp-0x130]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x14], eax
       jae      G_M000_IG34
       mov      rax, bword ptr [rbp-0x130]
       mov      ecx, dword ptr [rbp-0x14]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x140], rax
       mov      rsi, gword ptr [rbp-0x140]
       mov      rdi, 0x7F4B83F35F20
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG07
 
G_M000_IG05:                ;; offset=0x0176
       mov      rdi, 0x7F4B84ADBA74
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG06:                ;; offset=0x0185
       xor      rax, rax
       mov      gword ptr [rbp-0xB0], rax
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x0190
       mov      rdi, 0x7F4B84ADBA78
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0x138], rax
       mov      rax, bword ptr [rbp-0x138]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x14], eax
       jae      G_M000_IG34
       mov      rax, bword ptr [rbp-0x138]
       mov      ecx, dword ptr [rbp-0x14]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0xB0], rax
 
G_M000_IG08:                ;; offset=0x01E8
       mov      rax, gword ptr [rbp-0xB0]
       mov      gword ptr [rbp-0x38], rax
       mov      rsi, gword ptr [rbp-0x20]
       mov      rdi, 0x7F4B841D33F8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x40], rax
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG09
       mov      rdi, gword ptr [rbp-0x40]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Function():Lokad.Lython.Runtime.LythonRuntime+ICallable:this]
       mov      gword ptr [rbp-0x148], rax
       mov      rsi, gword ptr [rbp-0x148]
       mov      rdi, 0x7F4B841ACE90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       SHORT G_M000_IG13
       mov      rdi, 0x7F4B84ADBA7C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x48]
       mov      gword ptr [rbp-0x30], rax
       mov      rdi, gword ptr [rbp-0x40]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Receiver():System.Object:this]
       mov      gword ptr [rbp-0x38], rax
 
G_M000_IG09:                ;; offset=0x026C
       cmp      gword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG11
       lea      rcx, [rbp-0x50]
       mov      rdi, gword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rdx, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG14
 
G_M000_IG10:                ;; offset=0x028F
       mov      rdi, 0x7F4B84ADBA80
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x029E
       mov      rdi, 0x7F4B84ADBA84
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG12:                ;; offset=0x02AF
       add      rsp, 432
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x02B8
       mov      rdi, 0x7F4B84ADBA88
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG09
 
G_M000_IG14:                ;; offset=0x02C9
       mov      rax, bword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x150], rax
       mov      rsi, gword ptr [rbp-0x150]
       mov      rdi, gword ptr [rbp-0xB8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x54], 1
 
G_M000_IG15:                ;; offset=0x0308
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0xC0], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x14]
       mov      dword ptr [rbp-0xC4], eax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x154], eax
       mov      edx, dword ptr [rbp-0x154]
       mov      esi, dword ptr [rbp-0xC4]
       mov      rdi, bword ptr [rbp-0xC0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0xD8], rax
       mov      qword ptr [rbp-0xD0], rdx
 
G_M000_IG16:                ;; offset=0x036B
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rbp-0x68], xmm0
 
G_M000_IG17:                ;; offset=0x0378
       movzx    rax, byte  ptr [rbp-0x50]
       cmp      gword ptr [rbp-0x38], 0
       setne    cl
       movzx    rcx, cl
       and      eax, ecx
       test     eax, eax
       je       G_M000_IG20
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       jne      G_M000_IG19
       mov      rdi, bword ptr [rbp-0x68]
       mov      rsi, qword ptr [rbp-0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x128], rax
       mov      qword ptr [rbp-0x120], rdx
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x160], rax
       mov      r8, gword ptr [rbp-0x160]
       mov      rsi, bword ptr [rbp-0x128]
       mov      rdx, qword ptr [rbp-0x120]
       mov      rcx, gword ptr [rbp-0x38]
       mov      rdi, gword ptr [rbp-0x30]
       mov      r9, bword ptr [rbp-0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartBoundIntegerReturn(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG18
       mov      rdi, 0x7F4B84ADBA8C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x7C], 1
       jmp      G_M000_IG28
 
G_M000_IG18:                ;; offset=0x041C
       mov      rdi, 0x7F4B84ADBA90
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x042D
       mov      rdi, 0x7F4B84ADBA94
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG20:                ;; offset=0x043C
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG22
       mov      rax, bword ptr [rbp-0x08]
       movzx    rax, byte  ptr [rax+0x48]
       test     eax, eax
       je       SHORT G_M000_IG21
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0xDC], eax
       jmp      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x046C
       mov      rdi, 0x7F4B84ADBA98
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0xDC], eax
       jmp      SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x0485
       mov      rdi, 0x7F4B84ADBA9C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xDC], 1
 
G_M000_IG23:                ;; offset=0x049E
       movzx    rax, byte  ptr [rbp-0xDC]
       mov      dword ptr [rbp-0x6C], eax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG25
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_LastOwnedTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x14]
       jge      SHORT G_M000_IG24
       mov      rdi, 0x7F4B84ADBAA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x68]
       mov      rsi, qword ptr [rbp-0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x118], rax
       mov      qword ptr [rbp-0x110], rdx
       mov      eax, dword ptr [rbp-0x14]
       mov      dword ptr [rsp], eax
       mov      eax, dword ptr [rbp-0x6C]
       mov      dword ptr [rsp+0x08], eax
       movzx    rax, byte  ptr [rbp-0x50]
       mov      dword ptr [rsp+0x10], eax
       mov      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rsp+0x18], rax
       lea      rax, [rbp-0x78]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp-0x118]
       mov      r8, qword ptr [rbp-0x110]
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdx, gword ptr [rbp-0x10]
       mov      r9, gword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StartNativeFixedReturn(Lokad.Lython.Runtime.PyExecutableFunction,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,int,bool,bool,byref,byref):this]
       jmp      G_M000_IG26
 
G_M000_IG24:                ;; offset=0x054C
       mov      rdi, 0x7F4B84ADBAA4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG25:                ;; offset=0x055B
       mov      rdi, bword ptr [rbp-0x68]
       mov      rsi, qword ptr [rbp-0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0xF0], rax
       mov      qword ptr [rbp-0xE8], rdx
       mov      rax, bword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0xF8], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x100], rax
       movzx    rax, byte  ptr [rbp-0x50]
       mov      dword ptr [rbp-0x104], eax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
       mov      rax, gword ptr [rbp-0x100]
       mov      gword ptr [rsp], rax
       mov      eax, dword ptr [rbp-0x6C]
       mov      dword ptr [rsp+0x08], eax
       mov      eax, dword ptr [rbp-0x104]
       mov      dword ptr [rsp+0x10], eax
       lea      rdi, [rsp+0x18]
       lea      rsi, [rbp-0x98]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x18], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rax, [rbp-0x88]
       mov      qword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x78]
       mov      qword ptr [rsp+0x38], rax
       mov      rdx, bword ptr [rbp-0xF0]
       mov      rcx, qword ptr [rbp-0xE8]
       mov      rdi, gword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x38]
       mov      r9, gword ptr [rbp-0xF8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
 
G_M000_IG26:                ;; offset=0x0630
       cmp      gword ptr [rbp-0x78], 0
       je       SHORT G_M000_IG27
       mov      rax, bword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp-0x78]
       mov      gword ptr [rax+0x20], rcx
       mov      rdi, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      gword ptr [rcx+0x28], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x54], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x7C], eax
       jmp      SHORT G_M000_IG29
 
G_M000_IG27:                ;; offset=0x066E
       call     G_M000_IG35
       jmp      SHORT G_M000_IG30
 
G_M000_IG28:                ;; offset=0x0675
       call     G_M000_IG35
       jmp      SHORT G_M000_IG32
 
G_M000_IG29:                ;; offset=0x067C
       call     G_M000_IG35
       jmp      SHORT G_M000_IG32
 
G_M000_IG30:                ;; offset=0x0683
       mov      rdi, 0x7F4B84ADBAB0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG31:                ;; offset=0x0697
       add      rsp, 432
       pop      rbp
       ret      
 
G_M000_IG32:                ;; offset=0x06A0
       mov      rdi, 0x7F4B84ADBAB4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x7C]
 
G_M000_IG33:                ;; offset=0x06B2
       add      rsp, 432
       pop      rbp
       ret      
 
G_M000_IG34:                ;; offset=0x06BB
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG35:                ;; offset=0x06C1
       sub      rsp, 72
 
G_M000_IG36:                ;; offset=0x06C5
       cmp      dword ptr [rbp-0x54], 0
       je       SHORT G_M000_IG37
       mov      rdi, 0x7F4B84ADBAA8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG37:                ;; offset=0x06EA
       mov      rdi, 0x7F4B84ADBAAC
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG38:                ;; offset=0x06FA
       add      rsp, 72
       ret      
 
; Total bytes of code 1791

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 20208
; 9 inlinees with PGO data; 65 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 168
       lea      rbp, [rsp+0xD0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqa  xmmword ptr [rbp-0x40], xmm8
       mov      bword ptr [rbp-0x68], rdi
       mov      rbx, rsi
       mov      r15d, edx
       mov      r13, rcx
       mov      r14, r8
 
G_M000_IG02:                ;; offset=0x0038
       mov      rsi, 0x7F3BD98009B0
       mov      rsi, gword ptr [rsi]
       mov      rdi, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      edi, edi
       mov      qword ptr [r14+0x08], rdi
       mov      rdi, bword ptr [rbp-0x68]
       mov      rax, gword ptr [rdi+0x18]
       mov      rax, gword ptr [rax+0x98]
       cmp      qword ptr [rax+0x158], 8
       jge      G_M000_IG52
       test     r13, r13
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0075
       mov      rax, 0x7F4B841ACE90
       cmp      qword ptr [r13], rax
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0085
       mov      r12, r13
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x008A
       xor      r12, r12
 
G_M000_IG06:                ;; offset=0x008D
       cmp      byte  ptr [rbx+0x30], 0
       je       G_M000_IG42
 
G_M000_IG07:                ;; offset=0x0097
       lea      rax, bword ptr [rdi+0x50]
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      ecx, r15d
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rax, gword ptr [rcx]
       mov      rdx, 0x7F3BD9801308
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rbp-0x88], rdx
       cmp      rax, rdx
       je       G_M000_IG40
 
G_M000_IG08:                ;; offset=0x00CF
       mov      rsi, 0x7F3BD9801310
       cmp      rax, gword ptr [rsi]
       je       G_M000_IG45
       cmp      qword ptr [rcx+0x08], 0
       jne      G_M000_IG46
 
G_M000_IG09:                ;; offset=0x00ED
       test     rax, rax
       jne      G_M000_IG41
 
G_M000_IG10:                ;; offset=0x00F6
       mov      rdi, bword ptr [rbp-0x68]
       lea      rax, bword ptr [rdi+0x50]
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      ecx, r15d
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdx, gword ptr [rbp-0x88]
       cmp      gword ptr [rcx], rdx
       je       G_M000_IG43
 
G_M000_IG11:                ;; offset=0x0122
       mov      rax, gword ptr [rcx]
       mov      rdx, 0x7F3BD9801310
       cmp      rax, gword ptr [rdx]
       je       G_M000_IG47
       cmp      qword ptr [rcx+0x08], 0
       jne      G_M000_IG48
       mov      rax, gword ptr [rcx]
 
G_M000_IG12:                ;; offset=0x0146
       test     r13, r13
       je       SHORT G_M000_IG18
 
G_M000_IG13:                ;; offset=0x014B
       mov      rsi, 0x7F4B841D33F8
       cmp      qword ptr [r13], rsi
       jne      SHORT G_M000_IG18
 
G_M000_IG14:                ;; offset=0x015B
       mov      rsi, gword ptr [r13+0x10]
       test     rsi, rsi
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0164
       mov      rcx, 0x7F4B841ACE90
       xor      rdx, rdx
       cmp      qword ptr [rsi], rcx
       cmovne   rsi, rdx
 
G_M000_IG16:                ;; offset=0x0177
       test     rsi, rsi
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x017C
       mov      r12, rsi
       mov      rax, gword ptr [r13+0x08]
 
G_M000_IG18:                ;; offset=0x0183
       test     r12, r12
       je       G_M000_IG52
       mov      rsi, gword ptr [r12+0x40]
       cmp      byte  ptr [rsi+0xDF], 0
       je       G_M000_IG52
       mov      rcx, gword ptr [r12+0x28]
       cmp      byte  ptr [rcx+0xFA], 0
       jne      G_M000_IG52
       cmp      byte  ptr [rcx+0xFB], 0
       jne      G_M000_IG52
       cmp      byte  ptr [rcx+0xFC], 0
       jne      G_M000_IG52
       cmp      gword ptr [rcx+0xC0], 0
       jne      G_M000_IG52
       cmp      dword ptr [rsi+0xD4], 16
       jg       G_M000_IG52
       cmp      byte  ptr [rbx+0x34], 0
       je       G_M000_IG49
       mov      esi, dword ptr [rbx+0x28]
       mov      rcx, gword ptr [r12+0x08]
       cmp      byte  ptr [rcx+0x54], 0
       je       G_M000_IG44
 
G_M000_IG19:                ;; offset=0x0201
       mov      ecx, dword ptr [rcx+0x3C]
       mov      gword ptr [rbp-0x70], rax
       test     rax, rax
       setne    dl
       movzx    rdx, dl
       sub      ecx, edx
       cmp      ecx, esi
       sete     r13b
       movzx    r13, r13b
 
G_M000_IG20:                ;; offset=0x021D
       test     r13d, r13d
       jne      SHORT G_M000_IG25
 
G_M000_IG21:                ;; offset=0x0222
       mov      rcx, gword ptr [r12+0x08]
       mov      rsi, gword ptr [rcx+0x08]
       cmp      dword ptr [rsi+0x08], 16
       jg       G_M000_IG52
       cmp      dword ptr [rcx+0x4C], 0
       jge      G_M000_IG52
       cmp      dword ptr [rcx+0x50], 0
       jge      G_M000_IG52
       mov      rsi, gword ptr [r12+0x18]
       test     rsi, rsi
       je       SHORT G_M000_IG24
 
G_M000_IG22:                ;; offset=0x0253
       mov      rcx, rsi
       mov      rdx, 0x7F4B841F4450
       cmp      qword ptr [rcx], rdx
       jne      G_M000_IG50
 
G_M000_IG23:                ;; offset=0x0269
       test     rcx, rcx
       je       G_M000_IG52
 
G_M000_IG24:                ;; offset=0x0272
       mov      rdi, r12
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       test     rax, rax
       jne      G_M000_IG51
 
G_M000_IG25:                ;; offset=0x0284
       mov      rdi, bword ptr [rbp-0x68]
       mov      rsi, gword ptr [rdi+0x18]
       mov      rcx, gword ptr [rbx+0x18]
       mov      rdi, gword ptr [rsi+0x98]
       mov      rsi, rcx
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x2C], 1
 
G_M000_IG26:                ;; offset=0x02A9
       mov      rdi, bword ptr [rbp-0x68]
       lea      rcx, bword ptr [rdi+0x50]
       cmp      byte  ptr [rbx+0x30], 0
       setne    sil
       movzx    rsi, sil
       lea      esi, [r15+rsi+0x01]
       mov      eax, dword ptr [rbx+0x28]
       mov      dword ptr [rbp-0x44], eax
       mov      edx, esi
       mov      r8d, eax
       add      rdx, r8
       mov      r8d, dword ptr [rcx+0x08]
       cmp      rdx, r8
       ja       G_M000_IG28
       mov      r8d, esi
       shl      r8, 4
       add      r8, bword ptr [rcx]
       mov      bword ptr [rbp-0x80], r8
       mov      r9, gword ptr [rbp-0x70]
       test     r9, r9
       setne    cl
       movzx    rcx, cl
       test     ecx, r13d
       je       G_M000_IG29
 
G_M000_IG27:                ;; offset=0x0301
       cmp      dword ptr [rbx+0x2C], 0
       jne      G_M000_IG29
       mov      rsi, gword ptr [rbx+0x18]
       mov      gword ptr [rbp-0x78], rsi
       xor      ecx, ecx
       mov      qword ptr [r14], rcx
       mov      qword ptr [r14+0x08], rcx
       mov      rcx, gword ptr [r12+0x40]
       cmp      byte  ptr [rcx+0xE0], 0
       je       SHORT G_M000_IG29
       lea      edx, [rax+0x01]
       cmp      edx, dword ptr [rcx+0xC4]
       jne      SHORT G_M000_IG29
       mov      gword ptr [rbp-0x70], r9
       mov      gword ptr [rbp-0x60], r9
       mov      bword ptr [rbp-0x58], r8
       mov      dword ptr [rbp-0x50], eax
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x60]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, r12
       mov      rsi, gword ptr [rbp-0x78]
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+BoundIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+BoundIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       mov      eax, dword ptr [rbp-0x44]
       mov      r8, bword ptr [rbp-0x80]
       mov      r9, gword ptr [rbp-0x70]
       je       SHORT G_M000_IG29
       mov      eax, 1
       jmp      G_M000_IG36
 
G_M000_IG28:                ;; offset=0x0396
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG29:                ;; offset=0x039D
       cmp      byte  ptr [rbx+0x31], 0
       jne      SHORT G_M000_IG31
       mov      rdi, bword ptr [rbp-0x68]
       cmp      byte  ptr [rdi+0x48], 0
       je       SHORT G_M000_IG30
       movzx    rcx, byte  ptr [rbx+0x32]
       jmp      SHORT G_M000_IG32
 
G_M000_IG30:                ;; offset=0x03B3
       xor      ecx, ecx
       jmp      SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x03B7
       mov      ecx, 1
       mov      rdi, bword ptr [rbp-0x68]
 
G_M000_IG32:                ;; offset=0x03C0
       mov      dword ptr [rbp-0x30], ecx
       cmp      dword ptr [rbx+0x2C], 0
       je       SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x03C9
       mov      rsi, gword ptr [rdi+0x08]
       cmp      dword ptr [rsi+0xC8], r15d
       jge      SHORT G_M000_IG34
       mov      gword ptr [rbp-0x70], r9
       mov      rdi, r8
       mov      esi, eax
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rcx, rax
       mov      r8d, edx
       mov      dword ptr [rsp], r15d
       mov      r15d, dword ptr [rbp-0x30]
       mov      dword ptr [rsp+0x08], r15d
       mov      dword ptr [rsp+0x10], r13d
       mov      bword ptr [rsp+0x18], r14
       lea      rdi, [rbp-0x38]
       mov      qword ptr [rsp+0x20], rdi
       mov      rdi, bword ptr [rbp-0x68]
       mov      rsi, r12
       mov      rdx, rbx
       mov      r9, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StartNativeFixedReturn(Lokad.Lython.Runtime.PyExecutableFunction,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,int,bool,bool,byref,byref):this]
       jmp      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x0421
       mov      rdi, bword ptr [rbp-0x68]
       mov      r10, gword ptr [rdi+0x18]
       mov      rdx, gword ptr [rbx+0x18]
       mov      gword ptr [rsp], rdx
       mov      ecx, dword ptr [rbp-0x30]
       mov      dword ptr [rsp+0x08], ecx
       mov      dword ptr [rsp+0x10], r13d
       xor      rdx, rdx
       xor      ecx, ecx
       mov      bword ptr [rsp+0x18], rdx
       mov      dword ptr [rsp+0x20], ecx
       lea      rdx, [rbp-0x40]
       mov      qword ptr [rsp+0x28], rdx
       mov      bword ptr [rsp+0x30], r14
       lea      rdx, [rbp-0x38]
       mov      qword ptr [rsp+0x38], rdx
       mov      rdx, r8
       mov      ecx, eax
       mov      rdi, r12
       mov      rsi, rbx
       mov      r8, r9
       mov      r9, r10
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
 
G_M000_IG35:                ;; offset=0x0478
       cmp      gword ptr [rbp-0x38], 0
       je       G_M000_IG54
       mov      rax, gword ptr [rbp-0x38]
       mov      rdi, bword ptr [rbp-0x68]
       mov      gword ptr [rdi+0x20], rax
       mov      rax, gword ptr [r12+0x28]
       mov      rax, gword ptr [rax+0x98]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rdi+0x28], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
 
G_M000_IG36:                ;; offset=0x04AB
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG39
 
G_M000_IG37:                ;; offset=0x04B1
       mov      rdi, bword ptr [rbp-0x68]
       mov      rbx, gword ptr [rdi+0x18]
       mov      r15, gword ptr [rbx+0x98]
       mov      rcx, qword ptr [r15+0x160]
       test     rcx, rcx
       jle      SHORT G_M000_IG39
 
G_M000_IG38:                ;; offset=0x04CC
       dec      rcx
       mov      qword ptr [r15+0x160], rcx
 
G_M000_IG39:                ;; offset=0x04D6
       add      rsp, 168
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG40:                ;; offset=0x04E8
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       jmp      G_M000_IG09
 
G_M000_IG41:                ;; offset=0x04F6
       mov      rcx, 0x7F4B83F35F20
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG10
 
G_M000_IG42:                ;; offset=0x0509
       mov      rdi, bword ptr [rbp-0x68]
       xor      rax, rax
       jmp      G_M000_IG12
 
G_M000_IG43:                ;; offset=0x0514
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       jmp      G_M000_IG12
 
G_M000_IG44:                ;; offset=0x0522
       xor      r13d, r13d
       mov      gword ptr [rbp-0x70], rax
       jmp      G_M000_IG20
 
G_M000_IG45:                ;; offset=0x052E
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       jmp      G_M000_IG09
 
G_M000_IG46:                ;; offset=0x053C
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       jmp      G_M000_IG09
 
G_M000_IG47:                ;; offset=0x054A
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       jmp      G_M000_IG12
 
G_M000_IG48:                ;; offset=0x0558
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       jmp      G_M000_IG12
 
G_M000_IG49:                ;; offset=0x0566
       xor      r13d, r13d
       mov      gword ptr [rbp-0x70], rax
       jmp      G_M000_IG20
 
G_M000_IG50:                ;; offset=0x0572
       mov      rdi, 0x7F4B840108D0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rcx, rax
       jmp      G_M000_IG23
 
G_M000_IG51:                ;; offset=0x0589
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       sete     dil
       movzx    rdi, dil
       test     edi, edi
       je       G_M000_IG25
 
G_M000_IG52:                ;; offset=0x05A4
       xor      eax, eax
 
G_M000_IG53:                ;; offset=0x05A6
       add      rsp, 168
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG54:                ;; offset=0x05B8
       call     G_M000_IG58
       nop      
 
G_M000_IG55:                ;; offset=0x05BE
       mov      eax, 1
 
G_M000_IG56:                ;; offset=0x05C3
       add      rsp, 168
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG57:                ;; offset=0x05D5
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG58:                ;; offset=0x05DB
       sub      rsp, 72
 
G_M000_IG59:                ;; offset=0x05DF
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG62
 
G_M000_IG60:                ;; offset=0x05E5
       mov      rdi, bword ptr [rbp-0x68]
       mov      rbx, gword ptr [rdi+0x18]
       mov      r15, gword ptr [rbx+0x98]
       mov      rax, qword ptr [r15+0x160]
       test     rax, rax
       jle      SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x0600
       dec      rax
       mov      qword ptr [r15+0x160], rax
 
G_M000_IG62:                ;; offset=0x060A
       add      rsp, 72
       ret      
 
; Total bytes of code 1551

