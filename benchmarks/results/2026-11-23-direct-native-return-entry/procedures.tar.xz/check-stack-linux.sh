#!/bin/bash
set -euo pipefail
root=/mnt/d/code/Lython
lab="$root/.git/agent-notes/review-20261031/direct-native-return-entry-20261123"
old="$root/.git/agent-notes/review-20261031/native-stack-initialization-20261123"
tree="$root/.git/agent-worktrees/direct-native-return-entry-20261123"
dotnet=/home/vermorel/.dotnet/dotnet
export DOTNET_ROOT=/home/vermorel/.dotnet
cd "$root"
"$dotnet" build src/Lokad.Lython/Lokad.Lython.csproj -c Release -f net10.0 --no-incremental --artifacts-path "$lab/linux-baseline" > "$lab/linux-baseline-build.log" 2>&1
cd "$tree"
"$dotnet" build src/Lokad.Lython/Lokad.Lython.csproj -c Release -f net10.0 --no-incremental --artifacts-path "$lab/linux-direct" > "$lab/linux-direct-build.log" 2>&1
fixture="$old/stack-latest/bin/Lokad.Lython.WorkerFixture/release_net10.0"
test -f "$fixture/Lokad.Lython.WorkerFixture.dll"
for role in reference candidate; do
  path="$lab/stack-$role"
  mkdir "$path"
  cp "$fixture/"* "$path/"
  if [[ "$role" == reference ]]; then suffix=baseline; else suffix=direct; fi
  cp "$lab/linux-$suffix/bin/Lokad.Lython/release_net10.0/Lokad.Lython.dll" "$path/Lokad.Lython.dll"
  sha256sum "$path/Lokad.Lython.dll" "$path/Lokad.Lython.WorkerFixture.dll"
done
status=0
for repeat in 1 2 3 4; do
  if (( repeat % 2 )); then roles=(reference candidate); else roles=(candidate reference); fi
  for role in "${roles[@]}"; do
    path="$lab/stack-$role"
    code=0
    DOTNET_PROCESSOR_COUNT=1 timeout 24s "$dotnet" "$path/Lokad.Lython.WorkerFixture.dll" stack-guard "$path/Lokad.Lython.dll" native-call-continuation > "$lab/$role-stack-$repeat.log" 2>&1 || code=$?
    printf '%s %s exit=%s\n' "$role" "$repeat" "$code"
    cat "$lab/$role-stack-$repeat.log"
    if (( code != 0 )); then status=1; fi
  done
done
exit "$status"
