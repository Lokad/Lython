from pathlib import Path
import hashlib,json,os,subprocess,tarfile

lab=Path(__file__).absolute().parent
repository=lab.parents[3]
worktree=repository/".git/agent-worktrees/direct-native-return-entry-20261123"
prior=lab.parent/"dispatch-known-call-semantics-20261123/comparison"
native=lab.parent/"native-stack-initialization-20261123/comparison"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
write=lambda p,value:p.write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8",newline="\n")
source=read(prior/"identity.json")
retained=read(repository/"benchmarks/results/2026-11-23-dispatch-known-call-semantics/source.json")
assert retained["candidate"]==source["candidate"]
git=lambda *argv:subprocess.check_output(["git","-C",str(worktree),*argv],text=True,encoding="utf-8")
revision=git("rev-parse","HEAD").strip()
assert revision.startswith("2f83b871a") and not git("status","--porcelain")
assert not git("diff","--name-only",retained["retainedRevision"],"HEAD^","--","src","tests")
roles=("reference","candidate")
images={role:{name:sha(lab/role/name) for name in source["imageFiles"]["candidate"]} for role in roles}
assert images["reference"]==source["imageFiles"]["candidate"]
core="Lokad.Lython.dll"
assert images["candidate"][core]==sha(worktree/"src/Lokad.Lython/bin/Release/net11.0"/core)
assert [n for n in images["candidate"] if images["candidate"][n]!=images["reference"][n]]==[core]
summary=read(lab/"native-jit-summary.json")
assert {row["role"]:row["coreSHA256"] for row in summary}=={role:images[role][core] for role in roles}
comparison=lab/"comparison"
comparison.mkdir()
jobs=read(native/"jobs.json")
jobs.insert(3,["scripts.ordinary-fully-supplied-helper","warm"])
assert len(jobs)==8
catalog=native/"representative.json"
destination=comparison/"representative.json"
destination.write_bytes(catalog.read_bytes())
assert len(read(destination)["cases"])==8
write(comparison/"jobs.json",dict(warm=jobs))
verified=read(prior/"reference-verify.json")
dotnet=Path(verified["launched"]["dotnet"]["path"])
python=Path(verified["launched"]["python"]["path"])
protocol=Path(verified["launched"]["pythonWorker"]["path"])
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
assert sha(protocol)==source["cpythonWorkerSHA256"]
for role in roles:
    receipt=comparison/(role+"-verify.json")
    subprocess.run([dotnet,lab/role/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",destination,
        "--dotnet",dotnet,"--python",python,"--python-worker",protocol,"--out",receipt],
        env=env,check=True,timeout=90)
    result=read(receipt)
    assert result["state"]=="Completed" and result["caseCount"]==8 and result["catalogSha256"]==sha(destination)
    assert result["launched"]["library"]["sha256"]==images[role][core]
    assert all(sha(lab/role/n)==h for n,h in images[role].items())
identity=dict(sourceRevision=retained["retainedRevision"], sourceImageRevision=retained["candidate"],
    candidate=revision, purpose="B1455 direct integer calls skip native workspace and fixed-return staging",imageFiles=images,
    coreSHA256={key:images[role][core] for role in roles for key in (role,role+"-control")},
    cpythonWorkerSHA256=sha(protocol),expectedCPythonSHA256=source["expectedCPythonSHA256"],
    catalogs={n:dict(sha256=sha(comparison/n)) for n in ("representative.json","jobs.json")})
write(comparison/"identity.json",identity)
(comparison/"source.patch").write_text(git("diff","--binary","HEAD^","HEAD"),encoding="utf-8",newline="\n")
print(revision,"eight goldens on both images")
