#!/bin/bash
set -euo pipefail
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/direct-native-return-entry-20261123
dotnet=/home/vermorel/.dotnet/dotnet
export DOTNET_ROOT=/home/vermorel/.dotnet
cd "$lab"
for role in reference candidate; do
  image="$lab/$role"
  DOTNET_JitDisasm='StartNativeCall TryStartNativeIntegerReturn TryExecuteNativeCall CallFunction' \
    DOTNET_JitStdOutFile="$lab/$role-linux.asm" \
    "$dotnet" "$image/ValidatedAllocation.dll" "$image" "$lab/comparison/representative.json" "$lab/$role-linux-diagnostic.json"
done
