from pathlib import Path
import json
import re
from statistics import median

lab = Path(__file__).resolve().parent
methods = {"StartNativeCall", "TryStartNativeIntegerReturn", "TryExecuteNativeCall", "CallFunction"}
summary = {}
for platform, suffix in (("windows", ""), ("linux", "-linux")):
    roles = {}
    for role in ("reference", "candidate"):
        path = lab / f"{role}{suffix}.asm"
        entries = path.read_text(encoding="utf-8-sig").split("; Assembly listing for method ")[1:]
        stats = {}
        for entry in entries:
            signature, body = entry.split("\n", 1)
            name = signature.split(":", 1)[1].split("(", 1)[0]
            if name not in methods or not signature.endswith(" (Tier1)"):
                continue
            stack = re.search(r"\bsub\s+rsp,\s*(0x[\da-fA-F]+|\d+)", body)
            size = re.search(r"Total bytes of code (\d+)", body)
            assert name not in stats, signature
            stats[name] = {"stackSubtractionBytes": int(stack[1], 0) if stack else 0, "machineCodeBytes": int(size[1])}
        data = json.loads((lab / f"{role}{suffix}-diagnostic.json").read_text(encoding="utf-8"))
        rows = {row["id"]: {
            "allocatedBytes": median(row["allocatedBytesPerInvocation"]),
            "peakExecutionMemoryBytes": row["peakExecutionMemoryBytes"],
            "compiledReservedBytes": row["compiledReservedBytes"],
            "restored": row["sharedBudgetBaselineRestored"],
        } for row in data["rows"]}
        assert len(rows) == 8 and all(r["restored"] for r in rows.values())
        roles[role] = {"methods": stats, "rows": rows}
    differences = {key: {role: roles[role]["rows"][key] for role in roles} for key in roles["reference"]["rows"] if roles["reference"]["rows"][key] != roles["candidate"]["rows"][key]}
    summary[platform] = {"reference": roles["reference"]["methods"], "candidate": roles["candidate"]["methods"], "referenceOwnershipRows": roles["reference"]["rows"], "differingOwnershipRows": differences}
    print(platform, summary[platform]["reference"], "=>", summary[platform]["candidate"], differences)
(lab / "jit-and-ownership.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")

