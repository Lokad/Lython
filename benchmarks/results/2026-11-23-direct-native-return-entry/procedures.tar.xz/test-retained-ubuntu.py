from pathlib import Path
import subprocess

lab = Path(__file__).resolve().parent
repo = "/mnt/d/code/Lython"
dotnet = "/home/vermorel/.dotnet/dotnet"
with (lab / "retained-ubuntu.log").open("wb") as log:
    result = subprocess.run(["wsl.exe", "--cd", repo, "--exec", "env", "DOTNET_ROOT=/home/vermorel/.dotnet",
        "DOTNET_HOST_PATH=" + dotnet, dotnet, "test", "tests/Lokad.Lython.PublicApi.Tests",
        "-c", "Release", "-f", "net10.0",
        "--artifacts-path", repo + "/" + lab.relative_to(lab.parents[3]).as_posix() + "/retained-ubuntu",
        "--filter", "FullyQualifiedName~NativeReturnFunctionTests|FullyQualifiedName~StackGuardScenarioTests.YieldedDeepWorkUnwindsAndRecoversInAnIsolatedProcess"],
        stdout=log, stderr=subprocess.STDOUT, timeout=145)
print((lab / "retained-ubuntu.log").read_text(encoding="utf-8")[-6500:])
raise SystemExit(result.returncode)

