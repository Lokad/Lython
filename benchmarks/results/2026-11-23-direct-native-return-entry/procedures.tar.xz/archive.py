from pathlib import Path
import gzip
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
comparison = lab / "comparison"
quiet = comparison / "quiet"
read = lambda p: json.loads(p.read_text(encoding="utf-8"))
sha = lambda data: hashlib.sha256(data).hexdigest()
dest = repo / "benchmarks/results/2026-11-23-direct-native-return-entry"
identity = read(comparison / "identity.json")
terminal = read(quiet / "terminal-status.json")
assert terminal["exitCode"] == "0" and terminal["receipt"]["archivedAndVerifiedUnderLease"]
assert sha((quiet / "observations.tar.xz").read_bytes()) == terminal["receipt"]["archiveSHA256"]
for role, files in identity["imageFiles"].items():
    assert len(files) == 32
    for name, digest in files.items():
        assert sha((lab / role / name).read_bytes()) == digest
core = (lab / "candidate/Lokad.Lython.dll").read_bytes()
dest.mkdir(exist_ok=True)
for file in ("terminal-status.json", "observations.tar.xz", "summary.json"):
    shutil.copyfile(quiet / file, dest / file)
shutil.copyfile(comparison / "identity.json", dest / "identity.json")
shutil.copyfile(lab / "jit-and-ownership.json", dest / "jit-and-ownership.json")
(dest / "candidate-core.dll.gz").write_bytes(gzip.compress(core, mtime=0))
with tarfile.open(dest / "procedures.tar.xz", "w:xz") as archive:
    def add(file):
        archive.add(lab / file, arcname=file, recursive=False)
    for file in ("archive.py", "freeze.py", "stage.py", "quiet.py", "summarize.py",
            "compare-stack.py", "check-stack-linux.sh", "inspect-jit.py", "inspect-linux.sh", "summarize-jit.py",
            "test-retained-ubuntu.py", "retained-windows.log", "retained-ubuntu.log", "retained-ubuntu-launch-initial.log",
            "comparison/reference-verify.json", "comparison/candidate-verify.json", "comparison/source.patch",
            "comparison/jobs.json", "comparison/representative.json",
            "comparison/quiet/launch.log", "comparison/quiet/observe-not-before", "stack-control-rerun.json",
            "linux-baseline-build.log", "linux-direct-build.log"):
        add(file)
    for role in ("reference", "candidate"):
        for suffix in ("", "-linux"):
            add(role + suffix + ".asm")
            add(role + suffix + "-diagnostic.json")
        for repeat in range(1, 5):
            add(f"{role}-stack-{repeat}.log")
assert sha(gzip.decompress((dest / "candidate-core.dll.gz").read_bytes())) == identity["coreSHA256"]["candidate"]
print(dest)
