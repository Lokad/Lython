; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x400
       lea      rbp, [rsp+0x400]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x3A0], xmm4
       mov      rax, -912
 
G_M000_IG77:                ;; offset=0x0026
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG77
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x004D
       mov      rax, bword ptr [rbp+0x40]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
       mov      rdx, gword ptr [rbp+0x38]
       mov      rcx, 0x7FFA02847368
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x248], rax
       mov      rdx, gword ptr [rbp-0x248]
       mov      rcx, 0x7FFA026F6F40
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x00B8
       xor      rax, rax
       mov      gword ptr [rbp-0x118], rax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00C3
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x118], rax
 
G_M000_IG05:                ;; offset=0x00E1
       mov      rax, gword ptr [rbp-0x118]
       mov      gword ptr [rbp-0x10], rax
       mov      rdx, gword ptr [rbp+0x38]
       mov      rcx, 0x7FFA0286D848
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x18], rax
       cmp      gword ptr [rbp-0x18], 0
       je       SHORT G_M000_IG06
       mov      rcx, gword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Function():Lokad.Lython.Runtime.LythonRuntime+ICallable:this]
       mov      gword ptr [rbp-0x250], rax
       mov      rdx, gword ptr [rbp-0x250]
       mov      rcx, 0x7FFA02847368
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x20], 0
       je       SHORT G_M000_IG06
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Receiver():System.Object:this]
       mov      gword ptr [rbp-0x10], rax
 
G_M000_IG06:                ;; offset=0x0158
       cmp      gword ptr [rbp-0x08], 0
       je       G_M000_IG27
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG27
       lea      r9, [rbp-0x28]
       mov      rcx, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r8, gword ptr [rbp-0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG08
       xor      eax, eax
 
G_M000_IG07:                ;; offset=0x018C
       add      rsp, 0x400
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0195
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
 
G_M000_IG09:                ;; offset=0x019A
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x258], rax
       mov      rdx, gword ptr [rbp-0x258]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x2C], 1
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x260], rax
       mov      rdx, gword ptr [rbp-0x260]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x1F8], rax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rbp-0x1FC], eax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x264], eax
       mov      r9d, dword ptr [rbp-0x264]
       lea      rdx, [rbp-0x88]
       mov      r8d, dword ptr [rbp-0x1FC]
       mov      rcx, bword ptr [rbp-0x1F8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:Slice(int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       lea      rdx, [rbp-0x40]
       lea      rcx, [rbp-0x88]
       call     [System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_Span():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       lea      rax, [rbp-0x58]
       mov      qword ptr [rsp+0x20], rax
       lea      rcx, [rbp-0x50]
       mov      rdx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PrepareUnpackedCallReturn(byref,Lokad.Lython.Frontend.ExecutableCallSite,int,byref):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG10:                ;; offset=0x027B
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x278], xmm0
 
G_M000_IG11:                ;; offset=0x0288
       lea      rdx, [rbp-0x278]
       lea      rcx, [rbp-0x210]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x218], rax
 
G_M000_IG12:                ;; offset=0x02AF
       vmovdqu  xmm0, xmmword ptr [rbp-0x210]
       vmovdqu  xmmword ptr [rbp-0x288], xmm0
 
G_M000_IG13:                ;; offset=0x02BF
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CallResultConsumedByIteration(byref,Lokad.Lython.Frontend.ExecutableCallSite):bool]
       mov      dword ptr [rbp-0x29C], eax
       movzx    rax, byte  ptr [rbp-0x28]
       mov      dword ptr [rbp-0x2A0], eax
 
G_M000_IG14:                ;; offset=0x02DD
       vmovdqu  xmm0, xmmword ptr [rbp-0x50]
       vmovdqu  xmmword ptr [rbp-0x298], xmm0
 
G_M000_IG15:                ;; offset=0x02EA
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x48], rax
       lea      rax, [rbp-0x70]
       mov      qword ptr [rsp+0x50], rax
       lea      rax, [rbp-0x78]
       mov      qword ptr [rsp+0x58], rax
       mov      eax, dword ptr [rbp-0x29C]
       mov      dword ptr [rsp+0x30], eax
       lea      r8, [rbp-0x288]
       mov      eax, dword ptr [rbp-0x2A0]
       mov      dword ptr [rsp+0x38], eax
       lea      rax, [rbp-0x298]
       mov      qword ptr [rsp+0x40], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp-0x218]
       mov      gword ptr [rsp+0x28], rax
       mov      rcx, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r9, gword ptr [rbp-0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       movzx    rax, byte  ptr [rbp-0x60]
       test     eax, eax
       jne      SHORT G_M000_IG16
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RestoreNativeExtent(int):this]
 
G_M000_IG16:                ;; offset=0x0374
       cmp      gword ptr [rbp-0x78], 0
       je       G_M000_IG19
 
G_M000_IG17:                ;; offset=0x037F
       mov      rcx, gword ptr [rbp-0x78]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterExecutableSlots():this]
       mov      rax, gword ptr [rbp-0x78]
       mov      gword ptr [rbp-0x220], rax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x228], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x2A8], rax
       mov      rax, gword ptr [rbp-0x2A8]
       mov      gword ptr [rsp+0x30], rax
       mov      rdx, gword ptr [rbp-0x220]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [rbp+0x30]
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp+0x20]
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AttachPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.LythonSourceSpan,int,Lokad.Lython.Runtime.MemoryGovernor):this]
       nop      
 
G_M000_IG18:                ;; offset=0x0401
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, gword ptr [rbp-0x78]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       mov      dword ptr [rbp-0x8C], 1
       jmp      G_M000_IG25
 
G_M000_IG19:                ;; offset=0x0422
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       movzx    rax, byte  ptr [rbp-0x60]
       test     eax, eax
       je       SHORT G_M000_IG20
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8d, dword ptr [rbp+0x30]
       mov      r9d, dword ptr [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteUnpackedCallReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,int)]
       jmp      SHORT G_M000_IG23
 
G_M000_IG20:                ;; offset=0x0453
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG24
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x2C8], rax
 
G_M000_IG21:                ;; offset=0x0480
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG22:                ;; offset=0x048D
       mov      r8, bword ptr [rbp-0x2C8]
       lea      r9, [rbp-0x2C0]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
 
G_M000_IG23:                ;; offset=0x04A9
       mov      dword ptr [rbp-0x8C], 1
       jmp      SHORT G_M000_IG26
 
G_M000_IG24:                ;; offset=0x04B5
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG25:                ;; offset=0x04BB
       call     G_M000_IG69
       jmp      G_M000_IG61
 
G_M000_IG26:                ;; offset=0x04C5
       call     G_M000_IG69
       jmp      G_M000_IG61
 
G_M000_IG27:                ;; offset=0x04CF
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG53
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       je       G_M000_IG53
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG30
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x2D8], rax
       mov      rdx, gword ptr [rbp-0x2D8]
       mov      rcx, 0x7FFA0286DD10
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xA0], rax
       cmp      gword ptr [rbp-0xA0], 0
       je       SHORT G_M000_IG30
       mov      rax, bword ptr [rbp+0x10]
       mov      bword ptr [rbp-0x1E8], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x1F0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG28
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x1F0], rax
 
G_M000_IG28:                ;; offset=0x056E
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp-0x1E8]
       mov      rdx, gword ptr [rbp-0x1F0]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteCasedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCasedSplit,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG30
       mov      eax, 1
 
G_M000_IG29:                ;; offset=0x05A6
       add      rsp, 0x400
       pop      rbp
       ret      
 
G_M000_IG30:                ;; offset=0x05AF
       mov      rdx, gword ptr [rbp+0x38]
       mov      rcx, 0x7FFA0286E138
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xA8], rax
       cmp      gword ptr [rbp-0xA8], 0
       jne      SHORT G_M000_IG32
       xor      eax, eax
 
G_M000_IG31:                ;; offset=0x05D6
       add      rsp, 0x400
       pop      rbp
       ret      
 
G_M000_IG32:                ;; offset=0x05DF
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x2E0], rax
       mov      rdx, gword ptr [rbp-0x2E0]
       mov      rcx, 0x7FFA0286E440
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xB0], rax
       cmp      gword ptr [rbp-0xB0], 0
       je       SHORT G_M000_IG33
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteTrimmedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG33
       mov      dword ptr [rbp-0x8C], 1
       jmp      G_M000_IG61
 
G_M000_IG33:                ;; offset=0x065F
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x138], rax
       mov      rax, gword ptr [rbp-0xA8]
       mov      gword ptr [rbp-0x140], rax
       mov      rax, gword ptr [rbp-0x138]
       mov      gword ptr [rbp-0x148], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x2E8], rax
       mov      rdx, gword ptr [rbp-0x2E8]
       lea      rcx, [rbp-0x158]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 24
       mov      bword ptr [rbp-0x160], rax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rbp-0x168], rax
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rbp-0x16C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x178], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG34
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x178], rax
 
G_M000_IG34:                ;; offset=0x06FE
       vmovdqu  xmm0, xmmword ptr [rbp-0x158]
       vmovdqu  xmmword ptr [rbp-0x2F8], xmm0
 
G_M000_IG35:                ;; offset=0x070E
       mov      rax, gword ptr [rbp-0x168]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp-0x16C]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0xC0]
       mov      qword ptr [rsp+0x38], rax
       lea      r8, [rbp-0x2F8]
       mov      rdx, gword ptr [rbp-0x148]
       mov      rcx, gword ptr [rbp-0x140]
       mov      r9, bword ptr [rbp-0x160]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG38
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG52
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x310], rax
 
G_M000_IG36:                ;; offset=0x0793
       vmovdqu  xmm0, xmmword ptr [rbp-0xC0]
       vmovdqu  xmmword ptr [rbp-0x308], xmm0
 
G_M000_IG37:                ;; offset=0x07A3
       mov      r8, bword ptr [rbp-0x310]
       lea      r9, [rbp-0x308]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0x8C], 1
       jmp      G_M000_IG61
 
G_M000_IG38:                ;; offset=0x07CE
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0xC8], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x180], rax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rbp-0x184], eax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x314], eax
       mov      r9d, dword ptr [rbp-0x314]
       lea      rdx, [rbp-0x88]
       mov      r8d, dword ptr [rbp-0x184]
       mov      rcx, bword ptr [rbp-0x180]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:Slice(int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       lea      rdx, [rbp-0xD8]
       lea      rcx, [rbp-0x88]
       call     [System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_Span():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG43
       mov      rcx, 0x7FFA0286E738
       call     [CORINFO_HELP_GET_GCSTATIC_BASE]
       mov      rax, 0x242EF401C60
       mov      rax, gword ptr [rax]
       cmp      rax, gword ptr [rbp-0xA8]
       jne      G_M000_IG43
       mov      rdx, gword ptr [rbp-0xC8]
       mov      rcx, 0x7FFA025ACB28
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xE0], rax
       cmp      gword ptr [rbp-0xE0], 0
       je       G_M000_IG43
       cmp      dword ptr [rbp-0xD0], 2
       jg       G_M000_IG43
 
G_M000_IG39:                ;; offset=0x08D5
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rbp-0x328], xmm0
 
G_M000_IG40:                ;; offset=0x08E5
       lea      rdx, [rbp-0x328]
       lea      rcx, [rbp-0x1D8]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, gword ptr [rbp-0xE0]
       mov      gword ptr [rsp+0x28], rax
 
G_M000_IG41:                ;; offset=0x090C
       vmovdqu  xmm0, xmmword ptr [rbp-0x1D8]
       vmovdqu  xmmword ptr [rbp-0x338], xmm0
 
G_M000_IG42:                ;; offset=0x091C
       lea      rax, [rbp-0x338]
       mov      qword ptr [rsp+0x30], rax
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp+0x18]
       mov      r9, gword ptr [rbp+0x28]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSplitUnpack(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool]
       test     eax, eax
       je       SHORT G_M000_IG43
       mov      dword ptr [rbp-0x8C], 1
       jmp      G_M000_IG61
 
G_M000_IG43:                ;; offset=0x0951
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_AccumulatesDictionary():bool:this]
       test     eax, eax
       je       G_M000_IG45
       mov      eax, dword ptr [rbp-0xD0]
       mov      dword ptr [rbp-0xF4], eax
       cmp      dword ptr [rbp-0xF4], 1
       je       SHORT G_M000_IG44
       cmp      dword ptr [rbp-0xF4], 2
       jne      G_M000_IG45
 
G_M000_IG44:                ;; offset=0x0987
       mov      rcx, 0x7FFA0286E738
       call     [CORINFO_HELP_GET_GCSTATIC_BASE]
       mov      rax, 0x242EF401C30
       mov      rax, gword ptr [rax]
       cmp      rax, gword ptr [rbp-0xA8]
       jne      G_M000_IG45
       mov      rdx, gword ptr [rbp-0xC8]
       mov      rcx, 0x7FFA02607AA0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xE8], rax
       cmp      gword ptr [rbp-0xE8], 0
       je       G_M000_IG45
       cmp      dword ptr [rbp-0xD0], 0
       jbe      G_M000_IG52
       mov      rcx, bword ptr [rbp-0xD8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x340], rax
       mov      rdx, gword ptr [rbp-0x340]
       mov      rcx, gword ptr [rbp-0xE8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG45
       cmp      dword ptr [rbp-0xD0], 0
       jbe      G_M000_IG52
       mov      rcx, bword ptr [rbp-0xD8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x348], rax
       mov      rdx, gword ptr [rbp-0x348]
       mov      rcx, 0x7FFA025ACB28
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x350], rax
       mov      rax, gword ptr [rbp-0x350]
       mov      gword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [rbp+0x30]
       mov      rax, gword ptr [rbp-0xE8]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryAccumulation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.PyDict,Lokad.Lython.Runtime.Text.PyString):bool]
       test     eax, eax
       je       SHORT G_M000_IG45
       mov      dword ptr [rbp-0x8C], 1
       jmp      G_M000_IG61
 
G_M000_IG45:                ;; offset=0x0A9C
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rbp-0x198], xmm0
 
G_M000_IG46:                ;; offset=0x0AAC
       mov      rax, gword ptr [rbp-0xA8]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rax, gword ptr [rbp-0xC8]
       mov      gword ptr [rbp-0x1A8], rax
 
G_M000_IG47:                ;; offset=0x0AC8
       vmovdqu  xmm0, xmmword ptr [rbp-0x198]
       vmovdqu  xmmword ptr [rbp-0x1B8], xmm0
 
G_M000_IG48:                ;; offset=0x0AD8
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x1C8], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG49
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x1C8], rax
 
G_M000_IG49:                ;; offset=0x0B08
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B8]
       vmovdqu  xmmword ptr [rbp-0x360], xmm0
 
G_M000_IG50:                ;; offset=0x0B18
       mov      rax, gword ptr [rbp-0x1C8]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x360]
       mov      rdx, gword ptr [rbp-0x1A8]
       mov      rcx, gword ptr [rbp-0x1A0]
       mov      r9, gword ptr [rbp-0x1C0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG51
       xor      eax, eax
       mov      dword ptr [rbp-0x8C], eax
       jmp      G_M000_IG61
 
G_M000_IG51:                ;; offset=0x0B63
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG52
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x368], rax
       mov      r8, bword ptr [rbp-0x368]
       mov      rdx, gword ptr [rbp+0x20]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       mov      dword ptr [rbp-0x8C], 1
       jmp      G_M000_IG61
 
G_M000_IG52:                ;; offset=0x0BBB
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG53:                ;; offset=0x0BC1
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x370], rax
       mov      rdx, gword ptr [rbp-0x370]
       lea      rcx, [rbp-0x128]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG54:                ;; offset=0x0BF0
       vmovdqu  xmm0, xmmword ptr [rbp-0x128]
       vmovdqu  xmmword ptr [rbp-0x380], xmm0
 
G_M000_IG55:                ;; offset=0x0C00
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       cmp      gword ptr [rbp+0x20], 0
       setne    al
       movzx    rax, al
       mov      dword ptr [rsp+0x28], eax
       lea      rax, [rbp-0x108]
       mov      qword ptr [rsp+0x30], rax
       lea      r8, [rbp-0x380]
       mov      rdx, gword ptr [rbp+0x38]
       mov      rcx, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG56
       xor      eax, eax
       mov      dword ptr [rbp-0x8C], eax
       jmp      G_M000_IG61
 
G_M000_IG56:                ;; offset=0x0C4E
       lea      rcx, [rbp-0x108]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x388], rax
       mov      rdx, gword ptr [rbp-0x388]
       mov      rcx, 0x7FFA024EE760
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x110], rax
       cmp      gword ptr [rbp-0x110], 0
       je       SHORT G_M000_IG58
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, gword ptr [rbp-0x110]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0x8C], 1
       jmp      SHORT G_M000_IG61
 
G_M000_IG57:                ;; offset=0x0CBD
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG58:                ;; offset=0x0CC3
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x3A0], rax
 
G_M000_IG59:                ;; offset=0x0CF0
       vmovdqu  xmm0, xmmword ptr [rbp-0x108]
       vmovdqu  xmmword ptr [rbp-0x398], xmm0
 
G_M000_IG60:                ;; offset=0x0D00
       mov      r8, bword ptr [rbp-0x3A0]
       lea      r9, [rbp-0x398]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0x8C], 1
 
G_M000_IG61:                ;; offset=0x0D26
       mov      eax, dword ptr [rbp-0x8C]
 
G_M000_IG62:                ;; offset=0x0D2C
       add      rsp, 0x400
       pop      rbp
       ret      
 
G_M000_IG63:                ;; offset=0x0D35
       sub      rsp, 104
 
G_M000_IG64:                ;; offset=0x0D39
       mov      gword ptr [rbp-0x230], rcx
       mov      rax, gword ptr [rbp-0x78]
       mov      gword ptr [rbp-0x238], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x2B0], rax
       mov      rdx, gword ptr [rbp-0x2B0]
       mov      rcx, gword ptr [rbp-0x238]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AbortPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG65:                ;; offset=0x0D83
       sub      rsp, 104
 
G_M000_IG66:                ;; offset=0x0D87
       mov      gword ptr [rbp-0x240], rcx
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2D0], rax
       mov      rdx, gword ptr [rbp-0x2D0]
       lea      r8, [rbp-0x98]
       mov      rcx, gword ptr [rbp-0x240]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG68
 
G_M000_IG67:                ;; offset=0x0DD7
       mov      rcx, gword ptr [rbp-0x98]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG68:                ;; offset=0x0DE4
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG69:                ;; offset=0x0DEA
       sub      rsp, 104
 
G_M000_IG70:                ;; offset=0x0DEE
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG71
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG71:                ;; offset=0x0E00
       nop      
 
G_M000_IG72:                ;; offset=0x0E01
       add      rsp, 104
       ret      
 
G_M000_IG73:                ;; offset=0x0E06
       sub      rsp, 104
 
G_M000_IG74:                ;; offset=0x0E0A
       mov      gword ptr [rbp-0x1E0], rcx
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG75:                ;; offset=0x0E2E
       sub      rsp, 104
 
G_M000_IG76:                ;; offset=0x0E32
       mov      gword ptr [rbp-0x130], rcx
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 3670

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 704
       lea      rbp, [rsp+0x2C0]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -624
 
G_M000_IG32:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG32
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0045
       cmp      gword ptr [rbp+0x28], 0
       jne      G_M000_IG13
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       G_M000_IG13
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       jne      SHORT G_M000_IG05
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG03:                ;; offset=0x0079
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1C0], xmm0
 
G_M000_IG04:                ;; offset=0x0085
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x1C0]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x19C], eax
       jmp      G_M000_IG11
 
G_M000_IG05:                ;; offset=0x00BB
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x198], eax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x198]
       jne      SHORT G_M000_IG10
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG06:                ;; offset=0x00E9
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG07:                ;; offset=0x00F5
       lea      rdx, [rbp-0x1D0]
       lea      rcx, [rbp-0x1B0]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
 
G_M000_IG08:                ;; offset=0x0109
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
 
G_M000_IG09:                ;; offset=0x0119
       lea      rdx, [rbp-0x1E0]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, bword ptr [rbp+0x60]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x19C], eax
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x013A
       xor      eax, eax
       mov      dword ptr [rbp-0x19C], eax
 
G_M000_IG11:                ;; offset=0x0142
       cmp      dword ptr [rbp-0x19C], 0
       je       SHORT G_M000_IG13
       mov      rax, bword ptr [rbp+0x58]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x68]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG12:                ;; offset=0x015B
       vzeroupper 
       add      rsp, 704
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x0167
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
       vmovdqu  ymmword ptr [rbp-0xE0], ymm0
       vmovdqu  ymmword ptr [rbp-0xC0], ymm0
       vmovdqu  ymmword ptr [rbp-0xA0], ymm0
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  ymmword ptr [rbp-0x40], ymm0
       vmovdqu  ymmword ptr [rbp-0x20], ymm0
       lea      rdx, [rbp-0x100]
       lea      rcx, [rbp-0x110]
       mov      r8d, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       mov      r9d, dword ptr [rbp-0x1E4]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x110]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       je       G_M000_IG17
       xor      eax, eax
       mov      dword ptr [rbp-0x114], eax
       cmp      gword ptr [rbp+0x28], 0
       je       SHORT G_M000_IG14
       mov      eax, dword ptr [rbp-0x114]
       mov      dword ptr [rbp-0x194], eax
       mov      eax, dword ptr [rbp-0x114]
       inc      eax
       mov      dword ptr [rbp-0x114], eax
       mov      eax, dword ptr [rbp-0x108]
       cmp      dword ptr [rbp-0x194], eax
       jae      G_M000_IG31
       mov      eax, dword ptr [rbp-0x194]
       shl      rax, 4
       mov      rcx, rax
       add      rcx, bword ptr [rbp-0x110]
       mov      rdx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG14:                ;; offset=0x0257
       lea      rdx, [rbp-0x190]
       lea      rcx, [rbp-0x110]
       mov      r8d, dword ptr [rbp-0x114]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG15:                ;; offset=0x0272
       vmovdqu  xmm0, xmmword ptr [rbp-0x190]
       vmovdqu  xmmword ptr [rbp-0x1F8], xmm0
 
G_M000_IG16:                ;; offset=0x0282
       lea      rdx, [rbp-0x1F8]
       mov      rcx, bword ptr [rbp+0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG23
 
G_M000_IG17:                ;; offset=0x0298
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x1FC], eax
       mov      r9d, dword ptr [rbp-0x1FC]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x170]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG18:                ;; offset=0x02D2
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0x210], xmm0
 
G_M000_IG19:                ;; offset=0x02E2
       vmovdqu  xmm0, xmmword ptr [rbp-0x128]
       vmovdqu  xmmword ptr [rbp-0x220], xmm0
 
G_M000_IG20:                ;; offset=0x02F2
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG21:                ;; offset=0x0317
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x230], xmm0
 
G_M000_IG22:                ;; offset=0x0323
       lea      rcx, [rbp-0x210]
       lea      rdx, [rbp-0x220]
       lea      rax, [rbp-0x230]
       mov      qword ptr [rsp+0x40], rax
       mov      r9, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG23:                ;; offset=0x034B
       vmovdqu  xmm0, xmmword ptr [rbp-0x110]
       vmovdqu  xmmword ptr [rbp-0x180], xmm0
 
G_M000_IG24:                ;; offset=0x035B
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
 
G_M000_IG25:                ;; offset=0x0367
       vmovdqu  xmm0, xmmword ptr [rbp-0x180]
       vmovdqu  xmmword ptr [rbp-0x240], xmm0
 
G_M000_IG26:                ;; offset=0x0377
       vmovdqu  ymm0, ymmword ptr [rbp-0x160]
       vmovdqu  ymmword ptr [rbp-0x260], ymm0
 
G_M000_IG27:                ;; offset=0x0387
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG28:                ;; offset=0x0393
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x270], xmm0
 
G_M000_IG29:                ;; offset=0x039F
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rax
       lea      rax, [rbp-0x140]
       mov      qword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0x240]
       lea      r8, [rbp-0x260]
       lea      rax, [rbp-0x270]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp+0x38]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG30:                ;; offset=0x03EF
       vzeroupper 
       add      rsp, 704
       pop      rbp
       ret      
 
G_M000_IG31:                ;; offset=0x03FB
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1025

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x410
       lea      rbp, [rsp+0x410]
       xor      eax, eax
       mov      qword ptr [rbp-0x3A8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x3A0], xmm4
       mov      rax, -912
 
G_M000_IG94:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG94
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0056
       mov      rax, bword ptr [rbp+0x40]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
       mov      rdx, gword ptr [rbp+0x38]
       mov      rcx, 0x7FFA02847368
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG04
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x250], rax
       mov      rdx, gword ptr [rbp-0x250]
       mov      rcx, 0x7FFA026F6F40
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x00C1
       mov      rcx, 0x7FFA029444D8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00D0
       xor      rax, rax
       mov      gword ptr [rbp-0x118], rax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x00DB
       mov      rcx, 0x7FFA029444DC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x118], rax
 
G_M000_IG06:                ;; offset=0x0108
       mov      rax, gword ptr [rbp-0x118]
       mov      gword ptr [rbp-0x10], rax
       mov      rdx, gword ptr [rbp+0x38]
       mov      rcx, 0x7FFA0286D848
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x18], rax
       cmp      gword ptr [rbp-0x18], 0
       je       SHORT G_M000_IG07
       mov      rcx, gword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Function():Lokad.Lython.Runtime.LythonRuntime+ICallable:this]
       mov      gword ptr [rbp-0x258], rax
       mov      rdx, gword ptr [rbp-0x258]
       mov      rcx, 0x7FFA02847368
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x20], 0
       je       G_M000_IG10
       mov      rcx, 0x7FFA029444E0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Receiver():System.Object:this]
       mov      gword ptr [rbp-0x10], rax
 
G_M000_IG07:                ;; offset=0x0192
       cmp      gword ptr [rbp-0x08], 0
       je       G_M000_IG30
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG09
       lea      r9, [rbp-0x28]
       mov      rcx, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r8, gword ptr [rbp-0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG11
       mov      rcx, 0x7FFA029444E4
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG08:                ;; offset=0x01D1
       add      rsp, 0x410
       pop      rbp
       ret      
 
G_M000_IG09:                ;; offset=0x01DA
       mov      rcx, 0x7FFA029444E8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG30
 
G_M000_IG10:                ;; offset=0x01EE
       mov      rcx, 0x7FFA029444EC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG07
 
G_M000_IG11:                ;; offset=0x01FF
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
 
G_M000_IG12:                ;; offset=0x0204
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x260], rax
       mov      rdx, gword ptr [rbp-0x260]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x2C], 1
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x268], rax
       mov      rdx, gword ptr [rbp-0x268]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x1F8], rax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rbp-0x1FC], eax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x26C], eax
       mov      r9d, dword ptr [rbp-0x26C]
       lea      rdx, [rbp-0x88]
       mov      r8d, dword ptr [rbp-0x1FC]
       mov      rcx, bword ptr [rbp-0x1F8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:Slice(int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       lea      rdx, [rbp-0x40]
       lea      rcx, [rbp-0x88]
       call     [System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_Span():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       lea      rax, [rbp-0x58]
       mov      qword ptr [rsp+0x20], rax
       lea      rcx, [rbp-0x50]
       mov      rdx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PrepareUnpackedCallReturn(byref,Lokad.Lython.Frontend.ExecutableCallSite,int,byref):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG13:                ;; offset=0x02E5
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x280], xmm0
 
G_M000_IG14:                ;; offset=0x02F2
       lea      rdx, [rbp-0x280]
       lea      rcx, [rbp-0x210]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x218], rax
 
G_M000_IG15:                ;; offset=0x0319
       vmovdqu  xmm0, xmmword ptr [rbp-0x210]
       vmovdqu  xmmword ptr [rbp-0x290], xmm0
 
G_M000_IG16:                ;; offset=0x0329
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CallResultConsumedByIteration(byref,Lokad.Lython.Frontend.ExecutableCallSite):bool]
       mov      dword ptr [rbp-0x2A4], eax
       movzx    rax, byte  ptr [rbp-0x28]
       mov      dword ptr [rbp-0x2A8], eax
 
G_M000_IG17:                ;; offset=0x0347
       vmovdqu  xmm0, xmmword ptr [rbp-0x50]
       vmovdqu  xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG18:                ;; offset=0x0354
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x48], rax
       lea      rax, [rbp-0x70]
       mov      qword ptr [rsp+0x50], rax
       lea      rax, [rbp-0x78]
       mov      qword ptr [rsp+0x58], rax
       mov      eax, dword ptr [rbp-0x2A4]
       mov      dword ptr [rsp+0x30], eax
       lea      r8, [rbp-0x290]
       mov      eax, dword ptr [rbp-0x2A8]
       mov      dword ptr [rsp+0x38], eax
       lea      rax, [rbp-0x2A0]
       mov      qword ptr [rsp+0x40], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp-0x218]
       mov      gword ptr [rsp+0x28], rax
       mov      rcx, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r9, gword ptr [rbp-0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       movzx    rax, byte  ptr [rbp-0x60]
       test     eax, eax
       jne      SHORT G_M000_IG19
       mov      rcx, 0x7FFA029444F0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RestoreNativeExtent(int):this]
 
G_M000_IG19:                ;; offset=0x03ED
       cmp      gword ptr [rbp-0x78], 0
       je       G_M000_IG22
 
G_M000_IG20:                ;; offset=0x03F8
       mov      rcx, gword ptr [rbp-0x78]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterExecutableSlots():this]
       mov      rax, gword ptr [rbp-0x78]
       mov      gword ptr [rbp-0x220], rax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x228], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x2B0], rax
       mov      rax, gword ptr [rbp-0x2B0]
       mov      gword ptr [rsp+0x30], rax
       mov      rdx, gword ptr [rbp-0x220]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [rbp+0x30]
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp+0x20]
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AttachPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.LythonSourceSpan,int,Lokad.Lython.Runtime.MemoryGovernor):this]
       nop      
 
G_M000_IG21:                ;; offset=0x047A
       mov      rcx, 0x7FFA029444F4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, gword ptr [rbp-0x78]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       mov      dword ptr [rbp-0x8C], 1
       jmp      G_M000_IG28
 
G_M000_IG22:                ;; offset=0x04AA
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       movzx    rax, byte  ptr [rbp-0x60]
       test     eax, eax
       je       SHORT G_M000_IG23
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8d, dword ptr [rbp+0x30]
       mov      r9d, dword ptr [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteUnpackedCallReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,int)]
       jmp      SHORT G_M000_IG26
 
G_M000_IG23:                ;; offset=0x04DB
       mov      rcx, 0x7FFA029444F8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG27
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x2D0], rax
 
G_M000_IG24:                ;; offset=0x0517
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0x2C8], xmm0
 
G_M000_IG25:                ;; offset=0x0524
       mov      r8, bword ptr [rbp-0x2D0]
       lea      r9, [rbp-0x2C8]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
 
G_M000_IG26:                ;; offset=0x0540
       mov      rcx, 0x7FFA029444FC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x8C], 1
       jmp      SHORT G_M000_IG29
 
G_M000_IG27:                ;; offset=0x055B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG28:                ;; offset=0x0561
       call     G_M000_IG86
       jmp      G_M000_IG78
 
G_M000_IG29:                ;; offset=0x056B
       call     G_M000_IG86
       jmp      G_M000_IG78
 
G_M000_IG30:                ;; offset=0x0575
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG70
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       je       G_M000_IG35
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG36
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x2E0], rax
       mov      rdx, gword ptr [rbp-0x2E0]
       mov      rcx, 0x7FFA0286DD10
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xA0], rax
       cmp      gword ptr [rbp-0xA0], 0
       je       G_M000_IG34
       mov      rax, bword ptr [rbp+0x10]
       mov      bword ptr [rbp-0x1E8], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x1F0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG31
       mov      rcx, 0x7FFA02944508
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x1F0], rax
 
G_M000_IG31:                ;; offset=0x0627
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp-0x1E8]
       mov      rdx, gword ptr [rbp-0x1F0]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteCasedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCasedSplit,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG33
       mov      rcx, 0x7FFA0294450C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG32:                ;; offset=0x066E
       add      rsp, 0x410
       pop      rbp
       ret      
 
G_M000_IG33:                ;; offset=0x0677
       mov      rcx, 0x7FFA02944510
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG36
 
G_M000_IG34:                ;; offset=0x0688
       mov      rcx, 0x7FFA02944514
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x0699
       mov      rcx, 0x7FFA02944518
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG70
 
G_M000_IG36:                ;; offset=0x06AD
       mov      rdx, gword ptr [rbp+0x38]
       mov      rcx, 0x7FFA0286E138
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xA8], rax
       cmp      gword ptr [rbp-0xA8], 0
       jne      SHORT G_M000_IG38
       mov      rcx, 0x7FFA0294451C
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG37:                ;; offset=0x06E3
       add      rsp, 0x410
       pop      rbp
       ret      
 
G_M000_IG38:                ;; offset=0x06EC
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x2E8], rax
       mov      rdx, gword ptr [rbp-0x2E8]
       mov      rcx, 0x7FFA0286E440
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xB0], rax
       cmp      gword ptr [rbp-0xB0], 0
       je       SHORT G_M000_IG40
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteTrimmedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG39
       mov      rcx, 0x7FFA02944520
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x8C], 1
       jmp      G_M000_IG78
 
G_M000_IG39:                ;; offset=0x077B
       mov      rcx, 0x7FFA02944524
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG40:                ;; offset=0x078A
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x138], rax
       mov      rax, gword ptr [rbp-0xA8]
       mov      gword ptr [rbp-0x140], rax
       mov      rax, gword ptr [rbp-0x138]
       mov      gword ptr [rbp-0x148], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x2F0], rax
       mov      rdx, gword ptr [rbp-0x2F0]
       lea      rcx, [rbp-0x158]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 24
       mov      bword ptr [rbp-0x160], rax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rbp-0x168], rax
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rbp-0x16C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x178], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG41
       mov      rcx, 0x7FFA02944528
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x178], rax
 
G_M000_IG41:                ;; offset=0x0838
       vmovdqu  xmm0, xmmword ptr [rbp-0x158]
       vmovdqu  xmmword ptr [rbp-0x300], xmm0
 
G_M000_IG42:                ;; offset=0x0848
       mov      rax, gword ptr [rbp-0x168]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp-0x16C]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0xC0]
       mov      qword ptr [rsp+0x38], rax
       lea      r8, [rbp-0x300]
       mov      rdx, gword ptr [rbp-0x148]
       mov      rcx, gword ptr [rbp-0x140]
       mov      r9, bword ptr [rbp-0x160]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG45
       mov      rcx, 0x7FFA0294452C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG69
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x318], rax
 
G_M000_IG43:                ;; offset=0x08DC
       vmovdqu  xmm0, xmmword ptr [rbp-0xC0]
       vmovdqu  xmmword ptr [rbp-0x310], xmm0
 
G_M000_IG44:                ;; offset=0x08EC
       mov      r8, bword ptr [rbp-0x318]
       lea      r9, [rbp-0x310]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0x8C], 1
       jmp      G_M000_IG78
 
G_M000_IG45:                ;; offset=0x0917
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0xC8], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x180], rax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rbp-0x184], eax
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x31C], eax
       mov      r9d, dword ptr [rbp-0x31C]
       lea      rdx, [rbp-0x88]
       mov      r8d, dword ptr [rbp-0x184]
       mov      rcx, bword ptr [rbp-0x180]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:Slice(int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       lea      rdx, [rbp-0xD8]
       lea      rcx, [rbp-0x88]
       call     [System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_Span():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG54
       mov      rcx, 0x7FFA0286E738
       call     [CORINFO_HELP_GET_GCSTATIC_BASE]
       mov      rax, 0x242EF401C60
       mov      rax, gword ptr [rax]
       cmp      rax, gword ptr [rbp-0xA8]
       jne      G_M000_IG53
       mov      rdx, gword ptr [rbp-0xC8]
       mov      rcx, 0x7FFA025ACB28
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xE0], rax
       cmp      gword ptr [rbp-0xE0], 0
       je       G_M000_IG52
       cmp      dword ptr [rbp-0xD0], 2
       jg       G_M000_IG51
 
G_M000_IG46:                ;; offset=0x0A1E
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rbp-0x330], xmm0
 
G_M000_IG47:                ;; offset=0x0A2E
       lea      rdx, [rbp-0x330]
       lea      rcx, [rbp-0x1D8]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, gword ptr [rbp-0xE0]
       mov      gword ptr [rsp+0x28], rax
 
G_M000_IG48:                ;; offset=0x0A55
       vmovdqu  xmm0, xmmword ptr [rbp-0x1D8]
       vmovdqu  xmmword ptr [rbp-0x340], xmm0
 
G_M000_IG49:                ;; offset=0x0A65
       lea      rax, [rbp-0x340]
       mov      qword ptr [rsp+0x30], rax
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp+0x18]
       mov      r9, gword ptr [rbp+0x28]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSplitUnpack(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool]
       test     eax, eax
       je       SHORT G_M000_IG50
       mov      rcx, 0x7FFA02944530
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x8C], 1
       jmp      G_M000_IG78
 
G_M000_IG50:                ;; offset=0x0AA9
       mov      rcx, 0x7FFA02944534
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG54
 
G_M000_IG51:                ;; offset=0x0ABA
       mov      rcx, 0x7FFA02944538
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG54
 
G_M000_IG52:                ;; offset=0x0ACB
       mov      rcx, 0x7FFA0294453C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0ADC
       mov      rcx, 0x7FFA02944540
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG54:                ;; offset=0x0AEB
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_AccumulatesDictionary():bool:this]
       test     eax, eax
       je       G_M000_IG62
       mov      eax, dword ptr [rbp-0xD0]
       mov      dword ptr [rbp-0xF4], eax
       cmp      dword ptr [rbp-0xF4], 1
       je       SHORT G_M000_IG56
       cmp      dword ptr [rbp-0xF4], 2
       jne      G_M000_IG61
 
G_M000_IG55:                ;; offset=0x0B21
       mov      rcx, 0x7FFA02944544
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG56:                ;; offset=0x0B30
       mov      rcx, 0x7FFA0286E738
       call     [CORINFO_HELP_GET_GCSTATIC_BASE]
       mov      rax, 0x242EF401C30
       mov      rax, gword ptr [rax]
       cmp      rax, gword ptr [rbp-0xA8]
       jne      G_M000_IG60
       mov      rdx, gword ptr [rbp-0xC8]
       mov      rcx, 0x7FFA02607AA0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xE8], rax
       cmp      gword ptr [rbp-0xE8], 0
       je       G_M000_IG59
       cmp      dword ptr [rbp-0xD0], 0
       jbe      G_M000_IG69
       mov      rcx, bword ptr [rbp-0xD8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x348], rax
       mov      rdx, gword ptr [rbp-0x348]
       mov      rcx, gword ptr [rbp-0xE8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG58
       cmp      dword ptr [rbp-0xD0], 0
       jbe      G_M000_IG69
       mov      rcx, bword ptr [rbp-0xD8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x350], rax
       mov      rdx, gword ptr [rbp-0x350]
       mov      rcx, 0x7FFA025ACB28
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x358], rax
       mov      rax, gword ptr [rbp-0x358]
       mov      gword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [rbp+0x30]
       mov      rax, gword ptr [rbp-0xE8]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryAccumulation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.PyDict,Lokad.Lython.Runtime.Text.PyString):bool]
       test     eax, eax
       je       SHORT G_M000_IG57
       mov      rcx, 0x7FFA02944548
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x8C], 1
       jmp      G_M000_IG78
 
G_M000_IG57:                ;; offset=0x0C54
       mov      rcx, 0x7FFA0294454C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG62
 
G_M000_IG58:                ;; offset=0x0C65
       mov      rcx, 0x7FFA02944550
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG62
 
G_M000_IG59:                ;; offset=0x0C76
       mov      rcx, 0x7FFA02944554
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG62
 
G_M000_IG60:                ;; offset=0x0C87
       mov      rcx, 0x7FFA02944558
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x0C98
       mov      rcx, 0x7FFA0294455C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG62:                ;; offset=0x0CA7
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rbp-0x198], xmm0
 
G_M000_IG63:                ;; offset=0x0CB7
       mov      rax, gword ptr [rbp-0xA8]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rax, gword ptr [rbp-0xC8]
       mov      gword ptr [rbp-0x1A8], rax
 
G_M000_IG64:                ;; offset=0x0CD3
       vmovdqu  xmm0, xmmword ptr [rbp-0x198]
       vmovdqu  xmmword ptr [rbp-0x1B8], xmm0
 
G_M000_IG65:                ;; offset=0x0CE3
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x1C8], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG66
       mov      rcx, 0x7FFA02944560
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x1C8], rax
 
G_M000_IG66:                ;; offset=0x0D22
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B8]
       vmovdqu  xmmword ptr [rbp-0x368], xmm0
 
G_M000_IG67:                ;; offset=0x0D32
       mov      rax, gword ptr [rbp-0x1C8]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x368]
       mov      rdx, gword ptr [rbp-0x1A8]
       mov      rcx, gword ptr [rbp-0x1A0]
       mov      r9, gword ptr [rbp-0x1C0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG68
       mov      rcx, 0x7FFA02944564
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x8C], eax
       jmp      G_M000_IG78
 
G_M000_IG68:                ;; offset=0x0D8C
       mov      rcx, 0x7FFA02944568
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG69
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x370], rax
       mov      r8, bword ptr [rbp-0x370]
       mov      rdx, gword ptr [rbp+0x20]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       mov      dword ptr [rbp-0x8C], 1
       jmp      G_M000_IG78
 
G_M000_IG69:                ;; offset=0x0DF3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG70:                ;; offset=0x0DF9
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x378], rax
       mov      rdx, gword ptr [rbp-0x378]
       lea      rcx, [rbp-0x128]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG71:                ;; offset=0x0E28
       vmovdqu  xmm0, xmmword ptr [rbp-0x128]
       vmovdqu  xmmword ptr [rbp-0x388], xmm0
 
G_M000_IG72:                ;; offset=0x0E38
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       cmp      gword ptr [rbp+0x20], 0
       setne    al
       movzx    rax, al
       mov      dword ptr [rsp+0x28], eax
       lea      rax, [rbp-0x108]
       mov      qword ptr [rsp+0x30], rax
       lea      r8, [rbp-0x388]
       mov      rdx, gword ptr [rbp+0x38]
       mov      rcx, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG73
       xor      eax, eax
       mov      dword ptr [rbp-0x8C], eax
       jmp      G_M000_IG78
 
G_M000_IG73:                ;; offset=0x0E86
       lea      rcx, [rbp-0x108]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x248], rax
       mov      rcx, gword ptr [rbp-0x248]
       mov      rdx, 0x7FFA02944570
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x248]
       mov      gword ptr [rbp-0x390], rax
       mov      rdx, gword ptr [rbp-0x390]
       mov      rcx, 0x7FFA024EE760
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x110], rax
       cmp      gword ptr [rbp-0x110], 0
       je       SHORT G_M000_IG75
       mov      rcx, 0x7FFA02944678
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, gword ptr [rbp-0x110]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0x8C], 1
       jmp      SHORT G_M000_IG78
 
G_M000_IG74:                ;; offset=0x0F28
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG75:                ;; offset=0x0F2E
       mov      rcx, 0x7FFA0294467C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG74
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x3A8], rax
 
G_M000_IG76:                ;; offset=0x0F6A
       vmovdqu  xmm0, xmmword ptr [rbp-0x108]
       vmovdqu  xmmword ptr [rbp-0x3A0], xmm0
 
G_M000_IG77:                ;; offset=0x0F7A
       mov      r8, bword ptr [rbp-0x3A8]
       lea      r9, [rbp-0x3A0]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0x8C], 1
 
G_M000_IG78:                ;; offset=0x0FA0
       mov      rcx, 0x7FFA02944680
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x8C]
 
G_M000_IG79:                ;; offset=0x0FB5
       add      rsp, 0x410
       pop      rbp
       ret      
 
G_M000_IG80:                ;; offset=0x0FBE
       sub      rsp, 104
 
G_M000_IG81:                ;; offset=0x0FC2
       mov      gword ptr [rbp-0x230], rcx
       mov      rax, gword ptr [rbp-0x78]
       mov      gword ptr [rbp-0x238], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x2B8], rax
       mov      rdx, gword ptr [rbp-0x2B8]
       mov      rcx, gword ptr [rbp-0x238]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AbortPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG82:                ;; offset=0x100C
       sub      rsp, 104
 
G_M000_IG83:                ;; offset=0x1010
       mov      gword ptr [rbp-0x240], rcx
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2D8], rax
       mov      rdx, gword ptr [rbp-0x2D8]
       lea      r8, [rbp-0x98]
       mov      rcx, gword ptr [rbp-0x240]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG85
 
G_M000_IG84:                ;; offset=0x1060
       mov      rcx, gword ptr [rbp-0x98]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG85:                ;; offset=0x106D
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG86:                ;; offset=0x1073
       sub      rsp, 104
 
G_M000_IG87:                ;; offset=0x1077
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG88
       mov      rcx, 0x7FFA02944500
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG88:                ;; offset=0x1098
       mov      rcx, 0x7FFA02944504
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG89:                ;; offset=0x10A8
       add      rsp, 104
       ret      
 
G_M000_IG90:                ;; offset=0x10AD
       sub      rsp, 104
 
G_M000_IG91:                ;; offset=0x10B1
       mov      gword ptr [rbp-0x1E0], rcx
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG92:                ;; offset=0x10D5
       sub      rsp, 104
 
G_M000_IG93:                ;; offset=0x10D9
       mov      gword ptr [rbp-0x130], rcx
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 4349

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 704
       lea      rbp, [rsp+0x2C0]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -624
 
G_M000_IG35:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG35
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0045
       cmp      gword ptr [rbp+0x28], 0
       jne      G_M000_IG15
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       jne      SHORT G_M000_IG06
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG03:                ;; offset=0x0075
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1C0], xmm0
 
G_M000_IG04:                ;; offset=0x0081
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x1C0]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x19C], eax
       jmp      G_M000_IG12
 
G_M000_IG05:                ;; offset=0x00B7
       mov      rcx, 0x7FFA02944B68
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG15
 
G_M000_IG06:                ;; offset=0x00CB
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x198], eax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x198]
       jne      SHORT G_M000_IG11
       mov      rcx, 0x7FFA02944B6C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG07:                ;; offset=0x0108
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG08:                ;; offset=0x0114
       lea      rdx, [rbp-0x1D0]
       lea      rcx, [rbp-0x1B0]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
 
G_M000_IG09:                ;; offset=0x0128
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
 
G_M000_IG10:                ;; offset=0x0138
       lea      rdx, [rbp-0x1E0]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, bword ptr [rbp+0x60]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x19C], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x0159
       mov      rcx, 0x7FFA02944B70
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x19C], eax
 
G_M000_IG12:                ;; offset=0x0170
       cmp      dword ptr [rbp-0x19C], 0
       je       SHORT G_M000_IG14
       mov      rcx, 0x7FFA02944B74
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x58]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x68]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG13:                ;; offset=0x0198
       vzeroupper 
       add      rsp, 704
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x01A4
       mov      rcx, 0x7FFA02944B78
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG15:                ;; offset=0x01B3
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
       vmovdqu  ymmword ptr [rbp-0xE0], ymm0
       vmovdqu  ymmword ptr [rbp-0xC0], ymm0
       vmovdqu  ymmword ptr [rbp-0xA0], ymm0
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  ymmword ptr [rbp-0x40], ymm0
       vmovdqu  ymmword ptr [rbp-0x20], ymm0
       lea      rdx, [rbp-0x100]
       lea      rcx, [rbp-0x110]
       mov      r8d, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       mov      r9d, dword ptr [rbp-0x1E4]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x110]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       je       G_M000_IG19
       xor      eax, eax
       mov      dword ptr [rbp-0x114], eax
       cmp      gword ptr [rbp+0x28], 0
       je       SHORT G_M000_IG16
       mov      rcx, 0x7FFA02944B7C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x114]
       mov      dword ptr [rbp-0x194], eax
       mov      eax, dword ptr [rbp-0x114]
       inc      eax
       mov      dword ptr [rbp-0x114], eax
       mov      eax, dword ptr [rbp-0x108]
       cmp      dword ptr [rbp-0x194], eax
       jae      G_M000_IG34
       mov      eax, dword ptr [rbp-0x194]
       shl      rax, 4
       mov      rcx, rax
       add      rcx, bword ptr [rbp-0x110]
       mov      rdx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG16:                ;; offset=0x02B2
       lea      rdx, [rbp-0x190]
       lea      rcx, [rbp-0x110]
       mov      r8d, dword ptr [rbp-0x114]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG17:                ;; offset=0x02CD
       vmovdqu  xmm0, xmmword ptr [rbp-0x190]
       vmovdqu  xmmword ptr [rbp-0x1F8], xmm0
 
G_M000_IG18:                ;; offset=0x02DD
       lea      rdx, [rbp-0x1F8]
       mov      rcx, bword ptr [rbp+0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG25
 
G_M000_IG19:                ;; offset=0x02F3
       mov      rcx, 0x7FFA02944B80
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x1FC], eax
       mov      r9d, dword ptr [rbp-0x1FC]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x170]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG20:                ;; offset=0x033C
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0x210], xmm0
 
G_M000_IG21:                ;; offset=0x034C
       vmovdqu  xmm0, xmmword ptr [rbp-0x128]
       vmovdqu  xmmword ptr [rbp-0x220], xmm0
 
G_M000_IG22:                ;; offset=0x035C
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG23:                ;; offset=0x0381
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x230], xmm0
 
G_M000_IG24:                ;; offset=0x038D
       lea      rcx, [rbp-0x210]
       lea      rdx, [rbp-0x220]
       lea      rax, [rbp-0x230]
       mov      qword ptr [rsp+0x40], rax
       mov      r9, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG25:                ;; offset=0x03B5
       mov      rcx, 0x7FFA02944B84
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG26:                ;; offset=0x03C4
       vmovdqu  xmm0, xmmword ptr [rbp-0x110]
       vmovdqu  xmmword ptr [rbp-0x180], xmm0
 
G_M000_IG27:                ;; offset=0x03D4
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
 
G_M000_IG28:                ;; offset=0x03E0
       vmovdqu  xmm0, xmmword ptr [rbp-0x180]
       vmovdqu  xmmword ptr [rbp-0x240], xmm0
 
G_M000_IG29:                ;; offset=0x03F0
       vmovdqu  ymm0, ymmword ptr [rbp-0x160]
       vmovdqu  ymmword ptr [rbp-0x260], ymm0
 
G_M000_IG30:                ;; offset=0x0400
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG31:                ;; offset=0x040C
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x270], xmm0
 
G_M000_IG32:                ;; offset=0x0418
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rax
       lea      rax, [rbp-0x140]
       mov      qword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0x240]
       lea      r8, [rbp-0x260]
       lea      rax, [rbp-0x270]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp+0x38]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG33:                ;; offset=0x0468
       vzeroupper 
       add      rsp, 704
       pop      rbp
       ret      
 
G_M000_IG34:                ;; offset=0x0474
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1146

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 17960
; 29 inlinees with PGO data; 137 single block inlinees; 3 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 408
       lea      rbp, [rsp+0x1D0]
       xor      eax, eax
       mov      qword ptr [rbp-0x148], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x140], xmm4
       mov      rax, -240
 
G_M000_IG157:                ;; offset=0x003A
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG157
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x28], r9
       mov      rbx, r8
       mov      rsi, gword ptr [rbp+0x38]
 
G_M000_IG02:                ;; offset=0x0065
       xor      rdx, rdx
       mov      rdi, bword ptr [rbp+0x40]
       mov      gword ptr [rdi], rdx
       test     rsi, rsi
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0073
       mov      rdx, 0x7FFA02847368
       cmp      qword ptr [rsi], rdx
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0082
       mov      gword ptr [rbp-0x150], rsi
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x008B
       xor      rdx, rdx
       mov      gword ptr [rbp-0x150], rdx
 
G_M000_IG06:                ;; offset=0x0094
       cmp      byte  ptr [r9+0x30], 0
       jne      G_M000_IG101
 
G_M000_IG07:                ;; offset=0x009F
       xor      r14, r14
 
G_M000_IG08:                ;; offset=0x00A2
       test     rsi, rsi
       je       SHORT G_M000_IG14
 
G_M000_IG09:                ;; offset=0x00A7
       mov      rdx, 0x7FFA0286D848
       cmp      qword ptr [rsi], rdx
       jne      SHORT G_M000_IG14
 
G_M000_IG10:                ;; offset=0x00B6
       mov      rdx, gword ptr [rsi+0x10]
       test     rdx, rdx
       je       SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x00BF
       mov      rax, 0x7FFA02847368
       xor      r8, r8
       cmp      qword ptr [rdx], rax
       cmovne   rdx, r8
 
G_M000_IG12:                ;; offset=0x00D3
       test     rdx, rdx
       je       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x00D8
       mov      gword ptr [rbp-0x150], rdx
       mov      r14, gword ptr [rsi+0x08]
 
G_M000_IG14:                ;; offset=0x00E3
       cmp      gword ptr [rbp-0x150], 0
       je       G_M000_IG102
 
G_M000_IG15:                ;; offset=0x00F1
       test     rbx, rbx
       je       G_M000_IG105
       mov      rdx, gword ptr [rbp-0x150]
       mov      rdx, gword ptr [rdx+0x40]
       cmp      byte  ptr [rdx+0xDF], 0
       je       G_M000_IG103
       mov      rax, gword ptr [rbp-0x150]
       mov      rax, gword ptr [rax+0x28]
       cmp      byte  ptr [rax+0xFA], 0
       jne      G_M000_IG103
       cmp      byte  ptr [rax+0xFB], 0
       jne      G_M000_IG103
       cmp      byte  ptr [rax+0xFC], 0
       jne      G_M000_IG103
       cmp      gword ptr [rax+0xC0], 0
       jne      G_M000_IG103
       cmp      dword ptr [rdx+0xD4], 16
       jg       G_M000_IG103
       mov      r9, gword ptr [rbp+0x28]
       cmp      byte  ptr [r9+0x34], 0
       je       G_M000_IG106
       mov      edx, dword ptr [r9+0x28]
       mov      rax, gword ptr [rbp-0x150]
       mov      rax, gword ptr [rax+0x08]
       cmp      byte  ptr [rax+0x54], 0
       je       G_M000_IG100
 
G_M000_IG16:                ;; offset=0x0187
       mov      eax, dword ptr [rax+0x3C]
       test     r14, r14
       setne    r8b
       movzx    r8, r8b
       sub      eax, r8d
       cmp      eax, edx
       sete     sil
       movzx    rsi, sil
 
G_M000_IG17:                ;; offset=0x01A2
       test     esi, esi
       jne      SHORT G_M000_IG21
 
G_M000_IG18:                ;; offset=0x01A6
       mov      rdx, gword ptr [rbp-0x150]
       mov      rax, gword ptr [rdx+0x08]
       mov      rdx, gword ptr [rax+0x08]
       cmp      dword ptr [rdx+0x08], 16
       jg       G_M000_IG103
       cmp      dword ptr [rax+0x4C], 0
       jge      G_M000_IG103
       cmp      dword ptr [rax+0x50], 0
       jge      G_M000_IG103
       mov      rdx, gword ptr [rbp-0x150]
       mov      rdx, gword ptr [rdx+0x18]
       test     rdx, rdx
       je       SHORT G_M000_IG20
       mov      rax, rdx
       mov      r8, 0x7FFA0287EAC0
       cmp      qword ptr [rax], r8
       jne      G_M000_IG107
 
G_M000_IG19:                ;; offset=0x01F9
       test     rax, rax
       je       G_M000_IG103
 
G_M000_IG20:                ;; offset=0x0202
       mov      rcx, gword ptr [rbp-0x150]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       test     rax, rax
       jne      G_M000_IG108
 
G_M000_IG21:                ;; offset=0x0218
       mov      rcx, bword ptr [rbp+0x10]
       xor      edx, edx
       mov      dword ptr [rbp-0x3C], edx
 
G_M000_IG22:                ;; offset=0x0221
       mov      r9, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [r9+0x18]
       mov      r15, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [r15+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x3C], 1
       mov      r9, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [r9+0x18]
       mov      rcx, gword ptr [r15+0x98]
       mov      rax, gword ptr [rcx+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG64
       mov      rax, gword ptr [rcx+0x180]
       test     rax, rax
       jne      G_M000_IG63
 
G_M000_IG23:                ;; offset=0x0274
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x20]
       mov      r9, gword ptr [rbp+0x28]
       cmp      byte  ptr [r9+0x30], 0
       setne    al
       movzx    rax, al
       mov      r8d, dword ptr [rbp+0x30]
       lea      r13d, [r8+rax+0x01]
       mov      r12d, dword ptr [r9+0x28]
       mov      rdx, gword ptr [rdx]
       test     rdx, rdx
       je       G_M000_IG65
       mov      r8d, dword ptr [rbp+0x30]
       mov      eax, r13d
       mov      r10d, r12d
       add      rax, r10
       mov      r10d, dword ptr [rdx+0x08]
       cmp      rax, r10
       ja       G_M000_IG66
       mov      rax, rdx
 
G_M000_IG24:                ;; offset=0x02C1
       xor      r10, r10
       xor      r11d, r11d
       test     rax, rax
       je       SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x02CC
       mov      r10, qword ptr [rax]
       test     dword ptr [r10], 0xFFFFFFFF80000000
       je       G_M000_IG68
       lea      r10, bword ptr [rax+0x10]
       mov      r11d, dword ptr [rax+0x08]
 
G_M000_IG26:                ;; offset=0x02E4
       and      r13d, 0x7FFFFFFF
       mov      edx, r13d
       mov      eax, r12d
       add      rax, rdx
       mov      r11d, r11d
       cmp      rax, r11
       ja       G_M000_IG66
       shl      rdx, 4
       add      r10, rdx
       mov      bword ptr [rbp-0x168], r10
       mov      dword ptr [rbp-0xB4], r12d
       mov      r10, bword ptr [rbp-0x168]
       mov      r11d, dword ptr [rbp-0xB4]
 
G_M000_IG27:                ;; offset=0x0323
       mov      rcx, bword ptr [rbp+0x10]
       mov      r13d, dword ptr [rcx+0x60]
       mov      r9, gword ptr [rbp+0x28]
       cmp      dword ptr [r9+0x2C], 0
       jne      G_M000_IG69
 
G_M000_IG28:                ;; offset=0x033A
       mov      r9, gword ptr [rbp+0x28]
       xor      rdx, rdx
       xor      r12d, r12d
 
G_M000_IG29:                ;; offset=0x0343
       mov      rax, gword ptr [r9+0x18]
       cmp      byte  ptr [r9+0x31], 0
       jne      G_M000_IG74
       cmp      byte  ptr [rcx+0x1C], 0
       jne      G_M000_IG73
       xor      edi, edi
 
G_M000_IG30:                ;; offset=0x035E
       mov      bword ptr [rbp-0x148], r10
       mov      dword ptr [rbp-0x140], r11d
       mov      gword ptr [rsp+0x20], r15
       mov      gword ptr [rsp+0x28], rax
       mov      dword ptr [rsp+0x30], edi
       mov      dword ptr [rsp+0x38], esi
       mov      bword ptr [rbp-0x128], rdx
       mov      dword ptr [rbp-0x120], r12d
       lea      rdx, [rbp-0x48]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x58]
       mov      qword ptr [rsp+0x50], rdx
       lea      rdx, [rbp-0x60]
       mov      qword ptr [rsp+0x58], rdx
       lea      r8, [rbp-0x148]
       lea      rdx, [rbp-0x128]
       mov      qword ptr [rsp+0x40], rdx
       mov      rcx, gword ptr [rbp-0x150]
       mov      r9, r14
       mov      rdx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       cmp      byte  ptr [rbp-0x48], 0
       jne      SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x03D4
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x60], r13d
 
G_M000_IG32:                ;; offset=0x03DC
       cmp      gword ptr [rbp-0x60], 0
       jne      G_M000_IG75
       mov      rdx, gword ptr [r15+0x98]
       mov      rax, qword ptr [rdx+0x160]
       test     rax, rax
       jle      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x03FA
       dec      rax
       mov      qword ptr [rdx+0x160], rax
 
G_M000_IG34:                ;; offset=0x0404
       xor      edx, edx
       mov      dword ptr [rbp-0x3C], edx
       cmp      byte  ptr [rbp-0x48], 0
       jne      G_M000_IG77
 
G_M000_IG35:                ;; offset=0x0413
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx]
       mov      rdx, gword ptr [rdx+0x88]
       mov      eax, dword ptr [rcx+0x18]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG96
       shl      rax, 5
       lea      r12, bword ptr [rdx+rax+0x10]
       mov      rsi, gword ptr [rbp-0x58]
       mov      rdi, qword ptr [rbp-0x50]
       cmp      dword ptr [r12+0x18], 0
       jge      G_M000_IG54
 
G_M000_IG36:                ;; offset=0x044A
       mov      gword ptr [rbp-0xD8], rsi
       mov      qword ptr [rbp-0xD0], rdi
       mov      edx, dword ptr [r12+0x18]
       not      edx
       mov      eax, edx
       cmp      eax, dword ptr [rcx+0x60]
       jge      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x0466
       lea      rax, bword ptr [rcx+0x20]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0x10]
 
G_M000_IG38:                ;; offset=0x0477
       cmp      gword ptr [rcx+0x40], 0
       jne      G_M000_IG80
       mov      rax, gword ptr [rcx+0x38]
       mov      rdx, gword ptr [rax+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG80
       mov      rax, gword ptr [rax+0x180]
       test     rax, rax
       jne      G_M000_IG79
 
G_M000_IG39:                ;; offset=0x04A8
       lea      rsi, bword ptr [rcx+0x20]
       mov      eax, dword ptr [r12+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x04B6
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG83
 
G_M000_IG41:                ;; offset=0x04CA
       mov      eax, dword ptr [r12+0x14]
 
G_M000_IG42:                ;; offset=0x04CF
       mov      rdx, gword ptr [rsi]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG96
       mov      r8d, eax
       shl      r8, 4
       lea      rdx, bword ptr [rdx+r8+0x10]
       xor      r8, r8
       mov      gword ptr [rdx], r8
 
G_M000_IG43:                ;; offset=0x04ED
       mov      qword ptr [rdx+0x08], r8
       mov      dword ptr [rsi+0x40], eax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      rax, gword ptr [rax+0x88]
       mov      edx, dword ptr [rcx+0x18]
       inc      edx
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG96
       shl      rdx, 5
       lea      rdx, bword ptr [rax+rdx+0x10]
       mov      r12d, dword ptr [rdx+0x1C]
       cmp      r12d, 25
       jne      G_M000_IG88
 
G_M000_IG44:                ;; offset=0x0527
       mov      r12, gword ptr [rcx]
       mov      rdi, gword ptr [rcx+0x08]
       mov      esi, dword ptr [rdx+0x08]
 
G_M000_IG45:                ;; offset=0x0531
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
 
G_M000_IG46:                ;; offset=0x0541
       mov      rax, gword ptr [r12+0x58]
       mov      rdx, 0x7FFA0226C7D0
       cmp      qword ptr [rax], rdx
       jne      G_M000_IG85
       cmp      dword ptr [rax+0x08], esi
       jbe      G_M000_IG84
       mov      edx, esi
       mov      r14, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG47:                ;; offset=0x0569
       cmp      word  ptr [r14+0x0C], 60
       setne    r13b
       movzx    r13, r13b
       mov      rax, gword ptr [rbx+0x88]
       test     rax, rax
       setne    al
       movzx    rax, al
       test     eax, r13d
       jne      G_M000_IG86
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG96
       mov      eax, esi
       shl      rax, 4
       mov      rax, gword ptr [rdi+rax+0x10]
       test     rax, rax
       je       SHORT G_M000_IG50
 
G_M000_IG48:                ;; offset=0x05A9
       mov      rdx, 0x7FFA02827DA0
       cmp      qword ptr [rax], rdx
       jne      SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x05B8
       mov      rsi, rax
       lea      rcx, [rbp-0xE8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FFA0286CD80
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      SHORT G_M000_IG52
 
G_M000_IG50:                ;; offset=0x05E9
       mov      edx, esi
       shl      rdx, 4
       lea      rax, bword ptr [rdi+rdx+0x10]
       mov      bword ptr [rbp-0x170], rax
       mov      rdx, gword ptr [rbp-0xE8]
       mov      rcx, rax
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0xE0]
       mov      rax, bword ptr [rbp-0x170]
       mov      qword ptr [rax+0x08], rcx
       test     r13d, r13d
       je       SHORT G_M000_IG52
 
G_M000_IG51:                ;; offset=0x0621
       cmp      byte  ptr [r12+0xDD], 0
       jne      G_M000_IG87
       cmp      byte  ptr [rbx+0xFF], 0
       jne      G_M000_IG87
 
G_M000_IG52:                ;; offset=0x063D
       mov      rbx, bword ptr [rbp+0x10]
       inc      dword ptr [rbx+0x18]
 
G_M000_IG53:                ;; offset=0x0644
       mov      eax, 1
       jmp      G_M000_IG99
 
G_M000_IG54:                ;; offset=0x064E
       lea      rbx, bword ptr [rcx+0x20]
       mov      eax, dword ptr [r12+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG56
 
G_M000_IG55:                ;; offset=0x065C
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG78
 
G_M000_IG56:                ;; offset=0x0670
       mov      r14d, dword ptr [r12+0x14]
 
G_M000_IG57:                ;; offset=0x0675
       mov      r13d, dword ptr [r12+0x18]
       test     r13d, r13d
       jge      SHORT G_M000_IG62
 
G_M000_IG58:                ;; offset=0x067F
       not      r13d
 
G_M000_IG59:                ;; offset=0x0682
       cmp      r13d, dword ptr [rbx+0x40]
       jge      SHORT G_M000_IG61
 
G_M000_IG60:                ;; offset=0x0688
       mov      rcx, rbx
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG61:                ;; offset=0x0694
       mov      rdx, gword ptr [rbx]
       cmp      r14d, dword ptr [rdx+0x08]
       jae      G_M000_IG96
       mov      eax, r14d
       shl      rax, 4
       lea      r14, bword ptr [rdx+rax+0x10]
       mov      rcx, r14
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r14+0x08], rdi
       mov      dword ptr [rbx+0x40], r13d
       mov      rbx, bword ptr [rbp+0x10]
       jmp      G_M000_IG53
 
G_M000_IG62:                ;; offset=0x06C9
       jmp      SHORT G_M000_IG59
 
G_M000_IG63:                ;; offset=0x06CB
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG23
 
G_M000_IG64:                ;; offset=0x06DD
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG23
 
G_M000_IG65:                ;; offset=0x06E8
       mov      r8d, dword ptr [rbp+0x30]
       mov      eax, r13d
       or       eax, r12d
       je       SHORT G_M000_IG67
 
G_M000_IG66:                ;; offset=0x06F4
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG67:                ;; offset=0x06FB
       xor      rax, rax
       xor      r13d, r13d
       xor      r12d, r12d
       jmp      G_M000_IG24
 
G_M000_IG68:                ;; offset=0x0708
       lea      rdx, [rbp-0xC8]
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r10, bword ptr [rbp-0xC8]
       mov      rcx, r10
       mov      r11d, dword ptr [rbp-0xC0]
       mov      eax, r11d
       mov      r10, rcx
       mov      r11d, eax
       mov      r8d, dword ptr [rbp+0x30]
       jmp      G_M000_IG26
 
G_M000_IG69:                ;; offset=0x073F
       cmp      dword ptr [r9+0x28], 16
       jg       G_M000_IG28
       mov      bword ptr [rbp-0x168], r10
       mov      dword ptr [rbp-0xB4], r11d
       add      rcx, 32
       mov      edx, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:CanRetireWithoutCleanup(int):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG70
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8d, dword ptr [rbp+0x30]
       mov      r10, bword ptr [rbp-0x168]
       mov      r11d, dword ptr [rbp-0xB4]
       jmp      G_M000_IG28
 
G_M000_IG70:                ;; offset=0x0784
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x20]
       mov      r9, gword ptr [rbp+0x28]
       mov      edx, dword ptr [r9+0x2C]
       test     rax, rax
       jne      SHORT G_M000_IG71
       mov      r8d, dword ptr [rbp+0x30]
       or       edx, r8d
       jne      G_M000_IG66
       xor      rdx, rdx
       xor      r12d, r12d
       jmp      SHORT G_M000_IG72
 
G_M000_IG71:                ;; offset=0x07AD
       mov      r8d, dword ptr [rbp+0x30]
       mov      r10d, r8d
       mov      r11d, edx
       add      r10, r11
       mov      r11d, dword ptr [rax+0x08]
       cmp      r10, r11
       ja       G_M000_IG66
       mov      r10d, r8d
       shl      r10, 4
       lea      rax, bword ptr [rax+r10+0x10]
       mov      r12d, edx
       mov      rdx, rax
 
G_M000_IG72:                ;; offset=0x07D9
       lea      rax, bword ptr [rcx+0x20]
       lea      r10d, [r8+r12]
       cmp      r13d, r10d
       cmovge   r10d, r13d
       mov      dword ptr [rax+0x40], r10d
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8d, dword ptr [rbp+0x30]
       mov      r9, gword ptr [rbp+0x28]
       mov      r10, bword ptr [rbp-0x168]
       mov      r11d, dword ptr [rbp-0xB4]
       jmp      G_M000_IG29
 
G_M000_IG73:                ;; offset=0x080B
       movzx    rdi, byte  ptr [r9+0x32]
       jmp      G_M000_IG30
 
G_M000_IG74:                ;; offset=0x0815
       mov      edi, 1
       jmp      G_M000_IG30
 
G_M000_IG75:                ;; offset=0x081F
       mov      rcx, gword ptr [rbp-0x60]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterExecutableSlots():this]
       mov      rdx, gword ptr [rbp-0x60]
       mov      r9, gword ptr [rbp+0x28]
       mov      rcx, gword ptr [r9+0x18]
       mov      r8, gword ptr [rbp-0x150]
       mov      r8, gword ptr [r8+0x28]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      rcx, gword ptr [r8+0x98]
       mov      rcx, gword ptr [rcx+0x88]
       mov      gword ptr [rsp+0x30], rcx
       mov      rcx, rbx
       mov      r8, r9
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AttachPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.LythonSourceSpan,int,Lokad.Lython.Runtime.MemoryGovernor):this]
       nop      
 
G_M000_IG76:                ;; offset=0x0871
       mov      rdx, gword ptr [rbp-0x60]
       mov      rcx, bword ptr [rbp+0x40]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      dword ptr [rbp-0x3C], ecx
       mov      rbx, bword ptr [rbp+0x10]
       jmp      G_M000_IG53
 
G_M000_IG77:                ;; offset=0x088C
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, r15
       mov      r8d, dword ptr [rbp+0x30]
       mov      r9d, r12d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteUnpackedCallReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,int)]
       mov      rbx, bword ptr [rbp+0x10]
       jmp      G_M000_IG53
 
G_M000_IG78:                ;; offset=0x08A9
       mov      rcx, r12
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       jmp      G_M000_IG57
 
G_M000_IG79:                ;; offset=0x08BA
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG39
 
G_M000_IG80:                ;; offset=0x08CC
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, r12
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, r12
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
 
G_M000_IG81:                ;; offset=0x08E7
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rbp-0x138], xmm0
 
G_M000_IG82:                ;; offset=0x08F7
       mov      edx, esi
       mov      rcx, rbx
       lea      r9, [rbp-0x138]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rbx, bword ptr [rbp+0x10]
       jmp      G_M000_IG53
 
G_M000_IG83:                ;; offset=0x0912
       mov      rcx, r12
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG42
 
G_M000_IG84:                ;; offset=0x0920
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG85:                ;; offset=0x0927
       mov      rcx, rax
       mov      edx, esi
       mov      r11, 0x7FFA020D1B00
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r14, rax
       jmp      G_M000_IG47
 
G_M000_IG86:                ;; offset=0x0941
       lea      rcx, [rbp-0xE8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FFA0286CD80
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       mov      rdx, r14
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreGlobalNamespaceName(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,System.Object)]
       jmp      G_M000_IG52
 
G_M000_IG87:                ;; offset=0x0975
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.ExecutionFrame:get_Variables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rbx, rax
       mov      ecx, esi
       shl      rcx, 4
       lea      rcx, bword ptr [rdi+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FFA0286CD80
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       cmp      byte  ptr [rbx], bl
       mov      rcx, rbx
       mov      rdx, r14
       mov      r9d, 1
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryInsert(System.__Canon,System.__Canon,byte):bool:this]
       jmp      G_M000_IG52
 
G_M000_IG88:                ;; offset=0x09C1
       cmp      r12d, 71
       jne      SHORT G_M000_IG94
 
G_M000_IG89:                ;; offset=0x09C7
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       jne      SHORT G_M000_IG90
       xor      r9, r9
       xor      r8d, r8d
       jmp      SHORT G_M000_IG91
 
G_M000_IG90:                ;; offset=0x09D8
       lea      r9, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
 
G_M000_IG91:                ;; offset=0x09E0
       mov      bword ptr [rbp-0x128], r9
       mov      dword ptr [rbp-0x120], r8d
 
G_M000_IG92:                ;; offset=0x09EE
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rbp-0x138], xmm0
 
G_M000_IG93:                ;; offset=0x09FE
       lea      rcx, [rbp-0x128]
       lea      r8, [rbp-0x138]
       mov      rbx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG52
 
G_M000_IG94:                ;; offset=0x0A1F
       cmp      r12d, 30
       je       SHORT G_M000_IG97
 
G_M000_IG95:                ;; offset=0x0A25
       mov      rcx, 0x7FFA022FA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x242CA159428
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG96:                ;; offset=0x0A53
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG97:                ;; offset=0x0A59
       cmp      gword ptr [rbp-0xD8], 0
       jne      G_M000_IG52
 
G_M000_IG98:                ;; offset=0x0A67
       lea      rcx, [rbp-0xD8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FFA0286CD80
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       jmp      G_M000_IG52
 
G_M000_IG99:                ;; offset=0x0A8C
       add      rsp, 408
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG100:                ;; offset=0x0AA0
       xor      esi, esi
       jmp      G_M000_IG17
 
G_M000_IG101:                ;; offset=0x0AA7
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FFA026F6F40
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       mov      rcx, bword ptr [rbp+0x10]
       jne      G_M000_IG07
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      r14, rax
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG08
 
G_M000_IG102:                ;; offset=0x0AEE
       mov      rdi, bword ptr [rbp+0x40]
       jmp      SHORT G_M000_IG109
 
G_M000_IG103:                ;; offset=0x0AF4
       xor      eax, eax
 
G_M000_IG104:                ;; offset=0x0AF6
       add      rsp, 408
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG105:                ;; offset=0x0B0A
       mov      rdi, bword ptr [rbp+0x40]
       jmp      SHORT G_M000_IG109
 
G_M000_IG106:                ;; offset=0x0B10
       xor      esi, esi
       jmp      G_M000_IG17
 
G_M000_IG107:                ;; offset=0x0B17
       mov      rcx, 0x7FFA027D1128
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG19
 
G_M000_IG108:                ;; offset=0x0B2F
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       sete     cl
       movzx    rcx, cl
       test     ecx, ecx
       je       G_M000_IG21
       jmp      SHORT G_M000_IG103
 
G_M000_IG109:                ;; offset=0x0B4A
       mov      r9, gword ptr [rbp+0x28]
       cmp      byte  ptr [r9+0x30], 0
       je       G_M000_IG132
 
G_M000_IG110:                ;; offset=0x0B59
       cmp      byte  ptr [r9+0x34], 0
       je       G_M000_IG132
       cmp      dword ptr [r9+0x28], 0
       jne      SHORT G_M000_IG112
       mov      rdx, gword ptr [r9+0x20]
       mov      rcx, 0x7FFA0286DD10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG112
       mov      rdx, rbx
       test     rdx, rdx
       mov      r15, gword ptr [rbp+0x18]
       cmove    rdx, r15
       mov      r9d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], r9d
       mov      gword ptr [rsp+0x28], rsi
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, rbx
       mov      r9, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteCasedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCasedSplit,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG112
       mov      eax, 1
 
G_M000_IG111:                ;; offset=0x0BB8
       add      rsp, 408
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG112:                ;; offset=0x0BCC
       mov      r15, gword ptr [rbp+0x18]
       mov      rdx, rsi
       mov      rcx, 0x7FFA0286E138
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       je       G_M000_IG103
 
G_M000_IG113:                ;; offset=0x0BEE
       mov      r8, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [r8+0x20]
       mov      rcx, 0x7FFA0286E440
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG115
       mov      r8, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], r8
       mov      r9d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], r9d
       mov      gword ptr [rsp+0x30], rsi
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, r15
       mov      r8, rbx
       mov      r9, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteTrimmedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG115
 
G_M000_IG114:                ;; offset=0x0C38
       mov      eax, 1
       jmp      G_M000_IG99
 
G_M000_IG115:                ;; offset=0x0C42
       mov      r14, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r14]
       mov      r8, gword ptr [r14+0x20]
       test     r8, r8
       jne      SHORT G_M000_IG116
       xor      rcx, rcx
       xor      r8d, r8d
       jmp      SHORT G_M000_IG117
 
G_M000_IG116:                ;; offset=0x0C59
       lea      rcx, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
 
G_M000_IG117:                ;; offset=0x0C61
       lea      r9, bword ptr [r14+0x18]
       mov      rax, rbx
       test     rax, rax
       cmove    rax, r15
       mov      bword ptr [rbp-0x148], rcx
       mov      dword ptr [rbp-0x140], r8d
       mov      r8, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], r8
       mov      r10d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], r10d
       mov      gword ptr [rsp+0x30], rax
       lea      rcx, [rbp-0x88]
       mov      qword ptr [rsp+0x38], rcx
       lea      r8, [rbp-0x148]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG120
       mov      r8, gword ptr [r14]
       mov      r8, gword ptr [r8+0x88]
       mov      r9d, dword ptr [r14+0x18]
       cmp      r9d, dword ptr [r8+0x08]
       jae      G_M000_IG131
       shl      r9, 5
       lea      r8, bword ptr [r8+r9+0x10]
 
G_M000_IG118:                ;; offset=0x0CD5
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x138], xmm0
 
G_M000_IG119:                ;; offset=0x0CE5
       lea      r9, [rbp-0x138]
       mov      rcx, r14
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG114
 
G_M000_IG120:                ;; offset=0x0CFD
       lea      rcx, bword ptr [r14+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rsi, rax
       lea      rdx, bword ptr [r14+0x20]
       mov      r8, gword ptr [rbp+0x28]
       cmp      byte  ptr [r8+0x30], 0
       setne    r9b
       movzx    r9, r9b
       mov      r10d, dword ptr [rbp+0x30]
       lea      r8d, [r10+r9+0x01]
       mov      rdx, gword ptr [rdx]
       mov      r13, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [r13+0x28]
       lea      rcx, [rbp-0x70]
       call     [System.MemoryExtensions:AsMemory[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       xor      r12, r12
       xor      eax, eax
       mov      rcx, gword ptr [rbp-0x70]
       mov      r8d, dword ptr [rbp-0x68]
       mov      dword ptr [rbp-0x114], r8d
       mov      r10d, dword ptr [rbp-0x64]
       mov      dword ptr [rbp-0x118], r10d
       test     rcx, rcx
       je       SHORT G_M000_IG124
       mov      rax, qword ptr [rcx]
       test     dword ptr [rax], 0xFFFFFFFF80000000
       je       SHORT G_M000_IG121
       lea      r12, bword ptr [rcx+0x10]
       mov      eax, dword ptr [rcx+0x08]
       jmp      SHORT G_M000_IG122
 
G_M000_IG121:                ;; offset=0x0D78
       lea      rdx, [rbp-0x100]
       mov      rax, qword ptr [rcx]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r12, bword ptr [rbp-0x100]
       mov      eax, dword ptr [rbp-0xF8]
 
G_M000_IG122:                ;; offset=0x0D96
       mov      r8d, dword ptr [rbp-0x114]
       and      r8d, 0x7FFFFFFF
       mov      ecx, r8d
       mov      r10d, dword ptr [rbp-0x118]
       mov      edx, r10d
       add      rdx, rcx
       mov      eax, eax
       cmp      rdx, rax
       jbe      SHORT G_M000_IG123
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG123:                ;; offset=0x0DC2
       shl      rcx, 4
       add      r12, rcx
       mov      dword ptr [rbp-0xEC], r10d
       mov      eax, dword ptr [rbp-0xEC]
 
G_M000_IG124:                ;; offset=0x0DD6
       cmp      dword ptr [r13+0x2C], 0
       mov      dword ptr [rbp-0xEC], eax
       je       G_M000_IG126
       mov      rcx, 0x7FFA0286E738
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       mov      rdx, 0x242EF401C60
       cmp      rdi, gword ptr [rdx]
       jne      G_M000_IG126
       mov      rdx, rsi
       mov      rcx, 0x7FFA025ACB28
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x158], rax
       test     rax, rax
       je       SHORT G_M000_IG126
       mov      r8d, dword ptr [rbp-0xEC]
       cmp      r8d, 2
       jg       SHORT G_M000_IG125
       mov      bword ptr [rbp-0x128], r12
       mov      dword ptr [rbp-0xEC], r8d
       mov      dword ptr [rbp-0x120], r8d
       lea      rdx, [rbp-0x128]
       lea      rcx, [rbp-0xB0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      r10d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], r10d
       mov      rcx, gword ptr [rbp-0x158]
       mov      gword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xB0]
       mov      qword ptr [rsp+0x30], rcx
       mov      rcx, r14
       mov      rdx, rbx
       mov      r8, r15
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSplitUnpack(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool]
       test     eax, eax
       je       SHORT G_M000_IG126
       jmp      G_M000_IG114
 
G_M000_IG125:                ;; offset=0x0E99
       mov      dword ptr [rbp-0xEC], r8d
 
G_M000_IG126:                ;; offset=0x0EA0
       cmp      byte  ptr [r13+0x33], 0
       je       G_M000_IG129
       mov      eax, dword ptr [rbp-0xEC]
       cmp      eax, 1
       je       G_M000_IG128
       mov      dword ptr [rbp-0xEC], eax
       cmp      eax, 2
       jne      G_M000_IG129
 
G_M000_IG127:                ;; offset=0x0EC9
       mov      rcx, 0x7FFA0286E738
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       mov      rdx, 0x242EF401C30
       cmp      rdi, gword ptr [rdx]
       jne      G_M000_IG129
       mov      rdx, rsi
       mov      rcx, 0x7FFA02607AA0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x160], rax
       test     rax, rax
       je       G_M000_IG129
       cmp      dword ptr [rbp-0xEC], 0
       jbe      G_M000_IG131
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, gword ptr [rbp-0x160]
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG129
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FFA025ACB28
       call     CORINFO_HELP_CHKCASTCLASS
       mov      gword ptr [rsp+0x28], rax
       mov      rdx, r15
       mov      r8, r13
       mov      r9d, dword ptr [rbp+0x30]
       mov      rcx, gword ptr [rbp-0x160]
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryAccumulation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.PyDict,Lokad.Lython.Runtime.Text.PyString):bool]
       test     eax, eax
       je       SHORT G_M000_IG129
       jmp      G_M000_IG114
 
G_M000_IG128:                ;; offset=0x0F7F
       mov      dword ptr [rbp-0xEC], eax
       jmp      G_M000_IG127
 
G_M000_IG129:                ;; offset=0x0F8A
       mov      r9, gword ptr [r13+0x18]
       mov      r8, rbx
       test     r8, r8
       cmove    r8, r15
       mov      bword ptr [rbp-0x128], r12
       mov      r15d, dword ptr [rbp-0xEC]
       mov      dword ptr [rbp-0x120], r15d
       mov      gword ptr [rsp+0x20], r8
       lea      r8, [rbp-0x90]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0x128]
       mov      rdx, rsi
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG130
       xor      eax, eax
       jmp      G_M000_IG99
 
G_M000_IG130:                ;; offset=0x0FDC
       mov      rcx, gword ptr [r14]
       mov      rcx, gword ptr [rcx+0x88]
       mov      edx, dword ptr [r14+0x18]
       cmp      edx, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG131
       shl      rdx, 5
       lea      r13, bword ptr [rcx+rdx+0x10]
       mov      rdx, gword ptr [rbp-0x90]
       lea      rcx, [rbp-0x110]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x110]
       mov      rcx, r14
       mov      rdx, rbx
       mov      r8, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG114
 
G_M000_IG131:                ;; offset=0x1027
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG132:                ;; offset=0x102D
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       jne      SHORT G_M000_IG134
 
G_M000_IG133:                ;; offset=0x1036
       xor      rdx, rdx
       xor      r8d, r8d
       jmp      SHORT G_M000_IG135
 
G_M000_IG134:                ;; offset=0x103D
       lea      rdx, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
 
G_M000_IG135:                ;; offset=0x1045
       mov      bword ptr [rbp-0x128], rdx
       mov      dword ptr [rbp-0x120], r8d
       mov      r15, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], r15
       test     rbx, rbx
       setne    r8b
       movzx    r8, r8b
       mov      dword ptr [rsp+0x28], r8d
       lea      r8, [rbp-0xA0]
       mov      qword ptr [rsp+0x30], r8
       lea      r8, [rbp-0x128]
       mov      rdx, rsi
       mov      rcx, r9
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG136
       xor      eax, eax
       jmp      G_M000_IG99
 
G_M000_IG136:                ;; offset=0x109A
       mov      rdx, gword ptr [rbp-0xA0]
       mov      rcx, 0x7FFA024EE760
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       test     r15, r15
       je       SHORT G_M000_IG138
       mov      r14, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [r14+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, rdi
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG137:                ;; offset=0x10D4
       mov      eax, 1
       jmp      G_M000_IG99
 
G_M000_IG138:                ;; offset=0x10DE
       mov      r14, bword ptr [rbp+0x10]
       mov      r8, gword ptr [r14]
       mov      r8, gword ptr [r8+0x88]
       mov      r9d, dword ptr [r14+0x18]
       cmp      r9d, dword ptr [r8+0x08]
       jae      SHORT G_M000_IG141
       shl      r9, 5
       lea      r8, bword ptr [r8+r9+0x10]
 
G_M000_IG139:                ;; offset=0x10FF
       vmovdqu  xmm0, xmmword ptr [rbp-0xA0]
       vmovdqu  xmmword ptr [rbp-0x138], xmm0
 
G_M000_IG140:                ;; offset=0x110F
       lea      r9, [rbp-0x138]
       mov      rcx, r14
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      SHORT G_M000_IG137
 
G_M000_IG141:                ;; offset=0x1124
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG142:                ;; offset=0x112A
       sub      rsp, 104
 
G_M000_IG143:                ;; offset=0x112E
       mov      rbx, gword ptr [rbp-0x60]
       mov      rcx, gword ptr [rbp-0x150]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      rdx, rax
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AbortPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG144:                ;; offset=0x115C
       sub      rsp, 104
 
G_M000_IG145:                ;; offset=0x1160
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       lea      r8, [rbp-0x78]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG147
 
G_M000_IG146:                ;; offset=0x1194
       mov      rcx, gword ptr [rbp-0x78]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG147:                ;; offset=0x119E
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG148:                ;; offset=0x11A4
       sub      rsp, 104
 
G_M000_IG149:                ;; offset=0x11A8
       cmp      dword ptr [rbp-0x3C], 0
       je       SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x11AE
       mov      r15, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [r15+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
 
G_M000_IG151:                ;; offset=0x11C1
       nop      
 
G_M000_IG152:                ;; offset=0x11C2
       add      rsp, 104
       ret      
 
G_M000_IG153:                ;; offset=0x11C7
       sub      rsp, 104
 
G_M000_IG154:                ;; offset=0x11CB
       mov      r14, bword ptr [rbp+0x10]
       cmp      byte  ptr [r14], r14b
       lea      rcx, bword ptr [r14+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG155:                ;; offset=0x11E5
       sub      rsp, 104
 
G_M000_IG156:                ;; offset=0x11E9
       mov      r14, bword ptr [rbp+0x10]
       cmp      byte  ptr [r14], r14b
       lea      rcx, bword ptr [r14+0x20]
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 4611

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 23301
; 7 inlinees with PGO data; 24 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 504
       lea      rbp, [rsp+0x230]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x1D0], xmm4
       mov      rax, -384
 
G_M000_IG23:                ;; offset=0x0031
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG23
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r9
       mov      r15, bword ptr [rbp+0x50]
       mov      r14, bword ptr [rbp+0x60]
 
G_M000_IG02:                ;; offset=0x005E
       mov      r13, bword ptr [r8]
       mov      r12d, dword ptr [r8+0x08]
       test     rsi, rsi
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x006A
       mov      rcx, gword ptr [rbx+0x40]
       cmp      byte  ptr [rcx+0xE0], 0
       jne      G_M000_IG09
 
G_M000_IG04:                ;; offset=0x007B
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x138], ymm0
       vmovdqu  ymmword ptr [rbp-0x118], ymm0
       vmovdqu  ymmword ptr [rbp-0xF8], ymm0
       vmovdqu  ymmword ptr [rbp-0xD8], ymm0
       vmovdqu  ymmword ptr [rbp-0xB8], ymm0
       vmovdqu  ymmword ptr [rbp-0x98], ymm0
       vmovdqu  ymmword ptr [rbp-0x78], ymm0
       vmovdqu  ymmword ptr [rbp-0x58], ymm0
       mov      rcx, gword ptr [rbx+0x40]
       mov      eax, dword ptr [rcx+0xD4]
       mov      dword ptr [rbp-0x18C], eax
       cmp      eax, 16
       ja       G_M000_IG15
       cmp      byte  ptr [rbp+0x48], 0
       je       G_M000_IG20
       xor      ecx, ecx
       test     rsi, rsi
       jne      G_M000_IG16
 
G_M000_IG05:                ;; offset=0x00E7
       cmp      ecx, eax
       ja       G_M000_IG15
       lea      rdx, bword ptr [rbp-0x138]
       mov      r8d, ecx
       shl      r8, 4
       add      r8, rdx
       mov      edx, eax
       sub      edx, ecx
       cmp      r12d, edx
       ja       G_M000_IG19
       mov      ecx, r12d
       shl      rcx, 4
       mov      r10, rcx
       cmp      r10, 0x4000
       ja       G_M000_IG18
       mov      rcx, r8
       mov      rdx, r13
       mov      r8, r10
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa620d2aa8)], 0
       jne      G_M000_IG17
 
G_M000_IG06:                ;; offset=0x013F
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x170], ymm0
       lea      rdx, bword ptr [rbp-0x138]
       mov      bword ptr [rbp-0x1B0], rdx
       mov      esi, dword ptr [rbp-0x18C]
       mov      dword ptr [rbp-0x1A8], esi
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      bword ptr [rsp+0x28], r15
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rsi
       mov      bword ptr [rsp+0x38], r14
       mov      r14, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], r14
       lea      rdx, [rbp-0x150]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x1B0]
       lea      r8, [rbp-0x170]
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
 
G_M000_IG07:                ;; offset=0x01B0
       nop      
 
G_M000_IG08:                ;; offset=0x01B1
       add      rsp, 504
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG09:                ;; offset=0x01C5
       cmp      byte  ptr [rbp+0x48], 0
       jne      G_M000_IG14
       xor      ecx, ecx
       mov      qword ptr [r14], rcx
       mov      qword ptr [r14+0x08], rcx
       cmp      byte  ptr [rdi+0x34], 0
       je       G_M000_IG12
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       mov      rdx, gword ptr [rbx+0x40]
       cmp      ecx, dword ptr [rdx+0xC4]
       jne      SHORT G_M000_IG12
       mov      rcx, rbx
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG12
       mov      rax, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [rax+0x98]
       mov      gword ptr [rbp-0x1D8], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG13
 
G_M000_IG10:                ;; offset=0x022A
       mov      gword ptr [rbp-0x188], rbx
       mov      bword ptr [rbp-0x180], r13
       mov      dword ptr [rbp-0x178], r12d
       lea      rdx, [rbp-0x188]
       mov      rcx, rbx
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
 
G_M000_IG11:                ;; offset=0x0256
       test     eax, eax
       je       G_M000_IG04
       mov      r14, bword ptr [rbp+0x58]
       mov      byte  ptr [r14], 0
       xor      rcx, rcx
       mov      r14, bword ptr [rbp+0x68]
       mov      gword ptr [r14], rcx
       jmp      G_M000_IG07
 
G_M000_IG12:                ;; offset=0x0274
       xor      edx, edx
       mov      eax, edx
       jmp      SHORT G_M000_IG11
 
G_M000_IG13:                ;; offset=0x027A
       mov      rcx, gword ptr [rbp-0x1D8]
       mov      rdx, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      SHORT G_M000_IG10
 
G_M000_IG14:                ;; offset=0x028D
       mov      rdx, gword ptr [rbx+0x40]
       cmp      r12d, dword ptr [rdx+0xC4]
       jne      G_M000_IG04
       mov      bword ptr [rbp-0x1A0], r13
       mov      dword ptr [rbp-0x198], r12d
       lea      rdx, [rbp-0x1A0]
       mov      rcx, rbx
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      SHORT G_M000_IG11
 
G_M000_IG15:                ;; offset=0x02C5
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG16:                ;; offset=0x02CC
       mov      ecx, 1
       test     eax, eax
       je       G_M000_IG22
       mov      gword ptr [rbp-0x138], rsi
       xor      edx, edx
       mov      qword ptr [rbp-0x130], rdx
       jmp      G_M000_IG05
 
G_M000_IG17:                ;; offset=0x02EE
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG06
 
G_M000_IG18:                ;; offset=0x02F8
       mov      rcx, r8
       mov      rdx, r13
       mov      r8, r10
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG06
 
G_M000_IG19:                ;; offset=0x030C
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG20:                ;; offset=0x0313
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      ecx, eax
       ja       SHORT G_M000_IG15
       lea      rdx, bword ptr [rbp-0x138]
       mov      bword ptr [rbp-0x1B0], rdx
       mov      dword ptr [rbp-0x1A8], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x1C0], rcx
 
G_M000_IG21:                ;; offset=0x033F
       mov      dword ptr [rbp-0x1B8], ecx
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], rsi
       mov      gword ptr [rsp+0x38], rdi
       mov      bword ptr [rbp-0x1D0], r13
       mov      dword ptr [rbp-0x1C8], r12d
       lea      rcx, [rbp-0x1B0]
       lea      rdx, [rbp-0x1C0]
       lea      r9, [rbp-0x1D0]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, rbx
       mov      r8, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
       jmp      G_M000_IG06
 
G_M000_IG22:                ;; offset=0x0398
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 926

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 512
       lea      rbp, [rsp+0x200]
       xor      eax, eax
       mov      qword ptr [rbp-0x198], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x190], xmm4
       mov      rax, -384
 
G_M000_IG44:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG44
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      dword ptr [rbp+0x20], r8d
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0056
       mov      rax, 0x242EF4012C8
       mov      rdx, gword ptr [rax]
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0x198], rax
       mov      rcx, bword ptr [rbp-0x198]
       mov      rdx, gword ptr [rbp-0x80]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0x198]
       mov      rcx, qword ptr [rbp-0x78]
       mov      qword ptr [rax+0x08], rcx
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CurrentRecursionDepth():long:this]
       cmp      rax, 8
       jl       SHORT G_M000_IG04
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x00BA
       add      rsp, 512
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x00C3
       mov      rdx, gword ptr [rbp+0x28]
       mov      rcx, 0x7FFA02847368
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xF0], rax
       mov      rax, bword ptr [rbp-0xF0]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp+0x20], eax
       jae      G_M000_IG39
       mov      rax, bword ptr [rbp-0xF0]
       mov      ecx, dword ptr [rbp+0x20]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x100], rax
       mov      rdx, gword ptr [rbp-0x100]
       mov      rcx, 0x7FFA026F6F40
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x014B
       xor      rax, rax
       mov      gword ptr [rbp-0x88], rax
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0156
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xF8], rax
       mov      rax, bword ptr [rbp-0xF8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp+0x20], eax
       jae      G_M000_IG39
       mov      rax, bword ptr [rbp-0xF8]
       mov      ecx, dword ptr [rbp+0x20]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x88], rax
 
G_M000_IG07:                ;; offset=0x019C
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x10], rax
       mov      rdx, gword ptr [rbp+0x28]
       mov      rcx, 0x7FFA0286D848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x18], rax
       cmp      gword ptr [rbp-0x18], 0
       je       SHORT G_M000_IG08
       mov      rcx, gword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Function():Lokad.Lython.Runtime.LythonRuntime+ICallable:this]
       mov      gword ptr [rbp-0x108], rax
       mov      rdx, gword ptr [rbp-0x108]
       mov      rcx, 0x7FFA02847368
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x20], 0
       je       SHORT G_M000_IG08
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Receiver():System.Object:this]
       mov      gword ptr [rbp-0x10], rax
 
G_M000_IG08:                ;; offset=0x0211
       cmp      gword ptr [rbp-0x08], 0
       je       SHORT G_M000_IG09
       lea      r9, [rbp-0x28]
       mov      rcx, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp-0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0234
       xor      eax, eax
 
G_M000_IG10:                ;; offset=0x0236
       add      rsp, 512
       pop      rbp
       ret      
 
G_M000_IG11:                ;; offset=0x023F
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x90], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x110], rax
       mov      rdx, gword ptr [rbp-0x110]
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x2C], 1
 
G_M000_IG12:                ;; offset=0x027E
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0x98], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp+0x20]
       mov      dword ptr [rbp-0x9C], eax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x114], eax
       mov      r9d, dword ptr [rbp-0x114]
       lea      rdx, [rbp-0x40]
       mov      r8d, dword ptr [rbp-0x9C]
       mov      rcx, bword ptr [rbp-0x98]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       movzx    rax, byte  ptr [rbp-0x28]
       cmp      gword ptr [rbp-0x10], 0
       setne    cl
       movzx    rcx, cl
       and      eax, ecx
       test     eax, eax
       je       G_M000_IG17
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       jne      SHORT G_M000_IG17
 
G_M000_IG13:                ;; offset=0x0302
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG14:                ;; offset=0x030F
       lea      rdx, [rbp-0x128]
       lea      rcx, [rbp-0xE8]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG15:                ;; offset=0x0323
       vmovdqu  xmm0, xmmword ptr [rbp-0xE8]
       vmovdqu  xmmword ptr [rbp-0x138], xmm0
 
G_M000_IG16:                ;; offset=0x0333
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x140], rax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x140]
       lea      rdx, [rbp-0x138]
       mov      r8, gword ptr [rbp-0x10]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartBoundIntegerReturn(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG17
       mov      dword ptr [rbp-0x54], 1
       jmp      G_M000_IG33
 
G_M000_IG17:                ;; offset=0x037D
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG19
       mov      rax, bword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x48]
       test     eax, eax
       je       SHORT G_M000_IG18
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0xA0], eax
       jmp      SHORT G_M000_IG20
 
G_M000_IG18:                ;; offset=0x03AD
       xor      eax, eax
       mov      dword ptr [rbp-0xA0], eax
       jmp      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x03B7
       mov      dword ptr [rbp-0xA0], 1
 
G_M000_IG20:                ;; offset=0x03C1
       movzx    rax, byte  ptr [rbp-0xA0]
       mov      dword ptr [rbp-0x44], eax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG25
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_LastOwnedTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp+0x20]
       jge      G_M000_IG25
 
G_M000_IG21:                ;; offset=0x03F8
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x150], xmm0
 
G_M000_IG22:                ;; offset=0x0405
       lea      rdx, [rbp-0x150]
       lea      rcx, [rbp-0xD8]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG23:                ;; offset=0x0419
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rbp-0x160], xmm0
 
G_M000_IG24:                ;; offset=0x0429
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp+0x20]
       mov      dword ptr [rsp+0x28], eax
       mov      eax, dword ptr [rbp-0x44]
       mov      dword ptr [rsp+0x30], eax
       movzx    rax, byte  ptr [rbp-0x28]
       mov      dword ptr [rsp+0x38], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x40], rax
       lea      rax, [rbp-0x50]
       mov      qword ptr [rsp+0x48], rax
       lea      r9, [rbp-0x160]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8, gword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StartNativeFixedReturn(Lokad.Lython.Runtime.PyExecutableFunction,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,int,bool,bool,byref,byref):this]
       jmp      G_M000_IG31
 
G_M000_IG25:                ;; offset=0x0478
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x170], xmm0
 
G_M000_IG26:                ;; offset=0x0485
       lea      rdx, [rbp-0x170]
       lea      rcx, [rbp-0xB0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0xB8], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xC0], rax
       movzx    rax, byte  ptr [rbp-0x28]
       mov      dword ptr [rbp-0xC4], eax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG27:                ;; offset=0x04CE
       vmovdqu  xmm0, xmmword ptr [rbp-0xB0]
       vmovdqu  xmmword ptr [rbp-0x180], xmm0
 
G_M000_IG28:                ;; offset=0x04DE
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp-0xC0]
       mov      gword ptr [rsp+0x28], rax
       mov      eax, dword ptr [rbp-0x44]
       mov      dword ptr [rsp+0x30], eax
       mov      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rsp+0x38], eax
 
G_M000_IG29:                ;; offset=0x0507
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0x190], xmm0
 
G_M000_IG30:                ;; offset=0x0514
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x48], rax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x50], rax
       lea      rax, [rbp-0x50]
       mov      qword ptr [rsp+0x58], rax
       lea      r8, [rbp-0x180]
       lea      rax, [rbp-0x190]
       mov      qword ptr [rsp+0x40], rax
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9, gword ptr [rbp-0x10]
       mov      rdx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
 
G_M000_IG31:                ;; offset=0x0556
       cmp      gword ptr [rbp-0x50], 0
       je       SHORT G_M000_IG32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rbp-0x50]
       mov      gword ptr [rax+0x20], rcx
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      gword ptr [rcx+0x28], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x54], eax
       jmp      SHORT G_M000_IG34
 
G_M000_IG32:                ;; offset=0x0594
       call     G_M000_IG40
       jmp      SHORT G_M000_IG35
 
G_M000_IG33:                ;; offset=0x059B
       call     G_M000_IG40
       jmp      SHORT G_M000_IG37
 
G_M000_IG34:                ;; offset=0x05A2
       call     G_M000_IG40
       jmp      SHORT G_M000_IG37
 
G_M000_IG35:                ;; offset=0x05A9
       mov      eax, 1
 
G_M000_IG36:                ;; offset=0x05AE
       add      rsp, 512
       pop      rbp
       ret      
 
G_M000_IG37:                ;; offset=0x05B7
       mov      eax, dword ptr [rbp-0x54]
 
G_M000_IG38:                ;; offset=0x05BA
       add      rsp, 512
       pop      rbp
       ret      
 
G_M000_IG39:                ;; offset=0x05C3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG40:                ;; offset=0x05C9
       sub      rsp, 104
 
G_M000_IG41:                ;; offset=0x05CD
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG42
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG42:                ;; offset=0x05E3
       nop      
 
G_M000_IG43:                ;; offset=0x05E4
       add      rsp, 104
       ret      
 
; Total bytes of code 1513

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 512
       lea      rbp, [rsp+0x200]
       xor      eax, eax
       mov      qword ptr [rbp-0x198], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x190], xmm4
       mov      rax, -384
 
G_M000_IG50:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG50
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      dword ptr [rbp+0x20], r8d
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0056
       mov      rax, 0x242EF4012C8
       mov      rdx, gword ptr [rax]
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0x198], rax
       mov      rcx, bword ptr [rbp-0x198]
       mov      rdx, gword ptr [rbp-0x80]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0x198]
       mov      rcx, qword ptr [rbp-0x78]
       mov      qword ptr [rax+0x08], rcx
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CurrentRecursionDepth():long:this]
       cmp      rax, 8
       jl       SHORT G_M000_IG04
       mov      rcx, 0x7FFA02E74080
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x00C9
       add      rsp, 512
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x00D2
       mov      rdx, gword ptr [rbp+0x28]
       mov      rcx, 0x7FFA02847368
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG06
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xF0], rax
       mov      rax, bword ptr [rbp-0xF0]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp+0x20], eax
       jae      G_M000_IG45
       mov      rax, bword ptr [rbp-0xF0]
       mov      ecx, dword ptr [rbp+0x20]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x100], rax
       mov      rdx, gword ptr [rbp-0x100]
       mov      rcx, 0x7FFA026F6F40
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG07
 
G_M000_IG05:                ;; offset=0x015A
       mov      rcx, 0x7FFA02E74084
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG06:                ;; offset=0x0169
       xor      rax, rax
       mov      gword ptr [rbp-0x88], rax
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x0174
       mov      rcx, 0x7FFA02E74088
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xF8], rax
       mov      rax, bword ptr [rbp-0xF8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp+0x20], eax
       jae      G_M000_IG45
       mov      rax, bword ptr [rbp-0xF8]
       mov      ecx, dword ptr [rbp+0x20]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x88], rax
 
G_M000_IG08:                ;; offset=0x01C9
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x10], rax
       mov      rdx, gword ptr [rbp+0x28]
       mov      rcx, 0x7FFA0286D848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x18], rax
       cmp      gword ptr [rbp-0x18], 0
       je       SHORT G_M000_IG09
       mov      rcx, gword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Function():Lokad.Lython.Runtime.LythonRuntime+ICallable:this]
       mov      gword ptr [rbp-0x108], rax
       mov      rdx, gword ptr [rbp-0x108]
       mov      rcx, 0x7FFA02847368
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x20], 0
       je       SHORT G_M000_IG13
       mov      rcx, 0x7FFA02E7408C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Receiver():System.Object:this]
       mov      gword ptr [rbp-0x10], rax
 
G_M000_IG09:                ;; offset=0x024D
       cmp      gword ptr [rbp-0x08], 0
       je       SHORT G_M000_IG11
       lea      r9, [rbp-0x28]
       mov      rcx, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp-0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG14
 
G_M000_IG10:                ;; offset=0x0270
       mov      rcx, 0x7FFA02E74090
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x027F
       mov      rcx, 0x7FFA02E74094
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG12:                ;; offset=0x0290
       add      rsp, 512
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x0299
       mov      rcx, 0x7FFA02E74098
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG09
 
G_M000_IG14:                ;; offset=0x02AA
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x90], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x110], rax
       mov      rdx, gword ptr [rbp-0x110]
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x2C], 1
 
G_M000_IG15:                ;; offset=0x02E9
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0x98], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp+0x20]
       mov      dword ptr [rbp-0x9C], eax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x114], eax
       mov      r9d, dword ptr [rbp-0x114]
       lea      rdx, [rbp-0x40]
       mov      r8d, dword ptr [rbp-0x9C]
       mov      rcx, bword ptr [rbp-0x98]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       movzx    rax, byte  ptr [rbp-0x28]
       cmp      gword ptr [rbp-0x10], 0
       setne    cl
       movzx    rcx, cl
       and      eax, ecx
       test     eax, eax
       je       G_M000_IG22
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       jne      G_M000_IG21
 
G_M000_IG16:                ;; offset=0x0371
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG17:                ;; offset=0x037E
       lea      rdx, [rbp-0x128]
       lea      rcx, [rbp-0xE8]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG18:                ;; offset=0x0392
       vmovdqu  xmm0, xmmword ptr [rbp-0xE8]
       vmovdqu  xmmword ptr [rbp-0x138], xmm0
 
G_M000_IG19:                ;; offset=0x03A2
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x140], rax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x140]
       lea      rdx, [rbp-0x138]
       mov      r8, gword ptr [rbp-0x10]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartBoundIntegerReturn(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG20
       mov      rcx, 0x7FFA02E7409C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x54], 1
       jmp      G_M000_IG39
 
G_M000_IG20:                ;; offset=0x03FB
       mov      rcx, 0x7FFA02E740A0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x040C
       mov      rcx, 0x7FFA02E740A4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x041B
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG24
       mov      rax, bword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x48]
       test     eax, eax
       je       SHORT G_M000_IG23
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0xA0], eax
       jmp      SHORT G_M000_IG25
 
G_M000_IG23:                ;; offset=0x044B
       mov      rcx, 0x7FFA02E740A8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0xA0], eax
       jmp      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0464
       mov      rcx, 0x7FFA02E740AC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xA0], 1
 
G_M000_IG25:                ;; offset=0x047D
       movzx    rax, byte  ptr [rbp-0xA0]
       mov      dword ptr [rbp-0x44], eax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG31
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_LastOwnedTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp+0x20]
       jge      G_M000_IG30
       mov      rcx, 0x7FFA02E740B0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG26:                ;; offset=0x04C3
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x150], xmm0
 
G_M000_IG27:                ;; offset=0x04D0
       lea      rdx, [rbp-0x150]
       lea      rcx, [rbp-0xD8]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG28:                ;; offset=0x04E4
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rbp-0x160], xmm0
 
G_M000_IG29:                ;; offset=0x04F4
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp+0x20]
       mov      dword ptr [rsp+0x28], eax
       mov      eax, dword ptr [rbp-0x44]
       mov      dword ptr [rsp+0x30], eax
       movzx    rax, byte  ptr [rbp-0x28]
       mov      dword ptr [rsp+0x38], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x40], rax
       lea      rax, [rbp-0x50]
       mov      qword ptr [rsp+0x48], rax
       lea      r9, [rbp-0x160]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8, gword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StartNativeFixedReturn(Lokad.Lython.Runtime.PyExecutableFunction,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,int,bool,bool,byref,byref):this]
       jmp      G_M000_IG37
 
G_M000_IG30:                ;; offset=0x0543
       mov      rcx, 0x7FFA02E740B4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG31:                ;; offset=0x0552
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0x170], xmm0
 
G_M000_IG32:                ;; offset=0x055F
       lea      rdx, [rbp-0x170]
       lea      rcx, [rbp-0xB0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0xB8], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xC0], rax
       movzx    rax, byte  ptr [rbp-0x28]
       mov      dword ptr [rbp-0xC4], eax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG33:                ;; offset=0x05A8
       vmovdqu  xmm0, xmmword ptr [rbp-0xB0]
       vmovdqu  xmmword ptr [rbp-0x180], xmm0
 
G_M000_IG34:                ;; offset=0x05B8
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp-0xC0]
       mov      gword ptr [rsp+0x28], rax
       mov      eax, dword ptr [rbp-0x44]
       mov      dword ptr [rsp+0x30], eax
       mov      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rsp+0x38], eax
 
G_M000_IG35:                ;; offset=0x05E1
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0x190], xmm0
 
G_M000_IG36:                ;; offset=0x05EE
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x48], rax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x50], rax
       lea      rax, [rbp-0x50]
       mov      qword ptr [rsp+0x58], rax
       lea      r8, [rbp-0x180]
       lea      rax, [rbp-0x190]
       mov      qword ptr [rsp+0x40], rax
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9, gword ptr [rbp-0x10]
       mov      rdx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
 
G_M000_IG37:                ;; offset=0x0630
       cmp      gword ptr [rbp-0x50], 0
       je       SHORT G_M000_IG38
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rbp-0x50]
       mov      gword ptr [rax+0x20], rcx
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      gword ptr [rcx+0x28], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x54], eax
       jmp      SHORT G_M000_IG40
 
G_M000_IG38:                ;; offset=0x066E
       call     G_M000_IG46
       jmp      SHORT G_M000_IG41
 
G_M000_IG39:                ;; offset=0x0675
       call     G_M000_IG46
       jmp      SHORT G_M000_IG43
 
G_M000_IG40:                ;; offset=0x067C
       call     G_M000_IG46
       jmp      SHORT G_M000_IG43
 
G_M000_IG41:                ;; offset=0x0683
       mov      rcx, 0x7FFA02E740C0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG42:                ;; offset=0x0697
       add      rsp, 512
       pop      rbp
       ret      
 
G_M000_IG43:                ;; offset=0x06A0
       mov      rcx, 0x7FFA02E740C4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x54]
 
G_M000_IG44:                ;; offset=0x06B2
       add      rsp, 512
       pop      rbp
       ret      
 
G_M000_IG45:                ;; offset=0x06BB
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG46:                ;; offset=0x06C1
       sub      rsp, 104
 
G_M000_IG47:                ;; offset=0x06C5
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG48
       mov      rcx, 0x7FFA02E740B8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG48:                ;; offset=0x06EA
       mov      rcx, 0x7FFA02E740BC
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG49:                ;; offset=0x06FA
       add      rsp, 104
       ret      
 
; Total bytes of code 1791

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 34976
; 9 inlinees with PGO data; 65 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 200
       lea      rbp, [rsp+0x100]
       xor      eax, eax
       mov      qword ptr [rbp-0x98], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      bword ptr [rbp+0x10], rcx
       mov      rbx, rdx
       mov      esi, r8d
       mov      rdi, r9
       mov      r14, bword ptr [rbp+0x30]
 
G_M000_IG02:                ;; offset=0x004B
       mov      rdx, 0x242EF4012C8
       mov      rdx, gword ptr [rdx]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x18]
       mov      rax, gword ptr [rax+0x98]
       cmp      qword ptr [rax+0x158], 8
       jge      G_M000_IG52
       test     rdi, rdi
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0088
       mov      rax, 0x7FFA02847368
       cmp      qword ptr [rdi], rax
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0097
       mov      r15, rdi
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x009C
       xor      r15, r15
 
G_M000_IG06:                ;; offset=0x009F
       cmp      byte  ptr [rbx+0x30], 0
       je       G_M000_IG42
 
G_M000_IG07:                ;; offset=0x00A9
       lea      rax, bword ptr [rcx+0x50]
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, esi
       shl      rdx, 4
       add      rdx, bword ptr [rax]
       mov      rax, gword ptr [rdx]
       mov      r8, 0x242EF401C18
       mov      r13, gword ptr [r8]
       cmp      rax, r13
       je       G_M000_IG40
 
G_M000_IG08:                ;; offset=0x00D8
       mov      r8, 0x242EF401C20
       cmp      rax, gword ptr [r8]
       je       G_M000_IG45
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG46
 
G_M000_IG09:                ;; offset=0x00F6
       test     rax, rax
       jne      G_M000_IG41
 
G_M000_IG10:                ;; offset=0x00FF
       mov      rcx, bword ptr [rbp+0x10]
       lea      rax, bword ptr [rcx+0x50]
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, esi
       shl      rdx, 4
       add      rdx, bword ptr [rax]
       mov      r12, gword ptr [rdx]
       cmp      r12, r13
       je       G_M000_IG43
 
G_M000_IG11:                ;; offset=0x0125
       mov      rax, 0x242EF401C20
       cmp      r12, gword ptr [rax]
       je       G_M000_IG47
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG48
 
G_M000_IG12:                ;; offset=0x0143
       test     rdi, rdi
       je       SHORT G_M000_IG18
 
G_M000_IG13:                ;; offset=0x0148
       mov      rdx, 0x7FFA0286D848
       cmp      qword ptr [rdi], rdx
       jne      SHORT G_M000_IG18
 
G_M000_IG14:                ;; offset=0x0157
       mov      rdx, gword ptr [rdi+0x10]
       test     rdx, rdx
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0160
       mov      rax, 0x7FFA02847368
       xor      r8, r8
       cmp      qword ptr [rdx], rax
       cmovne   rdx, r8
 
G_M000_IG16:                ;; offset=0x0174
       test     rdx, rdx
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0179
       mov      r15, rdx
       mov      r12, gword ptr [rdi+0x08]
 
G_M000_IG18:                ;; offset=0x0180
       test     r15, r15
       je       G_M000_IG52
       mov      rdx, gword ptr [r15+0x40]
       cmp      byte  ptr [rdx+0xDF], 0
       je       G_M000_IG52
       mov      rax, gword ptr [r15+0x28]
       cmp      byte  ptr [rax+0xFA], 0
       jne      G_M000_IG52
       cmp      byte  ptr [rax+0xFB], 0
       jne      G_M000_IG52
       cmp      byte  ptr [rax+0xFC], 0
       jne      G_M000_IG52
       cmp      gword ptr [rax+0xC0], 0
       jne      G_M000_IG52
       cmp      dword ptr [rdx+0xD4], 16
       jg       G_M000_IG52
       cmp      byte  ptr [rbx+0x34], 0
       je       G_M000_IG49
       mov      edx, dword ptr [rbx+0x28]
       mov      rax, gword ptr [r15+0x08]
       cmp      byte  ptr [rax+0x54], 0
       je       G_M000_IG44
 
G_M000_IG19:                ;; offset=0x01FB
       mov      eax, dword ptr [rax+0x3C]
       test     r12, r12
       setne    r8b
       movzx    r8, r8b
       sub      eax, r8d
       cmp      eax, edx
       sete     dil
       movzx    rdi, dil
 
G_M000_IG20:                ;; offset=0x0216
       test     edi, edi
       jne      SHORT G_M000_IG24
 
G_M000_IG21:                ;; offset=0x021A
       mov      rax, gword ptr [r15+0x08]
       mov      rdx, gword ptr [rax+0x08]
       cmp      dword ptr [rdx+0x08], 16
       jg       G_M000_IG52
       cmp      dword ptr [rax+0x4C], 0
       jge      G_M000_IG52
       cmp      dword ptr [rax+0x50], 0
       jge      G_M000_IG52
       mov      rdx, gword ptr [r15+0x18]
       test     rdx, rdx
       je       SHORT G_M000_IG23
       mov      rax, rdx
       mov      r8, 0x7FFA0287EAC0
       cmp      qword ptr [rax], r8
       jne      G_M000_IG50
 
G_M000_IG22:                ;; offset=0x025F
       test     rax, rax
       je       G_M000_IG52
 
G_M000_IG23:                ;; offset=0x0268
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       test     rax, rax
       jne      G_M000_IG51
 
G_M000_IG24:                ;; offset=0x027A
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x18]
       mov      rax, gword ptr [rbx+0x18]
       mov      rcx, gword ptr [rdx+0x98]
       mov      rdx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x3C], 1
 
G_M000_IG25:                ;; offset=0x029F
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x50]
       cmp      byte  ptr [rbx+0x30], 0
       setne    r8b
       movzx    r8, r8b
       lea      r8d, [rsi+r8+0x01]
       mov      r13d, dword ptr [rbx+0x28]
       mov      r9d, r8d
       mov      eax, r13d
       add      r9, rax
       mov      eax, dword ptr [rdx+0x08]
       cmp      r9, rax
       ja       G_M000_IG27
       mov      eax, r8d
       shl      rax, 4
       add      rax, bword ptr [rdx]
       mov      bword ptr [rbp-0xA0], rax
       test     r12, r12
       setne    dl
       movzx    rdx, dl
       test     edx, edi
       je       SHORT G_M000_IG28
 
G_M000_IG26:                ;; offset=0x02EF
       cmp      dword ptr [rbx+0x2C], 0
       jne      SHORT G_M000_IG28
       mov      r8, gword ptr [rbx+0x18]
       xor      edx, edx
       mov      qword ptr [r14], rdx
       mov      qword ptr [r14+0x08], rdx
       mov      rdx, gword ptr [r15+0x40]
       cmp      byte  ptr [rdx+0xE0], 0
       je       SHORT G_M000_IG28
       lea      r9d, [r13+0x01]
       cmp      r9d, dword ptr [rdx+0xC4]
       jne      SHORT G_M000_IG28
       mov      gword ptr [rbp-0x78], r12
       mov      bword ptr [rbp-0x70], rax
       mov      dword ptr [rbp-0x68], r13d
       lea      rdx, [rbp-0x78]
       mov      rcx, r15
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+BoundIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+BoundIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       mov      rax, bword ptr [rbp-0xA0]
       je       SHORT G_M000_IG28
       mov      eax, 1
       jmp      G_M000_IG36
 
G_M000_IG27:                ;; offset=0x034D
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG28:                ;; offset=0x0354
       cmp      byte  ptr [rbx+0x31], 0
       jne      SHORT G_M000_IG30
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx+0x48], 0
       je       SHORT G_M000_IG29
       movzx    r8, byte  ptr [rbx+0x32]
       jmp      SHORT G_M000_IG31
 
G_M000_IG29:                ;; offset=0x036B
       xor      r8d, r8d
       jmp      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x0370
       mov      r8d, 1
       mov      rcx, bword ptr [rbp+0x10]
 
G_M000_IG31:                ;; offset=0x037A
       mov      dword ptr [rbp-0x40], r8d
       cmp      dword ptr [rbx+0x2C], 0
       je       SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x0384
       mov      rdx, gword ptr [rcx+0x08]
       cmp      dword ptr [rdx+0xC8], esi
       jge      SHORT G_M000_IG33
       mov      bword ptr [rbp-0x98], rax
       mov      dword ptr [rbp-0x90], r13d
       lea      rdx, [rbp-0x98]
       lea      rcx, [rbp-0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      gword ptr [rsp+0x20], r12
       mov      dword ptr [rsp+0x28], esi
       mov      r12d, dword ptr [rbp-0x40]
       mov      dword ptr [rsp+0x30], r12d
       mov      dword ptr [rsp+0x38], edi
       mov      bword ptr [rsp+0x40], r14
       lea      r9, [rbp-0x48]
       mov      qword ptr [rsp+0x48], r9
       lea      r9, [rbp-0x60]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, r15
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StartNativeFixedReturn(Lokad.Lython.Runtime.PyExecutableFunction,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,int,bool,bool,byref,byref):this]
       jmp      SHORT G_M000_IG35
 
G_M000_IG33:                ;; offset=0x03E9
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx+0x18]
       mov      rdx, gword ptr [rbx+0x18]
       mov      bword ptr [rbp-0x88], rax
       mov      dword ptr [rbp-0x80], r13d
       mov      gword ptr [rsp+0x20], r9
       mov      gword ptr [rsp+0x28], rdx
       mov      r8d, dword ptr [rbp-0x40]
       mov      dword ptr [rsp+0x30], r8d
       mov      dword ptr [rsp+0x38], edi
       xor      r8, r8
       mov      bword ptr [rbp-0x98], r8
 
G_M000_IG34:                ;; offset=0x0421
       mov      dword ptr [rbp-0x90], r8d
       lea      r8, [rbp-0x50]
       mov      qword ptr [rsp+0x48], r8
       mov      bword ptr [rsp+0x50], r14
       lea      r8, [rbp-0x48]
       mov      qword ptr [rsp+0x58], r8
       lea      r8, [rbp-0x88]
       lea      r9, [rbp-0x98]
       mov      qword ptr [rsp+0x40], r9
       mov      rcx, r15
       mov      r9, r12
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
 
G_M000_IG35:                ;; offset=0x0461
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG54
       mov      rax, gword ptr [rbp-0x48]
       mov      rcx, bword ptr [rbp+0x10]
       mov      gword ptr [rcx+0x20], rax
       mov      rax, gword ptr [r15+0x28]
       mov      rax, gword ptr [rax+0x98]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rcx+0x28], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG36:                ;; offset=0x0493
       cmp      dword ptr [rbp-0x3C], 0
       je       SHORT G_M000_IG39
 
G_M000_IG37:                ;; offset=0x0499
       mov      rcx, bword ptr [rbp+0x10]
       mov      rbx, gword ptr [rcx+0x18]
       mov      rsi, gword ptr [rbx+0x98]
       mov      rcx, qword ptr [rsi+0x160]
       test     rcx, rcx
       jle      SHORT G_M000_IG39
 
G_M000_IG38:                ;; offset=0x04B4
       dec      rcx
       mov      qword ptr [rsi+0x160], rcx
 
G_M000_IG39:                ;; offset=0x04BE
       add      rsp, 200
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG40:                ;; offset=0x04D2
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       jmp      G_M000_IG09
 
G_M000_IG41:                ;; offset=0x04E0
       mov      rdx, 0x7FFA026F6F40
       cmp      qword ptr [rax], rdx
       jne      G_M000_IG10
 
G_M000_IG42:                ;; offset=0x04F3
       mov      rcx, bword ptr [rbp+0x10]
       xor      r12, r12
       jmp      G_M000_IG12
 
G_M000_IG43:                ;; offset=0x04FF
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG12
 
G_M000_IG44:                ;; offset=0x0510
       xor      edi, edi
       jmp      G_M000_IG20
 
G_M000_IG45:                ;; offset=0x0517
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       jmp      G_M000_IG09
 
G_M000_IG46:                ;; offset=0x0525
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       jmp      G_M000_IG09
 
G_M000_IG47:                ;; offset=0x0533
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG12
 
G_M000_IG48:                ;; offset=0x0544
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG12
 
G_M000_IG49:                ;; offset=0x0555
       xor      edi, edi
       jmp      G_M000_IG20
 
G_M000_IG50:                ;; offset=0x055C
       mov      rcx, 0x7FFA027D1128
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       jmp      G_M000_IG22
 
G_M000_IG51:                ;; offset=0x0570
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       sete     cl
       movzx    rcx, cl
       test     ecx, ecx
       je       G_M000_IG24
 
G_M000_IG52:                ;; offset=0x0589
       xor      eax, eax
 
G_M000_IG53:                ;; offset=0x058B
       add      rsp, 200
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG54:                ;; offset=0x059F
       call     G_M000_IG58
       nop      
 
G_M000_IG55:                ;; offset=0x05A5
       mov      eax, 1
 
G_M000_IG56:                ;; offset=0x05AA
       add      rsp, 200
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG57:                ;; offset=0x05BE
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG58:                ;; offset=0x05C4
       sub      rsp, 104
 
G_M000_IG59:                ;; offset=0x05C8
       cmp      dword ptr [rbp-0x3C], 0
       je       SHORT G_M000_IG62
 
G_M000_IG60:                ;; offset=0x05CE
       mov      rcx, bword ptr [rbp+0x10]
       mov      rbx, gword ptr [rcx+0x18]
       mov      rsi, gword ptr [rbx+0x98]
       mov      rax, qword ptr [rsi+0x160]
       test     rax, rax
       jle      SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x05E9
       dec      rax
       mov      qword ptr [rsi+0x160], rax
 
G_M000_IG62:                ;; offset=0x05F3
       add      rsp, 104
       ret      
 
; Total bytes of code 1528

