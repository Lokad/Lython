; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 992
       lea      rbp, [rsp+0x3E0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x3A0], xmm8
       mov      rax, -864
 
G_M000_IG71:                ;; offset=0x0027
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG71
       mov      bword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
       mov      gword ptr [rbp-0x20], rcx
       mov      dword ptr [rbp-0x24], r8d
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x0057
       mov      rax, bword ptr [rbp+0x10]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdi, 0x7F5DAF71CEB0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x38], rax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG03
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x2F8], rax
       mov      rsi, gword ptr [rbp-0x2F8]
       mov      rdi, 0x7F5DAF4A5F20
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x00C2
       xor      rax, rax
       mov      gword ptr [rbp-0x158], rax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00CD
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x158], rax
 
G_M000_IG05:                ;; offset=0x00EB
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rbp-0x40], rax
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdi, 0x7F5DAF7433F8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       SHORT G_M000_IG06
       mov      rdi, gword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Function():Lokad.Lython.Runtime.LythonRuntime+ICallable:this]
       mov      gword ptr [rbp-0x300], rax
       mov      rsi, gword ptr [rbp-0x300]
       mov      rdi, 0x7F5DAF71CEB0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       je       SHORT G_M000_IG06
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x38], rax
       mov      rdi, gword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Receiver():System.Object:this]
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG06:                ;; offset=0x0162
       cmp      gword ptr [rbp-0x38], 0
       je       G_M000_IG27
       cmp      gword ptr [rbp-0x18], 0
       je       G_M000_IG27
       lea      rcx, [rbp-0x58]
       mov      rdi, gword ptr [rbp-0x38]
       mov      rsi, gword ptr [rbp-0x20]
       mov      rdx, gword ptr [rbp-0x40]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG08
       xor      eax, eax
 
G_M000_IG07:                ;; offset=0x0196
       add      rsp, 992
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x019F
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
 
G_M000_IG09:                ;; offset=0x01A4
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x308], rax
       mov      rsi, gword ptr [rbp-0x308]
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x5C], 1
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x310], rax
       mov      rsi, gword ptr [rbp-0x310]
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 32
       mov      bword ptr [rbp-0x268], rax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x26C], eax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x314], eax
       mov      edx, dword ptr [rbp-0x314]
       mov      esi, dword ptr [rbp-0x26C]
       mov      rdi, bword ptr [rbp-0x268]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:Slice(int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      gword ptr [rbp-0x280], rax
       mov      qword ptr [rbp-0x278], rdx
 
G_M000_IG10:                ;; offset=0x025A
       vmovdqu  xmm0, xmmword ptr [rbp-0x280]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG11:                ;; offset=0x026A
       lea      rdi, [rbp-0xC8]
       call     [System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_Span():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x290], rax
       mov      qword ptr [rbp-0x288], rdx
 
G_M000_IG12:                ;; offset=0x0285
       vmovdqu  xmm0, xmmword ptr [rbp-0x290]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG13:                ;; offset=0x0292
       cmp      gword ptr [rbp-0x40], 0
       jne      G_M000_IG14
       mov      rdi, bword ptr [rbp-0x70]
       mov      rsi, qword ptr [rbp-0x68]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x2E8], rax
       mov      qword ptr [rbp-0x2E0], rdx
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x320], rax
       movzx    rax, byte  ptr [rbp-0x58]
       mov      dword ptr [rsp], eax
       lea      rax, [rbp-0x80]
       mov      qword ptr [rsp+0x08], rax
       mov      r9, gword ptr [rbp-0x320]
       mov      rdx, bword ptr [rbp-0x2E8]
       mov      rcx, qword ptr [rbp-0x2E0]
       mov      rsi, gword ptr [rbp-0x20]
       mov      r8, gword ptr [rbp-0x10]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartNativeIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG14
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG23
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x328], rax
       mov      rdx, bword ptr [rbp-0x328]
       mov      rcx, gword ptr [rbp-0x80]
       mov      r8, qword ptr [rbp-0x78]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0xCC], 1
       jmp      G_M000_IG24
 
G_M000_IG14:                ;; offset=0x0377
       lea      rcx, [rbp-0x98]
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x20]
       mov      edx, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PrepareUnpackedCallReturn(byref,Lokad.Lython.Frontend.ExecutableCallSite,int,byref):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x2A0], rax
       mov      qword ptr [rbp-0x298], rdx
 
G_M000_IG15:                ;; offset=0x039D
       vmovdqu  xmm0, xmmword ptr [rbp-0x2A0]
       vmovdqu  xmmword ptr [rbp-0x90], xmm0
 
G_M000_IG16:                ;; offset=0x03AD
       mov      rdi, bword ptr [rbp-0x70]
       mov      rsi, qword ptr [rbp-0x68]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x2B0], rax
       mov      qword ptr [rbp-0x2A8], rdx
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2B8], rax
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CallResultConsumedByIteration(byref,Lokad.Lython.Frontend.ExecutableCallSite):bool]
       mov      dword ptr [rbp-0x32C], eax
       movzx    rax, byte  ptr [rbp-0x58]
       mov      dword ptr [rsp+0x10], eax
       lea      rdi, [rsp+0x18]
       lea      rsi, [rbp-0x90]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x18], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rax, [rbp-0xA0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0xB0]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0xB8]
       mov      qword ptr [rsp+0x38], rax
       mov      eax, dword ptr [rbp-0x32C]
       mov      dword ptr [rsp+0x08], eax
       mov      rdx, bword ptr [rbp-0x2B0]
       mov      rcx, qword ptr [rbp-0x2A8]
       mov      rsi, gword ptr [rbp-0x20]
       mov      r8, gword ptr [rbp-0x40]
       mov      r9, gword ptr [rbp-0x10]
       mov      rax, gword ptr [rbp-0x2B8]
       mov      gword ptr [rsp], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       movzx    rax, byte  ptr [rbp-0xA0]
       test     eax, eax
       jne      SHORT G_M000_IG17
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RestoreNativeExtent(int):this]
 
G_M000_IG17:                ;; offset=0x049A
       cmp      gword ptr [rbp-0xB8], 0
       je       G_M000_IG20
 
G_M000_IG18:                ;; offset=0x04A8
       mov      rdi, gword ptr [rbp-0xB8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterExecutableSlots():this]
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rbp-0x2C0], rax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2C8], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x338], rax
       mov      rax, gword ptr [rbp-0x338]
       mov      gword ptr [rsp], rax
       mov      rsi, gword ptr [rbp-0x2C0]
       mov      rdx, gword ptr [rbp-0x20]
       mov      ecx, dword ptr [rbp-0x24]
       mov      r8, gword ptr [rbp-0x2C8]
       mov      rdi, gword ptr [rbp-0x18]
       xor      r9d, r9d
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AttachPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.LythonSourceSpan,int,Lokad.Lython.Runtime.MemoryGovernor):this]
       nop      
 
G_M000_IG19:                ;; offset=0x0526
       mov      rdi, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp-0xB8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       mov      dword ptr [rbp-0xCC], 1
       jmp      G_M000_IG25
 
G_M000_IG20:                ;; offset=0x054A
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       movzx    rax, byte  ptr [rbp-0xA0]
       test     eax, eax
       je       SHORT G_M000_IG21
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      edx, dword ptr [rbp-0x24]
       mov      ecx, dword ptr [rbp-0x88]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteUnpackedCallReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,int)]
       jmp      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x057F
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG23
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x348], rax
       mov      rdx, bword ptr [rbp-0x348]
       mov      rcx, gword ptr [rbp-0xB0]
       mov      r8, qword ptr [rbp-0xA8]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
 
G_M000_IG22:                ;; offset=0x05CF
       mov      dword ptr [rbp-0xCC], 1
       jmp      SHORT G_M000_IG26
 
G_M000_IG23:                ;; offset=0x05DB
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG24:                ;; offset=0x05E1
       call     G_M000_IG63
       jmp      G_M000_IG55
 
G_M000_IG25:                ;; offset=0x05EB
       call     G_M000_IG63
       jmp      G_M000_IG55
 
G_M000_IG26:                ;; offset=0x05F5
       call     G_M000_IG63
       jmp      G_M000_IG55
 
G_M000_IG27:                ;; offset=0x05FF
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG51
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       je       G_M000_IG51
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG30
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x358], rax
       mov      rsi, gword ptr [rbp-0x358]
       mov      rdi, 0x7F5DAF7438C0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xE0], rax
       cmp      gword ptr [rbp-0xE0], 0
       je       SHORT G_M000_IG30
       mov      rax, bword ptr [rbp-0x08]
       mov      bword ptr [rbp-0x258], rax
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x260], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG28
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rbp-0x260], rax
 
G_M000_IG28:                ;; offset=0x069E
       mov      rdi, bword ptr [rbp-0x258]
       mov      rsi, gword ptr [rbp-0x260]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0xE0]
       mov      r8d, dword ptr [rbp-0x24]
       mov      r9, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteCasedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCasedSplit,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG30
       mov      eax, 1
 
G_M000_IG29:                ;; offset=0x06CE
       add      rsp, 992
       pop      rbp
       ret      
 
G_M000_IG30:                ;; offset=0x06D7
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdi, 0x7F5DAF743CE8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xE8], rax
       cmp      gword ptr [rbp-0xE8], 0
       jne      SHORT G_M000_IG32
       xor      eax, eax
 
G_M000_IG31:                ;; offset=0x06FE
       add      rsp, 992
       pop      rbp
       ret      
 
G_M000_IG32:                ;; offset=0x0707
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x360], rax
       mov      rsi, gword ptr [rbp-0x360]
       mov      rdi, 0x7F5DAF743FF0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xF0], rax
       cmp      gword ptr [rbp-0xF0], 0
       je       SHORT G_M000_IG33
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp], rax
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0xF0]
       mov      r8, gword ptr [rbp-0x20]
       mov      r9d, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteTrimmedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG33
       mov      dword ptr [rbp-0xCC], 1
       jmp      G_M000_IG55
 
G_M000_IG33:                ;; offset=0x077E
       mov      rax, bword ptr [rbp-0x08]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x178], rax
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      rdi, rax
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x188], rax
       mov      qword ptr [rbp-0x180], rdx
       mov      rax, gword ptr [rbp-0xE8]
       mov      gword ptr [rbp-0x190], rax
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rbp-0x198], rax
 
G_M000_IG34:                ;; offset=0x07D3
       vmovdqu  xmm0, xmmword ptr [rbp-0x188]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG35:                ;; offset=0x07E3
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 24
       mov      bword ptr [rbp-0x1B0], rax
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rbp-0x1B8], rax
       mov      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x1BC], eax
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x1C8], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG36
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rbp-0x1C8], rax
 
G_M000_IG36:                ;; offset=0x0829
       mov      eax, dword ptr [rbp-0x1BC]
       mov      dword ptr [rsp], eax
       mov      rax, gword ptr [rbp-0x1C8]
       mov      gword ptr [rsp+0x08], rax
       lea      rax, [rbp-0x100]
       mov      qword ptr [rsp+0x10], rax
       mov      rdx, bword ptr [rbp-0x1A8]
       mov      rcx, qword ptr [rbp-0x1A0]
       mov      rdi, gword ptr [rbp-0x190]
       mov      rsi, gword ptr [rbp-0x198]
       mov      r8, bword ptr [rbp-0x1B0]
       mov      r9, gword ptr [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG37
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG50
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x368], rax
       mov      rdx, bword ptr [rbp-0x368]
       mov      rcx, gword ptr [rbp-0x100]
       mov      r8, qword ptr [rbp-0xF8]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0xCC], 1
       jmp      G_M000_IG55
 
G_M000_IG37:                ;; offset=0x08E1
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x108], rax
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 32
       mov      bword ptr [rbp-0x1D0], rax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x1D4], eax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x36C], eax
       mov      edx, dword ptr [rbp-0x36C]
       mov      esi, dword ptr [rbp-0x1D4]
       mov      rdi, bword ptr [rbp-0x1D0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:Slice(int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      gword ptr [rbp-0x1E8], rax
       mov      qword ptr [rbp-0x1E0], rdx
 
G_M000_IG38:                ;; offset=0x0962
       vmovdqu  xmm0, xmmword ptr [rbp-0x1E8]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG39:                ;; offset=0x0972
       lea      rdi, [rbp-0xC8]
       call     [System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_Span():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1F8], rax
       mov      qword ptr [rbp-0x1F0], rdx
 
G_M000_IG40:                ;; offset=0x098D
       vmovdqu  xmm0, xmmword ptr [rbp-0x1F8]
       vmovdqu  xmmword ptr [rbp-0x118], xmm0
 
G_M000_IG41:                ;; offset=0x099D
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG42
       mov      rdi, 0x7F5DAF7442E8
       call     [CORINFO_HELP_GET_GCSTATIC_BASE]
       mov      rax, 0x7F4E05801350
       mov      rax, gword ptr [rax]
       cmp      rax, gword ptr [rbp-0xE8]
       jne      G_M000_IG42
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7F5DAF1A3B28
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x120], rax
       cmp      gword ptr [rbp-0x120], 0
       je       SHORT G_M000_IG42
       cmp      dword ptr [rbp-0x110], 2
       jg       SHORT G_M000_IG42
       mov      rdi, bword ptr [rbp-0x118]
       mov      rsi, qword ptr [rbp-0x110]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x248], rax
       mov      qword ptr [rbp-0x240], rdx
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x248]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdx, gword ptr [rbp-0x10]
       mov      rcx, gword ptr [rbp-0x20]
       mov      r8d, dword ptr [rbp-0x24]
       mov      r9, gword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSplitUnpack(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool]
       test     eax, eax
       je       SHORT G_M000_IG42
       mov      dword ptr [rbp-0xCC], 1
       jmp      G_M000_IG55
 
G_M000_IG42:                ;; offset=0x0A7E
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_AccumulatesDictionary():bool:this]
       test     eax, eax
       je       G_M000_IG44
       mov      eax, dword ptr [rbp-0x110]
       mov      dword ptr [rbp-0x134], eax
       cmp      dword ptr [rbp-0x134], 1
       je       SHORT G_M000_IG43
       cmp      dword ptr [rbp-0x134], 2
       jne      G_M000_IG44
 
G_M000_IG43:                ;; offset=0x0AB4
       mov      rdi, 0x7F5DAF7442E8
       call     [CORINFO_HELP_GET_GCSTATIC_BASE]
       mov      rax, 0x7F4E05801320
       mov      rax, gword ptr [rax]
       cmp      rax, gword ptr [rbp-0xE8]
       jne      G_M000_IG44
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7F5DAF26EB00
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x128], rax
       cmp      gword ptr [rbp-0x128], 0
       je       G_M000_IG44
       cmp      dword ptr [rbp-0x110], 0
       jbe      G_M000_IG50
       mov      rdi, bword ptr [rbp-0x118]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x378], rax
       mov      rsi, gword ptr [rbp-0x378]
       mov      rdi, gword ptr [rbp-0x128]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG44
       cmp      dword ptr [rbp-0x110], 0
       jbe      G_M000_IG50
       mov      rdi, bword ptr [rbp-0x118]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x380], rax
       mov      rsi, gword ptr [rbp-0x380]
       mov      rdi, 0x7F5DAF1A3B28
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x388], rax
       mov      r9, gword ptr [rbp-0x388]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rdx, gword ptr [rbp-0x20]
       mov      ecx, dword ptr [rbp-0x24]
       mov      r8, gword ptr [rbp-0x128]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryAccumulation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.PyDict,Lokad.Lython.Runtime.Text.PyString):bool]
       test     eax, eax
       je       SHORT G_M000_IG44
       mov      dword ptr [rbp-0xCC], 1
       jmp      G_M000_IG55
 
G_M000_IG44:                ;; offset=0x0BBA
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x208], xmm0
 
G_M000_IG45:                ;; offset=0x0BCA
       mov      rax, gword ptr [rbp-0xE8]
       mov      gword ptr [rbp-0x210], rax
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0x218], rax
 
G_M000_IG46:                ;; offset=0x0BE6
       vmovdqu  xmm0, xmmword ptr [rbp-0x208]
       vmovdqu  xmmword ptr [rbp-0x228], xmm0
 
G_M000_IG47:                ;; offset=0x0BF6
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x230], rax
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x238], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG48
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rbp-0x238], rax
 
G_M000_IG48:                ;; offset=0x0C26
       lea      rax, [rbp-0x130]
       mov      qword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x228]
       mov      rcx, qword ptr [rbp-0x220]
       mov      rdi, gword ptr [rbp-0x210]
       mov      rsi, gword ptr [rbp-0x218]
       mov      r8, gword ptr [rbp-0x230]
       mov      r9, gword ptr [rbp-0x238]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG49
       xor      eax, eax
       mov      dword ptr [rbp-0xCC], eax
       jmp      G_M000_IG55
 
G_M000_IG49:                ;; offset=0x0C72
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG50
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x390], rax
       mov      rdx, bword ptr [rbp-0x390]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdi, bword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp-0x130]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       mov      dword ptr [rbp-0xCC], 1
       jmp      G_M000_IG55
 
G_M000_IG50:                ;; offset=0x0CCA
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG51:                ;; offset=0x0CD0
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      rdi, rax
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x168], rax
       mov      qword ptr [rbp-0x160], rdx
       cmp      gword ptr [rbp-0x18], 0
       setne    al
       movzx    rax, al
       mov      dword ptr [rsp], eax
       lea      rax, [rbp-0x148]
       mov      qword ptr [rsp+0x08], rax
       mov      rdx, bword ptr [rbp-0x168]
       mov      rcx, qword ptr [rbp-0x160]
       mov      rdi, gword ptr [rbp-0x20]
       mov      rsi, gword ptr [rbp-0x30]
       mov      r8d, dword ptr [rbp-0x24]
       mov      r9, gword ptr [rbp-0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG52
       xor      eax, eax
       mov      dword ptr [rbp-0xCC], eax
       jmp      G_M000_IG55
 
G_M000_IG52:                ;; offset=0x0D4A
       lea      rdi, [rbp-0x148]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x398], rax
       mov      rsi, gword ptr [rbp-0x398]
       mov      rdi, 0x7F5DAEE0BB68
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x150], rax
       cmp      gword ptr [rbp-0x150], 0
       je       SHORT G_M000_IG54
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rdi, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp-0x150]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xCC], 1
       jmp      SHORT G_M000_IG55
 
G_M000_IG53:                ;; offset=0x0DB9
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG54:                ;; offset=0x0DBF
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x3A0], rax
       mov      rdx, bword ptr [rbp-0x3A0]
       mov      rcx, gword ptr [rbp-0x148]
       mov      r8, qword ptr [rbp-0x140]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0xCC], 1
 
G_M000_IG55:                ;; offset=0x0E19
       mov      eax, dword ptr [rbp-0xCC]
 
G_M000_IG56:                ;; offset=0x0E1F
       add      rsp, 992
       pop      rbp
       ret      
 
G_M000_IG57:                ;; offset=0x0E28
       sub      rsp, 72
 
G_M000_IG58:                ;; offset=0x0E2C
       mov      gword ptr [rbp-0x2D0], rdi
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rbp-0x2D8], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x340], rax
       mov      rsi, gword ptr [rbp-0x340]
       mov      rdi, gword ptr [rbp-0x2D8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AbortPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG59:                ;; offset=0x0E79
       sub      rsp, 72
 
G_M000_IG60:                ;; offset=0x0E7D
       mov      gword ptr [rbp-0x2F0], rdi
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x350], rax
       mov      rsi, gword ptr [rbp-0x350]
       lea      rdx, [rbp-0xD8]
       mov      rdi, gword ptr [rbp-0x2F0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x0ECD
       mov      rdi, gword ptr [rbp-0xD8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG62:                ;; offset=0x0EDA
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG63:                ;; offset=0x0EE0
       sub      rsp, 72
 
G_M000_IG64:                ;; offset=0x0EE4
       cmp      dword ptr [rbp-0x5C], 0
       je       SHORT G_M000_IG65
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG65:                ;; offset=0x0EF6
       nop      
 
G_M000_IG66:                ;; offset=0x0EF7
       add      rsp, 72
       ret      
 
G_M000_IG67:                ;; offset=0x0EFC
       sub      rsp, 72
 
G_M000_IG68:                ;; offset=0x0F00
       mov      gword ptr [rbp-0x250], rdi
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG69:                ;; offset=0x0F24
       sub      rsp, 72
 
G_M000_IG70:                ;; offset=0x0F28
       mov      gword ptr [rbp-0x170], rdi
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 3916

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TryStartNativeIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 80
       lea      rbp, [rsp+0x50]
       xor      eax, eax
       mov      qword ptr [rbp-0x48], rax
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x002C
       mov      rax, bword ptr [rbp+0x18]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x0054
       add      rsp, 80
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x005A
       movzx    rax, byte  ptr [rbp+0x10]
       test     eax, eax
       jne      SHORT G_M000_IG06
       mov      rax, bword ptr [rbp+0x18]
       mov      bword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x20]
       mov      rcx, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x28]
       mov      r9, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       nop      
 
G_M000_IG05:                ;; offset=0x0089
       add      rsp, 80
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x008F
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x34], eax
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x34]
       jne      SHORT G_M000_IG08
       mov      rsi, bword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       lea      rdi, [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       mov      rsi, bword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp-0x30]
       mov      r8, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       nop      
 
G_M000_IG07:                ;; offset=0x00DC
       add      rsp, 80
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x00E2
       xor      eax, eax
 
G_M000_IG09:                ;; offset=0x00E4
       add      rsp, 80
       pop      rbp
       ret      
 
; Total bytes of code 234

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 576
       lea      rbp, [rsp+0x240]
       vxorps   xmm8, xmm8, xmm8
       mov      rax, -432
 
G_M000_IG13:                ;; offset=0x001F
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG13
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x004F
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x130], ymm0
       vmovdqu  ymmword ptr [rbp-0x110], ymm0
       vmovdqu  ymmword ptr [rbp-0xF0], ymm0
       vmovdqu  ymmword ptr [rbp-0xD0], ymm0
       vmovdqu  ymmword ptr [rbp-0xB0], ymm0
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
       vmovdqu  ymmword ptr [rbp-0x70], ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
       lea      rdi, [rbp-0x130]
       mov      esi, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x1A0], rax
       mov      qword ptr [rbp-0x198], rdx
 
G_M000_IG03:                ;; offset=0x00AD
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG04:                ;; offset=0x00BD
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x1E8], eax
       mov      edx, dword ptr [rbp-0x1E8]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1B0], rax
       mov      qword ptr [rbp-0x1A8], rdx
 
G_M000_IG05:                ;; offset=0x00FB
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG06:                ;; offset=0x010B
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       je       G_M000_IG08
       xor      eax, eax
       mov      dword ptr [rbp-0x144], eax
       cmp      gword ptr [rbp-0x28], 0
       je       SHORT G_M000_IG07
       mov      eax, dword ptr [rbp-0x144]
       mov      dword ptr [rbp-0x1E4], eax
       mov      eax, dword ptr [rbp-0x144]
       inc      eax
       mov      dword ptr [rbp-0x144], eax
       mov      eax, dword ptr [rbp-0x138]
       cmp      dword ptr [rbp-0x1E4], eax
       jae      G_M000_IG12
       mov      eax, dword ptr [rbp-0x1E4]
       shl      rax, 4
       mov      rdi, rax
       add      rdi, bword ptr [rbp-0x140]
       mov      rsi, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG07:                ;; offset=0x0170
       lea      rdi, [rbp-0x140]
       mov      esi, dword ptr [rbp-0x144]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1E0], rax
       mov      qword ptr [rbp-0x1D8], rdx
       mov      rsi, bword ptr [rbp-0x1E0]
       mov      rdx, qword ptr [rbp-0x1D8]
       lea      rdi, [rbp-0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG09
 
G_M000_IG08:                ;; offset=0x01AE
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x1EC], eax
       mov      edx, dword ptr [rbp-0x1EC]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1C0], rax
       mov      qword ptr [rbp-0x1B8], rdx
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x08], eax
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rsp+0x18], rax
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp-0x20]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, bword ptr [rbp-0x1C0]
       mov      rsi, qword ptr [rbp-0x1B8]
       mov      rdx, bword ptr [rbp-0x158]
       mov      rcx, qword ptr [rbp-0x150]
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG09:                ;; offset=0x0252
       vmovdqu  xmm0, xmmword ptr [rbp-0x140]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG10:                ;; offset=0x0262
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x190], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x190]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], rax
       lea      rax, [rbp-0x170]
       mov      qword ptr [rsp+0x40], rax
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rsi, bword ptr [rbp-0x1D0]
       mov      rdx, qword ptr [rbp-0x1C8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG11:                ;; offset=0x02FC
       add      rsp, 576
       pop      rbp
       ret      
 
G_M000_IG12:                ;; offset=0x0305
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 779

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x3F0
       lea      rbp, [rsp+0x3F0]
       xor      eax, eax
       mov      qword ptr [rbp-0x3A8], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x3A0], xmm8
       mov      rax, -864
 
G_M000_IG89:                ;; offset=0x0030
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG89
       mov      bword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
       mov      gword ptr [rbp-0x20], rcx
       mov      dword ptr [rbp-0x24], r8d
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x0060
       mov      rax, bword ptr [rbp+0x10]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdi, 0x7F5DAF71CEB0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x38], rax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG04
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x300], rax
       mov      rsi, gword ptr [rbp-0x300]
       mov      rdi, 0x7F5DAF4A5F20
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x00CB
       mov      rdi, 0x7F5DAFAF8110
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00DA
       xor      rax, rax
       mov      gword ptr [rbp-0x158], rax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x00E5
       mov      rdi, 0x7F5DAFAF8114
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x158], rax
 
G_M000_IG06:                ;; offset=0x0112
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rbp-0x40], rax
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdi, 0x7F5DAF7433F8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       SHORT G_M000_IG07
       mov      rdi, gword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Function():Lokad.Lython.Runtime.LythonRuntime+ICallable:this]
       mov      gword ptr [rbp-0x308], rax
       mov      rsi, gword ptr [rbp-0x308]
       mov      rdi, 0x7F5DAF71CEB0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       je       G_M000_IG10
       mov      rdi, 0x7F5DAFAF8118
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x38], rax
       mov      rdi, gword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Receiver():System.Object:this]
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG07:                ;; offset=0x019C
       cmp      gword ptr [rbp-0x38], 0
       je       G_M000_IG31
       cmp      gword ptr [rbp-0x18], 0
       je       SHORT G_M000_IG09
       lea      rcx, [rbp-0x58]
       mov      rdi, gword ptr [rbp-0x38]
       mov      rsi, gword ptr [rbp-0x20]
       mov      rdx, gword ptr [rbp-0x40]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG11
       mov      rdi, 0x7F5DAFAF811C
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG08:                ;; offset=0x01DB
       add      rsp, 0x3F0
       pop      rbp
       ret      
 
G_M000_IG09:                ;; offset=0x01E4
       mov      rdi, 0x7F5DAFAF8120
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG31
 
G_M000_IG10:                ;; offset=0x01F8
       mov      rdi, 0x7F5DAFAF8124
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG07
 
G_M000_IG11:                ;; offset=0x0209
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
 
G_M000_IG12:                ;; offset=0x020E
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x310], rax
       mov      rsi, gword ptr [rbp-0x310]
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x5C], 1
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x318], rax
       mov      rsi, gword ptr [rbp-0x318]
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 32
       mov      bword ptr [rbp-0x268], rax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x26C], eax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x31C], eax
       mov      edx, dword ptr [rbp-0x31C]
       mov      esi, dword ptr [rbp-0x26C]
       mov      rdi, bword ptr [rbp-0x268]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:Slice(int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      gword ptr [rbp-0x280], rax
       mov      qword ptr [rbp-0x278], rdx
 
G_M000_IG13:                ;; offset=0x02C4
       vmovdqu  xmm0, xmmword ptr [rbp-0x280]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG14:                ;; offset=0x02D4
       lea      rdi, [rbp-0xC8]
       call     [System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_Span():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x290], rax
       mov      qword ptr [rbp-0x288], rdx
 
G_M000_IG15:                ;; offset=0x02EF
       vmovdqu  xmm0, xmmword ptr [rbp-0x290]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG16:                ;; offset=0x02FC
       cmp      gword ptr [rbp-0x40], 0
       jne      G_M000_IG18
       mov      rdi, bword ptr [rbp-0x70]
       mov      rsi, qword ptr [rbp-0x68]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x2E8], rax
       mov      qword ptr [rbp-0x2E0], rdx
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x328], rax
       movzx    rax, byte  ptr [rbp-0x58]
       mov      dword ptr [rsp], eax
       lea      rax, [rbp-0x80]
       mov      qword ptr [rsp+0x08], rax
       mov      r9, gword ptr [rbp-0x328]
       mov      rdx, bword ptr [rbp-0x2E8]
       mov      rcx, qword ptr [rbp-0x2E0]
       mov      rsi, gword ptr [rbp-0x20]
       mov      r8, gword ptr [rbp-0x10]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartNativeIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,byref):bool:this]
       test     eax, eax
       je       G_M000_IG17
       mov      rdi, 0x7F5DAFAF8128
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG27
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x330], rax
       mov      rdx, bword ptr [rbp-0x330]
       mov      rcx, gword ptr [rbp-0x80]
       mov      r8, qword ptr [rbp-0x78]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0xCC], 1
       jmp      G_M000_IG28
 
G_M000_IG17:                ;; offset=0x03F4
       mov      rdi, 0x7F5DAFAF812C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG18:                ;; offset=0x0403
       lea      rcx, [rbp-0x98]
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x20]
       mov      edx, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PrepareUnpackedCallReturn(byref,Lokad.Lython.Frontend.ExecutableCallSite,int,byref):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x2A0], rax
       mov      qword ptr [rbp-0x298], rdx
 
G_M000_IG19:                ;; offset=0x0429
       vmovdqu  xmm0, xmmword ptr [rbp-0x2A0]
       vmovdqu  xmmword ptr [rbp-0x90], xmm0
 
G_M000_IG20:                ;; offset=0x0439
       mov      rdi, bword ptr [rbp-0x70]
       mov      rsi, qword ptr [rbp-0x68]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x2B0], rax
       mov      qword ptr [rbp-0x2A8], rdx
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2B8], rax
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CallResultConsumedByIteration(byref,Lokad.Lython.Frontend.ExecutableCallSite):bool]
       mov      dword ptr [rbp-0x334], eax
       movzx    rax, byte  ptr [rbp-0x58]
       mov      dword ptr [rsp+0x10], eax
       lea      rdi, [rsp+0x18]
       lea      rsi, [rbp-0x90]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x18], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rax, [rbp-0xA0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0xB0]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0xB8]
       mov      qword ptr [rsp+0x38], rax
       mov      eax, dword ptr [rbp-0x334]
       mov      dword ptr [rsp+0x08], eax
       mov      rdx, bword ptr [rbp-0x2B0]
       mov      rcx, qword ptr [rbp-0x2A8]
       mov      rsi, gword ptr [rbp-0x20]
       mov      r8, gword ptr [rbp-0x40]
       mov      r9, gword ptr [rbp-0x10]
       mov      rax, gword ptr [rbp-0x2B8]
       mov      gword ptr [rsp], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       movzx    rax, byte  ptr [rbp-0xA0]
       test     eax, eax
       jne      SHORT G_M000_IG21
       mov      rdi, 0x7F5DAFAF8130
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RestoreNativeExtent(int):this]
 
G_M000_IG21:                ;; offset=0x0535
       cmp      gword ptr [rbp-0xB8], 0
       je       G_M000_IG24
 
G_M000_IG22:                ;; offset=0x0543
       mov      rdi, gword ptr [rbp-0xB8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterExecutableSlots():this]
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rbp-0x2C0], rax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2C8], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x340], rax
       mov      rax, gword ptr [rbp-0x340]
       mov      gword ptr [rsp], rax
       mov      rsi, gword ptr [rbp-0x2C0]
       mov      rdx, gword ptr [rbp-0x20]
       mov      ecx, dword ptr [rbp-0x24]
       mov      r8, gword ptr [rbp-0x2C8]
       mov      rdi, gword ptr [rbp-0x18]
       xor      r9d, r9d
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AttachPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.LythonSourceSpan,int,Lokad.Lython.Runtime.MemoryGovernor):this]
       nop      
 
G_M000_IG23:                ;; offset=0x05C1
       mov      rdi, 0x7F5DAFAF8134
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp-0xB8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       mov      dword ptr [rbp-0xCC], 1
       jmp      G_M000_IG29
 
G_M000_IG24:                ;; offset=0x05F4
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       movzx    rax, byte  ptr [rbp-0xA0]
       test     eax, eax
       je       SHORT G_M000_IG25
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      edx, dword ptr [rbp-0x24]
       mov      ecx, dword ptr [rbp-0x88]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteUnpackedCallReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,int)]
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x0629
       mov      rdi, 0x7F5DAFAF8138
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG27
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x350], rax
       mov      rdx, bword ptr [rbp-0x350]
       mov      rcx, gword ptr [rbp-0xB0]
       mov      r8, qword ptr [rbp-0xA8]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
 
G_M000_IG26:                ;; offset=0x0688
       mov      rdi, 0x7F5DAFAF813C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xCC], 1
       jmp      SHORT G_M000_IG30
 
G_M000_IG27:                ;; offset=0x06A3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG28:                ;; offset=0x06A9
       call     G_M000_IG81
       jmp      G_M000_IG73
 
G_M000_IG29:                ;; offset=0x06B3
       call     G_M000_IG81
       jmp      G_M000_IG73
 
G_M000_IG30:                ;; offset=0x06BD
       call     G_M000_IG81
       jmp      G_M000_IG73
 
G_M000_IG31:                ;; offset=0x06C7
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG69
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       je       G_M000_IG36
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG37
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x360], rax
       mov      rsi, gword ptr [rbp-0x360]
       mov      rdi, 0x7F5DAF7438C0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xE0], rax
       cmp      gword ptr [rbp-0xE0], 0
       je       G_M000_IG35
       mov      rax, bword ptr [rbp-0x08]
       mov      bword ptr [rbp-0x258], rax
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x260], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG32
       mov      rdi, 0x7F5DAFAF8148
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rbp-0x260], rax
 
G_M000_IG32:                ;; offset=0x0779
       mov      rdi, bword ptr [rbp-0x258]
       mov      rsi, gword ptr [rbp-0x260]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0xE0]
       mov      r8d, dword ptr [rbp-0x24]
       mov      r9, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteCasedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCasedSplit,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG34
       mov      rdi, 0x7F5DAFAF814C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG33:                ;; offset=0x07B8
       add      rsp, 0x3F0
       pop      rbp
       ret      
 
G_M000_IG34:                ;; offset=0x07C1
       mov      rdi, 0x7F5DAFAF8150
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG37
 
G_M000_IG35:                ;; offset=0x07D2
       mov      rdi, 0x7F5DAFAF8154
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x07E3
       mov      rdi, 0x7F5DAFAF8158
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG69
 
G_M000_IG37:                ;; offset=0x07F7
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdi, 0x7F5DAF743CE8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xE8], rax
       cmp      gword ptr [rbp-0xE8], 0
       jne      SHORT G_M000_IG39
       mov      rdi, 0x7F5DAFAF815C
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG38:                ;; offset=0x082D
       add      rsp, 0x3F0
       pop      rbp
       ret      
 
G_M000_IG39:                ;; offset=0x0836
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x368], rax
       mov      rsi, gword ptr [rbp-0x368]
       mov      rdi, 0x7F5DAF743FF0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xF0], rax
       cmp      gword ptr [rbp-0xF0], 0
       je       SHORT G_M000_IG41
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp], rax
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0xF0]
       mov      r8, gword ptr [rbp-0x20]
       mov      r9d, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteTrimmedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG40
       mov      rdi, 0x7F5DAFAF8160
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xCC], 1
       jmp      G_M000_IG73
 
G_M000_IG40:                ;; offset=0x08BC
       mov      rdi, 0x7F5DAFAF8164
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG41:                ;; offset=0x08CB
       mov      rax, bword ptr [rbp-0x08]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x178], rax
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      rdi, rax
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x188], rax
       mov      qword ptr [rbp-0x180], rdx
       mov      rax, gword ptr [rbp-0xE8]
       mov      gword ptr [rbp-0x190], rax
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rbp-0x198], rax
 
G_M000_IG42:                ;; offset=0x0920
       vmovdqu  xmm0, xmmword ptr [rbp-0x188]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG43:                ;; offset=0x0930
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 24
       mov      bword ptr [rbp-0x1B0], rax
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rbp-0x1B8], rax
       mov      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x1BC], eax
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x1C8], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG44
       mov      rdi, 0x7F5DAFAF8168
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rbp-0x1C8], rax
 
G_M000_IG44:                ;; offset=0x0985
       mov      eax, dword ptr [rbp-0x1BC]
       mov      dword ptr [rsp], eax
       mov      rax, gword ptr [rbp-0x1C8]
       mov      gword ptr [rsp+0x08], rax
       lea      rax, [rbp-0x100]
       mov      qword ptr [rsp+0x10], rax
       mov      rdx, bword ptr [rbp-0x1A8]
       mov      rcx, qword ptr [rbp-0x1A0]
       mov      rdi, gword ptr [rbp-0x190]
       mov      rsi, gword ptr [rbp-0x198]
       mov      r8, bword ptr [rbp-0x1B0]
       mov      r9, gword ptr [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG45
       mov      rdi, 0x7F5DAFAF816C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG68
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x370], rax
       mov      rdx, bword ptr [rbp-0x370]
       mov      rcx, gword ptr [rbp-0x100]
       mov      r8, qword ptr [rbp-0xF8]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0xCC], 1
       jmp      G_M000_IG73
 
G_M000_IG45:                ;; offset=0x0A4C
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x108], rax
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 32
       mov      bword ptr [rbp-0x1D0], rax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x1D4], eax
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x374], eax
       mov      edx, dword ptr [rbp-0x374]
       mov      esi, dword ptr [rbp-0x1D4]
       mov      rdi, bword ptr [rbp-0x1D0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:Slice(int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      gword ptr [rbp-0x1E8], rax
       mov      qword ptr [rbp-0x1E0], rdx
 
G_M000_IG46:                ;; offset=0x0ACD
       vmovdqu  xmm0, xmmword ptr [rbp-0x1E8]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG47:                ;; offset=0x0ADD
       lea      rdi, [rbp-0xC8]
       call     [System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_Span():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1F8], rax
       mov      qword ptr [rbp-0x1F0], rdx
 
G_M000_IG48:                ;; offset=0x0AF8
       vmovdqu  xmm0, xmmword ptr [rbp-0x1F8]
       vmovdqu  xmmword ptr [rbp-0x118], xmm0
 
G_M000_IG49:                ;; offset=0x0B08
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG54
       mov      rdi, 0x7F5DAF7442E8
       call     [CORINFO_HELP_GET_GCSTATIC_BASE]
       mov      rax, 0x7F4E05801350
       mov      rax, gword ptr [rax]
       cmp      rax, gword ptr [rbp-0xE8]
       jne      G_M000_IG53
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7F5DAF1A3B28
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x120], rax
       cmp      gword ptr [rbp-0x120], 0
       je       G_M000_IG52
       cmp      dword ptr [rbp-0x110], 2
       jg       G_M000_IG51
       mov      rdi, bword ptr [rbp-0x118]
       mov      rsi, qword ptr [rbp-0x110]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x248], rax
       mov      qword ptr [rbp-0x240], rdx
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x248]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdx, gword ptr [rbp-0x10]
       mov      rcx, gword ptr [rbp-0x20]
       mov      r8d, dword ptr [rbp-0x24]
       mov      r9, gword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSplitUnpack(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool]
       test     eax, eax
       je       SHORT G_M000_IG50
       mov      rdi, 0x7F5DAFAF8170
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xCC], 1
       jmp      G_M000_IG73
 
G_M000_IG50:                ;; offset=0x0C00
       mov      rdi, 0x7F5DAFAF8174
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG54
 
G_M000_IG51:                ;; offset=0x0C11
       mov      rdi, 0x7F5DAFAF8178
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG54
 
G_M000_IG52:                ;; offset=0x0C22
       mov      rdi, 0x7F5DAFAF817C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0C33
       mov      rdi, 0x7F5DAFAF8180
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG54:                ;; offset=0x0C42
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_AccumulatesDictionary():bool:this]
       test     eax, eax
       je       G_M000_IG62
       mov      eax, dword ptr [rbp-0x110]
       mov      dword ptr [rbp-0x134], eax
       cmp      dword ptr [rbp-0x134], 1
       je       SHORT G_M000_IG56
       cmp      dword ptr [rbp-0x134], 2
       jne      G_M000_IG61
 
G_M000_IG55:                ;; offset=0x0C78
       mov      rdi, 0x7F5DAFAF8184
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG56:                ;; offset=0x0C87
       mov      rdi, 0x7F5DAF7442E8
       call     [CORINFO_HELP_GET_GCSTATIC_BASE]
       mov      rax, 0x7F4E05801320
       mov      rax, gword ptr [rax]
       cmp      rax, gword ptr [rbp-0xE8]
       jne      G_M000_IG60
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7F5DAF26EB00
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x128], rax
       cmp      gword ptr [rbp-0x128], 0
       je       G_M000_IG59
       cmp      dword ptr [rbp-0x110], 0
       jbe      G_M000_IG68
       mov      rdi, bword ptr [rbp-0x118]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x380], rax
       mov      rsi, gword ptr [rbp-0x380]
       mov      rdi, gword ptr [rbp-0x128]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG58
       cmp      dword ptr [rbp-0x110], 0
       jbe      G_M000_IG68
       mov      rdi, bword ptr [rbp-0x118]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x388], rax
       mov      rsi, gword ptr [rbp-0x388]
       mov      rdi, 0x7F5DAF1A3B28
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x390], rax
       mov      r9, gword ptr [rbp-0x390]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rdx, gword ptr [rbp-0x20]
       mov      ecx, dword ptr [rbp-0x24]
       mov      r8, gword ptr [rbp-0x128]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryAccumulation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.PyDict,Lokad.Lython.Runtime.Text.PyString):bool]
       test     eax, eax
       je       SHORT G_M000_IG57
       mov      rdi, 0x7F5DAFAF8188
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xCC], 1
       jmp      G_M000_IG73
 
G_M000_IG57:                ;; offset=0x0DA0
       mov      rdi, 0x7F5DAFAF818C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG62
 
G_M000_IG58:                ;; offset=0x0DB1
       mov      rdi, 0x7F5DAFAF8190
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG62
 
G_M000_IG59:                ;; offset=0x0DC2
       mov      rdi, 0x7F5DAFAF8194
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG62
 
G_M000_IG60:                ;; offset=0x0DD3
       mov      rdi, 0x7F5DAFAF8198
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x0DE4
       mov      rdi, 0x7F5DAFAF819C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG62:                ;; offset=0x0DF3
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x208], xmm0
 
G_M000_IG63:                ;; offset=0x0E03
       mov      rax, gword ptr [rbp-0xE8]
       mov      gword ptr [rbp-0x210], rax
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0x218], rax
 
G_M000_IG64:                ;; offset=0x0E1F
       vmovdqu  xmm0, xmmword ptr [rbp-0x208]
       vmovdqu  xmmword ptr [rbp-0x228], xmm0
 
G_M000_IG65:                ;; offset=0x0E2F
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x230], rax
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x238], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG66
       mov      rdi, 0x7F5DAFAF81A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rbp-0x238], rax
 
G_M000_IG66:                ;; offset=0x0E6E
       lea      rax, [rbp-0x130]
       mov      qword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x228]
       mov      rcx, qword ptr [rbp-0x220]
       mov      rdi, gword ptr [rbp-0x210]
       mov      rsi, gword ptr [rbp-0x218]
       mov      r8, gword ptr [rbp-0x230]
       mov      r9, gword ptr [rbp-0x238]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG67
       mov      rdi, 0x7F5DAFAF81A4
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0xCC], eax
       jmp      G_M000_IG73
 
G_M000_IG67:                ;; offset=0x0EC9
       mov      rdi, 0x7F5DAFAF81A8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG68
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x398], rax
       mov      rdx, bword ptr [rbp-0x398]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdi, bword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp-0x130]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       mov      dword ptr [rbp-0xCC], 1
       jmp      G_M000_IG73
 
G_M000_IG68:                ;; offset=0x0F30
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG69:                ;; offset=0x0F36
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      rdi, rax
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x168], rax
       mov      qword ptr [rbp-0x160], rdx
       cmp      gword ptr [rbp-0x18], 0
       setne    al
       movzx    rax, al
       mov      dword ptr [rsp], eax
       lea      rax, [rbp-0x148]
       mov      qword ptr [rsp+0x08], rax
       mov      rdx, bword ptr [rbp-0x168]
       mov      rcx, qword ptr [rbp-0x160]
       mov      rdi, gword ptr [rbp-0x20]
       mov      rsi, gword ptr [rbp-0x30]
       mov      r8d, dword ptr [rbp-0x24]
       mov      r9, gword ptr [rbp-0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG70
       xor      eax, eax
       mov      dword ptr [rbp-0xCC], eax
       jmp      G_M000_IG73
 
G_M000_IG70:                ;; offset=0x0FB0
       lea      rdi, [rbp-0x148]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x2F8], rax
       mov      rdi, gword ptr [rbp-0x2F8]
       mov      rsi, 0x7F5DAFAF81B0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x2F8]
       mov      gword ptr [rbp-0x3A0], rax
       mov      rsi, gword ptr [rbp-0x3A0]
       mov      rdi, 0x7F5DAEE0BB68
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x150], rax
       cmp      gword ptr [rbp-0x150], 0
       je       SHORT G_M000_IG72
       mov      rdi, 0x7F5DAFAF82B8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rdi, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp-0x150]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xCC], 1
       jmp      SHORT G_M000_IG73
 
G_M000_IG71:                ;; offset=0x1052
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG72:                ;; offset=0x1058
       mov      rdi, 0x7F5DAFAF82BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG71
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x3A8], rax
       mov      rdx, bword ptr [rbp-0x3A8]
       mov      rcx, gword ptr [rbp-0x148]
       mov      r8, qword ptr [rbp-0x140]
       mov      rsi, gword ptr [rbp-0x18]
       mov      rdi, bword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       mov      dword ptr [rbp-0xCC], 1
 
G_M000_IG73:                ;; offset=0x10C1
       mov      rdi, 0x7F5DAFAF82C0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xCC]
 
G_M000_IG74:                ;; offset=0x10D6
       add      rsp, 0x3F0
       pop      rbp
       ret      
 
G_M000_IG75:                ;; offset=0x10DF
       sub      rsp, 72
 
G_M000_IG76:                ;; offset=0x10E3
       mov      gword ptr [rbp-0x2D0], rdi
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rbp-0x2D8], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x348], rax
       mov      rsi, gword ptr [rbp-0x348]
       mov      rdi, gword ptr [rbp-0x2D8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AbortPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG77:                ;; offset=0x1130
       sub      rsp, 72
 
G_M000_IG78:                ;; offset=0x1134
       mov      gword ptr [rbp-0x2F0], rdi
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rdi, gword ptr [rbp-0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x358], rax
       mov      rsi, gword ptr [rbp-0x358]
       lea      rdx, [rbp-0xD8]
       mov      rdi, gword ptr [rbp-0x2F0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x1184
       mov      rdi, gword ptr [rbp-0xD8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG80:                ;; offset=0x1191
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG81:                ;; offset=0x1197
       sub      rsp, 72
 
G_M000_IG82:                ;; offset=0x119B
       cmp      dword ptr [rbp-0x5C], 0
       je       SHORT G_M000_IG83
       mov      rdi, 0x7F5DAFAF8140
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG83:                ;; offset=0x11BC
       mov      rdi, 0x7F5DAFAF8144
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG84:                ;; offset=0x11CC
       add      rsp, 72
       ret      
 
G_M000_IG85:                ;; offset=0x11D1
       sub      rsp, 72
 
G_M000_IG86:                ;; offset=0x11D5
       mov      gword ptr [rbp-0x250], rdi
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG87:                ;; offset=0x11F9
       sub      rsp, 72
 
G_M000_IG88:                ;; offset=0x11FD
       mov      gword ptr [rbp-0x170], rdi
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x20]
       mov      esi, dword ptr [rbp-0x24]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 4641

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TryStartNativeIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 80
       lea      rbp, [rsp+0x50]
       xor      eax, eax
       mov      qword ptr [rbp-0x48], rax
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x002C
       mov      rax, bword ptr [rbp+0x18]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       mov      rdi, 0x7F5DAFAF8708
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x0063
       add      rsp, 80
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x0069
       movzx    rax, byte  ptr [rbp+0x10]
       test     eax, eax
       jne      SHORT G_M000_IG06
       mov      rdi, 0x7F5DAFAF870C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x18]
       mov      bword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x20]
       mov      rcx, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x28]
       mov      r9, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       nop      
 
G_M000_IG05:                ;; offset=0x00A7
       add      rsp, 80
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x00AD
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x34], eax
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x34]
       jne      SHORT G_M000_IG08
       mov      rdi, 0x7F5DAFAF8710
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, bword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       lea      rdi, [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       mov      rsi, bword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp-0x30]
       mov      r8, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       nop      
 
G_M000_IG07:                ;; offset=0x0109
       add      rsp, 80
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x010F
       mov      rdi, 0x7F5DAFAF8714
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG09:                ;; offset=0x0120
       add      rsp, 80
       pop      rbp
       ret      
 
; Total bytes of code 294

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 576
       lea      rbp, [rsp+0x240]
       vxorps   xmm8, xmm8, xmm8
       mov      rax, -432
 
G_M000_IG14:                ;; offset=0x001F
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG14
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x004F
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x130], ymm0
       vmovdqu  ymmword ptr [rbp-0x110], ymm0
       vmovdqu  ymmword ptr [rbp-0xF0], ymm0
       vmovdqu  ymmword ptr [rbp-0xD0], ymm0
       vmovdqu  ymmword ptr [rbp-0xB0], ymm0
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
       vmovdqu  ymmword ptr [rbp-0x70], ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
       lea      rdi, [rbp-0x130]
       mov      esi, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x1A0], rax
       mov      qword ptr [rbp-0x198], rdx
 
G_M000_IG03:                ;; offset=0x00AD
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG04:                ;; offset=0x00BD
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x1E8], eax
       mov      edx, dword ptr [rbp-0x1E8]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1B0], rax
       mov      qword ptr [rbp-0x1A8], rdx
 
G_M000_IG05:                ;; offset=0x00FB
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG06:                ;; offset=0x010B
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       je       G_M000_IG08
       xor      eax, eax
       mov      dword ptr [rbp-0x144], eax
       cmp      gword ptr [rbp-0x28], 0
       je       SHORT G_M000_IG07
       mov      rdi, 0x7F5DAFAFB150
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x144]
       mov      dword ptr [rbp-0x1E4], eax
       mov      eax, dword ptr [rbp-0x144]
       inc      eax
       mov      dword ptr [rbp-0x144], eax
       mov      eax, dword ptr [rbp-0x138]
       cmp      dword ptr [rbp-0x1E4], eax
       jae      G_M000_IG13
       mov      eax, dword ptr [rbp-0x1E4]
       shl      rax, 4
       mov      rdi, rax
       add      rdi, bword ptr [rbp-0x140]
       mov      rsi, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG07:                ;; offset=0x017F
       lea      rdi, [rbp-0x140]
       mov      esi, dword ptr [rbp-0x144]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1E0], rax
       mov      qword ptr [rbp-0x1D8], rdx
       mov      rsi, bword ptr [rbp-0x1E0]
       mov      rdx, qword ptr [rbp-0x1D8]
       lea      rdi, [rbp-0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG09
 
G_M000_IG08:                ;; offset=0x01BD
       mov      rdi, 0x7F5DAFAFB154
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x1EC], eax
       mov      edx, dword ptr [rbp-0x1EC]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1C0], rax
       mov      qword ptr [rbp-0x1B8], rdx
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x08], eax
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rsp+0x18], rax
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp-0x20]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, bword ptr [rbp-0x1C0]
       mov      rsi, qword ptr [rbp-0x1B8]
       mov      rdx, bword ptr [rbp-0x158]
       mov      rcx, qword ptr [rbp-0x150]
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG09:                ;; offset=0x0270
       mov      rdi, 0x7F5DAFAFB158
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG10:                ;; offset=0x027F
       vmovdqu  xmm0, xmmword ptr [rbp-0x140]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG11:                ;; offset=0x028F
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x190], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x190]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], rax
       lea      rax, [rbp-0x170]
       mov      qword ptr [rsp+0x40], rax
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rsi, bword ptr [rbp-0x1D0]
       mov      rdx, qword ptr [rbp-0x1C8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG12:                ;; offset=0x0329
       add      rsp, 576
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x0332
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 824

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 24984
; 26 inlinees with PGO data; 132 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 296
       lea      rbp, [rsp+0x150]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0xC0], ymm8
       vmovdqu  ymmword ptr [rbp-0xA0], ymm8
       vmovdqu  ymmword ptr [rbp-0x80], ymm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqa  xmmword ptr [rbp-0x40], xmm8
       mov      bword ptr [rbp-0xD8], rdi
       mov      gword ptr [rbp-0xE0], rsi
       mov      gword ptr [rbp-0xE8], rcx
       mov      dword ptr [rbp-0x2C], r8d
       mov      r15, rdx
       mov      rbx, r9
 
G_M000_IG02:                ;; offset=0x005C
       xor      rsi, rsi
       mov      r14, bword ptr [rbp+0x10]
       mov      gword ptr [r14], rsi
       test     rbx, rbx
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x006A
       mov      rsi, 0x7F5DAF71CEB0
       cmp      qword ptr [rbx], rsi
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0079
       mov      gword ptr [rbp-0xF0], rbx
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0082
       xor      rsi, rsi
       mov      gword ptr [rbp-0xF0], rsi
 
G_M000_IG06:                ;; offset=0x008B
       cmp      byte  ptr [rcx+0x30], 0
       jne      G_M000_IG88
 
G_M000_IG07:                ;; offset=0x0095
       xor      r13, r13
 
G_M000_IG08:                ;; offset=0x0098
       test     rbx, rbx
       je       SHORT G_M000_IG14
 
G_M000_IG09:                ;; offset=0x009D
       mov      rsi, 0x7F5DAF7433F8
       cmp      qword ptr [rbx], rsi
       jne      SHORT G_M000_IG14
 
G_M000_IG10:                ;; offset=0x00AC
       mov      rsi, gword ptr [rbx+0x10]
       test     rsi, rsi
       je       SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x00B5
       mov      rax, 0x7F5DAF71CEB0
       xor      rdx, rdx
       cmp      qword ptr [rsi], rax
       cmovne   rsi, rdx
 
G_M000_IG12:                ;; offset=0x00C8
       test     rsi, rsi
       je       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x00CD
       mov      gword ptr [rbp-0xF0], rsi
       mov      r13, gword ptr [rbx+0x08]
 
G_M000_IG14:                ;; offset=0x00D8
       cmp      gword ptr [rbp-0xF0], 0
       je       G_M000_IG89
 
G_M000_IG15:                ;; offset=0x00E6
       test     r15, r15
       je       G_M000_IG92
       mov      rsi, gword ptr [rbp-0xF0]
       mov      rsi, gword ptr [rsi+0x40]
       cmp      byte  ptr [rsi+0xDF], 0
       je       G_M000_IG90
       mov      rax, gword ptr [rbp-0xF0]
       mov      rax, gword ptr [rax+0x28]
       cmp      byte  ptr [rax+0xFA], 0
       jne      G_M000_IG90
       cmp      byte  ptr [rax+0xFB], 0
       jne      G_M000_IG90
       cmp      byte  ptr [rax+0xFC], 0
       jne      G_M000_IG90
       cmp      gword ptr [rax+0xC0], 0
       jne      G_M000_IG90
       cmp      dword ptr [rsi+0xD4], 16
       jg       G_M000_IG90
       mov      rcx, gword ptr [rbp-0xE8]
       cmp      byte  ptr [rcx+0x34], 0
       je       G_M000_IG93
       mov      esi, dword ptr [rcx+0x28]
       mov      rax, gword ptr [rbp-0xF0]
       mov      rax, gword ptr [rax+0x08]
       cmp      byte  ptr [rax+0x54], 0
       je       G_M000_IG83
 
G_M000_IG16:                ;; offset=0x017D
       mov      eax, dword ptr [rax+0x3C]
       test     r13, r13
       setne    dl
       movzx    rdx, dl
       sub      eax, edx
       cmp      eax, esi
       sete     bl
       movzx    rbx, bl
 
G_M000_IG17:                ;; offset=0x0193
       test     ebx, ebx
       je       G_M000_IG84
 
G_M000_IG18:                ;; offset=0x019B
       mov      rdi, bword ptr [rbp-0xD8]
       xor      esi, esi
       mov      dword ptr [rbp-0x30], esi
 
G_M000_IG19:                ;; offset=0x01A7
       mov      rcx, gword ptr [rbp-0xE8]
       mov      rsi, gword ptr [rcx+0x18]
       mov      r9, gword ptr [rbp-0xE0]
       mov      rdi, gword ptr [r9+0x98]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x30], 1
       mov      rcx, gword ptr [rbp-0xE8]
       mov      rsi, gword ptr [rcx+0x18]
       mov      r9, gword ptr [rbp-0xE0]
       mov      rdi, gword ptr [r9+0x98]
       mov      rax, gword ptr [rdi+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG61
       mov      rax, gword ptr [rdi+0x180]
       test     rax, rax
       jne      G_M000_IG60
 
G_M000_IG20:                ;; offset=0x020A
       mov      rdi, bword ptr [rbp-0xD8]
       lea      rax, bword ptr [rdi+0x20]
       mov      rcx, gword ptr [rbp-0xE8]
       cmp      byte  ptr [rcx+0x30], 0
       setne    dl
       movzx    rdx, dl
       mov      esi, dword ptr [rbp-0x2C]
       lea      r12d, [rsi+rdx+0x01]
       mov      edx, dword ptr [rcx+0x28]
       mov      rax, gword ptr [rax]
       test     rax, rax
       je       G_M000_IG62
       mov      r8d, r12d
       mov      r10d, edx
       add      r8, r10
       mov      r10d, dword ptr [rax+0x08]
       cmp      r8, r10
       ja       G_M000_IG63
       mov      r8d, edx
 
G_M000_IG21:                ;; offset=0x0256
       xor      rdx, rdx
       xor      r10d, r10d
       test     rax, rax
       je       SHORT G_M000_IG24
 
G_M000_IG22:                ;; offset=0x0260
       mov      rdx, qword ptr [rax]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       je       G_M000_IG65
       lea      rdx, bword ptr [rax+0x10]
       mov      r10d, dword ptr [rax+0x08]
 
G_M000_IG23:                ;; offset=0x0277
       and      r12d, 0x7FFFFFFF
       mov      eax, r12d
       mov      r11d, r8d
       add      r11, rax
       mov      r10d, r10d
       cmp      r11, r10
       ja       G_M000_IG63
       shl      rax, 4
       add      rdx, rax
       mov      bword ptr [rbp-0x108], rdx
       mov      r10d, r8d
       mov      rdx, bword ptr [rbp-0x108]
 
G_M000_IG24:                ;; offset=0x02AB
       test     r13, r13
       jne      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x02B0
       mov      rcx, gword ptr [rbp-0xE8]
       mov      r12, gword ptr [rcx+0x18]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
       mov      rax, gword ptr [rbp-0xF0]
       mov      rax, gword ptr [rax+0x40]
       cmp      byte  ptr [rax+0xE0], 0
       jne      G_M000_IG37
 
G_M000_IG26:                ;; offset=0x02DC
       mov      rdi, bword ptr [rbp-0xD8]
       mov      r12d, dword ptr [rdi+0x60]
       mov      rcx, gword ptr [rbp-0xE8]
       cmp      dword ptr [rcx+0x2C], 0
       jne      G_M000_IG71
 
G_M000_IG27:                ;; offset=0x02F8
       mov      rcx, gword ptr [rbp-0xE8]
       xor      r8, r8
       xor      eax, eax
 
G_M000_IG28:                ;; offset=0x0304
       mov      r11, gword ptr [rcx+0x18]
       cmp      byte  ptr [rcx+0x31], 0
       jne      G_M000_IG76
       cmp      byte  ptr [rdi+0x1C], 0
       jne      G_M000_IG75
       xor      r14d, r14d
 
G_M000_IG29:                ;; offset=0x031F
       mov      gword ptr [rsp], r11
       mov      dword ptr [rsp+0x08], r14d
       mov      dword ptr [rsp+0x10], ebx
       mov      bword ptr [rsp+0x18], r8
       mov      dword ptr [rbp-0xC8], eax
       mov      dword ptr [rsp+0x20], eax
       lea      r8, [rbp-0x48]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0x58]
       mov      qword ptr [rsp+0x30], r8
       lea      r8, [rbp-0x60]
       mov      qword ptr [rsp+0x38], r8
       mov      ecx, r10d
       mov      rdi, gword ptr [rbp-0xF0]
       mov      rsi, gword ptr [rbp-0xE8]
       mov      r8, r13
       mov      r9, gword ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       cmp      byte  ptr [rbp-0x48], 0
       jne      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x037D
       mov      rdi, bword ptr [rbp-0xD8]
       mov      dword ptr [rdi+0x60], r12d
 
G_M000_IG31:                ;; offset=0x0388
       cmp      gword ptr [rbp-0x60], 0
       jne      G_M000_IG77
       mov      r9, gword ptr [rbp-0xE0]
       mov      rcx, gword ptr [r9+0x98]
       mov      r8, qword ptr [rcx+0x160]
       test     r8, r8
       mov      r9, gword ptr [rbp-0xE0]
       jle      SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x03B4
       dec      r8
       mov      qword ptr [rcx+0x160], r8
 
G_M000_IG33:                ;; offset=0x03BE
       xor      ecx, ecx
       mov      dword ptr [rbp-0x30], ecx
       cmp      byte  ptr [rbp-0x48], 0
       jne      G_M000_IG80
 
G_M000_IG34:                ;; offset=0x03CD
       mov      rdi, bword ptr [rbp-0xD8]
       mov      rcx, gword ptr [rdi]
       mov      rcx, gword ptr [rcx+0x88]
       mov      r8d, dword ptr [rdi+0x18]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG79
       shl      r8, 5
       lea      rbx, bword ptr [rcx+r8+0x10]
       mov      r14, gword ptr [rbp-0x58]
       mov      r13, qword ptr [rbp-0x50]
       cmp      dword ptr [rbx+0x18], 0
       jge      G_M000_IG51
 
G_M000_IG35:                ;; offset=0x0407
       mov      rcx, r14
       mov      r8, r13
       mov      rsi, r15
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
 
G_M000_IG36:                ;; offset=0x0419
       mov      eax, 1
       jmp      G_M000_IG82
 
G_M000_IG37:                ;; offset=0x0423
       test     ebx, ebx
       jne      G_M000_IG69
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
       cmp      byte  ptr [rcx+0x34], 0
       je       G_M000_IG67
       mov      rax, gword ptr [rbp-0xF0]
       mov      rax, gword ptr [rax+0x08]
       mov      rax, gword ptr [rax+0x08]
       mov      eax, dword ptr [rax+0x08]
       mov      r8, gword ptr [rbp-0xF0]
       mov      r8, gword ptr [r8+0x40]
       cmp      eax, dword ptr [r8+0xC4]
       jne      G_M000_IG67
       mov      bword ptr [rbp-0x108], rdx
       mov      rdi, gword ptr [rbp-0xF0]
       mov      dword ptr [rbp-0xA4], r10d
       mov      esi, r10d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       G_M000_IG66
       mov      r9, gword ptr [rbp-0xE0]
       mov      rax, gword ptr [r9+0x98]
       mov      gword ptr [rbp-0x110], rax
       cmp      byte  ptr [rax], al
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       G_M000_IG68
 
G_M000_IG38:                ;; offset=0x04B6
       mov      rcx, gword ptr [rbp-0xF0]
       mov      gword ptr [rbp-0xC0], rcx
       mov      rax, bword ptr [rbp-0x108]
       mov      bword ptr [rbp-0xB8], rax
       mov      r8d, dword ptr [rbp-0xA4]
       mov      dword ptr [rbp-0xB0], r8d
       lea      rdi, [rsp]
       lea      rsi, [rbp-0xC0]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rdx, [rbp-0x40]
       mov      rdi, gword ptr [rbp-0xF0]
       mov      rsi, r12
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      rdx, bword ptr [rbp-0x108]
 
G_M000_IG39:                ;; offset=0x0527
       test     eax, eax
       mov      r10d, dword ptr [rbp-0xA4]
       je       G_M000_IG26
 
G_M000_IG40:                ;; offset=0x0536
       mov      r9, gword ptr [rbp-0xE0]
       mov      rdi, gword ptr [r9+0x98]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       xor      ecx, ecx
       mov      dword ptr [rbp-0x30], ecx
       mov      rdi, bword ptr [rbp-0xD8]
       mov      rcx, gword ptr [rdi]
       mov      rcx, gword ptr [rcx+0x88]
       mov      r8d, dword ptr [rdi+0x18]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG79
       shl      r8, 5
       lea      rbx, bword ptr [rcx+r8+0x10]
       mov      r13, gword ptr [rbp-0x40]
       mov      r14, qword ptr [rbp-0x38]
       cmp      dword ptr [rbx+0x18], 0
       jge      SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x0587
       mov      rcx, r13
       mov      r8, r14
       mov      rsi, r15
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG36
 
G_M000_IG42:                ;; offset=0x059E
       lea      r15, bword ptr [rdi+0x20]
       mov      eax, dword ptr [rbx+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x05AA
       mov      rcx, 0x7FFFFFFFFF9FF
       bt       rcx, rax
       jae      G_M000_IG70
 
G_M000_IG44:                ;; offset=0x05BE
       mov      r12d, dword ptr [rbx+0x14]
 
G_M000_IG45:                ;; offset=0x05C2
       mov      ebx, dword ptr [rbx+0x18]
       test     ebx, ebx
       jge      SHORT G_M000_IG50
 
G_M000_IG46:                ;; offset=0x05C9
       not      ebx
 
G_M000_IG47:                ;; offset=0x05CB
       cmp      ebx, dword ptr [r15+0x40]
       jge      SHORT G_M000_IG49
 
G_M000_IG48:                ;; offset=0x05D1
       mov      rdi, r15
       mov      esi, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG49:                ;; offset=0x05DC
       mov      rsi, gword ptr [r15]
       cmp      r12d, dword ptr [rsi+0x08]
       jae      G_M000_IG79
       mov      eax, r12d
       shl      rax, 4
       lea      r12, bword ptr [rsi+rax+0x10]
       mov      rdi, r12
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r12+0x08], r14
       mov      dword ptr [r15+0x40], ebx
       jmp      G_M000_IG36
 
G_M000_IG50:                ;; offset=0x060E
       jmp      SHORT G_M000_IG47
 
G_M000_IG51:                ;; offset=0x0610
       lea      r15, bword ptr [rdi+0x20]
       mov      eax, dword ptr [rbx+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x061C
       mov      rcx, 0x7FFFFFFFFF9FF
       bt       rcx, rax
       jae      G_M000_IG81
 
G_M000_IG53:                ;; offset=0x0630
       mov      r12d, dword ptr [rbx+0x14]
 
G_M000_IG54:                ;; offset=0x0634
       mov      ebx, dword ptr [rbx+0x18]
       test     ebx, ebx
       jge      SHORT G_M000_IG59
 
G_M000_IG55:                ;; offset=0x063B
       not      ebx
 
G_M000_IG56:                ;; offset=0x063D
       cmp      ebx, dword ptr [r15+0x40]
       jge      SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x0643
       mov      rdi, r15
       mov      esi, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG58:                ;; offset=0x064E
       mov      rsi, gword ptr [r15]
       cmp      r12d, dword ptr [rsi+0x08]
       jae      G_M000_IG79
       mov      eax, r12d
       shl      rax, 4
       lea      r12, bword ptr [rsi+rax+0x10]
       mov      rdi, r12
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r12+0x08], r13
       mov      dword ptr [r15+0x40], ebx
       jmp      G_M000_IG36
 
G_M000_IG59:                ;; offset=0x0680
       jmp      SHORT G_M000_IG56
 
G_M000_IG60:                ;; offset=0x0682
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG20
 
G_M000_IG61:                ;; offset=0x0694
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG20
 
G_M000_IG62:                ;; offset=0x069F
       mov      eax, r12d
       or       eax, edx
       je       SHORT G_M000_IG64
 
G_M000_IG63:                ;; offset=0x06A6
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG64:                ;; offset=0x06AD
       xor      rax, rax
       xor      r12d, r12d
       xor      r8d, r8d
       mov      dword ptr [rbp-0xC4], r8d
       mov      r8d, dword ptr [rbp-0xC4]
       jmp      G_M000_IG21
 
G_M000_IG65:                ;; offset=0x06C8
       mov      dword ptr [rbp-0xC4], r8d
       mov      rdi, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r10d, edx
       mov      rdi, rax
       mov      eax, r10d
       mov      rdx, rdi
       mov      r10d, eax
       mov      r8d, dword ptr [rbp-0xC4]
       jmp      G_M000_IG23
 
G_M000_IG66:                ;; offset=0x06F7
       mov      rdx, bword ptr [rbp-0x108]
       mov      r10d, dword ptr [rbp-0xA4]
 
G_M000_IG67:                ;; offset=0x0705
       xor      eax, eax
       mov      dword ptr [rbp-0xA4], r10d
       jmp      G_M000_IG39
 
G_M000_IG68:                ;; offset=0x0713
       mov      rdi, gword ptr [rbp-0x110]
       mov      rsi, r12
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG38
 
G_M000_IG69:                ;; offset=0x0728
       mov      r8, gword ptr [rbp-0xF0]
       mov      r8, gword ptr [r8+0x40]
       cmp      r10d, dword ptr [r8+0xC4]
       jne      G_M000_IG26
       mov      bword ptr [rbp-0x108], rdx
       mov      rsi, rdx
       mov      dword ptr [rbp-0xA4], r10d
       mov      edx, r10d
       lea      r8, [rbp-0x40]
       mov      rdi, gword ptr [rbp-0xF0]
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       mov      rdx, bword ptr [rbp-0x108]
       mov      r10d, dword ptr [rbp-0xA4]
       je       G_M000_IG26
       jmp      G_M000_IG40
 
G_M000_IG70:                ;; offset=0x0783
       mov      rdi, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r12d, eax
       jmp      G_M000_IG45
 
G_M000_IG71:                ;; offset=0x0794
       cmp      dword ptr [rcx+0x28], 16
       jg       G_M000_IG27
       mov      dword ptr [rbp-0xA4], r10d
       mov      bword ptr [rbp-0x108], rdx
       add      rdi, 32
       mov      esi, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:CanRetireWithoutCleanup(int):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG72
       mov      rdx, bword ptr [rbp-0x108]
       mov      rdi, bword ptr [rbp-0xD8]
       mov      r10d, dword ptr [rbp-0xA4]
       jmp      G_M000_IG27
 
G_M000_IG72:                ;; offset=0x07D7
       mov      rdi, bword ptr [rbp-0xD8]
       mov      rax, gword ptr [rdi+0x20]
       mov      rcx, gword ptr [rbp-0xE8]
       mov      edx, dword ptr [rcx+0x2C]
       test     rax, rax
       jne      SHORT G_M000_IG73
       mov      esi, dword ptr [rbp-0x2C]
       or       edx, esi
       jne      G_M000_IG63
       xor      rdx, rdx
       xor      r8d, r8d
       jmp      SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x0803
       mov      esi, dword ptr [rbp-0x2C]
       mov      r8d, esi
       mov      r9d, edx
       add      r8, r9
       mov      r9d, dword ptr [rax+0x08]
       cmp      r8, r9
       ja       G_M000_IG63
       mov      r8d, esi
       shl      r8, 4
       lea      rax, bword ptr [rax+r8+0x10]
       mov      r8d, edx
       mov      rdx, rax
 
G_M000_IG74:                ;; offset=0x082E
       lea      rax, bword ptr [rdi+0x20]
       lea      r9d, [rsi+r8]
       cmp      r12d, r9d
       cmovge   r9d, r12d
       mov      dword ptr [rax+0x40], r9d
       mov      eax, r8d
       mov      r8, rdx
       mov      rcx, gword ptr [rbp-0xE8]
       mov      rdx, bword ptr [rbp-0x108]
       mov      rdi, bword ptr [rbp-0xD8]
       mov      r10d, dword ptr [rbp-0xA4]
       jmp      G_M000_IG28
 
G_M000_IG75:                ;; offset=0x0868
       movzx    r14, byte  ptr [rcx+0x32]
       jmp      G_M000_IG29
 
G_M000_IG76:                ;; offset=0x0872
       mov      r14d, 1
       jmp      G_M000_IG29
 
G_M000_IG77:                ;; offset=0x087D
       mov      rdi, gword ptr [rbp-0x60]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterExecutableSlots():this]
       mov      rsi, gword ptr [rbp-0x60]
       mov      rcx, gword ptr [rbp-0xE8]
       mov      r8, gword ptr [rcx+0x18]
       mov      rdi, gword ptr [rbp-0xF0]
       mov      rdi, gword ptr [rdi+0x28]
       mov      rdi, gword ptr [rdi+0x98]
       mov      rdi, gword ptr [rdi+0x88]
       mov      gword ptr [rsp], rdi
       mov      rdi, r15
       mov      rdx, rcx
       mov      ecx, dword ptr [rbp-0x2C]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AttachPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.LythonSourceSpan,int,Lokad.Lython.Runtime.MemoryGovernor):this]
       nop      
 
G_M000_IG78:                ;; offset=0x08C8
       mov      rsi, gword ptr [rbp-0x60]
       mov      rdi, bword ptr [rbp+0x10]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      edi, edi
       mov      dword ptr [rbp-0x30], edi
       jmp      G_M000_IG36
 
G_M000_IG79:                ;; offset=0x08DF
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG80:                ;; offset=0x08E5
       mov      rdi, bword ptr [rbp-0xD8]
       mov      rsi, r9
       mov      edx, dword ptr [rbp-0x2C]
       mov      ecx, dword ptr [rbp-0xC8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteUnpackedCallReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,int)]
       jmp      G_M000_IG36
 
G_M000_IG81:                ;; offset=0x0903
       mov      rdi, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r12d, eax
       mov      r9, gword ptr [rbp-0xE0]
       jmp      G_M000_IG54
 
G_M000_IG82:                ;; offset=0x091B
       add      rsp, 296
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG83:                ;; offset=0x092D
       xor      ebx, ebx
       jmp      G_M000_IG17
 
G_M000_IG84:                ;; offset=0x0934
       mov      rsi, gword ptr [rbp-0xF0]
       mov      rax, gword ptr [rsi+0x08]
       mov      rsi, gword ptr [rax+0x08]
       cmp      dword ptr [rsi+0x08], 16
       jg       G_M000_IG90
       cmp      dword ptr [rax+0x4C], 0
       jge      G_M000_IG90
       cmp      dword ptr [rax+0x50], 0
       jge      G_M000_IG90
       mov      rsi, gword ptr [rbp-0xF0]
       mov      rsi, gword ptr [rsi+0x18]
       test     rsi, rsi
       je       SHORT G_M000_IG87
 
G_M000_IG85:                ;; offset=0x0971
       mov      rax, rsi
       mov      rdx, 0x7F5DAF764450
       cmp      qword ptr [rax], rdx
       jne      G_M000_IG94
 
G_M000_IG86:                ;; offset=0x0987
       test     rax, rax
       je       SHORT G_M000_IG90
 
G_M000_IG87:                ;; offset=0x098C
       mov      rdi, gword ptr [rbp-0xF0]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       test     rax, rax
       je       G_M000_IG18
       jmp      G_M000_IG95
 
G_M000_IG88:                ;; offset=0x09A7
       cmp      byte  ptr [rdi], dil
       add      rdi, 32
       mov      esi, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rsi, rax
       mov      rdi, 0x7F5DAF4A5F20
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       mov      rdi, bword ptr [rbp-0xD8]
       jne      G_M000_IG07
       add      rdi, 32
       mov      esi, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      r13, rax
       mov      rdi, bword ptr [rbp-0xD8]
       jmp      G_M000_IG08
 
G_M000_IG89:                ;; offset=0x09F5
       mov      r14, bword ptr [rbp+0x10]
       jmp      SHORT G_M000_IG96
 
G_M000_IG90:                ;; offset=0x09FB
       xor      eax, eax
 
G_M000_IG91:                ;; offset=0x09FD
       add      rsp, 296
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG92:                ;; offset=0x0A0F
       mov      r14, bword ptr [rbp+0x10]
       jmp      SHORT G_M000_IG96
 
G_M000_IG93:                ;; offset=0x0A15
       xor      ebx, ebx
       jmp      G_M000_IG17
 
G_M000_IG94:                ;; offset=0x0A1C
       mov      rdi, 0x7F5DAF5808D0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, bword ptr [rbp-0xD8]
       jmp      G_M000_IG86
 
G_M000_IG95:                ;; offset=0x0A37
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       sete     dil
       movzx    rdi, dil
       test     edi, edi
       je       G_M000_IG18
       jmp      SHORT G_M000_IG90
 
G_M000_IG96:                ;; offset=0x0A54
       mov      rcx, gword ptr [rbp-0xE8]
       cmp      byte  ptr [rcx+0x30], 0
       je       G_M000_IG115
 
G_M000_IG97:                ;; offset=0x0A65
       cmp      byte  ptr [rcx+0x34], 0
       je       G_M000_IG115
       cmp      dword ptr [rcx+0x28], 0
       jne      SHORT G_M000_IG99
       mov      rsi, gword ptr [rcx+0x20]
       mov      rdi, 0x7F5DAF7438C0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG99
       mov      rsi, r15
       test     rsi, rsi
       cmove    rsi, gword ptr [rbp-0xE0]
       mov      rdi, bword ptr [rbp-0xD8]
       mov      rdx, r15
       mov      rcx, rax
       mov      r8d, dword ptr [rbp-0x2C]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteCasedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCasedSplit,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG99
       mov      eax, 1
 
G_M000_IG98:                ;; offset=0x0ABE
       add      rsp, 296
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG99:                ;; offset=0x0AD0
       mov      rsi, rbx
       mov      rdi, 0x7F5DAF743CE8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       test     r14, r14
       je       G_M000_IG90
 
G_M000_IG100:                ;; offset=0x0AEE
       mov      rdx, gword ptr [rbp-0xE8]
       mov      rsi, gword ptr [rdx+0x20]
       mov      rdi, 0x7F5DAF743FF0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG102
       mov      gword ptr [rsp], rbx
       mov      rdi, bword ptr [rbp-0xD8]
       mov      rsi, gword ptr [rbp-0xE0]
       mov      rdx, r15
       mov      rcx, rax
       mov      r8, gword ptr [rbp-0xE8]
       mov      r9d, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteTrimmedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG102
 
G_M000_IG101:                ;; offset=0x0B3A
       mov      eax, 1
       jmp      G_M000_IG82
 
G_M000_IG102:                ;; offset=0x0B44
       mov      rdi, bword ptr [rbp-0xD8]
       mov      rsi, gword ptr [rdi]
       mov      rdx, gword ptr [rdi+0x20]
       test     rdx, rdx
       jne      SHORT G_M000_IG103
       xor      rcx, rcx
       xor      r8d, r8d
       jmp      SHORT G_M000_IG104
 
G_M000_IG103:                ;; offset=0x0B5E
       lea      rcx, bword ptr [rdx+0x10]
       mov      r8d, dword ptr [rdx+0x08]
 
G_M000_IG104:                ;; offset=0x0B66
       lea      r9, bword ptr [rdi+0x18]
       mov      rdx, r15
       test     rdx, rdx
       cmove    rdx, gword ptr [rbp-0xE0]
       mov      eax, dword ptr [rbp-0x2C]
       mov      dword ptr [rsp], eax
       mov      gword ptr [rsp+0x08], rdx
       lea      rdx, [rbp-0x88]
       mov      qword ptr [rsp+0x10], rdx
       mov      rdx, rcx
       mov      ecx, r8d
       mov      rdi, r14
       mov      r8, r9
       mov      r9, gword ptr [rbp-0xE8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG105
       mov      rdi, bword ptr [rbp-0xD8]
       mov      rdx, gword ptr [rdi]
       mov      rdx, gword ptr [rdx+0x88]
       mov      ecx, dword ptr [rdi+0x18]
       cmp      ecx, dword ptr [rdx+0x08]
       jae      G_M000_IG114
       shl      rcx, 5
       lea      rdx, bword ptr [rdx+rcx+0x10]
       mov      rcx, gword ptr [rbp-0x88]
       mov      r8, qword ptr [rbp-0x80]
       mov      rsi, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG101
 
G_M000_IG105:                ;; offset=0x0BEB
       mov      rdi, bword ptr [rbp-0xD8]
       add      rdi, 32
       mov      esi, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rbx, rax
       mov      rdi, bword ptr [rbp-0xD8]
       lea      rdx, bword ptr [rdi+0x20]
       mov      r8, gword ptr [rbp-0xE8]
       cmp      byte  ptr [r8+0x30], 0
       setne    sil
       movzx    rsi, sil
       mov      eax, dword ptr [rbp-0x2C]
       lea      esi, [rax+rsi+0x01]
       mov      rdi, gword ptr [rdx]
       mov      edx, dword ptr [r8+0x28]
       call     [System.MemoryExtensions:AsMemory[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,int):System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      gword ptr [rbp-0x70], rax
       mov      qword ptr [rbp-0x68], rdx
       xor      r13, r13
       xor      r12d, r12d
       mov      rdi, gword ptr [rbp-0x70]
       mov      eax, dword ptr [rbp-0x68]
       mov      dword ptr [rbp-0xCC], eax
       mov      ecx, dword ptr [rbp-0x64]
       mov      dword ptr [rbp-0xD0], ecx
       test     rdi, rdi
       je       SHORT G_M000_IG109
       mov      rdx, qword ptr [rdi]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       je       SHORT G_M000_IG106
       lea      r13, bword ptr [rdi+0x10]
       mov      r12d, dword ptr [rdi+0x08]
       jmp      SHORT G_M000_IG107
 
G_M000_IG106:                ;; offset=0x0C73
       mov      rdx, qword ptr [rdi]
       mov      rdx, qword ptr [rdx+0x40]
       call     [rdx+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r13, rax
       mov      r12d, edx
 
G_M000_IG107:                ;; offset=0x0C83
       mov      eax, dword ptr [rbp-0xCC]
       and      eax, 0x7FFFFFFF
       mov      ecx, dword ptr [rbp-0xD0]
       mov      edx, ecx
       add      rdx, rax
       mov      edi, r12d
       cmp      rdx, rdi
       jbe      SHORT G_M000_IG108
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG108:                ;; offset=0x0CA8
       shl      rax, 4
       add      r13, rax
       mov      r12d, ecx
 
G_M000_IG109:                ;; offset=0x0CB2
       mov      r8, gword ptr [rbp-0xE8]
       cmp      dword ptr [r8+0x2C], 0
       je       G_M000_IG110
       mov      rdi, 0x7F5DAF7442E8
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       mov      rsi, 0x7F4E05801350
       cmp      r14, gword ptr [rsi]
       jne      SHORT G_M000_IG110
       mov      rsi, rbx
       mov      rdi, 0x7F5DAF1A3B28
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0xF8], rax
       test     rax, rax
       je       SHORT G_M000_IG110
       cmp      r12d, 2
       jg       SHORT G_M000_IG110
       mov      rdi, r13
       mov      esi, r12d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rsp], rax
       mov      dword ptr [rsp+0x08], edx
       mov      rdi, bword ptr [rbp-0xD8]
       mov      rsi, r15
       mov      rdx, gword ptr [rbp-0xE0]
       mov      rcx, gword ptr [rbp-0xE8]
       mov      r8d, dword ptr [rbp-0x2C]
       mov      r9, gword ptr [rbp-0xF8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSplitUnpack(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool]
       test     eax, eax
       jne      G_M000_IG101
 
G_M000_IG110:                ;; offset=0x0D4B
       mov      rcx, gword ptr [rbp-0xE8]
       cmp      byte  ptr [rcx+0x33], 0
       je       G_M000_IG112
       cmp      r12d, 1
       je       SHORT G_M000_IG111
       cmp      r12d, 2
       jne      G_M000_IG112
 
G_M000_IG111:                ;; offset=0x0D6C
       mov      rdi, 0x7F5DAF7442E8
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       mov      rsi, 0x7F4E05801320
       cmp      r14, gword ptr [rsi]
       jne      G_M000_IG112
       mov      rsi, rbx
       mov      rdi, 0x7F5DAF26EB00
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x100], rax
       test     rax, rax
       je       SHORT G_M000_IG112
       test     r12d, r12d
       je       G_M000_IG114
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rsi, rax
       mov      rdi, gword ptr [rbp-0x100]
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG112
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rsi, rax
       mov      rdi, 0x7F5DAF1A3B28
       call     CORINFO_HELP_CHKCASTCLASS
       mov      r9, rax
       mov      rsi, gword ptr [rbp-0xE0]
       mov      rdx, gword ptr [rbp-0xE8]
       mov      ecx, dword ptr [rbp-0x2C]
       mov      r8, gword ptr [rbp-0x100]
       mov      rdi, bword ptr [rbp-0xD8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryAccumulation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.PyDict,Lokad.Lython.Runtime.Text.PyString):bool]
       test     eax, eax
       jne      G_M000_IG101
 
G_M000_IG112:                ;; offset=0x0E1D
       mov      rcx, gword ptr [rbp-0xE8]
       mov      r8, gword ptr [rcx+0x18]
       mov      r9, r15
       test     r9, r9
       cmove    r9, gword ptr [rbp-0xE0]
       lea      rdx, [rbp-0x90]
       mov      qword ptr [rsp], rdx
       mov      rdx, r13
       mov      ecx, r12d
       mov      rdi, r14
       mov      rsi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG113
       xor      eax, eax
       jmp      G_M000_IG82
 
G_M000_IG113:                ;; offset=0x0E5E
       mov      rdi, bword ptr [rbp-0xD8]
       mov      rax, gword ptr [rdi]
       mov      rax, gword ptr [rax+0x88]
       mov      ecx, dword ptr [rdi+0x18]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG114
       shl      rcx, 5
       lea      rbx, bword ptr [rax+rcx+0x10]
       mov      rax, gword ptr [rbp-0x90]
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rcx, rax
       mov      r8, rdx
       mov      rdi, bword ptr [rbp-0xD8]
       mov      rsi, r15
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG101
 
G_M000_IG114:                ;; offset=0x0EAE
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG115:                ;; offset=0x0EB4
       mov      rdx, gword ptr [rdi+0x20]
       test     rdx, rdx
       jne      SHORT G_M000_IG117
 
G_M000_IG116:                ;; offset=0x0EBD
       xor      rsi, rsi
       xor      r8d, r8d
       jmp      SHORT G_M000_IG118
 
G_M000_IG117:                ;; offset=0x0EC4
       lea      rsi, bword ptr [rdx+0x10]
       mov      r8d, dword ptr [rdx+0x08]
 
G_M000_IG118:                ;; offset=0x0ECC
       test     r15, r15
       setne    dl
       movzx    rdx, dl
       mov      dword ptr [rsp], edx
       lea      rdx, [rbp-0xA0]
       mov      qword ptr [rsp+0x08], rdx
       mov      rdx, rsi
       mov      ecx, r8d
       mov      rdi, gword ptr [rbp-0xE8]
       mov      rsi, rbx
       mov      r8d, dword ptr [rbp-0x2C]
       mov      r9, gword ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG119
       xor      eax, eax
       jmp      G_M000_IG82
 
G_M000_IG119:                ;; offset=0x0F10
       mov      rsi, gword ptr [rbp-0xA0]
       mov      rdi, 0x7F5DAEE0BB68
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbx, rax
       test     rbx, rbx
       je       SHORT G_M000_IG121
       mov      rdi, bword ptr [rbp-0xD8]
       add      rdi, 32
       mov      esi, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rdi, r14
       mov      rsi, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG120:                ;; offset=0x0F4D
       mov      eax, 1
       jmp      G_M000_IG82
 
G_M000_IG121:                ;; offset=0x0F57
       mov      rdi, bword ptr [rbp-0xD8]
       mov      rdx, gword ptr [rdi]
       mov      rdx, gword ptr [rdx+0x88]
       mov      ecx, dword ptr [rdi+0x18]
       cmp      ecx, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG122
       shl      rcx, 5
       lea      rdx, bword ptr [rdx+rcx+0x10]
       mov      rcx, gword ptr [rbp-0xA0]
       mov      r8, qword ptr [rbp-0x98]
       mov      rsi, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      SHORT G_M000_IG120
 
G_M000_IG122:                ;; offset=0x0F92
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG123:                ;; offset=0x0F98
       sub      rsp, 72
 
G_M000_IG124:                ;; offset=0x0F9C
       mov      r15, gword ptr [rbp-0x60]
       mov      rdi, gword ptr [rbp-0xF0]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      rsi, rax
       mov      rdi, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AbortPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG125:                ;; offset=0x0FCA
       sub      rsp, 72
 
G_M000_IG126:                ;; offset=0x0FCE
       mov      rbx, rdi
       mov      rdi, bword ptr [rbp-0xD8]
       cmp      byte  ptr [rdi], dil
       add      rdi, 32
       mov      esi, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rdi, gword ptr [rbp-0xE8]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rsi, rax
       lea      rdx, [rbp-0x78]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG128
 
G_M000_IG127:                ;; offset=0x1009
       mov      rdi, gword ptr [rbp-0x78]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG128:                ;; offset=0x1013
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG129:                ;; offset=0x1019
       sub      rsp, 72
 
G_M000_IG130:                ;; offset=0x101D
       cmp      dword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG132
 
G_M000_IG131:                ;; offset=0x1023
       mov      rsi, gword ptr [rbp-0xE0]
       mov      rdi, gword ptr [rsi+0x98]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
 
G_M000_IG132:                ;; offset=0x1039
       nop      
 
G_M000_IG133:                ;; offset=0x103A
       add      rsp, 72
       ret      
 
G_M000_IG134:                ;; offset=0x103F
       sub      rsp, 72
 
G_M000_IG135:                ;; offset=0x1043
       mov      rdi, bword ptr [rbp-0xD8]
       cmp      byte  ptr [rdi], dil
       add      rdi, 32
       mov      esi, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG136:                ;; offset=0x1060
       sub      rsp, 72
 
G_M000_IG137:                ;; offset=0x1064
       mov      rdi, bword ptr [rbp-0xD8]
       cmp      byte  ptr [rdi], dil
       add      rdi, 32
       mov      esi, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 4225

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TryStartNativeIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Dynamic PGO
; rbp based frame
; fully interruptible
; with Dynamic PGO: fgCalledCount is 34666
; 2 inlinees with PGO data; 13 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 56
       lea      rbp, [rsp+0x60]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x40], xmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x30], rax
       mov      rbx, rdi
       mov      r12, rdx
       mov      r13d, ecx
       mov      r14, r8
       mov      r15, r9
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG02:                ;; offset=0x0036
       xor      edi, edi
       mov      qword ptr [rax], rdi
       mov      qword ptr [rax+0x08], rdi
       mov      rdi, gword ptr [rbx+0x40]
       cmp      byte  ptr [rdi+0xE0], 0
       jne      SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x004C
       xor      eax, eax
 
G_M000_IG04:                ;; offset=0x004E
       add      rsp, 56
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG05:                ;; offset=0x005D
       cmp      byte  ptr [rbp+0x10], 0
       jne      G_M000_IG11
       xor      edi, edi
       mov      bword ptr [rbp+0x18], rax
       mov      qword ptr [rax], rdi
       mov      qword ptr [rax+0x08], rdi
       cmp      byte  ptr [rsi+0x34], 0
       je       G_M000_IG09
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      edi, dword ptr [rdi+0x08]
       mov      rsi, gword ptr [rbx+0x40]
       cmp      edi, dword ptr [rsi+0xC4]
       jne      G_M000_IG09
       mov      rdi, rbx
       mov      esi, r13d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG09
       mov      r14, gword ptr [r14+0x98]
       cmp      byte  ptr [r14], r14b
       mov      rdi, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG10
 
G_M000_IG06:                ;; offset=0x00C0
       mov      gword ptr [rbp-0x40], rbx
       mov      bword ptr [rbp-0x38], r12
       mov      dword ptr [rbp-0x30], r13d
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x40]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, rbx
       mov      rsi, r15
       mov      rdx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
 
G_M000_IG07:                ;; offset=0x0105
       nop      
 
G_M000_IG08:                ;; offset=0x0106
       add      rsp, 56
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG09:                ;; offset=0x0115
       xor      eax, eax
       jmp      SHORT G_M000_IG07
 
G_M000_IG10:                ;; offset=0x0119
       mov      rdi, r14
       mov      rsi, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      SHORT G_M000_IG06
 
G_M000_IG11:                ;; offset=0x0127
       mov      rsi, gword ptr [rbx+0x40]
       cmp      r13d, dword ptr [rsi+0xC4]
       jne      G_M000_IG03
       mov      rsi, r12
       mov      edx, r13d
       mov      rdi, rbx
       mov      rcx, r15
       mov      r8, rax
 
G_M000_IG12:                ;; offset=0x0147
       add      rsp, 56
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       tail.jmp [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
 
; Total bytes of code 347

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 38616
; 5 inlinees with PGO data; 11 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     rbx
       sub      rsp, 384
       lea      rbp, [rsp+0x1A0]
       xor      eax, eax
       mov      qword ptr [rbp-0x158], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x150], xmm8
       mov      rax, -288
 
G_M000_IG13:                ;; offset=0x0037
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       vmovdqa  xmmword ptr [rax+rbp], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG13
       mov      rbx, rdi
       mov      rax, rdx
 
G_M000_IG02:                ;; offset=0x0054
       mov      rdi, gword ptr [rbx+0x40]
       mov      r15d, dword ptr [rdi+0xD4]
       cmp      r15d, 16
       ja       G_M000_IG06
       cmp      byte  ptr [rbp+0x20], 0
       je       G_M000_IG11
       xor      edi, edi
       test     r8, r8
       jne      G_M000_IG07
 
G_M000_IG03:                ;; offset=0x007E
       cmp      edi, r15d
       ja       G_M000_IG06
       lea      rsi, bword ptr [rbp-0x120]
       mov      edx, edi
       shl      rdx, 4
       add      rdx, rsi
       mov      esi, r15d
       sub      esi, edi
       cmp      ecx, esi
       ja       G_M000_IG10
       mov      edi, ecx
       shl      rdi, 4
       mov      rcx, rdi
       cmp      rcx, 0x4000
       ja       G_M000_IG09
       mov      rdi, rdx
       mov      rsi, rax
       mov      rdx, rcx
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7f5e2c9f2818)], 0
       jne      G_M000_IG08
 
G_M000_IG04:                ;; offset=0x00D5
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x158], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x158]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      r14, bword ptr [rbp+0x28]
       mov      bword ptr [rsp+0x20], r14
       mov      r13d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], r13d
       mov      r14, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], r14
       mov      r14, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], r14
       lea      rsi, [rbp-0x138]
       mov      qword ptr [rsp+0x40], rsi
       lea      rsi, bword ptr [rbp-0x120]
       mov      edx, r15d
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rdi, rbx
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG05:                ;; offset=0x0161
       add      rsp, 384
       pop      rbx
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x0171
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG07:                ;; offset=0x0178
       mov      edi, 1
       test     r15d, r15d
       je       G_M000_IG12
       mov      gword ptr [rbp-0x120], r8
       xor      esi, esi
       mov      qword ptr [rbp-0x118], rsi
       jmp      G_M000_IG03
 
G_M000_IG08:                ;; offset=0x019B
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG04
 
G_M000_IG09:                ;; offset=0x01A5
       mov      rdi, rdx
       mov      rsi, rax
       mov      rdx, rcx
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG04
 
G_M000_IG10:                ;; offset=0x01B9
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG11:                ;; offset=0x01C0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      edx, dword ptr [rdi+0x08]
       cmp      edx, r15d
       ja       SHORT G_M000_IG06
       mov      gword ptr [rsp], r9
       xor      edi, edi
       mov      dword ptr [rsp+0x08], edi
       mov      gword ptr [rsp+0x10], r8
       mov      gword ptr [rsp+0x18], rsi
       mov      bword ptr [rsp+0x20], rax
       mov      dword ptr [rsp+0x28], ecx
       lea      rdi, bword ptr [rbp-0x120]
       mov      esi, edx
       xor      rdx, rdx
       xor      ecx, ecx
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
       jmp      G_M000_IG04
 
G_M000_IG12:                ;; offset=0x020C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 530

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 464
       lea      rbp, [rsp+0x1D0]
       xor      eax, eax
       mov      qword ptr [rbp-0x188], rax
       vxorps   xmm8, xmm8, xmm8
       mov      rax, -336
 
G_M000_IG35:                ;; offset=0x0028
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG35
       mov      qword ptr [rbp-0x30], rax
       mov      bword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      dword ptr [rbp-0x14], edx
       mov      gword ptr [rbp-0x20], rcx
       mov      bword ptr [rbp-0x28], r8
 
G_M000_IG02:                ;; offset=0x0057
       mov      rax, 0x7F4E058009B0
       mov      rdi, gword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      gword ptr [rbp-0xA8], rax
       mov      qword ptr [rbp-0xA0], rdx
       mov      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rbp-0x188], rax
       mov      rdi, bword ptr [rbp-0x188]
       mov      rsi, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0x188]
       mov      rcx, qword ptr [rbp-0xA0]
       mov      qword ptr [rax+0x08], rcx
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CurrentRecursionDepth():long:this]
       cmp      rax, 8
       jl       SHORT G_M000_IG04
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x00CB
       add      rsp, 464
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x00D4
       mov      rsi, gword ptr [rbp-0x20]
       mov      rdi, 0x7F5DAF71CEB0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x30], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0x148], rax
       mov      rax, bword ptr [rbp-0x148]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x14], eax
       jae      G_M000_IG30
       mov      rax, bword ptr [rbp-0x148]
       mov      ecx, dword ptr [rbp-0x14]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x158], rax
       mov      rsi, gword ptr [rbp-0x158]
       mov      rdi, 0x7F5DAF4A5F20
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x015F
       xor      rax, rax
       mov      gword ptr [rbp-0xB0], rax
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x016A
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0x150], rax
       mov      rax, bword ptr [rbp-0x150]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x14], eax
       jae      G_M000_IG30
       mov      rax, bword ptr [rbp-0x150]
       mov      ecx, dword ptr [rbp-0x14]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0xB0], rax
 
G_M000_IG07:                ;; offset=0x01B3
       mov      rax, gword ptr [rbp-0xB0]
       mov      gword ptr [rbp-0x38], rax
       mov      rsi, gword ptr [rbp-0x20]
       mov      rdi, 0x7F5DAF7433F8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x40], rax
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG08
       mov      rdi, gword ptr [rbp-0x40]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Function():Lokad.Lython.Runtime.LythonRuntime+ICallable:this]
       mov      gword ptr [rbp-0x160], rax
       mov      rsi, gword ptr [rbp-0x160]
       mov      rdi, 0x7F5DAF71CEB0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       SHORT G_M000_IG08
       mov      rax, gword ptr [rbp-0x48]
       mov      gword ptr [rbp-0x30], rax
       mov      rdi, gword ptr [rbp-0x40]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Receiver():System.Object:this]
       mov      gword ptr [rbp-0x38], rax
 
G_M000_IG08:                ;; offset=0x0228
       cmp      gword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG09
       lea      rcx, [rbp-0x50]
       mov      rdi, gword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rdx, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x024B
       xor      eax, eax
 
G_M000_IG10:                ;; offset=0x024D
       add      rsp, 464
       pop      rbp
       ret      
 
G_M000_IG11:                ;; offset=0x0256
       mov      rax, bword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x168], rax
       mov      rsi, gword ptr [rbp-0x168]
       mov      rdi, gword ptr [rbp-0xB8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x54], 1
 
G_M000_IG12:                ;; offset=0x0295
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0xC0], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x14]
       mov      dword ptr [rbp-0xC4], eax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x16C], eax
       mov      edx, dword ptr [rbp-0x16C]
       mov      esi, dword ptr [rbp-0xC4]
       mov      rdi, bword ptr [rbp-0xC0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0xD8], rax
       mov      qword ptr [rbp-0xD0], rdx
 
G_M000_IG13:                ;; offset=0x02F8
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rbp-0x68], xmm0
 
G_M000_IG14:                ;; offset=0x0305
       cmp      gword ptr [rbp-0x38], 0
       jne      G_M000_IG15
       mov      rdi, bword ptr [rbp-0x68]
       mov      rsi, qword ptr [rbp-0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x138], rax
       mov      qword ptr [rbp-0x130], rdx
       mov      rax, bword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x140], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x178], rax
       movzx    rax, byte  ptr [rbp-0x50]
       mov      dword ptr [rsp], eax
       mov      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rsp+0x08], rax
       mov      r9, gword ptr [rbp-0x178]
       mov      rdx, bword ptr [rbp-0x138]
       mov      rcx, qword ptr [rbp-0x130]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x140]
       mov      rdi, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartNativeIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,byref):bool:this]
       test     eax, eax
       je       G_M000_IG16
       mov      dword ptr [rbp-0x7C], 1
       jmp      G_M000_IG23
 
G_M000_IG15:                ;; offset=0x039E
       movzx    rax, byte  ptr [rbp-0x50]
       test     eax, eax
       je       SHORT G_M000_IG16
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       jne      SHORT G_M000_IG16
       mov      rdi, bword ptr [rbp-0x68]
       mov      rsi, qword ptr [rbp-0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x128], rax
       mov      qword ptr [rbp-0x120], rdx
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x180], rax
       mov      r8, gword ptr [rbp-0x180]
       mov      rsi, bword ptr [rbp-0x128]
       mov      rdx, qword ptr [rbp-0x120]
       mov      rcx, gword ptr [rbp-0x38]
       mov      rdi, gword ptr [rbp-0x30]
       mov      r9, bword ptr [rbp-0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartBoundIntegerReturn(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG16
       mov      dword ptr [rbp-0x7C], 1
       jmp      G_M000_IG24
 
G_M000_IG16:                ;; offset=0x041E
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG18
       mov      rax, bword ptr [rbp-0x08]
       movzx    rax, byte  ptr [rax+0x48]
       test     eax, eax
       je       SHORT G_M000_IG17
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0xDC], eax
       jmp      SHORT G_M000_IG19
 
G_M000_IG17:                ;; offset=0x044E
       xor      eax, eax
       mov      dword ptr [rbp-0xDC], eax
       jmp      SHORT G_M000_IG19
 
G_M000_IG18:                ;; offset=0x0458
       mov      dword ptr [rbp-0xDC], 1
 
G_M000_IG19:                ;; offset=0x0462
       movzx    rax, byte  ptr [rbp-0xDC]
       mov      dword ptr [rbp-0x6C], eax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG20
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_LastOwnedTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x14]
       jge      SHORT G_M000_IG20
       mov      rdi, bword ptr [rbp-0x68]
       mov      rsi, qword ptr [rbp-0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x118], rax
       mov      qword ptr [rbp-0x110], rdx
       mov      eax, dword ptr [rbp-0x14]
       mov      dword ptr [rsp], eax
       mov      eax, dword ptr [rbp-0x6C]
       mov      dword ptr [rsp+0x08], eax
       movzx    rax, byte  ptr [rbp-0x50]
       mov      dword ptr [rsp+0x10], eax
       mov      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rsp+0x18], rax
       lea      rax, [rbp-0x78]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp-0x118]
       mov      r8, qword ptr [rbp-0x110]
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdx, gword ptr [rbp-0x10]
       mov      r9, gword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StartNativeFixedReturn(Lokad.Lython.Runtime.PyExecutableFunction,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,int,bool,bool,byref,byref):this]
       jmp      G_M000_IG21
 
G_M000_IG20:                ;; offset=0x0501
       mov      rdi, bword ptr [rbp-0x68]
       mov      rsi, qword ptr [rbp-0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0xF0], rax
       mov      qword ptr [rbp-0xE8], rdx
       mov      rax, bword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0xF8], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x100], rax
       movzx    rax, byte  ptr [rbp-0x50]
       mov      dword ptr [rbp-0x104], eax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
       mov      rax, gword ptr [rbp-0x100]
       mov      gword ptr [rsp], rax
       mov      eax, dword ptr [rbp-0x6C]
       mov      dword ptr [rsp+0x08], eax
       mov      eax, dword ptr [rbp-0x104]
       mov      dword ptr [rsp+0x10], eax
       lea      rdi, [rsp+0x18]
       lea      rsi, [rbp-0x98]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x18], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rax, [rbp-0x88]
       mov      qword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x78]
       mov      qword ptr [rsp+0x38], rax
       mov      rdx, bword ptr [rbp-0xF0]
       mov      rcx, qword ptr [rbp-0xE8]
       mov      rdi, gword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x38]
       mov      r9, gword ptr [rbp-0xF8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
 
G_M000_IG21:                ;; offset=0x05D6
       cmp      gword ptr [rbp-0x78], 0
       je       SHORT G_M000_IG22
       mov      rax, bword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp-0x78]
       mov      gword ptr [rax+0x20], rcx
       mov      rdi, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      gword ptr [rcx+0x28], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x54], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x7C], eax
       jmp      SHORT G_M000_IG25
 
G_M000_IG22:                ;; offset=0x0614
       call     G_M000_IG31
       jmp      SHORT G_M000_IG26
 
G_M000_IG23:                ;; offset=0x061B
       call     G_M000_IG31
       jmp      SHORT G_M000_IG28
 
G_M000_IG24:                ;; offset=0x0622
       call     G_M000_IG31
       jmp      SHORT G_M000_IG28
 
G_M000_IG25:                ;; offset=0x0629
       call     G_M000_IG31
       jmp      SHORT G_M000_IG28
 
G_M000_IG26:                ;; offset=0x0630
       mov      eax, 1
 
G_M000_IG27:                ;; offset=0x0635
       add      rsp, 464
       pop      rbp
       ret      
 
G_M000_IG28:                ;; offset=0x063E
       mov      eax, dword ptr [rbp-0x7C]
 
G_M000_IG29:                ;; offset=0x0641
       add      rsp, 464
       pop      rbp
       ret      
 
G_M000_IG30:                ;; offset=0x064A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG31:                ;; offset=0x0650
       sub      rsp, 72
 
G_M000_IG32:                ;; offset=0x0654
       cmp      dword ptr [rbp-0x54], 0
       je       SHORT G_M000_IG33
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG33:                ;; offset=0x066A
       nop      
 
G_M000_IG34:                ;; offset=0x066B
       add      rsp, 72
       ret      
 
; Total bytes of code 1648

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 464
       lea      rbp, [rsp+0x1D0]
       xor      eax, eax
       mov      qword ptr [rbp-0x188], rax
       vxorps   xmm8, xmm8, xmm8
       mov      rax, -336
 
G_M000_IG42:                ;; offset=0x0028
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG42
       mov      qword ptr [rbp-0x30], rax
       mov      bword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      dword ptr [rbp-0x14], edx
       mov      gword ptr [rbp-0x20], rcx
       mov      bword ptr [rbp-0x28], r8
 
G_M000_IG02:                ;; offset=0x0057
       mov      rax, 0x7F4E058009B0
       mov      rdi, gword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      gword ptr [rbp-0xA8], rax
       mov      qword ptr [rbp-0xA0], rdx
       mov      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rbp-0x188], rax
       mov      rdi, bword ptr [rbp-0x188]
       mov      rsi, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0x188]
       mov      rcx, qword ptr [rbp-0xA0]
       mov      qword ptr [rax+0x08], rcx
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CurrentRecursionDepth():long:this]
       cmp      rax, 8
       jl       SHORT G_M000_IG04
       mov      rdi, 0x7F5DB003E060
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x00DA
       add      rsp, 464
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x00E3
       mov      rsi, gword ptr [rbp-0x20]
       mov      rdi, 0x7F5DAF71CEB0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x30], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG06
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0x148], rax
       mov      rax, bword ptr [rbp-0x148]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x14], eax
       jae      G_M000_IG37
       mov      rax, bword ptr [rbp-0x148]
       mov      ecx, dword ptr [rbp-0x14]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x158], rax
       mov      rsi, gword ptr [rbp-0x158]
       mov      rdi, 0x7F5DAF4A5F20
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG07
 
G_M000_IG05:                ;; offset=0x016E
       mov      rdi, 0x7F5DB003E064
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG06:                ;; offset=0x017D
       xor      rax, rax
       mov      gword ptr [rbp-0xB0], rax
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x0188
       mov      rdi, 0x7F5DB003E068
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0x150], rax
       mov      rax, bword ptr [rbp-0x150]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x14], eax
       jae      G_M000_IG37
       mov      rax, bword ptr [rbp-0x150]
       mov      ecx, dword ptr [rbp-0x14]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0xB0], rax
 
G_M000_IG08:                ;; offset=0x01E0
       mov      rax, gword ptr [rbp-0xB0]
       mov      gword ptr [rbp-0x38], rax
       mov      rsi, gword ptr [rbp-0x20]
       mov      rdi, 0x7F5DAF7433F8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x40], rax
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG09
       mov      rdi, gword ptr [rbp-0x40]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Function():Lokad.Lython.Runtime.LythonRuntime+ICallable:this]
       mov      gword ptr [rbp-0x160], rax
       mov      rsi, gword ptr [rbp-0x160]
       mov      rdi, 0x7F5DAF71CEB0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       SHORT G_M000_IG13
       mov      rdi, 0x7F5DB003E06C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x48]
       mov      gword ptr [rbp-0x30], rax
       mov      rdi, gword ptr [rbp-0x40]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyBoundMethod:get_Receiver():System.Object:this]
       mov      gword ptr [rbp-0x38], rax
 
G_M000_IG09:                ;; offset=0x0264
       cmp      gword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG11
       lea      rcx, [rbp-0x50]
       mov      rdi, gword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rdx, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG14
 
G_M000_IG10:                ;; offset=0x0287
       mov      rdi, 0x7F5DB003E070
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x0296
       mov      rdi, 0x7F5DB003E074
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG12:                ;; offset=0x02A7
       add      rsp, 464
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x02B0
       mov      rdi, 0x7F5DB003E078
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG09
 
G_M000_IG14:                ;; offset=0x02C1
       mov      rax, bword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x168], rax
       mov      rsi, gword ptr [rbp-0x168]
       mov      rdi, gword ptr [rbp-0xB8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x54], 1
 
G_M000_IG15:                ;; offset=0x0300
       mov      rax, bword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x08]
       add      rax, 80
       mov      bword ptr [rbp-0xC0], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x14]
       mov      dword ptr [rbp-0xC4], eax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x16C], eax
       mov      edx, dword ptr [rbp-0x16C]
       mov      esi, dword ptr [rbp-0xC4]
       mov      rdi, bword ptr [rbp-0xC0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0xD8], rax
       mov      qword ptr [rbp-0xD0], rdx
 
G_M000_IG16:                ;; offset=0x0363
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rbp-0x68], xmm0
 
G_M000_IG17:                ;; offset=0x0370
       cmp      gword ptr [rbp-0x38], 0
       jne      G_M000_IG18
       mov      rdi, bword ptr [rbp-0x68]
       mov      rsi, qword ptr [rbp-0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x138], rax
       mov      qword ptr [rbp-0x130], rdx
       mov      rax, bword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x140], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x178], rax
       movzx    rax, byte  ptr [rbp-0x50]
       mov      dword ptr [rsp], eax
       mov      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rsp+0x08], rax
       mov      r9, gword ptr [rbp-0x178]
       mov      rdx, bword ptr [rbp-0x138]
       mov      rcx, qword ptr [rbp-0x130]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x140]
       mov      rdi, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartNativeIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,byref):bool:this]
       test     eax, eax
       je       G_M000_IG22
       mov      rdi, 0x7F5DB003E07C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x7C], 1
       jmp      G_M000_IG30
 
G_M000_IG18:                ;; offset=0x0418
       movzx    rax, byte  ptr [rbp-0x50]
       test     eax, eax
       je       G_M000_IG21
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       jne      G_M000_IG20
       mov      rdi, bword ptr [rbp-0x68]
       mov      rsi, qword ptr [rbp-0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x128], rax
       mov      qword ptr [rbp-0x120], rdx
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x180], rax
       mov      r8, gword ptr [rbp-0x180]
       mov      rsi, bword ptr [rbp-0x128]
       mov      rdx, qword ptr [rbp-0x120]
       mov      rcx, gword ptr [rbp-0x38]
       mov      rdi, gword ptr [rbp-0x30]
       mov      r9, bword ptr [rbp-0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartBoundIntegerReturn(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG19
       mov      rdi, 0x7F5DB003E080
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x7C], 1
       jmp      G_M000_IG31
 
G_M000_IG19:                ;; offset=0x04AF
       mov      rdi, 0x7F5DB003E084
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x04C0
       mov      rdi, 0x7F5DB003E088
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x04D1
       mov      rdi, 0x7F5DB003E08C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x04E0
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG24
       mov      rax, bword ptr [rbp-0x08]
       movzx    rax, byte  ptr [rax+0x48]
       test     eax, eax
       je       SHORT G_M000_IG23
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0xDC], eax
       jmp      SHORT G_M000_IG25
 
G_M000_IG23:                ;; offset=0x0510
       mov      rdi, 0x7F5DB003E090
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0xDC], eax
       jmp      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0529
       mov      rdi, 0x7F5DB003E094
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xDC], 1
 
G_M000_IG25:                ;; offset=0x0542
       movzx    rax, byte  ptr [rbp-0xDC]
       mov      dword ptr [rbp-0x6C], eax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG27
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_LastOwnedTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x14]
       jge      SHORT G_M000_IG26
       mov      rdi, 0x7F5DB003E098
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x68]
       mov      rsi, qword ptr [rbp-0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x118], rax
       mov      qword ptr [rbp-0x110], rdx
       mov      eax, dword ptr [rbp-0x14]
       mov      dword ptr [rsp], eax
       mov      eax, dword ptr [rbp-0x6C]
       mov      dword ptr [rsp+0x08], eax
       movzx    rax, byte  ptr [rbp-0x50]
       mov      dword ptr [rsp+0x10], eax
       mov      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rsp+0x18], rax
       lea      rax, [rbp-0x78]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp-0x118]
       mov      r8, qword ptr [rbp-0x110]
       mov      rdi, bword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdx, gword ptr [rbp-0x10]
       mov      r9, gword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StartNativeFixedReturn(Lokad.Lython.Runtime.PyExecutableFunction,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,int,bool,bool,byref,byref):this]
       jmp      G_M000_IG28
 
G_M000_IG26:                ;; offset=0x05F0
       mov      rdi, 0x7F5DB003E09C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG27:                ;; offset=0x05FF
       mov      rdi, bword ptr [rbp-0x68]
       mov      rsi, qword ptr [rbp-0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0xF0], rax
       mov      qword ptr [rbp-0xE8], rdx
       mov      rax, bword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0xF8], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x100], rax
       movzx    rax, byte  ptr [rbp-0x50]
       mov      dword ptr [rbp-0x104], eax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
       mov      rax, gword ptr [rbp-0x100]
       mov      gword ptr [rsp], rax
       mov      eax, dword ptr [rbp-0x6C]
       mov      dword ptr [rsp+0x08], eax
       mov      eax, dword ptr [rbp-0x104]
       mov      dword ptr [rsp+0x10], eax
       lea      rdi, [rsp+0x18]
       lea      rsi, [rbp-0x98]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x18], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rax, [rbp-0x88]
       mov      qword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x78]
       mov      qword ptr [rsp+0x38], rax
       mov      rdx, bword ptr [rbp-0xF0]
       mov      rcx, qword ptr [rbp-0xE8]
       mov      rdi, gword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x38]
       mov      r9, gword ptr [rbp-0xF8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
 
G_M000_IG28:                ;; offset=0x06D4
       cmp      gword ptr [rbp-0x78], 0
       je       SHORT G_M000_IG29
       mov      rax, bword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp-0x78]
       mov      gword ptr [rax+0x20], rcx
       mov      rdi, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      rcx, bword ptr [rbp-0x08]
       mov      gword ptr [rcx+0x28], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x54], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x7C], eax
       jmp      SHORT G_M000_IG32
 
G_M000_IG29:                ;; offset=0x0712
       call     G_M000_IG38
       jmp      SHORT G_M000_IG33
 
G_M000_IG30:                ;; offset=0x0719
       call     G_M000_IG38
       jmp      SHORT G_M000_IG35
 
G_M000_IG31:                ;; offset=0x0720
       call     G_M000_IG38
       jmp      SHORT G_M000_IG35
 
G_M000_IG32:                ;; offset=0x0727
       call     G_M000_IG38
       jmp      SHORT G_M000_IG35
 
G_M000_IG33:                ;; offset=0x072E
       mov      rdi, 0x7F5DB003E0A8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG34:                ;; offset=0x0742
       add      rsp, 464
       pop      rbp
       ret      
 
G_M000_IG35:                ;; offset=0x074B
       mov      rdi, 0x7F5DB003E0AC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x7C]
 
G_M000_IG36:                ;; offset=0x075D
       add      rsp, 464
       pop      rbp
       ret      
 
G_M000_IG37:                ;; offset=0x0766
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG38:                ;; offset=0x076C
       sub      rsp, 72
 
G_M000_IG39:                ;; offset=0x0770
       cmp      dword ptr [rbp-0x54], 0
       je       SHORT G_M000_IG40
       mov      rdi, 0x7F5DB003E0A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG40:                ;; offset=0x0795
       mov      rdi, 0x7F5DB003E0A4
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG41:                ;; offset=0x07A5
       add      rsp, 72
       ret      
 
; Total bytes of code 1962

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 1052
; 9 inlinees with PGO data; 64 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 168
       lea      rbp, [rsp+0xD0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqa  xmmword ptr [rbp-0x40], xmm8
       mov      bword ptr [rbp-0x68], rdi
       mov      rbx, rsi
       mov      r15d, edx
       mov      r13, rcx
       mov      r14, r8
 
G_M000_IG02:                ;; offset=0x0038
       mov      rsi, 0x7F4E058009B0
       mov      rsi, gword ptr [rsi]
       mov      rdi, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      edi, edi
       mov      qword ptr [r14+0x08], rdi
       mov      rdi, bword ptr [rbp-0x68]
       mov      rax, gword ptr [rdi+0x18]
       mov      rax, gword ptr [rax+0x98]
       cmp      qword ptr [rax+0x158], 8
       jge      G_M000_IG52
       test     r13, r13
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0075
       mov      rax, 0x7F5DAF71CEB0
       cmp      qword ptr [r13], rax
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0085
       mov      r12, r13
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x008A
       xor      r12, r12
 
G_M000_IG06:                ;; offset=0x008D
       cmp      byte  ptr [rbx+0x30], 0
       je       G_M000_IG38
       lea      rax, bword ptr [rdi+0x50]
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      ecx, r15d
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rax, gword ptr [rcx]
       mov      rdx, 0x7F4E05801308
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rbp-0x88], rdx
       cmp      rax, rdx
       je       G_M000_IG36
 
G_M000_IG07:                ;; offset=0x00CF
       mov      rsi, 0x7F4E05801310
       cmp      rax, gword ptr [rsi]
       je       G_M000_IG45
       cmp      qword ptr [rcx+0x08], 0
       jne      G_M000_IG46
 
G_M000_IG08:                ;; offset=0x00ED
       test     rax, rax
       jne      G_M000_IG37
 
G_M000_IG09:                ;; offset=0x00F6
       mov      rdi, bword ptr [rbp-0x68]
       lea      rax, bword ptr [rdi+0x50]
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      ecx, r15d
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdx, gword ptr [rbp-0x88]
       cmp      gword ptr [rcx], rdx
       je       G_M000_IG39
 
G_M000_IG10:                ;; offset=0x0122
       mov      rax, gword ptr [rcx]
       mov      rdx, 0x7F4E05801310
       cmp      rax, gword ptr [rdx]
       je       G_M000_IG47
       cmp      qword ptr [rcx+0x08], 0
       jne      G_M000_IG48
       mov      rax, gword ptr [rcx]
 
G_M000_IG11:                ;; offset=0x0146
       test     r13, r13
       je       SHORT G_M000_IG17
 
G_M000_IG12:                ;; offset=0x014B
       mov      rsi, 0x7F5DAF7433F8
       cmp      qword ptr [r13], rsi
       jne      SHORT G_M000_IG17
 
G_M000_IG13:                ;; offset=0x015B
       mov      rsi, gword ptr [r13+0x10]
       test     rsi, rsi
       je       SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x0164
       mov      rcx, 0x7F5DAF71CEB0
       xor      rdx, rdx
       cmp      qword ptr [rsi], rcx
       cmovne   rsi, rdx
 
G_M000_IG15:                ;; offset=0x0177
       test     rsi, rsi
       je       SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x017C
       mov      r12, rsi
       mov      rax, gword ptr [r13+0x08]
 
G_M000_IG17:                ;; offset=0x0183
       test     r12, r12
       je       G_M000_IG52
       mov      rsi, gword ptr [r12+0x40]
       cmp      byte  ptr [rsi+0xDF], 0
       je       G_M000_IG52
       mov      rcx, gword ptr [r12+0x28]
       cmp      byte  ptr [rcx+0xFA], 0
       jne      G_M000_IG52
       cmp      byte  ptr [rcx+0xFB], 0
       jne      G_M000_IG52
       cmp      byte  ptr [rcx+0xFC], 0
       jne      G_M000_IG52
       cmp      gword ptr [rcx+0xC0], 0
       jne      G_M000_IG52
       cmp      dword ptr [rsi+0xD4], 16
       jg       G_M000_IG52
       cmp      byte  ptr [rbx+0x34], 0
       je       G_M000_IG49
       mov      esi, dword ptr [rbx+0x28]
       mov      rcx, gword ptr [r12+0x08]
       cmp      byte  ptr [rcx+0x54], 0
       je       G_M000_IG40
 
G_M000_IG18:                ;; offset=0x0201
       mov      ecx, dword ptr [rcx+0x3C]
       mov      gword ptr [rbp-0x70], rax
       test     rax, rax
       setne    dl
       movzx    rdx, dl
       sub      ecx, edx
       cmp      ecx, esi
       sete     r13b
       movzx    r13, r13b
 
G_M000_IG19:                ;; offset=0x021D
       test     r13d, r13d
       je       G_M000_IG41
 
G_M000_IG20:                ;; offset=0x0226
       mov      rdi, bword ptr [rbp-0x68]
       mov      rsi, gword ptr [rdi+0x18]
       mov      rcx, gword ptr [rbx+0x18]
       mov      rdi, gword ptr [rsi+0x98]
       mov      rsi, rcx
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x2C], 1
 
G_M000_IG21:                ;; offset=0x024B
       mov      rdi, bword ptr [rbp-0x68]
       lea      rcx, bword ptr [rdi+0x50]
       cmp      byte  ptr [rbx+0x30], 0
       setne    sil
       movzx    rsi, sil
       lea      esi, [r15+rsi+0x01]
       mov      eax, dword ptr [rbx+0x28]
       mov      dword ptr [rbp-0x44], eax
       mov      edx, esi
       mov      r8d, eax
       add      rdx, r8
       mov      r8d, dword ptr [rcx+0x08]
       cmp      rdx, r8
       ja       G_M000_IG24
       mov      r8d, esi
       shl      r8, 4
       add      r8, bword ptr [rcx]
       mov      bword ptr [rbp-0x80], r8
       mov      r9, gword ptr [rbp-0x70]
       test     r9, r9
       je       G_M000_IG25
       test     r13d, r13d
       je       G_M000_IG26
       cmp      dword ptr [rbx+0x2C], 0
       jne      G_M000_IG26
       mov      rsi, gword ptr [rbx+0x18]
       mov      gword ptr [rbp-0x78], rsi
       xor      ecx, ecx
       mov      qword ptr [r14], rcx
       mov      qword ptr [r14+0x08], rcx
       mov      rcx, gword ptr [r12+0x40]
       cmp      byte  ptr [rcx+0xE0], 0
       je       G_M000_IG26
       lea      edx, [rax+0x01]
       cmp      edx, dword ptr [rcx+0xC4]
       jne      G_M000_IG26
       mov      gword ptr [rbp-0x70], r9
       mov      gword ptr [rbp-0x60], r9
       mov      bword ptr [rbp-0x58], r8
       mov      dword ptr [rbp-0x50], eax
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x60]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, r12
       mov      rsi, gword ptr [rbp-0x78]
       mov      rdx, r14
 
G_M000_IG22:                ;; offset=0x0321
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+BoundIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+BoundIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       mov      eax, dword ptr [rbp-0x44]
       mov      r8, bword ptr [rbp-0x80]
       mov      r9, gword ptr [rbp-0x70]
       je       SHORT G_M000_IG26
 
G_M000_IG23:                ;; offset=0x0336
       mov      eax, 1
       jmp      G_M000_IG33
 
G_M000_IG24:                ;; offset=0x0340
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG25:                ;; offset=0x0347
       mov      gword ptr [rbp-0x70], r9
       mov      rdi, r8
       mov      esi, eax
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      ecx, edx
       mov      dword ptr [rsp], r13d
       mov      bword ptr [rsp+0x08], r14
       mov      rdi, bword ptr [rbp-0x68]
       mov      r8, gword ptr [rdi+0x18]
       mov      r9, gword ptr [rbx+0x18]
       mov      rdx, rax
       mov      rdi, r12
       mov      rsi, rbx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartNativeIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,byref):bool:this]
       test     eax, eax
       mov      eax, dword ptr [rbp-0x44]
       mov      r8, bword ptr [rbp-0x80]
       mov      r9, gword ptr [rbp-0x70]
       jne      SHORT G_M000_IG23
 
G_M000_IG26:                ;; offset=0x038B
       cmp      byte  ptr [rbx+0x31], 0
       jne      SHORT G_M000_IG28
       mov      rdi, bword ptr [rbp-0x68]
       cmp      byte  ptr [rdi+0x48], 0
       je       SHORT G_M000_IG27
       movzx    rcx, byte  ptr [rbx+0x32]
       jmp      SHORT G_M000_IG29
 
G_M000_IG27:                ;; offset=0x03A1
       xor      ecx, ecx
       jmp      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x03A5
       mov      ecx, 1
       mov      rdi, bword ptr [rbp-0x68]
 
G_M000_IG29:                ;; offset=0x03AE
       mov      dword ptr [rbp-0x30], ecx
       cmp      dword ptr [rbx+0x2C], 0
       je       SHORT G_M000_IG30
       mov      rsi, gword ptr [rdi+0x08]
       cmp      dword ptr [rsi+0xC8], r15d
       mov      gword ptr [rbp-0x70], r9
       jge      SHORT G_M000_IG31
       mov      rdi, r8
       mov      esi, eax
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rcx, rax
       mov      r8d, edx
       mov      dword ptr [rsp], r15d
       mov      r15d, dword ptr [rbp-0x30]
       mov      dword ptr [rsp+0x08], r15d
       mov      dword ptr [rsp+0x10], r13d
       mov      bword ptr [rsp+0x18], r14
       lea      rdi, [rbp-0x38]
       mov      qword ptr [rsp+0x20], rdi
       mov      rdi, bword ptr [rbp-0x68]
       mov      rsi, r12
       mov      rdx, rbx
       mov      r9, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StartNativeFixedReturn(Lokad.Lython.Runtime.PyExecutableFunction,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,int,bool,bool,byref,byref):this]
       jmp      SHORT G_M000_IG32
 
G_M000_IG30:                ;; offset=0x040F
       mov      gword ptr [rbp-0x70], r9
 
G_M000_IG31:                ;; offset=0x0413
       mov      rdi, r8
       mov      esi, eax
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      ecx, edx
       mov      rdi, bword ptr [rbp-0x68]
       mov      r9, gword ptr [rdi+0x18]
       mov      rdx, gword ptr [rbx+0x18]
       mov      gword ptr [rsp], rdx
       mov      r15d, dword ptr [rbp-0x30]
       mov      dword ptr [rsp+0x08], r15d
       mov      dword ptr [rsp+0x10], r13d
       xor      rdx, rdx
       xor      esi, esi
       mov      bword ptr [rsp+0x18], rdx
       mov      dword ptr [rsp+0x20], esi
       lea      rdx, [rbp-0x40]
       mov      qword ptr [rsp+0x28], rdx
       mov      bword ptr [rsp+0x30], r14
       lea      rdx, [rbp-0x38]
       mov      qword ptr [rsp+0x38], rdx
       mov      rdx, rax
       mov      rdi, r12
       mov      rsi, rbx
       mov      r8, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
 
G_M000_IG32:                ;; offset=0x0475
       cmp      gword ptr [rbp-0x38], 0
       je       G_M000_IG54
       mov      rax, gword ptr [rbp-0x38]
       mov      rdi, bword ptr [rbp-0x68]
       mov      gword ptr [rdi+0x20], rax
       mov      rax, gword ptr [r12+0x28]
       mov      rax, gword ptr [rax+0x98]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rdi+0x28], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
 
G_M000_IG33:                ;; offset=0x04A8
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG35
       mov      rdi, bword ptr [rbp-0x68]
       mov      rbx, gword ptr [rdi+0x18]
       mov      r15, gword ptr [rbx+0x98]
       mov      rcx, qword ptr [r15+0x160]
       test     rcx, rcx
       jle      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x04C9
       dec      rcx
       mov      qword ptr [r15+0x160], rcx
 
G_M000_IG35:                ;; offset=0x04D3
       add      rsp, 168
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG36:                ;; offset=0x04E5
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       jmp      G_M000_IG08
 
G_M000_IG37:                ;; offset=0x04F3
       mov      rcx, 0x7F5DAF4A5F20
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG09
 
G_M000_IG38:                ;; offset=0x0506
       mov      rdi, bword ptr [rbp-0x68]
       xor      rax, rax
       jmp      G_M000_IG11
 
G_M000_IG39:                ;; offset=0x0511
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       jmp      G_M000_IG11
 
G_M000_IG40:                ;; offset=0x051F
       xor      r13d, r13d
       mov      gword ptr [rbp-0x70], rax
       jmp      G_M000_IG19
 
G_M000_IG41:                ;; offset=0x052B
       mov      rcx, gword ptr [r12+0x08]
       mov      rsi, gword ptr [rcx+0x08]
       cmp      dword ptr [rsi+0x08], 16
       jg       G_M000_IG52
       cmp      dword ptr [rcx+0x4C], 0
       jge      G_M000_IG52
       cmp      dword ptr [rcx+0x50], 0
       jge      G_M000_IG52
       mov      rsi, gword ptr [r12+0x18]
       test     rsi, rsi
       je       SHORT G_M000_IG44
 
G_M000_IG42:                ;; offset=0x055C
       mov      rcx, rsi
       mov      rdx, 0x7F5DAF764450
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG50
 
G_M000_IG43:                ;; offset=0x056E
       test     rcx, rcx
       je       G_M000_IG52
 
G_M000_IG44:                ;; offset=0x0577
       mov      rdi, r12
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       test     rax, rax
       je       G_M000_IG20
       jmp      SHORT G_M000_IG51
 
G_M000_IG45:                ;; offset=0x058B
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       jmp      G_M000_IG08
 
G_M000_IG46:                ;; offset=0x0599
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       jmp      G_M000_IG08
 
G_M000_IG47:                ;; offset=0x05A7
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       jmp      G_M000_IG11
 
G_M000_IG48:                ;; offset=0x05B5
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       jmp      G_M000_IG11
 
G_M000_IG49:                ;; offset=0x05C3
       xor      r13d, r13d
       mov      gword ptr [rbp-0x70], rax
       jmp      G_M000_IG19
 
G_M000_IG50:                ;; offset=0x05CF
       mov      rdi, 0x7F5DAF5808D0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rcx, rax
       jmp      SHORT G_M000_IG43
 
G_M000_IG51:                ;; offset=0x05E3
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       sete     dil
       movzx    rdi, dil
       test     edi, edi
       je       G_M000_IG20
 
G_M000_IG52:                ;; offset=0x05FE
       xor      eax, eax
 
G_M000_IG53:                ;; offset=0x0600
       add      rsp, 168
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG54:                ;; offset=0x0612
       call     G_M000_IG58
       nop      
 
G_M000_IG55:                ;; offset=0x0618
       mov      eax, 1
 
G_M000_IG56:                ;; offset=0x061D
       add      rsp, 168
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG57:                ;; offset=0x062F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG58:                ;; offset=0x0635
       sub      rsp, 72
 
G_M000_IG59:                ;; offset=0x0639
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG61
       mov      rdi, bword ptr [rbp-0x68]
       mov      rbx, gword ptr [rdi+0x18]
       mov      r15, gword ptr [rbx+0x98]
       mov      rax, qword ptr [r15+0x160]
       test     rax, rax
       jle      SHORT G_M000_IG61
 
G_M000_IG60:                ;; offset=0x065A
       dec      rax
       mov      qword ptr [r15+0x160], rax
 
G_M000_IG61:                ;; offset=0x0664
       add      rsp, 72
       ret      
 
; Total bytes of code 1641

