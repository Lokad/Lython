from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
p=lab.with_name('invoice-activation-profile-20261125')
up=lab.with_name('ordinary-definition-effects-20261125')
q=up/'external'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,value): path.write_text(value,encoding='utf-8',newline='\n')
def save(path,value): write(path,json.dumps(value,indent=2)+'\n')
old=read(q/'identity.json')
receipt=read(q/'terminal-status.json')['receipt']
assert receipt['complete'] and sha(q/'observations.tar.xz')==receipt['archiveSHA256']
source=old['sourceRevision']
assert source.startswith('857cc8001')
assert subprocess.check_output(['git','diff','--name-only',source,'HEAD','--','src','tests',
    'benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py'],cwd=repo)==b''
image=up/'candidate'
files=old['imageFiles']['candidate']
assert len(files)==32 and {x.name:sha(x) for x in image.iterdir()}==files
shutil.copyfile(q/'representative.json',lab/'catalog.json')
shutil.copyfile(q/'candidate-verify.json',lab/'candidate-verification.json')
checked=read(lab/'candidate-verification.json')
assert checked['state']=='Completed' and checked['caseCount']==2 and checked['catalogSha256']==sha(lab/'catalog.json')
assert checked['launched']['library']['sha256']==files['Lokad.Lython.dll']
catalog=read(lab/'catalog.json')
assert len(catalog['cases'])==2
profiles=[[label,case['id'],'candidate'] for label,case in zip(('definitions-warm','effects-warm'),catalog['cases'],strict=True)]
save(lab/'identity.json',dict(sourceRevision=source,measurementReference=source,imageFiles={'candidate':files},
    coreSHA256={'candidate':files['Lokad.Lython.dll']},cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    profiles=profiles,purpose='Attribute warm default evaluation and executable operand transport',
    donorArchiveSHA256=receipt['archiveSHA256'],profileCatalogSHA256=sha(lab/'catalog.json')))
for name in ('collect.py','quiet.py','ops-profile.py','analyze.py','archive.py','find-archived-duplicates.py','run.sh'):
 txt=(p/name).read_text(encoding='utf-8')
 txt=txt.replace('private-definition-admission-b1721-20261125','ordinary-definition-effects-b1728-20261125')
 txt=txt.replace('private-definition-admission-20261125','ordinary-definition-effects-20261125')
 txt=txt.replace('invoice-activation-profile-b1723-20261125','default-effects-cpu-b1729-20261125')
 txt=txt.replace('lython-b1723-invoice-activation-profile','lython-b1729-default-effects-cpu')
 txt=txt.replace('b1723-fixtures','b1729-fixtures').replace('Staged two invoice profiles','Staged definition and effects profiles')
 txt=txt.replace('checked["caseCount"]==1','checked["caseCount"]==2')
 txt=txt.replace('        count = 256','        count = 512')
 if name=='archive.py':
  txt=txt.replace('2026-11-25-invoice-activation-profile','2026-11-25-default-effects-cpu')
  txt=txt.replace('startswith("93eead293")','startswith("857cc8001")')
  txt=txt.replace(',"instruction-layout.json"','')
  txt=txt.replace('"inventory.log", "inventory.py",','"inventory.log",')
  txt=txt.replace('"prepare.log", "inspection.log", "inspection/Program.cs", "inspection/InvoiceInspection.csproj"', '"prepare.log"')
 if name.endswith('.py'): compile(txt,name,'exec')
 write(lab/name,txt)
assert b'\r' not in (lab/'run.sh').read_bytes()
assert b'\r' not in (lab/'ops-profile.py').read_bytes()
print('Two checked warm profiles on the complete and default-effects scripts.')
