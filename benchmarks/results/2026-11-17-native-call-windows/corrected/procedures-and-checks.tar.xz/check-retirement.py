from pathlib import Path
import json,subprocess
r=Path(__file__).parent;q=r/'quiet';c=json.loads((q/'config.json').read_text(encoding='utf-8'))
code='''from pathlib import Path
import hashlib,json,os
b=Path('/home/lokad/lython-bench-checks');groups=GROUPS;rows=[]
for proof in groups:
 for n in proof['paths']:
  p=b/n
  if not p.exists():rows.append(dict(path=n,absent=True));continue
  m=p.lstat();actual=dict(bytes=m.st_size,links=m.st_nlink,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),uid=m.st_uid)
  rows.append(dict(path=n,actual=actual,mismatch={k:[proof[k],actual[k]]for k in ['bytes','links','sha256']if proof[k]!=actual[k]}))
print(json.dumps(rows))
'''.replace('GROUPS',repr(c['retireGroups']))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stderr;(q/'failed-proof-inspection.json').write_text(p.stdout,encoding='utf-8');print(p.stdout)
