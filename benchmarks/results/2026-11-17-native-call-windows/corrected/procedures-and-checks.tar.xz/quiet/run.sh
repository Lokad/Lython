set -eu
root=/home/lokad/lython-bench-checks/call-window-corrected-b897-20261117
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
