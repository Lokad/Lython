from pathlib import Path
import json,shutil
r=Path(__file__).parent;repo=Path('D:/code/Lython');d=r/'delivery';record=json.loads((d/'dispatch.json').read_text(encoding='utf-8'));run=record['run'];head=record['head'];assert run==44072440304 and head.startswith('abd3c788')
source=(r.parent.parent/'scalar-index-r453/finish-delivery.py').read_text(encoding='utf-8').split('out=repo/')[0]
source=source.replace('43936505308',str(run)).replace("terminal['headSha'].startswith('be176ed0')","terminal['headSha']=="+repr(head)).replace('[14,406,4808,17938]','[14,406,4820,18013]').replace('2370','2382').replace('584','585')
source=source.replace('benchmarks/results/2026-11-16-scalar-index-transport/candidate-sources.tar.xz','benchmarks/results/2026-11-17-native-call-windows/corrected/candidate-sources.tar.xz')
exec(compile(source,str(__file__),'exec'),{'__file__':str(__file__),'__name__':'__main__'})
v=json.loads((d/'qualification.json').read_text(encoding='utf-8'));assert v['conclusion']=='success'
out=repo/'benchmarks/results/2026-11-17-native-call-windows/delivery-corrected';out.mkdir(exist_ok=False)
for n in ['terminal.json','qualification.json','inputs.json','inputs.tar.xz','run-logs.zip']:shutil.copyfile(d/n,out/n)
(out/'README.md').write_text(f'''# Corrected caller-window delivery

GREEN [CI{run}](https://github.com/Lokad/Lython/actions/runs/{run}) at {head[:8]}.
Windows/Ubuntu actual .NET11/10 each pass 4820 internal / 18013 public ordinary
tests, original 14 / 406 stress tests and installed explicit Release package
consumers. All 16 summaries, 2382 committed inputs and 585 production files are
verified against corrected frozen source. Rebuilt binary equality is not inferred.

The first failed delivery remains preserved. Reused parameter storage now clears
before binding and after failure; later valid calls remain correct. Tight-budget
fixtures still require completed effects before later refusal, funded aliases and
awaited cleanup. No timeout, stress scale or containment assertion is weakened.

Corrected-source timing is recorded separately from the initial prototype.
Capacity/earlier-denial tradeoffs, original adverse evidence and unresolved fresh
measurements remain explicit. Broader performance work continues. Publication and
tagging remain held. Terminal/logs cached permanently; do not requery this run.

[Terminal](terminal.json), [verification](qualification.json),
[committed inputs](inputs.tar.xz), [logs](run-logs.zip).
''',encoding='utf-8',newline='\n')
p=out.parent/'decision.json';v=json.loads(p.read_text(encoding='utf-8'));v.update(fullDeliveryPending=False,qualifiedRun=run,qualifiedHead=head,correctedBindingRegression=True);p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
p=out.parent/'validation.json';v=json.loads(p.read_text(encoding='utf-8'));v.update(correctedFocusedEachActualTarget=dict(publicCases=124,internalCases=88),fullDelivery=f'GREEN{run}/{head[:8]}, Windows/Ubuntu actual11/10, originalstress, installedReleaseconsumers;16summaries/2382inputs/585production matched to corrected source',qualifiedRun=run);p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
p=out.parent/'README.md';s=p.read_text(encoding='utf-8').replace('**Retained; full delivery qualification pending.**','**Retained; corrected source [fully qualified](delivery-corrected/README.md).**');s+='\nCorrected source fully qualifies at '+head[:8]+' / [CI'+str(run)+'](delivery-corrected/README.md). The initial failed delivery remains preserved; initial-prototype timings do not describe the binding correction.\n';p.write_text(s,encoding='utf-8',newline='\n')
print('GREEN corrected delivery cached/verified:16summaries,2382committed inputs/585production. No publication, no inferred binary equality.')
