from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).parent;q=r/'quiet';repo=Path('D:/code/Lython');c=json.loads((q/'config.json').read_text(encoding='utf-8'));proof=c['retireGroups'][-1];assert proof['paths']==['whole-script-cpu-b191-20261104/observations.tgz']
blob=subprocess.check_output(['git','show','HEAD:'+proof['canonical']],cwd=repo);assert hashlib.sha256(blob).hexdigest()==proof['sha256']and blob==(repo/proof['canonical']).read_bytes()
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
b=Path('/home/lokad/lython-bench-checks');proof=PROOF;p=b/proof['paths'][0]
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not any(os.path.ismount(x)for x in b.glob('*/guest-fixtures'))
 m=p.lstat();assert p.resolve()==p and p.is_relative_to(b)and stat.S_ISREG(m.st_mode)and m.st_uid==0 and m.st_nlink==1 and m.st_size==proof['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256']
 aliases=[]
 for directory,dirs,names in os.walk(b):
  for name in names:
   x=Path(directory)/name;v=x.lstat()
   if(v.st_dev,v.st_ino)==(m.st_dev,m.st_ino):aliases.append(str(x.relative_to(b)))
 assert aliases==proof['paths']
 before=shutil.disk_usage(b).free
 subprocess.run(['sudo','-n','rm','--',str(p)],check=True)
 assert not p.exists()
 print(json.dumps(dict(retiredOnly=proof,verifiedUID=0,allAliases=aliases,freshIdleLease=True,canonicalCommittedBlobVerified=True,currentImagesAndToolchainsPreserved=True,freeBeforeBytes=before,freeAfterBytes=shutil.disk_usage(b).free)))
'''.replace('PROOF',repr(proof))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr;(q/'root-owned-replica-retirement.json').write_text(p.stdout,encoding='utf-8');print(p.stdout)
(q/'launch.log').rename(q/'initial-uid-guard.log');c['retireGroups']=c['retireGroups'][:-1];(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8');s=(q/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
