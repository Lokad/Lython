from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/call-operands-r470';out=repo/'benchmarks/results/2026-11-17-native-call-windows';out.mkdir(exist_ok=False)
receipt=json.loads((r/'quiet/archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']
first=out/'first-pair';first.mkdir()
for n in ['observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(r/'quiet'/n,first/n)
for n in ['summary.json','allocation-summary.json','candidate-sources.tar.xz','cpython-semantic-goldens.json']:shutil.copyfile(r/n,out/n)
shutil.copyfile(r/'frozen/identity.json',out/'identity.json')
(out/'candidate-core.dll.gz').write_bytes(gzip.compress((r/'frozen/candidate/Lokad.Lython.dll').read_bytes(),mtime=0))
(out/'prototype.patch.gz').write_bytes(gzip.compress(subprocess.check_output(['git','diff','--no-ext-diff','--binary'],cwd=work),mtime=0))
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
    for p in list(r.glob('*.py'))+list(r.glob('*.json'))+list(r.glob('*.log')):a.add(p,arcname=p.name)
    for p in (r/'quiet').rglob('*'):
        if p.is_file()and 'retrieved'not in p.parts and p.name not in ['observations.tgz','payload.tgz','Lokad.Lython.dll']:a.add(p,arcname=p.relative_to(r).as_posix())
validation=dict(eachActualWindowsTarget=dict(publicFocused=237,internalFocused=272),newObservablePublicCases=3,independentCPythonPrograms=3,adaptedDirectTestCalls=7,architectureCompatibilityWrapper=False,candidatePriorCatalogGoldens=13,actualFrozenBothCatalogGoldens=3,productionFilesChanged=6,copiedWorkerImageFiles=32,sourceInputs=2382,sharedBudgetBaselineRestored=True,fullDelivery='Private prototype; retention/qualification pending.',publicationHeld=True)
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf-8')
(out/'README.md').write_text('''# Native helper calls borrow admitted caller windows

R481/B895, 2026-11-17 UTC. **Private prototype; retention pending.** Qualified
d8611c85/frozen0315de0a versus 0ebab036 on 1390c110, six production files.
Ordinary positional calls reuse evaluated arguments as callee locals/operands.
The NativeValues fixed stack buffer and NoInlining StartNativeCall wrapper are
removed. Pattern storage, temporary ownership and unpacked outputs select a
disjoint admitted tail; other arguments retain native binding. Existing eight-
prefix eligibility bounds a fixed 128-slot tail. No growable arena, saved
activation array, offset-owner view, registry, new pool or execution route.

Borrowed locals are initialized before entry and cleared after actual users and
cleanup. Genuine suspension copies live values into the existing owned frame
before releasing the caller window. All managed stack checks remain. An invocation
with calls admits 3072 estimated extra bytes before allocation; earlier denial is
possible. Physical allocation/accounted peak are explicit costs, not hidden gains.

| Complete script | Phase | Elapsed change | Wider CPU change | Reference / candidate controls |
| --- | --- | ---: | ---: | ---: |
| Floating JSON report | Warm | **−4.64..−3.52%** | **−6.48..−4.57%** | 0.52 / 0.66% |
| Same | Compile and execute once | −2.17..+3.42% | −4.05..+3.96% | **5.27 / 0.42%** |
| Integer CSV invoice | Warm | −1.65..+2.35% | 0.00..+1.47% | 1.85 / 2.17% |
| Helper text | Warm | **+1.01..+5.78%** | **+0.80..+7.37%** | 0.59 / **4.12%** |
| Floating report | Compilation | −1.54..−0.43% | −1.38..−0.82% | 0.63 / 0.49% |

Natural-GC allocation increases 4096 B / 0.83% for floating, 2560 B / 0.061%
for CSV, and approximately 2678 B / 0.16% for text (minor diagnostic variation).
Accounted peaks increase 3072/3072/3584 B. Compiled balances are unchanged and all
shared allowances return to baseline. No allocation reduction or overall gain claim.

Each actual Windows .NET11/10 target passes 237 public and 272 internal focused
cases. Three new observable programs cover unassigned locals, nested/deep helpers,
live pattern guards and tuple returns; independent CPython3.13.2 agrees. Existing
tests preserve genuine I/O, cancellation, first refusal, retained aliases, defaults,
keyword protocols and awaited cleanup. Seven direct white-box calls now supply
independently funded caller windows; no production compatibility wrapper survives.
The cache-refusal fixture now admits its small working window and still refuses
the intended large cache with unchanged assertions. Original removed-wrapper build
failure, initial fixture failure and corrected arithmetic golden are preserved.
Both copied 32-file images pass actual three-case catalog goldens; candidate also
passes all 13 prior representative goldens. Full delivery is not claimed.

193.46 seconds, five jobs, quiet AzureF4as_v7/Ubuntu24.04.4/.NET11 RC3, normal GC/
tiering; six-second interleaved full-request warmups and five rotated sample rounds.
Warm clocks include Run, mediated RAM I/O, output/file goldens and previous-result
cleanup; exclude compilation/startup/reset/protocol/final cache disposal. Fresh
adds compilation and compiled-owner disposal. External CPU is wider. No CPython
ratio or embedding-tail/RSS/startup/async-I/O gain is inferred.

All image/golden/quiet/Closed/exit/join/archive checks pass; RAM removed and terminal
cached. Fresh path/UID/hash/link/all-alias proofs retire only 1287962 B of exact
committed older working evidence replicas, preserving current images/toolchains/
canonicals and 254/252 MiB floors. A local early-observation guard made no remote
request; the same collection was retrieved after its deadline. Publication held.

The numeric warm result supports the hypothesis; fresh and text remain unresolved
or adverse. One unchanged-image floating-fresh/text-warm confirmation with eight-
second warmups is justified. Do not erase the first text adversity or infer that
its moving candidate is the only cause. Retain/refine/withdraw remains explicit.

[Summary](summary.json), [allocation](allocation-summary.json),
[validation](validation.json), [independent programs](cpython-semantic-goldens.json),
[raw](first-pair/observations.tgz), [identity](identity.json),
[sources](candidate-sources.tar.xz), [prototype](prototype.patch.gz),
[core](candidate-core.dll.gz), [procedures and failures](procedures-and-checks.tar.xz).
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as stream:stream.write('''

R481/B895: [native helper caller windows](results/2026-11-17-native-call-windows/README.md), private six-file prototype removes NativeValues/NoInliningStartNativeCall and ordinary positional copy, no growable arena/saved activation framework. Added128 admitted slots per invocation with calls; allocation/peaks increase modestly. Floating warm −4.64..−3.52%/CPU−6.48..−4.57% with0.52/0.66% controls; fresh mixed/reference5.27% movement; text+1.01..+5.78% withcandidate4.12% movement; CSV mixed. Focused actual11/10 each237public/272internal, three independent semantic programs and all13candidate goldens pass. All original failures/adversity preserved; one unchanged floating-fresh/text-warm confirmation justified, no retention/full qualification claim. Broader performance objective/publication hold continue.
''')
print('First caller-window sources/core/checks/raw/adversity preserved; runtime not promoted, confirmation pending.')
