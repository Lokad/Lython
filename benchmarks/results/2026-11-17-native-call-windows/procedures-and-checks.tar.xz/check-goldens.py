from pathlib import Path
import json,re,subprocess,sys,textwrap
r=Path(__file__).parent;p=Path('D:/code/Lython/.git/agent-worktrees/call-operands-r470/tests/Lokad.Lython.PublicApi.Tests/HelperLocalLifetimeTests.cs')
programs=re.findall(r'yield return \["""\n(.*?)\n            """\];',p.read_text(encoding='utf-8'),re.S);assert len(programs)==3
rows=[]
for index,source in enumerate(programs):
    source=textwrap.dedent(source)
    p=subprocess.run([sys.executable,'-I','-c',source],capture_output=True,text=True,encoding='utf-8')
    rows.append(dict(index=index,source=source,exitCode=p.returncode,stdout=p.stdout,stderr=p.stderr))
    print(index,p.returncode,p.stdout,p.stderr)
(r/'cpython-semantic-goldens.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
