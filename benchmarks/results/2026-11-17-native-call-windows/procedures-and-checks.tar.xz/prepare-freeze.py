from pathlib import Path
r=Path(__file__).parent;old=r.parent/'instruction-global-slots-r479'
s=(old/'freeze.py').read_text(encoding='utf-8')
s=s.replace("inputs={name:sha(work/name)for name in prior['sourceInputs']}","names=list(prior['sourceInputs'])+['tests/Lokad.Lython.PublicApi.Tests/HelperLocalLifetimeTests.cs','tests/Lokad.Lython.Tests/Harness/NativeCallWindow.cs']\ninputs={name:sha(work/name)for name in names}")
s=s.replace('assert len(changed)==8','assert len(changed)==6')
s=s.replace('PrivateR479 on6fdacb90: LoadGlobal uses spare instruction operand; cancellable compile fixup and guarded live slot; no code-object fields/tables','PrivateR481 on1390c110: native helpers borrow caller operand windows; NativeValues/NoInliningStartNativeCall removed. Pre-admitted128slot tail for existing8prefix nesting; no growable arena/saved activations/new owner.')
(r/'freeze.py').write_text(s,encoding='utf-8',newline='\n')
print('Freeze preparation reuses qualified0315 full32file reference, six production edits and2382 matching build/test inputs.')
