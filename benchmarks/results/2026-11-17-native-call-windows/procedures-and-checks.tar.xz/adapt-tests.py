from pathlib import Path
import re
work=Path('D:/code/Lython/.git/agent-worktrees/call-operands-r470')
names=['ComposedNativeCallTests.cs','FormattedStringExecutableTests.cs','NativeIntegerChainTests.cs','NativeTupleReturnTests.cs','SimpleFunctionExecutionBoundaryTests.cs']
pattern=re.compile(r'function\.StartNativeCall\(call,\s*(\[[^\]]*\]), null, context, (Span|span|CallSpan),\s*false,\s*(?:borrow:\s*)?(!named|false|true),\s*(default|returned),\s*(out [^)]*)\)',re.S)
total=0
for name in names:
    p=work/'tests/Lokad.Lython.Tests'/name;s=p.read_text(encoding='utf-8-sig');matches=list(pattern.finditer(s));assert matches,name
    declarations=list(re.finditer(r'^(\s*)var function = [^\n]+;\n',s,re.M));selected={max((d for d in declarations if d.start()<m.start()),key=lambda d:d.start()).start()for m in matches}
    for d in reversed(declarations):
        if d.start()in selected:s=s[:d.end()]+d[1]+'using var window = new NativeCallWindow(budget, function.CodeObject);\n'+s[d.end():]
    s=s.replace('Assert.Throws<LythonRuntimeException>(() => function.StartNativeCall','Assert.Throws<LythonRuntimeException>(() => { function.StartNativeCall')
    def rewrite(m):
        arguments,span,borrow,returned,outputs=m.groups()
        return f'function.BindNativeCallArguments(call, {arguments}, window.Values, null, context, {span}, {borrow});\n                    function.StartInline(window.Values, null, {span}, false, {returned}, {outputs})'
    s,n=pattern.subn(rewrite,s);total+=n
    s=s.replace('out _, out _, out _));','out _, out _, out _); });')
    assert 'StartNativeCall'not in s,name;p.write_text(s,encoding='utf-8',newline='\n')
assert total==7,total
print('Adapted7 direct test entries to caller-owned funded windows; existing assertions retained, no production compatibility wrapper.')
