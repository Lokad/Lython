from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/call-operands-r470';old=r.parent/'unary-slot-results-r477'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
catalog=json.loads((r.parent/'generator-sum-r475/catalog.json').read_text(encoding='utf-8'))
ids=['scripts.numeric-squared-error.floating.large','scripts.csv-invoice.large','scripts.text-normalization.helper-list']
catalog['cases']=[next(c for c in catalog['cases']if c['id']==name)for name in ids]
(r/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
prior=json.loads((old/'frozen/identity.json').read_text(encoding='utf-8'));files=prior['imageFiles']['candidate'];frozen=r/'frozen';frozen.mkdir(exist_ok=False)
for role in ['reference','candidate']:
    image=frozen/role;image.mkdir()
    for name,h in files.items():
        source=old/'frozen/candidate'/name;assert sha(source)==h;shutil.copyfile(source,image/name)
    if role=='candidate':shutil.copyfile(work/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',image/'Lokad.Lython.dll')
    for p in (old/'frozen/candidate').glob('ValidatedAllocation.*'):shutil.copyfile(p,image/p.name)
images={role:{name:sha(frozen/role/name)for name in files}for role in ['reference','candidate']}
assert [n for n in files if images['reference'][n]!=images['candidate'][n]]==['Lokad.Lython.dll']
names=list(prior['sourceInputs'])+['tests/Lokad.Lython.PublicApi.Tests/HelperLocalLifetimeTests.cs','tests/Lokad.Lython.Tests/Harness/NativeCallWindow.cs']
inputs={name:sha(work/name)for name in names}
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
    for name in inputs:a.add(work/name,arcname=name)
changed=[name for name in inputs if name.startswith('src/Lokad.Lython/')and(work/name).read_text(encoding='utf-8-sig')!=(repo/name).read_text(encoding='utf-8-sig')]
assert len(changed)==6,changed
identity=dict(referenceSource='Qualifiedd8611c85/frozen0315de0a GREEN44050323147; metadata6fdacb90',candidateSource='PrivateR481 on1390c110: native helpers borrow caller operand windows; NativeValues/NoInliningStartNativeCall removed. Pre-admitted128slot tail for existing8prefix nesting; no growable arena/saved activations/new owner.',imageFiles=images,sourceInputs=inputs,productionFiles=sum(n.startswith('src/Lokad.Lython/')for n in inputs),changedProductionFiles=changed,catalogSHA256=sha(r/'catalog.json'),publicationHeld=True)
(frozen/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
for role in ['reference','candidate']:
    image=frozen/role
    commands=[('preflight',[str(dotnet),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'catalog.json'),'--dotnet',str(dotnet),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/(role+'-preflight.json'))]),('allocation',[str(dotnet),str(image/'ValidatedAllocation.dll'),str(image),str(r/'catalog.json'),str(r/(role+'-allocation.json'))])]
    for label,cmd in commands:
        with(r/(role+'-'+label+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
        assert p.returncode==0,(r/(role+'-'+label+'.log')).read_text(encoding='utf-8')
        print(role,label,'pass',flush=True)
print('Copied32file source-pair; only core differs',images['candidate']['Lokad.Lython.dll'],flush=True)
