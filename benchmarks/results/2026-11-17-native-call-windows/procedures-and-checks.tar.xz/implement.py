from pathlib import Path
r=Path(__file__).parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/call-operands-r470'
def edit(name,old,new,count=1):
    p=work/name;s=p.read_text(encoding='utf-8-sig');assert s.count(old)==count,(name,s.count(old),old);p.write_text(s.replace(old,new),encoding='utf-8',newline='\n')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');a=s.index('Hypothesis to assess:');b=s.index('## Measurement and remaining uncertainty',a)
s=s[:a]+'''R481 source gate selects a concrete prototype: remove NativeValues and the
NoInlining StartNativeCall wrapper. Ordinary positional prefixes reuse the
caller's already-evaluated argument window as final callee locals/operands.
Unpacking, live pattern storage and temporary-owned arguments use a disjoint
pre-admitted tail, with existing binding when needed. Fixed tail capacity covers
the existing eight-prefix nesting eligibility; no growable arena, offset-owner
indirection, saved activation array, registry, pool or new execution route.

The caller's existing storage owner funds the extra capacity before allocation.
Limits: an invocation with calls reserves 128 extra slots (3072 estimated bytes),
which may deny earlier. Preserve replacement peaks, aliases and batch streaming.
Initialize unpublished locals before entry; clear borrowed working values after
actual completion/transfer and cleanup. Genuine suspension first copies live
values into its existing owned frame; no span survives. Preserve measured tuple
unpacking using disjoint output/work windows. Keep all managed stack checks.

Completion milestone: remove fixed per-call stack backing, wrapper and ordinary
argument copy, qualify real alias/error/default/descriptor/closure semantics,
reentry/suspension/cancellation/terminal-refusal/cleanup on both actual targets,
and decide whole-script CPU/allocation/peak debt. One floating warm/fresh and text
helper comparison with integer CSV and compile controls. No speedup assumed;
bounded confirmation/refinement permitted. Retain/refine/withdraw with no dormant
displaced mechanism. Only retained coherent runtime changes trigger full delivery.

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
edit('src/Lokad.Lython/Frontend/ExecutableScript.cs',
     '    public int ValueStorageCapacity => checked(PatternStorageStart + PatternStorageCount);',
     '''    public int ValueStorageCapacity => checked(PatternStorageStart + PatternStorageCount);
    // Native prefixes borrow final operand storage. The existing depth eligibility
    // bounds a fixed tail; logical slots and pattern storage keep their layout.
    public int InvocationStorageCapacity => checked(ValueStorageCapacity +
        (CallSites.Count == 0 ? 0 : LythonRuntime.NativeCallStorageSlots));''')
for name in ['LythonRuntime.Executable.Calls.Invoke.cs','LythonRuntime.Executable.Calls.cs']:
    p=work/'src/Lokad.Lython/Runtime'/name;s=p.read_text(encoding='utf-8-sig');s=s.replace('Code.ValueStorageCapacity','Code.InvocationStorageCapacity').replace('CodeObject.ValueStorageCapacity','CodeObject.InvocationStorageCapacity');p.write_text(s,encoding='utf-8',newline='\n')
edit('src/Lokad.Lython/Runtime/LythonRuntime.Executable.cs',
     'new ExecutableValueStorage(codeObject.ValueStorageCapacity,','new ExecutableValueStorage(codeObject.InvocationStorageCapacity,')
name='src/Lokad.Lython/Runtime/PyExecutableFunction.cs';p=work/name;s=p.read_text(encoding='utf-8-sig');a=s.index('    [System.Runtime.CompilerServices.InlineArray');b=s.index('    internal override bool TryStartBoundInvocation',a)
s=s[:a]+'''    // Disjoint windows still use ordinary native binding. An in-place positional
    // call already has its final parameter prefix and needs no preparation/copy.
    internal void BindNativeCallArguments(ExecutableCallSite call,
        ReadOnlySpan<LythonRuntime.ExecutableSlot> arguments, Span<LythonRuntime.ExecutableSlot> values,
        object? receiver, LythonRuntime.ExecutionContext context, LythonSourceSpan span, bool borrow)
    {
        if (borrow) arguments.CopyTo(values);
        else LythonRuntime.BindFunctionArgumentsInto(values[..BindingPlan.ParameterCount],
            [], span, BindingPlan, context, receiver: receiver, callSite: call, operands: arguments);
    }

'''+s[b:]
s=s.replace('storageCapacity: codeObject.ValueStorageCapacity','storageCapacity: codeObject.InvocationStorageCapacity').replace('StartInline(bound.Values.AsSpan(0, _codeObject.ValueStorageCapacity),','StartInline(bound.Values,').replace('    private void StartInline(','    internal void StartInline(')
s=s.replace('''        // The common fixed buffer has a bounded managed stack cost; larger
        // bound calls borrow charged capacity until materialization and cleanup
        // finish. An idle loan stays funded until execution cleanup or eviction.''','''        // The caller owns a pre-admitted window through completion/transfer.
        // A recycled window must not expose stale unassigned locals. Bound
        // storage is already cleared by its existing workspace owner.
        if (existing is null) values[BindingPlan.ParameterCount.._codeObject.ValueStorageCapacity].Clear();''')
s=s.replace('                    _codeObject.ValueStorageCapacity);','                    _codeObject.InvocationStorageCapacity);').replace('ReturnBoundArguments(owned, _codeObject.ValueStorageCapacity)','ReturnBoundArguments(owned, _codeObject.InvocationStorageCapacity)')
old='''                    if (rented && !transferred) LythonRuntime.ReturnBoundArguments(owned, _codeObject.InvocationStorageCapacity);

''';new='''                    try { if (rented && !transferred) LythonRuntime.ReturnBoundArguments(owned, _codeObject.InvocationStorageCapacity); }
                    finally { if (existing is null) values[.._codeObject.ValueStorageCapacity].Clear(); }
''';assert old in s;s=s.replace(old,new);p.write_text(s,encoding='utf-8',newline='\n')
edit('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs',
     '    private const int NativeCallDepth = 8;',
     '    private const int NativeCallDepth = 8;\n    internal const int NativeCallStorageSlots = NativeValueCapacity * NativeCallDepth;')
edit('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.Invoke.cs',
'''                    function.StartNativeCall(call, arguments, functionReceiver, scope, call.CallSpan,
                        CallResultConsumedByIteration(in execution, call), borrow, unpackedReturn,
                        out var unpacked, out var value, out var frame);''',
'''                    // Pattern captures and unpacked output can outlive this call.
                    // Use the disjoint tail when the argument window is not free.
                    var inPlace = borrow && unpackedReturn.IsEmpty && execution.Code.PatternStorageCount == 0
                        && execution.Stack.CanRetireWithoutCleanup(start + call.ArgumentOffset);
                    var storageStart = inPlace ? start + call.ArgumentOffset : execution.Code.ValueStorageCapacity;
                    var values = execution.Stack.Values.AsSpan(storageStart);
                    if (!inPlace) function.BindNativeCallArguments(call, arguments, values,
                        functionReceiver, scope, call.CallSpan, borrow);
                    function.StartInline(values, null, call.CallSpan,
                        CallResultConsumedByIteration(in execution, call), unpackedReturn,
                        out var unpacked, out var value, out var frame);''')
edit('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs',
'''                function.StartNativeCall(call, arguments, receiver, _scope, call.CallSpan,
                    call.ConsumedByIteration || _consumedByIteration && call.ReturnedDirectly,
                    borrow, default, out _, out var childValue, out var child);''',
'''                var inPlace = borrow && Code.PatternStorageCount == 0;
                if (inPlace)
                    foreach (var argument in arguments)
                        if (argument.Reference is ExecutableTemporaryValue) { inPlace = false; break; }
                var storageStart = inPlace ? start + call.ArgumentOffset : Code.ValueStorageCapacity;
                var values = Values[storageStart..];
                if (!inPlace) function.BindNativeCallArguments(call, arguments, values,
                    receiver, _scope, call.CallSpan, borrow);
                function.StartInline(values, null, call.CallSpan,
                    call.ConsumedByIteration || _consumedByIteration && call.ReturnedDirectly,
                    default, out _, out var childValue, out var child);''')
print('Private R481: removed NativeValues/StartNativeCall; funded caller windows, logical layout unchanged, no new arena/frame/owner.')
