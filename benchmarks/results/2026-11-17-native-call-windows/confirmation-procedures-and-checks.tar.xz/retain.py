from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/call-operands-r470';out=repo/'benchmarks/results/2026-11-17-native-call-windows';confirm=out/'confirmation';confirm.mkdir(exist_ok=False)
receipt=json.loads((r/'confirm/quiet/archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']and receipt['quietBeforeAndAfter']
for n in ['observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(r/'confirm/quiet'/n,confirm/n)
shutil.copyfile(r/'confirm/summary.json',out/'confirmation-summary.json')
with tarfile.open(out/'confirmation-procedures-and-checks.tar.xz','w:xz')as a:
    for p in list(r.glob('*.py')):
        a.add(p,arcname=p.name)
    for p in (r/'confirm').rglob('*'):
        if p.is_file()and 'retrieved'not in p.parts and p.name not in ['payload.tgz','observations.tgz']:a.add(p,arcname=p.relative_to(r).as_posix())
decision=dict(retain=True,basis='Remove NativeValues fixed stack backing, NoInlining StartNativeCall and ordinary positional copy by using already-admitted caller storage. First stable complete floating warm elapsed−4.64..−3.52%, widerCPU−6.48..−4.57%. No general/compile-once CPU gain claim.',freshUncertainty='Confirmation−3.55..+1.71%elapsed/−2.42..+3.51%widerCPU, reference4.67%movement/candidate0.75%; first reference5.27%movement. Not resolved or a design failure.',textDebt='Confirmed+0.27..+0.98%elapsed, widerCPU−1.07..+1.08%, controls0.54/0.18%. Accept small elapsed debt for removed call storage and demonstrated numeric CPU; first+1.01..+5.78%adversity retained, cause unisolated.',memoryDebt='Accept4096/2560/~2678B allocation and3072/3072/3584B accounted peak increases (floating/CSV/text). Invocations with calls conservatively admit128extra slots before allocation; earlier denial is intentional.',removed=['NativeValues fixed managed stack buffer','NoInlining StartNativeCall wrapper','ordinary positional argument copy into separate backing'],preserved=['existing engine, code layout and8prefix eligibility','all managed stack checks, Python error/identity/default/descriptor/closure semantics','actual suspension transfers into owned frames without replay or retained spans','terminal first refusal, current cancellation and funded aliases through awaited cleanup','measured tuple-unpacking optimization with disjoint windows'],fullDeliveryPending=True,broaderPerformanceObjectiveComplete=False,publicationHeld=True)
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
p=out/'README.md';s=p.read_text(encoding='utf-8').replace('**Private prototype; retention pending.**','**Retained; full delivery qualification pending.**');s+='''
## B896 confirmation and retention decision

Same sources/images/catalog/protocol, eight-second interleaved full-request warmups;
two unresolved jobs finish 96.83 seconds. No source tuning or forced collection.

| Complete script | Phase | Elapsed change | Wider CPU change | Reference / candidate controls |
| --- | --- | ---: | ---: | ---: |
| Floating report | Compile and execute once | **−3.55..+1.71%** | **−2.42..+3.51%** | **4.67 / 0.75%** |
| Helper text | Warm | **+0.27..+0.98%** | −1.07..+1.08% | 0.54 / 0.18% |

Retain the removed call storage and demonstrated first warm numeric CPU benefit.
Fresh remains uncertain with moving reference controls; do not claim it improved,
that a particular speedup is established across all scripts, or that an inconclusive
measurement disproves the design. Accept the small confirmed text elapsed debt and
explicit capacity/allocation increase. First larger text adversity is preserved and
unexplained. R471 integer/R460 async/tuple debts remain; no additive speedups.
No more unchanged timing is needed for this bounded retention decision. The broader
performance objective continues with a separate record-construction design gate.

All guards/goldens/Closed/exit/join/archive checks pass; RAM removed, terminal cached.
The first confirmation staging guard stopped before mutation/timing because disk
headroom missed its floor by 5006 bytes. The repaired proof retires only an additional
31309-byte exact committed obsolete bytecode replica; original failure retained.
Total retirement is 521399 bytes of exact committed first working evidence, with
fresh path/UID/hash/link/all-alias checks. Current images/toolchains/canonicals and
254/252 MiB floors are preserved. No observation timeout restarted any collection.

Six production files and their semantic/ownership test adaptations are promoted;
full Windows/Ubuntu, original stress and installed Release consumers remain pending.
No public API change; earlier supplied-budget denial from admitted capacity is the
intentional compatibility tradeoff. Publication and tagging remain held.

[Confirmation](confirmation-summary.json), [raw](confirmation/observations.tgz),
[decision](decision.json), [procedures and original guard](confirmation-procedures-and-checks.tar.xz).
''';p.write_text(s,encoding='utf-8',newline='\n')
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
names=subprocess.check_output(['git','diff','--name-only'],cwd=work,text=True).splitlines()+['tests/Lokad.Lython.PublicApi.Tests/HelperLocalLifetimeTests.cs','tests/Lokad.Lython.Tests/Harness/NativeCallWindow.cs']
assert len(names)==14,names
for name in names:
    assert hashlib.sha256((work/name).read_bytes()).hexdigest()==f['sourceInputs'][name],name
    shutil.copyfile(work/name,repo/name)
(r/'retained-files.json').write_text(json.dumps(names,indent=2)+'\n',encoding='utf-8')
p=repo/'docs/RUNTIME.md';s=p.read_text(encoding='utf-8');old='''There is no separate native integer bank, loan or capacity fact. Small native
prefixes use a fixed managed buffer; larger helpers use admitted final slots.''';new='''There is no separate native integer bank, loan or capacity fact. Small native
prefixes borrow admitted caller operands; larger helpers use admitted final slots.
Ordinary positional inputs already occupy their final parameter prefix. Live
pattern state, temporary ownership and unpacked outputs use disjoint working space.
Invocations containing calls admit a fixed 128-slot tail (3072 estimated bytes),
covering the existing bounded native-prefix nesting. This can reject earlier under
a supplied allowance; it introduces no independent limit or hidden allowance.''';assert old in s;s=s.replace(old,new)
old='''Already-bound calls can run eligible bodies over their admitted full locals array;
the private stack buffer stays at sixteen slots. Dead operand references stay in
their funded backing until the synchronous prefix ends; the dead tail clears
before transfer and owned arrays clear on return.''';new='''Already-bound calls can run eligible bodies over their admitted full locals array.
Borrowed working slots initialize unassigned locals before entry and clear after
their users and cleanup end. No per-call fixed stack buffer is allocated. The
dead tail clears before transfer; surviving values move into the existing owned
frame, and owned arrays clear on return.''';assert old in s;s=s.replace(old,new);p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'tests/README.md';s=p.read_text(encoding='utf-8');s=s.replace('# Testing Lython\n','# Testing Lython\n\n[Helper local lifetimes](Lokad.Lython.PublicApi.Tests/HelperLocalLifetimeTests.cs)\ncheck unassigned locals across repeated calls, nested/deep helpers, live pattern\nguards and unpacked returns through both APIs, restoring shared-budget balances.\n',1);p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'CHANGELOG.md';s=p.read_text(encoding='utf-8').replace('## 0.11.0 - Unreleased\n','''## 0.11.0 - Unreleased

- Native helpers borrow admitted caller operands instead of allocating fixed
  stack buffers and copying ordinary positional arguments. Suspension transfers
  live values into existing owned frames. Invocations containing calls reserve
  extra working capacity, which can cause earlier supplied-budget rejection.
''',1);p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'docs/BENCHMARKS.md';s=p.read_text(encoding='utf-8');anchor='| Shared unary builtin result transport /';a=s.index(anchor);s=s[:a]+'''| Borrowed native call windows / complete floating JSON report | Warm elapsed 3.5–4.6% lower, wider CPU 4.6–6.5% lower against d8611c85; per-call fixed stack buffer removed | Allocation +0.83%, accounted peak +3072 B; fresh uncertain with moving reference controls. Confirmed helper text elapsed +0.27..+0.98%, wider CPU near flat. [Both comparisons and tradeoffs](../benchmarks/results/2026-11-17-native-call-windows/README.md). Full delivery pending. |
'''+s[a:];p.write_text(s,encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as stream:stream.write('''
R481/B896: retain caller windows and removed NativeValues/NoInlining wrapper/ordinary positional copy. Stable first floating warm−3.5..−4.6%/CPU−4.6..−6.5%; confirmed fresh remains mixed/reference4.67%movement. Confirmed text+0.27..+0.98%elapsed, CPU−1.07..+1.08%; accept small text/capacity debt, preserve first larger adversity. Allocation+4096/2560/~2678B, accounted peaks+3072/3072/3584B; earlier denial intentional. Six source files/observable tests and funded caller-window fixtures promoted; full delivery pending. Both conditions/failures preserved; no unchanged retiming needed for decision. Broader objective/publicationhold remain.
''')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');needle='| Latest qualified runtime |';a=s.index(needle);s=s[:a]+'''| Retained; delivery pending | R481 caller-owned native working windows: NativeValues/NoInlining wrapper and ordinary positional copy removed. Stable first warm floating elapsed −3.5..−4.6%, CPU −4.6..−6.5%. Fresh uncertain; accept confirmed text +0.27..+0.98% elapsed and modest extra capacity/allocation. Focused actual targets pass; full delivery is next. |
'''+s[a:];a=s.index('## Next: R481');b=s.index('## Measurement and remaining uncertainty',a);s=s[:a]+'''## Active: R481 delivery, then R482 record construction

R481 retention is explicit: accept 128 admitted extra slots for invocations with
calls, small confirmed text elapsed debt and +4096/2560/~2678 B allocation versus
demonstrated warm floating CPU improvement. Fresh remains uncertain; no general
compile-once speedup claim. Both collections, adverse conditions and initial test/
staging corrections are preserved. No unchanged timing is needed for this decision.
[Sources, contract, checks and comparisons](benchmarks/results/2026-11-17-native-call-windows/README.md).

Batch full Windows/Ubuntu, actual .NET 11/10, original stress and installed Release
consumers once at this retained boundary. Match committed production to frozen
source before qualification. Keep working while CI runs. After delivery, refresh
the changed floating report against CPython with compilation/warm/fresh separated;
other named historical baselines remain labeled. Publication/tagging remain held.

R482 bounded source gate: reassess the remaining eager CSV field/string construction
for partial-column aggregates and reports. Current parser already owns one native
record buffer/descriptors and batches final payload admission/shared string windows;
do not repeat earlier 6–8% row work. Inspect whether final strings for unused columns
can be deferred within existing record storage while preserving canonical aliases,
full up-front capacity admission, copies/mutation/views/projection, errors and
retained ownership. Name a complete stage/storage to eliminate and its semantic
costs. No new guest tracing, scalar identity ledger, universal lazy-container
framework or automatic promotion. Stop with one coherent proposal or uncertainty
before implementation/another measurement. R480 already shows private drain growth
is not established as dominant; no repeat capture or buffer framework.

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print('Retained six-file caller-window migration with explicit text/capacity/fresh debt; matched14source/test files promoted, full delivery next.')
