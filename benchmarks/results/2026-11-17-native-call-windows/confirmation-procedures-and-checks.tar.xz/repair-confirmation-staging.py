from pathlib import Path
import hashlib,io,json,subprocess,tarfile
base=Path(__file__).parent;q=base/'confirm/quiet';repo=Path('D:/code/Lython');c=json.loads((q/'config.json').read_text(encoding='utf-8'))
(q/'launch.log').rename(q/'initial-free-space-guard.log')
canonical='benchmarks/results/2026-11-17-native-call-windows/first-pair/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();member='__pycache__/cpython-worker.cpython-312.pyc'
with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile(member).read()
c['retireGroups'].append(dict(paths=['native-call-windows-b895-20261117/'+member],bytes=len(data),links=1,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8');s=(q/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
print('First guard stopped before mutation/timing; add only',len(data),'bytes exact committed obsolete bytecode replica, revalidate all paths/hashes/aliases under lease.')
