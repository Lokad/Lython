from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-17-native-call-windows';corr=out/'corrected';c=r/'corrected';q=c/'quiet'
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['jobs']==4 and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']
for n in ['observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(q/n,corr/n)
for n in ['summary.json','allocation-summary.json']:shutil.copyfile(c/n,corr/n)
(corr/'candidate-core.dll.gz').write_bytes(gzip.compress((c/'frozen/candidate/Lokad.Lython.dll').read_bytes(),mtime=0))
with tarfile.open(corr/'procedures-and-checks.tar.xz','w:xz')as a:
    for p in c.rglob('*'):
        if p.is_file()and not {'retrieved','frozen','delivery'}&set(p.relative_to(c).parts)and p.name not in ['payload.tgz','observations.tgz','candidate-sources.tar.xz','Lokad.Lython.dll']:a.add(p,arcname=p.relative_to(c).as_posix())
decision=json.loads((out/'decision.json').read_text(encoding='utf-8'));decision.update(retain=False,initialRetentionSuperseded=True,reason='Corrected-source stable defaulted-helper and text CPU regressions, no established numeric warm benefit with moving controls, extra capacity/allocation and window state do not justify this migration. Restore the qualified managed stack-backed prefix. No permanent design ban or fixed-percentage veto.',correctedFloatingWarm='−8.03..+2.91%elapsed, reference8.18/candidate3.44%spread; not established gain.',correctedFloatingFresh='+0.98..+7.75%elapsed/+2.73..+9.39%widerCPU, reference5.01%movement; original uncertainty/adversity preserved.',correctedDefaultDiagnostic='+3.61..+5.95%elapsed/+5.25..+6.98%widerCPU, controls1.30/0.95%.',correctedText='+2.17..+5.69%elapsed/+3.07..+5.01%widerCPU, controls1.73/1.70%.',fullDeliveryPending=False,discardedPrototypeDeliveryPending=True,currentRuntime='Restoredqualifiedd8611c85 via1390c110; GREEN44050323147 cached, no repeated unchanged qualification.',retainedTests='Three observable helper-local programs and structured integer-preflight assertion; restore architecture-specific adaptations/remove NativeCallWindow fixture.',broaderPerformanceObjectiveComplete=False)
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
p=out/'README.md';s=p.read_text(encoding='utf-8').replace('**Retained; full delivery qualification pending.**','**Withdrawn after corrected-source measurement; initial retention superseded.**');s+='''
## B897 corrected-source result: withdraw

Four jobs in 154.89 seconds against the same qualified d8611c85/0315de0a reference.
Corrected **abd3c788 / frozen27ed69a6** initializes/unwinds parameter storage after
binding errors. The catalog adds one diagnostic from the existing positional-loop
fixture with an ordinary defaulted parameter; expected output/input stay unchanged,
source/hash change explicitly. Both actual workers and CPython validate it before
staging. This is corrected-source qualification, not unchanged preferred-sign timing.

| Corrected complete workload | Phase | Elapsed change | Wider CPU change | Reference / candidate controls |
| --- | --- | ---: | ---: | ---: |
| Floating report | Warm | −8.03..+2.91% | −8.90..+4.36% | **8.18 / 3.44%** |
| Same | Compile and execute once | **+0.98..+7.75%** | **+2.73..+9.39%** | **5.01 / 1.61%** |
| Defaulted helper diagnostic | Warm | **+3.61..+5.95%** | **+5.25..+6.98%** | 1.30 / 0.95% |
| Helper text | Warm | **+2.17..+5.69%** | **+3.07..+5.01%** | 1.73 / 1.70% |

Withdraw the caller-window footprint. Corrected numeric warm gain is not established;
stable adverse helper/text CPU and extra capacity/allocation do not justify the new
lifetime state. Possible contributors include clearing and heap-backed operand
writes; neither is individually measured. No more unchanged run is needed for this
decision, and it is not a permanent prohibition on better call representations.

Remove InvocationStorageCapacity/the 128-slot tail, caller-window selection, parameter
window helpers and the NativeCallWindow fixture. Restore the real qualified
NativeValues/StartNativeCall implementation and prior architecture test setup.
Keep three independent observable helper-local programs and the stronger structured
integer-preflight assertion. No dormant alternative, compatibility wrapper, option
or new owner remains. The binding-poisoning bug belonged to the discarded reused
window; the restored fresh stack-backed parameters preserve its correct behavior.

All gates/goldens/Closed/exit/join/archive checks pass; RAM removed, terminal cached.
The initial UID guard stopped before mutation/timing on a root-owned historical
archive. A separate fresh idle-lease proof verifies its committed exact bytes,
resolved path, UID0, single inode/alias and containment before reclaiming that one
replica. Ordinary staging then rechecks and retires only the incorrect0ebab036
working core's two aliases and committed old raw/archive replicas. Current0315,
toolchains/canonicals and 254/252 MiB floors remain intact. Both original staging
conditions and the specific retirement receipt are preserved.

The corrected prototype's running full CI is independent historical qualification;
it cannot establish current-HEAD performance or justify retention. The restored
runtime already has its cached full delivery; focused new-test checks follow on
both actual runtimes, with no repeat unchanged platform qualification. Broader
performance work continues; publication/tagging remain held.

[Corrected summary](corrected/summary.json), [allocation](corrected/allocation-summary.json),
[raw](corrected/observations.tgz), [exact corrected source](corrected/candidate-sources.tar.xz),
[core](corrected/candidate-core.dll.gz), [procedures and original guards](corrected/procedures-and-checks.tar.xz).
''';p.write_text(s,encoding='utf-8',newline='\n')
original=json.loads((r/'retained-files.json').read_text(encoding='utf-8'))
restore=[n for n in original if n not in ['tests/Lokad.Lython.PublicApi.Tests/HelperLocalLifetimeTests.cs','tests/Lokad.Lython.Tests/Harness/NativeCallWindow.cs']]
restore+=['tests/Lokad.Lython.PublicApi.Tests/GzipCallbackScopeLifetimeTests.cs','tests/Lokad.Lython.PublicApi.Tests/GzipPathScopeLifetimeTests.cs','tests/Lokad.Lython.PublicApi.Tests/RootLifetimeContainmentTests.cs','tests/Lokad.Lython.Tests/BinaryFileWriteCallBoundaryTests.cs','tests/Lokad.Lython.Tests/CsvWriterowCallBoundaryTests.cs','tests/Lokad.Lython.Tests/TextFileWriteCallBoundaryTests.cs','docs/RUNTIME.md','docs/BENCHMARKS.md','CHANGELOG.md']
subprocess.run(['git','restore','--source=1390c110','--']+restore,cwd=repo,check=True)
subprocess.run(['git','rm','--','tests/Lokad.Lython.Tests/Harness/NativeCallWindow.cs'],cwd=repo,check=True)
with tarfile.open(r.parent/'unary-slot-results-r477/candidate-sources.tar.xz')as a:
    production=[m for m in a.getmembers()if m.name.startswith('src/Lokad.Lython/')and m.isfile()];assert len(production)==585
    for m in production:assert(repo/m.name).read_text(encoding='utf-8-sig')==a.extractfile(m).read().decode('utf-8-sig').replace('\r\n','\n'),m.name
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as stream:stream.write('''
R481/B897 corrected source27ed69a6/abd3c788: withdraw and supersede initial retention. Floating warm uncertain with reference8.18%movement; fresh+0.98..+7.75%/CPU+2.73..+9.39%, reference5.01%movement. Defaulted diagnostic+3.61..+5.95%/CPU+5.25..+6.98%, controls1.30/0.95%; helper text+2.17..+5.69%/CPU+3.07..+5.01%, controls1.73/1.70%. Added capacity/window state not justified. Remove all six production edits/architecture fixtures, restore qualifiedd8611c85 stack-backed prefix; retain3observable helper programs and structured integer-preflight assertion. All585production files verified against qualified snapshot. Corrected-prototype CI remains historical; no repeat unchanged core qualification. All conditions/raw/failures retained, no permanent design ban. Broader roadmap/publicationhold remain.
''')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');lines=s.splitlines();lines=[line for line in lines if not line.startswith('| Retained; delivery pending |')];s='\n'.join(lines)+'\n';s=s.replace('R474 subscript entry and R479 instruction global binding.','R474 subscript entry, R479 instruction global binding and R481 caller windows.');s=s.replace('R479 completed focused checks and two bounded comparisons; no prototype remains active.','R481 corrected source has stable helper/text regressions; all six production edits/architecture fixtures removed, qualified stack-backed execution restored. Three useful helper programs and structured refusal assertion remain; no active runtime prototype.')
a=s.index('## Active: R481');b=s.index('## Measurement and remaining uncertainty',a);s=s[:a]+'''## Active: close R481 evidence; then R483 bulk UTF-8 widths

R481 corrected source is withdrawn: defaulted-helper warm CPU+5.25..+6.98%, text
CPU+3.07..+5.01%; no established numeric warm gain with moving controls. Initial
retention is superseded. Remove the 128-slot tail/window machinery/test fixture;
restore qualifiedd8611c85 production, verified585files. Keep three independent
helper-local programs and the structured integer-preflight assertion. Focused
actual11/10 checks on restored source are next. Let already-running corrected-
prototype CI44072440304 finish and cache its historical result; never interpret it
as retained HEAD qualification. Do not replay the unchanged core's cached full
delivery44050323147. [All conditions/decision](benchmarks/results/2026-11-17-native-call-windows/README.md).

R482 record gate complete: parser batches payload admission and shares windows;
DictReader adopts the funded row array under shared keys. Deferred unused-field
strings need new offsets/presence/canonical-cache state and affect mutation/copies/
projection/current adoption. No coherent lower-cost replacement established; no
lazy-container framework, scalar identity ledger or automatic CSV prototype.
This is remaining uncertainty, not a permanent ban or a retiming of integrated
6–8% row work. Preserve source findings separately.

R483 next concrete proposal: replace CountUtf8Units' per-scalar width loop with
managed bulk byte classification over existing bounded chunks. Saved R480 stacks
attribute GetRuneLength calls mainly under ordinary call completion; current
PyString counting source is unchanged. For valid UTF-8, scalar count is byte count
minus continuation bytes; UTF-16 adds four-byte leads. The pinned .NET10/11 BCL
provides CountAny(SearchValues<byte>); no new dependency/unsafe/SIMD pointer code.
Remove the inner scalar loop/boundary adjustment, retain GetRuneLength's actual
indexing callers, current cancellation/checked arithmetic and ownership preflights.
Do not assume BCL vectorization or a speedup; qualify dense Unicode as well as
ASCII and scalar-boundary windows. Focused scalar/UTF16/projection/refusal/current-
token checks, then one short whole text/report comparison with controls. Affected
CPython refresh/full delivery only at a retained coherent boundary. Publication held.

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print('R481 withdrawn: all585production files match qualified source; caller-window fixture removed, independent tests retained. Corrected timings/decisions/failures preserved.')
