from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/call-operands-r470';out=repo/'benchmarks/results/2026-11-17-native-call-windows'
with tarfile.open(r.parent/'unary-slot-results-r477/candidate-sources.tar.xz')as a:
    prods=[m for m in a.getmembers()if m.isfile()and m.name.startswith('src/Lokad.Lython/')];assert len(prods)==585
    for m in prods:assert(repo/m.name).read_text(encoding='utf-8-sig')==a.extractfile(m).read().decode('utf-8-sig').replace('\r\n','\n'),m.name
for framework in ['net11.0','net10.0']:
    for suite,count in [('public',124),('internal',88)]:
        text=(r/f'restored-{suite}-{framework}.log').read_text(encoding='utf-8');assert f'Passed:   {count}'in text or f'Passed:    {count}'in text,(suite,framework)
with tarfile.open(out/'restored-runtime-checks.tar.xz','w:xz')as a:
    for p in r.glob('restored-*.log'):a.add(p,arcname=p.name)
    for p in [r/'close-withdrawal.py',r/'withdraw-corrected.py']:a.add(p,arcname=p.name)
v=dict(currentProduction='All585production files text-identical to qualifiedd8611c85 via1390c110',cachedProductionQualification=44050323147,unchangedQualificationRepeated=False,eachActualWindowsTarget=dict(publicFocused=124,internalFocused=88),newIndependentPublicPrograms=3,structuredIntegerPreflightAssertionRetained=True,allCallerWindowMachineryAndArchitectureFixtureRemoved=True,discardedPrototypeFullRun=44072440304,discardedPrototypeQualificationStillPending=True,publicationHeld=True)
(out/'restored-validation.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
# Retire only private editable replicas whose exact source is already committed
# and archived. Keep immutable frozen images and experiment evidence.
tracked=subprocess.check_output(['git','diff','--name-only'],cwd=work,text=True).splitlines();untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=work,text=True).splitlines()
assert set(untracked)=={'tests/Lokad.Lython.PublicApi.Tests/HelperLocalLifetimeTests.cs','tests/Lokad.Lython.Tests/Harness/NativeCallWindow.cs'},untracked
for name in tracked+untracked:
    path=work/name;assert path.resolve().is_relative_to(work.resolve())
    committed=subprocess.check_output(['git','show','abd3c788:'+name],cwd=repo).decode('utf-8-sig').replace('\r\n','\n');assert path.read_text(encoding='utf-8-sig')==committed,name
subprocess.run(['git','restore','--source=HEAD','--']+tracked,cwd=work,check=True)
for name in untracked:(work/name).unlink()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=work)
p=out/'README.md';s=p.read_text(encoding='utf-8');s+='\nRestored production matches all585 qualified source files. Fresh nonincremental builds and actual .NET11/10 each pass124public/88internal focused regressions; three independent helper programs and the structured JSON preflight assertion remain. Private editable prototype replicas are removed after exact committed/archive checks. [Restored validation](restored-validation.json), [checks](restored-runtime-checks.tar.xz).\n';p.write_text(s,encoding='utf-8',newline='\n')
p=out/'validation.json';s=json.loads(p.read_text(encoding='utf-8'));s.update(currentRuntimeValidation=v,fullDelivery='Caller-window prototype withdrawn. Current585production match previously qualifiedd8611c85; new retained tests pass actual11/10 focused checks. Discarded prototype CI tracked independently.');p.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8').replace('Focused\nactual11/10 checks on restored source are next.','Fresh nonincremental builds and focused\nactual11/10 each pass124public/88internal on restored source. Private editable\nprototype code/tests removed after exact committed/archive checks.');p.write_text(s,encoding='utf-8',newline='\n')
print('Restored qualified production585 and meaningful regressions verified; private prototype clean, no dormant alternative/tests remain.')
