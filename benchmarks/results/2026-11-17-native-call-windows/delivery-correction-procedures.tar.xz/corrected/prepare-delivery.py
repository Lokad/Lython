from pathlib import Path
r=Path(__file__).parent;base=r.parent
s=(base/'start-delivery.py').read_text(encoding='utf-8').replace("r.parent/'unary-slot-results-r477/delivery/inputs.json'","r.parent/'delivery/inputs.json'")
s=s.replace("names=sorted(list(old['inputs'])+['tests/Lokad.Lython.PublicApi.Tests/HelperLocalLifetimeTests.cs','tests/Lokad.Lython.Tests/Harness/NativeCallWindow.cs'])","names=sorted(old['inputs'])")
s=s.replace("r.parent/'unary-slot-results-r477/poll-delivery.py'","r.parent.parent/'unary-slot-results-r477/poll-delivery.py'")
(r/'start-delivery.py').write_text(s,encoding='utf-8',newline='\n')
print('Corrected delivery: same2382build/test inputs, production matched to corrected frozen source; one new combined workflow, failed run stays cached.')
