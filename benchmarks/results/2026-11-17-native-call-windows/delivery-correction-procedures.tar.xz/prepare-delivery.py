from pathlib import Path
r=Path(__file__).parent;old=r.parent/'unary-slot-results-r477'
s=(old/'start-delivery.py').read_text(encoding='utf-8')
s=s.replace("assert head.startswith('d8611c85')","assert head==json.loads((r/'retained-head.json').read_text(encoding='utf-8'))['head']")
s=s.replace("r.parent/'generator-sum-r475/delivery/inputs.json'","r.parent/'unary-slot-results-r477/delivery/inputs.json'")
s=s.replace("['tests/Lokad.Lython.PublicApi.Tests/ClosedBuiltinResultTests.cs']","['tests/Lokad.Lython.PublicApi.Tests/HelperLocalLifetimeTests.cs','tests/Lokad.Lython.Tests/Harness/NativeCallWindow.cs']")
s=s.replace('len(inputs)==2380','len(inputs)==2382').replace('ordinaryPublic=18010','ordinaryPublic=18013').replace('2380committed','2382committed')
# Generate the new poller from a local cached template; never query prior runs.
a=s.index('poll=');b=s.index("\nprint(json.dumps(record))",a)
s=s[:a]+'''poll=(r.parent/'unary-slot-results-r477/poll-delivery.py').read_text(encoding='utf-8').replace('44050323147',str(record['run'])).replace("v['headSha'].startswith('d8611c85')","v['headSha']=="+repr(head))
(r/'poll-delivery.py').write_text(poll,encoding='utf-8',newline='\\n')'''+s[b:]
(r/'start-delivery.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared one explicit stress/platform/package delivery for matched585production/2382committed inputs, no duplicate automatic cycle.')
