from pathlib import Path
import json,shutil,tarfile,zipfile,re
r=Path(__file__).parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-17-native-call-windows';failed=out/'delivery-first-failure';failed.mkdir(exist_ok=False)
for src,dst in [('terminal.json','terminal.json'),('inputs.json','inputs.json'),('inputs.tar.xz','inputs.tar.xz'),('failed-run-logs.zip','run-logs.zip')]:shutil.copyfile(r/'delivery'/src,failed/dst)
terminal=json.loads((failed/'terminal.json').read_text(encoding='utf-8'));assert terminal['conclusion']=='failure'and terminal['databaseId']==44067803913
(failed/'README.md').write_text('''# First delivery failure, preserved

CI [44067803913](https://github.com/Lokad/Lython/actions/runs/44067803913) at
34d2e393 fails ordinary .NET11 tests on Windows and Ubuntu. No full qualification
is claimed; subsequent .NET10/package/stress gates did not complete.

A real regression: caught native argument-binding errors leave partial parameter
values in caller-owned storage. A later valid call can incorrectly raise TypeError.
Existing FunctionBindingLifetimeTests expose both positional and keyword-default
cases. The correction initializes the disjoint parameter prefix before binding
and clears it on failure. No compatibility wrapper, fallback or alternate mode.

Other failures depend on earlier fixed working-storage sizes. Refusal fixtures
now admit the caller window before denying conversion/write storage; publication,
argument effects, input aliases and cleanup assertions remain. Retained-data
fixtures separate the first payload/working set from a larger refused second
payload, still requiring completed gate I/O, terminal refusal and funded runs.
The JSON preflight check now asserts a digit-scale refused request and the actual
supplied allowance instead of an unrelated 4096-byte setup threshold.

Focused correction checks on actual .NET11/10 each pass 124 public and 88 internal
cases; two independent CPython3.13.2 default-binding programs agree. Original CI
logs, inputs and the initial correction's fixture failures remain preserved.
Corrected-source measurement and full delivery are separate, still pending.

[Terminal](terminal.json), [committed inputs](inputs.tar.xz), [logs](run-logs.zip).
''',encoding='utf-8',newline='\n')
with tarfile.open(out/'delivery-correction-procedures.tar.xz','w:xz')as a:
    for p in list(r.glob('*correction*'))+list(r.glob('*delivery*.py'))+list(r.glob('first-correction*')):
        if p.is_file():a.add(p,arcname=p.name)
    for p in (r/'corrected').glob('*'):
        if p.is_file()and p.suffix in ['.py','.log','.json']:a.add(p,arcname='corrected/'+p.name)
corrected=out/'corrected';corrected.mkdir(exist_ok=False);shutil.copyfile(r/'corrected/candidate-sources.tar.xz',corrected/'candidate-sources.tar.xz');shutil.copyfile(r/'corrected/frozen/identity.json',corrected/'identity.json')
p=out/'README.md';s=p.read_text(encoding='utf-8');s+='''
## First delivery failure and correction

[CI44067803913 fails](delivery-first-failure/README.md): caught binding errors can
leave partial parameter values and poison later valid calls. The corrected code
clears the disjoint parameter window before binding and after failure. Existing
default-mutation/partial-binding cases reproduce and verify it; two CPython controls
agree. Tight-budget fixtures now reach their intended later refusal after admitting
the working window, preserving effects, aliases, terminal failure and cleanup.

Actual .NET11/10 focused corrections pass 124 public/88 internal cases each.
Corrected frozen core **27ed69a6** has a fresh nonincremental build, copied full
image, exact production snapshot and actual-worker three-case goldens/allocation
checks. Source before this correction remains fully preserved as historical
prototype evidence; its timing is not a measurement of the corrected HEAD.
Corrected-source comparison and a fresh combined delivery remain pending.

[Corrected identity](corrected/identity.json), [sources](corrected/candidate-sources.tar.xz),
[correction procedures and failures](delivery-correction-procedures.tar.xz).
''';p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'docs/BENCHMARKS.md';s=p.read_text(encoding='utf-8').replace('Full delivery pending. |','Initial prototype 0ebab036; caught-binding correction, updated comparison and full delivery pending. |',1);p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'docs/RUNTIME.md';s=p.read_text(encoding='utf-8').replace('Borrowed working slots initialize unassigned locals before entry and clear after','Disjoint parameter windows clear before binding and after a binding failure.\nBorrowed working slots initialize unassigned locals before body entry and clear after');p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');s=s.replace('R481 caller-owned native working windows:','R481 caller-owned native working windows (first CI44067803913 failed; corrected delivery pending):',1);s=s.replace('Batch full Windows/Ubuntu, actual .NET 11/10, original stress and installed Release','First delivery failed on both platforms: partial native binding poisoned a later\nvalid call; fixed by parameter-window initialization/unwind. Targeted correction\nchecks each actual target pass124public/88internal; two CPython controls agree.\nEarlier tiny-cap fixtures now fund initial working storage and still deny a larger\nretained payload after gate I/O, with original assertions preserved. Corrected\ncore27ed69a6 is copied/frozen after a fresh build; one affected source comparison\nand corrected full delivery are next. Never requery completed44067803913.\n\nBatch full Windows/Ubuntu, actual .NET 11/10, original stress and installed Release',1)
p.write_text(s,encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as stream:stream.write('''
R481 first delivery44067803913/34d2e393 fails Windows/Ubuntu .NET11: real partial-binding window poisoning plus fixed-small-budget setup assumptions. Correct disjoint parameters before binding and clear on error; no old wrapper/fallback restored. Existing failure/effect/alias/cleanup assertions preserved, payload fixtures separate working storage from a larger refused second allocation. Focused corrected actual11/10 each124public/88internal and2CPython default controls pass. Frozen corrected27ed69a6/source snapshot/actual3case goldens ready; initial0ebab036 timing remains historical, corrected pair and full delivery pending. Original failed CI/inputs/logs/correction fixtures preserved; publicationheld.
''')
print('First failed delivery and correction evidence preserved; original prototype timings explicitly historical, corrected qualification pending.')
