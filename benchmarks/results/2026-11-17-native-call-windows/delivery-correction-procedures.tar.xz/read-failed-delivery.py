from pathlib import Path
import hashlib,json,re,subprocess,zipfile
r=Path(__file__).parent/'delivery';run=json.loads((r/'dispatch.json').read_text(encoding='utf-8'))['run'];assert run==44067803913
p=r/'failed-run-logs.zip'
if not p.exists():
    result=subprocess.run(['gh','api',f'repos/Lokad/Lython/actions/runs/{run}/logs'],capture_output=True);assert result.returncode==0,result.stderr.decode();p.write_bytes(result.stdout)
rows=[]
with zipfile.ZipFile(p)as archive:
    for name in archive.namelist():
        if not name.endswith('.txt'):continue
        text=archive.read(name).decode('utf-8-sig',errors='replace');lines=text.splitlines();hits=[]
        for i,line in enumerate(lines):
            if any(x in line for x in ['[FAIL]','error CS','error :','Failed!','Passed!']):hits.append('\n'.join(lines[max(0,i-1):min(len(lines),i+9)]))
        if hits:rows.append(dict(file=name,hits=hits))
(r/'failed-log-summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
for row in rows:
    print(row['file'])
    for hit in row['hits'][:12]:print(hit)
print('Cached exact failed run logs',hashlib.sha256(p.read_bytes()).hexdigest())
