from pathlib import Path
import datetime,hashlib,io,json,re,subprocess,tarfile
r=Path(__file__).parent;root=Path('D:/code/Lython');delivery=r/'delivery';delivery.mkdir(exist_ok=False)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head==json.loads((r/'retained-head.json').read_text(encoding='utf-8'))['head']
old=json.loads((r.parent/'unary-slot-results-r477/delivery/inputs.json').read_text(encoding='utf-8'))
names=sorted(list(old['inputs'])+['tests/Lokad.Lython.PublicApi.Tests/HelperLocalLifetimeTests.cs','tests/Lokad.Lython.Tests/Harness/NativeCallWindow.cs'])
batch=subprocess.run(['git','cat-file','--batch'],cwd=root,input=''.join('HEAD:'+name+'\n'for name in names).encode(),capture_output=True,check=True).stdout
offset=0;inputs={};contents={}
for name in names:
    end=batch.index(b'\n',offset);header=batch[offset:end].decode().split();assert header[1]=='blob';size=int(header[2]);data=batch[end+1:end+1+size];assert len(data)==size and batch[end+1+size:end+2+size]==b'\n';offset=end+2+size
    inputs[name]=hashlib.sha256(data).hexdigest();contents[name]=data
assert offset==len(batch)and len(inputs)==2382
with tarfile.open(delivery/'inputs.tar.xz','w:xz')as archive:
    for name,data in contents.items():
        entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;archive.addfile(entry,io.BytesIO(data))
production=[name for name in names if name.startswith('src/Lokad.Lython/')];assert len(production)==585
with tarfile.open(r/'candidate-sources.tar.xz')as archive:
    for name in production:assert archive.extractfile(name).read().decode('utf-8-sig').replace('\r\n','\n')==contents[name].decode('utf-8-sig').replace('\r\n','\n'),name
(delivery/'inputs.json').write_text(json.dumps(dict(head=head,count=len(inputs),production=len(production),boundary='Exact committed Git blob bytes, archive verified against retained frozen production text; no working-tree timestamp/hash inference.',inputs=inputs),indent=2)+'\n',encoding='utf-8',newline='\n')
p=subprocess.run(['gh','workflow','run','ci.yml','--ref','master','-f','stress=true'],cwd=root,capture_output=True,text=True,encoding='utf-8')
(delivery/'dispatch.log').write_text(p.stdout+p.stderr,encoding='utf-8',newline='\n');assert p.returncode==0,p.stderr
m=re.search(r'https://github.com/Lokad/Lython/actions/runs/(\d+)',p.stdout);assert m,'Inspect acknowledgement; never retry a dispatched workflow.'
now=datetime.datetime.now(datetime.timezone.utc)
record=dict(head=head,workflow='ci.yml',stress=True,recordedAtUTC=now.isoformat(),run=int(m[1]),url=m[0],expectedEachPlatformTarget=dict(ordinaryInternal=4820,ordinaryPublic=18013,stressInternal=14,stressPublic=406),publicationHeld=True)
(delivery/'dispatch.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(delivery/'next-observation.json').write_text(json.dumps(dict(notBeforeUTC=(now+datetime.timedelta(seconds=300)).isoformat()),indent=2)+'\n',encoding='utf-8',newline='\n')
poll=(r.parent/'unary-slot-results-r477/poll-delivery.py').read_text(encoding='utf-8').replace('44050323147',str(record['run'])).replace("v['headSha'].startswith('d8611c85')","v['headSha']=="+repr(head))
(r/'poll-delivery.py').write_text(poll,encoding='utf-8',newline='\n')
print(json.dumps(record));print('Full delivery dispatched once;2382committed inputs/585production verified. Observe after',now+datetime.timedelta(seconds=300))
