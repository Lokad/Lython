from pathlib import Path
import re,zipfile
r=Path(__file__).parent/'delivery'
with zipfile.ZipFile(r/'failed-run-logs.zip')as a:
    name=next(n for n in a.namelist()if '/'not in n and 'ubuntu' in n);text=a.read(name).decode('utf-8-sig');text=re.sub(r'\x1b\[[0-9;]*m','',text);lines=text.splitlines()
    for target in ['FunctionBindingLifetimeTests','IntegerPayloadOwnershipTests','RootLifetimeContainmentTests','GzipPathScopeLifetimeTests','TextFileWriteCallBoundaryTests']:
        for i,line in enumerate(lines):
            if '  Failed 'in line and target in line:
                print('\n'.join(lines[i:i+13]));break
