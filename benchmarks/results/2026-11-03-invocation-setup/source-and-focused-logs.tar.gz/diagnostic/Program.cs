using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

// Component cost gate only. Existing public host/runtime and compilation paths;
// no source instrumentation, forced collections or tiering overrides.
var assembly = typeof(LythonEngine).Assembly;
var contextType = assembly.GetType("Lokad.Lython.Runtime.LythonRuntime+ExecutionContext", true)!;
var createBuiltins = contextType.GetMethod("CreateBuiltinVariables", BindingFlags.NonPublic | BindingFlags.Static)!.CreateDelegate<Func<object>>();
var hostAssembly = Assembly.LoadFrom(Path.Combine(AppContext.BaseDirectory, "Lokad.Lython.Benchmarks.dll"));
var host = (ILythonHost)Activator.CreateInstance(hostAssembly.GetType("Lokad.Lython.Benchmarks.BenchmarkHost", true)!, true)!;
var engine = new LythonEngine();
var budget = new LythonMemoryBudget();
using var compiled = engine.Compile("pass", budget);
if (!compiled.IsValid) throw new Exception("Invalid empty script");
var baseline = budget.ReservedBytes;
var options = new LythonRunOptions { MemoryBudget = budget };
object? last = null;
var operations = new (string Name, int Count, Action Action)[] {
    ("builtin-table", 8192, () => last = createBuiltins()),
    ("empty-sync-run-cleanup", 2048, () => { using var result = compiled.Run(host, options); if (!result.Success) throw new Exception(result.Failure?.Message); }),
    ("empty-async-run-cleanup", 2048, () => { using var result = compiled.RunAsync(host, options).GetAwaiter().GetResult(); if (!result.Success) throw new Exception(result.Failure?.Message); }),
    ("empty-compile-cleanup", 8192, () => { using var program = engine.Compile("pass", budget); if (!program.IsValid) throw new Exception("Compile failed"); })
};
var samples = new List<object>();
foreach (var operation in operations) {
    var start = Stopwatch.GetTimestamp();
    do { for(var i=0;i<operation.Count;i++) operation.Action(); }
    while(Stopwatch.GetElapsedTime(start).TotalSeconds < .5);
    if(budget.ReservedBytes != baseline) throw new Exception("Warmup funding did not return");
}
for(var round=0;round<9;round++) {
    foreach(var operation in round%2==0 ? operations : operations.Reverse()) {
        var bytes = GC.GetTotalAllocatedBytes(precise:true);
        var start = Stopwatch.GetTimestamp();
        for(var i=0;i<operation.Count;i++) operation.Action();
        var elapsed = Stopwatch.GetTimestamp()-start;
        var allocated = GC.GetTotalAllocatedBytes(precise:true)-bytes;
        if(budget.ReservedBytes != baseline) throw new Exception("Funding did not return");
        samples.Add(new {round, operation=operation.Name, operation.Count, elapsedTicks=elapsed, microseconds=elapsed*1e6/Stopwatch.Frequency/operation.Count, allocatedBytesPerInvocation=(double)allocated/operation.Count});
    }
}
GC.KeepAlive(last);
compiled.Dispose();
if(budget.ReservedBytes != 0) throw new Exception("Compilation funding did not return");
Console.WriteLine(JsonSerializer.Serialize(new {
    kind="component-diagnostic-not-causal-performance-comparison", date=DateTimeOffset.UtcNow,
    framework=RuntimeInformation.FrameworkDescription, platform=RuntimeInformation.OSDescription,
    coreSha256=Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(assembly.Location))),
    revision=assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion,
    Stopwatch.Frequency, budgetReturnedToZero=true,
    boundaries=new {builtins="table construction only, excludes execution and cleanup; consumed to prevent elision", execution="public pass script, host worker scheduling, result success check and result disposal; cached compilation and precreated options/host excluded", compilation="public pass compilation with shared budget and disposal; excludes execution", allocations="whole-process GC.GetTotalAllocatedBytes, natural collections, includes worker allocations"},
    samples
}));
