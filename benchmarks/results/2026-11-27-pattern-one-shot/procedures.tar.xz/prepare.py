from base64 import b64decode
from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import os
import shutil
import subprocess
import tarfile
import tempfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
notes=lab.parent
previous=notes/'signed-regex-small-match-20261127'
local_base=previous/'local'
donor=previous/'comparison/quiet'
local=lab/'local'
quiet=lab/'comparison/quiet'
local.mkdir()
(quiet/'candidate').mkdir(parents=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
write=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
sha=lambda p:sha256(p.read_bytes()).hexdigest()
manifest=lambda p:{f.name:sha(f) for f in p.iterdir()}
core='Lokad.Lython.dll'
adapter='Lokad.Lython.Utf8Regex.dll'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('b285b0bcd')
assert not subprocess.check_output(['git','diff','7305efabf',head,'--','src','benchmarks/Lokad.Lython.Benchmarks'],cwd=repo)
patch=subprocess.check_output(['git','diff','--binary','HEAD','--','src'],cwd=repo)
(local/'candidate.patch').write_bytes(patch)
assert patch.count(b'diff --git ')==6 and b'program.TryMatch(subject, window' in patch
(local/'regression.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD','--','tests','tools/PackageSmokeTest'],cwd=repo))
pin=read(donor/'identity.json')
assert sha(local_base/'candidate.patch')==pin['sourcePatchSHA256']
assert sha(donor/'observations.tar.xz')==read(donor/'terminal-status.json')['receipt']['archiveSHA256']
assert pin['imageFiles']['reference']['Lokad.Lython.Benchmarks.dll']==pin['imageFiles']['candidate']['Lokad.Lython.Benchmarks.dll']
files=pin['imageFiles']['candidate']
assert len(files)==32 and manifest(local_base/'candidate')==files
receipt=read(donor/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['quietBeforeAndAfter'] and receipt['archiveSHA256']==sha(donor/'observations.tar.xz')
for role in ('reference','candidate'):
    shutil.copytree(local_base/'candidate',local/role)
new=repo/'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0'
overlays=(core,adapter)
for name,project in ((core,'Lokad.Lython'),(adapter,'Lokad.Lython.Utf8Regex')):
    assert sha(new/name)==sha(repo/'src'/project/'bin/Release/net11.0'/name)
signed_packages=pin['signedPackageSHA256']
for name in ('Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll'):
    assert sha(new/name)==files[name]
for name in overlays:
    shutil.copyfile(new/name,local/'candidate'/name)
    shutil.copyfile(new/name,quiet/'candidate'/name)
images={role:manifest(local/role) for role in ('reference','candidate')}
assert images['reference']==files
assert {k for k,h in files.items() if h!=images['candidate'][k]}==set(overlays)

catalog=read(donor/'representative.json')
prior=read(notes/'regex-local-one-shot-20261121'/'representative.json')
compiler=read(notes/'short-path-cpython-20261126'/'comparison/quiet/representative.json')
compiled='scripts.regex-log-search.compiled'
module='scripts.regex-log-search.module'
cursor='scripts.regex.cursor-records'
invoice='scripts.csv-invoice.method-policy.quoted-control'
selectors='diagnostic.generated-regex-record-selectors'
cases={case['id']:case for case in (*prior['cases'],*catalog['cases'],*compiler['cases'])}
catalog['cases']=[cases[k] for k in (compiled,module,cursor,invoice,selectors)]
write(quiet/'representative.json',catalog)
write(quiet/'jobs.json',{'warm':[[compiled,'warm'],[cursor,'warm'],[module,'warm'],[invoice,'warm'],[selectors,'compile']]})
for name in ('cpython-worker.py','run.sh'):
    shutil.copyfile(donor/name,quiet/name)
assert sha(quiet/'cpython-worker.py')==pin['cpythonWorkerSHA256'] and b'\r' not in (quiet/'run.sh').read_bytes()
identity=dict(sourceRevision=head,sourcePatchSHA256=sha(local/'candidate.patch'),imageFiles=images,
    coreSHA256={role+suffix:items[core] for role,items in images.items() for suffix in ('','-control')},
    catalogs={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')},
    comparisonHostRevision=pin['comparisonHostRevision'],cpythonWorkerSHA256=pin['cpythonWorkerSHA256'],
    expectedCPythonSHA256=pin['expectedCPythonSHA256'],donorArchiveSHA256=receipt['archiveSHA256'],
    signedPackageSHA256=signed_packages,
    purpose='Compare pattern-level one-shot matching and constant analysis on the same signed 0.5.0 backend.')
write(quiet/'identity.json',identity)
collector=(donor/'collect.py').read_text(encoding='utf8').replace('lython-b1859-fixtures','lython-b1862-fixtures')
compile(collector,'collect.py','exec')
(quiet/'collect.py').write_text(collector,encoding='utf8',newline='\n')
ssh=(previous/'quiet-vm.py').read_text(encoding='utf8').replace('lython-b1859-signed-regex-small-match-20261127','lython-b1862-pattern-one-shot-20261127')
ssh=ssh.replace("name=='Lokad.Lython.Utf8Regex.dll'", "name in ('Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll')")
compile(ssh,'quiet-vm.py','exec')
(lab/'quiet-vm.py').write_text(ssh,encoding='utf8',newline='\n')
shutil.copyfile(previous/'summarize-quiet.py',lab/'summarize-quiet.py')

sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role,fileset in images.items():
    folder=local/role
    report=local/f'{role}-verify.json'
    subprocess.run([dotnet,folder/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',quiet/'cpython-worker.py','--out',report],env=env,check=True,timeout=65)
    proof=read(report)
    assert proof['state']=='Completed' and proof['caseCount']==5 and proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['adapter']['sha256']==fileset['Lokad.Lython.Benchmarks.dll']
    assert proof['launched']['library']['sha256']==fileset[core]
    allocated=local/f'{role}-allocated'
    shutil.copytree(folder,allocated)
    for p in (local_base/'candidate-allocated').glob('ValidatedAllocation*'): shutil.copyfile(p,allocated/p.name)
    assert all(sha(allocated/name)==h for name,h in fileset.items())

names=['identity.json','representative.json','jobs.json','cpython-worker.py','run.sh','collect.py',*(f'candidate/{name}' for name in overlays)]
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names:archive.add(quiet/name,arcname=name)
staged={name:dict(length=(quiet/name).stat().st_size,sha256=sha(quiet/name)) for name in names}
write(quiet/'upload.json',dict(root='pattern-one-shot-b1862-20261127',donor=read(donor/'upload.json')['root'],donorFiles=images['reference'],
    donorArchive=identity['donorArchiveSHA256'],payloadSHA256=sha(payload),files=staged,
    expandedBytes=sum(x['length'] for x in staged.values()),minimumAfterStageBytes=6*1024*1024))

rows=[]
for mode in ('sync','async'):
    for case in catalog['cases']:case['runAsync']=mode=='async'
    selection=local/f'{mode}-allocation-catalog.json'
    write(selection,catalog)
    pair=[]
    for role in images:
        folder=local/f'{role}-allocated'
        report=local/f'{role}-{mode}-allocation.json'
        subprocess.run([dotnet,folder/'ValidatedAllocation.dll',folder,selection,report],env=env,check=True,timeout=75)
        pair.append(read(report)['rows'])
    for before,after in zip(*pair,strict=True):
        assert before['id']==after['id'] and before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
        change=dict(case=before['id'],mode=mode,clr=[median(r['allocatedBytesPerInvocation']) for r in (before,after)],
                    peak=[r['peakExecutionMemoryBytes'] for r in (before,after)],
                    compiled=[r['compiledReservedBytes'] for r in (before,after)])
        rows.append(change)
        print(change,flush=True)
write(local/'allocation-summary.json',rows)
