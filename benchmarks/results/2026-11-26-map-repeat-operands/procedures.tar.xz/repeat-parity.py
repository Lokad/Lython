from itertools import repeat
marker=[]
alias=repeat(marker)
def choose(value,left,right):
 left.append(value)
 return right
rows=map(choose,[1,2,3],alias,alias)
first=next(rows)
second=next(rows)
print(first is second is marker, marker, next(alias) is marker)
source=iter(range(3))
bounded=repeat(marker,1)
print(list(map(lambda x,y,z:x,source,bounded,alias)),next(source))
print(next(map(lambda a,b:b,alias,repeat(None))) is None)
