set -eu
root=/dev/shm/lython-activation-cpu-b175-20261103
tar -xzf "$root/payload.tgz" -C "$root"
ln -s /dev/shm/lython-terminal-utf8-b174-20261103/candidate "$root/candidate"
sudo systemd-run --unit=lython-b175-activation-cpu-20261103 --uid=lokad --wait --collect --property=RuntimeMaxSec=150 --property=KillMode=control-group --property=TimeoutStopSec=10 --property=SendSIGKILL=yes /bin/sh "$root/collect.sh"
