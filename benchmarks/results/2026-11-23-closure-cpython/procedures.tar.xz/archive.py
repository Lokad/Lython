from pathlib import Path
import hashlib
import json
import shutil
import tarfile
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
dest = repo / 'benchmarks/results/2026-11-23-closure-cpython'
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
identity = read(lab/'identity.json')
terminal = read(lab/'terminal-status.json')
assert terminal['exitCode'] == '0' and all(terminal['receipt'][key] for key in ('complete','archivedAndVerifiedUnderLease','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter'))
assert sha(lab/'observations.tar.xz') == terminal['receipt']['archiveSHA256']
assert read(lab/'summary.json')['timedBatches'] == 168
assert not subprocess.check_output(['git','diff','--name-only',identity['sourceRevision'],'HEAD','--','src'],cwd=repo)
image = lab.parent/'closure-result-consumer-20261123/candidate'
assert {name:sha(image/name) for name in identity['imageFiles']['candidate']} == identity['imageFiles']['candidate']
dest.mkdir(exist_ok=True)
for name in ('identity.json','terminal-status.json','observations.tar.xz','summary.json'):
    shutil.copyfile(lab/name,dest/name)
with tarfile.open(dest/'procedures.tar.xz','w:xz') as archive:
    for name in ('archive.py','prepare.py','quiet.py','summarize.py','candidate-verify.json','selection.json','launch.log','observe-not-before','retrieval.log'):
        archive.add(lab/name,arcname=name,recursive=False)
print(dest)
