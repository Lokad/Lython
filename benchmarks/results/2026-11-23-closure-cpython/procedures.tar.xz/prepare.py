from pathlib import Path
import json
import shutil

lab=Path(__file__).resolve().parent
template=lab.parent/'forwarded-global-cpython-20261123'
source=lab.parent/'closure-result-consumer-20261123'
load=lambda path:json.loads(path.read_text(encoding='utf-8'))
write=lambda name,data:(lab/name).write_text(data,encoding='utf-8',newline='\n')
write_json=lambda name,data:write(name,json.dumps(data,indent=2,ensure_ascii=False)+'\n')
catalog=load(template/'representative.json')
extra=load(source/'comparison/representative.json')
short='diagnostic.text-summary.nonlocal-computed-width.large'
quote='scripts.csv-invoice.method-policy.quoted-control'
factory='scripts.annotated-rule-closures.nested-factories.postponed'
supplied='scripts.ordinary-fully-supplied-helper'
for name in (short,quote):
    a=next(row for row in catalog['cases'] if row['id']==name)
    b=next(row for row in extra['cases'] if row['id']==name)
    assert a==b
catalog['cases']=[row for row in catalog['cases'] if row['id'] in (short,quote,factory)]
catalog['cases'].extend(row for row in extra['cases'] if row['id']==supplied)
assert {a['id'] for a in catalog['cases']}=={short,quote,factory,supplied}
write_json('representative.json',catalog)
write_json('jobs.json',[[short,'warm'],[supplied,'warm'],[quote,'warm'],[factory,'warm'],[short,'compile'],[short,'compile-run']])
write_json('selection.json',dict(lab=source.name,remoteDirectory='closure-result-consumer-b1497-20261123',retainedRevision='9e0cf58f8'))
shutil.copyfile(source/'comparison/quiet/run.sh',lab/'run.sh')
assert b'\r' not in (lab/'run.sh').read_bytes()

def install(name,replacements):
    text=(template/name).read_text(encoding='utf-8')
    for a,b in replacements:
        assert a in text,(name,a)
        text=text.replace(a,b)
    compile(text,name,'exec')
    write(name,text)

install('quiet.py',[
    ('forwarded-global-cpython-b1491-20261123','closure-cpython-b1499-20261123'),
    ('lython-b1491-forwarded-global-cpython-20261123','lython-b1499-closure-cpython-20261123'),
    ('"--","src","tests"','"--","src","benchmarks/cpython-worker.py","benchmarks/Lokad.Lython.Benchmarks"'),
    ('proof["caseCount"]==5','proof["caseCount"]==4'),
])
install('collect.py',[
    ('CPython checkpoint after forwarding positional call operands','CPython checkpoint after retaining direct closure assignment'),
])
install('summarize.py',[])
install('archive.py',[
    ('2026-11-23-forwarded-global-cpython','2026-11-23-closure-cpython'),
    ('forwarded-global-call-20261123/candidate','closure-result-consumer-20261123/candidate'),
    ("'--','src','tests'","'--','src'"),
    ("'archive.py','quiet.py'","'archive.py','prepare.py','quiet.py'"),
])
