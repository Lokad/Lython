from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
out = lab.parents[3] / "benchmarks/results/2026-11-25-resolved-guest-call"
quiet = lab / "comparison/quiet"
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
identity = read(quiet/"identity.json")
assert out.is_dir()
assert sha(lab/"candidate.patch") == identity["sourcePatchSHA256"]
for role, files in identity["imageFiles"].items():
    assert {p.name:sha(p) for p in (lab/role).iterdir()} == files
for folder, name in ((quiet, "identity.json"), (lab, "allocation-summary.json"), (lab, "tape-summary.json")):
    shutil.copyfile(folder/name, out/name)
procedures = [
    "candidate.patch", "freeze.py", "check-tape.py", "allocations.py", "archive.py",
    "prepare-quiet.py", "quiet.py", "package.py", "test-ubuntu.sh",
    "candidate-build.log", "windows-net11.log", "ubuntu-net11.0-Lokad.Lython.PublicApi.Tests.log",
    "ubuntu-net11.0-Lokad.Lython.Tests.log", "candidate-allocation-final.json", "reference-allocation-final.json",
    "tape-candidate.json", "tape-reference.json", "comparison/candidate-verify.json", "comparison/reference-verify.json",
    "comparison/quiet/storage-custody.json", "comparison/quiet/upload.json", "comparison/quiet/launch.log",
    "retire-core-copy.py", "retired-core/local-custody.json", "retired-core/vm-custody.json", "verified-raw-replicas.json",
]
with tarfile.open(out/"procedures.tar.xz", "w:xz") as archive:
    for name in procedures:
        archive.add(lab/name, arcname=name, recursive=False)
with tarfile.open(out/"procedures.tar.xz") as archive:
    assert archive.getnames() == procedures
    assert all(hashlib.sha256(archive.extractfile(name).read()).hexdigest() == sha(lab/name) for name in procedures)
