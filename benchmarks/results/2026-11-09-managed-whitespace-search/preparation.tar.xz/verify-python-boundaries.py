from pathlib import Path
import hashlib,json,re,subprocess,sys,textwrap
r=Path(__file__).parent
p=Path('tests/Lokad.Lython.PublicApi.Tests/WhitespaceSplitBoundaryTests.cs')
template=textwrap.dedent(p.read_text(encoding='utf-8').split('Compile($$"""',1)[1].split('"""',1)[0]).strip()+'\n'
rows=[]
for size in [63,64,65,4095,4096,4097]:
    source=template.replace('{{size}}',str(size))
    done=subprocess.run([sys.executable,'-I','-c',source],capture_output=True,text=True,encoding='utf-8')
    assert done.returncode==0 and done.stdout=='ok\n',(size,done.stdout,done.stderr)
    rows.append(dict(size=size,sourceSHA256=hashlib.sha256(source.encode('utf-8')).hexdigest(),stdout=done.stdout))
(r/'python-boundaries.json').write_text(json.dumps(dict(python=sys.version,sourceFile=p.as_posix(),cases=rows,coverage='All128ASCII values, mixed NUL/DEL/Greek/emoji, forward/reverse split/maxsplit, Unicode casing/context and UTF8 byte chunk boundaries.'),indent=2)+'\n',encoding='utf-8')
print('Six existing public boundary scripts independently pass underCPython; no duplicate tests added.')
