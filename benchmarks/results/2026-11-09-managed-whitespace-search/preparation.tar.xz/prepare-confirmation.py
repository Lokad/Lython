from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;v=r/'b508';v.mkdir();old=r.parent/'borrowed-call-entry-r151/b506'
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
with(r/'final-build.log').open('w',encoding='utf-8')as log:
    done=subprocess.run([env['DOTNET_HOST_PATH'],'build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0,(r/'final-build.log').read_text(encoding='utf-8')[-3000:]
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',v/'current-core.dll')
shutil.copyfile(r/'images/before/Lokad.Lython.dll',v/'baseline-core.dll')
proof=dict(baselineRevision=(r/'baseline-revision.txt').read_text(encoding='utf-8').strip(),productionSources={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*.cs')if'obj'not in p.parts},candidateCoreSHA256=hashlib.sha256((v/'current-core.dll').read_bytes()).hexdigest(),refinement='Both fixed ASCII inventories now derive from the existing classifier; same measured bulk kernel, no duplicated whitespace definition. Original desktop image/source/adversity retained. Fresh nonincremental final-source freeze.')
(r/'final-source.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
(v/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython']))
jobs=[['scripts.text-summary-helpers.large','warm'],['scripts.text-summary-helpers.large','warm-async'],['scripts.csv-validated-records.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py','assess-vm.py']:
    s=(old/name).read_text(encoding='utf-8').replace('borrowed-call-entry-b506-20261109','bulk-whitespace-b508-20261109').replace('lython-b506-borrowed-call-entry-20261109','lython-b508-bulk-whitespace-20261109').replace('borrowed-call-entry-b506-launch.py','bulk-whitespace-b508-launch.py').replace('lython-b506-fixtures','lython-b508-fixtures')
    if name=='collect.py':
        a=s.index('jobs=[');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n'+s[b:]
        a=s.index("purpose='R151");b=s.index('\n                  warmupSeconds=',a);s=s[:a]+"purpose='R157 one bounded quiet confirmation of managed bulk ASCII whitespace discovery. Same whole text sync/async and unaffected CSV control; no allocation or CPU claim from inconclusive/adverse desktop results.',"+s[b:]
        s=s.replace('started < 180','started < 120')
    if name in ['archive-owned.py','retrieve.py']:s=s.replace("==5","==3").replace("== 5","== 3").replace("<180","<120").replace("Five-job", "Three-job")
    if name=='launch.py':s=s.replace("'assert len(jobs)==5 '","'assert len(jobs)==3 '").replace('RuntimeMaxSec=210','RuntimeMaxSec=150').replace('ownerSeconds=210','ownerSeconds=150').replace('seconds=270','seconds=210')
    if name.endswith('.py'):compile(s,name,'exec')
    (v/name).write_text(s,encoding='utf-8',newline='\n')
for target,source in [('representative.json',r/'catalog.json'),('baseline-source.json',r/'baseline-proof.json')]:shutil.copyfile(source,v/target)
shutil.copyfile('PLAN.md',v/'contract.md')
for target,name in [('common-worker.dll','Lokad.Lython.Benchmarks.dll'),('common-adapter.dll','Lokad.Lython.Utf8Regex.dll'),('common-worker.deps.json','Lokad.Lython.Benchmarks.deps.json'),('common-worker.runtimeconfig.json','Lokad.Lython.Benchmarks.runtimeconfig.json')]:shutil.copyfile(r/'images/before'/name,v/target)
identity=dict(sourceRevision='Qualified78fd7bb4 production / doc-only3fb8025d versus final R157 source, two fresh nonincremental freezes; common worker/adapter',coreSHA256={role:hashlib.sha256((v/name).read_bytes()).hexdigest()for role,name in [('reference','baseline-core.dll'),('reference-control','baseline-core.dll'),('candidate','current-core.dll'),('candidate-control','current-core.dll')]},auxiliaryFiles={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in(r/'images/before').glob('*.dll')if p.name!='Lokad.Lython.dll'},catalogSHA256=hashlib.sha256((v/'representative.json').read_bytes()).hexdigest())
(v/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(v/'focused.json').write_text(json.dumps(dict(status='178internal/219public per actual11/10 pass on final source; six existing boundary scripts independently pass CPython; no duplicate architecture-only tests.'),indent=2)+'\n',encoding='utf-8')
(v/'setup-contract.json').write_text(json.dumps(dict(ownerSeconds=150,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=12,jobs=3,unchangedWorkerAndProtocol=True),indent=2)+'\n',encoding='utf-8')
(v/'sizing.json').write_text(json.dumps(dict(jobs=3,warmupPerRoleSeconds=5,rounds=7,targetBatchSeconds=.15,expectedSeconds=95,ownerSeconds=150),indent=2)+'\n',encoding='utf-8')
(v/'pre-measurement-plan.md').write_text('''# R157 bounded confirmation
Three same-source jobs: maintained text sync/async, unaffected CSV control. Four
independent processes,5s warmup each,7rotated150ms rounds. Common frozen workers,
normal GC/tiering, RAM guest fixtures separate from persistent evidence/images.
Warm clock includes mediated I/O, full output validation and prior-result cleanup;
excludes startup/compilation/reset/protocol/final teardown. External CPU separate.
Initial desktop source15e49 has unchanged allocation, textsync−1.3to+3.6%, async
+5.9to10.1%; unchanged search controls25.5% apart. Preserve all adverse evidence.
Refine only metadata construction to derive both inventories from one classifier,
then freeze the final source freshly. No cross-source final-binary timing claim.
One quiet confirmation to decide retention; no fixed percentage veto or CPU claim
from source shape. Keep Python whitespace/casing/maxsplit, bounded cancellation,
terminal refusal, aliases/capacity/replacement funding and awaited cleanup.
Finite150sowner+30stop+30margin; reserve30s for final work/cleanup. Archive under
lease, join/unmount/verify localSHA; original240MiB OS floor+12MiB headroom unchanged.
Recover only exact already-tracked redundant remote compressed archives under
fresh idle/single-alias/hash/owner/group/mode/parents/pre-mutation proof; preserve
all raw traces/receipts/frozen images and canonical tracked local archives.
No producer replay, new worker/framework, full platform replay or publication.
''',encoding='utf-8')
with tarfile.open(v/'payload.tgz','w:gz')as archive:
    for p in v.iterdir():
        if p.name!='payload.tgz':archive.add(p,arcname=p.name)
with tarfile.open(v/'payload.tgz')as archive:required=sum(((m.size+4095)//4096)*4096 for m in archive.getmembers())+(240+12)*1024*1024
(v/'payload-sizing.json').write_text(json.dumps(dict(requiredFreeBytes=required,payloadBytes=(v/'payload.tgz').stat().st_size,originalFloorsPreserved=True),indent=2)+'\n',encoding='utf-8')
print('Final source frozen, three jobs, expected95s/owner150s. Required free bytes:',required)
