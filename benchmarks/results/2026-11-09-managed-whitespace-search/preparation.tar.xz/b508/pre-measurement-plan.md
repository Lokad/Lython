# R157 bounded confirmation
Three same-source jobs: maintained text sync/async, unaffected CSV control. Four
independent processes,5s warmup each,7rotated150ms rounds. Common frozen workers,
normal GC/tiering, RAM guest fixtures separate from persistent evidence/images.
Warm clock includes mediated I/O, full output validation and prior-result cleanup;
excludes startup/compilation/reset/protocol/final teardown. External CPU separate.
Initial desktop source15e49 has unchanged allocation, textsync−1.3to+3.6%, async
+5.9to10.1%; unchanged search controls25.5% apart. Preserve all adverse evidence.
Refine only metadata construction to derive both inventories from one classifier,
then freeze the final source freshly. No cross-source final-binary timing claim.
One quiet confirmation to decide retention; no fixed percentage veto or CPU claim
from source shape. Keep Python whitespace/casing/maxsplit, bounded cancellation,
terminal refusal, aliases/capacity/replacement funding and awaited cleanup.
Finite150sowner+30stop+30margin; reserve30s for final work/cleanup. Archive under
lease, join/unmount/verify localSHA; original240MiB OS floor+12MiB headroom unchanged.
Recover only exact already-tracked redundant remote compressed archives under
fresh idle/single-alias/hash/owner/group/mode/parents/pre-mutation proof; preserve
all raw traces/receipts/frozen images and canonical tracked local archives.
No producer replay, new worker/framework, full platform replay or publication.
