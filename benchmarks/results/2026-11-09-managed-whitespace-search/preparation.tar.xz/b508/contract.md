# Lokad.Lython 0.11.0

Updated 2026-11-09 (Paris). Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial whole-script performance. Completing
an isolated experiment does not complete it. Current contracts live in docs; original
failures, prototypes and qualification live in [history](benchmarks/EXPERIMENTS.md).

## Actual delivery status

| Work | Delivery | Qualification / limits |
| --- | --- | --- |
| Shared compiler-fact correction, direct UTF-8 formatting/storage, native helper returns | Committed foundations | Qualified. Keep allocation and elapsed claims separate; no unchanged replay. |
| R119–R135 record/lookup facts, storage lifetimes, declaration/literal/static-call facts, native inputs/Boolean identity | Committed | Qualified Windows/Ubuntu actual .NET 11/10, original Stress and installed consumers at later checkpoints. |
| R138/R139 closed helpers and incoming lexical reads | Committed, class/global proof corrections preserved | Qualified. Source-pair CPU benefits and control uncertainty remain in history. |
| R141 owned hash stress canceller | Committed `7aa637bf` | Full CI42573178034 cached success; original failed conditions/mutation proof retained. Never requery. |
| R142 shared generator compilation/state | Committed `081052fa`, test correction `27353cfb` | Fully qualified CI42579357509; prototype timings remain distinct from delivery binary. Never requery. |
| R140/R143 CPU attribution | Committed | One usable text/search capture each, exact sources/raw retained. Inclusive VM-prefix shares include useful work. |
| R144 helper proof gate | Completed assessment | Guards precede admission/effects; execution rereads live data. No safe phase deletion selected, no second guard VM/cache. Not a permanent design ban. |
| R145 one executable callable engine | Committed `65ed6cf7`, correctness/fixture correction `58d3ec0f` | Fully qualified: corrected CI42588611410 cached terminal success, Windows/Ubuntu actual11/10, original Stress both and installed consumers. Original failure/correction and measured65ed source retained. Never requery. |
| R146 CPython refresh | Committed `115dda5f`; measured `65ed6cf7`/core082a | Twelve jobs250.847s, all quiet/output/ownership/cleanup/archive gates pass. Do not relabel timings as the correction. |
| R147 general operand transport gate | Committed `c301812f` | Existing input/result forwarding already removes the presumed ordinary round trip. Store continuation retains cleanup/check/span semantics. Static census, no timing claim. |
| R148 filename-filter suspension | Committed `46e3746e` | Fully qualified with R149 at42598266368. Original pending-I/O failure and focused goldens retained. |
| R149 native callback transport | Committed `afb11d97`, measured core6417B97A | Fully qualified CI42598266368 cached success: bothOS actual11/10, original Stress both and installed consumers. Never requery. |
| R150 JSON-report attribution | Committed `2640437c`; boundary clarification `c89d6914` | One current-source usable capture, source gate finds no ordinary instruction copy or duplicate plain-string parse. No speedup claim; no unchanged second capture. |
| R151 borrowed callable entry | Committed `99844959`, measured core21CF1118 | Fully qualified42605184549 cached success: bothOS actual11/10, original Stress both and installed consumers. Never requery. Original cleanup failures/fix and constructor/text debt retained. |
| R154 workspace capacity | Committed `200d195b`, measured core85B9BCEB | Fully qualified42615908221/source78fd7bb4: bothOS actual11/10, original Stress both and installed consumers. Original failed prototype/adverse timings retained. |
| R155 valid DEFLATE | Committed `78fd7bb4`; handoff merged/removed | Focused147 internal/377 public per actual11/10; valid fixture originally failed both APIs, now passes with malformed controls and shared-owner cleanup. Full delivery42615908221 cached success, bothOS actual11/10, original Stress both and installed consumers. |
| Prepared maps, call arenas/control, shared string windows | Held/restored prototypes | Slower or complex variants and useful independent semantic fixes remain in history; no permanent bans. |

## Evidence and uncertainty

[BENCHMARKS.md](docs/BENCHMARKS.md) separates compilation, warm and compile-to-result.
Measured65ed / CPython3.13.16 complete CSV/text/JSON-report/search ratios:
1.13–1.17× /1.49–1.51× /1.35× /1.34–1.35×. Warm:1.15–1.17× /1.56–1.60× /
1.37–1.38× /1.61–1.63×. Compile roughly1.05–1.09×, search0.95×. Variable controls
remain visible; older rows retain their own sources. Includes mediated RAM-file I/O,
full output checks and prior-result cleanup; excludes startup/reset/protocol/final
cache teardown. Pending I/O, embedding tails and large-tree/file throughput unknown.
Search input has2,049 physical lines and exits at1,025; both engines run the same work.

Native helper returns: allocation−19.92/19.31%, distinct from diagnostic elapsed.
Formatting: allocation−8.67%; controlled B102 elapsed/CPU−5–8% supports retention,
while original adverse15.125ms remains unexplained and retained. No unchanged campaign.

R142: text allocation−15.1%; quiet affected pipelines improve, supporting CPU.
Compile allocation+1.3–1.6% and report control+1.17–4.54%elapsed/+0.39–4.44%CPU
remain accepted/unresolved debt. Original desktop JSON adversity survives. No final-
binary timing claim or attempt to settle this by comparing unrelated checkpoints.

R145: remove PyFunction, its mode/177-line duplicate dispatcher, runtime lambda
lowering/compilation and unused bodies; preserve actual executable capture facts
and real lowered consumers. Complete class-callable CSV/text/JSON warm allocation
−23–26%/−74–76%/−56–57%; quiet elapsed−9–12%/−38–39%/−13–15%, supporting CPU.
Compile allocation+3.2–5.2% accepted; report control+0.05–1.12%elapsed/0–4.44%coarseCPU
uncertain. Source pairs are not CPython/shape ratios. Measured source65ed remains
explicit after58d3's scope correction. [Evidence](benchmarks/results/2026-11-09-callable-consolidation/README.md).

## Prioritized non-regex deliverables

1. **R157 active uncommitted prototype: managed bulk ASCII whitespace discovery.**
   Fresh nonincremental baseline3fb8025d frozen; scalar scanner replaced, no old
   alternative kept. Focused178 internal/219 public per actual11/10 pass. Six
   existing boundary scripts independently pass CPython. One short local comparison
   in progress: five maintained whole scripts,32-job batches/five rotations/two
   unchanged baseline controls, warm sync/async and compilation separate. No CPU
   claim; no VM/CI run or full qualification for this prototype yet.
   R156 identifies62/1194 guest leaves in CollectWhitespaceForward; other text work
   and dispatch remain real costs. Replace the scalar ASCII category-run loop with
   standard managed SearchValues searches, forward/reverse, within existing chunks.
   The two fixed character inventories are immutable metadata, no guest cache/pool,
   per-operation backing or new option. Keep Python's29 whitespace scalars, Unicode
   casing/context, maxsplit/rsplit and owned final fragments exactly as today.
   Expected deletion: per-byte ASCII category tests in the shared run scanner;
   no custom SIMD/unsafe/native work, second execution route or quota.
   Acceptance: existing split/casing/cancellation/refusal/alias checks on actual11/10,
   trusted Python boundary cases where missing, one short whole text comparison
   plus CSV/JSON/search and compile controls. Freeze both sources nonincrementally.
   No CPU claim from allocation or desktop uncertainty; allow bounded confirmation
   only when materially useful. Complete by retaining/removing the prototype with
   explicit regression debt; broader performance objective remains open.

2. **R156 complete: same-process prefix/JIT attribution.**
   Selected because inclusive prefix counts still obscure actual primitive work.
   One maintained text script,6s existing-tool capture with matching JIT listing;
   reuse fully qualified99844959/core21cf, explicitly notHEAD. Method/tier/extent
   identity must uniquely match; ambiguous/native/unknown offsets stay unknown.
   No cross-process offset transfer. Bound offline attribution30min and choose one
   displaced phase with whole-script semantic acceptance; no automatic opcode,
   arena or tagged-value redesign. Read-only VM preflight idle but260743168B is
   below original252MiB gate before payload. Recover only redundant B506 archive
   after fresh single-alias/SHA/metadata/parents/persisted-plan proof; local tracked
   archive/raw/receipt/workers survive, all floors unchanged. B507 terminal success,6.104s/1194guest samples/6.01guestCPU seconds; no users/RAM remain.
   Unique same-process Tier1 extent14159B/246self samples. Observed loop bounds/
   switch75samples6.28%; mixed instruction fetch/required checks44samples3.69%.
   These are not savings. Prefix includes useful operations; no larger dispatch VM,
   loop-rotation continuation machinery or universal tagged values selected.
   New selected source phase is R157. Original failed classifier and headroom,
   source/script/core/aux/golden/current-source-delta identities retained in
   benchmarks/results/2026-11-09-prefix-generated-code. No repeated capture.

   **Existing evidence for the redesign:** Remaining
   warm text/search gaps are real; current profiles do not isolate one removable cause.
   **R150 complete:** maintained JSON/currentafb11d97 capture gives1201guest samples,
   5.66%unknown; observed prefix40.47%,JSON19.90%,dictionary7.83%,admission6.91%,
   nativecall6.74%,text6.41%,managed cancellation/stack4.33%. Prefix includes useful
   inlined work; source already reads immutable instructions by readonly reference,
   skips backend reparsing of plain strings and shares record keys/completed loops.
   Default JSON calls skip general binding. No duplicate phase selected; no second
   capture/new framework from these counts. [Evidence](benchmarks/results/2026-11-09-json-runtime-attribution/README.md).
   Module facts are retained at lexical preparation's end; early binding-only facts
   precede final class-cell demand. Do not cache partial class facts as final facts.
   R151 removes the separate packet pool with actual consume-before-suspension
   support; dynamic/constructor ownership cost remains explicit. Do not restore it.
   **Next bounded family: complete short config editing.** Existing config-edit.py
   represents compile-once/run-once host work; current large-script profiles do not
   establish its setup/compilation share. Inspect existing catalog/evidence first.
   Separate compilation, warm invocation, mediated I/O and cleanup using existing
   tools; only fill a material gap. Before redesign, name the demonstrated setup/
   analysis work eliminated, per-run mutable state preserved and displaced code.
   No new benchmark framework, blanket builtin singleton cache or repeated full lanes.
   Config gate: existing4598 complete ratio1.09–1.10× is historical, not currentHEAD;
   old1c369000 capture has only54guest samples and does not establish a setup cause.
   SharedFunctions/type signatures are already immutable/shared; no initializer
   redesign or new campaign selected. Immutable-input native proof remains a source
   hypothesis: current guard also validates live reads/mutable containers, so a
   second proof plan without retiring real work is not selected at this checkpoint.
   Start with general instruction/operand/call representation across complete scripts,
   then remaining text/record work. State the current duplicated work or storage and
   displaced code before implementation. R147 confirms direct input/result forwarding
   and nonmirrored maintained modules/helpers already exist; do not reimplement them.
   Retained store continuations protect pending disposal and publication ordering.
   No new arena, dispatch framework, guard VM, per-call cache or syntax-specific trick.

   Latest source gate: ordinary dictionary string queries already bypass structural
   protocols; fused splitting already batches admission and writes final payloads.
   Instruction spans are shared references, not inline four-int copies; operand
   diagnostic lookup is only on an unbound read. Static abstract resolutions already
   cache by syntax identity within the binding state. No prototype/timing selected
   for these presumed duplicate phases. These findings do not close the performance
   objective. Next gate must identify current work displaced, using R128 compile
   attribution and R140/R143/R150 runtime evidence without relabeling old sources.
   If inclusive prefix attribution remains the blocker, bound a same-process JIT/
   offset attribution to one affected script before choosing a whole-script redesign;
   retain unknowns and require matching code identity rather than cross-run offsets.

   Source/design gate at most20min per actual hypothesis. Static counts and inclusive
   samples are not savings. If no coherent deletion is found, record that and move to
   the independent next family without another capture/unchanged timing campaign.
   A selected milestone names affected CSV/text/JSON/report/file scripts and controls,
   preserves Python order/errors/scopes/protocols, current cancellation, terminal
   refusal, stack safety and explicit owners, then compares compile/allocation/warm
   separately. Use a short diagnostic and bounded quiet confirmation where material.
   Finish by deleting displaced implementation and deciding remaining regression debt.

3. **Remaining text/frontend and per-record gates.** Direct final UTF-8/managed bulk
   ASCII casing, one Unicode mapping pass, fused final-word splitting, flat callable
   facts and commit without root resizing already exist. Ordinary counters skip
   separate magnitude admission. SumState already accumulates machine integers
   with guarded promotion; local imports already compile/execute the common engine
   with explicit export mirroring. Do not repeat those migrations or infer scalar
   CPU dominance from boxing.
   Inspect remaining conversions/repeated analysis only where a current phase is
   demonstrated; preserve Unicode expansion/scalar offsets, aliases and diagnostics.
   No heavyweight JIT/tagged-value or class/import compiler rewrite from inclusive
   counts. Each new gate has the same20min stopping rule and coherent deletion target.

   CSV already stages a record, admits field/row capacity once and adopts storage;
   JSON shares layouts. Historical bulk-CSV6–8% benefits remain promising evidence,
   but the copying premise has been displaced. Reopen for a current duplicate phase
   or measured control issue; no automatic promotion or percentage veto. Slower
   call-arena/control lessons remain explicit. Refresh CPython after another substantial
   coherent checkpoint, not per tweak; R146 is complete and needs no unchanged replay.

## Independent regex deliverable

Core owns Python semantics, native UTF-8 names, byte ranges/scalar positions, original
windows, effective flags, errors/replacements, current tokens, explicit owners and one
frontend/runtime/import provider. Continue independent contract/implementation/semantic
work; missing published producer APIs defer only affected final adapter qualification.
Adapter-local bridges, test providers and pinned development producers are acceptable.
Keep forwarding/unwind, semantic validation and actual backend performance distinct.

Optional nonpackable adapter pin0.4.0; official index checked2026-11-09. Dev55/d6067925
already86 internal/514 public eachactual11/10 pass; no unchanged replay/sibling edits.
Missing released capabilities: DetailedData with distinct preparation/working owners,
native-name enumeration and cursor creation without an earlier caller token. Current
Lython-owned byte-range/capture-buffer contract is independent of those bridges.

## Iteration and lasting constraints

Timeouts, unstable controls and inconclusive observations establish uncertainty, not
failed designs. Allow bounded confirmation/refinement/measurement correction when
evidence justifies it. Retain original adverse/failed conditions. Percentages inform
decisions, not automatic vetoes; distinguish simplification, allocation and CPU benefit.

AGENTS.md is authoritative: fully managed memory safety and managed stack admission;
host mediation/current cancellation; coarse borrowed shared budget/preflights/capacity/
replacement overlap; escaping results/caches/aliases/pending users funded through
awaited cleanup. First refusal terminal. No unsafe/native probing, fuel/quotas/caps/
hidden allowance, tracing/weak reclaim/forced GC or abandoned work. Focused Release
checks during iteration; batch full platform/Stress/installed consumers at delivery.
No overlapping local builds/tests/timing; force nonincremental after source restores.
Release packages only via tools/pack.ps1 into artifacts/nuget; no publication.

VM lokad@20.166.121.73/key ~/.ssh/id_lython-bench.pem. ThroughB506 terminal/cached/local
SHA verified, no users/fixtures; never requery. Finite service/lease, persistent workers/
catalog/raw separate from RAM, joined users/unmount/archive under lease. Space recovery
requires fresh idle exact bytes/all aliases/SHA/owner/group/mode/parents and persisted
pre-mutation plan; preserve every path/byte/floor. CI observations at least5min apart
using recorded UTC clocks; cache terminal once. Through42588611410 terminal/cached.
Through42605184549 terminal cached success; never requery.
R151 recovery removed only two redundant remote compressed archives after fresh
idle/single-alias/hash/owner/parent/pre-mutation proof; Git copies/raw trees survive,
floors unchanged. Initial B506 setup failed before work; same staged payload resumed.
B507 terminal/cached/localSHA verified; no users/fixtures. No elapsed comparison. R151 production21CF1118/commit99844959 fully qualified.
R154/R155 delivery42615908221/source78fd7bb4 cached success, all platform/Stress/package gates; never requery. No publication.
R154 local comparisons terminal; source/image identity verified and original/corrected
evidence archived. R155 handoff integrated/removed. Full delivery42615908221 terminal
success; never requery. R157 local comparison active; no overlapping local build/test or VM user. Delivery CI terminal; never requery.
