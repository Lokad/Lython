from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent
observation=sorted(r.glob('observation-*.json'))[-1]
status=json.loads(observation.read_text(encoding='utf-8'))
assert status['exitCode']=='0'and status['receipt']['complete']and status['receipt']['allWorkersJoined']
assert status['receipt']['archivedAndVerifiedUnderLease']and status['receipt']['elapsedSeconds']<120
assert 'MainPID=0'in status['service']and'ActiveState=inactive'in status['service']
assert not status['remainingWorkers']and not status['remainingFixtures']and not status['remainingTrace']
assert status['receipt']['jobs']==5 # Preserve the known template error; validate actual records below.
(r/'terminal-status.json').write_text(observation.read_text(encoding='utf-8'),encoding='utf-8')
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15']
remote='lokad@20.166.121.73:/home/lokad/lython-bench-checks/bulk-whitespace-b508-20261109/'
for name in ['archive-receipt.json','observations.tgz']:
    done=subprocess.run(scp+[remote+name,str(r/name)],capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']==status['receipt']['archiveSHA256']
out=r/'retrieved';out.mkdir()
with tarfile.open(r/'observations.tgz')as archive:
    members=archive.getmembers();assert all(m.isfile()or m.isdir()for m in members)
    archive.extractall(out,filter='data')
actual=json.loads((out/'confirmation/confirmation.json').read_text(encoding='utf-8'))
assert actual['complete']and len(actual['jobs'])==3
assert [(j['case'],j['lane'])for j in actual['jobs']]==[
    ('scripts.text-summary-helpers.large','warm'),('scripts.text-summary-helpers.large','warm-async'),('scripts.csv-validated-records.large','warm')]
assert all(j['workersJoinedAndFixturesRemoved']and len(j['identities'])==4 and len(j['samples'])==28 for j in actual['jobs'])
archiver=(out/'archive-owned.py').read_text(encoding='utf-8')
assert "len(r['jobs'])==3"in archiver and'receipt=dict(complete=True,jobs=5'in archiver
normalized=dict(originalReceiptPreserved=True,producerDeclaredJobs=receipt['jobs'],actualValidatedJobs=len(actual['jobs']),
    exactScheduleAndFourRolesValidated=True,quietAndSourceGatesPassed=True,noCollectionRestart=True,
    reusedSetupField='allFiveJobsValidated names three source-asserted jobs',
    correction='Producer archiver validates actual len(jobs)==3 then copies stale literal jobs=5 into receipt. Original collector/archiver/receipt/setup/failure preserved; actual archived three-job schedule and28samples/four roles per job independently qualified.',
    archiveSHA256=receipt['archiveSHA256'],terminalObservationCached=observation.name)
(r/'receipt-qualification.json').write_text(json.dumps(normalized,indent=2)+'\n',encoding='utf-8')
print('Terminal state cached without requery; archive SHA verified; actual three-job schedule/four roles/28samples independently validated. Stale receipt retained.',flush=True)
