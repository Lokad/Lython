from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks')
spec=[{'path': '/home/lokad/lython-bench-checks/closed-nested-b497-20261109/observations.tgz', 'sha256': 'e1566047854db1f6ad7085f2ecaa1e2037b71817fee132e81ab2eee2e9ab0d66', 'size': 3816058, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-closed-nested-helpers/observations.tgz', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/lexical-operands-b498-20261109/observations.tgz', 'sha256': '8ead6be5724daabc6212db4b61f40779bb1196d9e9d5f329101f1836a399c025', 'size': 3818405, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-lexical-operands/observations.tgz', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/generator-storage-b500-20261109/observations.tgz', 'sha256': 'b95996262de325066c09a689790e705a5ea9a16b5cbea76e0a6ef5a69260e759', 'size': 3976498, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-generator-storage/observations.tgz', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/callable-consolidation-b502-20261109/observations.tgz', 'sha256': 'ba17154c27cf1261393c01fb5018dd1d1d6c057b46f1eec79e61c1b5b98a5f46', 'size': 3989129, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-callable-consolidation/observations.tgz', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/cpython-checkpoint-b503-20261109/observations.tgz', 'sha256': '5b542be40238fe30744f0b4ba889aeed184680e45a46fbbe5b07024a8dbfc655', 'size': 1984467, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-cpython-callable-checkpoint/observations.tgz', 'tracked': True}]
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (base/'bulk-whitespace-b508-20261109').exists()
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*')) and not Path('/dev/shm/lython-b508').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 free=shutil.disk_usage(base).free
 rows=[]
 for entry in spec:
  p=Path(entry['path']);assert p.resolve(strict=True)==p and p.parent.parent==base and p.name=='observations.tgz'
  info=p.lstat();assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_uid==os.getuid() and info.st_gid==os.getgid()
  assert info.st_size==entry['size'] and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
  receipt=json.loads((p.parent/'archive-receipt.json').read_text());assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archiveSHA256']==entry['sha256']
  parents=[]
  for parent in p.parents:
   meta=parent.lstat();assert stat.S_ISDIR(meta.st_mode) and not parent.is_symlink()
   parents.append(dict(path=str(parent),uid=meta.st_uid,gid=meta.st_gid,mode=oct(meta.st_mode)))
  rows.append(dict(**entry,device=info.st_dev,inode=info.st_ino,links=info.st_nlink,uid=info.st_uid,gid=info.st_gid,mode=oct(info.st_mode),parents=parents,allAliases=[str(p)]))
 assert free+sum(Path(e['path']).stat().st_blocks*512 for e in rows)>277012480, 'Original payload/floor requirement cannot be met; no mutation'
 plan=dict(freshIdleLease=True,beforeFreeBytes=free,osFloorMiB=240,evidenceHeadroomMiB=12,files=rows,operation='Remove only redundant remote compressed archives. Their raw trees, receipts, frozen workers and byte-identical tracked local archives survive.')
 target=base/'bulk-whitespace-b508-space-plan.json'
 with target.open('x') as f:f.write(json.dumps(plan,indent=2)+'\n');f.flush();os.fsync(f.fileno())
 for entry in rows:
  p=Path(entry['path']);info=p.lstat()
  assert info.st_dev==entry['device'] and info.st_ino==entry['inode'] and info.st_nlink==1 and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
  p.unlink()
 plan['afterFreeBytes']=shutil.disk_usage(base).free
 assert plan['afterFreeBytes']>free and plan['afterFreeBytes']>(240+12)*1024*1024
 (base/'bulk-whitespace-b508-space-receipt.json').write_text(json.dumps(plan,indent=2)+'\n')
 print(json.dumps(plan))
