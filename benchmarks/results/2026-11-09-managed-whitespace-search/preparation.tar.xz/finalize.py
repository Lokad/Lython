from pathlib import Path
import hashlib,json,re,shutil,tarfile
r=Path(__file__).parent;v=r/'b508';out=Path('benchmarks/results/2026-11-09-managed-whitespace-search');out.mkdir(exist_ok=True)
source=json.loads((r/'final-source.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in source['productionSources'].items())
receipt=json.loads((v/'archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256((v/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
normal=json.loads((v/'receipt-qualification.json').read_text(encoding='utf-8'))
assert normal['actualValidatedJobs']==3 and normal['exactScheduleAndFourRolesValidated'] and normal['noCollectionRestart']
checks={}
for f in ['net11.0','net10.0']:
    checks[f]={}
    for suite in ['internal','public']:
        text=(r/f'final-focused-{suite}-{f}.log').read_text(encoding='utf-8-sig');match=re.search(r'Passed!.*?Passed:\s*(\d+)',text)
        assert match and 'Failed:     0'in text;checks[f][suite]=int(match[1])
proof=dict(productionSourceMatchesMeasuredFreeze=True,baseline='3fb8025d, production78fd7bb4 fully qualified42615908221',measuredCoreSHA256=source['candidateCoreSHA256'],
    focused=checks,independentPythonBoundaryScripts=6,
    removed='Shared scalar per-byte ASCII category-run loop; no retained old alternative. Forward/reverse managed SearchValues searches use two fixed immutable metadata inventories derived from one existing classifier.',
    preserved='Python29whitespace scalars, Unicode decoding/casing/context, maxsplit/rsplit, original64-byte cancellation windows, terminal refusal, final capacity/overlap funding, aliases and deterministic cleanup. No new pool/cache policy/configuration or runtime dependency.',
    decision='Retain bounded managed bulk implementation without a CPU gain claim. Ordinary/compile allocation unchanged. Quiet elapsed is mostly lower but overlaps process-control spreads; coarse CPU mixed. This milestone does not close broader performance work.',
    limitations='Original desktop async text+5.9to10.1percent remains unexplained/preserved; search controls25.5percent apart. Final metadata-initializer refinement is a different binary from original desktop image15e49. Static metadata startup not timed. Full platform/original Stress/installed consumers of this change deferred to next coherent checkpoint.',
    receipt='Original raw archiver receipt says jobs5 after asserting actual len(jobs)==3. Original setup field also namesFive; exact archived schedule/4roles/28samples per actual3jobs independently verified in receipt-qualification. Initial retrieval failure and assessor template correction retained. No timed work restarted.')
(r/'delivery-source.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
for target,path in [('summary.json',v/'assessment.json'),('local-summary.json',r/'assessment-local.json'),('identity.json',v/'identity.json'),('final-source.json',r/'final-source.json'),('delivery-source.json',r/'delivery-source.json'),('terminal.json',v/'terminal-status.json'),('receipt-qualification.json',v/'receipt-qualification.json'),('space-recovery.json',v/'space-recovery.json'),('observations.tgz',v/'observations.tgz')]:
    assert not(out/target).exists();shutil.copyfile(path,out/target)
with tarfile.open(out/'preparation.tar.xz','w:xz')as archive:
    for p in r.iterdir():
        if p.is_file():archive.add(p,arcname=p.name)
    for phase in ['warm-sync','warm-async','compile-sync']:archive.add(r/phase,arcname=phase)
    for p in v.iterdir():
        if p.is_file()and p.name not in ['payload.tgz','observations.tgz','baseline-core.dll','current-core.dll','common-worker.dll','common-adapter.dll']:archive.add(p,arcname='b508/'+p.name)
    archive.add(r/'tool/Program.cs',arcname='tool/Program.cs');archive.add(r/'tool/complete-jobs.csproj',arcname='tool/complete-jobs.csproj')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8-sig');a=s.index('1. **R157');b=s.index('2. **R156',a)
s=s[:a]+'''1. **R157 implemented; retain with focused qualification and explicit CPU debt.**
   Replace the shared scalar ASCII category-run loop with managed bulk search;
   both immutable inventories derive from one classifier. No new pool, ownership
   layer, policy, public option or dependency. Unicode/final-fragment funding and
   existing cancellation windows unchanged. Focused178internal/219public per
   actual11/10 plus six independent CPython boundary scripts pass.
   Original desktop image15e49 allocation unchanged, async text+5.9to10.1%; search
   control spread25.5%. Final sourcecfeb99b0 derives both inventories consistently;
   one quiet B508/86.826s, three jobs/four independent roles, all source/golden/
   owner/quiet/join/archive gates pass. Textsync−5.0to+0.86%, async−3.89to+0.95%
   elapsed, overlapping control spreads3.96/2.58%; coarseCPU−2.13to+2.48% mixed.
   Retain managed bulk implementation; no CPU improvement or neutrality claim.
   Both images/raw adverse results and original staleFive receipt/setup labels
   survive; actual archived3jobs/4roles/28samples independently qualified. No rerun.
   Full platform/Stress/installed consumers deferred to coherent delivery checkpoint;
   original startup/static-metadata costs unknown, broader performance stays open.
   Evidence: benchmarks/results/2026-11-09-managed-whitespace-search.

   **R158 next: assess frontend traversal/state consolidation before coding.**
   R128's older compile attribution assigns19–29% to analysis, not all overhead.
   Compare current static abstract/name-binding/annotation visitors and flow states.
   Hypothesis: remove a duplicate walk/state construction in complete fresh helper/
   config/CSV scripts. Distinct directive/lazy-annotation/class-cell and maybe-bound
   rules must survive, with diagnostic order/spans and current cancellation/admission.
   Name concrete displaced methods before a prototype; do not merge distinct
   analyses merely because they traverse syntax. Source gate20min, then select one
   coherent deletion or record the missing fact and move boundary. Use existing
   source/profile evidence and focused diagnostics; no broad new compiler/measurement
   framework, persistent semantic caches or automatic percentage veto.

''' +s[b:]
s=s.replace('R157 local comparison terminal, final source frozen; quiet confirmation launched under finite150slease; terminal observation after13:05:47UTC, no local build/test/timing.', 'R157/B508 terminal success86.826s; original receipt count corrected by direct archived-record qualification, no requery/restart. Archive SHA locally verified. No VM user/fixture or local build/test/timing remains.')
p.write_text(s,encoding='utf-8')
print(json.dumps(proof,indent=2))
