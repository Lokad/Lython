from pathlib import Path
import json
r=Path(__file__).parent;v=r/'b508'
s=(r.parent/'borrowed-call-entry-r151/recover-space.py').read_text(encoding='utf-8')
s=s.replace("[('callback-transport-b504-20261109','2026-11-09-callback-arguments'),('json-runtime-b505-20261109','2026-11-09-json-runtime-attribution')]", "[('closed-nested-b497-20261109','2026-11-09-closed-nested-helpers'),('lexical-operands-b498-20261109','2026-11-09-lexical-operands'),('generator-storage-b500-20261109','2026-11-09-generator-storage'),('callable-consolidation-b502-20261109','2026-11-09-callable-consolidation'),('cpython-checkpoint-b503-20261109','2026-11-09-cpython-callable-checkpoint')]")
s=s.replace('borrowed-call-entry-b506','bulk-whitespace-b508').replace('/dev/shm/lython-b505','/dev/shm/lython-b508')
required=json.loads((v/'payload-sizing.json').read_text(encoding='utf-8'))['requiredFreeBytes']
s=s.replace(' plan=dict(', f" assert free+sum(Path(e['path']).stat().st_blocks*512 for e in rows)>{required}, 'Original payload/floor requirement cannot be met; no mutation'\n plan=dict(")
s=s.replace('Two redundant remote archives', 'Five exact redundant remote archives')
compile(s,'recover-space.py','exec');(v/'recover-space.py').write_text(s,encoding='utf-8')
p=Path('PLAN.md');t=p.read_text(encoding='utf-8-sig')
t=t.replace('   claim; no VM/CI run or full qualification for this prototype yet.', '''   claim. Original local image15e49: textsync−1.3to+3.6%, async+5.9to10.1%;
   unchanged search controls25.5% apart, allocation unchanged. Preserve adversity.
   Final source derives both tables from one existing classifier; fresh freeze and
   focused178internal/219public per actual11/10 pass. One bounded quiet confirmation
   prepared: text sync/async plus unaffectedCSV, four independent roles,5s warmup,
   seven150ms rounds,150sowner+30stop+30margin. Payload requires277012480B under
   original240+12MiB floors. Recover only five exact redundant compressed archives
   with tracked byte-identical local copies/raw/receipts/workers preserved and fresh
   idle/single-alias/SHA/metadata/parents/persisted-plan proof. No collection yet.''')
t=t.replace('R157 local comparison active; no overlapping local build/test or VM user.', 'R157 local comparison terminal, final source frozen; quiet confirmation prepared, no build/test or VM user.')
p.write_text(t,encoding='utf-8')
