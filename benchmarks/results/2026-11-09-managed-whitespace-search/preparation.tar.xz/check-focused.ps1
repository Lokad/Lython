$ErrorActionPreference = 'Stop'
$env:DOTNET_ROOT = 'C:/Users/JoannesVermorel/.dotnet11'
$env:DOTNET_HOST_PATH = "$env:DOTNET_ROOT/dotnet.exe"
$env:PATH = "$env:DOTNET_ROOT;C:/Python313;$env:PATH"
foreach ($framework in @('net11.0', 'net10.0')) {
    foreach ($suite in @('internal', 'public')) {
        $project = if ($suite -eq 'internal') { 'tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj' } else { 'tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj' }
        $log = Join-Path $PSScriptRoot "focused-$suite-$framework.log"
        & $env:DOTNET_HOST_PATH test $project -c Release -f $framework --no-restore --filter 'Category!=Stress&(FullyQualifiedName~Whitespace|FullyQualifiedName~Split|FullyQualifiedName~Casing)' *> $log
        if ($LASTEXITCODE -ne 0) { Get-Content $log -Tail 45; exit $LASTEXITCODE }
        Get-Content $log -Tail 2
    }
}
