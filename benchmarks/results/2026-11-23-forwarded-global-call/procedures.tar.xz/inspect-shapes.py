from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).resolve().parent
prior=lab.parent/'closed-definition-return-20261123/inspect/build/bin/Inspect/release_net11.0'
rootd=Path.home()/'.dotnet11'; pair={}
proof=json.loads((lab/'comparison/identity.json').read_text(encoding='utf-8'))
for role,files in proof['imageFiles'].items():
    image=lab/role
    for n in ('Inspect.dll','Inspect.deps.json','Inspect.runtimeconfig.json'): shutil.copyfile(prior/n,image/n)
    output=lab/(role+'-tape.json')
    subprocess.run([rootd/'dotnet.exe',image/'Inspect.dll',lab/'representative.json',output],check=True,timeout=20,env=dict(os.environ,DOTNET_ROOT=str(rootd)))
    pair[role]=json.loads(output.read_text(encoding='utf-8'))
    assert pair[role]['coreSHA256']==files['Lokad.Lython.dll'] and all(hashlib.sha256((image/n).read_bytes()).hexdigest()==digest for n,digest in files.items())
selection=[]
for r,c in zip(pair['reference']['rows'],pair['candidate']['rows'],strict=True):
    for a,b in zip(r['codes'],c['codes'],strict=True):
        assert a['name']==b['name'] and a['capacity']==b['capacity']
        forwarded=[site for site in b['calls'] if site['first']<0]
        assert a['instructions']-b['instructions']==len(forwarded)*2
        if forwarded: selection.append(dict(id=c['id'],function=b['name'],instructions=[a['instructions'],b['instructions']],capacity=b['capacity'],forwarded=forwarded))
assert len(selection) >= 3
(lab/'tape-summary.json').write_text(json.dumps(selection,indent=2)+'\n',encoding='utf-8',newline='\n')
print([(v['id'],v['function'],v['instructions']) for v in selection])
