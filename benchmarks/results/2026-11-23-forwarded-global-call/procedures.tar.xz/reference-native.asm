; Assembly listing for method Lokad.Lython.Frontend.ExecutableInstruction:Call(int,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Frontend.ExecutableInstruction (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      qword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      gword ptr [rbp+0x20], r8
 
G_M000_IG02:                ;; offset=0x001E
       mov      dword ptr [rsp+0x20], 0x7FFFFFFF
       mov      dword ptr [rsp+0x28], 0x7FFFFFFF
       mov      dword ptr [rsp+0x30], -1
       xor      eax, eax
       mov      dword ptr [rsp+0x38], eax
       lea      rcx, [rbp-0x20]
       mov      r9d, dword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      edx, 42
       call     [Lokad.Lython.Frontend.ExecutableInstruction:.ctor(int,Lokad.Lython.LythonSourceSpan,int,int,int,int,int):this]
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG03:                ;; offset=0x0057
       vmovdqu  ymm0, ymmword ptr [rbp-0x20]
       vmovdqu  ymmword ptr [rax], ymm0
 
G_M000_IG04:                ;; offset=0x0060
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG05:                ;; offset=0x0064
       vzeroupper 
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 109

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0xB90
       lea      rbp, [rsp+0xB90]
       xor      eax, eax
       mov      qword ptr [rbp-0xB48], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0xB40], xmm4
       vmovdqa  xmmword ptr [rbp-0xB30], xmm4
       mov      rax, -0xAE0
 
G_M000_IG246:                ;; offset=0x0037
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG246
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
 
G_M000_IG02:                ;; offset=0x0063
       mov      dword ptr [rbp-0x62C], 0x3E8
       mov      rax, bword ptr [rbp+0x30]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      rax, bword ptr [rbp+0x38]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      gword ptr [rbp-0x40], rax
       jmp      G_M000_IG227
 
G_M000_IG03:                ;; offset=0x00AC
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG233
       mov      edx, eax
       imul     rdx, rdx, 32
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x58], rcx
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x190], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x638], rax
       mov      rdx, gword ptr [rbp-0x638]
       mov      rcx, gword ptr [rbp-0x190]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG04:                ;; offset=0x010F
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0xE4], eax
       cmp      dword ptr [rbp-0xE4], 72
       ja       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0128
       mov      eax, dword ptr [rbp-0xE4]
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG06:                ;; offset=0x0144
       jmp      G_M000_IG213
 
G_M000_IG07:                ;; offset=0x0149
       mov      rcx, 0x7FF9D77FA948
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG231
 
G_M000_IG08:                ;; offset=0x0167
       mov      rcx, 0x7FF9D77FA94C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5B8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x5C0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x5C4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x640], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x640]
       mov      rdx, gword ptr [rbp-0x5C0]
       mov      r8d, dword ptr [rbp-0x5C4]
       mov      rcx, gword ptr [rbp-0x5B8]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadLocal(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x648], rax
       mov      r9, gword ptr [rbp-0x648]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG217
 
G_M000_IG09:                ;; offset=0x0204
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, gword ptr [rbp-0x1C8]
       mov      gword ptr [rbp-0xB48], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      rdx, gword ptr [rbp-0xB48]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG216
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_IsUnassigned():bool:this]
       test     eax, eax
       je       G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0254
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_LocalNames():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rax, gword ptr [rbp-0x1E8]
       mov      gword ptr [rbp-0x610], rax
       mov      rcx, gword ptr [rbp-0x610]
       mov      rdx, 0x7FF9D77FA950
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x610]
       mov      gword ptr [rbp-0x650], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x654], eax
       mov      rcx, gword ptr [rbp-0x650]
       mov      edx, dword ptr [rbp-0x654]
       mov      r11, 0x7FF9D70A1A40
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x1F0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x660], rax
       mov      rdx, gword ptr [rbp-0x660]
       mov      rcx, gword ptr [rbp-0x1F0]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG11:                ;; offset=0x02FB
       mov      rcx, 0x7FF9D77FAA58
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG12:                ;; offset=0x030F
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       jne      G_M000_IG14
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x598], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x5A0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      dword ptr [rbp-0x5A4], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x664], eax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9d, dword ptr [rbp-0x664]
       mov      rdx, gword ptr [rbp-0x5A0]
       mov      r8d, dword ptr [rbp-0x5A4]
       mov      rcx, gword ptr [rbp-0x598]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG13
       mov      rcx, 0x7FF9D77FAA5C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x5B0], rax
       mov      rax, bword ptr [rbp-0x5B0]
       add      dword ptr [rax], 2
       jmp      G_M000_IG217
 
G_M000_IG13:                ;; offset=0x03D1
       mov      rcx, 0x7FF9D77FAA60
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x03E0
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x590], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x670], rax
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x670]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8d, dword ptr [rbp-0x590]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG15
       mov      rcx, 0x7FF9D77FAA64
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG15:                ;; offset=0x0448
       mov      rcx, 0x7FF9D77FAA68
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      r9, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG217
 
G_M000_IG16:                ;; offset=0x0472
       mov      rcx, 0x7FF9D77FAA6C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG217
 
G_M000_IG17:                ;; offset=0x049C
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG18
       mov      rcx, 0x7FF9D77FAA70
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG18:                ;; offset=0x04D0
       mov      rcx, 0x7FF9D77FAA74
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG19:                ;; offset=0x04E4
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG20
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG20:                ;; offset=0x04FA
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG23
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG21:                ;; offset=0x0506
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x690], ymm0
 
G_M000_IG22:                ;; offset=0x0512
       lea      r8, [rbp-0x690]
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG217
 
G_M000_IG23:                ;; offset=0x0555
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG24:                ;; offset=0x0559
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x6B0], ymm0
 
G_M000_IG25:                ;; offset=0x0565
       lea      r8, [rbp-0x6B0]
       lea      rdx, [rbp-0x550]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG26:                ;; offset=0x0585
       vmovdqu  xmm0, xmmword ptr [rbp-0x550]
       vmovdqu  xmmword ptr [rbp-0x6C0], xmm0
 
G_M000_IG27:                ;; offset=0x0595
       lea      rdx, [rbp-0x6C0]
       lea      rcx, [rbp-0x560]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xAC0], rax
       mov      rcx, bword ptr [rbp-0xAC0]
       mov      rdx, gword ptr [rbp-0x560]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xAC0]
       mov      rcx, qword ptr [rbp-0x558]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG28
       mov      rcx, 0x7FF9D77FAA78
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x6C8], rax
       mov      rcx, gword ptr [rbp-0x6C8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG28:                ;; offset=0x0623
       mov      rcx, 0x7FF9D77FAA7C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG217
 
G_M000_IG29:                ;; offset=0x0641
       mov      rax, bword ptr [rbp+0x10]
       mov      bword ptr [rbp-0x2B8], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x2C0], rax
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x2C8], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x2D0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG30
       mov      rcx, 0x7FF9D77FAA80
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x2D0], rax
 
G_M000_IG30:                ;; offset=0x068E
       mov      rcx, bword ptr [rbp-0x2B8]
       mov      rdx, gword ptr [rbp-0x2C0]
       mov      r8, bword ptr [rbp-0x2C8]
       mov      r9, gword ptr [rbp-0x2D0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      SHORT G_M000_IG31
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG32
       mov      rcx, 0x7FF9D77FAA84
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG31:                ;; offset=0x06D9
       mov      rcx, 0x7FF9D77FAA88
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG32:                ;; offset=0x06ED
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG35
       mov      rcx, 0x7FF9D77FAA8C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG33:                ;; offset=0x0708
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x6E8], ymm0
 
G_M000_IG34:                ;; offset=0x0714
       lea      r8, [rbp-0x6E8]
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG217
 
G_M000_IG35:                ;; offset=0x0757
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG36:                ;; offset=0x075B
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x708], ymm0
 
G_M000_IG37:                ;; offset=0x0767
       lea      r8, [rbp-0x708]
       lea      rdx, [rbp-0x2E0]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG38:                ;; offset=0x0787
       vmovdqu  xmm0, xmmword ptr [rbp-0x2E0]
       vmovdqu  xmmword ptr [rbp-0x718], xmm0
 
G_M000_IG39:                ;; offset=0x0797
       lea      rdx, [rbp-0x718]
       lea      rcx, [rbp-0x2F0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xAC8], rax
       mov      rcx, bword ptr [rbp-0xAC8]
       mov      rdx, gword ptr [rbp-0x2F0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xAC8]
       mov      rcx, qword ptr [rbp-0x2E8]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG40
       mov      rcx, 0x7FF9D77FAA90
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x720], rax
       mov      rcx, gword ptr [rbp-0x720]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG40:                ;; offset=0x0825
       mov      rcx, 0x7FF9D77FAA94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG217
 
G_M000_IG41:                ;; offset=0x0843
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x238], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x238]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG216
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x728], rax
       mov      rdx, gword ptr [rbp-0x728]
       mov      rcx, 0x7FF9D759EAB0
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x240], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x248], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x24C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x250], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      ecx, dword ptr [rbp-0x250]
       sub      ecx, eax
       mov      dword ptr [rbp-0x72C], ecx
       mov      r9d, dword ptr [rbp-0x72C]
       lea      rcx, [rbp-0x260]
       mov      rdx, gword ptr [rbp-0x248]
       mov      r8d, dword ptr [rbp-0x24C]
       call     [System.MemoryExtensions:AsSpan[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, gword ptr [rbp-0x240]
       mov      gword ptr [rbp-0x268], rax
 
G_M000_IG42:                ;; offset=0x0925
       vmovdqu  xmm0, xmmword ptr [rbp-0x260]
       vmovdqu  xmmword ptr [rbp-0x278], xmm0
 
G_M000_IG43:                ;; offset=0x0935
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_StartsKeywordDefaultsOnly():bool:this]
       mov      dword ptr [rbp-0x27C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x288], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG44
       mov      rcx, 0x7FF9D77FAA98
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x288], rax
 
G_M000_IG44:                ;; offset=0x0971
       mov      rcx, 0x7FF9D77FAA9C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG45:                ;; offset=0x0980
       vmovdqu  xmm0, xmmword ptr [rbp-0x278]
       vmovdqu  xmmword ptr [rbp-0x740], xmm0
 
G_M000_IG46:                ;; offset=0x0990
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x748], rax
       mov      rax, gword ptr [rbp-0x748]
       mov      gword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0x740]
       mov      r8d, dword ptr [rbp-0x27C]
       mov      r9, gword ptr [rbp-0x288]
       mov      rcx, gword ptr [rbp-0x268]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x290], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x74C], eax
       mov      edx, dword ptr [rbp-0x74C]
       mov      rcx, bword ptr [rbp-0x290]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RestoreNativeExtent(int):this]
       jmp      G_M000_IG217
 
G_M000_IG47:                ;; offset=0x0A0C
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x1F8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x1FC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x750], eax
       mov      r9d, dword ptr [rbp-0x750]
       lea      rdx, [rbp-0x70]
       mov      r8d, dword ptr [rbp-0x1FC]
       mov      rcx, bword ptr [rbp-0x1F8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x758], rax
       mov      rdx, gword ptr [rbp-0x758]
       lea      rcx, [rbp-0x210]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x218], rax
 
G_M000_IG48:                ;; offset=0x0A9A
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0x228], xmm0
 
G_M000_IG49:                ;; offset=0x0AA7
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x230], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG50
       mov      rcx, 0x7FF9D77FAAA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x230], rax
 
G_M000_IG50:                ;; offset=0x0AD3
       mov      rcx, 0x7FF9D77FAAA4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:                ;; offset=0x0AE2
       vmovdqu  xmm0, xmmword ptr [rbp-0x210]
       vmovdqu  xmmword ptr [rbp-0x768], xmm0
 
G_M000_IG52:                ;; offset=0x0AF2
       vmovdqu  xmm0, xmmword ptr [rbp-0x228]
       vmovdqu  xmmword ptr [rbp-0x778], xmm0
 
G_M000_IG53:                ;; offset=0x0B02
       mov      rcx, gword ptr [rbp-0x230]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x780], rax
       mov      r9, gword ptr [rbp-0x780]
       lea      r8, [rbp-0x778]
       lea      rcx, [rbp-0x768]
       mov      rdx, bword ptr [rbp-0x218]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG217
 
G_M000_IG54:                ;; offset=0x0B3F
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       lea      rax, [rbp-0x80]
       mov      qword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG55
       mov      rcx, 0x7FF9D77FAAA8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG55:                ;; offset=0x0B88
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG56
       mov      rcx, 0x7FF9D77FAAAC
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0x80]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG217
 
G_M000_IG56:                ;; offset=0x0BC2
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x790], xmm0
 
G_M000_IG57:                ;; offset=0x0BCF
       lea      rdx, [rbp-0x790]
       lea      rcx, [rbp-0x570]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xAD0], rax
       mov      rcx, bword ptr [rbp-0xAD0]
       mov      rdx, gword ptr [rbp-0x570]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xAD0]
       mov      rcx, qword ptr [rbp-0x568]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG58
       mov      rcx, 0x7FF9D77FAAB0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x798], rax
       mov      rcx, gword ptr [rbp-0x798]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG58:                ;; offset=0x0C5D
       mov      rcx, 0x7FF9D77FAAB4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG217
 
G_M000_IG59:                ;; offset=0x0C7B
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG60
       mov      rcx, 0x7FF9D77FAAB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG60:                ;; offset=0x0CA0
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x340], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x344], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x79C], eax
       mov      r9d, dword ptr [rbp-0x79C]
       lea      rdx, [rbp-0x118]
       mov      r8d, dword ptr [rbp-0x344]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       inc      eax
       mov      dword ptr [rbp-0x11C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x70]
       mov      gword ptr [rbp-0x128], rax
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorsExecutableLocals():bool:this]
       test     eax, eax
       jne      G_M000_IG63
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG62
       mov      rax, gword ptr [rbp-0x40]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x11C]
       jle      SHORT G_M000_IG61
       mov      rcx, 0x7FF9D77FAABC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG216
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 30
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x348], eax
       jmp      SHORT G_M000_IG64
 
G_M000_IG61:                ;; offset=0x0D8F
       mov      rcx, 0x7FF9D77FAAC0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG62:                ;; offset=0x0DA0
       mov      rcx, 0x7FF9D77FAAC4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG63:                ;; offset=0x0DAF
       xor      eax, eax
       mov      dword ptr [rbp-0x348], eax
 
G_M000_IG64:                ;; offset=0x0DB7
       movzx    rax, byte  ptr [rbp-0x348]
       mov      dword ptr [rbp-0x12C], eax
       cmp      dword ptr [rbp-0x12C], 0
       je       G_M000_IG71
       cmp      gword ptr [rbp-0x128], 0
       je       G_M000_IG68
 
G_M000_IG65:                ;; offset=0x0DDF
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x7B0], xmm0
 
G_M000_IG66:                ;; offset=0x0DEF
       lea      r8, [rbp-0x7B0]
       mov      rdx, gword ptr [rbp-0x128]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       je       G_M000_IG67
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG216
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x7B8], rax
       mov      rdx, gword ptr [rbp-0x7B8]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x358], rax
       mov      rax, gword ptr [rbp-0x358]
       mov      gword ptr [rbp-0x360], rax
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasActiveHandler():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG69
       mov      rax, gword ptr [rbp-0x360]
       mov      gword ptr [rbp-0x368], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x80]
       mov      gword ptr [rbp-0x370], rax
       jmp      SHORT G_M000_IG70
 
G_M000_IG67:                ;; offset=0x0EA5
       mov      rcx, 0x7FF9D77FAAC8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG71
 
G_M000_IG68:                ;; offset=0x0EB9
       mov      rcx, 0x7FF9D77FAACC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG71
 
G_M000_IG69:                ;; offset=0x0ECD
       mov      rcx, 0x7FF9D77FAAD0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x360]
       mov      gword ptr [rbp-0x368], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CurrentException():Lokad.Lython.Runtime.PyException:this]
       mov      gword ptr [rbp-0x370], rax
 
G_M000_IG70:                ;; offset=0x0F08
       mov      rcx, 0x7FF9D77FAAD4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x368]
       mov      rdx, gword ptr [rbp-0x370]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:SetCurrentException(Lokad.Lython.Runtime.PyException):Lokad.Lython.Runtime.PyException:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x378], rax
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG216
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x7BC], eax
       mov      edx, dword ptr [rbp-0x7BC]
       mov      rcx, bword ptr [rbp-0x378]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x380], rax
       mov      rax, bword ptr [rbp-0x380]
       add      dword ptr [rax], 2
       jmp      G_M000_IG227
 
G_M000_IG71:                ;; offset=0x0FA6
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x7D0], xmm0
 
G_M000_IG72:                ;; offset=0x0FB6
       lea      rdx, [rbp-0x7D0]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:set_YieldValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rcx, gword ptr [rbp+0x20]
       mov      edx, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:set_HasYield(bool):this]
       mov      rax, gword ptr [rbp+0x20]
       mov      byte  ptr [rax+0xF8], 1
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x350], rax
       mov      rax, bword ptr [rbp-0x350]
       inc      dword ptr [rax]
       cmp      dword ptr [rbp-0x12C], 0
       jne      SHORT G_M000_IG75
       cmp      gword ptr [rbp-0x128], 0
       je       SHORT G_M000_IG74
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0x128]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG73
       mov      rcx, 0x7FF9D77FAAD8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG227
 
G_M000_IG73:                ;; offset=0x1041
       mov      rcx, 0x7FF9D77FAADC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG75
 
G_M000_IG74:                ;; offset=0x1052
       mov      rcx, 0x7FF9D77FAAE0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG75:                ;; offset=0x1061
       mov      rcx, 0x7FF9D77FAAE4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG231
 
G_M000_IG76:                ;; offset=0x107F
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG77
       mov      rcx, 0x7FF9D77FAAE8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG77:                ;; offset=0x10A4
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG81
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG78:                ;; offset=0x10B4
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x7F0], ymm0
 
G_M000_IG79:                ;; offset=0x10C0
       lea      r8, [rbp-0x7F0]
       lea      rdx, [rbp-0x338]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xAD8], rax
       mov      rcx, bword ptr [rbp-0xAD8]
       mov      rdx, gword ptr [rbp-0x338]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xAD8]
       mov      rcx, qword ptr [rbp-0x330]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG80
       mov      rcx, 0x7FF9D77FAAEC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x7F8], rax
       mov      rcx, gword ptr [rbp-0x7F8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG80:                ;; offset=0x1154
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG87
 
G_M000_IG81:                ;; offset=0x1163
       mov      rax, gword ptr [rbp+0x20]
       cmp      gword ptr [rax+0x68], 0
       jne      G_M000_IG82
       mov      rcx, 0x7FF9D77FAAF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x308], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x30C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x7FC], eax
       mov      r8d, dword ptr [rbp-0x7FC]
       mov      edx, dword ptr [rbp-0x30C]
       mov      rcx, bword ptr [rbp-0x308]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rcx, 0x7FF9D71628A8
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      gword ptr [rbp-0x318], rax
       mov      rcx, gword ptr [rbp-0x318]
       mov      r8, gword ptr [rbp-0x138]
       xor      edx, edx
       call     [CORINFO_HELP_ARRADDR_ST]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x808], rax
       mov      rdx, gword ptr [rbp-0x808]
       mov      rcx, gword ptr [rbp-0x318]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x320], rax
       mov      rcx, 0x7FF9D77F7DB8
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x328], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x810], rax
       mov      r9, gword ptr [rbp-0x810]
       mov      rdx, gword ptr [rbp-0x320]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x328]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:.ctor(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x20]
       lea      rcx, bword ptr [rax+0x68]
       mov      rdx, gword ptr [rbp-0x328]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG82:                ;; offset=0x1292
       mov      rcx, 0x7FF9D77FAAF4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rax+0x60]
       mov      rax, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rax+0x68]
       lea      rdx, [rbp-0x300]
       mov      rax, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rax+0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:Advance(System.Object,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.PyIterationResult:this]
 
G_M000_IG83:                ;; offset=0x12C8
       vmovdqu  xmm0, xmmword ptr [rbp-0x300]
       vmovdqu  xmmword ptr [rbp-0x820], xmm0
 
G_M000_IG84:                ;; offset=0x12D8
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG85:                ;; offset=0x12DC
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x840], ymm0
 
G_M000_IG86:                ;; offset=0x12E8
       lea      rdx, [rbp-0x820]
       lea      r8, [rbp-0x840]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
 
G_M000_IG87:                ;; offset=0x1302
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasYield():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG89
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x70]
       mov      gword ptr [rbp-0x140], rax
       cmp      gword ptr [rbp-0x140], 0
       je       SHORT G_M000_IG90
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0x140]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG88
       mov      rcx, 0x7FF9D77FAAF8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG227
 
G_M000_IG88:                ;; offset=0x1356
       mov      rcx, 0x7FF9D77FAAFC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x1367
       mov      rcx, 0x7FF9D77FAB00
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG90:                ;; offset=0x137B
       mov      rcx, 0x7FF9D77FAB04
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG231
 
G_M000_IG91:                ;; offset=0x1399
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG92
       mov      rcx, 0x7FF9D77FAB08
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG92:                ;; offset=0x13BE
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Imports():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ImportStatementSyntax]:this]
       mov      gword ptr [rbp-0x5D8], rax
       mov      rax, gword ptr [rbp-0x5D8]
       mov      gword ptr [rbp-0x618], rax
       mov      rcx, gword ptr [rbp-0x618]
       mov      rdx, 0x7FF9D77FAB10
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x618]
       mov      gword ptr [rbp-0x848], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ImportIndex():int:this]
       mov      dword ptr [rbp-0x84C], eax
       mov      rcx, gword ptr [rbp-0x848]
       mov      edx, dword ptr [rbp-0x84C]
       mov      r11, 0x7FF9D70A1A50
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x88], rax
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG93
       mov      rcx, 0x7FF9D77FAC18
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r9, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG217
 
G_M000_IG93:                ;; offset=0x1473
       lea      rcx, [rbp-0x5E8]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
 
G_M000_IG94:                ;; offset=0x148B
       vmovdqu  xmm0, xmmword ptr [rbp-0x5E8]
       vmovdqu  xmmword ptr [rbp-0x860], xmm0
 
G_M000_IG95:                ;; offset=0x149B
       lea      rdx, [rbp-0x860]
       lea      rcx, [rbp-0x5F8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xAE0], rax
       mov      rcx, bword ptr [rbp-0xAE0]
       mov      rdx, gword ptr [rbp-0x5F8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xAE0]
       mov      rcx, qword ptr [rbp-0x5F0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG96
       mov      rcx, 0x7FF9D77FAC1C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x868], rax
       mov      rcx, gword ptr [rbp-0x868]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG96:                ;; offset=0x1529
       mov      rcx, 0x7FF9D77FAC20
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG217
 
G_M000_IG97:                ;; offset=0x1547
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG98
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG99
       mov      rcx, 0x7FF9D77FAC24
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG98:                ;; offset=0x1586
       mov      rcx, 0x7FF9D77FAC28
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG99:                ;; offset=0x159A
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG100
       mov      rcx, 0x7FF9D77FAC2C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG217
 
G_M000_IG100:                ;; offset=0x15CC
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG101:                ;; offset=0x15D0
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x888], ymm0
 
G_M000_IG102:                ;; offset=0x15DC
       lea      r8, [rbp-0x888]
       lea      rdx, [rbp-0x540]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xAE8], rax
       mov      rcx, bword ptr [rbp-0xAE8]
       mov      rdx, gword ptr [rbp-0x540]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xAE8]
       mov      rcx, qword ptr [rbp-0x538]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG103
       mov      rcx, 0x7FF9D77FAC30
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x890], rax
       mov      rcx, gword ptr [rbp-0x890]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG103:                ;; offset=0x1670
       mov      rcx, 0x7FF9D77FAC34
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG217
 
G_M000_IG104:                ;; offset=0x168E
       mov      rcx, 0x7FF9D77FAC38
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x5D0], rax
       mov      rax, gword ptr [rbp-0x5D0]
       mov      gword ptr [rbp-0xB48], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rdx, gword ptr [rbp-0xB48]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG216
       mov      ecx, eax
       lea      rcx, bword ptr [rdx+8*rcx+0x10]
       mov      rcx, gword ptr [rcx]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x898], rax
       mov      r9, gword ptr [rbp-0x898]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG217
 
G_M000_IG105:                ;; offset=0x1710
       mov      rcx, 0x7FF9D77FAC3C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x588], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x58C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8A0], rax
       mov      r8, gword ptr [rbp-0x8A0]
       mov      edx, dword ptr [rbp-0x58C]
       mov      rcx, gword ptr [rbp-0x588]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x8A8], rax
       mov      r9, gword ptr [rbp-0x8A8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG217
 
G_M000_IG106:                ;; offset=0x1791
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG107
       mov      rcx, 0x7FF9D77FAC40
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG107:                ;; offset=0x17B6
       mov      rcx, 0x7FF9D77FAC44
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x578], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x578]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG216
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x580], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8B0], rax
       mov      rdx, gword ptr [rbp-0x8B0]
       mov      rcx, gword ptr [rbp-0x580]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x8B8], rax
       mov      r9, gword ptr [rbp-0x8B8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG217
 
G_M000_IG108:                ;; offset=0x1854
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG109
       mov      rcx, 0x7FF9D77FAC48
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG109:                ;; offset=0x1879
       mov      rcx, 0x7FF9D77FAC4C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8C0], rax
       mov      rdx, gword ptr [rbp-0x8C0]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG217
 
G_M000_IG110:                ;; offset=0x18AF
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG111
       mov      rcx, 0x7FF9D77FAC50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG111:                ;; offset=0x18D4
       mov      rcx, 0x7FF9D77FAC54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x510], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x510]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG216
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x518], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x520], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x524], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x8C4], eax
       mov      r8d, dword ptr [rbp-0x8C4]
       mov      edx, dword ptr [rbp-0x524]
       mov      rcx, bword ptr [rbp-0x520]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x530], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8D0], rax
       mov      r9, gword ptr [rbp-0x8D0]
       mov      rdx, gword ptr [rbp-0x530]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x518]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG217
 
G_M000_IG112:                ;; offset=0x19AF
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG113
       mov      rcx, 0x7FF9D77FAC58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG113:                ;; offset=0x19D4
       mov      rcx, 0x7FF9D77FAC5C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x4D8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x4E0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x4E8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x4E8]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG216
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x4F0], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4F8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4FC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x8D4], eax
       mov      r8d, dword ptr [rbp-0x8D4]
       mov      edx, dword ptr [rbp-0x4FC]
       mov      rcx, bword ptr [rbp-0x4F8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x508], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8E0], rax
       mov      rax, gword ptr [rbp-0x8E0]
       mov      gword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp-0x4E0]
       mov      r8, gword ptr [rbp-0x4F0]
       mov      r9, gword ptr [rbp-0x508]
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x4D8]
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG217
 
G_M000_IG114:                ;; offset=0x1AE4
       mov      rcx, 0x7FF9D77FAC60
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4C0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x4C4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x4C8], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4D0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x8E4], eax
       mov      edx, dword ptr [rbp-0x8E4]
       mov      rcx, bword ptr [rbp-0x4D0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x8F0], rax
       mov      r9, gword ptr [rbp-0x8F0]
       mov      edx, dword ptr [rbp-0x4C4]
       mov      r8d, dword ptr [rbp-0x4C8]
       mov      rcx, bword ptr [rbp-0x4C0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishValue(int,int,System.Object):this]
       jmp      G_M000_IG217
 
G_M000_IG115:                ;; offset=0x1B8F
       mov      rcx, 0x7FF9D77FAC64
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4B0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x8F4], eax
       mov      edx, dword ptr [rbp-0x8F4]
       mov      rcx, bword ptr [rbp-0x4B0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4B8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x8F8], eax
       mov      edx, dword ptr [rbp-0x8F8]
       mov      rcx, bword ptr [rbp-0x4B8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG217
 
G_M000_IG116:                ;; offset=0x1C13
       mov      rcx, 0x7FF9D77FAC68
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4A0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4A4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x4A8], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x900], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x900]
       mov      edx, dword ptr [rbp-0x4A4]
       mov      r8d, dword ptr [rbp-0x4A8]
       mov      rcx, bword ptr [rbp-0x4A0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x908], rax
       mov      r9, gword ptr [rbp-0x908]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG217
 
G_M000_IG117:                ;; offset=0x1CB7
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG119
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG118
       mov      rcx, 0x7FF9D77FAC6C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG231
 
G_M000_IG118:                ;; offset=0x1CF0
       mov      rcx, 0x7FF9D77FAC70
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG119:                ;; offset=0x1CFF
       mov      rcx, bword ptr [rbp+0x48]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG123
       mov      rax, bword ptr [rbp+0x48]
       mov      r8d, dword ptr [rax+0x08]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       je       SHORT G_M000_IG122
       mov      rcx, 0x7FF9D77FAC74
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x48]
 
G_M000_IG120:                ;; offset=0x1D3A
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x918], xmm0
 
G_M000_IG121:                ;; offset=0x1D46
       lea      r9, [rbp-0x918]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp-0xE8], 2
       jmp      G_M000_IG231
 
G_M000_IG122:                ;; offset=0x1D6E
       mov      rcx, 0x7FF9D77FAC78
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG123:                ;; offset=0x1D7D
       mov      rcx, 0x7FF9D77FAC7C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x490], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x494], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x498], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x920], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x920]
       mov      edx, dword ptr [rbp-0x494]
       mov      r8d, dword ptr [rbp-0x498]
       mov      rcx, bword ptr [rbp-0x490]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0x928], rax
       mov      r9, gword ptr [rbp-0x928]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG217
 
G_M000_IG124:                ;; offset=0x1E21
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG125
       mov      rcx, 0x7FF9D77FAC80
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG125:                ;; offset=0x1E46
       mov      rcx, 0x7FF9D77FAC84
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG217
 
G_M000_IG126:                ;; offset=0x1E6D
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG127
       mov      rcx, 0x7FF9D77FAC88
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG127:                ;; offset=0x1E92
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG128
       mov      rcx, 0x7FF9D77FAC8C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG217
 
G_M000_IG128:                ;; offset=0x1EC1
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG129:                ;; offset=0x1EC5
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x948], ymm0
 
G_M000_IG130:                ;; offset=0x1ED1
       lea      r8, [rbp-0x948]
       lea      rdx, [rbp-0x488]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xAF0], rax
       mov      rcx, bword ptr [rbp-0xAF0]
       mov      rdx, gword ptr [rbp-0x488]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xAF0]
       mov      rcx, qword ptr [rbp-0x480]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG131
       mov      rcx, 0x7FF9D77FAC90
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x950], rax
       mov      rcx, gword ptr [rbp-0x950]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG131:                ;; offset=0x1F65
       mov      rcx, 0x7FF9D77FAC94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG217
 
G_M000_IG132:                ;; offset=0x1F86
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       mov      dword ptr [rbp-0x8C], eax
       cmp      dword ptr [rbp-0x8C], 0
       je       SHORT G_M000_IG133
       mov      rcx, 0x7FF9D77FAC98
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x8C]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG133:                ;; offset=0x1FE5
       mov      rcx, 0x7FF9D77FAC9C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG217
 
G_M000_IG134:                ;; offset=0x2006
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG135
       mov      rcx, 0x7FF9D77FACA0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG135:                ;; offset=0x2034
       mov      rcx, 0x7FF9D77FACA4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG138
 
G_M000_IG136:                ;; offset=0x2045
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG140
 
G_M000_IG137:                ;; offset=0x2063
       mov      rcx, 0x7FF9D77FACA8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG138:                ;; offset=0x2072
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x38], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       mov      dword ptr [rbp-0x90], eax
       cmp      dword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG139
       mov      rcx, 0x7FF9D77FACAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x90]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG139:                ;; offset=0x20DA
       mov      rcx, 0x7FF9D77FACB0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG140:                ;; offset=0x20EE
       mov      rcx, 0x7FF9D77FACB4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG141:                ;; offset=0x2102
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG142
       mov      rcx, 0x7FF9D77FACB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG217
 
G_M000_IG142:                ;; offset=0x2137
       mov      rcx, 0x7FF9D77FACBC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG151
 
G_M000_IG143:                ;; offset=0x214B
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG149
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x294], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x294]
       jne      G_M000_IG148
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x2A0], rax
       mov      rax, gword ptr [rbp-0x2A0]
       mov      gword ptr [rbp-0xB48], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rdx, gword ptr [rbp-0xB48]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG216
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x958], rax
       mov      rdx, gword ptr [rbp-0x958]
       mov      rcx, 0x7FF9D77F5D30
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x98], rax
       cmp      gword ptr [rbp-0x98], 0
       je       G_M000_IG147
       mov      rcx, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       mov      gword ptr [rbp-0xA0], rax
       cmp      gword ptr [rbp-0xA0], 0
       je       G_M000_IG146
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:get_CanUnpackDirectly():bool:this]
       test     eax, eax
       je       G_M000_IG145
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rsp+0x20], rax
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x28], eax
 
G_M000_IG144:                ;; offset=0x2259
       lea      rdx, [rbp-0x2B0]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xA0]
       mov      r9, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xAF8], rax
       mov      rcx, bword ptr [rbp-0xAF8]
       mov      rdx, gword ptr [rbp-0x2B0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xAF8]
       mov      rcx, qword ptr [rbp-0x2A8]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      G_M000_IG150
       mov      rcx, 0x7FF9D77FACC0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x960], rax
       mov      rcx, gword ptr [rbp-0x960]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG145:                ;; offset=0x22F8
       mov      rcx, 0x7FF9D77FACC4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG146:                ;; offset=0x2309
       mov      rcx, 0x7FF9D77FACC8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG147:                ;; offset=0x231A
       mov      rcx, 0x7FF9D77FACCC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG148:                ;; offset=0x232B
       mov      rcx, 0x7FF9D77FACD0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG149:                ;; offset=0x233C
       mov      rcx, 0x7FF9D77FACD4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x234D
       mov      rcx, 0x7FF9D77FACD8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG217
 
G_M000_IG151:                ;; offset=0x236E
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x428], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x964], eax
       mov      edx, dword ptr [rbp-0x964]
       lea      r8, [rbp-0xA8]
       lea      r9, [rbp-0xB8]
       mov      rcx, bword ptr [rbp-0x428]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryAdvanceNativeIteration(int,byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG155
       movzx    rax, byte  ptr [rbp-0xA8]
       test     eax, eax
       je       SHORT G_M000_IG154
       mov      rcx, 0x7FF9D77FACDC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG152:                ;; offset=0x23D6
       vmovdqu  xmm0, xmmword ptr [rbp-0xB8]
       vmovdqu  xmmword ptr [rbp-0x978], xmm0
 
G_M000_IG153:                ;; offset=0x23E6
       lea      r9, [rbp-0x978]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG217
 
G_M000_IG154:                ;; offset=0x2404
       mov      rcx, 0x7FF9D77FACE0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x440], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x97C], eax
       mov      edx, dword ptr [rbp-0x97C]
       mov      rcx, bword ptr [rbp-0x440]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x10], eax
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG217
 
G_M000_IG155:                ;; offset=0x2468
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG156
       mov      rcx, 0x7FF9D77FACE4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG156:                ;; offset=0x248D
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG157
       mov      rcx, 0x7FF9D77FACE8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG217
 
G_M000_IG157:                ;; offset=0x24BC
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG158:                ;; offset=0x24C0
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x9A0], ymm0
 
G_M000_IG159:                ;; offset=0x24CC
       lea      r8, [rbp-0x9A0]
       lea      rdx, [rbp-0x438]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB00], rax
       mov      rcx, bword ptr [rbp-0xB00]
       mov      rdx, gword ptr [rbp-0x438]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB00]
       mov      rcx, qword ptr [rbp-0x430]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG160
       mov      rcx, 0x7FF9D77FACEC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x9A8], rax
       mov      rcx, gword ptr [rbp-0x9A8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG160:                ;; offset=0x2560
       mov      rcx, 0x7FF9D77FACF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG217
 
G_M000_IG161:                ;; offset=0x2581
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x3C8], rax
       mov      rax, gword ptr [rbp-0x3C8]
       mov      gword ptr [rbp-0x620], rax
       mov      rcx, gword ptr [rbp-0x620]
       mov      rdx, 0x7FF9D77FACF8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x620]
       mov      gword ptr [rbp-0x9B0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x9B4], eax
       mov      rcx, gword ptr [rbp-0x9B0]
       mov      edx, dword ptr [rbp-0x9B4]
       mov      r11, 0x7FF9D70A1A48
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0xC4], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x3D0], rax
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rbp-0x9B8], eax
       mov      edx, dword ptr [rbp-0x9B8]
       mov      rcx, bword ptr [rbp-0x3D0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0xD0], rax
       mov      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x28], rax
       lea      rax, [rbp-0xD8]
       mov      qword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG165
       cmp      gword ptr [rbp-0xD8], 0
       je       SHORT G_M000_IG163
       mov      rax, gword ptr [rbp-0xD8]
       mov      gword ptr [rbp-0x628], rax
       mov      rcx, gword ptr [rbp-0x628]
 
G_M000_IG162:                ;; offset=0x26B6
       mov      rdx, 0x7FF9D77FAE00
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x628]
       mov      gword ptr [rbp-0x9C0], rax
       mov      rdx, gword ptr [rbp-0x9C0]
       mov      rcx, 0x7FF9D7500AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x148], rax
       cmp      gword ptr [rbp-0x148], 0
       je       SHORT G_M000_IG164
       mov      rax, gword ptr [rbp-0x148]
       mov      gword ptr [rbp-0x50], rax
       jmp      G_M000_IG224
 
G_M000_IG163:                ;; offset=0x270B
       mov      rcx, 0x7FF9D77FAF08
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG164:                ;; offset=0x271F
       mov      rcx, 0x7FF9D77FAF0C
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x420], xmm0
       vmovdqu  xmmword ptr [rbp-0x418], xmm0
       mov      rdx, gword ptr [rbp-0xD8]
       mov      rcx, 0x7FF9D76B6708
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x9C8], rax
       mov      r8, gword ptr [rbp-0x9C8]
       lea      rcx, [rbp-0x420]
       mov      rdx, 0x7FF9D77F6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:.ctor(System.__Canon):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rbp-0xB08], rax
       mov      rcx, bword ptr [rbp-0xB08]
       mov      rax, bword ptr [rbp-0xB08]
       cmp      byte  ptr [rax], al
       lea      rdx, [rbp-0x420]
       mov      r8d, 24
       vzeroupper 
       call     [CORINFO_HELP_BULK_WRITEBARRIER]
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG231
 
G_M000_IG165:                ;; offset=0x27D9
       cmp      gword ptr [rbp+0x20], 0
       jne      G_M000_IG168
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x150]
       mov      qword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG166
       mov      rcx, 0x7FF9D77FAF10
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG166:                ;; offset=0x283A
       cmp      gword ptr [rbp-0x150], 0
       je       G_M000_IG167
       mov      rcx, 0x7FF9D77FAF14
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x408], xmm0
       vmovdqu  xmmword ptr [rbp-0x400], xmm0
       lea      rcx, [rbp-0x408]
       mov      r8, gword ptr [rbp-0x150]
       mov      rdx, 0x7FF9D77F6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:.ctor(System.__Canon):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rbp-0xB10], rax
       mov      rcx, bword ptr [rbp-0xB10]
       mov      rax, bword ptr [rbp-0xB10]
       cmp      byte  ptr [rax], al
       lea      rdx, [rbp-0x408]
       mov      r8d, 24
       vzeroupper 
       call     [CORINFO_HELP_BULK_WRITEBARRIER]
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG231
 
G_M000_IG167:                ;; offset=0x28E4
       mov      rcx, 0x7FF9D77FAF18
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG168:                ;; offset=0x28F8
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x28], rax
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      r8d, dword ptr [rbp-0xC4]
       mov      r9, gword ptr [rbp-0xD0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       je       G_M000_IG172
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, 0x7FF9D77F6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_IsCompletedSuccessfully():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG170
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, 0x7FF9D77F6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_Result():System.__Canon:this]
       cmp      rax, gword ptr [rbp+0x20]
       je       SHORT G_M000_IG171
 
G_M000_IG169:                ;; offset=0x2964
       mov      rcx, 0x7FF9D77FAF1C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG170:                ;; offset=0x2973
       mov      rcx, 0x7FF9D77FAF20
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG231
 
G_M000_IG171:                ;; offset=0x29AC
       mov      rcx, 0x7FF9D77FAF24
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG217
 
G_M000_IG172:                ;; offset=0x29D8
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG173
       mov      rcx, 0x7FF9D77FAF28
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG217
 
G_M000_IG173:                ;; offset=0x2A48
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0x3E0]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG174:                ;; offset=0x2A7D
       vmovdqu  xmm0, xmmword ptr [rbp-0x3E0]
       vmovdqu  xmmword ptr [rbp-0x9D8], xmm0
 
G_M000_IG175:                ;; offset=0x2A8D
       lea      rdx, [rbp-0x9D8]
       lea      rcx, [rbp-0x3F0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB18], rax
       mov      rcx, bword ptr [rbp-0xB18]
       mov      rdx, gword ptr [rbp-0x3F0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB18]
       mov      rcx, qword ptr [rbp-0x3E8]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG176
       mov      rcx, 0x7FF9D77FAF2C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x9E0], rax
       mov      rcx, gword ptr [rbp-0x9E0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG176:                ;; offset=0x2B1B
       mov      rcx, 0x7FF9D77FAF30
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG217
 
G_M000_IG177:                ;; offset=0x2B39
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x448], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x9E4], eax
       mov      edx, dword ptr [rbp-0x9E4]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0x450], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x454], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x458], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x9F0], rax
       mov      rax, gword ptr [rbp-0x9F0]
       mov      gword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp-0x450]
       mov      r8d, dword ptr [rbp-0x454]
       mov      r9d, dword ptr [rbp-0x458]
       mov      rcx, bword ptr [rbp-0x448]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG178
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG179
       mov      rcx, 0x7FF9D77FAF34
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG178:                ;; offset=0x2C04
       mov      rcx, 0x7FF9D77FAF38
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG179:                ;; offset=0x2C18
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG180
       mov      rcx, 0x7FF9D77FAF3C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG217
 
G_M000_IG180:                ;; offset=0x2C44
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG181:                ;; offset=0x2C48
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xA10], ymm0
 
G_M000_IG182:                ;; offset=0x2C54
       lea      r8, [rbp-0xA10]
       lea      rdx, [rbp-0x468]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG183:                ;; offset=0x2C6E
       vmovdqu  xmm0, xmmword ptr [rbp-0x468]
       vmovdqu  xmmword ptr [rbp-0xA20], xmm0
 
G_M000_IG184:                ;; offset=0x2C7E
       lea      rdx, [rbp-0xA20]
       lea      rcx, [rbp-0x478]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB20], rax
       mov      rcx, bword ptr [rbp-0xB20]
       mov      rdx, gword ptr [rbp-0x478]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB20]
       mov      rcx, qword ptr [rbp-0x470]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG185
       mov      rcx, 0x7FF9D77FAF40
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA28], rax
       mov      rcx, gword ptr [rbp-0xA28]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG185:                ;; offset=0x2D0C
       mov      rcx, 0x7FF9D77FAF44
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG217
 
G_M000_IG186:                ;; offset=0x2D2A
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG187
       mov      rcx, 0x7FF9D77FAF48
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG187:                ;; offset=0x2D4F
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG188
       mov      rcx, 0x7FF9D77FAF4C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG217
 
G_M000_IG188:                ;; offset=0x2D7B
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG189:                ;; offset=0x2D7F
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xA48], ymm0
 
G_M000_IG190:                ;; offset=0x2D8B
       lea      r8, [rbp-0xA48]
       lea      rdx, [rbp-0x3B0]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG191:                ;; offset=0x2DA5
       vmovdqu  xmm0, xmmword ptr [rbp-0x3B0]
       vmovdqu  xmmword ptr [rbp-0xA58], xmm0
 
G_M000_IG192:                ;; offset=0x2DB5
       lea      rdx, [rbp-0xA58]
       lea      rcx, [rbp-0x3C0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB28], rax
       mov      rcx, bword ptr [rbp-0xB28]
       mov      rdx, gword ptr [rbp-0x3C0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB28]
       mov      rcx, qword ptr [rbp-0x3B8]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG193
       mov      rcx, 0x7FF9D77FAF50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA60], rax
       mov      rcx, gword ptr [rbp-0xA60]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG193:                ;; offset=0x2E43
       mov      rcx, 0x7FF9D77FAF54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG217
 
G_M000_IG194:                ;; offset=0x2E61
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG195
       mov      rcx, 0x7FF9D77FAF58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG195:                ;; offset=0x2E86
       mov      rcx, 0x7FF9D77FAF5C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG217
 
G_M000_IG196:                ;; offset=0x2EAA
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0xA64], eax
       mov      edx, dword ptr [rbp-0xA64]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0xE0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG198
       mov      rcx, gword ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG197
       mov      rcx, 0x7FF9D77FAF60
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG197:                ;; offset=0x2F0E
       mov      rcx, 0x7FF9D77FAF64
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG198:                ;; offset=0x2F1D
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       SHORT G_M000_IG200
       mov      rdx, gword ptr [rbp-0xE0]
       mov      rcx, 0x7FF9D77F9A80
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG201
 
G_M000_IG199:                ;; offset=0x2F41
       mov      rcx, 0x7FF9D77FAF68
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG200:                ;; offset=0x2F50
       mov      rcx, 0x7FF9D77FAF6C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG217
 
G_M000_IG201:                ;; offset=0x2F7D
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG202:                ;; offset=0x2F81
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xA88], ymm0
 
G_M000_IG203:                ;; offset=0x2F8D
       lea      r8, [rbp-0xA88]
       lea      rdx, [rbp-0x390]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB30], rax
       mov      rcx, bword ptr [rbp-0xB30]
       mov      rdx, gword ptr [rbp-0x390]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB30]
       mov      rcx, qword ptr [rbp-0x388]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG204
       mov      rcx, 0x7FF9D77FAF70
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA90], rax
       mov      rcx, gword ptr [rbp-0xA90]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG204:                ;; offset=0x3021
       mov      rcx, 0x7FF9D77FAF74
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG217
 
G_M000_IG205:                ;; offset=0x3042
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG209
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x154], eax
       cmp      dword ptr [rbp-0x154], 49
       je       SHORT G_M000_IG208
       cmp      dword ptr [rbp-0x154], 57
       je       SHORT G_M000_IG207
       cmp      dword ptr [rbp-0x154], 58
       je       SHORT G_M000_IG206
       mov      rcx, 0x7FF9D77FAF78
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG206:                ;; offset=0x3092
       mov      rcx, 0x7FF9D77FAF7C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG209
 
G_M000_IG207:                ;; offset=0x30A3
       mov      rcx, 0x7FF9D77FAF80
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG209
 
G_M000_IG208:                ;; offset=0x30B4
       mov      rcx, 0x7FF9D77FAF84
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG209:                ;; offset=0x30C3
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x44], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_IsUnassigned():bool:this]
       test     eax, eax
       jne      G_M000_IG211
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG212
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG210
       mov      rcx, 0x7FF9D77FAF88
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x3A0], xmm0
       lea      rcx, [rbp-0x3A0]
       mov      edx, dword ptr [rbp-0x44]
       call     [System.Threading.Tasks.ValueTask`1[bool]:.ctor(bool):this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB38], rax
       mov      rcx, bword ptr [rbp-0xB38]
       mov      rdx, gword ptr [rbp-0x3A0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB38]
       mov      rcx, qword ptr [rbp-0x398]
       mov      qword ptr [rax+0x08], rcx
       mov      dword ptr [rbp-0xE8], 5
       jmp      G_M000_IG231
 
G_M000_IG210:                ;; offset=0x3186
       mov      rcx, 0x7FF9D77FAF8C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG212
 
G_M000_IG211:                ;; offset=0x3197
       mov      rcx, 0x7FF9D77FAF90
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG212:                ;; offset=0x31AB
       mov      rcx, 0x7FF9D77FAF94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG231
 
G_M000_IG213:                ;; offset=0x31C9
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x1B8], ymm0
       vmovdqu  xmmword ptr [rbp-0x1A0], xmm0
       lea      rcx, [rbp-0x1B8]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG214:                ;; offset=0x31F5
       vmovdqu  ymm0, ymmword ptr [rbp-0x1B8]
       vmovdqu  ymmword ptr [rbp-0x180], ymm0
       mov      rax, qword ptr [rbp-0x198]
       mov      qword ptr [rbp-0x160], rax
 
G_M000_IG215:                ;; offset=0x3213
       lea      rcx, [rbp-0x180]
       mov      rdx, 0x2965DB72A40
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendLiteral(System.String):this]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0xA94], eax
       mov      edx, dword ptr [rbp-0xA94]
       lea      rcx, [rbp-0x180]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1C0], rax
       lea      rcx, [rbp-0x180]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      gword ptr [rbp-0xAA0], rax
       mov      rdx, gword ptr [rbp-0xAA0]
       mov      rcx, gword ptr [rbp-0x1C0]
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, gword ptr [rbp-0x1C0]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG216:                ;; offset=0x3298
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG217:                ;; offset=0x329E
       mov      eax, dword ptr [rbp-0x62C]
       dec      eax
       mov      dword ptr [rbp-0x62C], eax
       cmp      dword ptr [rbp-0x62C], 0
       jg       SHORT G_M000_IG219
 
G_M000_IG218:                ;; offset=0x32B5
       lea      rcx, [rbp-0x62C]
       mov      edx, 0xF76
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG219:                ;; offset=0x32C8
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG222
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG221
       mov      rcx, 0x7FF9D77FAFA4
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x1E0]
       mov      edx, dword ptr [rbp-0x44]
       call     [System.Threading.Tasks.ValueTask`1[bool]:.ctor(bool):this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB40], rax
       mov      rcx, bword ptr [rbp-0xB40]
       mov      rdx, gword ptr [rbp-0x1E0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB40]
       mov      rcx, qword ptr [rbp-0x1D8]
       mov      qword ptr [rax+0x08], rcx
       mov      eax, 5
 
G_M000_IG220:                ;; offset=0x3340
       vzeroupper 
       add      rsp, 0xB90
       pop      rbp
       ret      
 
G_M000_IG221:                ;; offset=0x334C
       mov      rcx, 0x7FF9D77FAFA8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG222:                ;; offset=0x335B
       cmp      dword ptr [rbp-0x44], 0
       jne      SHORT G_M000_IG223
       mov      rcx, 0x7FF9D77FAFAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x1D0], rax
       mov      rax, bword ptr [rbp-0x1D0]
       inc      dword ptr [rax]
       jmp      SHORT G_M000_IG227
 
G_M000_IG223:                ;; offset=0x3390
       mov      rcx, 0x7FF9D77FAFB0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG227
 
G_M000_IG224:                ;; offset=0x33A1
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xAB8], rax
       mov      r9, gword ptr [rbp-0xAB8]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG226
 
G_M000_IG225:                ;; offset=0x33CF
       mov      rcx, gword ptr [rbp-0x50]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG226:                ;; offset=0x33D9
       mov      rcx, 0x7FF9D77FAFB4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG217
 
G_M000_IG227:                ;; offset=0x33F4
       mov      eax, dword ptr [rbp-0x62C]
       dec      eax
       mov      dword ptr [rbp-0x62C], eax
       cmp      dword ptr [rbp-0x62C], 0
       jg       SHORT G_M000_IG229
 
G_M000_IG228:                ;; offset=0x340B
       lea      rcx, [rbp-0x62C]
       mov      edx, 0xFBB
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG229:                ;; offset=0x341E
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      eax, dword ptr [rcx+0x08]
       jl       G_M000_IG03
       mov      rcx, 0x7FF9D77FAFB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG230:                ;; offset=0x3446
       vzeroupper 
       add      rsp, 0xB90
       pop      rbp
       ret      
 
G_M000_IG231:                ;; offset=0x3452
       mov      rcx, 0x7FF9D77FAFBC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xE8]
 
G_M000_IG232:                ;; offset=0x3467
       vzeroupper 
       add      rsp, 0xB90
       pop      rbp
       ret      
 
G_M000_IG233:                ;; offset=0x3473
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG234:                ;; offset=0x3479
       sub      rsp, 72
 
G_M000_IG235:                ;; offset=0x347D
       mov      gword ptr [rbp-0x608], rcx
       mov      rax, gword ptr [rbp-0x608]
       mov      gword ptr [rbp-0x188], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG237
 
G_M000_IG236:                ;; offset=0x3499
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG237:                ;; offset=0x349F
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xAA8], rax
       mov      r8, gword ptr [rbp-0xAA8]
       mov      rdx, gword ptr [rbp-0x188]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG239
       mov      rcx, 0x7FF9D77FAF98
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       lea      rax, G_M000_IG231
 
G_M000_IG238:                ;; offset=0x34EE
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG239:                ;; offset=0x34F6
       mov      rcx, 0x7FF9D77FAF9C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       lea      rax, G_M000_IG217
 
G_M000_IG240:                ;; offset=0x3513
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG241:                ;; offset=0x351B
       sub      rsp, 72
 
G_M000_IG242:                ;; offset=0x351F
       mov      gword ptr [rbp-0x600], rcx
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xAB0], rax
       mov      r9, gword ptr [rbp-0xAB0]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x600]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG244
 
G_M000_IG243:                ;; offset=0x3557
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG244:                ;; offset=0x355D
       mov      rcx, 0x7FF9D77FAFA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       lea      rax, G_M000_IG217
 
G_M000_IG245:                ;; offset=0x357A
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	00001336h ; case G_M000_IG91
       	dd	0000162Bh ; case G_M000_IG104
       	dd	00000104h ; case G_M000_IG08
       	dd	000002ACh ; case G_M000_IG12
       	dd	000016ADh ; case G_M000_IG105
       	dd	0000172Eh ; case G_M000_IG106
       	dd	00000ADCh ; case G_M000_IG54
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	0000200Fh ; case G_M000_IG138
       	dd	0000200Fh ; case G_M000_IG138
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	000014E4h ; case G_M000_IG97
       	dd	000014E4h ; case G_M000_IG97
       	dd	000017F1h ; case G_M000_IG108
       	dd	0000040Fh ; case G_M000_IG16
       	dd	00000439h ; case G_M000_IG17
       	dd	0000184Ch ; case G_M000_IG110
       	dd	0000194Ch ; case G_M000_IG112
       	dd	00001A81h ; case G_M000_IG114
       	dd	00001B2Ch ; case G_M000_IG115
       	dd	00001BB0h ; case G_M000_IG116
       	dd	00001C54h ; case G_M000_IG117
       	dd	00001DBEh ; case G_M000_IG124
       	dd	00001DBEh ; case G_M000_IG124
       	dd	00001DBEh ; case G_M000_IG124
       	dd	00001E0Ah ; case G_M000_IG126
       	dd	00001E0Ah ; case G_M000_IG126
       	dd	00001E0Ah ; case G_M000_IG126
       	dd	00001DBEh ; case G_M000_IG124
       	dd	00002AD6h ; case G_M000_IG177
       	dd	0000230Bh ; case G_M000_IG151
       	dd	0000251Eh ; case G_M000_IG161
       	dd	00001FE2h ; case G_M000_IG136
       	dd	00002CC7h ; case G_M000_IG186
       	dd	00002DFEh ; case G_M000_IG194
       	dd	00001FA3h ; case G_M000_IG134
       	dd	00001FA3h ; case G_M000_IG134
       	dd	00001FA3h ; case G_M000_IG134
       	dd	00002FDFh ; case G_M000_IG205
       	dd	00002E47h ; case G_M000_IG196
       	dd	00001F23h ; case G_M000_IG132
       	dd	00002FDFh ; case G_M000_IG205
       	dd	00002FDFh ; case G_M000_IG205
       	dd	00002FDFh ; case G_M000_IG205
       	dd	00002FDFh ; case G_M000_IG205
       	dd	00002FDFh ; case G_M000_IG205
       	dd	00002FDFh ; case G_M000_IG205
       	dd	00002FDFh ; case G_M000_IG205
       	dd	000000E6h ; case G_M000_IG07
       	dd	00000C18h ; case G_M000_IG59
       	dd	0000101Ch ; case G_M000_IG76
       	dd	00002FDFh ; case G_M000_IG205
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	0000209Fh ; case G_M000_IG141
       	dd	000020E8h ; case G_M000_IG143
       	dd	000007E0h ; case G_M000_IG41
       	dd	000009A9h ; case G_M000_IG47
       	dd	000001A1h ; case G_M000_IG09

; Total bytes of code 13698

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 976
       lea      rbp, [rsp+0x3D0]
       xor      eax, eax
       mov      qword ptr [rbp-0x388], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x380], xmm4
       vmovdqa  xmmword ptr [rbp-0x370], xmm4
       mov      rax, -864
 
G_M000_IG64:                ;; offset=0x0037
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG64
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
 
G_M000_IG02:                ;; offset=0x0056
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0xD0], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x244], eax
       mov      edx, dword ptr [rbp-0x244]
       mov      rcx, gword ptr [rbp-0xD0]
       mov      r11, 0x7FF9D70A1C28
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x0C], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0xD8], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0xDC], eax
       mov      rax, bword ptr [rbp-0xD8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xDC], eax
       jae      G_M000_IG53
       mov      rax, bword ptr [rbp-0xD8]
       mov      ecx, dword ptr [rbp-0xDC]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x250], rax
       mov      rdx, gword ptr [rbp-0x250]
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x18], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x28], xmm0
 
G_M000_IG03:                ;; offset=0x012D
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG42
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG51
 
G_M000_IG04:                ;; offset=0x016E
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       jne      G_M000_IG08
       mov      rcx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x200], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x204], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x254], eax
       mov      r9d, dword ptr [rbp-0x254]
       lea      rdx, [rbp-0x218]
       mov      r8d, dword ptr [rbp-0x204]
       mov      rcx, bword ptr [rbp-0x200]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG05:                ;; offset=0x01F2
       vmovdqu  xmm0, xmmword ptr [rbp-0x218]
       vmovdqu  xmmword ptr [rbp-0x268], xmm0
 
G_M000_IG06:                ;; offset=0x0202
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x270], rax
       mov      rdx, gword ptr [rbp-0x270]
       lea      rcx, [rbp-0x268]
       lea      r9, [rbp-0x38]
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG07
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG51
 
G_M000_IG07:                ;; offset=0x0243
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG42
 
G_M000_IG08:                ;; offset=0x0256
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG35
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, 0x7FF9D76B1038
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x40], rax
       cmp      gword ptr [rbp-0x40], 0
       je       G_M000_IG35
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x108], rax
       mov      rax, bword ptr [rbp-0x108]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x0C], eax
       jae      G_M000_IG39
       mov      rax, bword ptr [rbp-0x108]
       mov      ecx, dword ptr [rbp-0x0C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x48], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG20
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, 0x7FF9D75C1030
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       je       G_M000_IG20
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x278], rax
       mov      rdx, gword ptr [rbp-0x278]
       mov      rcx, 0x7FF9D76AFB58
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       G_M000_IG20
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingMethod():Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod:this]
 
G_M000_IG09:                ;; offset=0x034C
       cmp      rax, gword ptr [rbp-0x18]
       jne      G_M000_IG20
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG39
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
 
G_M000_IG10:                ;; offset=0x0384
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
 
G_M000_IG11:                ;; offset=0x0390
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x180], rax
       lea      rcx, [rbp-0x90]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x27C], eax
       mov      edx, dword ptr [rbp-0x27C]
       mov      rcx, gword ptr [rbp-0x180]
       mov      r11, 0x7FF9D70A1C40
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x98], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x188], rax
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingCallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x288], rax
       mov      rdx, gword ptr [rbp-0x288]
       mov      rcx, gword ptr [rbp-0x188]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG12:                ;; offset=0x0414
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x190], rax
       lea      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rbp-0x198], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x1A8], rax
       mov      rax, gword ptr [rbp-0x190]
       mov      gword ptr [rbp-0x1B0], rax
       mov      rcx, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      G_M000_IG14
       mov      rax, bword ptr [rbp-0x198]
       mov      bword ptr [rbp-0x1E0], rax
       mov      rax, gword ptr [rbp-0x1A0]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rax, gword ptr [rbp-0x1B0]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rax, bword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x40]
       test     eax, eax
       je       SHORT G_M000_IG13
       mov      rax, bword ptr [rbp-0x1E0]
       mov      bword ptr [rbp-0x1B8], rax
       mov      rax, gword ptr [rbp-0x1E8]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rax, gword ptr [rbp-0x1F0]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, gword ptr [rbp-0x1F8]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rcx, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0x1D4], eax
       jmp      G_M000_IG15
 
G_M000_IG13:                ;; offset=0x04FF
       mov      rax, bword ptr [rbp-0x1E0]
       mov      bword ptr [rbp-0x1B8], rax
       mov      rax, gword ptr [rbp-0x1E8]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rax, gword ptr [rbp-0x1F0]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, gword ptr [rbp-0x1F8]
       mov      gword ptr [rbp-0x1D0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x1D4], eax
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x0541
       mov      rax, bword ptr [rbp-0x198]
       mov      bword ptr [rbp-0x1B8], rax
       mov      rax, gword ptr [rbp-0x1A0]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, gword ptr [rbp-0x1B0]
       mov      gword ptr [rbp-0x1D0], rax
       mov      dword ptr [rbp-0x1D4], 1
 
G_M000_IG15:                ;; offset=0x0583
       mov      rcx, gword ptr [rbp-0x1C0]
       mov      rdx, gword ptr [rbp-0x1C8]
       mov      r8, gword ptr [rbp-0x1D0]
       mov      r9d, dword ptr [rbp-0x1D4]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x290], rax
       mov      rdx, gword ptr [rbp-0x290]
       mov      rcx, bword ptr [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       nop      
 
G_M000_IG16:                ;; offset=0x05C1
       call     G_M000_IG54
       nop      
 
G_M000_IG17:                ;; offset=0x05C7
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x38], 2
 
G_M000_IG18:                ;; offset=0x05CF
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG19:                ;; offset=0x05DC
       lea      r8, [rbp-0x2A0]
       lea      rdx, [rbp-0x90]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      dword ptr [rbp-0x2C], 1
       jmp      G_M000_IG51
 
G_M000_IG20:                ;; offset=0x0600
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x2A8], rax
       mov      rdx, gword ptr [rbp-0x2A8]
       mov      rcx, 0x7FF9D7803218
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x60], 0
       je       G_M000_IG27
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 3
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG39
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       cmp      eax, dword ptr [rbp-0x0C]
       jne      G_M000_IG27
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG21:                ;; offset=0x067D
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x2B8], xmm0
 
G_M000_IG22:                ;; offset=0x068A
       lea      rdx, [rbp-0x2B8]
       lea      rcx, [rbp-0x150]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG23:                ;; offset=0x069E
       vmovdqu  xmm0, xmmword ptr [rbp-0x150]
       vmovdqu  xmmword ptr [rbp-0x2C8], xmm0
 
G_M000_IG24:                ;; offset=0x06AE
       lea      rax, [rbp-0x68]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x70]
       mov      qword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x2C8]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9d, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadAsciiTrim(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG27
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 3
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG39
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x2CC], eax
       mov      edx, dword ptr [rbp-0x2CC]
       mov      rcx, gword ptr [rbp-0x158]
       mov      r11, 0x7FF9D70A1C38
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xA0], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x160], rax
       movzx    rax, byte  ptr [rbp-0x70]
       mov      dword ptr [rbp-0x164], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x170], rax
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x178], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rsp+0x20], rax
 
G_M000_IG25:                ;; offset=0x07AC
       vmovdqu  xmm0, xmmword ptr [rbp-0xB0]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG26:                ;; offset=0x07BC
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x2E0]
       mov      qword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp-0x160]
       mov      r8d, dword ptr [rbp-0x164]
       mov      r9, gword ptr [rbp-0x170]
       mov      rcx, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteTrimmedSplit(Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Runtime.Text.PyString,byte,Lokad.Lython.LythonSourceSpan,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x2E8], rax
       mov      rdx, gword ptr [rbp-0x2E8]
       lea      rcx, [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x38], 3
       jmp      G_M000_IG42
 
G_M000_IG27:                ;; offset=0x0819
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x110], rax
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG28:                ;; offset=0x082C
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x2F8], xmm0
 
G_M000_IG29:                ;; offset=0x0839
       lea      rdx, [rbp-0x2F8]
       lea      rcx, [rbp-0x120]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG30:                ;; offset=0x084D
       vmovdqu  xmm0, xmmword ptr [rbp-0x120]
       vmovdqu  xmmword ptr [rbp-0x308], xmm0
 
G_M000_IG31:                ;; offset=0x085D
       mov      rax, gword ptr [rbp-0x08]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x38], rax
       lea      r8, [rbp-0x308]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      r9, bword ptr [rax+0x38]
       mov      rdx, gword ptr [rbp-0x110]
       mov      rcx, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG42
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x128], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x12C], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x30C], eax
       mov      r9d, dword ptr [rbp-0x30C]
       lea      rdx, [rbp-0x140]
       mov      r8d, dword ptr [rbp-0x12C]
       mov      rcx, bword ptr [rbp-0x128]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG32:                ;; offset=0x090F
       vmovdqu  xmm0, xmmword ptr [rbp-0x140]
       vmovdqu  xmmword ptr [rbp-0x320], xmm0
 
G_M000_IG33:                ;; offset=0x091F
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x328], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xB8]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp-0x328]
       lea      r8, [rbp-0x320]
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG34
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG51
 
G_M000_IG34:                ;; offset=0x0975
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG42
 
G_M000_IG35:                ;; offset=0x098B
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG36:                ;; offset=0x098F
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x338], xmm0
 
G_M000_IG37:                ;; offset=0x099C
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x30], rax
       lea      r8, [rbp-0x338]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9d, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG41
       lea      rcx, [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x340], rax
       mov      rdx, gword ptr [rbp-0x340]
       mov      rcx, 0x7FF9D7500AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xC0], rax
       cmp      gword ptr [rbp-0xC0], 0
       je       G_M000_IG42
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ExceptionRegions():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableExceptionRegion]:this]
       mov      gword ptr [rbp-0x348], rax
       mov      rcx, gword ptr [rbp-0x348]
       mov      r11, 0x7FF9D70A1C30
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       jne      SHORT G_M000_IG40
 
G_M000_IG38:                ;; offset=0x0A45
       mov      rcx, gword ptr [rbp-0xC0]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG39:                ;; offset=0x0A52
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG40:                ;; offset=0x0A58
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:set_Failure(Lokad.Lython.Runtime.LythonRuntimeException):this]
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG51
 
G_M000_IG41:                ;; offset=0x0A73
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG42
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG51
 
G_M000_IG42:                ;; offset=0x0AA0
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG46
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 15
       jne      G_M000_IG46
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0xE8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x358], rax
       mov      rdx, gword ptr [rbp-0x358]
       mov      rcx, gword ptr [rbp-0xE8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x35C], eax
       mov      edx, dword ptr [rbp-0x35C]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0xF0], rax
 
G_M000_IG43:                ;; offset=0x0B8B
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       mov      dword ptr [rbp-0x360], eax
       mov      r9d, dword ptr [rbp-0x360]
       lea      rdx, [rbp-0x100]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      rcx, bword ptr [rbp-0xF0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG44:                ;; offset=0x0BBC
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0x370], xmm0
 
G_M000_IG45:                ;; offset=0x0BCC
       lea      rcx, [rbp-0x370]
       call     [System.MemoryExtensions:Reverse[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       jmp      SHORT G_M000_IG49
 
G_M000_IG46:                ;; offset=0x0BDB
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x388], rax
 
G_M000_IG47:                ;; offset=0x0C09
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x380], xmm0
 
G_M000_IG48:                ;; offset=0x0C16
       mov      rdx, bword ptr [rbp-0x388]
       lea      r8, [rbp-0x380]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG49:                ;; offset=0x0C2E
       mov      eax, 1
 
G_M000_IG50:                ;; offset=0x0C33
       vzeroupper 
       add      rsp, 976
       pop      rbp
       ret      
 
G_M000_IG51:                ;; offset=0x0C3F
       mov      eax, dword ptr [rbp-0x2C]
 
G_M000_IG52:                ;; offset=0x0C42
       vzeroupper 
       add      rsp, 976
       pop      rbp
       ret      
 
G_M000_IG53:                ;; offset=0x0C4E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG54:                ;; offset=0x0C54
       sub      rsp, 72
 
G_M000_IG55:                ;; offset=0x0C58
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG56:                ;; offset=0x0C69
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG57:                ;; offset=0x0C71
       sub      rsp, 72
 
G_M000_IG58:                ;; offset=0x0C75
       mov      gword ptr [rbp-0x220], rcx
       mov      rdx, gword ptr [rbp-0x220]
       mov      rcx, 0x7FF9D71A2168
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x228], rax
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rbp-0x230], rax
       cmp      gword ptr [rbp-0x228], 0
       jne      SHORT G_M000_IG59
       xor      eax, eax
       mov      dword ptr [rbp-0x234], eax
       jmp      SHORT G_M000_IG60
 
G_M000_IG59:                ;; offset=0x0CBC
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x350], rax
       mov      rdx, gword ptr [rbp-0x350]
       lea      r8, [rbp-0xC8]
       mov      rcx, gword ptr [rbp-0x230]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
       mov      dword ptr [rbp-0x234], eax
 
G_M000_IG60:                ;; offset=0x0CF8
       mov      eax, dword ptr [rbp-0x234]
 
G_M000_IG61:                ;; offset=0x0CFE
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG62:                ;; offset=0x0D06
       sub      rsp, 72
 
G_M000_IG63:                ;; offset=0x0D0A
       mov      gword ptr [rbp-0x240], rcx
       mov      rcx, gword ptr [rbp-0xC8]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 3358

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (Tier1-OSR)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1-OSR code
; OSR variant for entry point 0xf76
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 2
; 45 inlinees with PGO data; 261 single block inlinees; 55 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rax
       mov      rax, qword ptr [rbp]
       push     rax
       sub      rsp, 864
       mov      qword ptr [rsp+0xEF8], r15
       mov      qword ptr [rsp+0xEF0], r14
       mov      qword ptr [rsp+0xEE8], r13
       mov      qword ptr [rsp+0xEE0], r12
       mov      qword ptr [rsp+0xED8], rdi
       mov      qword ptr [rsp+0xED0], rsi
       mov      qword ptr [rsp+0xEC8], rbx
       lea      rbp, [rsp+0x360]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -672
 
G_M000_IG488:                ;; offset=0x005B
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG488
       mov      qword ptr [rbp-0x40], rax
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      r9, gword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      eax, dword ptr [rbp+0xBC8]
 
G_M000_IG02:                ;; offset=0x0092
       cmp      byte  ptr [rbp+0xBC8], 0
       jne      G_M000_IG468
 
G_M000_IG03:                ;; offset=0x009F
       cmp      dword ptr [rbp+0xB5C], 0
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00A8
       mov      rcx, bword ptr [rbp+0xBB0]
       inc      dword ptr [rcx+0x10]
 
G_M000_IG05:                ;; offset=0x00B2
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      edx, dword ptr [rcx+0x10]
       mov      r8, gword ptr [rbp+0xB60]
       mov      ebx, dword ptr [r8+0x08]
       cmp      edx, ebx
       jge      G_M000_IG466
 
G_M000_IG06:                ;; offset=0x00CF
       xor      edx, edx
       mov      dword ptr [rbp+0xB5C], edx
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, ebx
       jae      G_M000_IG474
       mov      r8, gword ptr [rbp+0xB60]
       shl      rdx, 5
       lea      rdx, bword ptr [r8+rdx+0x10]
       mov      bword ptr [rbp+0xB48], rdx
       mov      r9, gword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [r9+0x98]
       mov      r8, bword ptr [rbp+0xB48]
       mov      r8, gword ptr [r8]
       mov      r10, gword ptr [rdx+0x88]
       cmp      gword ptr [r10+0x20], 0
       jne      SHORT G_M000_IG09
 
G_M000_IG07:                ;; offset=0x011F
       mov      r10, gword ptr [rdx+0x180]
       test     r10, r10
       je       SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x012B
       cmp      dword ptr [r10+0x20], 0
       setne    r10b
       movzx    r10, r10b
       test     r10d, r10d
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x013D
       mov      rcx, rdx
       mov      rdx, r8
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG10:                ;; offset=0x014A
       mov      r8, bword ptr [rbp+0xB48]
       mov      esi, dword ptr [r8+0x1C]
       cmp      esi, 72
       ja       G_M000_IG71
 
G_M000_IG11:                ;; offset=0x015E
       mov      r8d, esi
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*r8]
       lea      rcx, G_M000_IG02
       add      rdx, rcx
       jmp      rdx
 
G_M000_IG12:                ;; offset=0x0178
       mov      rdi, bword ptr [rbp+0xBB0]
       mov      r14, gword ptr [rdi]
       mov      r15, gword ptr [rdi+0x08]
       mov      ecx, esi
       cmp      ecx, 2
       je       SHORT G_M000_IG15
 
G_M000_IG13:                ;; offset=0x018D
       cmp      ecx, 25
       je       SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x0192
       cmp      ecx, 72
       jne      G_M000_IG308
 
G_M000_IG15:                ;; offset=0x019B
       mov      rdx, bword ptr [rbp+0xB48]
       mov      esi, dword ptr [rdx+0x08]
       mov      rdx, bword ptr [rbp+0xB48]
       mov      r13, gword ptr [rdx]
       cmp      esi, dword ptr [r15+0x08]
       jae      G_M000_IG462
       mov      edx, esi
       shl      rdx, 4
       lea      r15, bword ptr [r15+rdx+0x10]
       mov      rdx, gword ptr [r15]
       mov      rcx, 0x27637001CE0
       cmp      rdx, gword ptr [rcx]
       je       G_M000_IG46
 
G_M000_IG16:                ;; offset=0x01DA
       mov      rdx, gword ptr [r15]
       mov      rcx, 0x27637001CE8
       cmp      rdx, gword ptr [rcx]
       je       G_M000_IG45
 
G_M000_IG17:                ;; offset=0x01F0
       cmp      qword ptr [r15+0x08], 0
       jle      G_M000_IG29
 
G_M000_IG18:                ;; offset=0x01FB
       mov      rdx, gword ptr [r15]
       mov      rcx, 0x7FF9D7763360
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      r12, rax
       test     r12, r12
       je       G_M000_IG29
 
G_M000_IG19:                ;; offset=0x021A
       mov      eax, dword ptr [r15+0x08]
       dec      eax
       mov      dword ptr [rbp-0x1B4], eax
       mov      rdx, gword ptr [r12+0x08]
       mov      rcx, 0x7FF9D71628A8
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       jne      G_M000_IG44
 
G_M000_IG20:                ;; offset=0x0244
       mov      rax, gword ptr [r12+0x08]
       test     rax, rax
       je       SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x024E
       mov      rdx, 0x7FF9D77D2CB8
       cmp      qword ptr [rax], rdx
       je       SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x025D
       xor      rax, rax
 
G_M000_IG23:                ;; offset=0x025F
       test     rax, rax
       jne      G_M000_IG41
 
G_M000_IG24:                ;; offset=0x0268
       cmp      dword ptr [rbp-0x1B4], 0
       jne      G_M000_IG309
       mov      r8, r12
       mov      rcx, 0x7FF9D78746E0
       cmp      qword ptr [r8], rcx
       jne      G_M000_IG310
       lea      r12, bword ptr [r8+0x28]
 
G_M000_IG25:                ;; offset=0x028F
       mov      rdx, gword ptr [r12]
       mov      rcx, 0x27637001CE0
       cmp      rdx, gword ptr [rcx]
       jne      G_M000_IG43
 
G_M000_IG26:                ;; offset=0x02A6
       mov      rcx, 0x7FF9D754B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x2E8], rax
       mov      rdx, qword ptr [r12+0x08]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x1C8], xmm0
       lea      rcx, [rbp-0x1C8]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rax, gword ptr [rbp-0x2E8]
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, gword ptr [rbp-0x1C8]
       call     CORINFO_HELP_ASSIGN_REF
       mov      r8d, dword ptr [rbp-0x1C0]
       mov      rax, gword ptr [rbp-0x2E8]
       mov      dword ptr [rax+0x10], r8d
       mov      rdx, rax
       mov      gword ptr [rbp-0x2F0], rdx
       mov      r8, 0x27637001CE0
       mov      r8, gword ptr [r8]
       mov      rcx, r12
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       mov      rcx, 0x27637001CE0
       cmp      rax, gword ptr [rcx]
       je       G_M000_IG42
 
G_M000_IG27:                ;; offset=0x0335
       test     rax, rax
       je       G_M000_IG312
       mov      rdx, rax
 
G_M000_IG28:                ;; offset=0x0341
       mov      rcx, r15
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r15+0x08], rcx
 
G_M000_IG29:                ;; offset=0x034F
       mov      r12, gword ptr [r15]
 
G_M000_IG30:                ;; offset=0x0352
       test     r12, r12
       jne      G_M000_IG47
 
G_M000_IG31:                ;; offset=0x035B
       mov      r15, r12
 
G_M000_IG32:                ;; offset=0x035E
       test     r15, r15
       jne      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x0363
       mov      rcx, r14
       mov      edx, esi
       mov      r8, r13
       mov      r9, gword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r15, rax
 
G_M000_IG34:                ;; offset=0x037B
       mov      rcx, bword ptr [rbp+0xB48]
       cmp      dword ptr [rcx+0x18], 0
       jl       G_M000_IG67
 
G_M000_IG35:                ;; offset=0x038C
       lea      rsi, bword ptr [rdi+0x20]
       mov      rcx, bword ptr [rbp+0xB48]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       G_M000_IG66
 
G_M000_IG36:                ;; offset=0x03A3
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       G_M000_IG66
 
G_M000_IG37:                ;; offset=0x03B7
       mov      rcx, bword ptr [rbp+0xB48]
       mov      r14d, dword ptr [rcx+0x18]
 
G_M000_IG38:                ;; offset=0x03C2
       mov      rcx, bword ptr [rbp+0xB48]
       mov      r13d, dword ptr [rcx+0x18]
       cmp      r13d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x03D3
       mov      rcx, rsi
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG40:                ;; offset=0x03DF
       mov      rcx, gword ptr [rsi]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG462
       mov      edx, r14d
       shl      rdx, 4
       lea      r14, bword ptr [rcx+rdx+0x10]
       mov      rcx, r14
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
       xor      r9d, r9d
       mov      qword ptr [r14+0x08], r9
       mov      dword ptr [rsi+0x40], r13d
       jmp      G_M000_IG02
 
G_M000_IG41:                ;; offset=0x0413
       mov      r12d, dword ptr [rbp-0x1B4]
       cmp      r12d, dword ptr [rax+0x08]
       jae      G_M000_IG462
       mov      ecx, r12d
       shl      rcx, 4
       lea      r12, bword ptr [rax+rcx+0x10]
       jmp      G_M000_IG25
 
G_M000_IG42:                ;; offset=0x0435
       mov      r12, gword ptr [rbp-0x2F0]
       mov      rdx, r12
       jmp      G_M000_IG28
 
G_M000_IG43:                ;; offset=0x0444
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       jmp      G_M000_IG28
 
G_M000_IG44:                ;; offset=0x045C
       mov      r12d, dword ptr [rbp-0x1B4]
       cmp      r12d, dword ptr [rax+0x08]
       jae      G_M000_IG462
       mov      edx, r12d
       mov      rdx, gword ptr [rax+8*rdx+0x10]
       jmp      G_M000_IG28
 
G_M000_IG45:                ;; offset=0x047A
       mov      rcx, 0x7FF9D7196D68
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       vmovsd   xmm0, qword ptr [r15+0x08]
       vmovsd   qword ptr [r12+0x08], xmm0
       mov      rcx, r15
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r15+0x08], rcx
       jmp      G_M000_IG30
 
G_M000_IG46:                ;; offset=0x04AF
       mov      rcx, 0x7FF9D754B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       mov      rdx, qword ptr [r15+0x08]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x1B0], xmm0
       lea      rcx, [rbp-0x1B0]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, gword ptr [rbp-0x1B0]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x1A8]
       mov      dword ptr [r12+0x10], ecx
       mov      rcx, r15
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r15+0x08], rcx
       jmp      G_M000_IG30
 
G_M000_IG47:                ;; offset=0x0510
       mov      rcx, 0x7FF9D77F4838
       cmp      qword ptr [r12], rcx
       jne      G_M000_IG31
 
G_M000_IG48:                ;; offset=0x0524
       mov      rcx, gword ptr [r12+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x052E
       cmp      byte  ptr [rcx+0x101], 0
       jne      G_M000_IG57
 
G_M000_IG50:                ;; offset=0x053B
       mov      rcx, gword ptr [r12+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG52
 
G_M000_IG51:                ;; offset=0x0545
       movzx    rcx, byte  ptr [rcx+0xFF]
       test     ecx, ecx
       jne      SHORT G_M000_IG57
 
G_M000_IG52:                ;; offset=0x0550
       cmp      byte  ptr [r12+0x28], 0
       je       SHORT G_M000_IG55
 
G_M000_IG53:                ;; offset=0x0558
       cmp      gword ptr [r12+0x08], 0
       jne      SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x0560
       mov      rcx, 0x7FF9D754B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rdx, qword ptr [r12+0x20]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
       lea      rcx, [rbp-0x1E0]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r15+0x08]
       mov      rdx, gword ptr [rbp-0x1E0]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x1D8]
       mov      dword ptr [r15+0x10], ecx
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG55:                ;; offset=0x05B7
       mov      r15, gword ptr [r12+0x08]
 
G_M000_IG56:                ;; offset=0x05BC
       jmp      G_M000_IG32
 
G_M000_IG57:                ;; offset=0x05C1
       mov      r15, gword ptr [r12+0x10]
       mov      rcx, gword ptr [r15+0x08]
       test     rcx, rcx
       jne      G_M000_IG62
 
G_M000_IG58:                ;; offset=0x05D3
       mov      rcx, 0x7FF9D71ADDF0
       call     CORINFO_HELP_NEWSFAST
       mov      rcx, rax
       mov      gword ptr [rbp-0x2F8], rcx
       mov      rdx, 0x27637000068
       mov      rdx, gword ptr [rdx]
       mov      rax, rdx
       mov      gword ptr [rbp-0x320], rax
       mov      rdx, rax
       lea      rcx, bword ptr [rcx+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, gword ptr [rbp-0x320]
       call     [System.Collections.Generic.NonRandomizedStringEqualityComparer:GetStringComparer(System.Object):System.Collections.Generic.IEqualityComparer`1[System.String]]
       test     rax, rax
       je       SHORT G_M000_IG60
 
G_M000_IG59:                ;; offset=0x0621
       mov      rcx, gword ptr [rbp-0x2F8]
       lea      rcx, bword ptr [rcx+0x18]
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG60:                ;; offset=0x0634
       lea      rcx, bword ptr [r15+0x08]
       test     rcx, rcx
       je       G_M000_IG311
       mov      rdx, gword ptr [rbp-0x2F8]
       xor      r8, r8
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       mov      rcx, rax
       test     rcx, rcx
       jne      SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x0658
       mov      r15, gword ptr [rbp-0x2F8]
       mov      rcx, r15
 
G_M000_IG62:                ;; offset=0x0662
       mov      rdx, gword ptr [r12+0x18]
       lea      r8, [rbp-0x1D0]
       mov      r11, 0x7FF9D70A1CF8
       call     [r11]System.Collections.Generic.IReadOnlyDictionary`2[System.__Canon,System.__Canon]:TryGetValue(System.__Canon,byref):bool:this
       test     eax, eax
       jne      SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x067F
       xor      r15, r15
 
G_M000_IG64:                ;; offset=0x0682
       xor      rcx, rcx
       mov      gword ptr [rbp-0x1D0], rcx
       jmp      G_M000_IG56
 
G_M000_IG65:                ;; offset=0x0690
       mov      r15, gword ptr [rbp-0x1D0]
       jmp      SHORT G_M000_IG64
 
G_M000_IG66:                ;; offset=0x0699
       mov      rcx, bword ptr [rbp+0xB48]
       mov      r14d, dword ptr [rcx+0x14]
       jmp      G_M000_IG38
 
G_M000_IG67:                ;; offset=0x06A9
       mov      gword ptr [rbp-0x2B0], r15
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2A8], r9
       lea      r9, [rbp-0x2B0]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r8, bword ptr [rbp+0xB48]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG68:                ;; offset=0x06DD
       mov      rdi, bword ptr [rbp+0xBB0]
       mov      rcx, gword ptr [rdi]
       mov      rax, gword ptr [rcx+0x30]
       mov      rsi, rax
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG462
       mov      ecx, eax
       mov      rcx, gword ptr [rsi+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x2B0], rax
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2A8], r9
       lea      r9, [rbp-0x2B0]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r8, bword ptr [rbp+0xB48]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG69:                ;; offset=0x0745
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG151
 
G_M000_IG70:                ;; offset=0x0753
       mov      rdi, bword ptr [rbp+0xBB0]
       mov      rcx, gword ptr [rdi]
       mov      rsi, gword ptr [rcx+0xA8]
       mov      rcx, bword ptr [rbp+0xB48]
       xor      edx, edx
       mov      r8, 0x2965DB746A8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:ReadPrimaryOperand(int,System.String):int:this]
       mov      edx, eax
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A1CF0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       cmp      byte  ptr [rbp+0xBC8], 0
       jne      G_M000_IG374
       jmp      G_M000_IG373
 
G_M000_IG71:                ;; offset=0x07A1
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
       lea      rcx, [rbp-0x60]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG72:                ;; offset=0x07C4
       vmovdqu  ymm0, ymmword ptr [rbp-0x60]
       vmovdqu  ymmword ptr [rbp+0xA20], ymm0
       mov      rcx, qword ptr [rbp-0x40]
       mov      qword ptr [rbp+0xA40], rcx
 
G_M000_IG73:                ;; offset=0x07DC
       mov      ecx, dword ptr [rbp+0xA30]
       mov      edx, dword ptr [rbp+0xA40]
       cmp      ecx, edx
       ja       G_M000_IG332
       mov      rax, bword ptr [rbp+0xA38]
       mov      r8d, ecx
       lea      rax, bword ptr [rax+2*r8]
       sub      edx, ecx
       cmp      edx, 27
       jb       G_M000_IG463
 
G_M000_IG74:                ;; offset=0x0809
       vmovups  ymm0, ymmword ptr [reloc @RWD292]
       vmovups  ymmword ptr [rax], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD324]
       vmovups  xmmword ptr [rax+0x20], xmm0
       mov      dword ptr [rax+0x30], 0x3A0065
       mov      word  ptr [rax+0x34], 32
       mov      ecx, dword ptr [rbp+0xA30]
       add      ecx, 27
       mov      dword ptr [rbp+0xA30], ecx
 
G_M000_IG75:                ;; offset=0x083E
       mov      rdx, bword ptr [rbp+0xB48]
       mov      edx, dword ptr [rdx+0x1C]
       lea      rcx, [rbp+0xA20]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       lea      rcx, [rbp+0xA20]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rdx, rax
       mov      rcx, rsi
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG76:                ;; offset=0x0889
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG151
 
G_M000_IG77:                ;; offset=0x0897
       cmp      byte  ptr [rbp+0xBC8], 0
       je       G_M000_IG366
       jmp      G_M000_IG359
 
G_M000_IG78:                ;; offset=0x08A9
       mov      r8, gword ptr [rbp+0xBC0]
       cmp      byte  ptr [r8+0xF9], 0
       je       G_M000_IG02
       jmp      G_M000_IG371
 
G_M000_IG79:                ;; offset=0x08C3
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG151
 
G_M000_IG80:                ;; offset=0x08D1
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r9d, eax
       mov      r8d, edi
       mov      rcx, rsi
       lea      rdx, [rbp+0xA88]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      esi, dword ptr [rcx+0x10]
       inc      esi
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      rdi, gword ptr [rdx+0x70]
       cmp      byte  ptr [rdx+0x101], 0
       jne      G_M000_IG346
       jmp      G_M000_IG343
 
G_M000_IG81:                ;; offset=0x0932
       test     r15d, r15d
       je       G_M000_IG356
       jmp      G_M000_IG347
 
G_M000_IG82:                ;; offset=0x0940
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rbx, gword ptr [rcx+0x08]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG462
       mov      ecx, eax
       shl      rcx, 4
       cmp      gword ptr [rbx+rcx+0x10], 0
       jne      G_M000_IG02
       jmp      G_M000_IG313
 
G_M000_IG83:                ;; offset=0x0978
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r9d, eax
       mov      r8d, esi
       mov      rcx, rbx
       lea      rdx, [rbp+0xB30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       G_M000_IG333
 
G_M000_IG84:                ;; offset=0x09C9
       lea      r9, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
 
G_M000_IG85:                ;; offset=0x09D1
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      rax, rdx
       test     rax, rax
       jne      SHORT G_M000_IG87
 
G_M000_IG86:                ;; offset=0x09E0
       mov      r10, gword ptr [rbp+0xBB8]
       mov      rax, r10
 
G_M000_IG87:                ;; offset=0x09EA
       mov      bword ptr [rbp-0x2A0], r9
       mov      dword ptr [rbp-0x298], r8d
 
G_M000_IG88:                ;; offset=0x09F8
       vmovdqu  xmm0, xmmword ptr [rbp+0xB30]
       vmovdqu  xmmword ptr [rbp-0x2B0], xmm0
 
G_M000_IG89:                ;; offset=0x0A08
       lea      rcx, [rbp-0x2A0]
       lea      r8, [rbp-0x2B0]
       mov      r9, gword ptr [rax+0x98]
       mov      rdx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG02
 
G_M000_IG90:                ;; offset=0x0A2F
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rax, gword ptr [rcx]
       mov      rbx, gword ptr [rax+0x30]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG462
       mov      ecx, eax
       mov      rdx, gword ptr [rbx+8*rcx+0x10]
       mov      rbx, rdx
       test     rbx, rbx
       je       SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x0A62
       mov      rcx, 0x7FF9D759EAB0
       cmp      qword ptr [rbx], rcx
       jne      G_M000_IG331
 
G_M000_IG92:                ;; offset=0x0A75
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rsi, gword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       sub      r14d, eax
       test     rsi, rsi
       jne      G_M000_IG97
 
G_M000_IG93:                ;; offset=0x0AB8
       or       edi, r14d
       jne      G_M000_IG332
       xor      rdx, rdx
       xor      ecx, ecx
 
G_M000_IG94:                ;; offset=0x0AC5
       mov      r8, bword ptr [rbp+0xB48]
       cmp      dword ptr [r8+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      rax, gword ptr [rbp+0xBC0]
       mov      r9, rax
       test     r9, r9
       jne      SHORT G_M000_IG96
 
G_M000_IG95:                ;; offset=0x0AE8
       mov      r10, gword ptr [rbp+0xBB8]
       mov      r9, r10
 
G_M000_IG96:                ;; offset=0x0AF2
       mov      bword ptr [rbp-0x2A0], rdx
       mov      dword ptr [rbp-0x298], ecx
       mov      rdx, bword ptr [rbp+0xB48]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x2A0]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      dword ptr [rcx+0x60], eax
       jmp      G_M000_IG02
 
G_M000_IG97:                ;; offset=0x0B3A
       mov      edx, edi
       mov      ecx, r14d
       add      rcx, rdx
       mov      r8d, dword ptr [rsi+0x08]
       cmp      rcx, r8
       ja       G_M000_IG332
       shl      rdx, 4
       lea      rdx, bword ptr [rsi+rdx+0x10]
       mov      ecx, r14d
       jmp      G_M000_IG94
 
G_M000_IG98:                ;; offset=0x0B60
       cmp      gword ptr [rbp+0xBC0], 0
       je       SHORT G_M000_IG100
 
G_M000_IG99:                ;; offset=0x0B6A
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      ebx, dword ptr [rcx+0x60]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      ebx, eax
       je       G_M000_IG397
 
G_M000_IG100:                ;; offset=0x0B89
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp+0xB48]
       mov      esi, dword ptr [rdx+0x10]
       mov      rdx, gword ptr [rbx]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG462
       mov      eax, esi
       shl      rax, 4
       lea      rdi, bword ptr [rdx+rax+0x10]
       mov      rdx, gword ptr [rdi]
       mov      rax, 0x27637001CE0
       cmp      rdx, gword ptr [rax]
       je       G_M000_IG182
 
G_M000_IG101:                ;; offset=0x0BCB
       mov      rdx, gword ptr [rdi]
       mov      rax, 0x27637001CE8
       cmp      rdx, gword ptr [rax]
       je       G_M000_IG181
 
G_M000_IG102:                ;; offset=0x0BE1
       cmp      qword ptr [rdi+0x08], 0
       jle      SHORT G_M000_IG107
 
G_M000_IG103:                ;; offset=0x0BE8
       mov      rdx, gword ptr [rdi]
       mov      rcx, 0x7FF9D7763360
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG107
 
G_M000_IG104:                ;; offset=0x0C03
       mov      r15d, dword ptr [rdi+0x08]
       dec      r15d
       mov      rdx, gword ptr [r14+0x08]
       mov      rcx, 0x7FF9D71628A8
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       jne      G_M000_IG180
 
G_M000_IG105:                ;; offset=0x0C27
       mov      rcx, r14
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.PyTuple:WritableValueSlot(int):byref:this]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishSharedInteger():System.Object:this]
 
G_M000_IG106:                ;; offset=0x0C3C
       mov      rcx, rdi
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
 
G_M000_IG107:                ;; offset=0x0C4D
       mov      r14, gword ptr [rdi]
 
G_M000_IG108:                ;; offset=0x0C50
       test     r14, r14
       je       G_M000_IG405
       mov      rdx, 0x7FF9D7848AB0
       cmp      qword ptr [r14], rdx
       jne      G_M000_IG183
 
G_M000_IG109:                ;; offset=0x0C6C
       mov      rbx, r14
       mov      eax, dword ptr [rbx+0x34]
       cmp      eax, dword ptr [rbx+0x30]
       jne      G_M000_IG192
 
G_M000_IG110:                ;; offset=0x0C7B
       xor      rbx, rbx
 
G_M000_IG111:                ;; offset=0x0C7D
       xor      esi, esi
 
G_M000_IG112:                ;; offset=0x0C7F
       test     rbx, rbx
       setne    r9b
       movzx    r9, r9b
       test     r9d, r9d
       jne      G_M000_IG205
 
G_M000_IG113:                ;; offset=0x0C93
       xor      rdx, rdx
       xor      r8d, r8d
 
G_M000_IG114:                ;; offset=0x0C98
       test     r9d, r9d
       je       G_M000_IG206
 
G_M000_IG115:                ;; offset=0x0CA1
       mov      gword ptr [rbp+0xAE8], rdx
       mov      qword ptr [rbp+0xAF0], r8
       lea      r9, [rbp+0xAE8]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r8, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG116:                ;; offset=0x0CD6
       movzx    rcx, byte  ptr [rbp+0xBC8]
       mov      dword ptr [rsp+0x20], ecx
       lea      rcx, [rbp+0xB20]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG151
 
G_M000_IG117:                ;; offset=0x0D17
       cmp      byte  ptr [rbp+0xBC8], 0
       jne      G_M000_IG338
 
G_M000_IG118:                ;; offset=0x0D24
       vmovdqu  xmm0, xmmword ptr [rbp+0xB20]
       vmovdqu  xmmword ptr [rbp+0xA98], xmm0
 
G_M000_IG119:                ;; offset=0x0D34
       mov      rsi, gword ptr [rbp+0xA98]
       test     rsi, rsi
       je       G_M000_IG02
       jmp      G_M000_IG334
 
G_M000_IG120:                ;; offset=0x0D49
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG151
 
G_M000_IG121:                ;; offset=0x0D57
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rax, gword ptr [rcx]
       mov      r12, gword ptr [rax+0x38]
       mov      rsi, r12
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      r10d, dword ptr [rsi+0x08]
       cmp      eax, r10d
       jae      G_M000_IG462
       mov      ecx, eax
       mov      rcx, gword ptr [rsi+8*rcx+0x10]
       mov      rdx, bword ptr [rbp+0xB48]
       mov      rdx, gword ptr [rdx]
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      rdx, rax
       lea      rcx, [rbp-0x210]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x210]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r8, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG122:                ;; offset=0x0DDD
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rsi, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rsi
       mov      r8, bword ptr [rbp+0xB48]
       mov      r8, gword ptr [r8]
       mov      r9, gword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdx, rax
       lea      rcx, [rbp-0x200]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x200]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r8, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG123:                ;; offset=0x0E47
       mov      rcx, bword ptr [rbp+0xBB0]
       cmp      gword ptr [rcx+0x40], 0
       jne      SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x0E55
       mov      r9, gword ptr [rbp+0xBB8]
       mov      gword ptr [rsp+0x20], r9
       mov      rcx, gword ptr [rcx]
       mov      rsi, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rsi+0x18]
       mov      r8d, dword ptr [rsi+0x10]
       mov      r9d, dword ptr [rsi+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG314
 
G_M000_IG125:                ;; offset=0x0E85
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      r8d, eax
       lea      r9, [rbp+0xB40]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, bword ptr [rbp+0xB48]
       mov      r9, gword ptr [r9]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      rcx, bword ptr [rbp+0xBB0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      G_M000_IG315
       jmp      G_M000_IG151
 
G_M000_IG126:                ;; offset=0x0ECC
       xor      rcx, rcx
       mov      gword ptr [rbp-0x290], rcx
       mov      rcx, gword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rcx+0x98]
       mov      rdx, gword ptr [rdx+0xE8]
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       mov      rdx, r14
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       je       SHORT G_M000_IG129
 
G_M000_IG127:                ;; offset=0x0EFD
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x290], rcx
       mov      ecx, 1
 
G_M000_IG128:                ;; offset=0x0F0C
       test     ecx, ecx
       jne      G_M000_IG226
       jmp      G_M000_IG440
 
G_M000_IG129:                ;; offset=0x0F19
       xor      rcx, rcx
       mov      gword ptr [rbp-0x290], rcx
 
G_M000_IG130:                ;; offset=0x0F22
       jmp      SHORT G_M000_IG128
 
G_M000_IG131:                ;; offset=0x0F24
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG462
       mov      edx, esi
       mov      rcx, gword ptr [rax+8*rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rdx, rax
       jmp      G_M000_IG227
 
G_M000_IG132:                ;; offset=0x0F42
       cmp      esi, r15d
       jae      G_M000_IG462
       mov      eax, esi
       shl      rax, 4
       add      rax, r14
       mov      rdx, gword ptr [rax]
       mov      r8, 0x27637001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG144
 
G_M000_IG133:                ;; offset=0x0F6A
       mov      rdx, gword ptr [rax]
       mov      r8, 0x27637001CE8
       cmp      rdx, gword ptr [r8]
       je       SHORT G_M000_IG143
 
G_M000_IG134:                ;; offset=0x0F7C
       cmp      qword ptr [rax+0x08], 0
       je       SHORT G_M000_IG142
 
G_M000_IG135:                ;; offset=0x0F83
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
 
G_M000_IG136:                ;; offset=0x0F8C
       mov      rcx, rax
       cmp      esi, dword ptr [rdi+0xD8]
       jge      SHORT G_M000_IG145
 
G_M000_IG137:                ;; offset=0x0F97
       test     rcx, rcx
       je       SHORT G_M000_IG140
 
G_M000_IG138:                ;; offset=0x0F9C
       mov      rax, 0x7FF9D77F4838
       cmp      qword ptr [rcx], rax
       jne      SHORT G_M000_IG140
 
G_M000_IG139:                ;; offset=0x0FAB
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      rcx, rax
 
G_M000_IG140:                ;; offset=0x0FB4
       test     rcx, rcx
       jne      SHORT G_M000_IG145
 
G_M000_IG141:                ;; offset=0x0FB9
       mov      rcx, rdi
       mov      edx, r13d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, esi
       mov      rcx, rdi
       mov      r9, gword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdx, rax
       jmp      G_M000_IG227
 
G_M000_IG142:                ;; offset=0x0FE5
       mov      rax, gword ptr [rax]
       jmp      SHORT G_M000_IG136
 
G_M000_IG143:                ;; offset=0x0FEA
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       jmp      SHORT G_M000_IG136
 
G_M000_IG144:                ;; offset=0x0FF5
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       jmp      SHORT G_M000_IG136
 
G_M000_IG145:                ;; offset=0x1000
       test     rcx, rcx
       je       G_M000_IG441
       mov      rdx, rcx
       jmp      G_M000_IG227
 
G_M000_IG146:                ;; offset=0x1011
       not      r8d
       jmp      G_M000_IG230
 
G_M000_IG147:                ;; offset=0x1019
       mov      r8, bword ptr [rbp+0xB48]
       mov      r8d, dword ptr [r8+0x14]
       jmp      G_M000_IG230
 
G_M000_IG148:                ;; offset=0x1029
       mov      r9d, ecx
       not      r9d
       jmp      G_M000_IG232
 
G_M000_IG149:                ;; offset=0x1034
       cmp      esi, 58
       ja       SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x1039
       mov      rcx, 0x1FDFFFFFFFFFFFF
       bt       rcx, rsi
       jae      G_M000_IG274
 
G_M000_IG151:                ;; offset=0x104D
       mov      dword ptr [rbp+0xAB8], 6
       jmp      G_M000_IG464
 
G_M000_IG152:                ;; offset=0x105C
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG462
       mov      ecx, r15d
       mov      rax, gword ptr [rax+8*rcx+0x10]
       jmp      G_M000_IG291
 
G_M000_IG153:                ;; offset=0x1073
       mov      rcx, 0x7FF9D7196D68
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       vmovsd   xmm0, qword ptr [rdi+0x08]
       vmovsd   qword ptr [r14+0x08], xmm0
       mov      rcx, rdi
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       jmp      G_M000_IG293
 
G_M000_IG154:                ;; offset=0x10A6
       mov      rcx, 0x7FF9D754B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rdx, qword ptr [rdi+0x08]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x288], xmm0
       lea      rcx, [rbp-0x288]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r14+0x08]
       mov      rdx, gword ptr [rbp-0x288]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x280]
       mov      dword ptr [r14+0x10], ecx
       mov      rcx, rdi
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       jmp      G_M000_IG293
 
G_M000_IG155:                ;; offset=0x1105
       mov      edx, edi
       mov      rcx, 0x7FF9D72800F0
       call     CORINFO_HELP_NEWARR_1_VC
       mov      rdx, rax
       mov      rax, gword ptr [rbp-0x310]
       lea      rcx, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG199
 
G_M000_IG156:                ;; offset=0x112E
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG202
 
G_M000_IG157:                ;; offset=0x1140
       mov      rdx, gword ptr [rbp-0x308]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      r10, gword ptr [rbp-0x300]
 
G_M000_IG158:                ;; offset=0x1154
       mov      r8d, dword ptr [rbp-0x274]
       mov      r9d, r12d
       sub      r9d, r8d
       cmp      r9d, 0x1000
       jl       G_M000_IG203
 
G_M000_IG159:                ;; offset=0x116E
       mov      r11d, 0x1000
 
G_M000_IG160:                ;; offset=0x1174
       lea      ecx, [rsi+r8]
       mov      edx, ecx
       mov      r9d, r11d
       add      rdx, r9
       mov      r9d, r13d
       cmp      rdx, r9
       ja       G_M000_IG332
       mov      edx, ecx
       add      rdx, r15
       mov      ecx, r8d
       mov      r9d, r11d
       add      rcx, r9
       mov      r9d, r12d
       cmp      rcx, r9
       ja       G_M000_IG332
       mov      dword ptr [rbp-0x274], r8d
       mov      ecx, r8d
       add      rcx, bword ptr [rbp-0x318]
       mov      dword ptr [rbp-0x278], r11d
       mov      r8d, r11d
       call     [System.SpanHelpers:Memmove(byref,byref,nuint)]
       mov      r8d, dword ptr [rbp-0x278]
       add      r8d, dword ptr [rbp-0x274]
       mov      ecx, r8d
       cmp      ecx, r12d
       mov      dword ptr [rbp-0x274], ecx
       jge      G_M000_IG200
 
G_M000_IG161:                ;; offset=0x11E7
       mov      r10, gword ptr [rbp-0x300]
       test     r10, r10
       je       G_M000_IG158
 
G_M000_IG162:                ;; offset=0x11F7
       mov      rcx, gword ptr [r10+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG157
 
G_M000_IG163:                ;; offset=0x1210
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG156
 
G_M000_IG164:                ;; offset=0x1220
       mov      r10, gword ptr [rbp-0x300]
       jmp      G_M000_IG158
 
G_M000_IG165:                ;; offset=0x122C
       xor      r14, r14
       xor      r15d, r15d
       jmp      G_M000_IG209
 
G_M000_IG166:                ;; offset=0x1237
       mov      rcx, r12
       jmp      G_M000_IG213
 
G_M000_IG167:                ;; offset=0x123F
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG100
 
G_M000_IG168:                ;; offset=0x1269
       mov      dword ptr [rbp+0xB5C], 1
       jmp      G_M000_IG02
 
G_M000_IG169:                ;; offset=0x1278
       mov      rax, gword ptr [rbp+0xBC0]
       mov      r9, rax
       test     r9, r9
       jne      SHORT G_M000_IG171
 
G_M000_IG170:                ;; offset=0x1287
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r9, rdx
 
G_M000_IG171:                ;; offset=0x1291
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, rax
       mov      r8, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG02
 
G_M000_IG172:                ;; offset=0x12B0
       movzx    rax, byte  ptr [rbp+0xBC8]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r9, gword ptr [rbp+0xBB8]
       test     rdx, rdx
       je       G_M000_IG151
 
G_M000_IG173:                ;; offset=0x12D5
       test     al, al
       jne      SHORT G_M000_IG177
 
G_M000_IG174:                ;; offset=0x12D9
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG175:                ;; offset=0x12E0
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG176:                ;; offset=0x12ED
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp+0xAA8]
       mov      rcx, gword ptr [rbp+0xBC0]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rbx, gword ptr [rbp+0xAA8]
       test     rbx, rbx
       je       G_M000_IG02
       jmp      G_M000_IG324
 
G_M000_IG177:                ;; offset=0x1320
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG178:                ;; offset=0x1327
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG179:                ;; offset=0x1334
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0x80]
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x90]
       lea      rdx, [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0x90]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x88]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG266
       jmp      G_M000_IG328
 
G_M000_IG180:                ;; offset=0x139F
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG462
       mov      ecx, r15d
       mov      rax, gword ptr [rax+8*rcx+0x10]
       jmp      G_M000_IG106
 
G_M000_IG181:                ;; offset=0x13B6
       mov      rcx, 0x7FF9D7196D68
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       vmovsd   xmm0, qword ptr [rdi+0x08]
       vmovsd   qword ptr [r14+0x08], xmm0
       mov      rcx, rdi
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       jmp      G_M000_IG108
 
G_M000_IG182:                ;; offset=0x13E9
       mov      rcx, 0x7FF9D754B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rdx, qword ptr [rdi+0x08]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x260], xmm0
       lea      rcx, [rbp-0x260]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r14+0x08]
       mov      rdx, gword ptr [rbp-0x260]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x258]
       mov      dword ptr [r14+0x10], ecx
       mov      rcx, rdi
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      edx, edx
       mov      qword ptr [rdi+0x08], rdx
       jmp      G_M000_IG108
 
G_M000_IG183:                ;; offset=0x1448
       mov      rdx, 0x7FF9D77FA4F0
       cmp      qword ptr [r14], rdx
       je       SHORT G_M000_IG190
 
G_M000_IG184:                ;; offset=0x1457
       mov      rdx, r14
       mov      rcx, 0x7FF9D7763360
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG190
 
G_M000_IG185:                ;; offset=0x146F
       mov      rcx, 0x7FF9D7848D18
       cmp      qword ptr [r14], rcx
       je       SHORT G_M000_IG189
 
G_M000_IG186:                ;; offset=0x147E
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG151
 
G_M000_IG187:                ;; offset=0x148C
       cmp      byte  ptr [rbp+0xBC8], 0
       jne      G_M000_IG411
 
G_M000_IG188:                ;; offset=0x1499
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      rdx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp+0xB5C], eax
       jmp      G_M000_IG02
 
G_M000_IG189:                ;; offset=0x14B8
       mov      rcx, r14
       lea      rdx, [rbp-0x250]
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG191
 
G_M000_IG190:                ;; offset=0x14CA
       mov      r8, gword ptr [rbx+0x08]
       sub      esi, dword ptr [rbx+0x38]
       cmp      esi, dword ptr [r8+0x08]
       jae      G_M000_IG462
       mov      edx, esi
       lea      r8, bword ptr [r8+4*rdx+0x10]
       lea      rcx, [rbp-0x250]
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.PyIteration:AdvanceBuiltinSequence(System.Object,byref):Lokad.Lython.Runtime.PyIterationResult]
 
G_M000_IG191:                ;; offset=0x14F2
       mov      rbx, gword ptr [rbp-0x250]
       mov      rsi, qword ptr [rbp-0x248]
       jmp      G_M000_IG112
 
G_M000_IG192:                ;; offset=0x1505
       mov      rax, gword ptr [rbx+0x10]
       test     rax, rax
       je       G_M000_IG406
 
G_M000_IG193:                ;; offset=0x1512
       lea      rdx, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG194:                ;; offset=0x1519
       lea      r8, bword ptr [rbx+0x34]
       mov      esi, dword ptr [r8]
       add      esi, 4
       mov      r10d, dword ptr [r8]
       cmp      r10d, eax
       ja       G_M000_IG332
       mov      r9d, r10d
       add      rdx, r9
       sub      eax, r10d
       cmp      eax, 4
       jl       G_M000_IG407
       mov      edi, dword ptr [rdx]
       lea      eax, [rsi+rdi]
       mov      dword ptr [r8], eax
       movsxd   r14, edi
       add      r14, 128
       cmp      r14, qword ptr [rbx+0x28]
       jg       G_M000_IG408
       mov      rax, gword ptr [rbx+0x10]
       test     rax, rax
       je       G_M000_IG409
       lea      r15, bword ptr [rax+0x10]
       mov      r13d, dword ptr [rax+0x08]
 
G_M000_IG195:                ;; offset=0x1572
       mov      r12, gword ptr [rbx+0x08]
       mov      rax, gword ptr [rbx+0x20]
       mov      gword ptr [rbp-0x308], rax
       mov      rdx, gword ptr [rbx+0x18]
       mov      gword ptr [rbp-0x300], rdx
       test     edi, edi
       je       G_M000_IG204
 
G_M000_IG196:                ;; offset=0x1594
       mov      rcx, 0x7FF9D75C1030
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x310], rax
       mov      dword ptr [rax+0x1C], -1
       test     edi, edi
       jl       G_M000_IG410
 
G_M000_IG197:                ;; offset=0x15B9
       cmp      edi, 8
       jg       G_M000_IG155
 
G_M000_IG198:                ;; offset=0x15C2
       mov      byte  ptr [rax+0x24], dil
 
G_M000_IG199:                ;; offset=0x15C6
       mov      rax, gword ptr [rbp-0x310]
       mov      dword ptr [rax+0x18], edi
       lea      rcx, bword ptr [rax+0x10]
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, gword ptr [rbp-0x310]
       lea      rdx, [rbp-0x270]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.Text.PyString:get_UnpublishedUtf8():System.Span`1[byte]:this]
       mov      r12d, dword ptr [rbp-0x268]
       mov      rax, bword ptr [rbp-0x270]
       mov      bword ptr [rbp-0x318], rax
       xor      r8d, r8d
       mov      dword ptr [rbp-0x274], r8d
       cmp      r8d, r12d
       jl       G_M000_IG161
 
G_M000_IG200:                ;; offset=0x161B
       mov      rcx, rdi
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.Text.PyString:CompleteUnpublishedUtf8(int):this]
 
G_M000_IG201:                ;; offset=0x1627
       sub      qword ptr [rbx+0x28], r14
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rbx, rax
       jmp      G_M000_IG111
 
G_M000_IG202:                ;; offset=0x163C
       mov      r10, gword ptr [rbp-0x300]
       jmp      G_M000_IG158
 
G_M000_IG203:                ;; offset=0x1648
       mov      r11d, r9d
       jmp      G_M000_IG160
 
G_M000_IG204:                ;; offset=0x1650
       mov      rax, 0x27637000F78
       mov      rdi, gword ptr [rax]
       jmp      SHORT G_M000_IG201
 
G_M000_IG205:                ;; offset=0x165F
       mov      rdx, rbx
       mov      r8, rsi
       jmp      G_M000_IG114
 
G_M000_IG206:                ;; offset=0x166A
       mov      rcx, bword ptr [rbp+0xBB0]
       add      rcx, 32
       mov      rdx, bword ptr [rbp+0xB48]
       mov      edx, dword ptr [rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      dword ptr [rcx+0x10], eax
       jmp      G_M000_IG168
 
G_M000_IG207:                ;; offset=0x16A1
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      esi, dword ptr [rax+0x10]
       mov      rdi, gword ptr [rcx]
       mov      rax, gword ptr [rcx+0x20]
       test     rax, rax
       je       G_M000_IG165
 
G_M000_IG208:                ;; offset=0x16C6
       lea      r14, bword ptr [rax+0x10]
       mov      r15d, dword ptr [rax+0x08]
 
G_M000_IG209:                ;; offset=0x16CE
       mov      r13d, dword ptr [rcx+0x10]
       xor      rax, rax
       mov      gword ptr [rbp-0x290], rax
       test     esi, esi
       jge      G_M000_IG132
 
G_M000_IG210:                ;; offset=0x16E3
       not      esi
       mov      rax, gword ptr [rdi+0x30]
       cmp      dword ptr [rax+0x08], esi
       jg       G_M000_IG131
 
G_M000_IG211:                ;; offset=0x16F2
       mov      r12, gword ptr [rdi+0x38]
       mov      rdx, r12
       mov      r8d, esi
       sub      r8d, dword ptr [rax+0x08]
       mov      r10d, dword ptr [rdx+0x08]
       cmp      r8d, r10d
       jae      G_M000_IG462
       mov      r15, gword ptr [rdx+8*r8+0x10]
       sub      esi, dword ptr [rax+0x08]
       cmp      esi, r10d
       jae      G_M000_IG462
       mov      eax, esi
       mov      r14, gword ptr [r12+8*rax+0x10]
       mov      rcx, gword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      r12, rax
       cmp      byte  ptr [r12+0xFE], 0
       jne      G_M000_IG166
 
G_M000_IG212:                ;; offset=0x1744
       xor      rcx, rcx
 
G_M000_IG213:                ;; offset=0x1746
       test     rcx, rcx
       je       SHORT G_M000_IG219
 
G_M000_IG214:                ;; offset=0x174B
       mov      rdx, gword ptr [rcx+0x118]
       cmp      rdx, gword ptr [rdi+0x40]
       jne      SHORT G_M000_IG218
 
G_M000_IG215:                ;; offset=0x1758
       mov      rdx, gword ptr [rdi+0x48]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG462
       mov      eax, esi
       mov      edx, dword ptr [rdx+4*rax+0x10]
       test     edx, edx
       jl       SHORT G_M000_IG219
 
G_M000_IG216:                ;; offset=0x176F
       mov      rcx, gword ptr [rcx+0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadLocalValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):System.Object]
       test     rax, rax
       je       SHORT G_M000_IG219
 
G_M000_IG217:                ;; offset=0x1781
       mov      gword ptr [rbp-0x290], rax
       jmp      G_M000_IG226
 
G_M000_IG218:                ;; offset=0x178D
       lea      r8, [rbp-0x290]
       mov      rdx, r14
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryResolveLocalOrClosure(System.String,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG226
 
G_M000_IG219:                ;; offset=0x17A7
       mov      rcx, gword ptr [r12+0x08]
       test     rcx, rcx
       jne      SHORT G_M000_IG224
 
G_M000_IG220:                ;; offset=0x17B1
       mov      rcx, 0x7FF9D71ADDF0
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      rcx, 0x27637000068
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x320], rax
       mov      rdx, rax
       lea      rcx, bword ptr [rsi+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, gword ptr [rbp-0x320]
       call     [System.Collections.Generic.NonRandomizedStringEqualityComparer:GetStringComparer(System.Object):System.Collections.Generic.IEqualityComparer`1[System.String]]
       test     rax, rax
       je       SHORT G_M000_IG222
 
G_M000_IG221:                ;; offset=0x17F5
       lea      rcx, bword ptr [rsi+0x18]
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG222:                ;; offset=0x1801
       lea      rcx, bword ptr [r12+0x08]
       test     rcx, rcx
       je       G_M000_IG311
       mov      rdx, rsi
       xor      r8, r8
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       mov      rcx, rax
       test     rcx, rcx
       jne      SHORT G_M000_IG224
 
G_M000_IG223:                ;; offset=0x1822
       mov      rcx, rsi
 
G_M000_IG224:                ;; offset=0x1825
       cmp      byte  ptr [rcx], cl
       mov      rdx, r14
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       je       G_M000_IG126
 
G_M000_IG225:                ;; offset=0x1839
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x290], rcx
 
G_M000_IG226:                ;; offset=0x1843
       mov      rdx, gword ptr [rbp-0x290]
 
G_M000_IG227:                ;; offset=0x184A
       xor      rcx, rcx
       mov      gword ptr [rbp-0x290], rcx
       mov      rcx, bword ptr [rbp+0xB48]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       G_M000_IG147
 
G_M000_IG228:                ;; offset=0x1866
       mov      r8, 0x7FFFFFFFFF9FF
       bt       r8, rcx
       jb       G_M000_IG147
 
G_M000_IG229:                ;; offset=0x187A
       mov      rcx, bword ptr [rbp+0xB48]
       mov      r8d, dword ptr [rcx+0x18]
       test     r8d, r8d
       jl       G_M000_IG146
 
G_M000_IG230:                ;; offset=0x188E
       mov      rcx, bword ptr [rbp+0xB48]
       mov      ecx, dword ptr [rcx+0x18]
       test     ecx, ecx
       jl       G_M000_IG148
 
G_M000_IG231:                ;; offset=0x18A0
       mov      r9d, ecx
 
G_M000_IG232:                ;; offset=0x18A3
       mov      rcx, bword ptr [rbp+0xB48]
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      G_M000_IG02
 
G_M000_IG233:                ;; offset=0x18C3
       movzx    rax, byte  ptr [rbp+0xBC8]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r9, gword ptr [rbp+0xBB8]
       test     rdx, rdx
       je       G_M000_IG151
 
G_M000_IG234:                ;; offset=0x18E8
       test     al, al
       jne      G_M000_IG442
 
G_M000_IG235:                ;; offset=0x18F0
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      rcx, rdx
       mov      rdx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG02
 
G_M000_IG236:                ;; offset=0x190C
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG151
 
G_M000_IG237:                ;; offset=0x191A
       cmp      byte  ptr [rbp+0xBC8], 0
       jne      G_M000_IG390
       jmp      SHORT G_M000_IG240
 
G_M000_IG238:                ;; offset=0x1929
       mov      rcx, bword ptr [rbp+0xBD0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp+0xB5C], eax
       jmp      G_M000_IG02
 
G_M000_IG239:                ;; offset=0x1941
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG151
 
G_M000_IG240:                ;; offset=0x194F
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      rdx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp+0xB5C], eax
       jmp      G_M000_IG02
 
G_M000_IG241:                ;; offset=0x196E
       cmp      gword ptr [rbp+0xBC0], 0
       je       SHORT G_M000_IG244
 
G_M000_IG242:                ;; offset=0x1978
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      rdx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG244
 
G_M000_IG243:                ;; offset=0x1990
       mov      dword ptr [rbp+0xAB8], 1
       jmp      G_M000_IG464
 
G_M000_IG244:                ;; offset=0x199F
       mov      rbx, bword ptr [rbp+0xBE8]
       mov      r8d, dword ptr [rbx+0x08]
       test     r8d, r8d
       jne      G_M000_IG387
 
G_M000_IG245:                ;; offset=0x19B3
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      gword ptr [rsp+0x20], rdx
       mov      edx, edi
       mov      rcx, rsi
       mov      r9, bword ptr [rbp+0xB48]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       lea      rcx, [rbp-0x240]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x240]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r8, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG246:                ;; offset=0x1A30
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      gword ptr [rsp+0x20], rdx
       mov      edx, edi
       mov      rcx, rsi
       mov      r9, bword ptr [rbp+0xB48]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      rdx, rax
       lea      rcx, [rbp-0x230]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x230]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r8, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG247:                ;; offset=0x1AAD
       mov      rdx, bword ptr [rbp+0xB48]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xBB0]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG02
 
G_M000_IG248:                ;; offset=0x1AF0
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      edi, [rax+0x01]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       mov      rdx, bword ptr [rbp+0xB48]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xBB0]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rdx, rax
       lea      rcx, [rbp-0x220]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x220]
       mov      rcx, rsi
       mov      edx, edi
       mov      r8d, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG02
 
G_M000_IG249:                ;; offset=0x1B60
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG151
 
G_M000_IG250:                ;; offset=0x1B6E
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rsi, gword ptr [rcx]
       mov      rdi, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rcx]
       mov      r12, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      r10d, dword ptr [r12+0x08]
       cmp      eax, r10d
       jae      G_M000_IG462
       mov      ecx, eax
       mov      r14, gword ptr [r12+8*rcx+0x10]
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      r15, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      r13d, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
       mov      edx, r13d
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      gword ptr [rsp+0x20], rdx
       mov      r8, bword ptr [rbp+0xB48]
       mov      r8, gword ptr [r8]
       mov      gword ptr [rsp+0x28], r8
       mov      r8, r14
       mov      rcx, rsi
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG251:                ;; offset=0x1C09
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG151
 
G_M000_IG252:                ;; offset=0x1C17
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rax, gword ptr [rcx]
       mov      r12, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      r10d, dword ptr [r12+0x08]
       cmp      eax, r10d
       jae      G_M000_IG462
       mov      ecx, eax
       mov      rsi, gword ptr [r12+8*rcx+0x10]
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      r14d, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
       mov      edx, r14d
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rdx, rax
       mov      rcx, rsi
       mov      r9, bword ptr [rbp+0xB48]
       mov      r9, gword ptr [r9]
       mov      r8, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG253:                ;; offset=0x1C9B
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r8, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
       jmp      G_M000_IG151
 
G_M000_IG254:                ;; offset=0x1CC3
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG02
 
G_M000_IG255:                ;; offset=0x1CEA
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG151
 
G_M000_IG256:                ;; offset=0x1CF8
       mov      rdx, bword ptr [rbp+0xB48]
       mov      rdx, gword ptr [rdx]
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG257:                ;; offset=0x1D14
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
       jmp      G_M000_IG378
 
G_M000_IG258:                ;; offset=0x1D43
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG151
 
G_M000_IG259:                ;; offset=0x1D51
       cmp      byte  ptr [rbp+0xBC8], 0
       jne      SHORT G_M000_IG263
 
G_M000_IG260:                ;; offset=0x1D5A
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG261:                ;; offset=0x1D61
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG262:                ;; offset=0x1D6E
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp+0xAA8]
       mov      rcx, gword ptr [rbp+0xBC0]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rsi, gword ptr [rbp+0xAA8]
       test     rsi, rsi
       je       G_M000_IG02
       jmp      G_M000_IG316
 
G_M000_IG263:                ;; offset=0x1DA1
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG264:                ;; offset=0x1DA8
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG265:                ;; offset=0x1DB5
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0x160]
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x170]
       lea      rdx, [rbp-0x160]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0x170]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x168]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       jne      G_M000_IG320
 
G_M000_IG266:                ;; offset=0x1E21
       mov      rcx, bword ptr [rbp+0xBD0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG02
 
G_M000_IG267:                ;; offset=0x1E33
       movzx    rcx, byte  ptr [rbp+0xBC8]
       mov      dword ptr [rsp+0x20], ecx
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      bword ptr [rsp+0x28], rcx
       mov      rax, bword ptr [rbp+0xBD8]
       mov      bword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       test     eax, eax
       je       G_M000_IG238
 
G_M000_IG268:                ;; offset=0x1E80
       mov      dword ptr [rbp+0xAB8], eax
       jmp      G_M000_IG464
 
G_M000_IG269:                ;; offset=0x1E8B
       mov      rdx, bword ptr [rbp+0xB48]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      r8, gword ptr [rbp+0xBB8]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      rbx, rax
       cmp      gword ptr [rbp+0xBC0], 0
       jne      SHORT G_M000_IG271
 
G_M000_IG270:                ;; offset=0x1EB9
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG151
 
G_M000_IG271:                ;; offset=0x1ECA
       cmp      byte  ptr [rbp+0xBC8], 0
       jne      G_M000_IG454
 
G_M000_IG272:                ;; offset=0x1ED7
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp+0xB5C], eax
       jmp      G_M000_IG02
 
G_M000_IG273:                ;; offset=0x1F04
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG149
 
G_M000_IG274:                ;; offset=0x1F12
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp+0xB5C], eax
       mov      rcx, bword ptr [rbp+0xBB0]
       cmp      gword ptr [rcx+0x68], 0
       je       G_M000_IG02
 
G_M000_IG275:                ;; offset=0x1F4C
       movzx    rax, byte  ptr [rbp+0xBC8]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r9, gword ptr [rbp+0xBB8]
       test     al, al
       je       G_M000_IG243
 
G_M000_IG276:                ;; offset=0x1F69
       cmp      gword ptr [rcx+0x40], 0
       je       G_M000_IG243
 
G_M000_IG277:                ;; offset=0x1F74
       xor      r8, r8
       mov      r10, bword ptr [rbp+0xBD0]
       mov      gword ptr [r10], r8
       mov      word  ptr [r10+0x08], 0
       movzx    r8, byte  ptr [rbp+0xB5C]
       mov      byte  ptr [r10+0x0A], r8b
       mov      byte  ptr [r10+0x0B], 1
       mov      dword ptr [rbp+0xAB8], 5
       jmp      G_M000_IG464
 
G_M000_IG278:                ;; offset=0x1FA8
       mov      r9, gword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG283
       jmp      G_M000_IG02
 
G_M000_IG279:                ;; offset=0x1FD6
       cmp      gword ptr [rbp+0xBC0], 0
       jne      G_M000_IG235
       jmp      G_M000_IG151
 
G_M000_IG280:                ;; offset=0x1FE9
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG151
 
G_M000_IG281:                ;; offset=0x1FF7
       cmp      byte  ptr [rbp+0xBC8], 0
       jne      G_M000_IG448
       jmp      G_M000_IG235
 
G_M000_IG282:                ;; offset=0x2009
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
 
G_M000_IG283:                ;; offset=0x2033
       movzx    rcx, byte  ptr [rbp+0xBC8]
       mov      dword ptr [rsp+0x20], ecx
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      bword ptr [rsp+0x28], rcx
       mov      rax, bword ptr [rbp+0xBD8]
       mov      bword ptr [rsp+0x30], rax
       mov      r8, bword ptr [rbp+0xBE0]
       mov      bword ptr [rsp+0x38], r8
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       test     eax, eax
       je       G_M000_IG02
       jmp      G_M000_IG396
 
G_M000_IG284:                ;; offset=0x2091
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rax, gword ptr [rcx]
       mov      rax, gword ptr [rax+0xB0]
       mov      rdx, bword ptr [rbp+0xB48]
       mov      edx, dword ptr [rdx+0x08]
       mov      r8, 0x7FF9D7648660
       cmp      qword ptr [rax], r8
       jne      G_M000_IG418
       cmp      dword ptr [rax+0x08], edx
       jbe      G_M000_IG417
       mov      rbx, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG285:                ;; offset=0x20CD
       mov      rdx, bword ptr [rbp+0xB48]
       mov      esi, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rdx, bword ptr [rcx+0x20]
       cmp      byte  ptr [rbx], bl
       mov      rdx, gword ptr [rdx]
       cmp      byte  ptr [rbx+0x30], 0
       setne    al
       movzx    rax, al
       add      eax, esi
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG462
       shl      rax, 4
       lea      rdi, bword ptr [rdx+rax+0x10]
       mov      rdx, gword ptr [rdi]
       mov      rax, 0x27637001CE0
       cmp      rdx, gword ptr [rax]
       je       G_M000_IG154
 
G_M000_IG286:                ;; offset=0x211B
       mov      rdx, gword ptr [rdi]
       mov      rax, 0x27637001CE8
       cmp      rdx, gword ptr [rax]
       je       G_M000_IG153
 
G_M000_IG287:                ;; offset=0x2131
       cmp      qword ptr [rdi+0x08], 0
       jle      SHORT G_M000_IG292
 
G_M000_IG288:                ;; offset=0x2138
       mov      rdx, gword ptr [rdi]
       mov      rcx, 0x7FF9D7763360
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG292
 
G_M000_IG289:                ;; offset=0x2153
       mov      r15d, dword ptr [rdi+0x08]
       dec      r15d
       mov      rdx, gword ptr [r14+0x08]
       mov      rcx, 0x7FF9D71628A8
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       jne      G_M000_IG152
 
G_M000_IG290:                ;; offset=0x2177
       mov      rcx, r14
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.PyTuple:WritableValueSlot(int):byref:this]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishSharedInteger():System.Object:this]
 
G_M000_IG291:                ;; offset=0x218C
       mov      rcx, rdi
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
 
G_M000_IG292:                ;; offset=0x219D
       mov      r14, gword ptr [rdi]
 
G_M000_IG293:                ;; offset=0x21A0
       test     r14, r14
       je       G_M000_IG419
       mov      dword ptr [rsp+0x20], esi
       mov      gword ptr [rsp+0x28], r14
       lea      rdx, [rbp+0xAC8]
       mov      qword ptr [rsp+0x30], rdx
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG299
 
G_M000_IG294:                ;; offset=0x21E4
       cmp      gword ptr [rbp+0xAC8], 0
       je       G_M000_IG02
 
G_M000_IG295:                ;; offset=0x21F2
       mov      rdx, gword ptr [rbp+0xAC8]
       mov      rcx, 0x7FF9D7500AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      rdi, rax
       test     rdi, rdi
       jne      G_M000_IG471
 
G_M000_IG296:                ;; offset=0x2215
       mov      rdx, gword ptr [rbp+0xAC8]
       mov      rax, rdx
       test     rax, rax
       je       SHORT G_M000_IG298
 
G_M000_IG297:                ;; offset=0x2224
       mov      rcx, 0x7FF9D76B6708
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG420
 
G_M000_IG298:                ;; offset=0x2237
       xor      rcx, rcx
       mov      r8, bword ptr [rbp+0xBE0]
       mov      gword ptr [r8], rcx
       lea      rcx, bword ptr [r8+0x08]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r8, bword ptr [rbp+0xBE0]
       mov      word  ptr [r8+0x10], 0
       mov      byte  ptr [r8+0x12], 1
       jmp      SHORT G_M000_IG305
 
G_M000_IG299:                ;; offset=0x2264
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG421
 
G_M000_IG300:                ;; offset=0x2272
       movzx    rcx, byte  ptr [rbp+0xBC8]
       mov      dword ptr [rsp+0x20], ecx
       mov      r8, bword ptr [rbp+0xBE0]
       mov      bword ptr [rsp+0x28], r8
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      rdx, rbx
       mov      r8d, esi
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG306
 
G_M000_IG301:                ;; offset=0x22A3
       mov      r8, bword ptr [rbp+0xBE0]
       mov      r14, gword ptr [r8]
       test     r14, r14
       jne      G_M000_IG424
 
G_M000_IG302:                ;; offset=0x22B6
       mov      r8, bword ptr [rbp+0xBE0]
       mov      rsi, gword ptr [r8]
       test     rsi, rsi
       jne      G_M000_IG427
 
G_M000_IG303:                ;; offset=0x22C9
       mov      rdi, gword ptr [r8+0x08]
 
G_M000_IG304:                ;; offset=0x22CD
       mov      rcx, gword ptr [rbp+0xBC0]
       cmp      rdi, rcx
       je       G_M000_IG431
 
G_M000_IG305:                ;; offset=0x22DD
       mov      rdx, gword ptr [rbx+0x18]
       mov      rcx, bword ptr [rbp+0xBD8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp+0xAB8], 3
       jmp      G_M000_IG464
 
G_M000_IG306:                ;; offset=0x22FC
       cmp      byte  ptr [rbp+0xBC8], 0
       jne      G_M000_IG436
 
G_M000_IG307:                ;; offset=0x2309
       mov      gword ptr [rsp+0x20], r14
       xor      edx, edx
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp+0xAA8]
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       mov      r14, gword ptr [rbp+0xAA8]
       test     r14, r14
       je       G_M000_IG02
       jmp      G_M000_IG432
 
G_M000_IG308:                ;; offset=0x2343
       mov      rcx, bword ptr [rbp+0xB48]
       mov      rdx, 0x2965DB6E048
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG309:                ;; offset=0x2363
       mov      rcx, 0x7FF9D72CE510
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rcx, r15
       call     [System.IndexOutOfRangeException:.ctor():this]
       mov      rcx, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG310:                ;; offset=0x2387
       mov      rdx, r12
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG311:                ;; offset=0x2391
       call     [System.ThrowHelper:ThrowNullReferenceException()]
       int3     
 
G_M000_IG312:                ;; offset=0x2398
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rcx, r15
       mov      rdx, 0x2965DB6AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG313:                ;; offset=0x23C6
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      r8, gword ptr [rcx]
       mov      rbx, gword ptr [r8+0x68]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A1CE0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, bword ptr [rbp+0xB48]
       mov      rdx, gword ptr [rdx]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG314:                ;; offset=0x240F
       add      dword ptr [rsi+0x10], 2
       jmp      G_M000_IG02
 
G_M000_IG315:                ;; offset=0x2418
       mov      rdx, gword ptr [rbp+0xB40]
       lea      rcx, [rbp-0x1F0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x1F0]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r8, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG316:                ;; offset=0x2453
       mov      rdx, rsi
       mov      rcx, 0x7FF9D74947C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG319
 
G_M000_IG317:                ;; offset=0x246B
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
 
G_M000_IG318:                ;; offset=0x2480
       mov      r8, rax
       mov      rcx, r8
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG319:                ;; offset=0x2493
       mov      rcx, rsi
       movsx    rdx, word  ptr [rbp+0xAB0]
       mov      r11, 0x7FF9D70A1D00
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG320:                ;; offset=0x24B0
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG321
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG322
 
G_M000_IG321:                ;; offset=0x24D9
       mov      rcx, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A1D08
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG322:                ;; offset=0x24FF
       test     edi, edi
       jne      G_M000_IG266
 
G_M000_IG323:                ;; offset=0x2507
       mov      rcx, bword ptr [rbp+0xB48]
       mov      rdx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0xBD8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp+0xAB8], 4
       jmp      G_M000_IG464
 
G_M000_IG324:                ;; offset=0x252C
       mov      rdx, rbx
       mov      rcx, 0x7FF9D74947C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG327
 
G_M000_IG325:                ;; offset=0x2544
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
 
G_M000_IG326:                ;; offset=0x2559
       mov      r8, rax
       mov      rcx, r8
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG327:                ;; offset=0x256C
       mov      rcx, rbx
       movsx    rdx, word  ptr [rbp+0xAB0]
       mov      r11, 0x7FF9D70A1D10
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG328:                ;; offset=0x2589
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG329
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG330
 
G_M000_IG329:                ;; offset=0x25B2
       mov      rcx, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A1D18
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG330:                ;; offset=0x25D8
       test     esi, esi
       jne      G_M000_IG266
       jmp      G_M000_IG323
 
G_M000_IG331:                ;; offset=0x25E5
       mov      rax, rcx
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG332:                ;; offset=0x25EF
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG333:                ;; offset=0x25F6
       xor      r9, r9
       xor      r8d, r8d
       jmp      G_M000_IG85
 
G_M000_IG334:                ;; offset=0x2601
       mov      rdx, rsi
       mov      rcx, 0x7FF9D74947C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG337
 
G_M000_IG335:                ;; offset=0x2619
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
 
G_M000_IG336:                ;; offset=0x262E
       mov      r8, rax
       mov      rcx, r8
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG337:                ;; offset=0x2641
       mov      rcx, rsi
       movsx    rdx, word  ptr [rbp+0xAA0]
       mov      r11, 0x7FF9D70A1D20
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG338:                ;; offset=0x265E
       vmovdqu  xmm0, xmmword ptr [rbp+0xB20]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG339:                ;; offset=0x266E
       lea      rdx, [rbp-0x2E0]
       lea      rcx, [rbp-0x180]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0x180]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x178]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       je       G_M000_IG266
 
G_M000_IG340:                ;; offset=0x26B9
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG341
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG342
 
G_M000_IG341:                ;; offset=0x26E2
       mov      rcx, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A1D28
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG342:                ;; offset=0x2708
       test     edi, edi
       jne      G_M000_IG266
       jmp      G_M000_IG323
 
G_M000_IG343:                ;; offset=0x2715
       cmp      byte  ptr [rdx+0xFF], 0
       jne      SHORT G_M000_IG346
 
G_M000_IG344:                ;; offset=0x271E
       cmp      ebx, esi
       jle      SHORT G_M000_IG346
 
G_M000_IG345:                ;; offset=0x2722
       cmp      esi, ebx
       jae      G_M000_IG462
       mov      r8, gword ptr [rbp+0xB60]
       mov      r14d, esi
       shl      r14, 5
       cmp      dword ptr [r8+r14+0x2C], 30
       sete     r15b
       movzx    r15, r15b
       mov      rdx, gword ptr [rbp+0xBC0]
       jmp      G_M000_IG81
 
G_M000_IG346:                ;; offset=0x2752
       mov      rdx, gword ptr [rbp+0xBC0]
       xor      r15d, r15d
       jmp      G_M000_IG81
 
G_M000_IG347:                ;; offset=0x2761
       test     rdi, rdi
       je       G_M000_IG356
 
G_M000_IG348:                ;; offset=0x276A
       vmovdqu  xmm0, xmmword ptr [rbp+0xA88]
       vmovdqu  xmmword ptr [rbp-0x2B0], xmm0
 
G_M000_IG349:                ;; offset=0x277A
       lea      r8, [rbp-0x2B0]
       mov      rdx, rdi
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       je       G_M000_IG356
 
G_M000_IG350:                ;; offset=0x2799
       cmp      esi, ebx
       jae      G_M000_IG462
       mov      rcx, gword ptr [rbp+0xB60]
       mov      r14d, esi
       shl      r14, 5
       mov      r15, gword ptr [rcx+r14+0x10]
       mov      r9, gword ptr [rbp+0xBB8]
       mov      rdi, gword ptr [r9+0x98]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG352
 
G_M000_IG351:                ;; offset=0x27D2
       mov      rcx, rdi
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG352:                ;; offset=0x27DE
       mov      r9, gword ptr [rbp+0xBB8]
       mov      rsi, gword ptr [r9+0x98]
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasActiveHandler():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG354
 
G_M000_IG353:                ;; offset=0x27FD
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      rdx, gword ptr [rcx+0x80]
       jmp      SHORT G_M000_IG355
 
G_M000_IG354:                ;; offset=0x280D
       mov      r9, gword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [r9+0x98]
       mov      rdx, gword ptr [rdx+0x148]
 
G_M000_IG355:                ;; offset=0x2822
       lea      rcx, bword ptr [rsi+0x148]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, gword ptr [rbp+0xB60]
       lea      rcx, bword ptr [rax+r14+0x10]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xBB0]
       add      dword ptr [rcx+0x10], 2
       jmp      G_M000_IG472
 
G_M000_IG356:                ;; offset=0x2866
       mov      rdx, gword ptr [rbp+0xBC0]
       lea      rsi, bword ptr [rdx+0x190]
       mov      rdx, gword ptr [rbp+0xA88]
       mov      rcx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp+0xA90]
       mov      qword ptr [rsi+0x08], rcx
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      word  ptr [rdx+0xF8], 257
       mov      rcx, bword ptr [rbp+0xBB0]
       inc      dword ptr [rcx+0x10]
       test     r15d, r15d
       jne      G_M000_IG243
 
G_M000_IG357:                ;; offset=0x28B1
       test     rdi, rdi
       je       G_M000_IG243
 
G_M000_IG358:                ;; offset=0x28BA
       mov      rcx, rdx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG243
       jmp      G_M000_IG472
 
G_M000_IG359:                ;; offset=0x28D3
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG360:                ;; offset=0x28DA
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG361:                ;; offset=0x28E7
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0xB0]
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0xB0]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xA8]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       je       SHORT G_M000_IG365
 
G_M000_IG362:                ;; offset=0x2935
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG363
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG364
 
G_M000_IG363:                ;; offset=0x295E
       mov      rcx, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A1D30
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG364:                ;; offset=0x2984
       test     edi, edi
       je       G_M000_IG323
 
G_M000_IG365:                ;; offset=0x298C
       mov      rcx, bword ptr [rbp+0xBD0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG78
 
G_M000_IG366:                ;; offset=0x299E
       mov      rdx, gword ptr [rbp+0xBC0]
       cmp      gword ptr [rdx+0x68], 0
       jne      G_M000_IG368
 
G_M000_IG367:                ;; offset=0x29B0
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r8d, eax
       mov      edx, edi
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rsi, rax
       mov      rcx, 0x7FF9D71628A8
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      rdi, rax
       lea      rcx, bword ptr [rdi+0x10]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, bword ptr [rbp+0xB48]
       mov      rdx, gword ptr [rdx]
       mov      rcx, rdi
       mov      r8, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rsi, rax
       mov      rcx, 0x7FF9D77F7DB8
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       mov      r9, bword ptr [rbp+0xB48]
       mov      r9, gword ptr [r9]
       mov      rcx, rdi
       mov      rdx, rsi
       mov      r8, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:.ctor(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      r8, gword ptr [rbp+0xBC0]
       lea      rcx, bword ptr [r8+0x68]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG368:                ;; offset=0x2A65
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      rcx, gword ptr [rdx+0x68]
       mov      r8, gword ptr [rdx+0x58]
       mov      r9, gword ptr [rdx+0x60]
       lea      rdx, [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:Advance(System.Object,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.PyIterationResult:this]
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG369:                ;; offset=0x2A8E
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG370:                ;; offset=0x2A9B
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0xA0]
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
       jmp      G_M000_IG78
 
G_M000_IG371:                ;; offset=0x2ABB
       mov      rdx, r8
       movzx    rax, byte  ptr [rbp+0xBC8]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      r9, gword ptr [rbp+0xBB8]
       mov      r8, gword ptr [rdx+0x70]
       test     r8, r8
       je       G_M000_IG243
 
G_M000_IG372:                ;; offset=0x2AE0
       mov      rcx, rdx
       mov      rdx, r8
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG243
       jmp      G_M000_IG472
 
G_M000_IG373:                ;; offset=0x2AF9
       mov      rcx, gword ptr [rdi]
       mov      r8, gword ptr [rdi+0x08]
       mov      rdx, rax
       mov      r9, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG02
 
G_M000_IG374:                ;; offset=0x2B15
       lea      rcx, [rbp-0x190]
       mov      rdx, rax
       mov      r8, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
       lea      rcx, [rbp-0x1A0]
       lea      rdx, [rbp-0x190]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0x1A0]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x198]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       je       G_M000_IG266
 
G_M000_IG375:                ;; offset=0x2B77
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG376
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG377
 
G_M000_IG376:                ;; offset=0x2BA0
       mov      rcx, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A1D38
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG377:                ;; offset=0x2BC6
       test     r14d, r14d
       jne      G_M000_IG266
       jmp      G_M000_IG323
 
G_M000_IG378:                ;; offset=0x2BD4
       movzx    rax, byte  ptr [rbp+0xBC8]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r9, gword ptr [rbp+0xBB8]
       test     rdx, rdx
       je       G_M000_IG151
 
G_M000_IG379:                ;; offset=0x2BF9
       test     al, al
       jne      SHORT G_M000_IG381
 
G_M000_IG380:                ;; offset=0x2BFD
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG02
 
G_M000_IG381:                ;; offset=0x2C19
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG382:                ;; offset=0x2C20
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG383:                ;; offset=0x2C2D
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0x150]
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0x150]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x148]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       je       G_M000_IG266
 
G_M000_IG384:                ;; offset=0x2C7F
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG385
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG386
 
G_M000_IG385:                ;; offset=0x2CA8
       mov      rcx, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A1D40
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG386:                ;; offset=0x2CCE
       test     edi, edi
       jne      G_M000_IG266
       jmp      G_M000_IG323
 
G_M000_IG387:                ;; offset=0x2CDB
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       je       G_M000_IG245
 
G_M000_IG388:                ;; offset=0x2CF7
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG389:                ;; offset=0x2D03
       lea      r9, [rbp-0x2A0]
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r8, bword ptr [rbp+0xB48]
       mov      rcx, bword ptr [rbp+0xBB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp+0xAB8], 2
       jmp      G_M000_IG464
 
G_M000_IG390:                ;; offset=0x2D34
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG391:                ;; offset=0x2D3B
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG392:                ;; offset=0x2D48
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0x140]
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r10, bword ptr [rbp+0xBD0]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0x140]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x138]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xBD0]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG238
 
G_M000_IG393:                ;; offset=0x2D9A
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG394
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG395
 
G_M000_IG394:                ;; offset=0x2DC3
       mov      r10, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A1D48
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG395:                ;; offset=0x2DE9
       test     esi, esi
       jne      G_M000_IG238
       jmp      G_M000_IG323
 
G_M000_IG396:                ;; offset=0x2DF6
       mov      r8d, eax
       movzx    rax, byte  ptr [rbp+0xBC8]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r9, gword ptr [rbp+0xBB8]
       mov      dword ptr [rbp+0xAB8], r8d
       jmp      G_M000_IG464
 
G_M000_IG397:                ;; offset=0x2E21
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rax, gword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp+0xB48]
       mov      edx, dword ptr [rdx+0x10]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG462
       shl      rdx, 4
       mov      rbx, gword ptr [rax+rdx+0x10]
       test     rbx, rbx
       je       G_M000_IG100
 
G_M000_IG398:                ;; offset=0x2E51
       mov      rax, 0x7FF9D77F5D30
       cmp      qword ptr [rbx], rax
       jne      G_M000_IG100
 
G_M000_IG399:                ;; offset=0x2E64
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       test     rax, rax
       je       G_M000_IG100
 
G_M000_IG400:                ;; offset=0x2E76
       cmp      gword ptr [rax+0x20], 0
       je       G_M000_IG100
 
G_M000_IG401:                ;; offset=0x2E81
       mov      rdx, bword ptr [rbp+0xB48]
       mov      bword ptr [rsp+0x20], rdx
       movzx    rdx, byte  ptr [rbp+0xBC8]
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x70]
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      r8, rax
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0x70]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x68]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG238
 
G_M000_IG402:                ;; offset=0x2EE0
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG403
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG404
 
G_M000_IG403:                ;; offset=0x2F09
       mov      rcx, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A1D50
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG404:                ;; offset=0x2F2F
       test     esi, esi
       jne      G_M000_IG238
       jmp      G_M000_IG323
 
G_M000_IG405:                ;; offset=0x2F3C
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2965DB6AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG406:                ;; offset=0x2F6A
       xor      rdx, rdx
       xor      eax, eax
       jmp      G_M000_IG194
 
G_M000_IG407:                ;; offset=0x2F73
       mov      ecx, 40
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException(int)]
       int3     
 
G_M000_IG408:                ;; offset=0x2F7F
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2965DB74020
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG409:                ;; offset=0x2FAD
       xor      r15, r15
       xor      r13d, r13d
       jmp      G_M000_IG195
 
G_M000_IG410:                ;; offset=0x2FB8
       mov      ecx, edi
       mov      rdx, 0x2965DB66810
       call     [System.ArgumentOutOfRangeException:ThrowNegativeOrZero[int](int,System.String)]
       int3     
 
G_M000_IG411:                ;; offset=0x2FCB
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG412:                ;; offset=0x2FD2
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG413:                ;; offset=0x2FDF
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0x110]
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r10, bword ptr [rbp+0xBD0]
       mov      r14, r10
       mov      rdx, gword ptr [rbp-0x110]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x108]
       mov      qword ptr [r14+0x08], rdx
       mov      r10, bword ptr [rbp+0xBD0]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG238
 
G_M000_IG414:                ;; offset=0x3031
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG415
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG416
 
G_M000_IG415:                ;; offset=0x305A
       mov      r10, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A1D58
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG416:                ;; offset=0x3080
       test     esi, esi
       jne      G_M000_IG238
       jmp      G_M000_IG323
 
G_M000_IG417:                ;; offset=0x308D
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG418:                ;; offset=0x3094
       mov      rcx, rax
       mov      r11, 0x7FF9D70A1CE8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rbx, rax
       jmp      G_M000_IG285
 
G_M000_IG419:                ;; offset=0x30AC
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2965DB6AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG420:                ;; offset=0x30DA
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG421:                ;; offset=0x30E1
       mov      gword ptr [rsp+0x20], r14
       lea      rcx, [rbp+0xA50]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG151
 
G_M000_IG422:                ;; offset=0x3114
       cmp      gword ptr [rbp+0xA50], 0
       je       G_M000_IG02
 
G_M000_IG423:                ;; offset=0x3122
       mov      r8, gword ptr [rbp+0xA50]
       xor      r10, r10
       mov      r11, bword ptr [rbp+0xBE0]
       mov      gword ptr [r11], r10
       lea      rcx, bword ptr [r11+0x08]
       mov      rdx, r8
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r11, bword ptr [rbp+0xBE0]
       mov      word  ptr [r11+0x10], 0
       mov      byte  ptr [r11+0x12], 1
       jmp      G_M000_IG305
 
G_M000_IG424:                ;; offset=0x315A
       mov      rdx, r14
       mov      rcx, 0x7FF9D78959B0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG425
       mov      rcx, rax
       call     [System.Threading.Tasks.Task:get_IsCompletedSuccessfully():bool:this]
       jmp      SHORT G_M000_IG426
 
G_M000_IG425:                ;; offset=0x317D
       mov      r8, bword ptr [rbp+0xBE0]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, r14
       mov      r11, 0x7FF9D70A1D60
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetStatus(short):int:this
       cmp      eax, 1
       sete     al
       movzx    rax, al
 
G_M000_IG426:                ;; offset=0x31A2
       test     eax, eax
       je       G_M000_IG305
       jmp      G_M000_IG302
 
G_M000_IG427:                ;; offset=0x31AF
       mov      rdx, rsi
       mov      rcx, 0x7FF9D78959B0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      rdi, rax
       test     rdi, rdi
       je       SHORT G_M000_IG430
       mov      ecx, dword ptr [rdi+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG429
 
G_M000_IG428:                ;; offset=0x31DB
       mov      rcx, rdi
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG429:                ;; offset=0x31E6
       mov      rdi, gword ptr [rdi+0x38]
       jmp      G_M000_IG304
 
G_M000_IG430:                ;; offset=0x31EF
       mov      r8, bword ptr [rbp+0xBE0]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A1D68
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetResult(short):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG304
 
G_M000_IG431:                ;; offset=0x3213
       xor      edx, edx
       mov      r8, bword ptr [rbp+0xBE0]
       mov      qword ptr [r8], rdx
       mov      qword ptr [r8+0x08], rdx
       mov      qword ptr [r8+0x10], rdx
       jmp      G_M000_IG168
 
G_M000_IG432:                ;; offset=0x322C
       mov      rdx, r14
       mov      rcx, 0x7FF9D74947C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG435
 
G_M000_IG433:                ;; offset=0x3244
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
 
G_M000_IG434:                ;; offset=0x3259
       mov      r8, rax
       mov      rcx, r8
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG435:                ;; offset=0x326C
       mov      rcx, r14
       movsx    rdx, word  ptr [rbp+0xAB0]
       mov      r11, 0x7FF9D70A1D70
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG436:                ;; offset=0x3289
       mov      gword ptr [rsp+0x20], r14
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0xF0]
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x100]
       lea      rdx, [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xBD0]
       mov      r14, r10
       mov      rdx, gword ptr [rbp-0x100]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xF8]
       mov      qword ptr [r14+0x08], rdx
       mov      r10, bword ptr [rbp+0xBD0]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG266
 
G_M000_IG437:                ;; offset=0x32FB
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG438
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG439
 
G_M000_IG438:                ;; offset=0x3324
       mov      r10, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A1D78
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG439:                ;; offset=0x334A
       test     esi, esi
       jne      G_M000_IG266
       jmp      G_M000_IG323
 
G_M000_IG440:                ;; offset=0x3357
       mov      rcx, rdi
       mov      edx, r13d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG441:                ;; offset=0x337B
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2965DB6AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG442:                ;; offset=0x33A9
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG443:                ;; offset=0x33B0
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG444:                ;; offset=0x33BD
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0x120]
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x130]
       lea      rdx, [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xBD0]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0x130]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x128]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xBD0]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG266
 
G_M000_IG445:                ;; offset=0x3423
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG446
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG447
 
G_M000_IG446:                ;; offset=0x344C
       mov      r10, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A1D80
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG447:                ;; offset=0x3472
       test     esi, esi
       jne      G_M000_IG266
       jmp      G_M000_IG323
 
G_M000_IG448:                ;; offset=0x347F
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG449:                ;; offset=0x3486
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG450:                ;; offset=0x3493
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0xD0]
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0xE0]
       lea      rdx, [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xBD0]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0xE0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xD8]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xBD0]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG266
 
G_M000_IG451:                ;; offset=0x34F9
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG452
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG453
 
G_M000_IG452:                ;; offset=0x3522
       mov      r10, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A1D88
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG453:                ;; offset=0x3548
       test     esi, esi
       jne      G_M000_IG266
       jmp      G_M000_IG323
 
G_M000_IG454:                ;; offset=0x3555
       test     rbx, rbx
       je       G_M000_IG272
 
G_M000_IG455:                ;; offset=0x355E
       mov      r8, 0x7FF9D77F9A80
       cmp      qword ptr [rbx], r8
       jne      G_M000_IG272
 
G_M000_IG456:                ;; offset=0x3571
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG457:                ;; offset=0x3578
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG458:                ;; offset=0x3585
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0xC0]
       mov      rcx, gword ptr [rbp+0xBC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xB8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG238
 
G_M000_IG459:                ;; offset=0x35D9
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG460
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG461
 
G_M000_IG460:                ;; offset=0x3602
       mov      rcx, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A1D90
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG461:                ;; offset=0x3628
       test     esi, esi
       jne      G_M000_IG238
       jmp      G_M000_IG323
 
G_M000_IG462:                ;; offset=0x3635
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG463:                ;; offset=0x363B
       lea      rcx, [rbp+0xA20]
       mov      rdx, 0x2965DB72A40
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
       jmp      G_M000_IG75
 
G_M000_IG464:                ;; offset=0x3657
       mov      eax, dword ptr [rbp+0xAB8]
 
G_M000_IG465:                ;; offset=0x365D
       vzeroupper 
       add      rsp, 0xEC8
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG466:                ;; offset=0x3674
       mov      eax, 1
 
G_M000_IG467:                ;; offset=0x3679
       vzeroupper 
       add      rsp, 0xEC8
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG468:                ;; offset=0x3690
       mov      rcx, bword ptr [rbp+0xBB0]
       cmp      gword ptr [rcx+0x40], 0
       je       G_M000_IG03
 
G_M000_IG469:                ;; offset=0x36A2
       xor      rax, rax
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      gword ptr [rcx], rax
       mov      word  ptr [rcx+0x08], 0
       movzx    rax, byte  ptr [rbp+0xB5C]
       mov      byte  ptr [rcx+0x0A], al
       mov      byte  ptr [rcx+0x0B], 1
       mov      eax, 5
 
G_M000_IG470:                ;; offset=0x36C7
       vzeroupper 
       add      rsp, 0xEC8
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG471:                ;; offset=0x36DE
       mov      r9, bword ptr [rbp+0xB48]
       mov      r9, gword ptr [r9]
       mov      rcx, rdi
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r8, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG473
       mov      dword ptr [rbp+0xB5C], 1
       jmp      G_M000_IG02
 
G_M000_IG472:                ;; offset=0x3712
       mov      rcx, bword ptr [rbp+0xBB0]
       cmp      dword ptr [rcx+0x10], ebx
       jl       G_M000_IG06
       jmp      G_M000_IG466
 
G_M000_IG473:                ;; offset=0x3727
       mov      rcx, rdi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG474:                ;; offset=0x3730
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG475:                ;; offset=0x3736
       sub      rsp, 72
 
G_M000_IG476:                ;; offset=0x373A
       mov      rbx, rcx
       cmp      gword ptr [rbp+0xBC0], 0
       jne      SHORT G_M000_IG478
 
G_M000_IG477:                ;; offset=0x3747
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG478:                ;; offset=0x374D
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG481
 
G_M000_IG479:                ;; offset=0x3771
       mov      dword ptr [rbp+0xAB8], 1
       lea      rax, G_M000_IG464
 
G_M000_IG480:                ;; offset=0x3782
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG481:                ;; offset=0x378A
       mov      dword ptr [rbp+0xB5C], 1
       lea      rax, G_M000_IG02
 
G_M000_IG482:                ;; offset=0x379B
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG483:                ;; offset=0x37A3
       sub      rsp, 72
 
G_M000_IG484:                ;; offset=0x37A7
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r8, gword ptr [rbp+0xBC0]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG486
 
G_M000_IG485:                ;; offset=0x37D5
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG486:                ;; offset=0x37DB
       mov      dword ptr [rbp+0xB5C], 1
       lea      rax, G_M000_IG02
 
G_M000_IG487:                ;; offset=0x37EC
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	000006B3h ; case G_M000_IG69
       	dd	0000064Bh ; case G_M000_IG68
       	dd	000000E6h ; case G_M000_IG12
       	dd	00000DB5h ; case G_M000_IG123
       	dd	00000D4Bh ; case G_M000_IG122
       	dd	00000CB7h ; case G_M000_IG120
       	dd	00000C44h ; case G_M000_IG116
       	dd	00001CB1h ; case G_M000_IG258
       	dd	00001CB1h ; case G_M000_IG258
       	dd	00001FA1h ; case G_M000_IG283
       	dd	00001FA1h ; case G_M000_IG283
       	dd	00001CB1h ; case G_M000_IG258
       	dd	00001CB1h ; case G_M000_IG258
       	dd	00001CB1h ; case G_M000_IG258
       	dd	00001CB1h ; case G_M000_IG258
       	dd	00001CB1h ; case G_M000_IG258
       	dd	00001CB1h ; case G_M000_IG258
       	dd	00001CB1h ; case G_M000_IG258
       	dd	00001CB1h ; case G_M000_IG258
       	dd	00001CB1h ; case G_M000_IG258
       	dd	00001CB1h ; case G_M000_IG258
       	dd	00001CB1h ; case G_M000_IG258
       	dd	00001C82h ; case G_M000_IG257
       	dd	00001C82h ; case G_M000_IG257
       	dd	00001C58h ; case G_M000_IG255
       	dd	00001C31h ; case G_M000_IG254
       	dd	00001C09h ; case G_M000_IG253
       	dd	00001B77h ; case G_M000_IG251
       	dd	00001ACEh ; case G_M000_IG249
       	dd	00001A5Eh ; case G_M000_IG248
       	dd	00001A1Bh ; case G_M000_IG247
       	dd	0000199Eh ; case G_M000_IG246
       	dd	000018DCh ; case G_M000_IG241
       	dd	000018AFh ; case G_M000_IG239
       	dd	000018AFh ; case G_M000_IG239
       	dd	000018AFh ; case G_M000_IG239
       	dd	0000187Ah ; case G_M000_IG236
       	dd	0000187Ah ; case G_M000_IG236
       	dd	0000187Ah ; case G_M000_IG236
       	dd	000018AFh ; case G_M000_IG239
       	dd	0000160Fh ; case G_M000_IG207
       	dd	00000AF7h ; case G_M000_IG100
       	dd	00001FFFh ; case G_M000_IG284
       	dd	00001F77h ; case G_M000_IG282
       	dd	00001F57h ; case G_M000_IG280
       	dd	00001F44h ; case G_M000_IG279
       	dd	00001F16h ; case G_M000_IG278
       	dd	00001F16h ; case G_M000_IG278
       	dd	00001F16h ; case G_M000_IG278
       	dd	00001E72h ; case G_M000_IG273
       	dd	00001DF9h ; case G_M000_IG269
       	dd	00001DA1h ; case G_M000_IG267
       	dd	00001E72h ; case G_M000_IG273
       	dd	00001E72h ; case G_M000_IG273
       	dd	00001E72h ; case G_M000_IG273
       	dd	00001E72h ; case G_M000_IG273
       	dd	00001E72h ; case G_M000_IG273
       	dd	00001E72h ; case G_M000_IG273
       	dd	00001E72h ; case G_M000_IG273
       	dd	000018FEh ; case G_M000_IG243
       	dd	00000831h ; case G_M000_IG79
       	dd	000007F7h ; case G_M000_IG76
       	dd	00001E72h ; case G_M000_IG273
       	dd	000011E6h ; case G_M000_IG169
       	dd	000011E6h ; case G_M000_IG169
       	dd	000011E6h ; case G_M000_IG169
       	dd	000011E6h ; case G_M000_IG169
       	dd	000011E6h ; case G_M000_IG169
       	dd	000011ADh ; case G_M000_IG167
       	dd	00000ACEh ; case G_M000_IG98
       	dd	0000099Dh ; case G_M000_IG90
       	dd	000008E6h ; case G_M000_IG83
       	dd	000008AEh ; case G_M000_IG82
RWD292 	dq	006E006B006E0055h, 0020006E0077006Fh, 0063006500780065h, 0062006100740075h
RWD324 	dq	006F00200065006Ch, 0064006F00630070h

; Total bytes of code 14324

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x420
       lea      rbp, [rsp+0x420]
       xor      eax, eax
       mov      qword ptr [rbp-0x3D8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x3D0], xmm4
       mov      rax, -960
 
G_M000_IG77:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG77
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
 
G_M000_IG02:                ;; offset=0x004E
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0xD0], rax
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rbp-0x248], rax
       mov      rcx, gword ptr [rbp-0x248]
       mov      rdx, 0x7FF9D7A1AA28
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x248]
       mov      gword ptr [rbp-0x278], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x27C], eax
       mov      rcx, gword ptr [rbp-0x278]
       mov      edx, dword ptr [rbp-0x27C]
       mov      r11, 0x7FF9D70A2088
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x0C], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0xD8], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0xDC], eax
       mov      rax, bword ptr [rbp-0xD8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xDC], eax
       jae      G_M000_IG66
       mov      rax, bword ptr [rbp-0xD8]
       mov      ecx, dword ptr [rbp-0xDC]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x288], rax
       mov      rdx, gword ptr [rbp-0x288]
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x18], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x28], xmm0
 
G_M000_IG03:                ;; offset=0x0157
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG53
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG64
 
G_M000_IG04:                ;; offset=0x0198
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       jne      G_M000_IG09
       mov      rcx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG07
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x200], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x204], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x28C], eax
       mov      r9d, dword ptr [rbp-0x28C]
       lea      rdx, [rbp-0x218]
       mov      r8d, dword ptr [rbp-0x204]
       mov      rcx, bword ptr [rbp-0x200]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG05:                ;; offset=0x021C
       vmovdqu  xmm0, xmmword ptr [rbp-0x218]
       vmovdqu  xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG06:                ;; offset=0x022C
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2A8], rax
       mov      rdx, gword ptr [rbp-0x2A8]
       lea      rcx, [rbp-0x2A0]
       lea      r9, [rbp-0x38]
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG08
       mov      rcx, 0x7FF9D7A1AB30
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG64
 
G_M000_IG07:                ;; offset=0x027C
       mov      rcx, 0x7FF9D7A1AB34
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x028D
       mov      rcx, 0x7FF9D7A1AB38
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG53
 
G_M000_IG09:                ;; offset=0x02AF
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG44
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, 0x7FF9D76B1038
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x40], rax
       cmp      gword ptr [rbp-0x40], 0
       je       G_M000_IG21
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x108], rax
       mov      rax, bword ptr [rbp-0x108]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x0C], eax
       jae      G_M000_IG48
       mov      rax, bword ptr [rbp-0x108]
       mov      ecx, dword ptr [rbp-0x0C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x48], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG25
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, 0x7FF9D75C1030
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       je       G_M000_IG20
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x2B0], rax
       mov      rdx, gword ptr [rbp-0x2B0]
       mov      rcx, 0x7FF9D76AFB58
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       G_M000_IG19
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingMethod():Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod:this]
 
G_M000_IG10:                ;; offset=0x03A5
       cmp      rax, gword ptr [rbp-0x18]
       jne      G_M000_IG18
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG48
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
 
G_M000_IG11:                ;; offset=0x03DD
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
 
G_M000_IG12:                ;; offset=0x03E9
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x180], rax
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x250], rax
       mov      rcx, gword ptr [rbp-0x250]
       mov      rdx, 0x7FF9D7A1AB40
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x250]
       mov      gword ptr [rbp-0x2B8], rax
       lea      rcx, [rbp-0x90]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x2BC], eax
       mov      rcx, gword ptr [rbp-0x2B8]
       mov      edx, dword ptr [rbp-0x2BC]
       mov      r11, 0x7FF9D70A20A0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x98], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x188], rax
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingCallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2C8], rax
       mov      rdx, gword ptr [rbp-0x2C8]
       mov      rcx, gword ptr [rbp-0x188]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG13:                ;; offset=0x049F
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x190], rax
       lea      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rbp-0x198], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x1A8], rax
       mov      rax, gword ptr [rbp-0x190]
       mov      gword ptr [rbp-0x1B0], rax
       mov      rcx, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      G_M000_IG15
       mov      rax, bword ptr [rbp-0x198]
       mov      bword ptr [rbp-0x1E0], rax
       mov      rax, gword ptr [rbp-0x1A0]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rax, gword ptr [rbp-0x1B0]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rax, bword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x40]
       test     eax, eax
       je       SHORT G_M000_IG14
       mov      rax, bword ptr [rbp-0x1E0]
       mov      bword ptr [rbp-0x1B8], rax
       mov      rax, gword ptr [rbp-0x1E8]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rax, gword ptr [rbp-0x1F0]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, gword ptr [rbp-0x1F8]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rcx, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0x1D4], eax
       jmp      G_M000_IG16
 
G_M000_IG14:                ;; offset=0x058A
       mov      rcx, 0x7FF9D7A1AC48
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x1E0]
       mov      bword ptr [rbp-0x1B8], rax
       mov      rax, gword ptr [rbp-0x1E8]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rax, gword ptr [rbp-0x1F0]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, gword ptr [rbp-0x1F8]
       mov      gword ptr [rbp-0x1D0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x1D4], eax
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x05DB
       mov      rcx, 0x7FF9D7A1AC4C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x198]
       mov      bword ptr [rbp-0x1B8], rax
       mov      rax, gword ptr [rbp-0x1A0]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, gword ptr [rbp-0x1B0]
       mov      gword ptr [rbp-0x1D0], rax
       mov      dword ptr [rbp-0x1D4], 1
 
G_M000_IG16:                ;; offset=0x062C
       mov      rcx, gword ptr [rbp-0x1C0]
       mov      rdx, gword ptr [rbp-0x1C8]
       mov      r8, gword ptr [rbp-0x1D0]
       mov      r9d, dword ptr [rbp-0x1D4]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x2D0], rax
       mov      rdx, gword ptr [rbp-0x2D0]
       mov      rcx, bword ptr [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       nop      
 
G_M000_IG17:                ;; offset=0x066A
       call     G_M000_IG67
       jmp      SHORT G_M000_IG22
 
G_M000_IG18:                ;; offset=0x0671
       mov      rcx, 0x7FF9D7A1AC50
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG25
 
G_M000_IG19:                ;; offset=0x0685
       mov      rcx, 0x7FF9D7A1AC54
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG25
 
G_M000_IG20:                ;; offset=0x0696
       mov      rcx, 0x7FF9D7A1AC58
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG25
 
G_M000_IG21:                ;; offset=0x06A7
       mov      rcx, 0x7FF9D7A1AC5C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG44
 
G_M000_IG22:                ;; offset=0x06BB
       mov      rcx, 0x7FF9D7A1AC64
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x38], 2
 
G_M000_IG23:                ;; offset=0x06D2
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG24:                ;; offset=0x06DF
       lea      r8, [rbp-0x2E0]
       lea      rdx, [rbp-0x90]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      dword ptr [rbp-0x2C], 1
       jmp      G_M000_IG64
 
G_M000_IG25:                ;; offset=0x0703
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x2E8], rax
       mov      rdx, gword ptr [rbp-0x2E8]
       mov      rcx, 0x7FF9D7803218
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x60], 0
       je       G_M000_IG35
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 3
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG48
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       cmp      eax, dword ptr [rbp-0x0C]
       jne      G_M000_IG34
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG26:                ;; offset=0x0780
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x2F8], xmm0
 
G_M000_IG27:                ;; offset=0x078D
       lea      rdx, [rbp-0x2F8]
       lea      rcx, [rbp-0x150]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG28:                ;; offset=0x07A1
       vmovdqu  xmm0, xmmword ptr [rbp-0x150]
       vmovdqu  xmmword ptr [rbp-0x308], xmm0
 
G_M000_IG29:                ;; offset=0x07B1
       lea      rax, [rbp-0x68]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x70]
       mov      qword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x308]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9d, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadAsciiTrim(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG33
       mov      rcx, 0x7FF9D7A1AC68
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rbp-0x258], rax
       mov      rcx, gword ptr [rbp-0x258]
       mov      rdx, 0x7FF9D7A1AC70
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x258]
       mov      gword ptr [rbp-0x310], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 3
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG48
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x314], eax
       mov      rcx, gword ptr [rbp-0x310]
       mov      edx, dword ptr [rbp-0x314]
       mov      r11, 0x7FF9D70A2098
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xA0], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x160], rax
       movzx    rax, byte  ptr [rbp-0x70]
       mov      dword ptr [rbp-0x164], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x170], rax
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
 
G_M000_IG30:                ;; offset=0x08D1
       mov      gword ptr [rbp-0x178], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rsp+0x20], rax
 
G_M000_IG31:                ;; offset=0x08F0
       vmovdqu  xmm0, xmmword ptr [rbp-0xB0]
       vmovdqu  xmmword ptr [rbp-0x328], xmm0
 
G_M000_IG32:                ;; offset=0x0900
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x328]
       mov      qword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp-0x160]
       mov      r8d, dword ptr [rbp-0x164]
       mov      r9, gword ptr [rbp-0x170]
       mov      rcx, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteTrimmedSplit(Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Runtime.Text.PyString,byte,Lokad.Lython.LythonSourceSpan,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x330], rax
       mov      rdx, gword ptr [rbp-0x330]
       lea      rcx, [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x38], 3
       jmp      G_M000_IG53
 
G_M000_IG33:                ;; offset=0x095D
       mov      rcx, 0x7FF9D7A1AD78
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x096E
       mov      rcx, 0x7FF9D7A1AD7C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG35:                ;; offset=0x097D
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x110], rax
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG36:                ;; offset=0x0990
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x340], xmm0
 
G_M000_IG37:                ;; offset=0x099D
       lea      rdx, [rbp-0x340]
       lea      rcx, [rbp-0x120]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG38:                ;; offset=0x09B1
       vmovdqu  xmm0, xmmword ptr [rbp-0x120]
       vmovdqu  xmmword ptr [rbp-0x350], xmm0
 
G_M000_IG39:                ;; offset=0x09C1
       mov      rax, gword ptr [rbp-0x08]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x38], rax
       lea      r8, [rbp-0x350]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      r9, bword ptr [rax+0x38]
       mov      rdx, gword ptr [rbp-0x110]
       mov      rcx, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG42
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x128], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x12C], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x354], eax
       mov      r9d, dword ptr [rbp-0x354]
       lea      rdx, [rbp-0x140]
       mov      r8d, dword ptr [rbp-0x12C]
       mov      rcx, bword ptr [rbp-0x128]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG40:                ;; offset=0x0A73
       vmovdqu  xmm0, xmmword ptr [rbp-0x140]
       vmovdqu  xmmword ptr [rbp-0x368], xmm0
 
G_M000_IG41:                ;; offset=0x0A83
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x370], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xB8]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp-0x370]
       lea      r8, [rbp-0x368]
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG43
       mov      rcx, 0x7FF9D7A1AD80
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG64
 
G_M000_IG42:                ;; offset=0x0AE8
       mov      rcx, 0x7FF9D7A1AD84
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG53
 
G_M000_IG43:                ;; offset=0x0AFC
       mov      rcx, 0x7FF9D7A1AD88
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG53
 
G_M000_IG44:                ;; offset=0x0B21
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG45:                ;; offset=0x0B25
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x380], xmm0
 
G_M000_IG46:                ;; offset=0x0B32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x30], rax
       lea      r8, [rbp-0x380]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9d, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG51
       lea      rcx, [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x260], rax
       mov      rcx, gword ptr [rbp-0x260]
       mov      rdx, 0x7FF9D7A1AD90
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x260]
       mov      gword ptr [rbp-0x388], rax
       mov      rdx, gword ptr [rbp-0x388]
       mov      rcx, 0x7FF9D7500AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xC0], rax
       cmp      gword ptr [rbp-0xC0], 0
       je       SHORT G_M000_IG49
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ExceptionRegions():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableExceptionRegion]:this]
       mov      gword ptr [rbp-0x268], rax
       mov      rcx, gword ptr [rbp-0x268]
       mov      rdx, 0x7FF9D7A1AE98
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x268]
       mov      gword ptr [rbp-0x390], rax
       mov      rcx, gword ptr [rbp-0x390]
       mov      r11, 0x7FF9D70A2090
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       jne      SHORT G_M000_IG50
 
G_M000_IG47:                ;; offset=0x0C1F
       mov      rcx, gword ptr [rbp-0xC0]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG48:                ;; offset=0x0C2C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG49:                ;; offset=0x0C32
       mov      rcx, 0x7FF9D7A1AFA0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG53
 
G_M000_IG50:                ;; offset=0x0C43
       mov      rcx, 0x7FF9D7A1AFA4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:set_Failure(Lokad.Lython.Runtime.LythonRuntimeException):this]
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG64
 
G_M000_IG51:                ;; offset=0x0C6D
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG52
       mov      rcx, 0x7FF9D7A1AFA8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG64
 
G_M000_IG52:                ;; offset=0x0CA9
       mov      rcx, 0x7FF9D7A1AFAC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG53:                ;; offset=0x0CB8
       nop      
 
G_M000_IG54:                ;; offset=0x0CB9
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG59
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG66
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 15
       jne      G_M000_IG58
       mov      rcx, 0x7FF9D7A1B0C0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0xE8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG66
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3A8], rax
       mov      rdx, gword ptr [rbp-0x3A8]
       mov      rcx, gword ptr [rbp-0xE8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x3AC], eax
       mov      edx, dword ptr [rbp-0x3AC]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG55:                ;; offset=0x0DA8
       add      rax, 72
       mov      bword ptr [rbp-0xF0], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       mov      dword ptr [rbp-0x3B0], eax
       mov      r9d, dword ptr [rbp-0x3B0]
       lea      rdx, [rbp-0x100]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      rcx, bword ptr [rbp-0xF0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG56:                ;; offset=0x0DE4
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0x3C0], xmm0
 
G_M000_IG57:                ;; offset=0x0DF4
       lea      rcx, [rbp-0x3C0]
       call     [System.MemoryExtensions:Reverse[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       jmp      SHORT G_M000_IG62
 
G_M000_IG58:                ;; offset=0x0E03
       mov      rcx, 0x7FF9D7A1B0C4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG59:                ;; offset=0x0E12
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG66
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x3D8], rax
 
G_M000_IG60:                ;; offset=0x0E40
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x3D0], xmm0
 
G_M000_IG61:                ;; offset=0x0E4D
       mov      rdx, bword ptr [rbp-0x3D8]
       lea      r8, [rbp-0x3D0]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG62:                ;; offset=0x0E65
       mov      rcx, 0x7FF9D7A1B0C8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG63:                ;; offset=0x0E79
       vzeroupper 
       add      rsp, 0x420
       pop      rbp
       ret      
 
G_M000_IG64:                ;; offset=0x0E85
       mov      rcx, 0x7FF9D7A1B0CC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x2C]
 
G_M000_IG65:                ;; offset=0x0E97
       vzeroupper 
       add      rsp, 0x420
       pop      rbp
       ret      
 
G_M000_IG66:                ;; offset=0x0EA3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG67:                ;; offset=0x0EA9
       sub      rsp, 72
 
G_M000_IG68:                ;; offset=0x0EAD
       mov      rcx, 0x7FF9D7A1AC60
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG69:                ;; offset=0x0ECD
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG70:                ;; offset=0x0ED5
       sub      rsp, 72
 
G_M000_IG71:                ;; offset=0x0ED9
       mov      gword ptr [rbp-0x220], rcx
       mov      rax, gword ptr [rbp-0x220]
       mov      gword ptr [rbp-0x270], rax
       mov      rcx, gword ptr [rbp-0x270]
       mov      rdx, 0x7FF9D7A1AFB0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x270]
       mov      gword ptr [rbp-0x398], rax
       mov      rdx, gword ptr [rbp-0x398]
       mov      rcx, 0x7FF9D71A2168
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x228], rax
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rbp-0x230], rax
       cmp      gword ptr [rbp-0x228], 0
       jne      SHORT G_M000_IG72
       xor      eax, eax
       mov      dword ptr [rbp-0x234], eax
       jmp      SHORT G_M000_IG73
 
G_M000_IG72:                ;; offset=0x0F52
       mov      rcx, 0x7FF9D7A1B0B8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3A0], rax
       mov      rdx, gword ptr [rbp-0x3A0]
       lea      r8, [rbp-0xC8]
       mov      rcx, gword ptr [rbp-0x230]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
       mov      dword ptr [rbp-0x234], eax
 
G_M000_IG73:                ;; offset=0x0F9D
       mov      rcx, 0x7FF9D7A1B0BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x234]
 
G_M000_IG74:                ;; offset=0x0FB2
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG75:                ;; offset=0x0FBA
       sub      rsp, 72
 
G_M000_IG76:                ;; offset=0x0FBE
       mov      gword ptr [rbp-0x240], rcx
       mov      rcx, gword ptr [rbp-0xC8]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 4050

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 101776
; 27 inlinees with PGO data; 109 single block inlinees; 3 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 344
       lea      rbp, [rsp+0x190]
       xor      eax, eax
       mov      qword ptr [rbp-0x148], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x140], xmm4
       mov      rax, -240
 
G_M000_IG163:                ;; offset=0x003A
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG163
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      rbx, rdx
 
G_M000_IG02:                ;; offset=0x005D
       mov      rax, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rax+0xB0]
       cmp      dword ptr [rbx+0x1C], 42
       jne      G_M000_IG130
       mov      edx, dword ptr [rbx+0x08]
       mov      r8, 0x7FF9D7648660
       cmp      qword ptr [rax], r8
       jne      G_M000_IG132
       mov      r8d, dword ptr [rax+0x08]
       cmp      r8d, edx
       jbe      G_M000_IG131
       mov      rsi, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG03:                ;; offset=0x009A
       mov      gword ptr [rbp-0x140], rsi
       mov      ebx, dword ptr [rbx+0x10]
       mov      rcx, bword ptr [rbp+0x10]
       lea      rax, bword ptr [rcx+0x48]
       cmp      byte  ptr [rsi+0x30], 0
       setne    dl
       movzx    rdx, dl
       add      edx, ebx
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG140
       shl      rdx, 4
       add      rdx, bword ptr [rax]
       mov      rdi, gword ptr [rdx]
       mov      rax, 0x27637001CE0
       cmp      rdi, gword ptr [rax]
       je       G_M000_IG133
 
G_M000_IG04:                ;; offset=0x00DE
       mov      rax, 0x27637001CE8
       cmp      rdi, gword ptr [rax]
       je       G_M000_IG134
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG135
 
G_M000_IG05:                ;; offset=0x00FC
       test     rdi, rdi
       je       G_M000_IG136
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
 
G_M000_IG06:                ;; offset=0x010E
       cmp      byte  ptr [rsi+0x34], 0
       je       G_M000_IG85
 
G_M000_IG07:                ;; offset=0x0118
       movzx    r14, byte  ptr [rsi+0x30]
       test     r14d, r14d
       jne      G_M000_IG23
 
G_M000_IG08:                ;; offset=0x0126
       mov      r15, rdi
       mov      rax, 0x7FF9D776AC10
       cmp      qword ptr [r15], rax
       jne      G_M000_IG86
 
G_M000_IG09:                ;; offset=0x013C
       test     r15, r15
       je       SHORT G_M000_IG16
       mov      rdx, gword ptr [r15+0x08]
       mov      rdx, gword ptr [rdx+0x08]
       mov      r8, 0x2965DB6FE40
       cmp      rdx, r8
       je       SHORT G_M000_IG14
 
G_M000_IG10:                ;; offset=0x0158
       test     rdx, rdx
       je       SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x015D
       cmp      dword ptr [rdx+0x08], 5
       je       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x0163
       xor      r8d, r8d
       jmp      SHORT G_M000_IG15
 
G_M000_IG13:                ;; offset=0x0168
       mov      r8, 0x67006E00610072
       xor      r8, qword ptr [rdx+0x0C]
       movzx    rdx, word  ptr [rdx+0x14]
       xor      edx, 101
       or       rdx, r8
       sete     r8b
       movzx    r8, r8b
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x018A
       mov      r8d, 1
 
G_M000_IG15:                ;; offset=0x0190
       test     r8d, r8d
       jne      G_M000_IG87
 
G_M000_IG16:                ;; offset=0x0199
       mov      rcx, bword ptr [rbp+0x10]
       mov      r15, bword ptr [rcx+0x48]
       mov      r13d, dword ptr [rcx+0x50]
       mov      r9, gword ptr [rcx+0x10]
       mov      gword ptr [rbp-0x148], r9
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
       test     r14d, r14d
       jne      G_M000_IG113
       cmp      dword ptr [rsi+0x28], 1
       jg       G_M000_IG114
 
G_M000_IG17:                ;; offset=0x01CC
       cmp      dword ptr [rsi+0x28], 1
       jne      G_M000_IG113
       mov      r14, rdi
       mov      rax, 0x7FF9D776AC10
       cmp      qword ptr [r14], rax
       jne      G_M000_IG115
 
G_M000_IG18:                ;; offset=0x01EC
       test     r14, r14
       je       G_M000_IG113
 
G_M000_IG19:                ;; offset=0x01F5
       lea      eax, [rbx+0x01]
       cmp      eax, r13d
       jae      G_M000_IG122
       shl      rax, 4
       add      rax, r15
       mov      r13, gword ptr [rax]
       mov      rdx, 0x27637001CE0
       cmp      r13, gword ptr [rdx]
       je       G_M000_IG116
 
G_M000_IG20:                ;; offset=0x021E
       mov      rdx, 0x27637001CE8
       cmp      r13, gword ptr [rdx]
       je       G_M000_IG117
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG118
 
G_M000_IG21:                ;; offset=0x023C
       mov      rcx, r14
       mov      rdx, r13
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime:SelectNativeUnaryOperation(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,bool):System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      r15, rax
       test     r15, r15
       je       G_M000_IG113
 
G_M000_IG22:                ;; offset=0x0257
       mov      rdx, gword ptr [rsi+0x18]
       mov      gword ptr [rbp-0x150], rdx
       mov      r9, gword ptr [rbp-0x148]
       mov      rcx, gword ptr [r9+0x98]
       mov      rdx, gword ptr [rbp-0x150]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG35
 
G_M000_IG23:                ;; offset=0x0284
       mov      rdx, 0x7FF9D76B1038
       cmp      qword ptr [rdi], rdx
       jne      G_M000_IG16
 
G_M000_IG24:                ;; offset=0x0297
       mov      rcx, bword ptr [rbp+0x10]
       lea      rax, bword ptr [rcx+0x48]
       cmp      ebx, dword ptr [rax+0x08]
       jae      G_M000_IG122
       mov      edx, ebx
       shl      rdx, 4
       add      rdx, bword ptr [rax]
       mov      r14, gword ptr [rdx]
       mov      rax, 0x27637001CE0
       cmp      r14, gword ptr [rax]
       je       G_M000_IG90
 
G_M000_IG25:                ;; offset=0x02C7
       mov      rax, 0x27637001CE8
       cmp      r14, gword ptr [rax]
       je       G_M000_IG91
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG92
 
G_M000_IG26:                ;; offset=0x02E5
       cmp      dword ptr [rsi+0x28], 0
       jne      SHORT G_M000_IG27
       test     r14, r14
       jne      G_M000_IG57
 
G_M000_IG27:                ;; offset=0x02F4
       mov      rdx, gword ptr [rsi+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x02FD
       mov      rax, 0x7FF9D7803218
       xor      r8, r8
       cmp      qword ptr [rdx], rax
       cmovne   rdx, r8
 
G_M000_IG29:                ;; offset=0x0311
       mov      r15, rdx
       test     r15, r15
       je       G_M000_IG78
 
G_M000_IG30:                ;; offset=0x031D
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x08]
       mov      rdx, gword ptr [rdx+0x98]
       mov      eax, dword ptr [rcx+0x38]
       add      eax, 3
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG122
       shl      rax, 5
       cmp      dword ptr [rdx+rax+0x20], ebx
       jne      G_M000_IG78
 
G_M000_IG31:                ;; offset=0x0349
       vmovdqu  xmm0, xmmword ptr [rcx+0x48]
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG32:                ;; offset=0x0356
       lea      rdx, [rbp-0x128]
       lea      rcx, [rbp-0xB0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       lea      r8, [rbp-0x58]
       mov      qword ptr [rsp+0x20], r8
       lea      r8, [rbp-0x60]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0xB0]
       mov      rcx, rsi
       mov      rdx, rdi
       mov      r9d, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadAsciiTrim(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG78
 
G_M000_IG33:                ;; offset=0x039A
       mov      r12, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r12+0x08]
       mov      rdi, gword ptr [rcx+0xB0]
       mov      rcx, gword ptr [rcx+0x98]
       mov      edx, dword ptr [r12+0x38]
       add      edx, 3
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG122
       shl      rdx, 5
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      edx, 42
       mov      r8, 0x2965DB6D5C8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:ReadPrimaryOperand(int,System.String):int:this]
       mov      edx, eax
       mov      rcx, rdi
       mov      r11, 0x7FF9D70A21C8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdx, gword ptr [rbp-0x58]
       movzx    r8, byte  ptr [rbp-0x60]
       mov      r9, gword ptr [rsi+0x18]
       mov      rcx, gword ptr [rax+0x18]
       mov      gword ptr [rsp+0x20], rcx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x128], rcx
 
G_M000_IG34:                ;; offset=0x0411
       mov      dword ptr [rbp-0x120], ecx
       mov      rcx, gword ptr [r12+0x10]
       mov      gword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0x128]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteTrimmedSplit(Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Runtime.Text.PyString,byte,Lokad.Lython.LythonSourceSpan,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x48], rax
       xor      edx, edx
       mov      qword ptr [rbp-0x40], rdx
       add      dword ptr [r12+0x38], 3
       jmp      G_M000_IG123
 
G_M000_IG35:                ;; offset=0x044B
       mov      rcx, 0x7FF9D766BBA0
       cmp      qword ptr [r15+0x18], rcx
       jne      G_M000_IG49
       lea      rcx, [rbp-0xF8]
       mov      rdx, r13
       mov      r8, gword ptr [rbp-0x150]
       mov      r9, gword ptr [rbp-0x148]
       call     [Lokad.Lython.Runtime.LythonRuntime:GetLength(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Numerics.BigInteger]
       mov      r13, gword ptr [rbp-0xF8]
       mov      ecx, dword ptr [rbp-0xF0]
       test     ecx, ecx
       je       G_M000_IG39
       test     r13, r13
       jne      G_M000_IG42
       mov      r15d, 255
       xor      r8d, r8d
       test     ecx, ecx
       cmovge   r15d, r8d
       movsxd   rdi, ecx
 
G_M000_IG36:                ;; offset=0x04AD
       test     r15d, r15d
       jne      G_M000_IG46
       xor      ecx, ecx
       lzcnt    rcx, rdi
       shr      ecx, 3
       neg      ecx
       add      ecx, 7
       xor      eax, eax
       test     ecx, ecx
       cmovg    eax, ecx
 
G_M000_IG37:                ;; offset=0x04CC
       lea      ecx, [8*rax]
       shrx     rcx, rdi, rcx
       movzx    rcx, cl
       and      ecx, 128
       and      r15d, 128
       cmp      ecx, r15d
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       setne    cl
       movzx    rcx, cl
       lea      ecx, [rax+rcx+0x01]
       test     r13, r13
       jne      G_M000_IG47
 
G_M000_IG38:                ;; offset=0x0506
       cmp      ecx, 8
       jg       G_M000_IG48
 
G_M000_IG39:                ;; offset=0x050F
       vmovdqu  xmm0, xmmword ptr [rbp-0xF8]
       vmovdqu  xmmword ptr [rbp-0x118], xmm0
 
G_M000_IG40:                ;; offset=0x051F
       lea      rcx, [rbp-0x118]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      r14, rax
       mov      rdx, 0x27637001CE0
       mov      rdi, gword ptr [rdx]
 
G_M000_IG41:                ;; offset=0x053C
       mov      gword ptr [rbp-0xE0], rdi
       mov      qword ptr [rbp-0xD8], r14
       jmp      G_M000_IG50
 
G_M000_IG42:                ;; offset=0x054F
       cmp      ecx, -1
       jne      SHORT G_M000_IG45
       mov      r15d, 255
       lea      rcx, bword ptr [r13+0x10]
       mov      r8d, dword ptr [r13+0x08]
       xor      edx, edx
       call     [System.SpanHelpers:NonPackedIndexOfValueType[long,System.SpanHelpers+Negate`1[long]](byref,long,int):int]
       mov      ecx, dword ptr [r13+0x08]
       dec      ecx
       cmp      ecx, dword ptr [r13+0x08]
       jae      SHORT G_M000_IG43
       mov      ecx, dword ptr [r13+0x08]
       dec      ecx
       mov      rcx, qword ptr [r13+8*rcx+0x10]
       mov      rdi, rcx
       not      rdi
       mov      ecx, dword ptr [r13+0x08]
       dec      ecx
       cmp      ecx, eax
       jne      G_M000_IG36
       inc      rdi
       jmp      G_M000_IG36
 
G_M000_IG43:                ;; offset=0x059D
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG44:                ;; offset=0x05A3
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG45:                ;; offset=0x05A9
       xor      r15d, r15d
       mov      ecx, dword ptr [r13+0x08]
       dec      ecx
       cmp      ecx, dword ptr [r13+0x08]
       jae      SHORT G_M000_IG43
       mov      ecx, dword ptr [r13+0x08]
       dec      ecx
       mov      rdi, qword ptr [r13+8*rcx+0x10]
       jmp      G_M000_IG36
 
G_M000_IG46:                ;; offset=0x05C8
       mov      rax, rdi
       not      rax
       xor      ecx, ecx
       lzcnt    rcx, rax
       shr      ecx, 3
       neg      ecx
       add      ecx, 7
       xor      eax, eax
       test     ecx, ecx
       cmovg    eax, ecx
       jmp      G_M000_IG37
 
G_M000_IG47:                ;; offset=0x05E9
       mov      eax, dword ptr [r13+0x08]
       sub      eax, 1
       imul     eax, eax, 8
       jo       SHORT G_M000_IG44
       add      ecx, eax
       jo       SHORT G_M000_IG44
       jmp      G_M000_IG38
 
G_M000_IG48:                ;; offset=0x05FE
       mov      rcx, 0x7FF9D754B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       lea      r14, bword ptr [rdi+0x08]
       mov      rdx, gword ptr [rbp-0xF8]
       mov      rcx, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xF0]
       mov      qword ptr [r14+0x08], rdx
       mov      rdx, rdi
       lea      rcx, [rbp-0x108]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rdi, gword ptr [rbp-0x108]
       mov      r14, qword ptr [rbp-0x100]
       jmp      G_M000_IG41
 
G_M000_IG49:                ;; offset=0x0651
       mov      r9, gword ptr [rbp-0x148]
       mov      gword ptr [rsp+0x20], r9
       lea      rdx, [rbp-0xE0]
       mov      r8, r13
       mov      r9, gword ptr [rbp-0x150]
       mov      rcx, gword ptr [r15+0x10]
       call     [r15+0x18]System.Func`4[System.__Canon,System.__Canon,System.__Canon,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Invoke(System.__Canon,System.__Canon,System.__Canon):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this
       nop      
 
G_M000_IG50:                ;; offset=0x0677
       mov      r9, gword ptr [rbp-0x148]
       mov      rdi, gword ptr [r9+0x98]
       mov      rdx, qword ptr [rdi+0x160]
       test     rdx, rdx
       jle      SHORT G_M000_IG52
 
G_M000_IG51:                ;; offset=0x0691
       dec      rdx
       mov      qword ptr [rdi+0x160], rdx
 
G_M000_IG52:                ;; offset=0x069B
       xor      rdx, rdx
       mov      gword ptr [rbp-0xE8], rdx
 
G_M000_IG53:                ;; offset=0x06A4
       vmovdqu  xmm0, xmmword ptr [rbp-0xE0]
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
 
G_M000_IG54:                ;; offset=0x06B1
       mov      rdx, gword ptr [rbp-0x48]
       mov      rdi, rdx
       test     rdi, rdi
       je       SHORT G_M000_IG56
 
G_M000_IG55:                ;; offset=0x06BD
       mov      rcx, 0x7FF9D70947B0
       cmp      qword ptr [rdi], rcx
       jne      G_M000_IG119
       xor      rdi, rdi
 
G_M000_IG56:                ;; offset=0x06D2
       test     rdi, rdi
       je       G_M000_IG123
       jmp      G_M000_IG120
 
G_M000_IG57:                ;; offset=0x06E0
       mov      rax, 0x7FF9D75C1030
       cmp      qword ptr [r14], rax
       jne      G_M000_IG27
 
G_M000_IG58:                ;; offset=0x06F3
       mov      r15, r14
       mov      r13, gword ptr [rsi+0x20]
       test     r13, r13
       je       G_M000_IG27
 
G_M000_IG59:                ;; offset=0x0703
       mov      rax, 0x7FF9D76AFB58
       cmp      qword ptr [r13], rax
       jne      G_M000_IG27
 
G_M000_IG60:                ;; offset=0x0717
       cmp      rdi, gword ptr [r13+0x08]
       jne      G_M000_IG27
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rax+0x98]
       mov      edx, dword ptr [rcx+0x38]
       add      edx, 2
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG122
       shl      rdx, 5
 
G_M000_IG61:                ;; offset=0x0743
       vmovdqu  ymm0, ymmword ptr [rax+rdx+0x10]
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
 
G_M000_IG62:                ;; offset=0x074E
       mov      rax, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rax+0xB0]
       cmp      dword ptr [rbp-0x64], 42
       jne      G_M000_IG93
       mov      edx, dword ptr [rbp-0x78]
       mov      r8, 0x7FF9D7648660
       cmp      qword ptr [rax], r8
       jne      G_M000_IG95
       mov      r8d, dword ptr [rax+0x08]
       cmp      r8d, edx
       jbe      G_M000_IG94
       mov      rsi, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG63:                ;; offset=0x078B
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x10]
       mov      rax, gword ptr [r13+0x18]
       mov      rcx, gword ptr [rdx+0x98]
       mov      rdx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG64:                ;; offset=0x07AA
       mov      r12, bword ptr [rbp+0x10]
       mov      r8, gword ptr [r12+0x10]
       cmp      byte  ptr [rsi+0x31], 0
       jne      SHORT G_M000_IG67
       cmp      byte  ptr [r12+0x40], 0
       je       SHORT G_M000_IG66
       movzx    r9, byte  ptr [rsi+0x32]
 
G_M000_IG65:                ;; offset=0x07C6
       mov      rcx, r13
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x48], rax
       xor      ecx, ecx
       mov      qword ptr [rbp-0x40], rcx
       jmp      SHORT G_M000_IG68
 
G_M000_IG66:                ;; offset=0x07DE
       xor      r9d, r9d
       jmp      SHORT G_M000_IG65
 
G_M000_IG67:                ;; offset=0x07E3
       mov      r9d, 1
       jmp      SHORT G_M000_IG65
 
G_M000_IG68:                ;; offset=0x07EB
       mov      rsi, gword ptr [r12+0x10]
       mov      r15, gword ptr [rsi+0x98]
       mov      rcx, qword ptr [r15+0x160]
       test     rcx, rcx
       jle      SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x0803
       dec      rcx
       mov      qword ptr [r15+0x160], rcx
 
G_M000_IG70:                ;; offset=0x080D
       add      dword ptr [r12+0x38], 2
 
G_M000_IG71:                ;; offset=0x0813
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
 
G_M000_IG72:                ;; offset=0x0820
       cmp      dword ptr [rbp-0x68], 0
       jl       G_M000_IG98
       mov      ecx, dword ptr [rbp-0x64]
       cmp      ecx, 51
       ja       SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x0832
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jae      G_M000_IG96
 
G_M000_IG74:                ;; offset=0x0846
       mov      ebx, dword ptr [rbp-0x6C]
 
G_M000_IG75:                ;; offset=0x0849
       mov      ecx, dword ptr [rbp-0x68]
       mov      edi, ecx
       not      edi
       test     ecx, ecx
       cmovge   edi, ecx
       mov      r14, gword ptr [rbp-0xC0]
       mov      rsi, qword ptr [rbp-0xB8]
       cmp      edi, dword ptr [r12+0x3C]
       jl       G_M000_IG97
 
G_M000_IG76:                ;; offset=0x086E
       lea      rcx, bword ptr [r12+0x48]
       cmp      ebx, dword ptr [rcx+0x08]
       jae      G_M000_IG122
       mov      r15d, ebx
       shl      r15, 4
       add      r15, bword ptr [rcx]
       mov      rcx, r15
       mov      rdx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [r15+0x08], rsi
       mov      dword ptr [r12+0x3C], edi
 
G_M000_IG77:                ;; offset=0x089A
       mov      eax, 1
       jmp      G_M000_IG129
 
G_M000_IG78:                ;; offset=0x08A4
       mov      rcx, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rcx+0x08]
 
G_M000_IG79:                ;; offset=0x08AC
       vmovdqu  xmm0, xmmword ptr [rcx+0x48]
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG80:                ;; offset=0x08B9
       lea      rdx, [rbp-0x128]
       lea      rcx, [rbp-0xA0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      gword ptr [rsp+0x20], rsi
       mov      dword ptr [rsp+0x28], ebx
       mov      r12, bword ptr [rbp+0x10]
       mov      r9, gword ptr [r12+0x10]
       mov      gword ptr [rsp+0x30], r9
       lea      r9, [rbp-0x48]
       mov      qword ptr [rsp+0x38], r9
       lea      r9, bword ptr [r12+0x38]
       lea      r8, [rbp-0xA0]
       mov      rcx, rdi
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG123
 
G_M000_IG81:                ;; offset=0x090D
       lea      r8, bword ptr [r12+0x48]
       cmp      byte  ptr [rsi+0x30], 0
       setne    r9b
       movzx    r9, r9b
       lea      r9d, [rbx+r9+0x01]
       mov      edx, dword ptr [rsi+0x28]
       mov      ecx, edx
       add      rcx, r9
       mov      eax, dword ptr [r8+0x08]
       cmp      rcx, rax
       ja       G_M000_IG88
       shl      r9, 4
       add      r9, bword ptr [r8]
       mov      bword ptr [rbp-0x128], r9
       mov      dword ptr [rbp-0x120], edx
       mov      r8, gword ptr [r12+0x10]
       mov      gword ptr [rsp+0x20], r8
       lea      r8, [rbp-0x88]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0x128]
       mov      r9, gword ptr [rsi+0x18]
       mov      rdx, r14
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG83
 
G_M000_IG82:                ;; offset=0x097D
       mov      r12, bword ptr [rbp+0x10]
       xor      eax, eax
       jmp      G_M000_IG129
 
G_M000_IG83:                ;; offset=0x0988
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x48], rax
 
G_M000_IG84:                ;; offset=0x0993
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       jmp      G_M000_IG123
 
G_M000_IG85:                ;; offset=0x099E
       lea      rdx, [rbp-0x48]
       mov      qword ptr [rsp+0x20], rdx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, rsi
       mov      r8d, ebx
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG123
       jmp      SHORT G_M000_IG82
 
G_M000_IG86:                ;; offset=0x09C4
       mov      rdx, rdi
       mov      rcx, rax
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       jmp      G_M000_IG09
 
G_M000_IG87:                ;; offset=0x09D7
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x48]
       test     r14d, r14d
       setne    r8b
       movzx    r8, r8b
       lea      r8d, [rbx+r8+0x01]
       mov      r9d, dword ptr [rsi+0x28]
       mov      eax, r8d
       mov      r10d, r9d
       add      rax, r10
       mov      r10d, dword ptr [rdx+0x08]
       cmp      rax, r10
       jbe      SHORT G_M000_IG89
 
G_M000_IG88:                ;; offset=0x0A05
       mov      r12, bword ptr [rbp+0x10]
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG89:                ;; offset=0x0A10
       mov      r8d, r8d
       shl      r8, 4
       add      r8, bword ptr [rdx]
       mov      bword ptr [rbp-0x128], r8
       mov      dword ptr [rbp-0x120], r9d
       lea      rcx, [rbp-0x128]
       mov      rdx, gword ptr [rsi+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      r8, gword ptr [r15+0x10]
       lea      r9, [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG82
       mov      rdx, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x48], rdx
       mov      r12, r15
       jmp      G_M000_IG84
 
G_M000_IG90:                ;; offset=0x0A5D
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG26
 
G_M000_IG91:                ;; offset=0x0A6E
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG26
 
G_M000_IG92:                ;; offset=0x0A7F
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG26
 
G_M000_IG93:                ;; offset=0x0A90
       lea      rcx, [rbp-0x80]
       mov      rdx, 0x2965DB6D5C8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG94:                ;; offset=0x0AAD
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG95:                ;; offset=0x0AB4
       mov      rcx, rax
       mov      r11, 0x7FF9D70A21D0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rsi, rax
       jmp      G_M000_IG63
 
G_M000_IG96:                ;; offset=0x0ACC
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      ebx, eax
       jmp      G_M000_IG75
 
G_M000_IG97:                ;; offset=0x0ADD
       mov      rcx, r12
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG76
 
G_M000_IG98:                ;; offset=0x0AED
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       cmp      eax, dword ptr [r12+0x3C]
       jge      SHORT G_M000_IG99
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG99:                ;; offset=0x0B13
       mov      rcx, gword ptr [r12+0x10]
       mov      rcx, gword ptr [rcx+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG102
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      ebx, eax
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
 
G_M000_IG100:                ;; offset=0x0B44
       vmovdqu  xmm0, xmmword ptr [rbp-0xC0]
       vmovdqu  xmmword ptr [rbp-0x138], xmm0
 
G_M000_IG101:                ;; offset=0x0B54
       mov      edx, ebx
       lea      r9, [rbp-0x138]
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      r12, bword ptr [rbp+0x10]
       jmp      G_M000_IG77
 
G_M000_IG102:                ;; offset=0x0B6F
       lea      rbx, bword ptr [r12+0x48]
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG122
       mov      rcx, bword ptr [rbx]
       mov      eax, eax
       shl      rax, 4
       xor      edx, edx
       mov      qword ptr [rcx+rax], rdx
       mov      qword ptr [rcx+rax+0x08], rdx
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [r12+0x3C], eax
       mov      rcx, gword ptr [r12+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [r12+0x38]
       inc      eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG122
       shl      rax, 5
       lea      rbx, bword ptr [rcx+rax+0x10]
       cmp      dword ptr [rbx+0x1C], 25
       jne      G_M000_IG106
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_StoresCapturedLocal():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG103
       lea      rsi, bword ptr [r12+0x48]
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG122
       mov      ebx, eax
       shl      rbx, 4
       add      rbx, bword ptr [rsi]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0xB8]
       mov      qword ptr [rbx+0x08], rcx
       jmp      G_M000_IG112
 
G_M000_IG103:                ;; offset=0x0C25
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
 
G_M000_IG104:                ;; offset=0x0C30
       vmovdqu  xmm0, xmmword ptr [rbp-0xC0]
       vmovdqu  xmmword ptr [rbp-0x138], xmm0
 
G_M000_IG105:                ;; offset=0x0C40
       lea      r8, [rbp-0x138]
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StoreCapturedLocal(int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG112
 
G_M000_IG106:                ;; offset=0x0C55
       cmp      dword ptr [rbx+0x1C], 71
       jne      SHORT G_M000_IG110
 
G_M000_IG107:                ;; offset=0x0C5B
       vmovdqu  xmm0, xmmword ptr [r12+0x48]
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG108:                ;; offset=0x0C6A
       vmovdqu  xmm0, xmmword ptr [rbp-0xC0]
       vmovdqu  xmmword ptr [rbp-0x138], xmm0
 
G_M000_IG109:                ;; offset=0x0C7A
       lea      rcx, [rbp-0x128]
       lea      r8, [rbp-0x138]
       mov      r9, gword ptr [r12+0x10]
       mov      r9, gword ptr [r9+0x98]
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      SHORT G_M000_IG112
 
G_M000_IG110:                ;; offset=0x0C9F
       cmp      dword ptr [rbx+0x1C], 30
       je       SHORT G_M000_IG111
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2965DB72BE0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG111:                ;; offset=0x0CD3
       cmp      gword ptr [rbp-0xC0], 0
       jne      SHORT G_M000_IG112
       lea      rcx, [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
 
G_M000_IG112:                ;; offset=0x0CFD
       inc      dword ptr [r12+0x38]
       jmp      G_M000_IG77
 
G_M000_IG113:                ;; offset=0x0D07
       lea      rdx, [rbp-0x48]
       mov      qword ptr [rsp+0x20], rdx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, rsi
       mov      r8d, ebx
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG123
       jmp      G_M000_IG82
 
G_M000_IG114:                ;; offset=0x0D30
       mov      rdx, rdi
       mov      rcx, 0x7FF9D77D5648
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       test     r14, r14
       je       G_M000_IG17
       lea      edx, [rbx+0x01]
       mov      eax, dword ptr [rsi+0x28]
       mov      r8d, edx
       mov      r10d, eax
       add      r8, r10
       mov      r10d, r13d
       cmp      r8, r10
       ja       G_M000_IG88
       shl      rdx, 4
       add      rdx, r15
       mov      bword ptr [rbp-0x128], rdx
       mov      dword ptr [rbp-0x120], eax
       lea      rdx, [rbp-0x128]
       lea      rcx, [rbp-0xD0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       lea      r8, [rbp-0x48]
       mov      qword ptr [rsp+0x20], r8
       mov      r8, gword ptr [rsi+0x18]
       lea      rdx, [rbp-0xD0]
       mov      rcx, r14
       mov      r9, gword ptr [rbp-0x148]
       call     [Lokad.Lython.Runtime.LythonRuntime+MinMaxCallable:TryInvokeNumericOperands(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool:this]
       test     eax, eax
       je       G_M000_IG113
       jmp      G_M000_IG54
 
G_M000_IG115:                ;; offset=0x0DC2
       mov      rdx, rdi
       mov      rcx, rax
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       jmp      G_M000_IG18
 
G_M000_IG116:                ;; offset=0x0DD5
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r13, rax
       jmp      G_M000_IG21
 
G_M000_IG117:                ;; offset=0x0DE6
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r13, rax
       jmp      G_M000_IG21
 
G_M000_IG118:                ;; offset=0x0DF7
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r13, rax
       jmp      G_M000_IG21
 
G_M000_IG119:                ;; offset=0x0E08
       mov      rcx, 0x7FF9D7500AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       jmp      G_M000_IG56
 
G_M000_IG120:                ;; offset=0x0E1F
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15+0x08]
       mov      rcx, gword ptr [rcx+0xA0]
       mov      r11, 0x7FF9D70A21C0
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       jne      SHORT G_M000_IG121
       mov      rcx, rdi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG121:                ;; offset=0x0E48
       mov      gword ptr [r15+0x28], rdi
       jmp      G_M000_IG82
 
G_M000_IG122:                ;; offset=0x0E51
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG123:                ;; offset=0x0E57
       cmp      dword ptr [rsi+0x2C], 0
       jne      G_M000_IG137
 
G_M000_IG124:                ;; offset=0x0E61
       mov      r12, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r12+0x08]
       mov      rdx, gword ptr [rdx+0x98]
       mov      r8d, dword ptr [r12+0x38]
       cmp      r8d, dword ptr [rdx+0x08]
       jae      G_M000_IG140
       shl      r8, 5
       lea      rdx, bword ptr [rdx+r8+0x10]
 
G_M000_IG125:                ;; offset=0x0E89
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0x138], xmm0
 
G_M000_IG126:                ;; offset=0x0E96
       lea      r8, [rbp-0x138]
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG127:                ;; offset=0x0EA6
       mov      eax, 1
 
G_M000_IG128:                ;; offset=0x0EAB
       vzeroupper 
       add      rsp, 344
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG129:                ;; offset=0x0EC2
       vzeroupper 
       add      rsp, 344
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG130:                ;; offset=0x0ED9
       mov      rcx, rbx
       mov      rdx, 0x2965DB6D5C8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG131:                ;; offset=0x0EF5
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG132:                ;; offset=0x0EFC
       mov      rcx, rax
       mov      r11, 0x7FF9D70A21B8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rsi, rax
       jmp      G_M000_IG03
 
G_M000_IG133:                ;; offset=0x0F14
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG05
 
G_M000_IG134:                ;; offset=0x0F25
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG05
 
G_M000_IG135:                ;; offset=0x0F36
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG05
 
G_M000_IG136:                ;; offset=0x0F47
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2965DB6AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG137:                ;; offset=0x0F75
       mov      r12, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r12+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [r12+0x38]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG140
       shl      rax, 5
       cmp      dword ptr [rcx+rax+0x2C], 15
       jne      G_M000_IG124
       mov      rcx, gword ptr [r12+0x10]
       mov      rax, gword ptr [r12+0x08]
       mov      rax, gword ptr [rax+0x98]
       mov      edx, dword ptr [r12+0x38]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG140
       shl      rdx, 5
       mov      rdi, gword ptr [rax+rdx+0x10]
       mov      r14, gword ptr [rcx+0x98]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG138
       mov      rcx, r14
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG138:                ;; offset=0x0FED
       mov      edx, ebx
       add      edx, dword ptr [rsi+0x2C]
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       add      r12, 72
       mov      ecx, dword ptr [rsi+0x2C]
       mov      eax, ebx
       mov      edx, ecx
       add      rax, rdx
       mov      edx, dword ptr [r12+0x08]
       cmp      rax, rdx
       jbe      SHORT G_M000_IG139
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG139:                ;; offset=0x101A
       mov      eax, ebx
       shl      rax, 4
       add      rax, bword ptr [r12]
       mov      bword ptr [rbp-0x128], rax
       mov      dword ptr [rbp-0x120], ecx
       lea      rcx, [rbp-0x128]
       call     [System.MemoryExtensions:Reverse[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       jmp      G_M000_IG127
 
G_M000_IG140:                ;; offset=0x1043
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG141:                ;; offset=0x1049
       sub      rsp, 72
 
G_M000_IG142:                ;; offset=0x104D
       mov      r12, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [r12+0x10]
       mov      r15, gword ptr [rsi+0x98]
       mov      rcx, qword ptr [r15+0x160]
       test     rcx, rcx
       jle      SHORT G_M000_IG144
 
G_M000_IG143:                ;; offset=0x1069
       dec      rcx
       mov      qword ptr [r15+0x160], rcx
 
G_M000_IG144:                ;; offset=0x1073
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG145:                ;; offset=0x107B
       sub      rsp, 72
 
G_M000_IG146:                ;; offset=0x107F
       mov      rdx, rcx
       mov      rcx, 0x7FF9D71A2168
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG148
 
G_M000_IG147:                ;; offset=0x1096
       xor      eax, eax
       jmp      SHORT G_M000_IG149
 
G_M000_IG148:                ;; offset=0x109A
       lea      r8, [rbp-0xE8]
       mov      rcx, rax
       mov      rdx, gword ptr [rbp-0x150]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG149:                ;; offset=0x10B9
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG150:                ;; offset=0x10C1
       sub      rsp, 72
 
G_M000_IG151:                ;; offset=0x10C5
       mov      rcx, gword ptr [rbp-0xE8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG152:                ;; offset=0x10D2
       sub      rsp, 72
 
G_M000_IG153:                ;; offset=0x10D6
       mov      r9, gword ptr [rbp-0x148]
       mov      rdi, gword ptr [r9+0x98]
       mov      rcx, qword ptr [rdi+0x160]
       test     rcx, rcx
       jle      SHORT G_M000_IG155
 
G_M000_IG154:                ;; offset=0x10F0
       dec      rcx
       mov      qword ptr [rdi+0x160], rcx
 
G_M000_IG155:                ;; offset=0x10FA
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG156:                ;; offset=0x1102
       sub      rsp, 72
 
G_M000_IG157:                ;; offset=0x1106
       mov      rdx, rcx
       mov      rcx, 0x7FF9D71A2168
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbx, rax
       test     rbx, rbx
       jne      SHORT G_M000_IG159
 
G_M000_IG158:                ;; offset=0x1120
       xor      eax, eax
       jmp      SHORT G_M000_IG160
 
G_M000_IG159:                ;; offset=0x1124
       mov      rcx, gword ptr [rbp-0x140]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       lea      r8, [rbp-0x90]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG160:                ;; offset=0x114C
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG161:                ;; offset=0x1154
       sub      rsp, 72
 
G_M000_IG162:                ;; offset=0x1158
       mov      rcx, gword ptr [rbp-0x90]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 4453

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0xB90
       lea      rbp, [rsp+0xB90]
       xor      eax, eax
       mov      qword ptr [rbp-0xB48], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0xB40], xmm4
       vmovdqa  xmmword ptr [rbp-0xB30], xmm4
       mov      rax, -0xAE0
 
G_M000_IG246:                ;; offset=0x0037
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG246
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
 
G_M000_IG02:                ;; offset=0x0063
       mov      dword ptr [rbp-0x62C], 0x3E8
       mov      rax, bword ptr [rbp+0x30]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      rax, bword ptr [rbp+0x38]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      gword ptr [rbp-0x40], rax
       jmp      G_M000_IG227
 
G_M000_IG03:                ;; offset=0x00AC
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG233
       mov      edx, eax
       imul     rdx, rdx, 32
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x58], rcx
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x190], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x638], rax
       mov      rdx, gword ptr [rbp-0x638]
       mov      rcx, gword ptr [rbp-0x190]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG04:                ;; offset=0x010F
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0xE4], eax
       cmp      dword ptr [rbp-0xE4], 72
       ja       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0128
       mov      eax, dword ptr [rbp-0xE4]
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG06:                ;; offset=0x0144
       jmp      G_M000_IG213
 
G_M000_IG07:                ;; offset=0x0149
       mov      rcx, 0x7FF9D77FA948
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG231
 
G_M000_IG08:                ;; offset=0x0167
       mov      rcx, 0x7FF9D77FA94C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5B8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x5C0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x5C4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x640], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x640]
       mov      rdx, gword ptr [rbp-0x5C0]
       mov      r8d, dword ptr [rbp-0x5C4]
       mov      rcx, gword ptr [rbp-0x5B8]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadLocal(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x648], rax
       mov      r9, gword ptr [rbp-0x648]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG217
 
G_M000_IG09:                ;; offset=0x0204
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, gword ptr [rbp-0x1C8]
       mov      gword ptr [rbp-0xB48], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      rdx, gword ptr [rbp-0xB48]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG216
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_IsUnassigned():bool:this]
       test     eax, eax
       je       G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0254
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_LocalNames():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rax, gword ptr [rbp-0x1E8]
       mov      gword ptr [rbp-0x610], rax
       mov      rcx, gword ptr [rbp-0x610]
       mov      rdx, 0x7FF9D77FA950
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x610]
       mov      gword ptr [rbp-0x650], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x654], eax
       mov      rcx, gword ptr [rbp-0x650]
       mov      edx, dword ptr [rbp-0x654]
       mov      r11, 0x7FF9D70A2950
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x1F0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x660], rax
       mov      rdx, gword ptr [rbp-0x660]
       mov      rcx, gword ptr [rbp-0x1F0]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG11:                ;; offset=0x02FB
       mov      rcx, 0x7FF9D77FAA58
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG12:                ;; offset=0x030F
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       jne      G_M000_IG14
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x598], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x5A0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      dword ptr [rbp-0x5A4], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x664], eax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9d, dword ptr [rbp-0x664]
       mov      rdx, gword ptr [rbp-0x5A0]
       mov      r8d, dword ptr [rbp-0x5A4]
       mov      rcx, gword ptr [rbp-0x598]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG13
       mov      rcx, 0x7FF9D77FAA5C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x5B0], rax
       mov      rax, bword ptr [rbp-0x5B0]
       add      dword ptr [rax], 2
       jmp      G_M000_IG217
 
G_M000_IG13:                ;; offset=0x03D1
       mov      rcx, 0x7FF9D77FAA60
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x03E0
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x590], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x670], rax
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x670]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8d, dword ptr [rbp-0x590]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG15
       mov      rcx, 0x7FF9D77FAA64
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG15:                ;; offset=0x0448
       mov      rcx, 0x7FF9D77FAA68
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      r9, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG217
 
G_M000_IG16:                ;; offset=0x0472
       mov      rcx, 0x7FF9D77FAA6C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG217
 
G_M000_IG17:                ;; offset=0x049C
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG18
       mov      rcx, 0x7FF9D77FAA70
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG18:                ;; offset=0x04D0
       mov      rcx, 0x7FF9D77FAA74
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG19:                ;; offset=0x04E4
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG20
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG20:                ;; offset=0x04FA
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG23
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG21:                ;; offset=0x0506
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x690], ymm0
 
G_M000_IG22:                ;; offset=0x0512
       lea      r8, [rbp-0x690]
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG217
 
G_M000_IG23:                ;; offset=0x0555
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG24:                ;; offset=0x0559
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x6B0], ymm0
 
G_M000_IG25:                ;; offset=0x0565
       lea      r8, [rbp-0x6B0]
       lea      rdx, [rbp-0x550]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG26:                ;; offset=0x0585
       vmovdqu  xmm0, xmmword ptr [rbp-0x550]
       vmovdqu  xmmword ptr [rbp-0x6C0], xmm0
 
G_M000_IG27:                ;; offset=0x0595
       lea      rdx, [rbp-0x6C0]
       lea      rcx, [rbp-0x560]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xAC0], rax
       mov      rcx, bword ptr [rbp-0xAC0]
       mov      rdx, gword ptr [rbp-0x560]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xAC0]
       mov      rcx, qword ptr [rbp-0x558]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG28
       mov      rcx, 0x7FF9D77FAA78
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x6C8], rax
       mov      rcx, gword ptr [rbp-0x6C8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG28:                ;; offset=0x0623
       mov      rcx, 0x7FF9D77FAA7C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG217
 
G_M000_IG29:                ;; offset=0x0641
       mov      rax, bword ptr [rbp+0x10]
       mov      bword ptr [rbp-0x2B8], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x2C0], rax
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x2C8], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x2D0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG30
       mov      rcx, 0x7FF9D77FAA80
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x2D0], rax
 
G_M000_IG30:                ;; offset=0x068E
       mov      rcx, bword ptr [rbp-0x2B8]
       mov      rdx, gword ptr [rbp-0x2C0]
       mov      r8, bword ptr [rbp-0x2C8]
       mov      r9, gword ptr [rbp-0x2D0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      SHORT G_M000_IG31
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG32
       mov      rcx, 0x7FF9D77FAA84
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG31:                ;; offset=0x06D9
       mov      rcx, 0x7FF9D77FAA88
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG32:                ;; offset=0x06ED
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG35
       mov      rcx, 0x7FF9D77FAA8C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG33:                ;; offset=0x0708
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x6E8], ymm0
 
G_M000_IG34:                ;; offset=0x0714
       lea      r8, [rbp-0x6E8]
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG217
 
G_M000_IG35:                ;; offset=0x0757
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG36:                ;; offset=0x075B
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x708], ymm0
 
G_M000_IG37:                ;; offset=0x0767
       lea      r8, [rbp-0x708]
       lea      rdx, [rbp-0x2E0]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG38:                ;; offset=0x0787
       vmovdqu  xmm0, xmmword ptr [rbp-0x2E0]
       vmovdqu  xmmword ptr [rbp-0x718], xmm0
 
G_M000_IG39:                ;; offset=0x0797
       lea      rdx, [rbp-0x718]
       lea      rcx, [rbp-0x2F0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xAC8], rax
       mov      rcx, bword ptr [rbp-0xAC8]
       mov      rdx, gword ptr [rbp-0x2F0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xAC8]
       mov      rcx, qword ptr [rbp-0x2E8]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG40
       mov      rcx, 0x7FF9D77FAA90
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x720], rax
       mov      rcx, gword ptr [rbp-0x720]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG40:                ;; offset=0x0825
       mov      rcx, 0x7FF9D77FAA94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG217
 
G_M000_IG41:                ;; offset=0x0843
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x238], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x238]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG216
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x728], rax
       mov      rdx, gword ptr [rbp-0x728]
       mov      rcx, 0x7FF9D759EAB0
       call     CORINFO_HELP_CHKCASTCLASS
       mov      gword ptr [rbp-0x240], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x248], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x24C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x250], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      ecx, dword ptr [rbp-0x250]
       sub      ecx, eax
       mov      dword ptr [rbp-0x72C], ecx
       mov      r9d, dword ptr [rbp-0x72C]
       lea      rcx, [rbp-0x260]
       mov      rdx, gword ptr [rbp-0x248]
       mov      r8d, dword ptr [rbp-0x24C]
       call     [System.MemoryExtensions:AsSpan[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, gword ptr [rbp-0x240]
       mov      gword ptr [rbp-0x268], rax
 
G_M000_IG42:                ;; offset=0x0924
       vmovdqu  xmm0, xmmword ptr [rbp-0x260]
       vmovdqu  xmmword ptr [rbp-0x278], xmm0
 
G_M000_IG43:                ;; offset=0x0934
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_StartsKeywordDefaultsOnly():bool:this]
       mov      dword ptr [rbp-0x27C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x288], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG44
       mov      rcx, 0x7FF9D77FAA98
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x288], rax
 
G_M000_IG44:                ;; offset=0x0970
       mov      rcx, 0x7FF9D77FAA9C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG45:                ;; offset=0x097F
       vmovdqu  xmm0, xmmword ptr [rbp-0x278]
       vmovdqu  xmmword ptr [rbp-0x740], xmm0
 
G_M000_IG46:                ;; offset=0x098F
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x748], rax
       mov      rax, gword ptr [rbp-0x748]
       mov      gword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0x740]
       mov      r8d, dword ptr [rbp-0x27C]
       mov      r9, gword ptr [rbp-0x288]
       mov      rcx, gword ptr [rbp-0x268]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x290], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x74C], eax
       mov      edx, dword ptr [rbp-0x74C]
       mov      rcx, bword ptr [rbp-0x290]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RestoreNativeExtent(int):this]
       jmp      G_M000_IG217
 
G_M000_IG47:                ;; offset=0x0A0B
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x1F8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x1FC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x750], eax
       mov      r9d, dword ptr [rbp-0x750]
       lea      rdx, [rbp-0x70]
       mov      r8d, dword ptr [rbp-0x1FC]
       mov      rcx, bword ptr [rbp-0x1F8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x758], rax
       mov      rdx, gword ptr [rbp-0x758]
       lea      rcx, [rbp-0x210]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x218], rax
 
G_M000_IG48:                ;; offset=0x0A99
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0x228], xmm0
 
G_M000_IG49:                ;; offset=0x0AA6
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x230], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG50
       mov      rcx, 0x7FF9D77FAAA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x230], rax
 
G_M000_IG50:                ;; offset=0x0AD2
       mov      rcx, 0x7FF9D77FAAA4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:                ;; offset=0x0AE1
       vmovdqu  xmm0, xmmword ptr [rbp-0x210]
       vmovdqu  xmmword ptr [rbp-0x768], xmm0
 
G_M000_IG52:                ;; offset=0x0AF1
       vmovdqu  xmm0, xmmword ptr [rbp-0x228]
       vmovdqu  xmmword ptr [rbp-0x778], xmm0
 
G_M000_IG53:                ;; offset=0x0B01
       mov      rcx, gword ptr [rbp-0x230]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x780], rax
       mov      r9, gword ptr [rbp-0x780]
       lea      r8, [rbp-0x778]
       lea      rcx, [rbp-0x768]
       mov      rdx, bword ptr [rbp-0x218]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG217
 
G_M000_IG54:                ;; offset=0x0B3E
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       lea      rax, [rbp-0x80]
       mov      qword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG55
       mov      rcx, 0x7FF9D77FAAA8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG55:                ;; offset=0x0B87
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG56
       mov      rcx, 0x7FF9D77FAAAC
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0x80]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG217
 
G_M000_IG56:                ;; offset=0x0BC1
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x790], xmm0
 
G_M000_IG57:                ;; offset=0x0BCE
       lea      rdx, [rbp-0x790]
       lea      rcx, [rbp-0x570]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xAD0], rax
       mov      rcx, bword ptr [rbp-0xAD0]
       mov      rdx, gword ptr [rbp-0x570]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xAD0]
       mov      rcx, qword ptr [rbp-0x568]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG58
       mov      rcx, 0x7FF9D77FAAB0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x798], rax
       mov      rcx, gword ptr [rbp-0x798]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG58:                ;; offset=0x0C5C
       mov      rcx, 0x7FF9D77FAAB4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG217
 
G_M000_IG59:                ;; offset=0x0C7A
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG60
       mov      rcx, 0x7FF9D77FAAB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG60:                ;; offset=0x0C9F
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x340], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x344], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x79C], eax
       mov      r9d, dword ptr [rbp-0x79C]
       lea      rdx, [rbp-0x118]
       mov      r8d, dword ptr [rbp-0x344]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       inc      eax
       mov      dword ptr [rbp-0x11C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x70]
       mov      gword ptr [rbp-0x128], rax
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorsExecutableLocals():bool:this]
       test     eax, eax
       jne      G_M000_IG63
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG62
       mov      rax, gword ptr [rbp-0x40]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x11C]
       jle      SHORT G_M000_IG61
       mov      rcx, 0x7FF9D77FAABC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG216
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 30
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x348], eax
       jmp      SHORT G_M000_IG64
 
G_M000_IG61:                ;; offset=0x0D8E
       mov      rcx, 0x7FF9D77FAAC0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG62:                ;; offset=0x0D9F
       mov      rcx, 0x7FF9D77FAAC4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG63:                ;; offset=0x0DAE
       xor      eax, eax
       mov      dword ptr [rbp-0x348], eax
 
G_M000_IG64:                ;; offset=0x0DB6
       movzx    rax, byte  ptr [rbp-0x348]
       mov      dword ptr [rbp-0x12C], eax
       cmp      dword ptr [rbp-0x12C], 0
       je       G_M000_IG71
       cmp      gword ptr [rbp-0x128], 0
       je       G_M000_IG68
 
G_M000_IG65:                ;; offset=0x0DDE
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x7B0], xmm0
 
G_M000_IG66:                ;; offset=0x0DEE
       lea      r8, [rbp-0x7B0]
       mov      rdx, gword ptr [rbp-0x128]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       je       G_M000_IG67
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG216
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x7B8], rax
       mov      rdx, gword ptr [rbp-0x7B8]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x358], rax
       mov      rax, gword ptr [rbp-0x358]
       mov      gword ptr [rbp-0x360], rax
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasActiveHandler():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG69
       mov      rax, gword ptr [rbp-0x360]
       mov      gword ptr [rbp-0x368], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x80]
       mov      gword ptr [rbp-0x370], rax
       jmp      SHORT G_M000_IG70
 
G_M000_IG67:                ;; offset=0x0EA4
       mov      rcx, 0x7FF9D77FAAC8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG71
 
G_M000_IG68:                ;; offset=0x0EB8
       mov      rcx, 0x7FF9D77FAACC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG71
 
G_M000_IG69:                ;; offset=0x0ECC
       mov      rcx, 0x7FF9D77FAAD0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x360]
       mov      gword ptr [rbp-0x368], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CurrentException():Lokad.Lython.Runtime.PyException:this]
       mov      gword ptr [rbp-0x370], rax
 
G_M000_IG70:                ;; offset=0x0F07
       mov      rcx, 0x7FF9D77FAAD4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x368]
       mov      rdx, gword ptr [rbp-0x370]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:SetCurrentException(Lokad.Lython.Runtime.PyException):Lokad.Lython.Runtime.PyException:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x378], rax
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG216
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x7BC], eax
       mov      edx, dword ptr [rbp-0x7BC]
       mov      rcx, bword ptr [rbp-0x378]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x380], rax
       mov      rax, bword ptr [rbp-0x380]
       add      dword ptr [rax], 2
       jmp      G_M000_IG227
 
G_M000_IG71:                ;; offset=0x0FA5
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x7D0], xmm0
 
G_M000_IG72:                ;; offset=0x0FB5
       lea      rdx, [rbp-0x7D0]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:set_YieldValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rcx, gword ptr [rbp+0x20]
       mov      edx, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:set_HasYield(bool):this]
       mov      rax, gword ptr [rbp+0x20]
       mov      byte  ptr [rax+0xF8], 1
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x350], rax
       mov      rax, bword ptr [rbp-0x350]
       inc      dword ptr [rax]
       cmp      dword ptr [rbp-0x12C], 0
       jne      SHORT G_M000_IG75
       cmp      gword ptr [rbp-0x128], 0
       je       SHORT G_M000_IG74
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0x128]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG73
       mov      rcx, 0x7FF9D77FAAD8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG227
 
G_M000_IG73:                ;; offset=0x1040
       mov      rcx, 0x7FF9D77FAADC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG75
 
G_M000_IG74:                ;; offset=0x1051
       mov      rcx, 0x7FF9D77FAAE0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG75:                ;; offset=0x1060
       mov      rcx, 0x7FF9D77FAAE4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG231
 
G_M000_IG76:                ;; offset=0x107E
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG77
       mov      rcx, 0x7FF9D77FAAE8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG77:                ;; offset=0x10A3
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG81
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG78:                ;; offset=0x10B3
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x7F0], ymm0
 
G_M000_IG79:                ;; offset=0x10BF
       lea      r8, [rbp-0x7F0]
       lea      rdx, [rbp-0x338]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xAD8], rax
       mov      rcx, bword ptr [rbp-0xAD8]
       mov      rdx, gword ptr [rbp-0x338]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xAD8]
       mov      rcx, qword ptr [rbp-0x330]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG80
       mov      rcx, 0x7FF9D77FAAEC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x7F8], rax
       mov      rcx, gword ptr [rbp-0x7F8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG80:                ;; offset=0x1153
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG87
 
G_M000_IG81:                ;; offset=0x1162
       mov      rax, gword ptr [rbp+0x20]
       cmp      gword ptr [rax+0x68], 0
       jne      G_M000_IG82
       mov      rcx, 0x7FF9D77FAAF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x308], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x30C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x7FC], eax
       mov      r8d, dword ptr [rbp-0x7FC]
       mov      edx, dword ptr [rbp-0x30C]
       mov      rcx, bword ptr [rbp-0x308]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rcx, 0x7FF9D71628A8
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      gword ptr [rbp-0x318], rax
       mov      rcx, gword ptr [rbp-0x318]
       mov      r8, gword ptr [rbp-0x138]
       xor      edx, edx
       call     CORINFO_HELP_ARRADDR_ST
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x808], rax
       mov      rdx, gword ptr [rbp-0x808]
       mov      rcx, gword ptr [rbp-0x318]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x320], rax
       mov      rcx, 0x7FF9D77F7DB8
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x328], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x810], rax
       mov      r9, gword ptr [rbp-0x810]
       mov      rdx, gword ptr [rbp-0x320]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x328]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:.ctor(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x20]
       lea      rcx, bword ptr [rax+0x68]
       mov      rdx, gword ptr [rbp-0x328]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG82:                ;; offset=0x1290
       mov      rcx, 0x7FF9D77FAAF4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rax+0x60]
       mov      rax, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rax+0x68]
       lea      rdx, [rbp-0x300]
       mov      rax, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rax+0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:Advance(System.Object,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.PyIterationResult:this]
 
G_M000_IG83:                ;; offset=0x12C6
       vmovdqu  xmm0, xmmword ptr [rbp-0x300]
       vmovdqu  xmmword ptr [rbp-0x820], xmm0
 
G_M000_IG84:                ;; offset=0x12D6
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG85:                ;; offset=0x12DA
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x840], ymm0
 
G_M000_IG86:                ;; offset=0x12E6
       lea      rdx, [rbp-0x820]
       lea      r8, [rbp-0x840]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
 
G_M000_IG87:                ;; offset=0x1300
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasYield():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG89
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x70]
       mov      gword ptr [rbp-0x140], rax
       cmp      gword ptr [rbp-0x140], 0
       je       SHORT G_M000_IG90
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0x140]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG88
       mov      rcx, 0x7FF9D77FAAF8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG227
 
G_M000_IG88:                ;; offset=0x1354
       mov      rcx, 0x7FF9D77FAAFC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x1365
       mov      rcx, 0x7FF9D77FAB00
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG90:                ;; offset=0x1379
       mov      rcx, 0x7FF9D77FAB04
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG231
 
G_M000_IG91:                ;; offset=0x1397
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG92
       mov      rcx, 0x7FF9D77FAB08
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG92:                ;; offset=0x13BC
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Imports():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ImportStatementSyntax]:this]
       mov      gword ptr [rbp-0x5D8], rax
       mov      rax, gword ptr [rbp-0x5D8]
       mov      gword ptr [rbp-0x618], rax
       mov      rcx, gword ptr [rbp-0x618]
       mov      rdx, 0x7FF9D77FAB10
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x618]
       mov      gword ptr [rbp-0x848], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ImportIndex():int:this]
       mov      dword ptr [rbp-0x84C], eax
       mov      rcx, gword ptr [rbp-0x848]
       mov      edx, dword ptr [rbp-0x84C]
       mov      r11, 0x7FF9D70A2960
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x88], rax
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG93
       mov      rcx, 0x7FF9D77FAC18
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r9, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG217
 
G_M000_IG93:                ;; offset=0x1471
       lea      rcx, [rbp-0x5E8]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
 
G_M000_IG94:                ;; offset=0x1489
       vmovdqu  xmm0, xmmword ptr [rbp-0x5E8]
       vmovdqu  xmmword ptr [rbp-0x860], xmm0
 
G_M000_IG95:                ;; offset=0x1499
       lea      rdx, [rbp-0x860]
       lea      rcx, [rbp-0x5F8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xAE0], rax
       mov      rcx, bword ptr [rbp-0xAE0]
       mov      rdx, gword ptr [rbp-0x5F8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xAE0]
       mov      rcx, qword ptr [rbp-0x5F0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG96
       mov      rcx, 0x7FF9D77FAC1C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x868], rax
       mov      rcx, gword ptr [rbp-0x868]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG96:                ;; offset=0x1527
       mov      rcx, 0x7FF9D77FAC20
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG217
 
G_M000_IG97:                ;; offset=0x1545
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG98
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG99
       mov      rcx, 0x7FF9D77FAC24
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG98:                ;; offset=0x1584
       mov      rcx, 0x7FF9D77FAC28
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG99:                ;; offset=0x1598
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG100
       mov      rcx, 0x7FF9D77FAC2C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG217
 
G_M000_IG100:                ;; offset=0x15CA
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG101:                ;; offset=0x15CE
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x888], ymm0
 
G_M000_IG102:                ;; offset=0x15DA
       lea      r8, [rbp-0x888]
       lea      rdx, [rbp-0x540]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xAE8], rax
       mov      rcx, bword ptr [rbp-0xAE8]
       mov      rdx, gword ptr [rbp-0x540]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xAE8]
       mov      rcx, qword ptr [rbp-0x538]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG103
       mov      rcx, 0x7FF9D77FAC30
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x890], rax
       mov      rcx, gword ptr [rbp-0x890]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG103:                ;; offset=0x166E
       mov      rcx, 0x7FF9D77FAC34
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG217
 
G_M000_IG104:                ;; offset=0x168C
       mov      rcx, 0x7FF9D77FAC38
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x5D0], rax
       mov      rax, gword ptr [rbp-0x5D0]
       mov      gword ptr [rbp-0xB48], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rdx, gword ptr [rbp-0xB48]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG216
       mov      ecx, eax
       lea      rcx, bword ptr [rdx+8*rcx+0x10]
       mov      rcx, gword ptr [rcx]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x898], rax
       mov      r9, gword ptr [rbp-0x898]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG217
 
G_M000_IG105:                ;; offset=0x170E
       mov      rcx, 0x7FF9D77FAC3C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x588], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x58C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8A0], rax
       mov      r8, gword ptr [rbp-0x8A0]
       mov      edx, dword ptr [rbp-0x58C]
       mov      rcx, gword ptr [rbp-0x588]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x8A8], rax
       mov      r9, gword ptr [rbp-0x8A8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG217
 
G_M000_IG106:                ;; offset=0x178F
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG107
       mov      rcx, 0x7FF9D77FAC40
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG107:                ;; offset=0x17B4
       mov      rcx, 0x7FF9D77FAC44
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x578], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x578]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG216
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x580], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8B0], rax
       mov      rdx, gword ptr [rbp-0x8B0]
       mov      rcx, gword ptr [rbp-0x580]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x8B8], rax
       mov      r9, gword ptr [rbp-0x8B8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG217
 
G_M000_IG108:                ;; offset=0x1852
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG109
       mov      rcx, 0x7FF9D77FAC48
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG109:                ;; offset=0x1877
       mov      rcx, 0x7FF9D77FAC4C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8C0], rax
       mov      rdx, gword ptr [rbp-0x8C0]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG217
 
G_M000_IG110:                ;; offset=0x18AD
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG111
       mov      rcx, 0x7FF9D77FAC50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG111:                ;; offset=0x18D2
       mov      rcx, 0x7FF9D77FAC54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x510], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x510]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG216
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x518], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x520], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x524], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x8C4], eax
       mov      r8d, dword ptr [rbp-0x8C4]
       mov      edx, dword ptr [rbp-0x524]
       mov      rcx, bword ptr [rbp-0x520]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x530], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8D0], rax
       mov      r9, gword ptr [rbp-0x8D0]
       mov      rdx, gword ptr [rbp-0x530]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x518]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG217
 
G_M000_IG112:                ;; offset=0x19AD
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG113
       mov      rcx, 0x7FF9D77FAC58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG113:                ;; offset=0x19D2
       mov      rcx, 0x7FF9D77FAC5C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x4D8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x4E0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x4E8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x4E8]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG216
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x4F0], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4F8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4FC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x8D4], eax
       mov      r8d, dword ptr [rbp-0x8D4]
       mov      edx, dword ptr [rbp-0x4FC]
       mov      rcx, bword ptr [rbp-0x4F8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x508], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8E0], rax
       mov      rax, gword ptr [rbp-0x8E0]
       mov      gword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp-0x4E0]
       mov      r8, gword ptr [rbp-0x4F0]
       mov      r9, gword ptr [rbp-0x508]
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x4D8]
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG217
 
G_M000_IG114:                ;; offset=0x1AE2
       mov      rcx, 0x7FF9D77FAC60
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4C0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x4C4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x4C8], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4D0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x8E4], eax
       mov      edx, dword ptr [rbp-0x8E4]
       mov      rcx, bword ptr [rbp-0x4D0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x8F0], rax
       mov      r9, gword ptr [rbp-0x8F0]
       mov      edx, dword ptr [rbp-0x4C4]
       mov      r8d, dword ptr [rbp-0x4C8]
       mov      rcx, bword ptr [rbp-0x4C0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishValue(int,int,System.Object):this]
       jmp      G_M000_IG217
 
G_M000_IG115:                ;; offset=0x1B8D
       mov      rcx, 0x7FF9D77FAC64
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4B0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x8F4], eax
       mov      edx, dword ptr [rbp-0x8F4]
       mov      rcx, bword ptr [rbp-0x4B0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4B8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x8F8], eax
       mov      edx, dword ptr [rbp-0x8F8]
       mov      rcx, bword ptr [rbp-0x4B8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG217
 
G_M000_IG116:                ;; offset=0x1C11
       mov      rcx, 0x7FF9D77FAC68
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4A0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4A4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x4A8], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x900], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x900]
       mov      edx, dword ptr [rbp-0x4A4]
       mov      r8d, dword ptr [rbp-0x4A8]
       mov      rcx, bword ptr [rbp-0x4A0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x908], rax
       mov      r9, gword ptr [rbp-0x908]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG217
 
G_M000_IG117:                ;; offset=0x1CB5
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG119
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG118
       mov      rcx, 0x7FF9D77FAC6C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG231
 
G_M000_IG118:                ;; offset=0x1CEE
       mov      rcx, 0x7FF9D77FAC70
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG119:                ;; offset=0x1CFD
       mov      rcx, bword ptr [rbp+0x48]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG123
       mov      rax, bword ptr [rbp+0x48]
       mov      r8d, dword ptr [rax+0x08]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       je       SHORT G_M000_IG122
       mov      rcx, 0x7FF9D77FAC74
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x48]
 
G_M000_IG120:                ;; offset=0x1D38
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x918], xmm0
 
G_M000_IG121:                ;; offset=0x1D44
       lea      r9, [rbp-0x918]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp-0xE8], 2
       jmp      G_M000_IG231
 
G_M000_IG122:                ;; offset=0x1D6C
       mov      rcx, 0x7FF9D77FAC78
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG123:                ;; offset=0x1D7B
       mov      rcx, 0x7FF9D77FAC7C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x490], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x494], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x498], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x920], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x920]
       mov      edx, dword ptr [rbp-0x494]
       mov      r8d, dword ptr [rbp-0x498]
       mov      rcx, bword ptr [rbp-0x490]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0x928], rax
       mov      r9, gword ptr [rbp-0x928]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG217
 
G_M000_IG124:                ;; offset=0x1E1F
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG125
       mov      rcx, 0x7FF9D77FAC80
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG125:                ;; offset=0x1E44
       mov      rcx, 0x7FF9D77FAC84
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG217
 
G_M000_IG126:                ;; offset=0x1E6B
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG127
       mov      rcx, 0x7FF9D77FAC88
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG127:                ;; offset=0x1E90
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG128
       mov      rcx, 0x7FF9D77FAC8C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG217
 
G_M000_IG128:                ;; offset=0x1EBF
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG129:                ;; offset=0x1EC3
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x948], ymm0
 
G_M000_IG130:                ;; offset=0x1ECF
       lea      r8, [rbp-0x948]
       lea      rdx, [rbp-0x488]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xAF0], rax
       mov      rcx, bword ptr [rbp-0xAF0]
       mov      rdx, gword ptr [rbp-0x488]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xAF0]
       mov      rcx, qword ptr [rbp-0x480]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG131
       mov      rcx, 0x7FF9D77FAC90
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x950], rax
       mov      rcx, gword ptr [rbp-0x950]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG131:                ;; offset=0x1F63
       mov      rcx, 0x7FF9D77FAC94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG217
 
G_M000_IG132:                ;; offset=0x1F84
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       mov      dword ptr [rbp-0x8C], eax
       cmp      dword ptr [rbp-0x8C], 0
       je       SHORT G_M000_IG133
       mov      rcx, 0x7FF9D77FAC98
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x8C]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG133:                ;; offset=0x1FE3
       mov      rcx, 0x7FF9D77FAC9C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG217
 
G_M000_IG134:                ;; offset=0x2004
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG135
       mov      rcx, 0x7FF9D77FACA0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG135:                ;; offset=0x2032
       mov      rcx, 0x7FF9D77FACA4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG138
 
G_M000_IG136:                ;; offset=0x2043
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG140
 
G_M000_IG137:                ;; offset=0x2061
       mov      rcx, 0x7FF9D77FACA8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG138:                ;; offset=0x2070
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x38], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       mov      dword ptr [rbp-0x90], eax
       cmp      dword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG139
       mov      rcx, 0x7FF9D77FACAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x90]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG139:                ;; offset=0x20D8
       mov      rcx, 0x7FF9D77FACB0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG140:                ;; offset=0x20EC
       mov      rcx, 0x7FF9D77FACB4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG141:                ;; offset=0x2100
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG142
       mov      rcx, 0x7FF9D77FACB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG217
 
G_M000_IG142:                ;; offset=0x2135
       mov      rcx, 0x7FF9D77FACBC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG151
 
G_M000_IG143:                ;; offset=0x2149
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG149
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x294], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x294]
       jne      G_M000_IG148
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x2A0], rax
       mov      rax, gword ptr [rbp-0x2A0]
       mov      gword ptr [rbp-0xB48], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rdx, gword ptr [rbp-0xB48]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG216
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x958], rax
       mov      rdx, gword ptr [rbp-0x958]
       mov      rcx, 0x7FF9D77F5D30
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x98], rax
       cmp      gword ptr [rbp-0x98], 0
       je       G_M000_IG147
       mov      rcx, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       mov      gword ptr [rbp-0xA0], rax
       cmp      gword ptr [rbp-0xA0], 0
       je       G_M000_IG146
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:get_CanUnpackDirectly():bool:this]
       test     eax, eax
       je       G_M000_IG145
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rsp+0x20], rax
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x28], eax
 
G_M000_IG144:                ;; offset=0x2256
       lea      rdx, [rbp-0x2B0]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xA0]
       mov      r9, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xAF8], rax
       mov      rcx, bword ptr [rbp-0xAF8]
       mov      rdx, gword ptr [rbp-0x2B0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xAF8]
       mov      rcx, qword ptr [rbp-0x2A8]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      G_M000_IG150
       mov      rcx, 0x7FF9D77FACC0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x960], rax
       mov      rcx, gword ptr [rbp-0x960]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG145:                ;; offset=0x22F5
       mov      rcx, 0x7FF9D77FACC4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG146:                ;; offset=0x2306
       mov      rcx, 0x7FF9D77FACC8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG147:                ;; offset=0x2317
       mov      rcx, 0x7FF9D77FACCC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG148:                ;; offset=0x2328
       mov      rcx, 0x7FF9D77FACD0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG149:                ;; offset=0x2339
       mov      rcx, 0x7FF9D77FACD4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x234A
       mov      rcx, 0x7FF9D77FACD8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG217
 
G_M000_IG151:                ;; offset=0x236B
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x428], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x964], eax
       mov      edx, dword ptr [rbp-0x964]
       lea      r8, [rbp-0xA8]
       lea      r9, [rbp-0xB8]
       mov      rcx, bword ptr [rbp-0x428]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryAdvanceNativeIteration(int,byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG155
       movzx    rax, byte  ptr [rbp-0xA8]
       test     eax, eax
       je       SHORT G_M000_IG154
       mov      rcx, 0x7FF9D77FACDC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG152:                ;; offset=0x23D3
       vmovdqu  xmm0, xmmword ptr [rbp-0xB8]
       vmovdqu  xmmword ptr [rbp-0x978], xmm0
 
G_M000_IG153:                ;; offset=0x23E3
       lea      r9, [rbp-0x978]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG217
 
G_M000_IG154:                ;; offset=0x2401
       mov      rcx, 0x7FF9D77FACE0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x440], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x97C], eax
       mov      edx, dword ptr [rbp-0x97C]
       mov      rcx, bword ptr [rbp-0x440]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x10], eax
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG217
 
G_M000_IG155:                ;; offset=0x2465
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG156
       mov      rcx, 0x7FF9D77FACE4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG156:                ;; offset=0x248A
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG157
       mov      rcx, 0x7FF9D77FACE8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG217
 
G_M000_IG157:                ;; offset=0x24B9
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG158:                ;; offset=0x24BD
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x9A0], ymm0
 
G_M000_IG159:                ;; offset=0x24C9
       lea      r8, [rbp-0x9A0]
       lea      rdx, [rbp-0x438]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB00], rax
       mov      rcx, bword ptr [rbp-0xB00]
       mov      rdx, gword ptr [rbp-0x438]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB00]
       mov      rcx, qword ptr [rbp-0x430]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG160
       mov      rcx, 0x7FF9D77FACEC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x9A8], rax
       mov      rcx, gword ptr [rbp-0x9A8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG160:                ;; offset=0x255D
       mov      rcx, 0x7FF9D77FACF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG217
 
G_M000_IG161:                ;; offset=0x257E
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x3C8], rax
       mov      rax, gword ptr [rbp-0x3C8]
       mov      gword ptr [rbp-0x620], rax
       mov      rcx, gword ptr [rbp-0x620]
       mov      rdx, 0x7FF9D77FACF8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x620]
       mov      gword ptr [rbp-0x9B0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x9B4], eax
       mov      rcx, gword ptr [rbp-0x9B0]
       mov      edx, dword ptr [rbp-0x9B4]
       mov      r11, 0x7FF9D70A2958
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0xC4], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x3D0], rax
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rbp-0x9B8], eax
       mov      edx, dword ptr [rbp-0x9B8]
       mov      rcx, bword ptr [rbp-0x3D0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0xD0], rax
       mov      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x28], rax
       lea      rax, [rbp-0xD8]
       mov      qword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG165
       cmp      gword ptr [rbp-0xD8], 0
       je       SHORT G_M000_IG163
       mov      rax, gword ptr [rbp-0xD8]
       mov      gword ptr [rbp-0x628], rax
       mov      rcx, gword ptr [rbp-0x628]
 
G_M000_IG162:                ;; offset=0x26B3
       mov      rdx, 0x7FF9D77FAE00
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x628]
       mov      gword ptr [rbp-0x9C0], rax
       mov      rdx, gword ptr [rbp-0x9C0]
       mov      rcx, 0x7FF9D7500AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x148], rax
       cmp      gword ptr [rbp-0x148], 0
       je       SHORT G_M000_IG164
       mov      rax, gword ptr [rbp-0x148]
       mov      gword ptr [rbp-0x50], rax
       jmp      G_M000_IG224
 
G_M000_IG163:                ;; offset=0x2707
       mov      rcx, 0x7FF9D77FAF08
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG164:                ;; offset=0x271B
       mov      rcx, 0x7FF9D77FAF0C
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x420], xmm0
       vmovdqu  xmmword ptr [rbp-0x418], xmm0
       mov      rdx, gword ptr [rbp-0xD8]
       mov      rcx, 0x7FF9D76B6708
       call     CORINFO_HELP_CHKCASTCLASS
       mov      gword ptr [rbp-0x9C8], rax
       mov      r8, gword ptr [rbp-0x9C8]
       lea      rcx, [rbp-0x420]
       mov      rdx, 0x7FF9D77F6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:.ctor(System.__Canon):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rbp-0xB08], rax
       mov      rcx, bword ptr [rbp-0xB08]
       mov      rax, bword ptr [rbp-0xB08]
       cmp      byte  ptr [rax], al
       lea      rdx, [rbp-0x420]
       mov      r8d, 24
       vzeroupper 
       call     CORINFO_HELP_BULK_WRITEBARRIER
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG231
 
G_M000_IG165:                ;; offset=0x27D3
       cmp      gword ptr [rbp+0x20], 0
       jne      G_M000_IG168
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x150]
       mov      qword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG166
       mov      rcx, 0x7FF9D77FAF10
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG166:                ;; offset=0x2834
       cmp      gword ptr [rbp-0x150], 0
       je       G_M000_IG167
       mov      rcx, 0x7FF9D77FAF14
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x408], xmm0
       vmovdqu  xmmword ptr [rbp-0x400], xmm0
       lea      rcx, [rbp-0x408]
       mov      r8, gword ptr [rbp-0x150]
       mov      rdx, 0x7FF9D77F6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:.ctor(System.__Canon):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rbp-0xB10], rax
       mov      rcx, bword ptr [rbp-0xB10]
       mov      rax, bword ptr [rbp-0xB10]
       cmp      byte  ptr [rax], al
       lea      rdx, [rbp-0x408]
       mov      r8d, 24
       vzeroupper 
       call     CORINFO_HELP_BULK_WRITEBARRIER
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG231
 
G_M000_IG167:                ;; offset=0x28DD
       mov      rcx, 0x7FF9D77FAF18
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG168:                ;; offset=0x28F1
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x28], rax
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      r8d, dword ptr [rbp-0xC4]
       mov      r9, gword ptr [rbp-0xD0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       je       G_M000_IG172
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, 0x7FF9D77F6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_IsCompletedSuccessfully():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG170
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, 0x7FF9D77F6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_Result():System.__Canon:this]
       cmp      rax, gword ptr [rbp+0x20]
       je       SHORT G_M000_IG171
 
G_M000_IG169:                ;; offset=0x295D
       mov      rcx, 0x7FF9D77FAF1C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG170:                ;; offset=0x296C
       mov      rcx, 0x7FF9D77FAF20
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG231
 
G_M000_IG171:                ;; offset=0x29A5
       mov      rcx, 0x7FF9D77FAF24
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG217
 
G_M000_IG172:                ;; offset=0x29D1
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG173
       mov      rcx, 0x7FF9D77FAF28
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG217
 
G_M000_IG173:                ;; offset=0x2A41
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0x3E0]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG174:                ;; offset=0x2A76
       vmovdqu  xmm0, xmmword ptr [rbp-0x3E0]
       vmovdqu  xmmword ptr [rbp-0x9D8], xmm0
 
G_M000_IG175:                ;; offset=0x2A86
       lea      rdx, [rbp-0x9D8]
       lea      rcx, [rbp-0x3F0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB18], rax
       mov      rcx, bword ptr [rbp-0xB18]
       mov      rdx, gword ptr [rbp-0x3F0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB18]
       mov      rcx, qword ptr [rbp-0x3E8]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG176
       mov      rcx, 0x7FF9D77FAF2C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x9E0], rax
       mov      rcx, gword ptr [rbp-0x9E0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG176:                ;; offset=0x2B14
       mov      rcx, 0x7FF9D77FAF30
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG217
 
G_M000_IG177:                ;; offset=0x2B32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x448], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x9E4], eax
       mov      edx, dword ptr [rbp-0x9E4]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0x450], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x454], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x458], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x9F0], rax
       mov      rax, gword ptr [rbp-0x9F0]
       mov      gword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp-0x450]
       mov      r8d, dword ptr [rbp-0x454]
       mov      r9d, dword ptr [rbp-0x458]
       mov      rcx, bword ptr [rbp-0x448]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG178
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG179
       mov      rcx, 0x7FF9D77FAF34
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG178:                ;; offset=0x2BFD
       mov      rcx, 0x7FF9D77FAF38
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG179:                ;; offset=0x2C11
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG180
       mov      rcx, 0x7FF9D77FAF3C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG217
 
G_M000_IG180:                ;; offset=0x2C3D
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG181:                ;; offset=0x2C41
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xA10], ymm0
 
G_M000_IG182:                ;; offset=0x2C4D
       lea      r8, [rbp-0xA10]
       lea      rdx, [rbp-0x468]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG183:                ;; offset=0x2C67
       vmovdqu  xmm0, xmmword ptr [rbp-0x468]
       vmovdqu  xmmword ptr [rbp-0xA20], xmm0
 
G_M000_IG184:                ;; offset=0x2C77
       lea      rdx, [rbp-0xA20]
       lea      rcx, [rbp-0x478]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB20], rax
       mov      rcx, bword ptr [rbp-0xB20]
       mov      rdx, gword ptr [rbp-0x478]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB20]
       mov      rcx, qword ptr [rbp-0x470]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG185
       mov      rcx, 0x7FF9D77FAF40
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA28], rax
       mov      rcx, gword ptr [rbp-0xA28]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG185:                ;; offset=0x2D05
       mov      rcx, 0x7FF9D77FAF44
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG217
 
G_M000_IG186:                ;; offset=0x2D23
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG187
       mov      rcx, 0x7FF9D77FAF48
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG187:                ;; offset=0x2D48
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG188
       mov      rcx, 0x7FF9D77FAF4C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG217
 
G_M000_IG188:                ;; offset=0x2D74
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG189:                ;; offset=0x2D78
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xA48], ymm0
 
G_M000_IG190:                ;; offset=0x2D84
       lea      r8, [rbp-0xA48]
       lea      rdx, [rbp-0x3B0]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG191:                ;; offset=0x2D9E
       vmovdqu  xmm0, xmmword ptr [rbp-0x3B0]
       vmovdqu  xmmword ptr [rbp-0xA58], xmm0
 
G_M000_IG192:                ;; offset=0x2DAE
       lea      rdx, [rbp-0xA58]
       lea      rcx, [rbp-0x3C0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB28], rax
       mov      rcx, bword ptr [rbp-0xB28]
       mov      rdx, gword ptr [rbp-0x3C0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB28]
       mov      rcx, qword ptr [rbp-0x3B8]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG193
       mov      rcx, 0x7FF9D77FAF50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA60], rax
       mov      rcx, gword ptr [rbp-0xA60]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG193:                ;; offset=0x2E3C
       mov      rcx, 0x7FF9D77FAF54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG217
 
G_M000_IG194:                ;; offset=0x2E5A
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG195
       mov      rcx, 0x7FF9D77FAF58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG195:                ;; offset=0x2E7F
       mov      rcx, 0x7FF9D77FAF5C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG217
 
G_M000_IG196:                ;; offset=0x2EA3
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0xA64], eax
       mov      edx, dword ptr [rbp-0xA64]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0xE0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG198
       mov      rcx, gword ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG197
       mov      rcx, 0x7FF9D77FAF60
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG197:                ;; offset=0x2F07
       mov      rcx, 0x7FF9D77FAF64
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG198:                ;; offset=0x2F16
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       SHORT G_M000_IG200
       mov      rdx, gword ptr [rbp-0xE0]
       mov      rcx, 0x7FF9D77F9A80
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG201
 
G_M000_IG199:                ;; offset=0x2F39
       mov      rcx, 0x7FF9D77FAF68
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG200:                ;; offset=0x2F48
       mov      rcx, 0x7FF9D77FAF6C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG217
 
G_M000_IG201:                ;; offset=0x2F75
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG202:                ;; offset=0x2F79
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xA88], ymm0
 
G_M000_IG203:                ;; offset=0x2F85
       lea      r8, [rbp-0xA88]
       lea      rdx, [rbp-0x390]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB30], rax
       mov      rcx, bword ptr [rbp-0xB30]
       mov      rdx, gword ptr [rbp-0x390]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB30]
       mov      rcx, qword ptr [rbp-0x388]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG204
       mov      rcx, 0x7FF9D77FAF70
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA90], rax
       mov      rcx, gword ptr [rbp-0xA90]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG231
 
G_M000_IG204:                ;; offset=0x3019
       mov      rcx, 0x7FF9D77FAF74
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG217
 
G_M000_IG205:                ;; offset=0x303A
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG209
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x154], eax
       cmp      dword ptr [rbp-0x154], 49
       je       SHORT G_M000_IG208
       cmp      dword ptr [rbp-0x154], 57
       je       SHORT G_M000_IG207
       cmp      dword ptr [rbp-0x154], 58
       je       SHORT G_M000_IG206
       mov      rcx, 0x7FF9D77FAF78
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG231
 
G_M000_IG206:                ;; offset=0x308A
       mov      rcx, 0x7FF9D77FAF7C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG209
 
G_M000_IG207:                ;; offset=0x309B
       mov      rcx, 0x7FF9D77FAF80
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG209
 
G_M000_IG208:                ;; offset=0x30AC
       mov      rcx, 0x7FF9D77FAF84
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG209:                ;; offset=0x30BB
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x44], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_IsUnassigned():bool:this]
       test     eax, eax
       jne      G_M000_IG211
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG212
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG210
       mov      rcx, 0x7FF9D77FAF88
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x3A0], xmm0
       lea      rcx, [rbp-0x3A0]
       mov      edx, dword ptr [rbp-0x44]
       call     [System.Threading.Tasks.ValueTask`1[bool]:.ctor(bool):this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB38], rax
       mov      rcx, bword ptr [rbp-0xB38]
       mov      rdx, gword ptr [rbp-0x3A0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB38]
       mov      rcx, qword ptr [rbp-0x398]
       mov      qword ptr [rax+0x08], rcx
       mov      dword ptr [rbp-0xE8], 5
       jmp      G_M000_IG231
 
G_M000_IG210:                ;; offset=0x317E
       mov      rcx, 0x7FF9D77FAF8C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG212
 
G_M000_IG211:                ;; offset=0x318F
       mov      rcx, 0x7FF9D77FAF90
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG217
 
G_M000_IG212:                ;; offset=0x31A3
       mov      rcx, 0x7FF9D77FAF94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG231
 
G_M000_IG213:                ;; offset=0x31C1
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x1B8], ymm0
       vmovdqu  xmmword ptr [rbp-0x1A0], xmm0
       lea      rcx, [rbp-0x1B8]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG214:                ;; offset=0x31ED
       vmovdqu  ymm0, ymmword ptr [rbp-0x1B8]
       vmovdqu  ymmword ptr [rbp-0x180], ymm0
       mov      rax, qword ptr [rbp-0x198]
       mov      qword ptr [rbp-0x160], rax
 
G_M000_IG215:                ;; offset=0x320B
       lea      rcx, [rbp-0x180]
       mov      rdx, 0x2965DB72A40
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendLiteral(System.String):this]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0xA94], eax
       mov      edx, dword ptr [rbp-0xA94]
       lea      rcx, [rbp-0x180]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1C0], rax
       lea      rcx, [rbp-0x180]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      gword ptr [rbp-0xAA0], rax
       mov      rdx, gword ptr [rbp-0xAA0]
       mov      rcx, gword ptr [rbp-0x1C0]
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, gword ptr [rbp-0x1C0]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG216:                ;; offset=0x3290
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG217:                ;; offset=0x3296
       mov      eax, dword ptr [rbp-0x62C]
       dec      eax
       mov      dword ptr [rbp-0x62C], eax
       cmp      dword ptr [rbp-0x62C], 0
       jg       SHORT G_M000_IG219
 
G_M000_IG218:                ;; offset=0x32AD
       lea      rcx, [rbp-0x62C]
       mov      edx, 0xF76
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG219:                ;; offset=0x32C0
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG222
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG221
       mov      rcx, 0x7FF9D77FAFA4
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x1E0]
       mov      edx, dword ptr [rbp-0x44]
       call     [System.Threading.Tasks.ValueTask`1[bool]:.ctor(bool):this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB40], rax
       mov      rcx, bword ptr [rbp-0xB40]
       mov      rdx, gword ptr [rbp-0x1E0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB40]
       mov      rcx, qword ptr [rbp-0x1D8]
       mov      qword ptr [rax+0x08], rcx
       mov      eax, 5
 
G_M000_IG220:                ;; offset=0x3338
       vzeroupper 
       add      rsp, 0xB90
       pop      rbp
       ret      
 
G_M000_IG221:                ;; offset=0x3344
       mov      rcx, 0x7FF9D77FAFA8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG222:                ;; offset=0x3353
       cmp      dword ptr [rbp-0x44], 0
       jne      SHORT G_M000_IG223
       mov      rcx, 0x7FF9D77FAFAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x1D0], rax
       mov      rax, bword ptr [rbp-0x1D0]
       inc      dword ptr [rax]
       jmp      SHORT G_M000_IG227
 
G_M000_IG223:                ;; offset=0x3388
       mov      rcx, 0x7FF9D77FAFB0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG227
 
G_M000_IG224:                ;; offset=0x3399
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xAB8], rax
       mov      r9, gword ptr [rbp-0xAB8]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG226
 
G_M000_IG225:                ;; offset=0x33C7
       mov      rcx, gword ptr [rbp-0x50]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG226:                ;; offset=0x33D1
       mov      rcx, 0x7FF9D77FAFB4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG217
 
G_M000_IG227:                ;; offset=0x33EC
       mov      eax, dword ptr [rbp-0x62C]
       dec      eax
       mov      dword ptr [rbp-0x62C], eax
       cmp      dword ptr [rbp-0x62C], 0
       jg       SHORT G_M000_IG229
 
G_M000_IG228:                ;; offset=0x3403
       lea      rcx, [rbp-0x62C]
       mov      edx, 0xFBB
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG229:                ;; offset=0x3416
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      eax, dword ptr [rcx+0x08]
       jl       G_M000_IG03
       mov      rcx, 0x7FF9D77FAFB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG230:                ;; offset=0x343E
       vzeroupper 
       add      rsp, 0xB90
       pop      rbp
       ret      
 
G_M000_IG231:                ;; offset=0x344A
       mov      rcx, 0x7FF9D77FAFBC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xE8]
 
G_M000_IG232:                ;; offset=0x345F
       vzeroupper 
       add      rsp, 0xB90
       pop      rbp
       ret      
 
G_M000_IG233:                ;; offset=0x346B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG234:                ;; offset=0x3471
       sub      rsp, 72
 
G_M000_IG235:                ;; offset=0x3475
       mov      gword ptr [rbp-0x608], rcx
       mov      rax, gword ptr [rbp-0x608]
       mov      gword ptr [rbp-0x188], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG237
 
G_M000_IG236:                ;; offset=0x3491
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG237:                ;; offset=0x3497
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xAA8], rax
       mov      r8, gword ptr [rbp-0xAA8]
       mov      rdx, gword ptr [rbp-0x188]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG239
       mov      rcx, 0x7FF9D77FAF98
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       lea      rax, G_M000_IG231
 
G_M000_IG238:                ;; offset=0x34E6
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG239:                ;; offset=0x34EE
       mov      rcx, 0x7FF9D77FAF9C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       lea      rax, G_M000_IG217
 
G_M000_IG240:                ;; offset=0x350B
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG241:                ;; offset=0x3513
       sub      rsp, 72
 
G_M000_IG242:                ;; offset=0x3517
       mov      gword ptr [rbp-0x600], rcx
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xAB0], rax
       mov      r9, gword ptr [rbp-0xAB0]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x600]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG244
 
G_M000_IG243:                ;; offset=0x354F
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG244:                ;; offset=0x3555
       mov      rcx, 0x7FF9D77FAFA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       lea      rax, G_M000_IG217
 
G_M000_IG245:                ;; offset=0x3572
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	00001334h ; case G_M000_IG91
       	dd	00001629h ; case G_M000_IG104
       	dd	00000104h ; case G_M000_IG08
       	dd	000002ACh ; case G_M000_IG12
       	dd	000016ABh ; case G_M000_IG105
       	dd	0000172Ch ; case G_M000_IG106
       	dd	00000ADBh ; case G_M000_IG54
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	0000200Dh ; case G_M000_IG138
       	dd	0000200Dh ; case G_M000_IG138
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	000014E2h ; case G_M000_IG97
       	dd	000014E2h ; case G_M000_IG97
       	dd	000017EFh ; case G_M000_IG108
       	dd	0000040Fh ; case G_M000_IG16
       	dd	00000439h ; case G_M000_IG17
       	dd	0000184Ah ; case G_M000_IG110
       	dd	0000194Ah ; case G_M000_IG112
       	dd	00001A7Fh ; case G_M000_IG114
       	dd	00001B2Ah ; case G_M000_IG115
       	dd	00001BAEh ; case G_M000_IG116
       	dd	00001C52h ; case G_M000_IG117
       	dd	00001DBCh ; case G_M000_IG124
       	dd	00001DBCh ; case G_M000_IG124
       	dd	00001DBCh ; case G_M000_IG124
       	dd	00001E08h ; case G_M000_IG126
       	dd	00001E08h ; case G_M000_IG126
       	dd	00001E08h ; case G_M000_IG126
       	dd	00001DBCh ; case G_M000_IG124
       	dd	00002ACFh ; case G_M000_IG177
       	dd	00002308h ; case G_M000_IG151
       	dd	0000251Bh ; case G_M000_IG161
       	dd	00001FE0h ; case G_M000_IG136
       	dd	00002CC0h ; case G_M000_IG186
       	dd	00002DF7h ; case G_M000_IG194
       	dd	00001FA1h ; case G_M000_IG134
       	dd	00001FA1h ; case G_M000_IG134
       	dd	00001FA1h ; case G_M000_IG134
       	dd	00002FD7h ; case G_M000_IG205
       	dd	00002E40h ; case G_M000_IG196
       	dd	00001F21h ; case G_M000_IG132
       	dd	00002FD7h ; case G_M000_IG205
       	dd	00002FD7h ; case G_M000_IG205
       	dd	00002FD7h ; case G_M000_IG205
       	dd	00002FD7h ; case G_M000_IG205
       	dd	00002FD7h ; case G_M000_IG205
       	dd	00002FD7h ; case G_M000_IG205
       	dd	00002FD7h ; case G_M000_IG205
       	dd	000000E6h ; case G_M000_IG07
       	dd	00000C17h ; case G_M000_IG59
       	dd	0000101Bh ; case G_M000_IG76
       	dd	00002FD7h ; case G_M000_IG205
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	0000209Dh ; case G_M000_IG141
       	dd	000020E6h ; case G_M000_IG143
       	dd	000007E0h ; case G_M000_IG41
       	dd	000009A8h ; case G_M000_IG47
       	dd	000001A1h ; case G_M000_IG09

; Total bytes of code 13690

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (Tier1-OSR)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1-OSR code
; OSR variant for entry point 0xf76
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 200
; 112 inlinees with PGO data; 326 single block inlinees; 11 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rax
       mov      rax, qword ptr [rbp]
       push     rax
       sub      rsp, 816
       mov      qword ptr [rsp+0xEC8], r15
       mov      qword ptr [rsp+0xEC0], r14
       mov      qword ptr [rsp+0xEB8], r13
       mov      qword ptr [rsp+0xEB0], r12
       mov      qword ptr [rsp+0xEA8], rdi
       mov      qword ptr [rsp+0xEA0], rsi
       mov      qword ptr [rsp+0xE98], rbx
       lea      rbp, [rsp+0x330]
       xor      eax, eax
       mov      qword ptr [rbp-0x2D8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x2D0], xmm4
       vmovdqa  xmmword ptr [rbp-0x2C0], xmm4
       mov      rax, -624
 
G_M000_IG534:                ;; offset=0x0074
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG534
       mov      qword ptr [rbp-0x40], rax
       mov      eax, dword ptr [rbp+0xBC8]
 
G_M000_IG02:                ;; offset=0x0096
       cmp      byte  ptr [rbp+0xBC8], 0
       jne      G_M000_IG512
 
G_M000_IG03:                ;; offset=0x00A3
       cmp      dword ptr [rbp+0xB5C], 0
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00AC
       mov      rcx, bword ptr [rbp+0xBB0]
       inc      dword ptr [rcx+0x10]
 
G_M000_IG05:                ;; offset=0x00B6
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      edx, dword ptr [rcx+0x10]
       mov      rax, gword ptr [rbp+0xB60]
       mov      ebx, dword ptr [rax+0x08]
       cmp      edx, ebx
       jge      G_M000_IG518
 
G_M000_IG06:                ;; offset=0x00D2
       xor      edx, edx
       mov      dword ptr [rbp+0xB5C], edx
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, ebx
       jae      G_M000_IG520
       mov      rax, gword ptr [rbp+0xB60]
       shl      rdx, 5
       lea      rdx, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp+0xB48], rdx
       mov      r9, gword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [r9+0x98]
       mov      rax, bword ptr [rbp+0xB48]
       mov      rax, gword ptr [rax]
       mov      r8, gword ptr [rdx+0x88]
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG511
       mov      r8, gword ptr [rdx+0x180]
       test     r8, r8
       jne      G_M000_IG510
 
G_M000_IG07:                ;; offset=0x0136
       mov      r8, bword ptr [rbp+0xB48]
       mov      esi, dword ptr [r8+0x1C]
       cmp      esi, 72
       ja       G_M000_IG260
 
G_M000_IG08:                ;; offset=0x014A
       mov      r8d, esi
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*r8]
       lea      rax, G_M000_IG02
       add      rdx, rax
       jmp      rdx
 
G_M000_IG09:                ;; offset=0x0164
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rbx, gword ptr [rcx]
       mov      rax, gword ptr [rcx+0x08]
       mov      edx, esi
       cmp      edx, 2
       je       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0179
       cmp      edx, 25
       jne      G_M000_IG263
 
G_M000_IG11:                ;; offset=0x0182
       mov      rdx, bword ptr [rbp+0xB48]
       mov      esi, dword ptr [rdx+0x08]
       mov      rdx, bword ptr [rbp+0xB48]
       mov      rdi, gword ptr [rdx]
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG507
       mov      edx, esi
       shl      rdx, 4
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      r8, 0x27637001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG265
 
G_M000_IG12:                ;; offset=0x01C0
       mov      r8, 0x27637001CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG266
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG267
 
G_M000_IG13:                ;; offset=0x01DE
       test     rdx, rdx
       jne      G_M000_IG39
 
G_M000_IG14:                ;; offset=0x01E7
       mov      rax, rdx
 
G_M000_IG15:                ;; offset=0x01EA
       test     rax, rax
       je       G_M000_IG268
 
G_M000_IG16:                ;; offset=0x01F3
       mov      rbx, rax
       mov      rdx, bword ptr [rbp+0xB48]
       cmp      dword ptr [rdx+0x18], 0
       jl       G_M000_IG47
 
G_M000_IG17:                ;; offset=0x0207
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG19
 
G_M000_IG18:                ;; offset=0x0221
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG269
 
G_M000_IG19:                ;; offset=0x0235
       mov      rdx, bword ptr [rbp+0xB48]
       mov      edi, dword ptr [rdx+0x14]
 
G_M000_IG20:                ;; offset=0x023F
       mov      rdx, bword ptr [rbp+0xB48]
       mov      r14d, dword ptr [rdx+0x18]
       test     r14d, r14d
       jl       G_M000_IG41
 
G_M000_IG21:                ;; offset=0x0253
       cmp      r14d, dword ptr [rsi+0x40]
       jge      G_M000_IG38
 
G_M000_IG22:                ;; offset=0x025D
       mov      r15d, dword ptr [rsi+0x40]
       dec      r15d
       mov      r13d, dword ptr [rsi+0x3C]
       cmp      r15d, r13d
       jle      G_M000_IG42
 
G_M000_IG23:                ;; offset=0x0271
       cmp      r13d, r14d
       jl       G_M000_IG34
 
G_M000_IG24:                ;; offset=0x027A
       cmp      byte  ptr [rsi+0x44], 0
       jne      G_M000_IG270
 
G_M000_IG25:                ;; offset=0x0284
       mov      rdx, gword ptr [rsi]
       cmp      r13d, dword ptr [rdx+0x08]
       jae      G_M000_IG507
       mov      eax, r13d
       shl      rax, 4
       lea      r15, bword ptr [rdx+rax+0x10]
       mov      rdx, gword ptr [rsi+0x18]
       mov      r12, gword ptr [rdx+0x88]
       mov      rdx, gword ptr [r15]
       mov      rax, rdx
       test     rax, rax
       je       SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x02B3
       mov      r8, 0x7FF9D7848AB0
       cmp      qword ptr [rax], r8
       jne      G_M000_IG274
 
G_M000_IG27:                ;; offset=0x02C6
       test     rax, rax
       je       G_M000_IG44
 
G_M000_IG28:                ;; offset=0x02CF
       xor      edx, edx
       mov      qword ptr [r15], rdx
       mov      qword ptr [r15+0x08], rdx
       mov      rdx, 0x7FF9D7848AB0
       cmp      qword ptr [rax], rdx
       jne      G_M000_IG277
       mov      rdx, gword ptr [rax+0x08]
       cmp      byte  ptr [rdx], dl
       cmp      byte  ptr [rax+0x38], 0
       je       SHORT G_M000_IG33
       mov      byte  ptr [rax+0x38], 0
       xor      r8, r8
       mov      gword ptr [rax+0x18], r8
 
G_M000_IG29:                ;; offset=0x0302
       mov      gword ptr [rax+0x20], r8
 
G_M000_IG30:                ;; offset=0x0306
       mov      qword ptr [rax+0x30], r8
       mov      r15, gword ptr [rdx+0x18]
       cmp      byte  ptr [rdx+0x48], 0
       jne      G_M000_IG43
 
G_M000_IG31:                ;; offset=0x0318
       test     r15, r15
       jne      G_M000_IG275
 
G_M000_IG32:                ;; offset=0x0321
       lea      rcx, bword ptr [rdx+0x18]
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       test     r15, r15
       jne      G_M000_IG276
 
G_M000_IG33:                ;; offset=0x0336
       dec      r13d
       cmp      r13d, r14d
       jge      G_M000_IG24
 
G_M000_IG34:                ;; offset=0x0342
       mov      rdx, gword ptr [rsi]
       mov      eax, dword ptr [rsi+0x40]
       sub      eax, r14d
       test     rdx, rdx
       je       G_M000_IG282
       lea      r8, bword ptr [rdx+0x10]
       xor      r10d, r10d
       mov      r11, qword ptr [rdx]
       cmp      dword ptr [r11+0x04], 24
       jne      G_M000_IG283
 
G_M000_IG35:                ;; offset=0x0369
       mov      r15d, r14d
       sub      r15d, r10d
       cmp      r14d, r10d
       jl       G_M000_IG46
 
G_M000_IG36:                ;; offset=0x0378
       mov      r10d, r15d
       or       r10d, eax
       jl       G_M000_IG46
       lea      r10d, [r15+rax]
       cmp      r10d, dword ptr [rdx+0x08]
       ja       G_M000_IG46
       movzx    rdx, word  ptr [r11]
       mov      r10d, r15d
       imul     r10, rdx
       add      r10, r8
       mov      eax, eax
       imul     rdx, rax
       test     dword ptr [r11], 0x1000000
       je       G_M000_IG284
       shr      rdx, 3
       mov      rcx, r10
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
 
G_M000_IG37:                ;; offset=0x03C0
       mov      dword ptr [rsi+0x40], r14d
 
G_M000_IG38:                ;; offset=0x03C4
       mov      rdx, gword ptr [rsi]
       cmp      edi, dword ptr [rdx+0x08]
       jae      G_M000_IG507
       mov      eax, edi
       shl      rax, 4
       lea      rdi, bword ptr [rdx+rax+0x10]
       mov      rcx, rdi
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      eax, eax
       mov      qword ptr [rdi+0x08], rax
       mov      dword ptr [rsi+0x40], r14d
       jmp      G_M000_IG02
 
G_M000_IG39:                ;; offset=0x03F5
       mov      rax, 0x7FF9D77F4838
       cmp      qword ptr [rdx], rax
       jne      G_M000_IG14
 
G_M000_IG40:                ;; offset=0x0408
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       jmp      G_M000_IG15
 
G_M000_IG41:                ;; offset=0x0416
       not      r14d
       jmp      G_M000_IG21
 
G_M000_IG42:                ;; offset=0x041E
       mov      r13d, r15d
       jmp      G_M000_IG23
 
G_M000_IG43:                ;; offset=0x0426
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:ReleaseStorage():this]
       jmp      G_M000_IG33
 
G_M000_IG44:                ;; offset=0x0434
       cmp      qword ptr [r15+0x08], -1
       je       G_M000_IG278
 
G_M000_IG45:                ;; offset=0x043F
       cmp      qword ptr [r15+0x08], -2
       jne      G_M000_IG33
       jmp      G_M000_IG281
 
G_M000_IG46:                ;; offset=0x044F
       call     [System.ThrowHelper:ThrowIndexOutOfRangeException()]
       int3     
 
G_M000_IG47:                ;; offset=0x0456
       mov      gword ptr [rbp-0x1B0], rax
       xor      edx, edx
       mov      qword ptr [rbp-0x1A8], rdx
       mov      rdx, bword ptr [rbp+0xB48]
       mov      edx, dword ptr [rdx+0x18]
       not      edx
       mov      rcx, bword ptr [rbp+0xBB0]
       cmp      edx, dword ptr [rcx+0x60]
       jl       G_M000_IG63
 
G_M000_IG48:                ;; offset=0x0482
       cmp      gword ptr [rcx+0x40], 0
       jne      G_M000_IG286
       mov      rax, gword ptr [rcx+0x38]
       mov      rdx, gword ptr [rax+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG286
       mov      rax, gword ptr [rax+0x180]
       test     rax, rax
       jne      G_M000_IG285
 
G_M000_IG49:                ;; offset=0x04B3
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG51
 
G_M000_IG50:                ;; offset=0x04C6
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG289
 
G_M000_IG51:                ;; offset=0x04DA
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG52:                ;; offset=0x04E4
       mov      rdx, gword ptr [rbx]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG507
       mov      r8d, eax
       shl      r8, 4
       lea      rdx, bword ptr [rdx+r8+0x10]
       xor      r8, r8
       mov      gword ptr [rdx], r8
 
G_M000_IG53:                ;; offset=0x0502
       mov      qword ptr [rdx+0x08], r8
       mov      dword ptr [rbx+0x40], eax
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rax, gword ptr [rcx]
       mov      rax, gword ptr [rax+0x98]
       mov      edx, dword ptr [rcx+0x10]
       inc      edx
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG507
       shl      rdx, 5
       lea      rdx, bword ptr [rax+rdx+0x10]
       mov      ebx, dword ptr [rdx+0x1C]
       cmp      ebx, 25
       jne      G_M000_IG67
 
G_M000_IG54:                ;; offset=0x053D
       mov      rbx, gword ptr [rcx]
       mov      rsi, gword ptr [rcx+0x08]
       mov      edi, dword ptr [rdx+0x08]
 
G_M000_IG55:                ;; offset=0x0547
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x1C0], xmm0
 
G_M000_IG56:                ;; offset=0x0557
       mov      rax, gword ptr [rbx+0x68]
       mov      rdx, 0x7FF9D723C7D0
       cmp      qword ptr [rax], rdx
       jne      G_M000_IG291
       cmp      dword ptr [rax+0x08], edi
       jbe      G_M000_IG290
       mov      edx, edi
       mov      r14, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG57:                ;; offset=0x057E
       cmp      word  ptr [r14+0x0C], 60
       setne    r15b
       movzx    r15, r15b
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG64
 
G_M000_IG58:                ;; offset=0x059A
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      rax, gword ptr [rdx+0x88]
 
G_M000_IG59:                ;; offset=0x05A8
       test     rax, rax
       setne    al
       movzx    rax, al
       test     eax, r15d
       jne      G_M000_IG292
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG507
       mov      eax, edi
       shl      rax, 4
       mov      r13, gword ptr [rsi+rax+0x10]
       test     r13, r13
       jne      G_M000_IG65
 
G_M000_IG60:                ;; offset=0x05D7
       mov      eax, edi
       shl      rax, 4
       lea      r13, bword ptr [rsi+rax+0x10]
       mov      rdx, gword ptr [rbp-0x1C0]
       mov      rcx, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x1B8]
       mov      qword ptr [r13+0x08], rcx
       test     r15d, r15d
       je       SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x0601
       cmp      byte  ptr [rbx+0xF2], 0
       jne      G_M000_IG293
       cmp      gword ptr [rbp+0xBC0], 0
       je       SHORT G_M000_IG62
       mov      rdx, gword ptr [rbp+0xBC0]
       cmp      byte  ptr [rdx+0xFF], 0
       jne      G_M000_IG293
 
G_M000_IG62:                ;; offset=0x062C
       mov      rbx, bword ptr [rbp+0xBB0]
       inc      dword ptr [rbx+0x10]
       jmp      G_M000_IG02
 
G_M000_IG63:                ;; offset=0x063B
       lea      rdx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x18]
       not      eax
       mov      rcx, rdx
       mov      edx, eax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xBB0]
       jmp      G_M000_IG48
 
G_M000_IG64:                ;; offset=0x0662
       xor      rax, rax
       jmp      G_M000_IG59
 
G_M000_IG65:                ;; offset=0x0669
       mov      rax, 0x7FF9D77F4838
       cmp      qword ptr [r13], rax
       jne      G_M000_IG60
 
G_M000_IG66:                ;; offset=0x067D
       lea      rcx, [rbp-0x1C0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      SHORT G_M000_IG62
 
G_M000_IG67:                ;; offset=0x06AB
       cmp      ebx, 71
       je       G_M000_IG294
       cmp      ebx, 30
       jne      G_M000_IG299
       cmp      gword ptr [rbp-0x1B0], 0
       jne      G_M000_IG62
       jmp      G_M000_IG300
 
G_M000_IG68:                ;; offset=0x06D0
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rcx]
       mov      rbx, gword ptr [rdx+0x30]
       mov      edx, esi
       cmp      edx, 35
       jg       G_M000_IG405
       cmp      edx, 35
       ja       G_M000_IG404
       mov      rax, 0x7FFFFFFBD
       bt       rax, rdx
       jb       G_M000_IG404
 
G_M000_IG69:                ;; offset=0x0706
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG507
       mov      rcx, gword ptr [rbx+8*rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rbx, rax
       mov      rcx, bword ptr [rbp+0xB48]
       cmp      dword ptr [rcx+0x18], 0
       jl       G_M000_IG78
 
G_M000_IG70:                ;; offset=0x0738
       mov      rsi, bword ptr [rbp+0xBB0]
       lea      rdi, bword ptr [rsi+0x20]
       mov      rcx, bword ptr [rbp+0xB48]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG72
 
G_M000_IG71:                ;; offset=0x0752
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jae      G_M000_IG406
 
G_M000_IG72:                ;; offset=0x0766
       mov      rcx, bword ptr [rbp+0xB48]
       mov      r14d, dword ptr [rcx+0x14]
 
G_M000_IG73:                ;; offset=0x0771
       mov      rcx, bword ptr [rbp+0xB48]
       mov      r15d, dword ptr [rcx+0x18]
       test     r15d, r15d
       jl       SHORT G_M000_IG77
 
G_M000_IG74:                ;; offset=0x0781
       cmp      r15d, dword ptr [rdi+0x40]
       jge      SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x0787
       mov      rcx, rdi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG76:                ;; offset=0x0793
       mov      rcx, gword ptr [rdi]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG507
       mov      edx, r14d
       shl      rdx, 4
       lea      r14, bword ptr [rcx+rdx+0x10]
       mov      rcx, r14
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      r9d, r9d
       mov      qword ptr [r14+0x08], r9
       mov      dword ptr [rdi+0x40], r15d
       jmp      G_M000_IG02
 
G_M000_IG77:                ;; offset=0x07C7
       not      r15d
       jmp      SHORT G_M000_IG74
 
G_M000_IG78:                ;; offset=0x07CC
       mov      rsi, bword ptr [rbp+0xBB0]
       mov      gword ptr [rbp-0x2A8], rbx
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2A0], r9
       lea      r9, [rbp-0x2A8]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r8, bword ptr [rbp+0xB48]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG79:                ;; offset=0x0807
       mov      r9, gword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG97
 
G_M000_IG80:                ;; offset=0x0834
       mov      dword ptr [rbp+0xB5C], 1
       jmp      G_M000_IG02
 
G_M000_IG81:                ;; offset=0x0843
       mov      r9, gword ptr [rbp+0xBB8]
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG502
 
G_M000_IG82:                ;; offset=0x0858
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp+0xB5C], eax
       mov      rcx, bword ptr [rbp+0xBB0]
       cmp      gword ptr [rcx+0x68], 0
       je       G_M000_IG02
       jmp      G_M000_IG503
 
G_M000_IG83:                ;; offset=0x0893
       mov      r9, gword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG222
       jmp      G_M000_IG02
 
G_M000_IG84:                ;; offset=0x08C5
       mov      r9, gword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rcx]
       mov      rdx, gword ptr [rdx+0xB0]
       cmp      esi, 42
       jne      G_M000_IG454
       mov      r11, bword ptr [rbp+0xB48]
       mov      r11d, dword ptr [r11+0x08]
       mov      rax, 0x7FF9D7648660
       cmp      qword ptr [rdx], rax
       jne      G_M000_IG455
       cmp      dword ptr [rdx+0x08], r11d
       jbe      G_M000_IG290
       cmp      r11d, dword ptr [rdx+0x08]
       jae      G_M000_IG507
       mov      rsi, gword ptr [rdx+8*r11+0x10]
 
G_M000_IG85:                ;; offset=0x091D
       mov      rax, bword ptr [rbp+0xB48]
       mov      ebx, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rax, bword ptr [rcx+0x20]
       cmp      byte  ptr [rsi], sil
       mov      rax, gword ptr [rax]
       cmp      byte  ptr [rsi+0x30], 0
       setne    dl
       movzx    rdx, dl
       add      edx, ebx
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG507
       shl      rdx, 4
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      r8, 0x27637001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG456
 
G_M000_IG86:                ;; offset=0x096C
       mov      rdx, gword ptr [rax]
       mov      r8, 0x27637001CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG457
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG458
       mov      rdi, gword ptr [rax]
 
G_M000_IG87:                ;; offset=0x0990
       test     rdi, rdi
       je       G_M000_IG459
       mov      dword ptr [rsp+0x20], ebx
       mov      gword ptr [rsp+0x28], rdi
       lea      rdx, [rbp+0xAC8]
       mov      qword ptr [rsp+0x30], rdx
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG89
 
G_M000_IG88:                ;; offset=0x09CC
       cmp      gword ptr [rbp+0xAC8], 0
       je       G_M000_IG02
       jmp      G_M000_IG460
 
G_M000_IG89:                ;; offset=0x09DF
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG461
       movzx    rcx, byte  ptr [rbp+0xBC8]
       mov      dword ptr [rsp+0x20], ecx
       mov      r8, bword ptr [rbp+0xBE0]
       mov      bword ptr [rsp+0x28], r8
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      rdx, rsi
       mov      r8d, ebx
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG93
 
G_M000_IG90:                ;; offset=0x0A1E
       cmp      byte  ptr [rbp+0xBC8], 0
       jne      G_M000_IG471
       mov      gword ptr [rsp+0x20], rdi
       xor      edx, edx
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp+0xAA8]
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      r8, rsi
       mov      r9d, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       mov      r14, gword ptr [rbp+0xAA8]
 
G_M000_IG91:                ;; offset=0x0A57
       vmovdqu  xmm0, xmmword ptr [rbp+0xAA8]
       vmovdqu  xmmword ptr [rbp+0xA98], xmm0
 
G_M000_IG92:                ;; offset=0x0A67
       test     r14, r14
       je       G_M000_IG02
       jmp      G_M000_IG469
 
G_M000_IG93:                ;; offset=0x0A75
       mov      r8, bword ptr [rbp+0xBE0]
       mov      rbx, gword ptr [r8]
       test     rbx, rbx
       jne      G_M000_IG462
 
G_M000_IG94:                ;; offset=0x0A88
       mov      r8, bword ptr [rbp+0xBE0]
       mov      rbx, gword ptr [r8]
       test     rbx, rbx
       jne      G_M000_IG465
       mov      rdi, gword ptr [r8+0x08]
 
G_M000_IG95:                ;; offset=0x0A9F
       mov      rcx, gword ptr [rbp+0xBC0]
       cmp      rdi, rcx
       je       G_M000_IG468
 
G_M000_IG96:                ;; offset=0x0AAF
       mov      rdx, gword ptr [rsi+0x18]
       mov      rcx, bword ptr [rbp+0xBD8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp+0xAB8], 3
       jmp      G_M000_IG508
 
G_M000_IG97:                ;; offset=0x0ACE
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      esi, dword ptr [rax+0x10]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x270], xmm0
       mov      rax, gword ptr [rbx]
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG507
       mov      edx, esi
       shl      rdx, 4
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      r8, 0x27637001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG444
 
G_M000_IG98:                ;; offset=0x0B1C
       mov      rdx, gword ptr [rax]
       mov      r8, 0x27637001CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG445
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG446
       mov      rdi, gword ptr [rax]
 
G_M000_IG99:                ;; offset=0x0B40
       test     rdi, rdi
       je       G_M000_IG447
       mov      rdx, 0x7FF9D7848AB0
       cmp      qword ptr [rdi], rdx
       je       G_M000_IG107
 
G_M000_IG100:                ;; offset=0x0B5C
       mov      rdx, 0x7FF9D77FA4F0
       cmp      qword ptr [rdi], rdx
       je       G_M000_IG106
 
G_M000_IG101:                ;; offset=0x0B6F
       mov      rax, rdi
       test     rax, rax
       je       SHORT G_M000_IG103
 
G_M000_IG102:                ;; offset=0x0B77
       mov      rdx, 0x7FF9D77F5D30
       cmp      qword ptr [rax], rdx
       jne      G_M000_IG448
       xor      rax, rax
 
G_M000_IG103:                ;; offset=0x0B8C
       test     rax, rax
       jne      SHORT G_M000_IG106
       mov      rdx, 0x7FF9D7848D18
       cmp      qword ptr [rdi], rdx
       je       SHORT G_M000_IG105
 
G_M000_IG104:                ;; offset=0x0BA0
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp+0xAE8], xmm0
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG304
       cmp      byte  ptr [rbp+0xBC8], 0
       jne      G_M000_IG449
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      rdx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp+0xB5C], eax
       jmp      G_M000_IG02
 
G_M000_IG105:                ;; offset=0x0BE6
       lea      rdx, [rbp-0x270]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG108
 
G_M000_IG106:                ;; offset=0x0BF8
       mov      r8, gword ptr [rbx+0x08]
       sub      esi, dword ptr [rbx+0x38]
       cmp      esi, dword ptr [r8+0x08]
       jae      G_M000_IG507
       mov      edx, esi
       lea      r8, bword ptr [r8+4*rdx+0x10]
       lea      rcx, [rbp-0x270]
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.PyIteration:AdvanceBuiltinSequence(System.Object,byref):Lokad.Lython.Runtime.PyIterationResult]
       jmp      SHORT G_M000_IG108
 
G_M000_IG107:                ;; offset=0x0C22
       mov      rax, rdi
       lea      rdx, [rbp-0x270]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
 
G_M000_IG108:                ;; offset=0x0C35
       cmp      gword ptr [rbp-0x270], 0
       setne    bl
       movzx    rbx, bl
       test     ebx, ebx
       jne      SHORT G_M000_IG113
 
G_M000_IG109:                ;; offset=0x0C47
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x280], xmm0
 
G_M000_IG110:                ;; offset=0x0C53
       vmovdqu  xmm0, xmmword ptr [rbp-0x280]
       vmovdqu  xmmword ptr [rbp+0xAE8], xmm0
 
G_M000_IG111:                ;; offset=0x0C63
       test     ebx, ebx
       je       SHORT G_M000_IG114
 
G_M000_IG112:                ;; offset=0x0C67
       lea      r9, [rbp+0xAE8]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r8, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG113:                ;; offset=0x0C8E
       lea      rcx, [rbp-0x270]
       lea      rdx, [rbp-0x280]
       call     [Lokad.Lython.Runtime.PyIterationResult:TakeSlotValue():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       jmp      SHORT G_M000_IG110
 
G_M000_IG114:                ;; offset=0x0CA4
       mov      rdx, bword ptr [rbp+0xB48]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xBB0]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      dword ptr [rcx+0x10], eax
       jmp      G_M000_IG80
 
G_M000_IG115:                ;; offset=0x0CDB
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      esi, dword ptr [rax+0x10]
       mov      rdi, gword ptr [rcx]
       mov      rax, gword ptr [rcx+0x20]
       test     rax, rax
       je       G_M000_IG474
       lea      rdx, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG116:                ;; offset=0x0D07
       mov      r14d, dword ptr [rcx+0x10]
       xor      r8, r8
       mov      gword ptr [rbp-0x288], r8
       test     esi, esi
       jl       G_M000_IG258
 
G_M000_IG117:                ;; offset=0x0D1D
       cmp      esi, eax
       jae      G_M000_IG507
       mov      eax, esi
       shl      rax, 4
       add      rax, rdx
       mov      rdx, gword ptr [rax]
       mov      r8, 0x27637001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG477
 
G_M000_IG118:                ;; offset=0x0D44
       mov      rdx, gword ptr [rax]
       mov      r8, 0x27637001CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG478
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG479
       mov      r15, gword ptr [rax]
 
G_M000_IG119:                ;; offset=0x0D68
       cmp      esi, dword ptr [rdi+0xD8]
       jge      SHORT G_M000_IG124
 
G_M000_IG120:                ;; offset=0x0D70
       test     r15, r15
       je       SHORT G_M000_IG123
 
G_M000_IG121:                ;; offset=0x0D75
       mov      rax, 0x7FF9D77F4838
       cmp      qword ptr [r15], rax
       jne      SHORT G_M000_IG123
 
G_M000_IG122:                ;; offset=0x0D84
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      r15, rax
 
G_M000_IG123:                ;; offset=0x0D90
       test     r15, r15
       je       G_M000_IG480
 
G_M000_IG124:                ;; offset=0x0D99
       test     r15, r15
       je       G_M000_IG481
       mov      r14, r15
 
G_M000_IG125:                ;; offset=0x0DA5
       xor      rax, rax
       mov      gword ptr [rbp-0x288], rax
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG127
 
G_M000_IG126:                ;; offset=0x0DBD
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG482
 
G_M000_IG127:                ;; offset=0x0DD1
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG128:                ;; offset=0x0DDB
       mov      rdx, bword ptr [rbp+0xB48]
       cmp      dword ptr [rdx+0x18], 0
       jl       G_M000_IG259
 
G_M000_IG129:                ;; offset=0x0DEC
       mov      rdx, bword ptr [rbp+0xB48]
       mov      r10d, dword ptr [rdx+0x18]
 
G_M000_IG130:                ;; offset=0x0DF7
       mov      rdx, bword ptr [rbp+0xB48]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x20], rdx
       mov      rcx, rbx
       mov      rdx, r14
       mov      r8d, eax
       mov      r9d, r10d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      G_M000_IG02
 
G_M000_IG131:                ;; offset=0x0E20
       movzx    rax, byte  ptr [rbp+0xBC8]
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG304
       test     al, al
       jne      G_M000_IG483
 
G_M000_IG132:                ;; offset=0x0E3D
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      rdx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG02
 
G_M000_IG133:                ;; offset=0x0E56
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG304
       cmp      byte  ptr [rbp+0xBC8], 0
       jne      G_M000_IG431
 
G_M000_IG134:                ;; offset=0x0E71
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      rdx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp+0xB5C], eax
       jmp      G_M000_IG02
 
G_M000_IG135:                ;; offset=0x0E90
       cmp      gword ptr [rbp+0xBC0], 0
       jne      SHORT G_M000_IG134
       jmp      G_M000_IG304
 
G_M000_IG136:                ;; offset=0x0E9F
       mov      dword ptr [rbp+0xAB8], 1
       jmp      G_M000_IG508
 
G_M000_IG137:                ;; offset=0x0EAE
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rbx, bword ptr [rcx+0x20]
       mov      eax, esi
       cmp      eax, 51
       ja       SHORT G_M000_IG139
 
G_M000_IG138:                ;; offset=0x0EC0
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG422
 
G_M000_IG139:                ;; offset=0x0ED4
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG140:                ;; offset=0x0EDE
       lea      esi, [rax+0x01]
       mov      rax, bword ptr [rbp+0xB48]
       cmp      dword ptr [rax+0x18], 0
       jl       G_M000_IG145
 
G_M000_IG141:                ;; offset=0x0EF2
       mov      rax, bword ptr [rbp+0xB48]
       mov      edi, dword ptr [rax+0x18]
 
G_M000_IG142:                ;; offset=0x0EFC
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rax, gword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp+0xB48]
       mov      edx, dword ptr [rdx+0x10]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG507
       shl      rdx, 4
       lea      rcx, bword ptr [rax+rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      r14, rax
       test     r14, r14
       je       G_M000_IG423
       cmp      edi, dword ptr [rbx+0x40]
       jge      SHORT G_M000_IG144
 
G_M000_IG143:                ;; offset=0x0F3A
       mov      rcx, rbx
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG144:                ;; offset=0x0F45
       mov      rcx, gword ptr [rbx]
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG507
       mov      edx, esi
       shl      rdx, 4
       lea      rsi, bword ptr [rcx+rdx+0x10]
       mov      rcx, rsi
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rsi+0x08], rcx
       mov      dword ptr [rbx+0x40], edi
       jmp      G_M000_IG02
 
G_M000_IG145:                ;; offset=0x0F75
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x18]
       mov      edi, eax
       not      edi
       jmp      G_M000_IG142
 
G_M000_IG146:                ;; offset=0x0F88
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG304
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rbx, gword ptr [rcx]
       mov      rsi, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rcx]
       mov      rdi, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG507
       mov      ecx, eax
       mov      rdi, gword ptr [rdi+8*rcx+0x10]
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      r14, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      r15d, dword ptr [rax+0x10]
       mov      rax, bword ptr [rbp+0xB48]
       cmp      dword ptr [rax+0x18], 0
       jl       G_M000_IG152
 
G_M000_IG147:                ;; offset=0x0FEF
       mov      rax, bword ptr [rbp+0xB48]
       mov      r13d, dword ptr [rax+0x18]
 
G_M000_IG148:                ;; offset=0x0FFA
       mov      rax, gword ptr [r14]
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG507
       mov      edx, r15d
       shl      rdx, 4
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      r8, 0x27637001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG418
 
G_M000_IG149:                ;; offset=0x1029
       mov      rdx, gword ptr [rax]
       mov      r8, 0x27637001CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG419
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG420
       mov      r9, gword ptr [rax]
 
G_M000_IG150:                ;; offset=0x104D
       test     r9, r9
       je       G_M000_IG421
       mov      rdx, gword ptr [r14]
       cmp      r15d, dword ptr [rdx+0x08]
       jae      G_M000_IG507
       mov      r8d, r15d
       shl      r8, 4
       lea      rdx, bword ptr [rdx+r8+0x10]
       xor      r8, r8
       mov      gword ptr [rdx], r8
 
G_M000_IG151:                ;; offset=0x1075
       mov      qword ptr [rdx+0x08], r8
       mov      dword ptr [r14+0x40], r13d
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      gword ptr [rsp+0x20], rdx
       mov      r8, bword ptr [rbp+0xB48]
       mov      r8, gword ptr [r8]
       mov      gword ptr [rsp+0x28], r8
       mov      rcx, rbx
       mov      rdx, rsi
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG152:                ;; offset=0x10AC
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x18]
       mov      r13d, eax
       not      r13d
       jmp      G_M000_IG148
 
G_M000_IG153:                ;; offset=0x10C1
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rbx, gword ptr [rcx]
       mov      rdi, gword ptr [rcx+0x08]
       mov      eax, esi
       cmp      eax, 2
       je       SHORT G_M000_IG155
 
G_M000_IG154:                ;; offset=0x10D6
       cmp      eax, 25
       jne      G_M000_IG306
 
G_M000_IG155:                ;; offset=0x10DF
       mov      rax, bword ptr [rbp+0xB48]
       mov      esi, dword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x10]
       mov      rdx, gword ptr [rcx]
       cmp      eax, dword ptr [rdx+0xD8]
       jl       G_M000_IG168
 
G_M000_IG156:                ;; offset=0x1102
       lea      r14, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      r15d, dword ptr [rax+0x10]
       mov      rax, bword ptr [rbp+0xB48]
       mov      r13d, dword ptr [rax+0x18]
       test     r13d, r13d
       jl       G_M000_IG167
 
G_M000_IG157:                ;; offset=0x1125
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x1E8], xmm0
       mov      rax, gword ptr [r14]
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG507
       mov      edx, r15d
       shl      rdx, 4
 
G_M000_IG158:                ;; offset=0x1145
       vmovdqu  xmm0, xmmword ptr [rax+rdx+0x10]
       vmovdqu  xmmword ptr [rbp-0x1E8], xmm0
 
G_M000_IG159:                ;; offset=0x1153
       cmp      gword ptr [rbp-0x1E8], 0
       je       G_M000_IG317
 
G_M000_IG160:                ;; offset=0x1161
       mov      rax, gword ptr [r14]
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG507
       mov      edx, r15d
       shl      rdx, 4
       xor      r8d, r8d
       mov      qword ptr [rax+rdx+0x10], r8
       mov      qword ptr [rax+rdx+0x18], r8
       mov      dword ptr [r14+0x40], r13d
       mov      r14, gword ptr [rbp-0x1E8]
       mov      r15, qword ptr [rbp-0x1E0]
 
G_M000_IG161:                ;; offset=0x1194
       mov      gword ptr [rbp-0x1F8], r14
       mov      qword ptr [rbp-0x1F0], r15
       mov      rdx, gword ptr [rbx+0x68]
       mov      r11, 0x7FF9D723C7D0
       cmp      qword ptr [rdx], r11
       jne      G_M000_IG318
       cmp      dword ptr [rdx+0x08], esi
       jbe      G_M000_IG290
       mov      r11d, esi
       mov      r14, gword ptr [rdx+8*r11+0x10]
 
G_M000_IG162:                ;; offset=0x11CA
       cmp      word  ptr [r14+0x0C], 60
       setne    r15b
       movzx    r15, r15b
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG319
 
G_M000_IG163:                ;; offset=0x11E6
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      rax, gword ptr [rdx+0x88]
 
G_M000_IG164:                ;; offset=0x11F4
       test     rax, rax
       setne    al
       movzx    rax, al
       test     eax, r15d
       jne      G_M000_IG320
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG507
       mov      eax, esi
       shl      rax, 4
       mov      r13, gword ptr [rdi+rax+0x10]
       test     r13, r13
       jne      G_M000_IG182
 
G_M000_IG165:                ;; offset=0x1223
       mov      eax, esi
       shl      rax, 4
       lea      r13, bword ptr [rdi+rax+0x10]
       mov      rdx, gword ptr [rbp-0x1F8]
       mov      rcx, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x1F0]
       mov      qword ptr [r13+0x08], rcx
       test     r15d, r15d
       je       G_M000_IG02
 
G_M000_IG166:                ;; offset=0x1251
       movzx    rax, byte  ptr [rbp+0xBC8]
       cmp      byte  ptr [rbx+0xF2], 0
       jne      G_M000_IG321
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG02
       mov      rdx, gword ptr [rbp+0xBC0]
       cmp      byte  ptr [rdx+0xFF], 0
       je       G_M000_IG02
       jmp      G_M000_IG321
 
G_M000_IG167:                ;; offset=0x128C
       not      r13d
       jmp      G_M000_IG157
 
G_M000_IG168:                ;; offset=0x1294
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x10]
       mov      rdx, gword ptr [rcx]
       cmp      eax, dword ptr [rdx+0xD8]
       jge      G_M000_IG307
       mov      rax, bword ptr [rbp+0xB48]
       mov      r14d, dword ptr [rax+0x10]
       mov      r15, gword ptr [rcx]
       mov      rax, gword ptr [rcx+0x20]
       test     rax, rax
       je       G_M000_IG308
       lea      rdx, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG169:                ;; offset=0x12CF
       mov      r13d, dword ptr [rcx+0x10]
       xor      r8, r8
       mov      gword ptr [rbp-0x1D8], r8
       test     r14d, r14d
       jl       G_M000_IG309
 
G_M000_IG170:                ;; offset=0x12E6
       cmp      r14d, eax
       jae      G_M000_IG507
       mov      eax, r14d
       shl      rax, 4
       add      rax, rdx
       mov      rdx, gword ptr [rax]
       mov      r8, 0x27637001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG312
 
G_M000_IG171:                ;; offset=0x130F
       mov      rdx, gword ptr [rax]
       mov      r8, 0x27637001CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG313
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG314
       mov      r12, gword ptr [rax]
 
G_M000_IG172:                ;; offset=0x1333
       cmp      r14d, dword ptr [r15+0xD8]
       jge      SHORT G_M000_IG177
 
G_M000_IG173:                ;; offset=0x133C
       test     r12, r12
       je       SHORT G_M000_IG176
 
G_M000_IG174:                ;; offset=0x1341
       mov      rax, 0x7FF9D77F4838
       cmp      qword ptr [r12], rax
       jne      SHORT G_M000_IG176
 
G_M000_IG175:                ;; offset=0x1351
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      r12, rax
 
G_M000_IG176:                ;; offset=0x135D
       test     r12, r12
       je       G_M000_IG315
 
G_M000_IG177:                ;; offset=0x1366
       test     r12, r12
       je       G_M000_IG316
       mov      r14, r12
 
G_M000_IG178:                ;; offset=0x1372
       xor      rdx, rdx
       mov      gword ptr [rbp-0x1D8], rdx
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rdx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x18]
       test     eax, eax
       jl       SHORT G_M000_IG181
 
G_M000_IG179:                ;; offset=0x1394
       mov      rcx, rdx
       mov      edx, eax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG180:                ;; offset=0x139F
       xor      r15d, r15d
       jmp      G_M000_IG161
 
G_M000_IG181:                ;; offset=0x13A7
       not      eax
       jmp      SHORT G_M000_IG179
 
G_M000_IG182:                ;; offset=0x13AB
       mov      rax, 0x7FF9D77F4838
       cmp      qword ptr [r13], rax
       jne      G_M000_IG165
 
G_M000_IG183:                ;; offset=0x13BF
       lea      rcx, [rbp-0x1F8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG02
 
G_M000_IG184:                ;; offset=0x13F0
       xor      rax, rax
       mov      gword ptr [rbp-0x200], rax
       cmp      esi, 23
       jne      G_M000_IG384
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rax, gword ptr [rcx]
       mov      rsi, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG507
       mov      ecx, eax
       mov      rbx, gword ptr [rsi+8*rcx+0x10]
       mov      rcx, bword ptr [rbp+0xB48]
       mov      esi, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdi, gword ptr [rcx]
       mov      rax, gword ptr [rcx+0x20]
       test     rax, rax
       je       G_M000_IG385
       lea      rdx, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG185:                ;; offset=0x1455
       mov      r14d, dword ptr [rcx+0x10]
       xor      r8, r8
       mov      gword ptr [rbp-0x208], r8
       test     esi, esi
       jl       G_M000_IG386
 
G_M000_IG186:                ;; offset=0x146B
       cmp      esi, eax
       jae      G_M000_IG507
       mov      eax, esi
       shl      rax, 4
       add      rax, rdx
       mov      rdx, gword ptr [rax]
       mov      r8, 0x27637001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG389
 
G_M000_IG187:                ;; offset=0x1492
       mov      rdx, gword ptr [rax]
       mov      r8, 0x27637001CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG390
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG391
       mov      r15, gword ptr [rax]
 
G_M000_IG188:                ;; offset=0x14B6
       cmp      esi, dword ptr [rdi+0xD8]
       jge      SHORT G_M000_IG193
 
G_M000_IG189:                ;; offset=0x14BE
       test     r15, r15
       je       SHORT G_M000_IG192
 
G_M000_IG190:                ;; offset=0x14C3
       mov      rax, 0x7FF9D77F4838
       cmp      qword ptr [r15], rax
       jne      SHORT G_M000_IG192
 
G_M000_IG191:                ;; offset=0x14D2
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      r15, rax
 
G_M000_IG192:                ;; offset=0x14DE
       test     r15, r15
       je       G_M000_IG392
 
G_M000_IG193:                ;; offset=0x14E7
       test     r15, r15
       je       G_M000_IG393
       mov      r14, r15
 
G_M000_IG194:                ;; offset=0x14F3
       xor      r8, r8
       mov      gword ptr [rbp-0x208], r8
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG200
       test     r14, r14
       je       G_M000_IG200
 
G_M000_IG195:                ;; offset=0x1514
       mov      r8, 0x7FF9D77F9A80
       cmp      qword ptr [r14], r8
       jne      G_M000_IG200
 
G_M000_IG196:                ;; offset=0x1527
       lea      r8, [rbp-0x200]
       mov      rcx, r14
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.PyAttributeLookup:TryResolveInstanceFunctionForCall(Lokad.Lython.Runtime.PyInstance,System.String,byref):bool]
       test     eax, eax
       je       G_M000_IG200
 
G_M000_IG197:                ;; offset=0x1542
       mov      rcx, bword ptr [rbp+0xB48]
       mov      ebx, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      ebx, eax
       je       SHORT G_M000_IG199
 
G_M000_IG198:                ;; offset=0x155D
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r15d, eax
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      ebx, [rax+0x01]
       lea      rcx, [rbp-0x218]
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x218]
       mov      rcx, rdi
       mov      edx, r15d
       mov      r8d, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG199:                ;; offset=0x15AE
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      r14, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      ebx, [rax+0x01]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      esi, eax
       mov      rdx, gword ptr [rbp-0x200]
       lea      rcx, [rbp-0x228]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x228]
       mov      rcx, r14
       mov      edx, ebx
       mov      r8d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG219
 
G_M000_IG200:                ;; offset=0x1606
       mov      rcx, r14
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveBuiltinReceiverMethod(System.Object,System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      rbx, rax
       test     rbx, rbx
       je       G_M000_IG384
       mov      rcx, bword ptr [rbp+0xB48]
       mov      esi, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp+0xB48]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG202
 
G_M000_IG201:                ;; offset=0x1637
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jae      G_M000_IG394
 
G_M000_IG202:                ;; offset=0x164B
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG203:                ;; offset=0x1655
       cmp      esi, eax
       je       G_M000_IG212
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG205
 
G_M000_IG204:                ;; offset=0x1677
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG395
 
G_M000_IG205:                ;; offset=0x168B
       mov      rax, bword ptr [rbp+0xB48]
       mov      edi, dword ptr [rax+0x14]
 
G_M000_IG206:                ;; offset=0x1695
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG208
 
G_M000_IG207:                ;; offset=0x16A4
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG396
 
G_M000_IG208:                ;; offset=0x16B8
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG209:                ;; offset=0x16C2
       lea      r15d, [rax+0x01]
       cmp      r15d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG211
 
G_M000_IG210:                ;; offset=0x16CC
       mov      rcx, rsi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG211:                ;; offset=0x16D8
       mov      rdx, gword ptr [rsi]
       cmp      edi, dword ptr [rdx+0x08]
       jae      G_M000_IG507
       mov      eax, edi
       shl      rax, 4
       lea      rdi, bword ptr [rdx+rax+0x10]
       mov      rcx, rdi
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       mov      dword ptr [rsi+0x40], r15d
 
G_M000_IG212:                ;; offset=0x1704
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG214
 
G_M000_IG213:                ;; offset=0x171E
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG397
 
G_M000_IG214:                ;; offset=0x1732
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG215:                ;; offset=0x173C
       lea      edi, [rax+0x01]
       mov      rdx, bword ptr [rbp+0xB48]
       mov      r14d, dword ptr [rdx+0x18]
       test     r14d, r14d
       jl       SHORT G_M000_IG221
 
G_M000_IG216:                ;; offset=0x174F
       cmp      r14d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG218
 
G_M000_IG217:                ;; offset=0x1755
       mov      rcx, rsi
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG218:                ;; offset=0x1761
       mov      rdx, gword ptr [rsi]
       cmp      edi, dword ptr [rdx+0x08]
       jae      G_M000_IG507
       mov      eax, edi
       shl      rax, 4
       lea      rdi, bword ptr [rdx+rax+0x10]
       mov      rcx, rdi
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       mov      dword ptr [rsi+0x40], r14d
 
G_M000_IG219:                ;; offset=0x178D
       mov      ebx, 1
       mov      r9, gword ptr [rbp+0xBB8]
 
G_M000_IG220:                ;; offset=0x1799
       xor      rdx, rdx
       mov      gword ptr [rbp-0x200], rdx
       test     ebx, ebx
       jne      G_M000_IG02
       jmp      G_M000_IG398
 
G_M000_IG221:                ;; offset=0x17AF
       not      r14d
       jmp      SHORT G_M000_IG216
 
G_M000_IG222:                ;; offset=0x17B4
       mov      r9, gword ptr [rbp+0xBB8]
       movzx    rdx, byte  ptr [rbp+0xBC8]
       mov      dword ptr [rsp+0x20], edx
       mov      rax, bword ptr [rbp+0xBD0]
       mov      bword ptr [rsp+0x28], rax
       mov      r10, bword ptr [rbp+0xBD8]
       mov      bword ptr [rsp+0x30], r10
       mov      r8, bword ptr [rbp+0xBE0]
       mov      bword ptr [rsp+0x38], r8
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       test     eax, eax
       je       G_M000_IG02
       jmp      G_M000_IG439
 
G_M000_IG223:                ;; offset=0x1815
       mov      r9, gword ptr [rbp+0xBB8]
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG304
       cmp      byte  ptr [rbp+0xBC8], 0
       jne      G_M000_IG325
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG224:                ;; offset=0x183E
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2C8], ymm0
 
G_M000_IG225:                ;; offset=0x184B
       lea      r8, [rbp-0x2C8]
       lea      rdx, [rbp+0xAA8]
       mov      rcx, gword ptr [rbp+0xBC0]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      r14, gword ptr [rbp+0xAA8]
 
G_M000_IG226:                ;; offset=0x1870
       vmovdqu  xmm0, xmmword ptr [rbp+0xAA8]
       vmovdqu  xmmword ptr [rbp+0xA98], xmm0
 
G_M000_IG227:                ;; offset=0x1880
       test     r14, r14
       je       G_M000_IG02
       jmp      G_M000_IG323
 
G_M000_IG228:                ;; offset=0x188E
       mov      r9, gword ptr [rbp+0xBB8]
       movzx    rdx, byte  ptr [rbp+0xBC8]
       mov      dword ptr [rsp+0x20], edx
       lea      rdx, [rbp+0xB20]
       mov      qword ptr [rsp+0x28], rdx
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG304
       cmp      byte  ptr [rbp+0xBC8], 0
       jne      G_M000_IG356
       mov      r14, gword ptr [rbp+0xB20]
 
G_M000_IG229:                ;; offset=0x18E6
       vmovdqu  xmm0, xmmword ptr [rbp+0xB20]
       vmovdqu  xmmword ptr [rbp+0xA98], xmm0
 
G_M000_IG230:                ;; offset=0x18F6
       test     r14, r14
       je       G_M000_IG02
       jmp      G_M000_IG354
 
G_M000_IG231:                ;; offset=0x1904
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rbx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      esi, eax
       mov      rcx, bword ptr [rbp+0xB48]
       mov      rdi, gword ptr [rcx]
       xor      rcx, rcx
       mov      gword ptr [rbp-0x230], rcx
       mov      rcx, gword ptr [rbx+0x38]
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG507
       mov      eax, esi
       mov      r14, gword ptr [rcx+8*rax+0x10]
       mov      rcx, gword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      r15, rax
       cmp      byte  ptr [r15+0xFE], 0
       je       G_M000_IG407
       mov      rcx, r15
 
G_M000_IG232:                ;; offset=0x1965
       test     rcx, rcx
       je       SHORT G_M000_IG234
 
G_M000_IG233:                ;; offset=0x196A
       mov      rax, gword ptr [rcx+0x118]
       cmp      rax, gword ptr [rbx+0x40]
       jne      G_M000_IG411
       mov      rax, gword ptr [rbx+0x48]
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG507
       mov      edx, esi
       mov      eax, dword ptr [rax+4*rdx+0x10]
       test     eax, eax
       jge      SHORT G_M000_IG239
 
G_M000_IG234:                ;; offset=0x1992
       mov      rcx, gword ptr [r15+0x08]
       test     rcx, rcx
       je       G_M000_IG412
 
G_M000_IG235:                ;; offset=0x199F
       cmp      byte  ptr [rcx], cl
       mov      rdx, r14
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       jne      G_M000_IG255
 
G_M000_IG236:                ;; offset=0x19B3
       xor      rcx, rcx
       mov      gword ptr [rbp-0x230], rcx
       mov      rcx, gword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rcx+0x98]
       mov      rdx, gword ptr [rdx+0xE8]
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       mov      rdx, r14
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       jne      G_M000_IG254
 
G_M000_IG237:                ;; offset=0x19E8
       xor      rax, rax
       mov      gword ptr [rbp-0x230], rax
 
G_M000_IG238:                ;; offset=0x19F1
       test     eax, eax
       jne      G_M000_IG246
       jmp      G_M000_IG413
 
G_M000_IG239:                ;; offset=0x19FE
       mov      rcx, gword ptr [rcx+0x120]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG507
       mov      eax, eax
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       mov      rax, gword ptr [rcx]
       mov      rdx, 0x27637001CE0
       cmp      rax, gword ptr [rdx]
       je       G_M000_IG408
 
G_M000_IG240:                ;; offset=0x1A2F
       mov      rax, gword ptr [rcx]
       mov      rdx, 0x27637001CE8
       cmp      rax, gword ptr [rdx]
       je       G_M000_IG409
       cmp      qword ptr [rcx+0x08], 0
       jne      G_M000_IG410
       mov      rcx, gword ptr [rcx]
 
G_M000_IG241:                ;; offset=0x1A53
       test     rcx, rcx
       je       SHORT G_M000_IG244
 
G_M000_IG242:                ;; offset=0x1A58
       mov      rax, 0x7FF9D77F4838
       cmp      qword ptr [rcx], rax
       jne      SHORT G_M000_IG244
 
G_M000_IG243:                ;; offset=0x1A67
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       jmp      SHORT G_M000_IG245
 
G_M000_IG244:                ;; offset=0x1A6F
       mov      rax, rcx
 
G_M000_IG245:                ;; offset=0x1A72
       test     rax, rax
       je       G_M000_IG234
       mov      gword ptr [rbp-0x230], rax
 
G_M000_IG246:                ;; offset=0x1A82
       mov      rbx, gword ptr [rbp-0x230]
       xor      rcx, rcx
       mov      gword ptr [rbp-0x230], rcx
       mov      rcx, bword ptr [rbp+0xB48]
       cmp      dword ptr [rcx+0x18], 0
       jl       G_M000_IG257
 
G_M000_IG247:                ;; offset=0x1AA3
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG249
 
G_M000_IG248:                ;; offset=0x1ABD
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG414
 
G_M000_IG249:                ;; offset=0x1AD1
       mov      rdx, bword ptr [rbp+0xB48]
       mov      edi, dword ptr [rdx+0x14]
 
G_M000_IG250:                ;; offset=0x1ADB
       mov      rdx, bword ptr [rbp+0xB48]
       mov      r14d, dword ptr [rdx+0x18]
       test     r14d, r14d
       jl       SHORT G_M000_IG256
 
G_M000_IG251:                ;; offset=0x1AEB
       cmp      r14d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG253
 
G_M000_IG252:                ;; offset=0x1AF1
       mov      rcx, rsi
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG253:                ;; offset=0x1AFD
       mov      rdx, gword ptr [rsi]
       cmp      edi, dword ptr [rdx+0x08]
       jae      G_M000_IG507
       mov      eax, edi
       shl      rax, 4
       lea      rdi, bword ptr [rdx+rax+0x10]
       mov      rcx, rdi
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      r9d, r9d
       mov      qword ptr [rdi+0x08], r9
       mov      dword ptr [rsi+0x40], r14d
       jmp      G_M000_IG02
 
G_M000_IG254:                ;; offset=0x1B2F
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x230], rcx
       mov      eax, 1
       jmp      G_M000_IG238
 
G_M000_IG255:                ;; offset=0x1B43
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x230], rcx
       jmp      G_M000_IG246
 
G_M000_IG256:                ;; offset=0x1B52
       not      r14d
       jmp      SHORT G_M000_IG251
 
G_M000_IG257:                ;; offset=0x1B57
       mov      gword ptr [rbp-0x2A8], rbx
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2A0], r9
       lea      r9, [rbp-0x2A8]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r8, bword ptr [rbp+0xB48]
       mov      rcx, bword ptr [rbp+0xBB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG258:                ;; offset=0x1B8F
       mov      edx, esi
       not      edx
       mov      rax, gword ptr [rdi+0x30]
       cmp      dword ptr [rax+0x08], edx
       jle      G_M000_IG475
       mov      rax, gword ptr [rdi+0x30]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG507
       mov      rcx, gword ptr [rax+8*rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r14, rax
       jmp      G_M000_IG125
 
G_M000_IG259:                ;; offset=0x1BC0
       mov      r10, bword ptr [rbp+0xB48]
       mov      edx, dword ptr [r10+0x18]
       mov      r10d, edx
       not      r10d
       jmp      G_M000_IG130
 
G_M000_IG260:                ;; offset=0x1BD6
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
       lea      rcx, [rbp-0x60]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG261:                ;; offset=0x1BF9
       vmovdqu  ymm0, ymmword ptr [rbp-0x60]
       vmovdqu  ymmword ptr [rbp+0xA20], ymm0
       mov      rcx, qword ptr [rbp-0x40]
       mov      qword ptr [rbp+0xA40], rcx
 
G_M000_IG262:                ;; offset=0x1C11
       mov      ecx, dword ptr [rbp+0xA30]
       cmp      ecx, dword ptr [rbp+0xA40]
       jbe      G_M000_IG504
       jmp      G_M000_IG343
 
G_M000_IG263:                ;; offset=0x1C28
       cmp      edx, 72
       je       G_M000_IG11
 
G_M000_IG264:                ;; offset=0x1C31
       mov      rcx, bword ptr [rbp+0xB48]
       mov      rdx, 0x2965DB6E048
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG265:                ;; offset=0x1C51
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rcx, rax
       mov      rdx, rcx
       jmp      G_M000_IG13
 
G_M000_IG266:                ;; offset=0x1C65
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rcx, rax
       mov      rdx, rcx
       jmp      G_M000_IG13
 
G_M000_IG267:                ;; offset=0x1C79
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rcx, rax
       mov      rdx, rcx
       jmp      G_M000_IG13
 
G_M000_IG268:                ;; offset=0x1C8D
       mov      rcx, rbx
       mov      edx, esi
       mov      r8, rdi
       mov      r9, gword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       jmp      G_M000_IG16
 
G_M000_IG269:                ;; offset=0x1CA7
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       jmp      G_M000_IG20
 
G_M000_IG270:                ;; offset=0x1CBB
       mov      rdx, gword ptr [rsi]
       cmp      r13d, dword ptr [rdx+0x08]
       jae      G_M000_IG507
       mov      eax, r13d
       shl      rax, 4
       mov      rdx, gword ptr [rdx+rax+0x10]
       mov      rcx, 0x7FF9D77F5D30
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       test     r15, r15
       je       G_M000_IG25
       cmp      gword ptr [rsi+0x28], 0
       jne      SHORT G_M000_IG271
       lea      rcx, bword ptr [rsi+0x20]
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG272
 
G_M000_IG271:                ;; offset=0x1D04
       mov      rcx, gword ptr [rsi+0x28]
       lea      rcx, bword ptr [rcx+0x48]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG272:                ;; offset=0x1D14
       lea      rcx, bword ptr [rsi+0x28]
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, gword ptr [rsi]
       cmp      r13d, dword ptr [rdx+0x08]
       jae      G_M000_IG507
       mov      ecx, r13d
       shl      rcx, 4
       lea      rdx, bword ptr [rdx+rcx+0x10]
       xor      rcx, rcx
       mov      gword ptr [rdx], rcx
 
G_M000_IG273:                ;; offset=0x1D3E
       mov      qword ptr [rdx+0x08], rcx
       jmp      G_M000_IG33
 
G_M000_IG274:                ;; offset=0x1D47
       mov      rcx, 0x7FF9D77DE450
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       jmp      G_M000_IG27
 
G_M000_IG275:                ;; offset=0x1D5B
       mov      r8, gword ptr [r15+0x10]
       mov      r8d, dword ptr [r8+0x08]
       mov      r10, gword ptr [rax+0x10]
       cmp      r8d, dword ptr [r10+0x08]
       jge      G_M000_IG43
       jmp      G_M000_IG32
 
G_M000_IG276:                ;; offset=0x1D76
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:ReleaseStorage():this]
       jmp      G_M000_IG33
 
G_M000_IG277:                ;; offset=0x1D84
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
       jmp      G_M000_IG33
 
G_M000_IG278:                ;; offset=0x1D96
       mov      rax, gword ptr [r15]
       mov      gword ptr [rbp-0x2E8], rax
       mov      rdx, rax
       mov      rcx, 0x7FF9D7763360
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG279
       mov      rdx, gword ptr [rbp-0x2E8]
       mov      rcx, 0x7FF9D71628A8
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       jne      SHORT G_M000_IG279
       mov      rdx, gword ptr [rbp-0x2E8]
       mov      rcx, 0x7FF9D76708D0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       sete     cl
       movzx    rcx, cl
       test     ecx, ecx
       jne      G_M000_IG45
 
G_M000_IG279:                ;; offset=0x1DF9
       mov      rax, gword ptr [r15]
       mov      gword ptr [rbp-0x2E0], rax
       xor      edx, edx
       mov      qword ptr [r15], rdx
       mov      qword ptr [r15+0x08], rdx
       mov      rdx, rax
       mov      rcx, 0x7FF9D71628A8
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       je       SHORT G_M000_IG280
       mov      ecx, dword ptr [rax+0x08]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:RecordBytes(int):long]
       mov      rdx, rax
       mov      rcx, r12
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Release(long):this]
       jmp      G_M000_IG33
 
G_M000_IG280:                ;; offset=0x1E3F
       mov      rcx, r12
       mov      rdx, gword ptr [rbp-0x2E0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:RefundUnpublishedValue(System.Object):this]
       jmp      G_M000_IG33
 
G_M000_IG281:                ;; offset=0x1E56
       mov      rax, gword ptr [r15]
       mov      rdx, 0x27637001CE0
       cmp      rax, gword ptr [rdx]
       je       G_M000_IG33
       mov      rax, gword ptr [r15]
       mov      rdx, 0x27637001CE8
       cmp      rax, gword ptr [rdx]
       je       G_M000_IG33
       xor      eax, eax
       mov      qword ptr [r15], rax
       mov      qword ptr [r15+0x08], rax
       mov      rcx, 0x7FF9D764E798
       call     [CORINFO_HELP_GET_NONGCSTATIC_BASE]
       mov      rdx, qword ptr [(reloc 0x7ff9d709b100)]
       mov      rcx, r12
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Release(long):this]
       jmp      G_M000_IG33
 
G_M000_IG282:                ;; offset=0x1EB2
       mov      ecx, 2
       call     [System.ThrowHelper:ThrowArgumentNullException(int)]
       int3     
 
G_M000_IG283:                ;; offset=0x1EBE
       mov      r10d, dword ptr [r11+0x04]
       add      r10d, -24
       shr      r10d, 3
       movsxd   r15, r10d
       mov      r15d, dword ptr [r8+4*r15]
       shl      r10d, 3
       movsxd   r10, r10d
       add      r8, r10
       mov      r10d, r15d
       jmp      G_M000_IG35
 
G_M000_IG284:                ;; offset=0x1EE3
       mov      rcx, r10
       call     [System.SpanHelpers:ClearWithoutReferences(byref,nuint)]
       jmp      G_M000_IG37
 
G_M000_IG285:                ;; offset=0x1EF1
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG49
 
G_M000_IG286:                ;; offset=0x1F03
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
 
G_M000_IG287:                ;; offset=0x1F26
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x2A8], xmm0
 
G_M000_IG288:                ;; offset=0x1F36
       mov      edx, esi
       mov      rcx, rbx
       lea      r9, [rbp-0x2A8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG02
 
G_M000_IG289:                ;; offset=0x1F4D
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG52
 
G_M000_IG290:                ;; offset=0x1F5F
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG291:                ;; offset=0x1F66
       mov      rcx, rax
       mov      edx, edi
       mov      r11, 0x7FF9D70A29D8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r14, rax
       jmp      G_M000_IG57
 
G_M000_IG292:                ;; offset=0x1F80
       lea      rcx, [rbp-0x1C0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       mov      rdx, r14
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreGlobalNamespaceName(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,System.Object)]
       jmp      G_M000_IG62
 
G_M000_IG293:                ;; offset=0x1FB8
       mov      rdx, gword ptr [rbp+0xBC0]
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionFrame:get_Variables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rbx, rax
       mov      ecx, edi
       shl      rcx, 4
       lea      rcx, bword ptr [rsi+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       cmp      byte  ptr [rbx], bl
       mov      rcx, rbx
       mov      rdx, r14
       mov      r9d, 1
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryInsert(System.__Canon,System.__Canon,byte):bool:this]
       jmp      G_M000_IG62
 
G_M000_IG294:                ;; offset=0x200D
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       jne      SHORT G_M000_IG295
       xor      rax, rax
       xor      r8d, r8d
       jmp      SHORT G_M000_IG296
 
G_M000_IG295:                ;; offset=0x201D
       lea      rax, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
 
G_M000_IG296:                ;; offset=0x2025
       mov      bword ptr [rbp-0x298], rax
       mov      dword ptr [rbp-0x290], r8d
 
G_M000_IG297:                ;; offset=0x2033
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x2A8], xmm0
 
G_M000_IG298:                ;; offset=0x2043
       lea      rcx, [rbp-0x298]
       lea      r8, [rbp-0x2A8]
       mov      rbx, bword ptr [rbp+0xBB0]
       mov      r9, gword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG62
 
G_M000_IG299:                ;; offset=0x2067
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2965DB72BE0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG300:                ;; offset=0x2095
       lea      rcx, [rbp-0x1B0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       jmp      G_M000_IG62
 
G_M000_IG301:                ;; offset=0x20BA
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rbx, gword ptr [rcx+0x08]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG507
       mov      ecx, eax
       shl      rcx, 4
       cmp      gword ptr [rbx+rcx+0x10], 0
       jne      G_M000_IG02
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rcx]
       mov      rbx, gword ptr [rdx+0x68]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A29C0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, bword ptr [rbp+0xB48]
       mov      rdx, gword ptr [rdx]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG302:                ;; offset=0x2136
       mov      rcx, bword ptr [rbp+0xBB0]
       cmp      gword ptr [rcx+0x40], 0
       jne      SHORT G_M000_IG303
       mov      r9, gword ptr [rbp+0xBB8]
       mov      gword ptr [rsp+0x20], r9
       mov      rcx, gword ptr [rcx]
       mov      rbx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbx+0x18]
       mov      r8d, dword ptr [rbx+0x10]
       mov      r9d, dword ptr [rbx+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG303
       add      dword ptr [rbx+0x10], 2
       jmp      G_M000_IG02
 
G_M000_IG303:                ;; offset=0x2179
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      r8d, eax
       lea      r9, [rbp+0xB40]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, bword ptr [rbp+0xB48]
       mov      r9, gword ptr [r9]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      rcx, bword ptr [rbp+0xBB0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG305
 
G_M000_IG304:                ;; offset=0x21B7
       mov      dword ptr [rbp+0xAB8], 6
       jmp      G_M000_IG508
 
G_M000_IG305:                ;; offset=0x21C6
       mov      rdx, gword ptr [rbp+0xB40]
       lea      rcx, [rbp-0x1D0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x1D0]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r8, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG306:                ;; offset=0x2201
       cmp      eax, 72
       je       G_M000_IG155
       jmp      G_M000_IG264
 
G_M000_IG307:                ;; offset=0x220F
       lea      r14, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      r15d, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
       mov      edx, r15d
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG180
 
G_M000_IG308:                ;; offset=0x2242
       xor      rdx, rdx
       xor      eax, eax
       jmp      G_M000_IG169
 
G_M000_IG309:                ;; offset=0x224B
       mov      edx, r14d
       not      edx
       mov      rax, gword ptr [r15+0x30]
       cmp      dword ptr [rax+0x08], edx
       jle      SHORT G_M000_IG310
       mov      rax, gword ptr [r15+0x30]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG507
       mov      rcx, gword ptr [rax+8*rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r14, rax
       jmp      G_M000_IG178
 
G_M000_IG310:                ;; offset=0x2279
       mov      r8, gword ptr [r15+0x38]
       mov      rax, gword ptr [r15+0x30]
       mov      r10d, edx
       sub      r10d, dword ptr [rax+0x08]
       cmp      r10d, dword ptr [r8+0x08]
       jae      G_M000_IG507
       mov      eax, r10d
       mov      r12, gword ptr [r8+8*rax+0x10]
       mov      r8, gword ptr [r15+0x30]
       sub      edx, dword ptr [r8+0x08]
       lea      r9, [rbp-0x1D8]
       mov      rcx, r15
       mov      r8, gword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG311
       mov      rcx, r15
       mov      edx, r13d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG311:                ;; offset=0x22E1
       mov      r14, gword ptr [rbp-0x1D8]
       jmp      G_M000_IG178
 
G_M000_IG312:                ;; offset=0x22ED
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG172
 
G_M000_IG313:                ;; offset=0x22FE
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG172
 
G_M000_IG314:                ;; offset=0x230F
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG172
 
G_M000_IG315:                ;; offset=0x2320
       mov      rcx, r15
       mov      edx, r13d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, r14d
       mov      rcx, r15
       mov      r9, gword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
       jmp      G_M000_IG178
 
G_M000_IG316:                ;; offset=0x234D
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rcx, r15
       mov      rdx, 0x2965DB6AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG317:                ;; offset=0x237B
       lea      rcx, [rbp-0x1E8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       jmp      G_M000_IG160
 
G_M000_IG318:                ;; offset=0x23A0
       mov      rcx, rdx
       mov      edx, esi
       mov      r11, 0x7FF9D70A29E0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r14, rax
       jmp      G_M000_IG162
 
G_M000_IG319:                ;; offset=0x23BA
       xor      rax, rax
       jmp      G_M000_IG164
 
G_M000_IG320:                ;; offset=0x23C1
       lea      rcx, [rbp-0x1F8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       mov      rdx, r14
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreGlobalNamespaceName(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,System.Object)]
       jmp      G_M000_IG02
 
G_M000_IG321:                ;; offset=0x23F9
       mov      rdx, gword ptr [rbp+0xBC0]
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionFrame:get_Variables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rbx, rax
       mov      ecx, esi
       shl      rcx, 4
       lea      rcx, bword ptr [rdi+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       cmp      byte  ptr [rbx], bl
       mov      rcx, rbx
       mov      rdx, r14
       mov      r9d, 1
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryInsert(System.__Canon,System.__Canon,byte):bool:this]
       jmp      G_M000_IG02
 
G_M000_IG322:                ;; offset=0x244E
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r8, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
       jmp      G_M000_IG304
 
G_M000_IG323:                ;; offset=0x2476
       mov      rdx, r14
       mov      rcx, 0x7FF9D74947C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG324
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG324:                ;; offset=0x24B2
       mov      rcx, r14
       movsx    rdx, word  ptr [rbp+0xAA0]
       mov      r11, 0x7FF9D70A29E8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG325:                ;; offset=0x24CF
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG326:                ;; offset=0x24D6
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2C8], ymm0
 
G_M000_IG327:                ;; offset=0x24E3
       lea      r8, [rbp-0x2C8]
       lea      rdx, [rbp-0x160]
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x170]
       lea      rdx, [rbp-0x160]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0xBD0]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x170]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x168]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0xBD0]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       SHORT G_M000_IG331
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG328
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG329
 
G_M000_IG328:                ;; offset=0x2573
       mov      rax, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A29F0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG329:                ;; offset=0x2599
       test     esi, esi
       jne      SHORT G_M000_IG331
 
G_M000_IG330:                ;; offset=0x259D
       mov      rcx, bword ptr [rbp+0xB48]
       mov      rdx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0xBD8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp+0xAB8], 4
       jmp      G_M000_IG508
 
G_M000_IG331:                ;; offset=0x25C2
       mov      rax, bword ptr [rbp+0xBD0]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG02
 
G_M000_IG332:                ;; offset=0x25D7
       mov      rax, gword ptr [rbp+0xBC0]
       mov      r10, rax
       test     r10, r10
       jne      SHORT G_M000_IG333
       mov      r9, gword ptr [rbp+0xBB8]
       mov      r10, r9
 
G_M000_IG333:                ;; offset=0x25F0
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, rax
       mov      r8, bword ptr [rbp+0xB48]
       mov      r9, r10
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG02
       movzx    rax, byte  ptr [rbp+0xBC8]
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG304
       test     al, al
       jne      G_M000_IG337
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG334:                ;; offset=0x2636
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2C8], ymm0
 
G_M000_IG335:                ;; offset=0x2643
       lea      r8, [rbp-0x2C8]
       lea      rdx, [rbp+0xAA8]
       mov      rcx, gword ptr [rbp+0xBC0]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp+0xAA8]
       lea      rdx, [rbp+0xA98]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       mov      rbx, gword ptr [rbp+0xA98]
       test     rbx, rbx
       je       G_M000_IG02
       mov      rdx, rbx
       mov      rcx, 0x7FF9D74947C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG336
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG336:                ;; offset=0x26C1
       mov      rcx, rbx
       movsx    rdx, word  ptr [rbp+0xAA0]
       mov      r11, 0x7FF9D70A29F8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG337:                ;; offset=0x26DE
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG338:                ;; offset=0x26E5
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2C8], ymm0
 
G_M000_IG339:                ;; offset=0x26F2
       lea      r8, [rbp-0x2C8]
       lea      rdx, [rbp-0x80]
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x90]
       lea      rdx, [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0x90]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x88]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG331
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG340
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG341
 
G_M000_IG340:                ;; offset=0x2780
       mov      rcx, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A2A00
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG341:                ;; offset=0x27A6
       test     esi, esi
       jne      G_M000_IG331
       jmp      G_M000_IG330
 
G_M000_IG342:                ;; offset=0x27B3
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rax, gword ptr [rcx]
       mov      rbx, gword ptr [rax+0x30]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG507
       mov      edx, eax
       mov      rdx, gword ptr [rbx+8*rdx+0x10]
       mov      rcx, 0x7FF9D759EAB0
       call     CORINFO_HELP_CHKCASTCLASS
       mov      rbx, rax
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rsi, gword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       sub      r14d, eax
       test     rsi, rsi
       jne      SHORT G_M000_IG345
       or       edi, r14d
       je       SHORT G_M000_IG344
 
G_M000_IG343:                ;; offset=0x2834
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG344:                ;; offset=0x283B
       xor      rdx, rdx
       xor      ecx, ecx
       jmp      SHORT G_M000_IG346
 
G_M000_IG345:                ;; offset=0x2841
       mov      edx, edi
       mov      ecx, r14d
       add      rdx, rcx
       mov      ecx, dword ptr [rsi+0x08]
       cmp      rdx, rcx
       ja       SHORT G_M000_IG343
       mov      edx, edi
       shl      rdx, 4
       lea      rdx, bword ptr [rsi+rdx+0x10]
       mov      ecx, r14d
 
G_M000_IG346:                ;; offset=0x285F
       mov      r8, bword ptr [rbp+0xB48]
       cmp      dword ptr [r8+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      rax, gword ptr [rbp+0xBC0]
       mov      r9, rax
       test     r9, r9
       mov      r10, r9
       jne      SHORT G_M000_IG347
       mov      r9, gword ptr [rbp+0xBB8]
       mov      r10, r9
 
G_M000_IG347:                ;; offset=0x288F
       mov      bword ptr [rbp-0x298], rdx
       mov      dword ptr [rbp-0x290], ecx
       mov      rdx, bword ptr [rbp+0xB48]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x298]
       mov      rcx, rbx
       mov      r9, r10
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      dword ptr [rcx+0x60], eax
       jmp      G_M000_IG02
 
G_M000_IG348:                ;; offset=0x28DA
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r9d, eax
       mov      r8d, esi
       mov      rcx, rbx
       lea      rdx, [rbp+0xB30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       jne      SHORT G_M000_IG349
       xor      r9, r9
       xor      r8d, r8d
       jmp      SHORT G_M000_IG350
 
G_M000_IG349:                ;; offset=0x292F
       lea      r9, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
 
G_M000_IG350:                ;; offset=0x2937
       mov      rax, gword ptr [rbp+0xBC0]
       mov      rdx, rax
       test     rdx, rdx
       jne      SHORT G_M000_IG351
       mov      r10, gword ptr [rbp+0xBB8]
       mov      rdx, r10
 
G_M000_IG351:                ;; offset=0x2950
       mov      bword ptr [rbp-0x298], r9
       mov      dword ptr [rbp-0x290], r8d
 
G_M000_IG352:                ;; offset=0x295E
       vmovdqu  xmm0, xmmword ptr [rbp+0xB30]
       vmovdqu  xmmword ptr [rbp-0x2A8], xmm0
 
G_M000_IG353:                ;; offset=0x296E
       lea      rcx, [rbp-0x298]
       lea      r8, [rbp-0x2A8]
       mov      r9, gword ptr [rdx+0x98]
       mov      rdx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG02
 
G_M000_IG354:                ;; offset=0x2995
       mov      rdx, r14
       mov      rcx, 0x7FF9D74947C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG355
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG355:                ;; offset=0x29D1
       mov      rcx, r14
       movsx    rdx, word  ptr [rbp+0xAA0]
       mov      r11, 0x7FF9D70A2A08
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG356:                ;; offset=0x29EE
       vmovdqu  xmm0, xmmword ptr [rbp+0xB20]
       vmovdqu  xmmword ptr [rbp-0x2D8], xmm0
 
G_M000_IG357:                ;; offset=0x29FE
       lea      rdx, [rbp-0x2D8]
       lea      rcx, [rbp-0x180]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0xBD0]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x180]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x178]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0xBD0]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG331
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG358
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG359
 
G_M000_IG358:                ;; offset=0x2A71
       mov      rax, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A2A10
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG359:                ;; offset=0x2A97
       test     esi, esi
       jne      G_M000_IG331
       jmp      G_M000_IG330
 
G_M000_IG360:                ;; offset=0x2AA4
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG304
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r9d, eax
       mov      r8d, edi
       mov      rcx, rsi
       lea      rdx, [rbp+0xA88]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      esi, dword ptr [rcx+0x10]
       inc      esi
       mov      rax, gword ptr [rbp+0xBC0]
       mov      rdi, gword ptr [rax+0x70]
       cmp      byte  ptr [rax+0x101], 0
       jne      SHORT G_M000_IG361
       cmp      byte  ptr [rax+0xFF], 0
       jne      SHORT G_M000_IG361
       cmp      ebx, esi
       jle      SHORT G_M000_IG361
       cmp      esi, ebx
       jae      G_M000_IG507
       mov      r8, gword ptr [rbp+0xB60]
       mov      edx, esi
       shl      rdx, 5
       cmp      dword ptr [r8+rdx+0x2C], 30
       sete     r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG362
 
G_M000_IG361:                ;; offset=0x2B3C
       xor      r14d, r14d
 
G_M000_IG362:                ;; offset=0x2B3F
       test     r14d, r14d
       je       G_M000_IG368
       test     rdi, rdi
       je       G_M000_IG368
 
G_M000_IG363:                ;; offset=0x2B51
       vmovdqu  xmm0, xmmword ptr [rbp+0xA88]
       vmovdqu  xmmword ptr [rbp-0x2A8], xmm0
 
G_M000_IG364:                ;; offset=0x2B61
       lea      r8, [rbp-0x2A8]
       mov      rdx, rdi
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       je       G_M000_IG368
       cmp      esi, ebx
       jae      G_M000_IG507
       mov      rcx, gword ptr [rbp+0xB60]
       mov      eax, esi
       shl      rax, 5
       mov      r14, gword ptr [rcx+rax+0x10]
       mov      r9, gword ptr [rbp+0xBB8]
       mov      rdi, gword ptr [r9+0x98]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG365
       mov      rcx, rdi
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG365:                ;; offset=0x2BC0
       mov      r9, gword ptr [rbp+0xBB8]
       mov      rbx, gword ptr [r9+0x98]
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasActiveHandler():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG366
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      rdx, gword ptr [rcx+0x80]
       jmp      SHORT G_M000_IG367
 
G_M000_IG366:                ;; offset=0x2BEF
       mov      r9, gword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [r9+0x98]
       mov      rdx, gword ptr [rdx+0x148]
 
G_M000_IG367:                ;; offset=0x2C04
       lea      rcx, bword ptr [rbx+0x148]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, gword ptr [rbp+0xB60]
       mov      edx, esi
       shl      rdx, 5
       lea      rcx, bword ptr [rax+rdx+0x10]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xBB0]
       add      dword ptr [rcx+0x10], 2
       jmp      G_M000_IG514
 
G_M000_IG368:                ;; offset=0x2C4E
       mov      rax, gword ptr [rbp+0xBC0]
       lea      rbx, bword ptr [rax+0x190]
       mov      rdx, gword ptr [rbp+0xA88]
       mov      rcx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp+0xA90]
       mov      qword ptr [rbx+0x08], rcx
       mov      rax, gword ptr [rbp+0xBC0]
       mov      word  ptr [rax+0xF8], 257
       mov      rcx, bword ptr [rbp+0xBB0]
       inc      dword ptr [rcx+0x10]
       test     r14d, r14d
       jne      G_M000_IG136
       test     rdi, rdi
       je       G_M000_IG136
       mov      rcx, rax
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG136
       jmp      G_M000_IG514
 
G_M000_IG369:                ;; offset=0x2CBB
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG304
       cmp      byte  ptr [rbp+0xBC8], 0
       je       G_M000_IG375
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG370:                ;; offset=0x2CDD
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2C8], ymm0
 
G_M000_IG371:                ;; offset=0x2CEA
       lea      r8, [rbp-0x2C8]
       lea      rdx, [rbp-0xB0]
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0xB0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xA8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       je       SHORT G_M000_IG374
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG372
       test     dword ptr [rax+0x34], 0x1600000
       setne    bl
       movzx    rbx, bl
       jmp      SHORT G_M000_IG373
 
G_M000_IG372:                ;; offset=0x2D5E
       mov      rcx, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A2A18
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    bl
       movzx    rbx, bl
 
G_M000_IG373:                ;; offset=0x2D82
       test     ebx, ebx
       je       G_M000_IG330
 
G_M000_IG374:                ;; offset=0x2D8A
       mov      rcx, bword ptr [rbp+0xBD0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG379
 
G_M000_IG375:                ;; offset=0x2D9C
       mov      rax, gword ptr [rbp+0xBC0]
       cmp      gword ptr [rax+0x68], 0
       jne      G_M000_IG376
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp+0xB48]
       mov      esi, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r8d, eax
       mov      edx, esi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rbx, rax
       mov      rcx, 0x7FF9D71628A8
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      rsi, rax
       lea      rcx, bword ptr [rsi+0x10]
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, bword ptr [rbp+0xB48]
       mov      rdx, gword ptr [rdx]
       mov      rcx, rsi
       mov      r8, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbx, rax
       mov      rcx, 0x7FF9D77F7DB8
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      r9, bword ptr [rbp+0xB48]
       mov      r9, gword ptr [r9]
       mov      rcx, rsi
       mov      rdx, rbx
       mov      r8, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:.ctor(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0xBC0]
       lea      rcx, bword ptr [rax+0x68]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG376:                ;; offset=0x2E63
       mov      rax, gword ptr [rbp+0xBC0]
       mov      rcx, gword ptr [rax+0x68]
       mov      r8, gword ptr [rax+0x58]
       mov      r9, gword ptr [rax+0x60]
       lea      rdx, [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:Advance(System.Object,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.PyIterationResult:this]
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG377:                ;; offset=0x2E8C
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2C8], ymm0
 
G_M000_IG378:                ;; offset=0x2E99
       lea      r8, [rbp-0x2C8]
       lea      rdx, [rbp-0xA0]
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
 
G_M000_IG379:                ;; offset=0x2EB4
       mov      rcx, gword ptr [rbp+0xBC0]
       cmp      byte  ptr [rcx+0xF9], 0
       je       G_M000_IG02
       movzx    rax, byte  ptr [rbp+0xBC8]
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      rdx, gword ptr [rcx+0x70]
       test     rdx, rdx
       je       G_M000_IG136
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG136
       jmp      G_M000_IG514
 
G_M000_IG380:                ;; offset=0x2EF6
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG304
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rcx]
       mov      rbx, gword ptr [rdx+0xA8]
       mov      rcx, bword ptr [rbp+0xB48]
       xor      edx, edx
       mov      r8, 0x2965DB746A8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:ReadPrimaryOperand(int,System.String):int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A29D0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       cmp      byte  ptr [rbp+0xBC8], 0
       jne      SHORT G_M000_IG381
       mov      rbx, bword ptr [rbp+0xBB0]
       mov      rcx, gword ptr [rbx]
       mov      r8, gword ptr [rbx+0x08]
       mov      rdx, rax
       mov      r9, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG02
 
G_M000_IG381:                ;; offset=0x2F6C
       lea      rcx, [rbp-0x190]
       mov      rdx, rax
       mov      r8, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
       lea      rcx, [rbp-0x1A0]
       lea      rdx, [rbp-0x190]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0xBD0]
       mov      rsi, rax
       mov      rdx, gword ptr [rbp-0x1A0]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x198]
       mov      qword ptr [rsi+0x08], rdx
       mov      rax, bword ptr [rbp+0xBD0]
       mov      rsi, gword ptr [rax]
       test     rsi, rsi
       je       G_M000_IG331
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG382
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG383
 
G_M000_IG382:                ;; offset=0x2FF6
       mov      rax, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A2A20
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG383:                ;; offset=0x301C
       test     edi, edi
       jne      G_M000_IG331
       jmp      G_M000_IG330
 
G_M000_IG384:                ;; offset=0x3029
       mov      r9, gword ptr [rbp+0xBB8]
       xor      ebx, ebx
       jmp      G_M000_IG220
 
G_M000_IG385:                ;; offset=0x3037
       xor      rdx, rdx
       xor      eax, eax
       jmp      G_M000_IG185
 
G_M000_IG386:                ;; offset=0x3040
       mov      edx, esi
       not      edx
       mov      rsi, gword ptr [rdi+0x30]
       cmp      dword ptr [rsi+0x08], edx
       jle      SHORT G_M000_IG387
       cmp      edx, dword ptr [rsi+0x08]
       jae      G_M000_IG507
       mov      eax, edx
       mov      rcx, gword ptr [rsi+8*rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r14, rax
       jmp      G_M000_IG194
 
G_M000_IG387:                ;; offset=0x306B
       mov      r9, gword ptr [rdi+0x38]
       mov      r8d, edx
       sub      r8d, dword ptr [rsi+0x08]
       cmp      r8d, dword ptr [r9+0x08]
       jae      G_M000_IG507
       mov      r15, gword ptr [r9+8*r8+0x10]
       sub      edx, dword ptr [rsi+0x08]
       lea      r9, [rbp-0x208]
       mov      rcx, rdi
       mov      r8, gword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG388
       mov      rcx, rdi
       mov      edx, r14d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG388:                ;; offset=0x30C7
       mov      r14, gword ptr [rbp-0x208]
       jmp      G_M000_IG194
 
G_M000_IG389:                ;; offset=0x30D3
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG188
 
G_M000_IG390:                ;; offset=0x30E4
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG188
 
G_M000_IG391:                ;; offset=0x30F5
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG188
 
G_M000_IG392:                ;; offset=0x3106
       mov      rcx, rdi
       mov      edx, r14d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, esi
       mov      rcx, rdi
       mov      r9, gword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
       jmp      G_M000_IG194
 
G_M000_IG393:                ;; offset=0x3132
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      rcx, rsi
       mov      rdx, 0x2965DB6AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG394:                ;; offset=0x3160
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG203
 
G_M000_IG395:                ;; offset=0x3172
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       jmp      G_M000_IG206
 
G_M000_IG396:                ;; offset=0x3186
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG209
 
G_M000_IG397:                ;; offset=0x3198
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG215
 
G_M000_IG398:                ;; offset=0x31AA
       movzx    rax, byte  ptr [rbp+0xBC8]
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG304
       test     al, al
       jne      SHORT G_M000_IG399
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG02
 
G_M000_IG399:                ;; offset=0x31E6
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG400:                ;; offset=0x31ED
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2C8], ymm0
 
G_M000_IG401:                ;; offset=0x31FA
       lea      r8, [rbp-0x2C8]
       lea      rdx, [rbp-0x150]
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0x150]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x148]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG331
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG402
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG403
 
G_M000_IG402:                ;; offset=0x3274
       mov      rcx, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A2A28
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG403:                ;; offset=0x329A
       test     esi, esi
       jne      G_M000_IG331
       jmp      G_M000_IG330
 
G_M000_IG404:                ;; offset=0x32A7
       mov      rcx, bword ptr [rbp+0xB48]
       mov      rdx, 0x2965DB6D5F8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG405:                ;; offset=0x32C7
       cmp      edx, 64
       je       G_M000_IG69
       cmp      edx, 67
       je       G_M000_IG69
       cmp      edx, 70
       jne      SHORT G_M000_IG404
       jmp      G_M000_IG69
 
G_M000_IG406:                ;; offset=0x32E3
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       jmp      G_M000_IG73
 
G_M000_IG407:                ;; offset=0x32F8
       xor      rcx, rcx
       jmp      G_M000_IG232
 
G_M000_IG408:                ;; offset=0x32FF
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rcx, rax
       jmp      G_M000_IG241
 
G_M000_IG409:                ;; offset=0x330D
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rcx, rax
       jmp      G_M000_IG241
 
G_M000_IG410:                ;; offset=0x331B
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rcx, rax
       jmp      G_M000_IG241
 
G_M000_IG411:                ;; offset=0x3329
       lea      r8, [rbp-0x230]
       mov      rdx, r14
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryResolveLocalOrClosure(System.String,byref):bool:this]
       test     eax, eax
       je       G_M000_IG234
       jmp      G_M000_IG246
 
G_M000_IG412:                ;; offset=0x3348
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionFrame:InitializeVariables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rcx, rax
       jmp      G_M000_IG235
 
G_M000_IG413:                ;; offset=0x3359
       mov      rcx, gword ptr [rbx+0x38]
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG507
       mov      edx, esi
       mov      rcx, gword ptr [rcx+8*rdx+0x10]
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG414:                ;; offset=0x337F
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       jmp      G_M000_IG250
 
G_M000_IG415:                ;; offset=0x3393
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG304
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rax, gword ptr [rcx]
       mov      rbx, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG507
       mov      ecx, eax
       mov      rcx, gword ptr [rbx+8*rcx+0x10]
       mov      rdx, bword ptr [rbp+0xB48]
       mov      rdx, gword ptr [rdx]
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      rdx, rax
       lea      rcx, [rbp-0x240]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x240]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r8, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG416:                ;; offset=0x3420
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG304
       mov      rdx, bword ptr [rbp+0xB48]
       mov      rdx, gword ptr [rdx]
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG417:                ;; offset=0x344A
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG304
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rax, gword ptr [rcx]
       mov      rbx, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG507
       mov      ecx, eax
       mov      rbx, gword ptr [rbx+8*rcx+0x10]
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
       mov      edx, edi
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rdx, rax
       mov      rcx, rbx
       mov      r9, bword ptr [rbp+0xB48]
       mov      r9, gword ptr [r9]
       mov      r8, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG418:                ;; offset=0x34D5
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r9, rax
       jmp      G_M000_IG150
 
G_M000_IG419:                ;; offset=0x34E6
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r9, rax
       jmp      G_M000_IG150
 
G_M000_IG420:                ;; offset=0x34F7
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r9, rax
       jmp      G_M000_IG150
 
G_M000_IG421:                ;; offset=0x3508
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2965DB6AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG422:                ;; offset=0x3536
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG140
 
G_M000_IG423:                ;; offset=0x3548
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2965DB6AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG424:                ;; offset=0x3576
       mov      rdx, bword ptr [rbp+0xB48]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xBB0]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG02
 
G_M000_IG425:                ;; offset=0x35B9
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      esi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      r9, gword ptr [rbp+0xBB8]
       mov      gword ptr [rsp+0x20], r9
       mov      edx, esi
       mov      rcx, rbx
       mov      rax, bword ptr [rbp+0xB48]
       mov      r9, gword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      rdx, rax
       lea      rcx, [rbp-0x250]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x250]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r8, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG426:                ;; offset=0x3636
       cmp      gword ptr [rbp+0xBC0], 0
       je       SHORT G_M000_IG427
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      rdx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG136
 
G_M000_IG427:                ;; offset=0x365C
       mov      rax, bword ptr [rbp+0xBE8]
       cmp      dword ptr [rax+0x08], 0
       je       SHORT G_M000_IG430
       mov      r8d, dword ptr [rax+0x08]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       je       SHORT G_M000_IG430
 
G_M000_IG428:                ;; offset=0x3685
       mov      rax, bword ptr [rbp+0xBE8]
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x298], xmm0
 
G_M000_IG429:                ;; offset=0x3698
       lea      r9, [rbp-0x298]
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r8, bword ptr [rbp+0xB48]
       mov      rcx, bword ptr [rbp+0xBB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp+0xAB8], 2
       jmp      G_M000_IG508
 
G_M000_IG430:                ;; offset=0x36C9
       mov      rcx, bword ptr [rbp+0xBB0]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp+0xB48]
       mov      esi, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      r9, gword ptr [rbp+0xBB8]
       mov      gword ptr [rsp+0x20], r9
       mov      edx, esi
       mov      rcx, rbx
       mov      rax, bword ptr [rbp+0xB48]
       mov      r9, gword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       lea      rcx, [rbp-0x260]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x260]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBC0]
       mov      r8, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG431:                ;; offset=0x3746
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG432:                ;; offset=0x374D
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2C8], ymm0
 
G_M000_IG433:                ;; offset=0x375A
       lea      r8, [rbp-0x2C8]
       lea      rdx, [rbp-0x140]
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r10, bword ptr [rbp+0xBD0]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0x140]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x138]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xBD0]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       SHORT G_M000_IG436
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG434
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG435
 
G_M000_IG434:                ;; offset=0x37D0
       mov      r10, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A2A30
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG435:                ;; offset=0x37F6
       test     esi, esi
       je       G_M000_IG330
 
G_M000_IG436:                ;; offset=0x37FE
       mov      r10, bword ptr [rbp+0xBD0]
       mov      rcx, r10
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp+0xB5C], eax
       jmp      G_M000_IG02
 
G_M000_IG437:                ;; offset=0x3819
       mov      r9, gword ptr [rbp+0xBB8]
       movzx    rdx, byte  ptr [rbp+0xBC8]
       mov      dword ptr [rsp+0x20], edx
       mov      rax, bword ptr [rbp+0xBD0]
       mov      bword ptr [rsp+0x28], rax
       mov      r10, bword ptr [rbp+0xBD8]
       mov      bword ptr [rsp+0x30], r10
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       test     eax, eax
       je       SHORT G_M000_IG436
       mov      dword ptr [rbp+0xAB8], eax
       jmp      G_M000_IG508
 
G_M000_IG438:                ;; offset=0x3870
       mov      r9, gword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
       jmp      G_M000_IG222
 
G_M000_IG439:                ;; offset=0x38A2
       mov      r8d, eax
       movzx    rax, byte  ptr [rbp+0xBC8]
       mov      dword ptr [rbp+0xAB8], r8d
       jmp      G_M000_IG508
 
G_M000_IG440:                ;; offset=0x38B8
       mov      r9, gword ptr [rbp+0xBB8]
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG97
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      ebx, dword ptr [rcx+0x60]
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      ebx, eax
       jne      G_M000_IG97
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xB48]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG507
       shl      rax, 4
       mov      rdx, gword ptr [rdx+rax+0x10]
       mov      rcx, 0x7FF9D77F5D30
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbx, rax
       test     rbx, rbx
       je       G_M000_IG97
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       test     rax, rax
       je       G_M000_IG97
       cmp      gword ptr [rax+0x20], 0
       je       G_M000_IG97
       mov      rdx, bword ptr [rbp+0xB48]
       mov      bword ptr [rsp+0x20], rdx
       movzx    rdx, byte  ptr [rbp+0xBC8]
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x70]
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      r8, rax
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0x70]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG441:                ;; offset=0x398F
       mov      rdx, qword ptr [rbp-0x68]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG436
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG442
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG443
 
G_M000_IG442:                ;; offset=0x39D2
       mov      rcx, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A2A38
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG443:                ;; offset=0x39F8
       test     esi, esi
       jne      G_M000_IG436
       jmp      G_M000_IG330
 
G_M000_IG444:                ;; offset=0x3A05
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG99
 
G_M000_IG445:                ;; offset=0x3A16
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG99
 
G_M000_IG446:                ;; offset=0x3A27
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG99
 
G_M000_IG447:                ;; offset=0x3A38
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2965DB6AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG448:                ;; offset=0x3A66
       mov      rdx, rdi
       mov      rcx, 0x7FF9D7763360
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       jmp      G_M000_IG103
 
G_M000_IG449:                ;; offset=0x3A7D
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG450:                ;; offset=0x3A84
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2C8], ymm0
 
G_M000_IG451:                ;; offset=0x3A91
       lea      r8, [rbp-0x2C8]
       lea      rdx, [rbp-0x110]
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r10, bword ptr [rbp+0xBD0]
       mov      rdi, r10
       mov      rdx, gword ptr [rbp-0x110]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x108]
       mov      qword ptr [rdi+0x08], rdx
       mov      r10, bword ptr [rbp+0xBD0]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG436
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG452
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG453
 
G_M000_IG452:                ;; offset=0x3B0B
       mov      r10, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A2A40
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG453:                ;; offset=0x3B31
       test     esi, esi
       jne      G_M000_IG436
       jmp      G_M000_IG330
 
G_M000_IG454:                ;; offset=0x3B3E
       mov      rcx, bword ptr [rbp+0xB48]
       mov      rdx, 0x2965DB6D5C8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG455:                ;; offset=0x3B5E
       mov      rcx, rdx
       mov      edx, r11d
       mov      r11, 0x7FF9D70A29C8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rsi, rax
       mov      r9, gword ptr [rbp+0xBB8]
       jmp      G_M000_IG85
 
G_M000_IG456:                ;; offset=0x3B80
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rdi, rax
       mov      r9, gword ptr [rbp+0xBB8]
       jmp      G_M000_IG87
 
G_M000_IG457:                ;; offset=0x3B98
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rdi, rax
       mov      r9, gword ptr [rbp+0xBB8]
       jmp      G_M000_IG87
 
G_M000_IG458:                ;; offset=0x3BB0
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rdi, rax
       mov      r9, gword ptr [rbp+0xBB8]
       jmp      G_M000_IG87
 
G_M000_IG459:                ;; offset=0x3BC8
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2965DB6AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG460:                ;; offset=0x3BF6
       mov      rdx, gword ptr [rbp+0xAC8]
       mov      rcx, 0x7FF9D7500AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       test     r14, r14
       jne      G_M000_IG513
       mov      rdx, gword ptr [rbp+0xAC8]
       mov      rcx, 0x7FF9D76B6708
       call     CORINFO_HELP_CHKCASTCLASS
       xor      rcx, rcx
       mov      r8, bword ptr [rbp+0xBE0]
       mov      gword ptr [r8], rcx
       lea      rcx, bword ptr [r8+0x08]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r8, bword ptr [rbp+0xBE0]
       mov      word  ptr [r8+0x10], 0
       mov      byte  ptr [r8+0x12], 1
       jmp      G_M000_IG96
 
G_M000_IG461:                ;; offset=0x3C5E
       mov      gword ptr [rsp+0x20], rdi
       lea      rdx, [rbp+0xA50]
       mov      qword ptr [rsp+0x28], rdx
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r8, rsi
       mov      r9d, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG304
       cmp      gword ptr [rbp+0xA50], 0
       je       G_M000_IG02
       mov      rdx, gword ptr [rbp+0xA50]
       xor      rcx, rcx
       mov      r8, bword ptr [rbp+0xBE0]
       mov      gword ptr [r8], rcx
       lea      rcx, bword ptr [r8+0x08]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r8, bword ptr [rbp+0xBE0]
       mov      word  ptr [r8+0x10], 0
       mov      byte  ptr [r8+0x12], 1
       jmp      G_M000_IG96
 
G_M000_IG462:                ;; offset=0x3CD3
       mov      rdx, rbx
       mov      rcx, 0x7FF9D78959B0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG463
       mov      rcx, rax
       call     [System.Threading.Tasks.Task:get_IsCompletedSuccessfully():bool:this]
       jmp      SHORT G_M000_IG464
 
G_M000_IG463:                ;; offset=0x3CF5
       mov      r8, bword ptr [rbp+0xBE0]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A2A48
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetStatus(short):int:this
       cmp      eax, 1
       sete     al
       movzx    rax, al
 
G_M000_IG464:                ;; offset=0x3D1A
       test     eax, eax
       je       G_M000_IG96
       jmp      G_M000_IG94
 
G_M000_IG465:                ;; offset=0x3D27
       mov      rdx, rbx
       mov      rcx, 0x7FF9D78959B0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       je       SHORT G_M000_IG467
       mov      ecx, dword ptr [rdi+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG466
       mov      rcx, rdi
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG466:                ;; offset=0x3D5D
       mov      rdi, gword ptr [rdi+0x38]
       jmp      G_M000_IG95
 
G_M000_IG467:                ;; offset=0x3D66
       mov      r8, bword ptr [rbp+0xBE0]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A2A50
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetResult(short):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG95
 
G_M000_IG468:                ;; offset=0x3D8A
       xor      edx, edx
       mov      r8, bword ptr [rbp+0xBE0]
       mov      qword ptr [r8], rdx
       mov      qword ptr [r8+0x08], rdx
       mov      qword ptr [r8+0x10], rdx
       jmp      G_M000_IG80
 
G_M000_IG469:                ;; offset=0x3DA3
       mov      rdx, r14
       mov      rcx, 0x7FF9D74947C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG470
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG470:                ;; offset=0x3DDF
       mov      rcx, r14
       movsx    rdx, word  ptr [rbp+0xAA0]
       mov      r11, 0x7FF9D70A2A58
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG471:                ;; offset=0x3DFC
       mov      gword ptr [rsp+0x20], rdi
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0xF0]
       mov      rcx, gword ptr [rbp+0xBC0]
       mov      r8, rsi
       mov      r9d, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x100]
       lea      rdx, [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xBD0]
       mov      rdi, r10
       mov      rdx, gword ptr [rbp-0x100]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xF8]
       mov      qword ptr [rdi+0x08], rdx
       mov      r10, bword ptr [rbp+0xBD0]
       mov      rsi, gword ptr [r10]
       test     rsi, rsi
       je       G_M000_IG331
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG472
       test     dword ptr [rax+0x34], 0x1600000
       setne    bl
       movzx    rbx, bl
       jmp      SHORT G_M000_IG473
 
G_M000_IG472:                ;; offset=0x3E94
       mov      r10, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A2A60
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    bl
       movzx    rbx, bl
 
G_M000_IG473:                ;; offset=0x3EB8
       test     ebx, ebx
       jne      G_M000_IG331
       jmp      G_M000_IG330
 
G_M000_IG474:                ;; offset=0x3EC5
       xor      rdx, rdx
       xor      eax, eax
       jmp      G_M000_IG116
 
G_M000_IG475:                ;; offset=0x3ECE
       mov      r8, gword ptr [rdi+0x38]
       mov      rax, gword ptr [rdi+0x30]
       mov      r10d, edx
       sub      r10d, dword ptr [rax+0x08]
       cmp      r10d, dword ptr [r8+0x08]
       jae      G_M000_IG507
       mov      eax, r10d
       mov      rsi, gword ptr [r8+8*rax+0x10]
       mov      r8, gword ptr [rdi+0x30]
       sub      edx, dword ptr [r8+0x08]
       lea      r9, [rbp-0x288]
       mov      rcx, rdi
       mov      r8, gword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG476
       mov      rcx, rdi
       mov      edx, r14d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG476:                ;; offset=0x3F36
       mov      r14, gword ptr [rbp-0x288]
       jmp      G_M000_IG125
 
G_M000_IG477:                ;; offset=0x3F42
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG119
 
G_M000_IG478:                ;; offset=0x3F53
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG119
 
G_M000_IG479:                ;; offset=0x3F64
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG119
 
G_M000_IG480:                ;; offset=0x3F75
       mov      rcx, rdi
       mov      edx, r14d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, esi
       mov      rcx, rdi
       mov      r9, gword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
       jmp      G_M000_IG125
 
G_M000_IG481:                ;; offset=0x3FA1
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      rcx, rsi
       mov      rdx, 0x2965DB6AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG482:                ;; offset=0x3FCF
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG128
 
G_M000_IG483:                ;; offset=0x3FE1
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG484:                ;; offset=0x3FE8
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2C8], ymm0
 
G_M000_IG485:                ;; offset=0x3FF5
       lea      r8, [rbp-0x2C8]
       lea      rdx, [rbp-0x120]
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x130]
       lea      rdx, [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xBD0]
       mov      rdi, r10
       mov      rdx, gword ptr [rbp-0x130]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x128]
       mov      qword ptr [rdi+0x08], rdx
       mov      r10, bword ptr [rbp+0xBD0]
       mov      rsi, gword ptr [r10]
       test     rsi, rsi
       je       G_M000_IG331
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG486
       test     dword ptr [rax+0x34], 0x1600000
       setne    bl
       movzx    rbx, bl
       jmp      SHORT G_M000_IG487
 
G_M000_IG486:                ;; offset=0x4081
       mov      r10, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A2A68
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    bl
       movzx    rbx, bl
 
G_M000_IG487:                ;; offset=0x40A5
       test     ebx, ebx
       jne      G_M000_IG331
       jmp      G_M000_IG330
 
G_M000_IG488:                ;; offset=0x40B2
       mov      r9, gword ptr [rbp+0xBB8]
       cmp      gword ptr [rbp+0xBC0], 0
       je       G_M000_IG304
       cmp      byte  ptr [rbp+0xBC8], 0
       je       G_M000_IG132
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG489:                ;; offset=0x40DB
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2C8], ymm0
 
G_M000_IG490:                ;; offset=0x40E8
       lea      r8, [rbp-0x2C8]
       lea      rdx, [rbp-0xD0]
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0xE0]
       lea      rdx, [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xBD0]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0xE0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xD8]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xBD0]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG331
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG491
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG492
 
G_M000_IG491:                ;; offset=0x4176
       mov      r10, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A2A70
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG492:                ;; offset=0x419C
       test     esi, esi
       jne      G_M000_IG331
       jmp      G_M000_IG330
 
G_M000_IG493:                ;; offset=0x41A9
       mov      r9, gword ptr [rbp+0xBB8]
       cmp      gword ptr [rbp+0xBC0], 0
       jne      G_M000_IG132
       jmp      G_M000_IG304
 
G_M000_IG494:                ;; offset=0x41C3
       mov      r9, gword ptr [rbp+0xBB8]
       mov      rdx, bword ptr [rbp+0xB48]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      r8, r9
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      rbx, rax
       cmp      gword ptr [rbp+0xBC0], 0
       jne      SHORT G_M000_IG495
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG304
 
G_M000_IG495:                ;; offset=0x4205
       cmp      byte  ptr [rbp+0xBC8], 0
       je       SHORT G_M000_IG496
       mov      rdx, rbx
       mov      rcx, 0x7FF9D77F9A80
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG497
 
G_M000_IG496:                ;; offset=0x4225
       mov      rcx, bword ptr [rbp+0xBB0]
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r8, gword ptr [rbp+0xBC0]
       mov      r9, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp+0xB5C], eax
       jmp      G_M000_IG02
 
G_M000_IG497:                ;; offset=0x4252
       mov      r8, bword ptr [rbp+0xB48]
 
G_M000_IG498:                ;; offset=0x4259
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2C8], ymm0
 
G_M000_IG499:                ;; offset=0x4266
       lea      r8, [rbp-0x2C8]
       lea      rdx, [rbp-0xC0]
       mov      rcx, gword ptr [rbp+0xBC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0xBD0]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xB8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0xBD0]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG436
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG500
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG501
 
G_M000_IG500:                ;; offset=0x42E2
       mov      rax, bword ptr [rbp+0xBD0]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A2A78
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG501:                ;; offset=0x4308
       test     esi, esi
       jne      G_M000_IG436
       jmp      G_M000_IG330
 
G_M000_IG502:                ;; offset=0x4315
       cmp      esi, 49
       je       G_M000_IG82
       cmp      esi, 57
       je       G_M000_IG82
       cmp      esi, 58
       je       G_M000_IG82
       jmp      G_M000_IG304
 
G_M000_IG503:                ;; offset=0x4335
       movzx    rax, byte  ptr [rbp+0xBC8]
       test     al, al
       je       G_M000_IG136
       mov      rcx, bword ptr [rbp+0xBB0]
       cmp      gword ptr [rcx+0x40], 0
       je       G_M000_IG136
       xor      rdx, rdx
       mov      r10, bword ptr [rbp+0xBD0]
       mov      gword ptr [r10], rdx
       mov      word  ptr [r10+0x08], 0
       movzx    rdx, byte  ptr [rbp+0xB5C]
       mov      byte  ptr [r10+0x0A], dl
       mov      byte  ptr [r10+0x0B], 1
       mov      dword ptr [rbp+0xAB8], 5
       jmp      G_M000_IG508
 
G_M000_IG504:                ;; offset=0x4388
       mov      rdx, bword ptr [rbp+0xA38]
       mov      eax, ecx
       lea      rdx, bword ptr [rdx+2*rax]
       mov      eax, dword ptr [rbp+0xA40]
       sub      eax, ecx
       cmp      eax, 27
       jb       SHORT G_M000_IG505
       vmovups  ymm0, ymmword ptr [reloc @RWD292]
       vmovups  ymmword ptr [rdx], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD324]
       vmovups  xmmword ptr [rdx+0x20], xmm0
       mov      dword ptr [rdx+0x30], 0x3A0065
       mov      word  ptr [rdx+0x34], 32
       mov      ecx, dword ptr [rbp+0xA30]
       add      ecx, 27
       mov      dword ptr [rbp+0xA30], ecx
       jmp      SHORT G_M000_IG506
 
G_M000_IG505:                ;; offset=0x43D9
       lea      rcx, [rbp+0xA20]
       mov      rdx, 0x2965DB72A40
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
 
G_M000_IG506:                ;; offset=0x43F0
       mov      rdx, bword ptr [rbp+0xB48]
       mov      edx, dword ptr [rdx+0x1C]
       lea      rcx, [rbp+0xA20]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       lea      rcx, [rbp+0xA20]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG507:                ;; offset=0x443B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG508:                ;; offset=0x4441
       mov      eax, dword ptr [rbp+0xAB8]
 
G_M000_IG509:                ;; offset=0x4447
       vzeroupper 
       add      rsp, 0xE98
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG510:                ;; offset=0x445E
       cmp      dword ptr [r8+0x20], 0
       setne    r8b
       movzx    r8, r8b
       test     r8d, r8d
       je       G_M000_IG07
 
G_M000_IG511:                ;; offset=0x4474
       mov      rcx, rdx
       mov      rdx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG07
 
G_M000_IG512:                ;; offset=0x4485
       mov      rcx, bword ptr [rbp+0xBB0]
       cmp      gword ptr [rcx+0x40], 0
       je       G_M000_IG03
       jmp      SHORT G_M000_IG515
 
G_M000_IG513:                ;; offset=0x4499
       mov      r9, bword ptr [rbp+0xB48]
       mov      r9, gword ptr [r9]
       mov      rcx, r14
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r8, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG517
       mov      dword ptr [rbp+0xB5C], 1
       jmp      G_M000_IG02
 
G_M000_IG514:                ;; offset=0x44CD
       mov      rax, gword ptr [rbp+0xB60]
       mov      ebx, dword ptr [rax+0x08]
       mov      rcx, bword ptr [rbp+0xBB0]
       cmp      dword ptr [rcx+0x10], ebx
       jl       G_M000_IG06
       jmp      SHORT G_M000_IG518
 
G_M000_IG515:                ;; offset=0x44E9
       xor      rax, rax
       mov      rcx, bword ptr [rbp+0xBD0]
       mov      gword ptr [rcx], rax
       mov      word  ptr [rcx+0x08], 0
       movzx    rax, byte  ptr [rbp+0xB5C]
       mov      byte  ptr [rcx+0x0A], al
       mov      byte  ptr [rcx+0x0B], 1
       mov      eax, 5
 
G_M000_IG516:                ;; offset=0x450E
       vzeroupper 
       add      rsp, 0xE98
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG517:                ;; offset=0x4525
       mov      rcx, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG518:                ;; offset=0x452E
       mov      eax, 1
 
G_M000_IG519:                ;; offset=0x4533
       vzeroupper 
       add      rsp, 0xE98
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG520:                ;; offset=0x454A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG521:                ;; offset=0x4550
       sub      rsp, 72
 
G_M000_IG522:                ;; offset=0x4554
       mov      rbx, rcx
       cmp      gword ptr [rbp+0xBC0], 0
       jne      SHORT G_M000_IG524
 
G_M000_IG523:                ;; offset=0x4561
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG524:                ;; offset=0x4567
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp+0xBC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG527
 
G_M000_IG525:                ;; offset=0x458B
       mov      dword ptr [rbp+0xAB8], 1
       lea      rax, G_M000_IG508
 
G_M000_IG526:                ;; offset=0x459C
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG527:                ;; offset=0x45A4
       mov      dword ptr [rbp+0xB5C], 1
       lea      rax, G_M000_IG02
 
G_M000_IG528:                ;; offset=0x45B5
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG529:                ;; offset=0x45BD
       sub      rsp, 72
 
G_M000_IG530:                ;; offset=0x45C1
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp+0xB48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0xBB8]
       mov      r8, gword ptr [rbp+0xBC0]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG532
 
G_M000_IG531:                ;; offset=0x45EF
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG532:                ;; offset=0x45F5
       mov      dword ptr [rbp+0xB5C], 1
       lea      rax, G_M000_IG02
 
G_M000_IG533:                ;; offset=0x4606
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	00002E60h ; case G_M000_IG380
       	dd	0000063Ah ; case G_M000_IG68
       	dd	000000CEh ; case G_M000_IG09
       	dd	000020A0h ; case G_M000_IG302
       	dd	0000186Eh ; case G_M000_IG231
       	dd	000032FDh ; case G_M000_IG415
       	dd	000017F8h ; case G_M000_IG228
       	dd	0000177Fh ; case G_M000_IG223
       	dd	0000177Fh ; case G_M000_IG223
       	dd	0000171Eh ; case G_M000_IG222
       	dd	0000171Eh ; case G_M000_IG222
       	dd	0000177Fh ; case G_M000_IG223
       	dd	0000177Fh ; case G_M000_IG223
       	dd	0000177Fh ; case G_M000_IG223
       	dd	0000177Fh ; case G_M000_IG223
       	dd	0000177Fh ; case G_M000_IG223
       	dd	0000177Fh ; case G_M000_IG223
       	dd	0000177Fh ; case G_M000_IG223
       	dd	0000177Fh ; case G_M000_IG223
       	dd	0000177Fh ; case G_M000_IG223
       	dd	0000177Fh ; case G_M000_IG223
       	dd	0000177Fh ; case G_M000_IG223
       	dd	0000135Ah ; case G_M000_IG184
       	dd	0000135Ah ; case G_M000_IG184
       	dd	0000338Ah ; case G_M000_IG416
       	dd	0000102Bh ; case G_M000_IG153
       	dd	000023B8h ; case G_M000_IG322
       	dd	000033B4h ; case G_M000_IG417
       	dd	00000EF2h ; case G_M000_IG146
       	dd	00000E18h ; case G_M000_IG137
       	dd	000034E0h ; case G_M000_IG424
       	dd	00003523h ; case G_M000_IG425
       	dd	000035A0h ; case G_M000_IG426
       	dd	00000DFAh ; case G_M000_IG135
       	dd	00000DFAh ; case G_M000_IG135
       	dd	00000DFAh ; case G_M000_IG135
       	dd	00000DC0h ; case G_M000_IG133
       	dd	00000DC0h ; case G_M000_IG133
       	dd	00000DC0h ; case G_M000_IG133
       	dd	00000DFAh ; case G_M000_IG135
       	dd	00000C45h ; case G_M000_IG115
       	dd	00000A38h ; case G_M000_IG97
       	dd	0000082Fh ; case G_M000_IG84
       	dd	000037DAh ; case G_M000_IG438
       	dd	0000401Ch ; case G_M000_IG488
       	dd	00004113h ; case G_M000_IG493
       	dd	000007FDh ; case G_M000_IG83
       	dd	000007FDh ; case G_M000_IG83
       	dd	000007FDh ; case G_M000_IG83
       	dd	000007ADh ; case G_M000_IG81
       	dd	0000412Dh ; case G_M000_IG494
       	dd	00003783h ; case G_M000_IG437
       	dd	000007ADh ; case G_M000_IG81
       	dd	000007ADh ; case G_M000_IG81
       	dd	000007ADh ; case G_M000_IG81
       	dd	000007ADh ; case G_M000_IG81
       	dd	000007ADh ; case G_M000_IG81
       	dd	000007ADh ; case G_M000_IG81
       	dd	000007ADh ; case G_M000_IG81
       	dd	00000E09h ; case G_M000_IG136
       	dd	00002A0Eh ; case G_M000_IG360
       	dd	00002C25h ; case G_M000_IG369
       	dd	000007ADh ; case G_M000_IG81
       	dd	00002541h ; case G_M000_IG332
       	dd	00002541h ; case G_M000_IG332
       	dd	00002541h ; case G_M000_IG332
       	dd	00002541h ; case G_M000_IG332
       	dd	00002541h ; case G_M000_IG332
       	dd	00000771h ; case G_M000_IG79
       	dd	00003822h ; case G_M000_IG440
       	dd	0000271Dh ; case G_M000_IG342
       	dd	00002844h ; case G_M000_IG348
       	dd	00002024h ; case G_M000_IG301
RWD292 	dq	006E006B006E0055h, 0020006E0077006Fh, 0063006500780065h, 0062006100740075h
RWD324 	dq	006F00200065006Ch, 0064006F00630070h

; Total bytes of code 17934

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 229
; 91 inlinees with PGO data; 288 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 824
       lea      rbp, [rsp+0x370]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -720
 
G_M000_IG509:                ;; offset=0x0029
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG509
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
       mov      rax, bword ptr [rbp+0x30]
       mov      r10, bword ptr [rbp+0x38]
       mov      r8, bword ptr [rbp+0x40]
 
G_M000_IG02:                ;; offset=0x005D
       xor      r9d, r9d
       mov      qword ptr [rax], r9
       mov      qword ptr [rax+0x08], r9
 
G_M000_IG03:                ;; offset=0x0067
       mov      gword ptr [r10], r9
 
G_M000_IG04:                ;; offset=0x006A
       mov      qword ptr [r8], r9
       mov      qword ptr [r8+0x08], r9
       mov      qword ptr [r8+0x10], r9
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x98]
       mov      gword ptr [rbp-0x318], r9
       mov      ebx, dword ptr [r9+0x08]
       cmp      dword ptr [rcx+0x10], ebx
       jl       G_M000_IG12
 
G_M000_IG05:                ;; offset=0x0093
       mov      eax, 1
 
G_M000_IG06:                ;; offset=0x0098
       vzeroupper 
       add      rsp, 824
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x00AF
       mov      r9, bword ptr [rbp-0x320]
       mov      r9, gword ptr [r9]
       mov      rcx, r14
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       G_M000_IG494
       mov      dword ptr [rbp-0x3C], 1
 
G_M000_IG08:                ;; offset=0x00D9
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG487
 
G_M000_IG09:                ;; offset=0x00E3
       cmp      dword ptr [rbp-0x3C], 0
       jne      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00E9
       mov      r14, bword ptr [rbp+0x10]
       inc      dword ptr [r14+0x10]
 
G_M000_IG11:                ;; offset=0x00F1
       mov      r14, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [r14+0x10]
       mov      r9, gword ptr [rbp-0x318]
       mov      ebx, dword ptr [r9+0x08]
       cmp      ecx, ebx
       mov      rcx, r14
       mov      rdx, gword ptr [rbp+0x18]
       jge      SHORT G_M000_IG05
 
G_M000_IG12:                ;; offset=0x010F
       xor      r11d, r11d
       mov      dword ptr [rbp-0x3C], r11d
       mov      r11d, dword ptr [rcx+0x10]
       cmp      r11d, ebx
       jae      G_M000_IG495
       shl      r11, 5
       lea      r11, bword ptr [r9+r11+0x10]
       mov      bword ptr [rbp-0x320], r11
       mov      r11, gword ptr [rdx+0x98]
       mov      rsi, bword ptr [rbp-0x320]
       mov      rsi, gword ptr [rsi]
       mov      rdi, gword ptr [r11+0x88]
       cmp      gword ptr [rdi+0x20], 0
       jne      G_M000_IG493
       mov      rdi, gword ptr [r11+0x180]
       test     rdi, rdi
       jne      G_M000_IG492
 
G_M000_IG13:                ;; offset=0x0166
       mov      r11, bword ptr [rbp-0x320]
       mov      esi, dword ptr [r11+0x1C]
       cmp      esi, 72
       ja       G_M000_IG146
 
G_M000_IG14:                ;; offset=0x017A
       mov      r11d, esi
       lea      rdi, [reloc @RWD00]
       mov      edi, dword ptr [rdi+4*r11]
       lea      r14, G_M000_IG02
       add      rdi, r14
       jmp      rdi
 
G_M000_IG15:                ;; offset=0x0194
       mov      rcx, bword ptr [rbp+0x10]
       mov      rbx, gword ptr [rcx]
       mov      r11, gword ptr [rcx+0x08]
       cmp      esi, 2
       je       SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x01A4
       cmp      esi, 25
       jne      G_M000_IG282
 
G_M000_IG17:                ;; offset=0x01AD
       mov      rsi, bword ptr [rbp-0x320]
       mov      esi, dword ptr [rsi+0x08]
       mov      rdi, bword ptr [rbp-0x320]
       mov      rdi, gword ptr [rdi]
       cmp      esi, dword ptr [r11+0x08]
       jae      G_M000_IG485
       mov      r14d, esi
       shl      r14, 4
       lea      r11, bword ptr [r11+r14+0x10]
       mov      r14, gword ptr [r11]
       mov      r15, 0x27637001CE0
       cmp      r14, gword ptr [r15]
       je       G_M000_IG283
 
G_M000_IG18:                ;; offset=0x01ED
       mov      r15, 0x27637001CE8
       cmp      r14, gword ptr [r15]
       je       G_M000_IG284
       cmp      qword ptr [r11+0x08], 0
       jne      G_M000_IG285
 
G_M000_IG19:                ;; offset=0x020B
       test     r14, r14
       jne      G_M000_IG44
 
G_M000_IG20:                ;; offset=0x0214
       test     r14, r14
       je       G_M000_IG286
 
G_M000_IG21:                ;; offset=0x021D
       mov      rbx, r14
       mov      r11, bword ptr [rbp-0x320]
       cmp      dword ptr [r11+0x18], 0
       jl       G_M000_IG49
 
G_M000_IG22:                ;; offset=0x0232
       mov      rcx, bword ptr [rbp+0x10]
       lea      r14, bword ptr [rcx+0x20]
       mov      r11, bword ptr [rbp-0x320]
       mov      r11d, dword ptr [r11+0x1C]
       cmp      r11d, 51
       ja       SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x024B
       mov      rsi, 0x7FFFFFFFFF9FF
       bt       rsi, r11
       jae      G_M000_IG287
 
G_M000_IG24:                ;; offset=0x025F
       mov      r11, bword ptr [rbp-0x320]
       mov      esi, dword ptr [r11+0x14]
 
G_M000_IG25:                ;; offset=0x026A
       mov      r11, bword ptr [rbp-0x320]
       mov      edi, dword ptr [r11+0x18]
       test     edi, edi
       jl       G_M000_IG46
 
G_M000_IG26:                ;; offset=0x027D
       cmp      edi, dword ptr [r14+0x40]
       jge      G_M000_IG43
 
G_M000_IG27:                ;; offset=0x0287
       mov      r15d, dword ptr [r14+0x40]
       dec      r15d
       mov      r13d, dword ptr [r14+0x3C]
       cmp      r15d, r13d
       jle      G_M000_IG47
 
G_M000_IG28:                ;; offset=0x029B
       cmp      r13d, edi
       jl       G_M000_IG39
 
G_M000_IG29:                ;; offset=0x02A4
       cmp      byte  ptr [r14+0x44], 0
       jne      G_M000_IG288
 
G_M000_IG30:                ;; offset=0x02AF
       mov      r11, gword ptr [r14]
       cmp      r13d, dword ptr [r11+0x08]
       jae      G_M000_IG485
       mov      r15d, r13d
       shl      r15, 4
       lea      r15, bword ptr [r11+r15+0x10]
       mov      r11, gword ptr [r14+0x18]
       mov      r12, gword ptr [r11+0x88]
       mov      r11, gword ptr [r15]
       mov      r10, r11
       test     r10, r10
       je       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x02DE
       mov      r8, 0x7FF9D7848AB0
       cmp      qword ptr [r10], r8
       jne      G_M000_IG292
 
G_M000_IG32:                ;; offset=0x02F1
       test     r10, r10
       je       G_M000_IG48
 
G_M000_IG33:                ;; offset=0x02FA
       xor      r11d, r11d
       mov      qword ptr [r15], r11
       mov      qword ptr [r15+0x08], r11
       mov      r11, 0x7FF9D7848AB0
       cmp      qword ptr [r10], r11
       jne      G_M000_IG296
       mov      r11, gword ptr [r10+0x08]
       cmp      byte  ptr [r11], r11b
       cmp      byte  ptr [r10+0x38], 0
       je       SHORT G_M000_IG38
       mov      byte  ptr [r10+0x38], 0
       xor      r15, r15
       mov      gword ptr [r10+0x18], r15
 
G_M000_IG34:                ;; offset=0x0331
       mov      gword ptr [r10+0x20], r15
 
G_M000_IG35:                ;; offset=0x0335
       mov      qword ptr [r10+0x30], r15
       mov      r12, gword ptr [r11+0x18]
       cmp      byte  ptr [r11+0x48], 0
       jne      G_M000_IG295
 
G_M000_IG36:                ;; offset=0x0348
       test     r12, r12
       jne      G_M000_IG293
 
G_M000_IG37:                ;; offset=0x0351
       lea      rcx, bword ptr [r11+0x18]
       mov      rdx, r10
       call     CORINFO_HELP_ASSIGN_REF
       test     r12, r12
       jne      G_M000_IG294
 
G_M000_IG38:                ;; offset=0x0366
       dec      r13d
       cmp      r13d, edi
       jge      G_M000_IG29
 
G_M000_IG39:                ;; offset=0x0372
       mov      r11, gword ptr [r14]
       mov      r15d, dword ptr [r14+0x40]
       sub      r15d, edi
       test     r11, r11
       je       G_M000_IG300
       lea      r13, bword ptr [r11+0x10]
       xor      r12d, r12d
       mov      r10, qword ptr [r11]
       cmp      dword ptr [r10+0x04], 24
       jne      G_M000_IG301
 
G_M000_IG40:                ;; offset=0x039A
       mov      r8d, edi
       sub      r8d, r12d
       cmp      edi, r12d
       jl       G_M000_IG302
 
G_M000_IG41:                ;; offset=0x03A9
       mov      r12d, r8d
       or       r12d, r15d
       jl       G_M000_IG302
       lea      r12d, [r8+r15]
       cmp      r12d, dword ptr [r11+0x08]
       ja       G_M000_IG302
       movzx    r11, word  ptr [r10]
       mov      r8d, r8d
       imul     r8, r11
       add      r8, r13
       mov      r15d, r15d
       imul     r11, r15
       test     dword ptr [r10], 0x1000000
       je       G_M000_IG303
       mov      rdx, r11
       shr      rdx, 3
       mov      rcx, r8
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
 
G_M000_IG42:                ;; offset=0x03F5
       mov      dword ptr [r14+0x40], edi
 
G_M000_IG43:                ;; offset=0x03F9
       mov      r11, gword ptr [r14]
       cmp      esi, dword ptr [r11+0x08]
       jae      G_M000_IG485
       mov      esi, esi
       shl      rsi, 4
       lea      rsi, bword ptr [r11+rsi+0x10]
       mov      rcx, rsi
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      eax, eax
       mov      qword ptr [rsi+0x08], rax
       mov      dword ptr [r14+0x40], edi
       jmp      G_M000_IG08
 
G_M000_IG44:                ;; offset=0x042B
       mov      r11, 0x7FF9D77F4838
       cmp      qword ptr [r14], r11
       jne      G_M000_IG20
 
G_M000_IG45:                ;; offset=0x043E
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG20
 
G_M000_IG46:                ;; offset=0x044F
       not      edi
       jmp      G_M000_IG26
 
G_M000_IG47:                ;; offset=0x0456
       mov      r13d, r15d
       jmp      G_M000_IG28
 
G_M000_IG48:                ;; offset=0x045E
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_HasPrivateDefault():bool:this]
       test     eax, eax
       jne      G_M000_IG297
       cmp      qword ptr [r15+0x08], -2
       jne      G_M000_IG38
       jmp      G_M000_IG299
 
G_M000_IG49:                ;; offset=0x047F
       mov      gword ptr [rbp-0x248], r14
       xor      r11d, r11d
       mov      qword ptr [rbp-0x240], r11
       mov      r11, bword ptr [rbp-0x320]
       mov      r11d, dword ptr [r11+0x18]
       not      r11d
       mov      rcx, bword ptr [rbp+0x10]
       cmp      r11d, dword ptr [rcx+0x60]
       jl       G_M000_IG130
 
G_M000_IG50:                ;; offset=0x04AC
       cmp      gword ptr [rcx+0x40], 0
       jne      G_M000_IG305
       mov      r11, gword ptr [rcx+0x38]
       mov      rbx, gword ptr [r11+0x88]
       cmp      gword ptr [rbx+0x20], 0
       jne      G_M000_IG305
       mov      r11, gword ptr [r11+0x180]
       test     r11, r11
       jne      G_M000_IG304
 
G_M000_IG51:                ;; offset=0x04DD
       lea      rbx, bword ptr [rcx+0x20]
       mov      r11, bword ptr [rbp-0x320]
       mov      r11d, dword ptr [r11+0x1C]
       cmp      r11d, 51
       ja       SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x04F2
       mov      rsi, 0x7FFFFFFFFF9FF
       bt       rsi, r11
       jae      G_M000_IG308
 
G_M000_IG53:                ;; offset=0x0506
       mov      r11, bword ptr [rbp-0x320]
       mov      r11d, dword ptr [r11+0x14]
 
G_M000_IG54:                ;; offset=0x0511
       mov      rsi, gword ptr [rbx]
       cmp      r11d, dword ptr [rsi+0x08]
       jae      G_M000_IG485
       mov      edi, r11d
       shl      rdi, 4
       lea      rsi, bword ptr [rsi+rdi+0x10]
       xor      rdi, rdi
       mov      gword ptr [rsi], rdi
 
G_M000_IG55:                ;; offset=0x052F
       mov      qword ptr [rsi+0x08], rdi
       mov      dword ptr [rbx+0x40], r11d
       mov      rcx, bword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx]
       mov      r11, gword ptr [r11+0x98]
       mov      ebx, dword ptr [rcx+0x10]
       inc      ebx
       cmp      ebx, dword ptr [r11+0x08]
       jae      G_M000_IG485
       shl      rbx, 5
       lea      r11, bword ptr [r11+rbx+0x10]
       mov      ebx, dword ptr [r11+0x1C]
       cmp      ebx, 25
       jne      G_M000_IG134
 
G_M000_IG56:                ;; offset=0x056A
       mov      rbx, gword ptr [rcx]
       mov      rsi, gword ptr [rcx+0x08]
       mov      edi, dword ptr [r11+0x08]
 
G_M000_IG57:                ;; offset=0x0575
       vmovdqu  xmm0, xmmword ptr [rbp-0x248]
       vmovdqu  xmmword ptr [rbp-0x258], xmm0
 
G_M000_IG58:                ;; offset=0x0585
       mov      r11, gword ptr [rbx+0x68]
       mov      r14, 0x7FF9D723C7D0
       cmp      qword ptr [r11], r14
       jne      G_M000_IG310
       cmp      dword ptr [r11+0x08], edi
       jbe      G_M000_IG309
       mov      r14d, edi
       mov      r14, gword ptr [r11+8*r14+0x10]
 
G_M000_IG59:                ;; offset=0x05AE
       cmp      word  ptr [r14+0x0C], 60
       setne    r15b
       movzx    r15, r15b
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG131
 
G_M000_IG60:                ;; offset=0x05C7
       mov      r11, gword ptr [rbp+0x20]
       mov      r13, gword ptr [r11+0x88]
 
G_M000_IG61:                ;; offset=0x05D2
       test     r13, r13
       setne    r13b
       movzx    r13, r13b
       test     r13d, r15d
       jne      G_M000_IG311
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG485
       mov      r13d, edi
       shl      r13, 4
       mov      r13, gword ptr [rsi+r13+0x10]
       test     r13, r13
       jne      G_M000_IG132
 
G_M000_IG62:                ;; offset=0x0604
       mov      r13d, edi
       shl      r13, 4
       lea      r13, bword ptr [rsi+r13+0x10]
       mov      rdx, gword ptr [rbp-0x258]
       mov      rcx, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x250]
       mov      qword ptr [r13+0x08], rcx
       test     r15d, r15d
       je       SHORT G_M000_IG64
 
G_M000_IG63:                ;; offset=0x062F
       cmp      byte  ptr [rbx+0xF2], 0
       jne      G_M000_IG312
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG64
       mov      r11, gword ptr [rbp+0x20]
       cmp      byte  ptr [r11+0xFF], 0
       jne      G_M000_IG312
 
G_M000_IG64:                ;; offset=0x0655
       mov      r14, bword ptr [rbp+0x10]
       inc      dword ptr [r14+0x10]
       jmp      G_M000_IG08
 
G_M000_IG65:                ;; offset=0x0662
       cmp      r14d, dword ptr [rdi+0x08]
       jae      G_M000_IG485
       mov      edx, r14d
       shl      rdx, 4
       lea      r12, bword ptr [rdi+rdx+0x10]
       mov      rdx, gword ptr [rbp-0x2B8]
       mov      rcx, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x2B0]
       mov      qword ptr [r12+0x08], rcx
       test     r13d, r13d
       je       SHORT G_M000_IG64
 
G_M000_IG66:                ;; offset=0x0698
       cmp      byte  ptr [rsi+0xF2], 0
       jne      G_M000_IG420
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG64
       mov      rcx, gword ptr [rbp+0x20]
       cmp      byte  ptr [rcx+0xFF], 0
       je       SHORT G_M000_IG64
       jmp      G_M000_IG420
 
G_M000_IG67:                ;; offset=0x06BE
       mov      rdx, bword ptr [rbp-0x320]
       mov      edx, dword ptr [rdx+0x10]
       mov      rbx, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rbx+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [rbx+0x10], eax
       jmp      G_M000_IG215
 
G_M000_IG68:                ;; offset=0x06EB
       mov      rcx, bword ptr [rbp+0x10]
       lea      rbx, bword ptr [rcx+0x20]
       mov      r11, bword ptr [rbp-0x320]
       mov      esi, dword ptr [r11+0x10]
       mov      rdi, gword ptr [rcx]
       mov      r11, gword ptr [rcx+0x20]
       test     r11, r11
       je       G_M000_IG456
       lea      r14, bword ptr [r11+0x10]
       mov      r11d, dword ptr [r11+0x08]
 
G_M000_IG69:                ;; offset=0x0716
       mov      r15d, dword ptr [rcx+0x10]
       xor      r13, r13
       mov      gword ptr [rbp-0x2C0], r13
       test     esi, esi
       jl       G_M000_IG457
 
G_M000_IG70:                ;; offset=0x072C
       cmp      esi, r11d
       jae      G_M000_IG485
       mov      r11d, esi
       shl      r11, 4
       add      r11, r14
       mov      r14, gword ptr [r11]
       mov      r13, 0x27637001CE0
       cmp      r14, gword ptr [r13]
       je       G_M000_IG460
 
G_M000_IG71:                ;; offset=0x0756
       mov      r14, gword ptr [r11]
       mov      r13, 0x27637001CE8
       cmp      r14, gword ptr [r13]
       je       G_M000_IG461
       cmp      qword ptr [r11+0x08], 0
       jne      G_M000_IG462
       mov      r14, gword ptr [r11]
 
G_M000_IG72:                ;; offset=0x077B
       cmp      esi, dword ptr [rdi+0xD8]
       jge      SHORT G_M000_IG77
 
G_M000_IG73:                ;; offset=0x0783
       test     r14, r14
       je       SHORT G_M000_IG76
 
G_M000_IG74:                ;; offset=0x0788
       mov      r11, 0x7FF9D77F4838
       cmp      qword ptr [r14], r11
       jne      SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x0797
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      r14, rax
 
G_M000_IG76:                ;; offset=0x07A3
       test     r14, r14
       je       G_M000_IG463
 
G_M000_IG77:                ;; offset=0x07AC
       test     r14, r14
       je       G_M000_IG464
       mov      r15, r14
 
G_M000_IG78:                ;; offset=0x07B8
       xor      r11, r11
       mov      gword ptr [rbp-0x2C0], r11
       mov      r11, bword ptr [rbp-0x320]
       mov      r11d, dword ptr [r11+0x1C]
       cmp      r11d, 51
       ja       SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x07D3
       mov      rdi, 0x7FFFFFFFFF9FF
       bt       rdi, r11
       jae      G_M000_IG465
 
G_M000_IG80:                ;; offset=0x07E7
       mov      r11, bword ptr [rbp-0x320]
       mov      r11d, dword ptr [r11+0x14]
 
G_M000_IG81:                ;; offset=0x07F2
       mov      r14, bword ptr [rbp-0x320]
       cmp      dword ptr [r14+0x18], 0
       jl       G_M000_IG213
 
G_M000_IG82:                ;; offset=0x0804
       mov      rsi, bword ptr [rbp-0x320]
       mov      esi, dword ptr [rsi+0x18]
 
G_M000_IG83:                ;; offset=0x080E
       mov      rdi, bword ptr [rbp-0x320]
       mov      rdi, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], rdi
       mov      rcx, rbx
       mov      rdx, r15
       mov      r8d, r11d
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      G_M000_IG08
 
G_M000_IG84:                ;; offset=0x0837
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG212
 
G_M000_IG85:                ;; offset=0x0842
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG466
 
G_M000_IG86:                ;; offset=0x084C
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG08
 
G_M000_IG87:                ;; offset=0x0862
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG212
 
G_M000_IG88:                ;; offset=0x086D
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG391
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x0879
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG212
 
G_M000_IG90:                ;; offset=0x0884
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG08
 
G_M000_IG91:                ;; offset=0x089D
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG93
 
G_M000_IG92:                ;; offset=0x08A4
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG236
 
G_M000_IG93:                ;; offset=0x08BD
       mov      r11, bword ptr [rbp+0x48]
       cmp      dword ptr [r11+0x08], 0
       jne      G_M000_IG388
 
G_M000_IG94:                ;; offset=0x08CC
       mov      rcx, bword ptr [rbp+0x10]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rsi, bword ptr [rbp-0x320]
       mov      esi, dword ptr [rsi+0x10]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdx
       mov      edx, esi
       mov      rcx, rbx
       mov      r9, bword ptr [rbp-0x320]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0x2E0], rax
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2D8], r9
       lea      r9, [rbp-0x2E0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x320]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG08
 
G_M000_IG95:                ;; offset=0x093E
       not      r8d
       jmp      G_M000_IG244
 
G_M000_IG96:                ;; offset=0x0946
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG212
 
G_M000_IG97:                ;; offset=0x0951
       mov      rcx, bword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx]
       mov      rbx, gword ptr [r11+0x38]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG485
       mov      ecx, eax
       mov      rbx, gword ptr [rbx+8*rcx+0x10]
       mov      r14, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x320]
       mov      edi, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
       mov      edx, edi
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rdx, rax
       mov      rcx, rbx
       mov      r9, bword ptr [rbp-0x320]
       mov      r9, gword ptr [r9]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG08
 
G_M000_IG98:                ;; offset=0x09C5
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG08
       jmp      G_M000_IG212
 
G_M000_IG99:                ;; offset=0x09E7
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG08
 
G_M000_IG100:                ;; offset=0x0A05
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG212
 
G_M000_IG101:                ;; offset=0x0A10
       mov      r11, bword ptr [rbp-0x320]
       mov      rdx, gword ptr [r11]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG08
 
G_M000_IG102:                ;; offset=0x0A29
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG08
       jmp      G_M000_IG378
 
G_M000_IG103:                ;; offset=0x0A4F
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG212
 
G_M000_IG104:                ;; offset=0x0A5A
       cmp      byte  ptr [rbp+0x28], 0
       jne      SHORT G_M000_IG108
 
G_M000_IG105:                ;; offset=0x0A60
       mov      r11, bword ptr [rbp-0x320]
 
G_M000_IG106:                ;; offset=0x0A67
       vmovdqu  ymm0, ymmword ptr [r11]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG107:                ;; offset=0x0A74
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x88]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rbx, gword ptr [rbp-0x88]
       movsx    rsi, word  ptr [rbp-0x80]
       test     rbx, rbx
       je       G_M000_IG08
       jmp      G_M000_IG322
 
G_M000_IG108:                ;; offset=0x0AA9
       mov      r11, bword ptr [rbp-0x320]
 
G_M000_IG109:                ;; offset=0x0AB0
       vmovdqu  ymm0, ymmword ptr [r11]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG110:                ;; offset=0x0ABD
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x1F0]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x200]
       lea      rdx, [rbp-0x1F0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x200]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1F8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG227
       jmp      G_M000_IG324
 
G_M000_IG111:                ;; offset=0x0B25
       movzx    r11, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], r11d
       lea      r11, [rbp-0x68]
       mov      qword ptr [rsp+0x28], r11
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG212
 
G_M000_IG112:                ;; offset=0x0B59
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG340
 
G_M000_IG113:                ;; offset=0x0B63
       mov      rbx, gword ptr [rbp-0x68]
       movsx    rsi, word  ptr [rbp-0x60]
       test     rbx, rbx
       je       G_M000_IG08
       jmp      G_M000_IG338
 
G_M000_IG114:                ;; offset=0x0B7A
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG212
 
G_M000_IG115:                ;; offset=0x0B85
       mov      rcx, bword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx]
       mov      rbx, gword ptr [r11+0x38]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG485
       mov      ecx, eax
       mov      rcx, gword ptr [rbx+8*rcx+0x10]
       mov      rdx, bword ptr [rbp-0x320]
       mov      rdx, gword ptr [rdx]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      rdx, rax
       lea      rcx, [rbp-0x278]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x278]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG08
 
G_M000_IG116:                ;; offset=0x0BF8
       mov      rcx, bword ptr [rbp+0x10]
       mov      rbx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r8, bword ptr [rbp-0x320]
       mov      r8, gword ptr [r8]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbx, rax
       mov      rcx, bword ptr [rbp-0x320]
       cmp      dword ptr [rcx+0x18], 0
       jl       G_M000_IG125
 
G_M000_IG117:                ;; offset=0x0C39
       mov      r14, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x320]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x0C50
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jae      G_M000_IG387
 
G_M000_IG119:                ;; offset=0x0C64
       mov      rcx, bword ptr [rbp-0x320]
       mov      edi, dword ptr [rcx+0x14]
 
G_M000_IG120:                ;; offset=0x0C6E
       mov      rcx, bword ptr [rbp-0x320]
       mov      r15d, dword ptr [rcx+0x18]
       test     r15d, r15d
       jl       SHORT G_M000_IG124
 
G_M000_IG121:                ;; offset=0x0C7E
       cmp      r15d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG123
 
G_M000_IG122:                ;; offset=0x0C84
       mov      rcx, rsi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG123:                ;; offset=0x0C90
       mov      rcx, gword ptr [rsi]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG485
       mov      edx, edi
       shl      rdx, 4
       lea      rdi, bword ptr [rcx+rdx+0x10]
       mov      rcx, rdi
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      r9d, r9d
       mov      qword ptr [rdi+0x08], r9
       mov      dword ptr [rsi+0x40], r15d
       jmp      G_M000_IG08
 
G_M000_IG124:                ;; offset=0x0CC2
       not      r15d
       jmp      SHORT G_M000_IG121
 
G_M000_IG125:                ;; offset=0x0CC7
       mov      r14, bword ptr [rbp+0x10]
       mov      gword ptr [rbp-0x2E0], rbx
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2D8], r9
       lea      r9, [rbp-0x2E0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x320]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG08
 
G_M000_IG126:                ;; offset=0x0CFC
       mov      rcx, bword ptr [rbp+0x10]
       cmp      gword ptr [rcx+0x40], 0
       jne      SHORT G_M000_IG128
 
G_M000_IG127:                ;; offset=0x0D07
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdx
       mov      rcx, gword ptr [rcx]
       mov      r14, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r14+0x18]
       mov      r8d, dword ptr [r14+0x10]
       mov      r9d, dword ptr [r14+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG321
 
G_M000_IG128:                ;; offset=0x0D31
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      r8d, eax
       lea      r9, [rbp-0x48]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, bword ptr [rbp-0x320]
       mov      r9, gword ptr [r9]
       mov      rdx, gword ptr [rbp+0x20]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG212
 
G_M000_IG129:                ;; offset=0x0D6A
       mov      rdx, gword ptr [rbp-0x48]
       lea      rcx, [rbp-0x268]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x268]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG08
 
G_M000_IG130:                ;; offset=0x0D9C
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG50
 
G_M000_IG131:                ;; offset=0x0DC1
       xor      r13, r13
       jmp      G_M000_IG61
 
G_M000_IG132:                ;; offset=0x0DC9
       mov      r12, 0x7FF9D77F4838
       cmp      qword ptr [r13], r12
       jne      G_M000_IG62
 
G_M000_IG133:                ;; offset=0x0DDD
       lea      rcx, [rbp-0x258]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG64
 
G_M000_IG134:                ;; offset=0x0E0E
       cmp      ebx, 71
       je       G_M000_IG313
       cmp      ebx, 30
       jne      G_M000_IG318
       cmp      gword ptr [rbp-0x248], 0
       jne      G_M000_IG64
       jmp      G_M000_IG319
 
G_M000_IG135:                ;; offset=0x0E33
       mov      rcx, bword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx]
       mov      rbx, gword ptr [r11+0x30]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG485
       mov      ecx, eax
       mov      rcx, gword ptr [rbx+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rbx, rax
       mov      rcx, bword ptr [rbp-0x320]
       cmp      dword ptr [rcx+0x18], 0
       jl       SHORT G_M000_IG141
 
G_M000_IG136:                ;; offset=0x0E71
       mov      r14, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rcx, bword ptr [rbp-0x320]
       mov      r15d, dword ptr [rcx+0x18]
       test     r15d, r15d
       jl       SHORT G_M000_IG140
 
G_M000_IG137:                ;; offset=0x0E98
       cmp      r15d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG139
 
G_M000_IG138:                ;; offset=0x0E9E
       mov      rcx, rsi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG139:                ;; offset=0x0EAA
       mov      rcx, gword ptr [rsi]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG485
       mov      edx, edi
       shl      rdx, 4
       lea      rdi, bword ptr [rcx+rdx+0x10]
       mov      rcx, rdi
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      r9d, r9d
       mov      qword ptr [rdi+0x08], r9
       mov      dword ptr [rsi+0x40], r15d
       jmp      G_M000_IG08
 
G_M000_IG140:                ;; offset=0x0EDC
       not      r15d
       jmp      SHORT G_M000_IG137
 
G_M000_IG141:                ;; offset=0x0EE1
       mov      r14, bword ptr [rbp+0x10]
       mov      gword ptr [rbp-0x2E0], rbx
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2D8], r9
       lea      r9, [rbp-0x2E0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x320]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG08
 
G_M000_IG142:                ;; offset=0x0F16
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG212
 
G_M000_IG143:                ;; offset=0x0F21
       mov      rcx, bword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx]
       mov      rbx, gword ptr [r11+0xA8]
       mov      rcx, bword ptr [rbp-0x320]
       xor      edx, edx
       mov      r8, 0x2965DB746A8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:ReadPrimaryOperand(int,System.String):int:this]
       mov      rcx, 0x7FF9D76485A0
       cmp      qword ptr [rbx], rcx
       jne      G_M000_IG373
       mov      ecx, dword ptr [rbx+0x08]
       cmp      ecx, eax
       jbe      G_M000_IG309
       mov      eax, eax
       mov      rdx, gword ptr [rbx+8*rax+0x10]
 
G_M000_IG144:                ;; offset=0x0F6D
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG374
 
G_M000_IG145:                ;; offset=0x0F77
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r14]
       mov      r8, gword ptr [r14+0x08]
       mov      r9, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG08
 
G_M000_IG146:                ;; offset=0x0F91
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xF0], ymm0
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
       lea      rcx, [rbp-0xF0]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG147:                ;; offset=0x0FBD
       vmovdqu  ymm0, ymmword ptr [rbp-0xF0]
       vmovdqu  ymmword ptr [rbp-0xC8], ymm0
       mov      rcx, qword ptr [rbp-0xD0]
       mov      qword ptr [rbp-0xA8], rcx
 
G_M000_IG148:                ;; offset=0x0FDB
       mov      ecx, dword ptr [rbp-0xB8]
       cmp      ecx, dword ptr [rbp-0xA8]
       ja       G_M000_IG335
       mov      rdx, bword ptr [rbp-0xB0]
       mov      eax, ecx
       lea      rdx, bword ptr [rdx+2*rax]
       mov      eax, dword ptr [rbp-0xA8]
       sub      eax, ecx
       cmp      eax, 27
       jb       G_M000_IG486
 
G_M000_IG149:                ;; offset=0x100B
       vmovups  ymm0, ymmword ptr [reloc @RWD292]
       vmovups  ymmword ptr [rdx], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD324]
       vmovups  xmmword ptr [rdx+0x20], xmm0
       mov      dword ptr [rdx+0x30], 0x3A0065
       mov      word  ptr [rdx+0x34], 32
       mov      ecx, dword ptr [rbp-0xB8]
       add      ecx, 27
       mov      dword ptr [rbp-0xB8], ecx
 
G_M000_IG150:                ;; offset=0x1040
       mov      rdx, bword ptr [rbp-0x320]
       mov      edx, dword ptr [rdx+0x1C]
       lea      rcx, [rbp-0xC8]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       lea      rcx, [rbp-0xC8]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG151:                ;; offset=0x108B
       mov      rcx, bword ptr [rbp+0x10]
       mov      rbx, gword ptr [rcx+0x08]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG485
       mov      ecx, eax
       shl      rcx, 4
       cmp      gword ptr [rbx+rcx+0x10], 0
       jne      G_M000_IG08
       jmp      G_M000_IG320
 
G_M000_IG152:                ;; offset=0x10C0
       mov      rcx, bword ptr [rbp+0x10]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r9d, eax
       mov      r8d, esi
       mov      rcx, rbx
       lea      rdx, [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       G_M000_IG337
       lea      r9, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
 
G_M000_IG153:                ;; offset=0x1110
       mov      rax, gword ptr [rbp+0x20]
       mov      rdx, rax
       test     rdx, rdx
       jne      SHORT G_M000_IG155
 
G_M000_IG154:                ;; offset=0x111C
       mov      rdx, gword ptr [rbp+0x18]
       mov      r10, rdx
       mov      rdx, r10
 
G_M000_IG155:                ;; offset=0x1126
       mov      bword ptr [rbp-0x2D0], r9
       mov      dword ptr [rbp-0x2C8], r8d
 
G_M000_IG156:                ;; offset=0x1134
       vmovdqu  xmm0, xmmword ptr [rbp-0x58]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG157:                ;; offset=0x1141
       lea      rcx, [rbp-0x2D0]
       lea      r8, [rbp-0x2E0]
       mov      r9, gword ptr [rdx+0x98]
       mov      rdx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG08
 
G_M000_IG158:                ;; offset=0x1168
       mov      rcx, bword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx]
       mov      rbx, gword ptr [r11+0x30]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG485
       mov      ecx, eax
       mov      rdx, gword ptr [rbx+8*rcx+0x10]
       mov      rbx, rdx
       test     rbx, rbx
       je       SHORT G_M000_IG160
 
G_M000_IG159:                ;; offset=0x1198
       mov      rcx, 0x7FF9D759EAB0
       cmp      qword ptr [rbx], rcx
       jne      G_M000_IG333
 
G_M000_IG160:                ;; offset=0x11AB
       mov      rcx, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       sub      r14d, eax
       test     rsi, rsi
       je       G_M000_IG334
       mov      edx, edi
       mov      ecx, r14d
       add      rcx, rdx
       mov      r8d, dword ptr [rsi+0x08]
       cmp      rcx, r8
       ja       G_M000_IG335
       shl      rdx, 4
       lea      rdx, bword ptr [rsi+rdx+0x10]
 
G_M000_IG161:                ;; offset=0x1209
       mov      rcx, bword ptr [rbp-0x320]
       cmp      dword ptr [rcx+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      rax, gword ptr [rbp+0x20]
       mov      r9, rax
       test     r9, r9
       jne      SHORT G_M000_IG163
 
G_M000_IG162:                ;; offset=0x1228
       mov      r10, gword ptr [rbp+0x18]
       mov      r9, r10
 
G_M000_IG163:                ;; offset=0x122F
       mov      bword ptr [rbp-0x2D0], rdx
       mov      dword ptr [rbp-0x2C8], r14d
       mov      rdx, bword ptr [rbp-0x320]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x2D0]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x60], eax
       jmp      G_M000_IG08
 
G_M000_IG164:                ;; offset=0x1275
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG166
 
G_M000_IG165:                ;; offset=0x127C
       mov      rcx, bword ptr [rbp+0x10]
       mov      ebx, dword ptr [rcx+0x60]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      ebx, eax
       je       G_M000_IG397
 
G_M000_IG166:                ;; offset=0x1298
       mov      rcx, bword ptr [rbp+0x10]
       lea      rbx, bword ptr [rcx+0x20]
       mov      r11, bword ptr [rbp-0x320]
       mov      esi, dword ptr [r11+0x10]
       mov      r11, gword ptr [rbx]
       cmp      esi, dword ptr [r11+0x08]
       jae      G_M000_IG485
       mov      edi, esi
       shl      rdi, 4
       lea      r11, bword ptr [r11+rdi+0x10]
       mov      rdi, gword ptr [r11]
       mov      r14, 0x27637001CE0
       cmp      rdi, gword ptr [r14]
       je       G_M000_IG405
 
G_M000_IG167:                ;; offset=0x12D9
       mov      r14, 0x27637001CE8
       cmp      rdi, gword ptr [r14]
       je       G_M000_IG406
       cmp      qword ptr [r11+0x08], 0
       jne      G_M000_IG407
 
G_M000_IG168:                ;; offset=0x12F7
       test     rdi, rdi
       je       G_M000_IG408
       mov      r11, 0x7FF9D7848AB0
       cmp      qword ptr [rdi], r11
       je       G_M000_IG181
 
G_M000_IG169:                ;; offset=0x1313
       mov      r11, 0x7FF9D77FA4F0
       cmp      qword ptr [rdi], r11
       je       G_M000_IG180
 
G_M000_IG170:                ;; offset=0x1326
       mov      r11, rdi
       mov      r14, 0x7FF9D77F5D30
       cmp      qword ptr [r11], r14
       jne      G_M000_IG409
       xor      r11, r11
 
G_M000_IG171:                ;; offset=0x133F
       test     r11, r11
       jne      G_M000_IG180
       mov      r11, 0x7FF9D7848D18
       cmp      qword ptr [rdi], r11
       je       G_M000_IG179
 
G_M000_IG172:                ;; offset=0x135B
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG212
 
G_M000_IG173:                ;; offset=0x1366
       cmp      byte  ptr [rbp+0x28], 0
       jne      SHORT G_M000_IG175
 
G_M000_IG174:                ;; offset=0x136C
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG08
 
G_M000_IG175:                ;; offset=0x1385
       mov      r11, bword ptr [rbp-0x320]
 
G_M000_IG176:                ;; offset=0x138C
       vmovdqu  ymm0, ymmword ptr [r11]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG177:                ;; offset=0x1399
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x1A0]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      rdi, rax
       mov      rdx, gword ptr [rbp-0x1A0]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x198]
       mov      qword ptr [rdi+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       jne      G_M000_IG431
 
G_M000_IG178:                ;; offset=0x13E2
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG08
 
G_M000_IG179:                ;; offset=0x13F4
       lea      rdx, [rbp-0x298]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG182
 
G_M000_IG180:                ;; offset=0x1406
       mov      r11, gword ptr [rbx+0x08]
       sub      esi, dword ptr [rbx+0x38]
       cmp      esi, dword ptr [r11+0x08]
       jae      G_M000_IG485
       mov      ebx, esi
       lea      r11, bword ptr [r11+4*rbx+0x10]
       mov      r8, r11
       lea      rcx, [rbp-0x298]
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.PyIteration:AdvanceBuiltinSequence(System.Object,byref):Lokad.Lython.Runtime.PyIterationResult]
       jmp      SHORT G_M000_IG182
 
G_M000_IG181:                ;; offset=0x1433
       mov      r11, rdi
       lea      rdx, [rbp-0x298]
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
 
G_M000_IG182:                ;; offset=0x1446
       cmp      gword ptr [rbp-0x298], 0
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       jne      G_M000_IG193
 
G_M000_IG183:                ;; offset=0x145C
       xor      rbx, rbx
       xor      esi, esi
 
G_M000_IG184:                ;; offset=0x1460
       test     ecx, ecx
       je       G_M000_IG67
 
G_M000_IG185:                ;; offset=0x1468
       mov      rcx, bword ptr [rbp-0x320]
       cmp      dword ptr [rcx+0x18], 0
       jl       G_M000_IG195
 
G_M000_IG186:                ;; offset=0x1479
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp-0x320]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG188
 
G_M000_IG187:                ;; offset=0x1490
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG410
 
G_M000_IG188:                ;; offset=0x14A4
       mov      rdx, bword ptr [rbp-0x320]
       mov      r14d, dword ptr [rdx+0x14]
 
G_M000_IG189:                ;; offset=0x14AF
       mov      rdx, bword ptr [rbp-0x320]
       mov      r15d, dword ptr [rdx+0x18]
       test     r15d, r15d
       jl       SHORT G_M000_IG194
 
G_M000_IG190:                ;; offset=0x14BF
       cmp      r15d, dword ptr [rdi+0x40]
       jge      SHORT G_M000_IG192
 
G_M000_IG191:                ;; offset=0x14C5
       mov      rcx, rdi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG192:                ;; offset=0x14D1
       mov      rdx, gword ptr [rdi]
       cmp      r14d, dword ptr [rdx+0x08]
       jae      G_M000_IG485
       mov      eax, r14d
       shl      rax, 4
       lea      r14, bword ptr [rdx+rax+0x10]
       mov      rcx, r14
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r14+0x08], rsi
       mov      dword ptr [rdi+0x40], r15d
       jmp      G_M000_IG08
 
G_M000_IG193:                ;; offset=0x1502
       mov      rbx, gword ptr [rbp-0x298]
       mov      rsi, qword ptr [rbp-0x290]
       jmp      G_M000_IG184
 
G_M000_IG194:                ;; offset=0x1515
       not      r15d
       jmp      SHORT G_M000_IG190
 
G_M000_IG195:                ;; offset=0x151A
       mov      gword ptr [rbp-0x2A8], rbx
       mov      qword ptr [rbp-0x2A0], rsi
       mov      rcx, bword ptr [rbp-0x320]
       mov      ecx, dword ptr [rcx+0x18]
       not      ecx
       mov      rbx, bword ptr [rbp+0x10]
       cmp      ecx, dword ptr [rbx+0x60]
       jl       G_M000_IG411
 
G_M000_IG196:                ;; offset=0x1541
       cmp      gword ptr [rbx+0x40], 0
       jne      G_M000_IG413
       mov      rcx, gword ptr [rbx+0x38]
       mov      rax, gword ptr [rcx+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG413
       mov      rcx, gword ptr [rcx+0x180]
       test     rcx, rcx
       jne      G_M000_IG412
 
G_M000_IG197:                ;; offset=0x1572
       lea      rsi, bword ptr [rbx+0x20]
       mov      rcx, bword ptr [rbp-0x320]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG199
 
G_M000_IG198:                ;; offset=0x1585
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jae      G_M000_IG416
 
G_M000_IG199:                ;; offset=0x1599
       mov      rax, bword ptr [rbp-0x320]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG200:                ;; offset=0x15A3
       mov      rcx, gword ptr [rsi]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG485
       mov      edx, eax
       shl      rdx, 4
       lea      rcx, bword ptr [rcx+rdx+0x10]
       xor      rdx, rdx
       mov      gword ptr [rcx], rdx
 
G_M000_IG201:                ;; offset=0x15BF
       mov      qword ptr [rcx+0x08], rdx
       mov      dword ptr [rsi+0x40], eax
       mov      rcx, gword ptr [rbx]
       mov      rcx, gword ptr [rcx+0x98]
       mov      edx, dword ptr [rbx+0x10]
       inc      edx
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG485
       shl      rdx, 5
       lea      rdx, bword ptr [rcx+rdx+0x10]
       mov      esi, dword ptr [rdx+0x1C]
       cmp      esi, 25
       jne      G_M000_IG421
 
G_M000_IG202:                ;; offset=0x15F3
       mov      rsi, gword ptr [rbx]
       mov      rdi, gword ptr [rbx+0x08]
       mov      r14d, dword ptr [rdx+0x08]
 
G_M000_IG203:                ;; offset=0x15FE
       vmovdqu  xmm0, xmmword ptr [rbp-0x2A8]
       vmovdqu  xmmword ptr [rbp-0x2B8], xmm0
 
G_M000_IG204:                ;; offset=0x160E
       mov      rcx, gword ptr [rsi+0x68]
       mov      rdx, 0x7FF9D723C7D0
       cmp      qword ptr [rcx], rdx
       jne      G_M000_IG417
       cmp      dword ptr [rcx+0x08], r14d
       jbe      G_M000_IG309
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG485
       mov      edx, r14d
       mov      r15, gword ptr [rcx+8*rdx+0x10]
 
G_M000_IG205:                ;; offset=0x1641
       cmp      word  ptr [r15+0x0C], 60
       setne    r13b
       movzx    r13, r13b
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG418
 
G_M000_IG206:                ;; offset=0x165A
       mov      rcx, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rcx+0x88]
 
G_M000_IG207:                ;; offset=0x1665
       test     rax, rax
       setne    al
       movzx    rax, al
       test     eax, r13d
       jne      G_M000_IG419
       cmp      r14d, dword ptr [rdi+0x08]
       jae      G_M000_IG485
       mov      eax, r14d
       shl      rax, 4
       mov      r12, gword ptr [rdi+rax+0x10]
       test     r12, r12
       je       G_M000_IG65
 
G_M000_IG208:                ;; offset=0x1696
       mov      rax, 0x7FF9D77F4838
       cmp      qword ptr [r12], rax
       jne      G_M000_IG65
 
G_M000_IG209:                ;; offset=0x16AA
       lea      rcx, [rbp-0x2B8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG64
 
G_M000_IG210:                ;; offset=0x16DB
       cmp      esi, 58
       ja       SHORT G_M000_IG212
 
G_M000_IG211:                ;; offset=0x16E0
       mov      r11, 0x1FDFFFFFFFFFFFF
       bt       r11, rsi
       jae      G_M000_IG253
 
G_M000_IG212:                ;; offset=0x16F4
       mov      dword ptr [rbp-0x74], 6
       jmp      G_M000_IG490
 
G_M000_IG213:                ;; offset=0x1700
       mov      rsi, bword ptr [rbp-0x320]
       mov      esi, dword ptr [rsi+0x18]
       not      esi
       jmp      G_M000_IG83
 
G_M000_IG214:                ;; offset=0x1711
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG166
 
G_M000_IG215:                ;; offset=0x1732
       mov      dword ptr [rbp-0x3C], 1
       jmp      G_M000_IG08
 
G_M000_IG216:                ;; offset=0x173E
       mov      r11, gword ptr [rbp+0x20]
       mov      rbx, r11
       test     rbx, rbx
       jne      SHORT G_M000_IG218
 
G_M000_IG217:                ;; offset=0x174A
       mov      rdx, gword ptr [rbp+0x18]
       mov      rbx, rdx
 
G_M000_IG218:                ;; offset=0x1751
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, r11
       mov      r8, bword ptr [rbp-0x320]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG08
 
G_M000_IG219:                ;; offset=0x1770
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG212
 
G_M000_IG220:                ;; offset=0x177B
       cmp      byte  ptr [rbp+0x28], 0
       jne      SHORT G_M000_IG224
 
G_M000_IG221:                ;; offset=0x1781
       mov      r8, bword ptr [rbp-0x320]
 
G_M000_IG222:                ;; offset=0x1788
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG223:                ;; offset=0x1795
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x88]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rbx, gword ptr [rbp-0x88]
       movsx    rsi, word  ptr [rbp-0x80]
       test     rbx, rbx
       je       G_M000_IG08
       jmp      G_M000_IG328
 
G_M000_IG224:                ;; offset=0x17CA
       mov      r8, bword ptr [rbp-0x320]
 
G_M000_IG225:                ;; offset=0x17D1
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG226:                ;; offset=0x17DE
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x110]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x120]
       lea      rdx, [rbp-0x110]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x120]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x118]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       jne      G_M000_IG330
 
G_M000_IG227:                ;; offset=0x1841
       mov      rax, bword ptr [rbp+0x30]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG08
 
G_M000_IG228:                ;; offset=0x1853
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG212
 
G_M000_IG229:                ;; offset=0x185E
       cmp      byte  ptr [rbp+0x28], 0
       je       G_M000_IG366
       jmp      G_M000_IG359
 
G_M000_IG230:                ;; offset=0x186D
       mov      rcx, gword ptr [rbp+0x20]
       cmp      byte  ptr [rcx+0xF9], 0
       je       G_M000_IG08
       jmp      G_M000_IG371
 
G_M000_IG231:                ;; offset=0x1883
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG212
 
G_M000_IG232:                ;; offset=0x188E
       mov      rcx, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [rcx+0x20]
       mov      r11, bword ptr [rbp-0x320]
       mov      edi, dword ptr [r11+0x10]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r9d, eax
       mov      r8d, edi
       mov      rcx, rsi
       lea      rdx, [rbp-0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      esi, dword ptr [rcx+0x10]
       inc      esi
       mov      rax, gword ptr [rbp+0x20]
       mov      rdi, gword ptr [rax+0x70]
       cmp      byte  ptr [rax+0x101], 0
       je       G_M000_IG345
 
G_M000_IG233:                ;; offset=0x18E2
       xor      r15d, r15d
 
G_M000_IG234:                ;; offset=0x18E5
       test     r15d, r15d
       jne      G_M000_IG348
 
G_M000_IG235:                ;; offset=0x18EE
       mov      rax, gword ptr [rbp+0x20]
       lea      rbx, bword ptr [rax+0x190]
       mov      rdx, gword ptr [rbp-0x98]
       mov      rcx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x90]
       mov      qword ptr [rbx+0x08], rcx
       mov      rax, gword ptr [rbp+0x20]
       mov      word  ptr [rax+0xF8], 257
       mov      rcx, bword ptr [rbp+0x10]
       inc      dword ptr [rcx+0x10]
       test     r15d, r15d
       je       G_M000_IG357
 
G_M000_IG236:                ;; offset=0x1930
       mov      dword ptr [rbp-0x74], 1
       jmp      G_M000_IG490
 
G_M000_IG237:                ;; offset=0x193C
       mov      rcx, bword ptr [rbp+0x10]
       lea      rbx, bword ptr [rcx+0x20]
       mov      r11, bword ptr [rbp-0x320]
       mov      esi, dword ptr [r11+0x10]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdx
       mov      edx, esi
       mov      rcx, rbx
       mov      r9, bword ptr [rbp-0x320]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      rdx, rax
       lea      rcx, [rbp-0x288]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x288]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG08
 
G_M000_IG238:                ;; offset=0x19AE
       mov      r11, bword ptr [rbp-0x320]
       mov      edx, dword ptr [r11+0x10]
       mov      rcx, bword ptr [rbp+0x10]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rbx, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [rbx+0x20]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG08
 
G_M000_IG239:                ;; offset=0x19EC
       mov      rcx, bword ptr [rbp+0x10]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      esi, [rax+0x01]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       mov      rdx, bword ptr [rbp-0x320]
       mov      edx, dword ptr [rdx+0x10]
       mov      r14, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [r14+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      r15, rax
       cmp      edi, dword ptr [rbx+0x40]
       jge      SHORT G_M000_IG241
 
G_M000_IG240:                ;; offset=0x1A33
       mov      rcx, rbx
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG241:                ;; offset=0x1A3E
       mov      rcx, gword ptr [rbx]
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG485
       mov      edx, esi
       shl      rdx, 4
       lea      rsi, bword ptr [rcx+rdx+0x10]
       mov      rcx, rsi
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rsi+0x08], rcx
       mov      dword ptr [rbx+0x40], edi
       jmp      G_M000_IG08
 
G_M000_IG242:                ;; offset=0x1A6E
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG212
 
G_M000_IG243:                ;; offset=0x1A79
       mov      rcx, bword ptr [rbp+0x10]
       mov      rbx, gword ptr [rcx]
       mov      rsi, gword ptr [rcx+0x08]
       mov      r11, gword ptr [rcx]
       mov      rdi, gword ptr [r11+0x38]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG485
       mov      ecx, eax
       mov      rdi, gword ptr [rdi+8*rcx+0x10]
       mov      r14, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [r14+0x20]
       mov      rdx, bword ptr [rbp-0x320]
       mov      edx, dword ptr [rdx+0x10]
       mov      r8, bword ptr [rbp-0x320]
       mov      r8d, dword ptr [r8+0x18]
       test     r8d, r8d
       jl       G_M000_IG95
 
G_M000_IG244:                ;; offset=0x1ACE
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rdx
       mov      r8, bword ptr [rbp-0x320]
       mov      r8, gword ptr [r8]
       mov      gword ptr [rsp+0x28], r8
       mov      rdx, rsi
       mov      r8, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG08
 
G_M000_IG245:                ;; offset=0x1B03
       movzx    r11, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], r11d
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      r10, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], r10
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       test     eax, eax
       je       G_M000_IG178
 
G_M000_IG246:                ;; offset=0x1B40
       mov      dword ptr [rbp-0x74], eax
       jmp      G_M000_IG490
 
G_M000_IG247:                ;; offset=0x1B48
       mov      r11, bword ptr [rbp-0x320]
       mov      edx, dword ptr [r11+0x10]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      rbx, rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG249
 
G_M000_IG248:                ;; offset=0x1B6E
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG212
 
G_M000_IG249:                ;; offset=0x1B7F
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG251
 
G_M000_IG250:                ;; offset=0x1B85
       test     rbx, rbx
       jne      G_M000_IG478
 
G_M000_IG251:                ;; offset=0x1B8E
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG08
 
G_M000_IG252:                ;; offset=0x1BAF
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG210
 
G_M000_IG253:                ;; offset=0x1BBA
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       mov      rcx, bword ptr [rbp+0x10]
       cmp      gword ptr [rcx+0x68], 0
       je       G_M000_IG08
 
G_M000_IG254:                ;; offset=0x1BE5
       cmp      byte  ptr [rbp+0x28], 0
       je       G_M000_IG236
 
G_M000_IG255:                ;; offset=0x1BEF
       cmp      gword ptr [rcx+0x40], 0
       je       G_M000_IG236
 
G_M000_IG256:                ;; offset=0x1BFA
       xor      rdx, rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      gword ptr [rax], rdx
       mov      word  ptr [rax+0x08], 0
       movzx    rdx, byte  ptr [rbp-0x3C]
       mov      byte  ptr [rax+0x0A], dl
       mov      byte  ptr [rax+0x0B], 1
       mov      dword ptr [rbp-0x74], 5
       jmp      G_M000_IG490
 
G_M000_IG257:                ;; offset=0x1C20
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG08
 
G_M000_IG258:                ;; offset=0x1C41
       movzx    r11, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], r11d
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      r10, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], r10
       mov      r8, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x38], r8
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       test     eax, eax
       je       G_M000_IG08
 
G_M000_IG259:                ;; offset=0x1C87
       mov      dword ptr [rbp-0x74], eax
       jmp      G_M000_IG490
 
G_M000_IG260:                ;; offset=0x1C8F
       mov      rdx, gword ptr [rbp-0x70]
       mov      rax, rdx
       test     rax, rax
       je       SHORT G_M000_IG262
 
G_M000_IG261:                ;; offset=0x1C9B
       mov      rcx, 0x7FF9D76B6708
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG440
 
G_M000_IG262:                ;; offset=0x1CAE
       xor      rcx, rcx
       mov      r8, bword ptr [rbp+0x40]
       mov      gword ptr [r8], rcx
       lea      rcx, bword ptr [r8+0x08]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r8, bword ptr [rbp+0x40]
       mov      word  ptr [r8+0x10], 0
       mov      byte  ptr [r8+0x12], 1
 
G_M000_IG263:                ;; offset=0x1CD3
       mov      rdx, gword ptr [rbx+0x18]
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0x74], 3
       jmp      G_M000_IG490
 
G_M000_IG264:                ;; offset=0x1CEC
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG441
 
G_M000_IG265:                ;; offset=0x1CF7
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       mov      r8, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x28], r8
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, rbx
       mov      r8d, esi
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG268
 
G_M000_IG266:                ;; offset=0x1D1F
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG452
 
G_M000_IG267:                ;; offset=0x1D29
       mov      gword ptr [rsp+0x20], rdi
       xor      edx, edx
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x88]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       mov      rbx, gword ptr [rbp-0x88]
       movsx    rsi, word  ptr [rbp-0x80]
       test     rbx, rbx
       je       G_M000_IG08
       jmp      G_M000_IG450
 
G_M000_IG268:                ;; offset=0x1D65
       mov      r8, bword ptr [rbp+0x40]
       mov      r14, gword ptr [r8]
       test     r14, r14
       je       SHORT G_M000_IG270
 
G_M000_IG269:                ;; offset=0x1D71
       mov      rdx, r14
       mov      rcx, 0x7FF9D78959B0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       G_M000_IG445
       jmp      G_M000_IG444
 
G_M000_IG270:                ;; offset=0x1D91
       mov      r8, bword ptr [rbp+0x40]
       mov      rsi, gword ptr [r8]
       test     rsi, rsi
       jne      G_M000_IG446
       mov      rdi, gword ptr [r8+0x08]
 
G_M000_IG271:                ;; offset=0x1DA5
       mov      rcx, gword ptr [rbp+0x20]
       cmp      rdi, rcx
       je       G_M000_IG449
       jmp      G_M000_IG263
 
G_M000_IG272:                ;; offset=0x1DB7
       cmp      gword ptr [rbp+0x20], 0
       jne      G_M000_IG86
       jmp      G_M000_IG212
 
G_M000_IG273:                ;; offset=0x1DC7
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG212
 
G_M000_IG274:                ;; offset=0x1DD2
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG472
       jmp      G_M000_IG86
 
G_M000_IG275:                ;; offset=0x1DE1
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG08
       jmp      G_M000_IG258
 
G_M000_IG276:                ;; offset=0x1E07
       mov      rcx, bword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx]
       mov      r11, gword ptr [r11+0xB0]
       cmp      esi, 42
       jne      G_M000_IG434
       mov      rsi, bword ptr [rbp-0x320]
       mov      ebx, dword ptr [rsi+0x08]
       mov      rsi, 0x7FF9D7648660
       cmp      qword ptr [r11], rsi
       jne      G_M000_IG435
       cmp      dword ptr [r11+0x08], ebx
       jbe      G_M000_IG309
       cmp      ebx, dword ptr [r11+0x08]
       jae      G_M000_IG485
       mov      rbx, gword ptr [r11+8*rbx+0x10]
 
G_M000_IG277:                ;; offset=0x1E54
       mov      r11, bword ptr [rbp-0x320]
       mov      esi, dword ptr [r11+0x10]
       mov      rcx, bword ptr [rbp+0x10]
       lea      r11, bword ptr [rcx+0x20]
       cmp      byte  ptr [rbx], bl
       mov      r11, gword ptr [r11]
       cmp      byte  ptr [rbx+0x30], 0
       setne    dil
       movzx    rdi, dil
       add      edi, esi
       cmp      edi, dword ptr [r11+0x08]
       jae      G_M000_IG485
       shl      rdi, 4
       lea      r11, bword ptr [r11+rdi+0x10]
       mov      rdi, gword ptr [r11]
       mov      r14, 0x27637001CE0
       cmp      rdi, gword ptr [r14]
       je       G_M000_IG436
 
G_M000_IG278:                ;; offset=0x1EA3
       mov      rdi, gword ptr [r11]
       mov      r14, 0x27637001CE8
       cmp      rdi, gword ptr [r14]
       je       G_M000_IG437
       cmp      qword ptr [r11+0x08], 0
       jne      G_M000_IG438
       mov      rdi, gword ptr [r11]
 
G_M000_IG279:                ;; offset=0x1EC7
       test     rdi, rdi
       je       G_M000_IG439
       mov      dword ptr [rsp+0x20], esi
       mov      gword ptr [rsp+0x28], rdi
       lea      r11, [rbp-0x70]
       mov      qword ptr [rsp+0x30], r11
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG264
 
G_M000_IG280:                ;; offset=0x1EFF
       cmp      gword ptr [rbp-0x70], 0
       je       G_M000_IG08
 
G_M000_IG281:                ;; offset=0x1F0A
       mov      rdx, gword ptr [rbp-0x70]
       mov      rcx, 0x7FF9D7500AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       test     r14, r14
       jne      G_M000_IG07
       jmp      G_M000_IG260
 
G_M000_IG282:                ;; offset=0x1F2E
       cmp      esi, 72
       je       G_M000_IG17
       mov      rcx, bword ptr [rbp-0x320]
       mov      rdx, 0x2965DB6E048
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG283:                ;; offset=0x1F57
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG19
 
G_M000_IG284:                ;; offset=0x1F68
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG19
 
G_M000_IG285:                ;; offset=0x1F79
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG19
 
G_M000_IG286:                ;; offset=0x1F8A
       mov      rcx, rbx
       mov      edx, esi
       mov      r8, rdi
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
       jmp      G_M000_IG21
 
G_M000_IG287:                ;; offset=0x1FA4
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      esi, eax
       jmp      G_M000_IG25
 
G_M000_IG288:                ;; offset=0x1FB8
       mov      r11, gword ptr [r14]
       cmp      r13d, dword ptr [r11+0x08]
       jae      G_M000_IG485
       mov      r15d, r13d
       shl      r15, 4
       mov      r11, gword ptr [r11+r15+0x10]
       mov      rdx, r11
       mov      rcx, 0x7FF9D77F5D30
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       test     r15, r15
       je       G_M000_IG30
       cmp      gword ptr [r14+0x28], 0
       jne      SHORT G_M000_IG289
       lea      rcx, bword ptr [r14+0x20]
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG290
 
G_M000_IG289:                ;; offset=0x2004
       mov      rcx, gword ptr [r14+0x28]
       lea      rcx, bword ptr [rcx+0x48]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG290:                ;; offset=0x2014
       lea      rcx, bword ptr [r14+0x28]
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, gword ptr [r14]
       cmp      r13d, dword ptr [rdx+0x08]
       jae      G_M000_IG485
       mov      ecx, r13d
       shl      rcx, 4
       lea      rdx, bword ptr [rdx+rcx+0x10]
       xor      rcx, rcx
       mov      gword ptr [rdx], rcx
 
G_M000_IG291:                ;; offset=0x203E
       mov      qword ptr [rdx+0x08], rcx
       jmp      G_M000_IG38
 
G_M000_IG292:                ;; offset=0x2047
       mov      rdx, r11
       mov      rcx, 0x7FF9D77DE450
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rcx, rax
       mov      r10, rcx
       jmp      G_M000_IG32
 
G_M000_IG293:                ;; offset=0x2064
       mov      r15, gword ptr [r12+0x10]
       mov      r15d, dword ptr [r15+0x08]
       mov      dword ptr [rbp-0x32C], r15d
       mov      r15, gword ptr [r10+0x10]
       mov      r8d, dword ptr [rbp-0x32C]
       cmp      r8d, dword ptr [r15+0x08]
       jge      SHORT G_M000_IG295
       jmp      G_M000_IG37
 
G_M000_IG294:                ;; offset=0x208A
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:ReleaseStorage():this]
       jmp      G_M000_IG38
 
G_M000_IG295:                ;; offset=0x2098
       mov      rcx, r10
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:ReleaseStorage():this]
       jmp      G_M000_IG38
 
G_M000_IG296:                ;; offset=0x20A6
       mov      rcx, r10
       mov      r10, qword ptr [r10]
       mov      r10, qword ptr [r10+0x40]
       call     [r10+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
       jmp      G_M000_IG38
 
G_M000_IG297:                ;; offset=0x20B9
       mov      rax, gword ptr [r15]
       mov      gword ptr [rbp-0x328], rax
       xor      edx, edx
       mov      qword ptr [r15], rdx
       mov      qword ptr [r15+0x08], rdx
       mov      rdx, rax
       mov      rcx, 0x7FF9D71628A8
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       je       SHORT G_M000_IG298
       mov      ecx, dword ptr [rax+0x08]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:RecordBytes(int):long]
       mov      rdx, rax
       mov      rcx, r12
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Release(long):this]
       jmp      G_M000_IG38
 
G_M000_IG298:                ;; offset=0x20FF
       mov      rcx, r12
       mov      rdx, gword ptr [rbp-0x328]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:RefundUnpublishedValue(System.Object):this]
       jmp      G_M000_IG38
 
G_M000_IG299:                ;; offset=0x2116
       mov      rcx, gword ptr [r15]
       mov      rax, 0x27637001CE0
       cmp      rcx, gword ptr [rax]
       je       G_M000_IG38
       mov      rcx, gword ptr [r15]
       mov      rax, 0x27637001CE8
       cmp      rcx, gword ptr [rax]
       je       G_M000_IG38
       xor      ecx, ecx
       mov      qword ptr [r15], rcx
       mov      qword ptr [r15+0x08], rcx
       mov      rcx, 0x7FF9D764E798
       call     [CORINFO_HELP_GET_NONGCSTATIC_BASE]
       mov      rdx, qword ptr [(reloc 0x7ff9d709b100)]
       mov      rcx, r12
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Release(long):this]
       jmp      G_M000_IG38
 
G_M000_IG300:                ;; offset=0x2172
       mov      ecx, 2
       call     [System.ThrowHelper:ThrowArgumentNullException(int)]
       int3     
 
G_M000_IG301:                ;; offset=0x217E
       mov      r12d, dword ptr [r10+0x04]
       add      r12d, -24
       shr      r12d, 3
       mov      dword ptr [rbp-0x234], r12d
       movsxd   r12, r12d
       mov      r12d, dword ptr [r13+4*r12]
       mov      r8d, dword ptr [rbp-0x234]
       shl      r8d, 3
       movsxd   r8, r8d
       add      r13, r8
       jmp      G_M000_IG40
 
G_M000_IG302:                ;; offset=0x21AF
       call     [System.ThrowHelper:ThrowIndexOutOfRangeException()]
       int3     
 
G_M000_IG303:                ;; offset=0x21B6
       mov      rcx, r8
       mov      rdx, r11
       call     [System.SpanHelpers:ClearWithoutReferences(byref,nuint)]
       jmp      G_M000_IG42
 
G_M000_IG304:                ;; offset=0x21C7
       cmp      dword ptr [r11+0x20], 0
       setne    r11b
       movzx    r11, r11b
       test     r11d, r11d
       je       G_M000_IG51
 
G_M000_IG305:                ;; offset=0x21DD
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
 
G_M000_IG306:                ;; offset=0x2200
       vmovdqu  xmm0, xmmword ptr [rbp-0x248]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG307:                ;; offset=0x2210
       mov      edx, esi
       mov      rcx, rbx
       lea      r9, [rbp-0x2E0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG08
 
G_M000_IG308:                ;; offset=0x2227
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r11d, eax
       jmp      G_M000_IG54
 
G_M000_IG309:                ;; offset=0x223C
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG310:                ;; offset=0x2243
       mov      rcx, r11
       mov      edx, edi
       mov      r11, 0x7FF9D70A4060
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r14, rax
       jmp      G_M000_IG59
 
G_M000_IG311:                ;; offset=0x225D
       lea      rcx, [rbp-0x258]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       mov      rdx, r14
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreGlobalNamespaceName(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,System.Object)]
       jmp      G_M000_IG64
 
G_M000_IG312:                ;; offset=0x2292
       mov      r11, gword ptr [rbp+0x20]
       cmp      byte  ptr [r11], r11b
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.ExecutionFrame:get_Variables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rbx, rax
       mov      ecx, edi
       shl      rcx, 4
       lea      rcx, bword ptr [rsi+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       cmp      byte  ptr [rbx], bl
       mov      rcx, rbx
       mov      rdx, r14
       mov      r9d, 1
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryInsert(System.__Canon,System.__Canon,byte):bool:this]
       jmp      G_M000_IG64
 
G_M000_IG313:                ;; offset=0x22E5
       mov      rbx, gword ptr [rcx+0x20]
       test     rbx, rbx
       jne      SHORT G_M000_IG314
       xor      rsi, rsi
       xor      ebx, ebx
       jmp      SHORT G_M000_IG315
 
G_M000_IG314:                ;; offset=0x22F4
       lea      rsi, bword ptr [rbx+0x10]
       mov      ebx, dword ptr [rbx+0x08]
 
G_M000_IG315:                ;; offset=0x22FB
       mov      bword ptr [rbp-0x2D0], rsi
       mov      dword ptr [rbp-0x2C8], ebx
 
G_M000_IG316:                ;; offset=0x2308
       vmovdqu  xmm0, xmmword ptr [rbp-0x248]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG317:                ;; offset=0x2318
       lea      rcx, [rbp-0x2D0]
       lea      r8, [rbp-0x2E0]
       mov      r14, bword ptr [rbp+0x10]
       mov      r9, gword ptr [r14+0x38]
       mov      rdx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG64
 
G_M000_IG318:                ;; offset=0x233C
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2965DB72BE0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG319:                ;; offset=0x236A
       lea      rcx, [rbp-0x248]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       jmp      G_M000_IG64
 
G_M000_IG320:                ;; offset=0x238F
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      rsi, gword ptr [rax+0x68]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A4048
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, bword ptr [rbp-0x320]
       mov      rdx, gword ptr [rdx]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG321:                ;; offset=0x23D5
       add      dword ptr [r14+0x10], 2
       jmp      G_M000_IG08
 
G_M000_IG322:                ;; offset=0x23DF
       mov      rdx, rbx
       mov      rcx, 0x7FF9D74947C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG323
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG08
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG08
 
G_M000_IG323:                ;; offset=0x241B
       mov      rcx, rbx
       mov      edx, esi
       mov      r11, 0x7FF9D70A4068
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG08
 
G_M000_IG324:                ;; offset=0x2432
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG325
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG326
 
G_M000_IG325:                ;; offset=0x245A
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A4070
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG326:                ;; offset=0x247D
       test     esi, esi
       jne      G_M000_IG227
 
G_M000_IG327:                ;; offset=0x2485
       mov      rcx, bword ptr [rbp-0x320]
       mov      rdx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0x74], 4
       jmp      G_M000_IG490
 
G_M000_IG328:                ;; offset=0x24A4
       mov      rdx, rbx
       mov      rcx, 0x7FF9D74947C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG329
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG08
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG08
 
G_M000_IG329:                ;; offset=0x24E0
       mov      rcx, rbx
       mov      edx, esi
       mov      r11, 0x7FF9D70A4078
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG08
 
G_M000_IG330:                ;; offset=0x24F7
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG331
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG332
 
G_M000_IG331:                ;; offset=0x251F
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A4080
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG332:                ;; offset=0x2542
       test     esi, esi
       jne      G_M000_IG227
       jmp      G_M000_IG327
 
G_M000_IG333:                ;; offset=0x254F
       mov      rax, rcx
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG334:                ;; offset=0x2558
       or       edi, r14d
       je       SHORT G_M000_IG336
 
G_M000_IG335:                ;; offset=0x255D
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG336:                ;; offset=0x2564
       xor      rdx, rdx
       xor      r14d, r14d
       jmp      G_M000_IG161
 
G_M000_IG337:                ;; offset=0x256E
       xor      r9, r9
       xor      r8d, r8d
       jmp      G_M000_IG153
 
G_M000_IG338:                ;; offset=0x2579
       mov      rdx, rbx
       mov      rcx, 0x7FF9D74947C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG339
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG08
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG08
 
G_M000_IG339:                ;; offset=0x25B5
       mov      rcx, rbx
       mov      edx, esi
       mov      r11, 0x7FF9D70A4088
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG08
 
G_M000_IG340:                ;; offset=0x25CC
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0x310], xmm0
 
G_M000_IG341:                ;; offset=0x25D9
       lea      rdx, [rbp-0x310]
       lea      rcx, [rbp-0x210]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x210]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x208]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG227
 
G_M000_IG342:                ;; offset=0x261E
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG343
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG344
 
G_M000_IG343:                ;; offset=0x2646
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A4090
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG344:                ;; offset=0x2669
       test     esi, esi
       jne      G_M000_IG227
       jmp      G_M000_IG327
 
G_M000_IG345:                ;; offset=0x2676
       cmp      byte  ptr [rax+0xFF], 0
       jne      G_M000_IG233
 
G_M000_IG346:                ;; offset=0x2683
       cmp      ebx, esi
       jle      G_M000_IG233
 
G_M000_IG347:                ;; offset=0x268B
       cmp      esi, ebx
       jae      G_M000_IG485
       mov      r14d, esi
       shl      r14, 5
       mov      r9, gword ptr [rbp-0x318]
       cmp      dword ptr [r9+r14+0x2C], 30
       sete     r15b
       movzx    r15, r15b
       jmp      G_M000_IG234
 
G_M000_IG348:                ;; offset=0x26B4
       test     rdi, rdi
       je       G_M000_IG235
 
G_M000_IG349:                ;; offset=0x26BD
       vmovdqu  xmm0, xmmword ptr [rbp-0x98]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG350:                ;; offset=0x26CD
       lea      r8, [rbp-0x2E0]
       mov      rdx, rdi
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       je       G_M000_IG235
 
G_M000_IG351:                ;; offset=0x26E8
       cmp      esi, ebx
       jae      G_M000_IG485
       mov      r14d, esi
       shl      r14, 5
       mov      r9, gword ptr [rbp-0x318]
       mov      r15, gword ptr [r9+r14+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rdi, gword ptr [rdx+0x98]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG353
 
G_M000_IG352:                ;; offset=0x271E
       mov      rcx, rdi
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG353:                ;; offset=0x272A
       mov      rdx, gword ptr [rbp+0x18]
       mov      rbx, gword ptr [rdx+0x98]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasActiveHandler():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG355
 
G_M000_IG354:                ;; offset=0x2743
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rcx+0x80]
       jmp      SHORT G_M000_IG356
 
G_M000_IG355:                ;; offset=0x2750
       mov      rdx, gword ptr [rbp+0x18]
       mov      rax, gword ptr [rdx+0x98]
       mov      rax, gword ptr [rax+0x148]
       mov      rdx, rax
 
G_M000_IG356:                ;; offset=0x2765
       lea      rcx, bword ptr [rbx+0x148]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x10]
       lea      rbx, bword ptr [rcx+0x20]
       mov      r9, gword ptr [rbp-0x318]
       lea      rcx, bword ptr [r9+r14+0x10]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0x10]
       add      dword ptr [rcx+0x10], 2
       jmp      G_M000_IG11
 
G_M000_IG357:                ;; offset=0x27A3
       test     rdi, rdi
       je       G_M000_IG236
 
G_M000_IG358:                ;; offset=0x27AC
       mov      rcx, rax
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG236
       jmp      G_M000_IG11
 
G_M000_IG359:                ;; offset=0x27C5
       mov      r11, bword ptr [rbp-0x320]
 
G_M000_IG360:                ;; offset=0x27CC
       vmovdqu  ymm0, ymmword ptr [r11]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG361:                ;; offset=0x27D9
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x140]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x140]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x138]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       SHORT G_M000_IG365
 
G_M000_IG362:                ;; offset=0x281E
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG363
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG364
 
G_M000_IG363:                ;; offset=0x2846
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A4098
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG364:                ;; offset=0x2869
       test     esi, esi
       je       G_M000_IG327
 
G_M000_IG365:                ;; offset=0x2871
       mov      rax, bword ptr [rbp+0x30]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG230
 
G_M000_IG366:                ;; offset=0x2883
       mov      r11, gword ptr [rbp+0x20]
       cmp      gword ptr [r11+0x68], 0
       jne      G_M000_IG368
 
G_M000_IG367:                ;; offset=0x2892
       mov      rcx, bword ptr [rbp+0x10]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rsi, bword ptr [rbp-0x320]
       mov      esi, dword ptr [rsi+0x10]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r8d, eax
       mov      edx, esi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rbx, rax
       mov      rcx, 0x7FF9D71628A8
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      rsi, rax
       lea      rcx, bword ptr [rsi+0x10]
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, bword ptr [rbp-0x320]
       mov      rdx, gword ptr [rdx]
       mov      rcx, rsi
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbx, rax
       mov      rcx, 0x7FF9D77F7DB8
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      r9, bword ptr [rbp-0x320]
       mov      r9, gword ptr [r9]
       mov      rcx, rsi
       mov      rdx, rbx
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:.ctor(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      r11, gword ptr [rbp+0x20]
       lea      rcx, bword ptr [r11+0x68]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG368:                ;; offset=0x293B
       mov      r11, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [r11+0x68]
       mov      r8, gword ptr [r11+0x58]
       mov      r9, gword ptr [r11+0x60]
       lea      rdx, [rbp-0x130]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:Advance(System.Object,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.PyIterationResult:this]
       mov      r8, bword ptr [rbp-0x320]
 
G_M000_IG369:                ;; offset=0x2961
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG370:                ;; offset=0x296E
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x130]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
       jmp      G_M000_IG230
 
G_M000_IG371:                ;; offset=0x298B
       mov      rdx, gword ptr [rcx+0x70]
       test     rdx, rdx
       je       G_M000_IG236
 
G_M000_IG372:                ;; offset=0x2998
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG236
       jmp      G_M000_IG11
 
G_M000_IG373:                ;; offset=0x29AB
       mov      rcx, rbx
       mov      edx, eax
       mov      r11, 0x7FF9D70A4058
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdx, rax
       jmp      G_M000_IG144
 
G_M000_IG374:                ;; offset=0x29C5
       lea      rcx, [rbp-0x220]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
       lea      rcx, [rbp-0x230]
       lea      rdx, [rbp-0x220]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x230]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x228]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG227
 
G_M000_IG375:                ;; offset=0x2A1B
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG376
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG377
 
G_M000_IG376:                ;; offset=0x2A43
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A40A0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG377:                ;; offset=0x2A66
       test     esi, esi
       jne      G_M000_IG227
       jmp      G_M000_IG327
 
G_M000_IG378:                ;; offset=0x2A73
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG212
 
G_M000_IG379:                ;; offset=0x2A7E
       cmp      byte  ptr [rbp+0x28], 0
       jne      SHORT G_M000_IG381
 
G_M000_IG380:                ;; offset=0x2A84
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG08
 
G_M000_IG381:                ;; offset=0x2AA2
       mov      r8, bword ptr [rbp-0x320]
 
G_M000_IG382:                ;; offset=0x2AA9
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG383:                ;; offset=0x2AB6
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x1E0]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1D8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG227
 
G_M000_IG384:                ;; offset=0x2AFF
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG385
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG386
 
G_M000_IG385:                ;; offset=0x2B27
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A40A8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG386:                ;; offset=0x2B4A
       test     esi, esi
       jne      G_M000_IG227
       jmp      G_M000_IG327
 
G_M000_IG387:                ;; offset=0x2B57
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       jmp      G_M000_IG120
 
G_M000_IG388:                ;; offset=0x2B6B
       mov      r8d, dword ptr [r11+0x08]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       je       G_M000_IG94
 
G_M000_IG389:                ;; offset=0x2B88
       mov      r11, bword ptr [rbp+0x48]
       vmovdqu  xmm0, xmmword ptr [r11]
       vmovdqu  xmmword ptr [rbp-0x2D0], xmm0
 
G_M000_IG390:                ;; offset=0x2B99
       lea      r9, [rbp-0x2D0]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, bword ptr [rbp-0x320]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp-0x74], 2
       jmp      G_M000_IG490
 
G_M000_IG391:                ;; offset=0x2BC1
       mov      r11, bword ptr [rbp-0x320]
 
G_M000_IG392:                ;; offset=0x2BC8
       vmovdqu  ymm0, ymmword ptr [r11]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG393:                ;; offset=0x2BD5
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x1D0]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x1D0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1C8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG178
 
G_M000_IG394:                ;; offset=0x2C1E
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG395
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG396
 
G_M000_IG395:                ;; offset=0x2C46
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A40B0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG396:                ;; offset=0x2C69
       test     esi, esi
       jne      G_M000_IG178
       jmp      G_M000_IG327
 
G_M000_IG397:                ;; offset=0x2C76
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp-0x320]
       mov      edx, dword ptr [rdx+0x10]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG485
       shl      rdx, 4
       mov      rbx, gword ptr [rax+rdx+0x10]
       test     rbx, rbx
       je       G_M000_IG166
 
G_M000_IG398:                ;; offset=0x2CA3
       mov      rax, 0x7FF9D77F5D30
       cmp      qword ptr [rbx], rax
       jne      G_M000_IG166
 
G_M000_IG399:                ;; offset=0x2CB6
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       test     rax, rax
       je       G_M000_IG166
 
G_M000_IG400:                ;; offset=0x2CC8
       cmp      gword ptr [rax+0x20], 0
       je       G_M000_IG166
 
G_M000_IG401:                ;; offset=0x2CD3
       mov      rdx, bword ptr [rbp-0x320]
       mov      bword ptr [rsp+0x20], rdx
       movzx    rdx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x100]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, rax
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x100]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xF8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG178
 
G_M000_IG402:                ;; offset=0x2D2F
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG403
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG404
 
G_M000_IG403:                ;; offset=0x2D57
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A40B8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG404:                ;; offset=0x2D7A
       test     esi, esi
       jne      G_M000_IG178
       jmp      G_M000_IG327
 
G_M000_IG405:                ;; offset=0x2D87
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG168
 
G_M000_IG406:                ;; offset=0x2D98
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG168
 
G_M000_IG407:                ;; offset=0x2DA9
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG168
 
G_M000_IG408:                ;; offset=0x2DBA
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2965DB6AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG409:                ;; offset=0x2DE8
       mov      rdx, rdi
       mov      rcx, 0x7FF9D7763360
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r11, rax
       jmp      G_M000_IG171
 
G_M000_IG410:                ;; offset=0x2E02
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       jmp      G_M000_IG189
 
G_M000_IG411:                ;; offset=0x2E17
       lea      rsi, bword ptr [rbx+0x20]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG196
 
G_M000_IG412:                ;; offset=0x2E38
       cmp      dword ptr [rcx+0x20], 0
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       je       G_M000_IG197
 
G_M000_IG413:                ;; offset=0x2E4A
       lea      rsi, bword ptr [rbx+0x20]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
 
G_M000_IG414:                ;; offset=0x2E6D
       vmovdqu  xmm0, xmmword ptr [rbp-0x2A8]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG415:                ;; offset=0x2E7D
       mov      edx, edi
       mov      rcx, rsi
       lea      r9, [rbp-0x2E0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG08
 
G_M000_IG416:                ;; offset=0x2E94
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG200
 
G_M000_IG417:                ;; offset=0x2EA6
       mov      edx, r14d
       mov      r11, 0x7FF9D70A40C0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r15, rax
       jmp      G_M000_IG205
 
G_M000_IG418:                ;; offset=0x2EBE
       xor      rax, rax
       jmp      G_M000_IG207
 
G_M000_IG419:                ;; offset=0x2EC5
       lea      rcx, [rbp-0x2B8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       mov      rdx, r15
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreGlobalNamespaceName(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,System.Object)]
       jmp      G_M000_IG64
 
G_M000_IG420:                ;; offset=0x2EFA
       mov      rcx, gword ptr [rbp+0x20]
       cmp      byte  ptr [rcx], cl
       call     [Lokad.Lython.Runtime.ExecutionFrame:get_Variables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rsi, rax
       cmp      r14d, dword ptr [rdi+0x08]
       jae      G_M000_IG485
       mov      ecx, r14d
       shl      rcx, 4
       lea      rcx, bword ptr [rdi+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       cmp      byte  ptr [rsi], sil
       mov      rcx, rsi
       mov      rdx, r15
       mov      r9d, 1
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryInsert(System.__Canon,System.__Canon,byte):bool:this]
       jmp      G_M000_IG64
 
G_M000_IG421:                ;; offset=0x2F55
       cmp      esi, 71
       jne      SHORT G_M000_IG427
 
G_M000_IG422:                ;; offset=0x2F5A
       mov      rcx, gword ptr [rbx+0x20]
       test     rcx, rcx
       jne      SHORT G_M000_IG423
       xor      r8, r8
       xor      ecx, ecx
       jmp      SHORT G_M000_IG424
 
G_M000_IG423:                ;; offset=0x2F6A
       lea      r8, bword ptr [rcx+0x10]
       mov      ecx, dword ptr [rcx+0x08]
 
G_M000_IG424:                ;; offset=0x2F71
       mov      bword ptr [rbp-0x2D0], r8
       mov      dword ptr [rbp-0x2C8], ecx
 
G_M000_IG425:                ;; offset=0x2F7E
       vmovdqu  xmm0, xmmword ptr [rbp-0x2A8]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG426:                ;; offset=0x2F8E
       lea      rcx, [rbp-0x2D0]
       lea      r8, [rbp-0x2E0]
       mov      r9, gword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG64
 
G_M000_IG427:                ;; offset=0x2FAB
       cmp      esi, 30
       je       SHORT G_M000_IG429
 
G_M000_IG428:                ;; offset=0x2FB0
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      rcx, rsi
       mov      rdx, 0x2965DB72BE0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG429:                ;; offset=0x2FDE
       cmp      gword ptr [rbp-0x2A8], 0
       jne      G_M000_IG64
 
G_M000_IG430:                ;; offset=0x2FEC
       lea      rcx, [rbp-0x2A8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D78023D8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       jmp      G_M000_IG64
 
G_M000_IG431:                ;; offset=0x3011
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG432
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG433
 
G_M000_IG432:                ;; offset=0x3039
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A40C8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG433:                ;; offset=0x305C
       test     esi, esi
       jne      G_M000_IG178
       jmp      G_M000_IG327
 
G_M000_IG434:                ;; offset=0x3069
       mov      rcx, bword ptr [rbp-0x320]
       mov      rdx, 0x2965DB6D5C8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG435:                ;; offset=0x3089
       mov      rcx, r11
       mov      edx, ebx
       mov      r11, 0x7FF9D70A4050
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rbx, rax
       jmp      G_M000_IG277
 
G_M000_IG436:                ;; offset=0x30A3
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG279
 
G_M000_IG437:                ;; offset=0x30B4
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG279
 
G_M000_IG438:                ;; offset=0x30C5
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG279
 
G_M000_IG439:                ;; offset=0x30D6
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2965DB6AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG440:                ;; offset=0x3104
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG441:                ;; offset=0x310A
       mov      gword ptr [rsp+0x20], rdi
       lea      rdx, [rbp-0xA0]
       mov      qword ptr [rsp+0x28], rdx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG212
 
G_M000_IG442:                ;; offset=0x3137
       cmp      gword ptr [rbp-0xA0], 0
       je       G_M000_IG08
 
G_M000_IG443:                ;; offset=0x3145
       mov      rdx, gword ptr [rbp-0xA0]
       xor      rcx, rcx
       mov      r8, bword ptr [rbp+0x40]
       mov      gword ptr [r8], rcx
       lea      rcx, bword ptr [r8+0x08]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r8, bword ptr [rbp+0x40]
       mov      word  ptr [r8+0x10], 0
       mov      byte  ptr [r8+0x12], 1
       jmp      G_M000_IG263
 
G_M000_IG444:                ;; offset=0x3173
       mov      rcx, rax
       call     [System.Threading.Tasks.Task:get_IsCompletedSuccessfully():bool:this]
       test     eax, eax
       je       G_M000_IG263
       jmp      G_M000_IG270
 
G_M000_IG445:                ;; offset=0x3189
       mov      r8, bword ptr [rbp+0x40]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, r14
       mov      r11, 0x7FF9D70A40D0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetStatus(short):int:this
       cmp      eax, 1
       jne      G_M000_IG263
       jmp      G_M000_IG270
 
G_M000_IG446:                ;; offset=0x31B0
       mov      rdx, rsi
       mov      rcx, 0x7FF9D78959B0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       je       SHORT G_M000_IG448
       mov      ecx, dword ptr [rdi+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG447
       mov      rcx, rdi
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG447:                ;; offset=0x31E6
       mov      rdi, gword ptr [rdi+0x38]
       jmp      G_M000_IG271
 
G_M000_IG448:                ;; offset=0x31EF
       mov      r8, bword ptr [rbp+0x40]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A40D8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetResult(short):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG271
 
G_M000_IG449:                ;; offset=0x3210
       xor      edx, edx
       mov      r8, bword ptr [rbp+0x40]
       mov      qword ptr [r8], rdx
       mov      qword ptr [r8+0x08], rdx
       mov      qword ptr [r8+0x10], rdx
       jmp      G_M000_IG215
 
G_M000_IG450:                ;; offset=0x3226
       mov      rdx, rbx
       mov      rcx, 0x7FF9D74947C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG451
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG08
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG08
 
G_M000_IG451:                ;; offset=0x3262
       mov      rcx, rbx
       mov      edx, esi
       mov      r11, 0x7FF9D70A40E0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG08
 
G_M000_IG452:                ;; offset=0x3279
       mov      gword ptr [rsp+0x20], rdi
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0x180]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x190]
       lea      rdx, [rbp-0x180]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      rdi, rax
       mov      rdx, gword ptr [rbp-0x190]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x188]
       mov      qword ptr [rdi+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG227
 
G_M000_IG453:                ;; offset=0x32E2
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG454
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG455
 
G_M000_IG454:                ;; offset=0x330A
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A40E8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG455:                ;; offset=0x332D
       test     esi, esi
       jne      G_M000_IG227
       jmp      G_M000_IG327
 
G_M000_IG456:                ;; offset=0x333A
       xor      r14, r14
       xor      r11d, r11d
       jmp      G_M000_IG69
 
G_M000_IG457:                ;; offset=0x3345
       not      esi
       mov      r11, gword ptr [rdi+0x30]
       cmp      dword ptr [r11+0x08], esi
       jle      SHORT G_M000_IG458
       mov      r11, gword ptr [rdi+0x30]
       cmp      esi, dword ptr [r11+0x08]
       jae      G_M000_IG485
       mov      edi, esi
       mov      rcx, gword ptr [r11+8*rdi+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r15, rax
       jmp      G_M000_IG78
 
G_M000_IG458:                ;; offset=0x3374
       mov      r11, gword ptr [rdi+0x38]
       mov      r14, gword ptr [rdi+0x30]
       mov      r13d, esi
       sub      r13d, dword ptr [r14+0x08]
       cmp      r13d, dword ptr [r11+0x08]
       jae      G_M000_IG485
       mov      r14d, r13d
       mov      r14, gword ptr [r11+8*r14+0x10]
       mov      r11, gword ptr [rdi+0x30]
       sub      esi, dword ptr [r11+0x08]
       mov      edx, esi
       lea      r9, [rbp-0x2C0]
       mov      rcx, rdi
       mov      r8, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG459
       mov      rcx, rdi
       mov      edx, r15d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG459:                ;; offset=0x33DB
       mov      r15, gword ptr [rbp-0x2C0]
       jmp      G_M000_IG78
 
G_M000_IG460:                ;; offset=0x33E7
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG72
 
G_M000_IG461:                ;; offset=0x33F8
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG72
 
G_M000_IG462:                ;; offset=0x3409
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG72
 
G_M000_IG463:                ;; offset=0x341A
       mov      rcx, rdi
       mov      edx, r15d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, esi
       mov      rcx, rdi
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r15, rax
       jmp      G_M000_IG78
 
G_M000_IG464:                ;; offset=0x3443
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      rcx, rsi
       mov      rdx, 0x2965DB6AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG465:                ;; offset=0x3471
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r11d, eax
       jmp      G_M000_IG81
 
G_M000_IG466:                ;; offset=0x3486
       mov      r8, bword ptr [rbp-0x320]
 
G_M000_IG467:                ;; offset=0x348D
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG468:                ;; offset=0x349A
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x1B0]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x1C0]
       lea      rdx, [rbp-0x1B0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x1C0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1B8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG227
 
G_M000_IG469:                ;; offset=0x34F7
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG470
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG471
 
G_M000_IG470:                ;; offset=0x351F
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A40F0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG471:                ;; offset=0x3542
       test     esi, esi
       jne      G_M000_IG227
       jmp      G_M000_IG327
 
G_M000_IG472:                ;; offset=0x354F
       mov      r11, bword ptr [rbp-0x320]
 
G_M000_IG473:                ;; offset=0x3556
       vmovdqu  ymm0, ymmword ptr [r11]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG474:                ;; offset=0x3563
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x160]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x170]
       lea      rdx, [rbp-0x160]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x170]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x168]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG227
 
G_M000_IG475:                ;; offset=0x35C0
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG476
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG477
 
G_M000_IG476:                ;; offset=0x35E8
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A40F8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG477:                ;; offset=0x360B
       test     esi, esi
       jne      G_M000_IG227
       jmp      G_M000_IG327
 
G_M000_IG478:                ;; offset=0x3618
       mov      r8, 0x7FF9D77F9A80
       cmp      qword ptr [rbx], r8
       jne      G_M000_IG251
 
G_M000_IG479:                ;; offset=0x362B
       mov      r8, bword ptr [rbp-0x320]
 
G_M000_IG480:                ;; offset=0x3632
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG481:                ;; offset=0x363F
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x150]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x150]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x148]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG178
 
G_M000_IG482:                ;; offset=0x368A
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG483
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG484
 
G_M000_IG483:                ;; offset=0x36B2
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A4100
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG484:                ;; offset=0x36D5
       test     esi, esi
       jne      G_M000_IG178
       jmp      G_M000_IG327
 
G_M000_IG485:                ;; offset=0x36E2
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG486:                ;; offset=0x36E8
       lea      rcx, [rbp-0xC8]
       mov      rdx, 0x2965DB72A40
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
       jmp      G_M000_IG150
 
G_M000_IG487:                ;; offset=0x3704
       mov      r14, bword ptr [rbp+0x10]
       cmp      gword ptr [r14+0x40], 0
       je       G_M000_IG09
 
G_M000_IG488:                ;; offset=0x3713
       xor      rax, rax
       mov      rcx, bword ptr [rbp+0x30]
       mov      gword ptr [rcx], rax
       mov      word  ptr [rcx+0x08], 0
       movzx    rax, byte  ptr [rbp-0x3C]
       mov      byte  ptr [rcx+0x0A], al
       mov      byte  ptr [rcx+0x0B], 1
       mov      eax, 5
 
G_M000_IG489:                ;; offset=0x3732
       vzeroupper 
       add      rsp, 824
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG490:                ;; offset=0x3749
       mov      eax, dword ptr [rbp-0x74]
 
G_M000_IG491:                ;; offset=0x374C
       vzeroupper 
       add      rsp, 824
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG492:                ;; offset=0x3763
       cmp      dword ptr [rdi+0x20], 0
       setne    dil
       movzx    rdi, dil
       test     edi, edi
       je       G_M000_IG13
 
G_M000_IG493:                ;; offset=0x3777
       mov      rcx, r11
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG13
 
G_M000_IG494:                ;; offset=0x3788
       mov      rcx, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG495:                ;; offset=0x3791
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG496:                ;; offset=0x3797
       sub      rsp, 72
 
G_M000_IG497:                ;; offset=0x379B
       mov      rbx, rcx
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG499
 
G_M000_IG498:                ;; offset=0x37A5
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG499:                ;; offset=0x37AB
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG502
 
G_M000_IG500:                ;; offset=0x37CC
       mov      dword ptr [rbp-0x74], 1
       lea      rax, G_M000_IG490
 
G_M000_IG501:                ;; offset=0x37DA
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG502:                ;; offset=0x37E2
       mov      dword ptr [rbp-0x3C], 1
       lea      rax, G_M000_IG08
 
G_M000_IG503:                ;; offset=0x37F0
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG504:                ;; offset=0x37F8
       sub      rsp, 72
 
G_M000_IG505:                ;; offset=0x37FC
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG507
 
G_M000_IG506:                ;; offset=0x3824
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG507:                ;; offset=0x382A
       mov      dword ptr [rbp-0x3C], 1
       lea      rax, G_M000_IG08
 
G_M000_IG508:                ;; offset=0x3838
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	00000EB9h ; case G_M000_IG142
       	dd	00000DD6h ; case G_M000_IG135
       	dd	00000137h ; case G_M000_IG15
       	dd	00000C9Fh ; case G_M000_IG126
       	dd	00000B9Bh ; case G_M000_IG116
       	dd	00000B1Dh ; case G_M000_IG114
       	dd	00000AC8h ; case G_M000_IG111
       	dd	000009F2h ; case G_M000_IG103
       	dd	000009F2h ; case G_M000_IG103
       	dd	00001BE4h ; case G_M000_IG258
       	dd	00001BE4h ; case G_M000_IG258
       	dd	000009F2h ; case G_M000_IG103
       	dd	000009F2h ; case G_M000_IG103
       	dd	000009F2h ; case G_M000_IG103
       	dd	000009F2h ; case G_M000_IG103
       	dd	000009F2h ; case G_M000_IG103
       	dd	000009F2h ; case G_M000_IG103
       	dd	000009F2h ; case G_M000_IG103
       	dd	000009F2h ; case G_M000_IG103
       	dd	000009F2h ; case G_M000_IG103
       	dd	000009F2h ; case G_M000_IG103
       	dd	000009F2h ; case G_M000_IG103
       	dd	000009CCh ; case G_M000_IG102
       	dd	000009CCh ; case G_M000_IG102
       	dd	000009A8h ; case G_M000_IG100
       	dd	0000098Ah ; case G_M000_IG99
       	dd	00000968h ; case G_M000_IG98
       	dd	000008E9h ; case G_M000_IG96
       	dd	00001A11h ; case G_M000_IG242
       	dd	0000198Fh ; case G_M000_IG239
       	dd	00001951h ; case G_M000_IG238
       	dd	000018DFh ; case G_M000_IG237
       	dd	00000840h ; case G_M000_IG91
       	dd	0000081Ch ; case G_M000_IG89
       	dd	0000081Ch ; case G_M000_IG89
       	dd	0000081Ch ; case G_M000_IG89
       	dd	00000805h ; case G_M000_IG87
       	dd	00000805h ; case G_M000_IG87
       	dd	00000805h ; case G_M000_IG87
       	dd	0000081Ch ; case G_M000_IG89
       	dd	0000068Eh ; case G_M000_IG68
       	dd	0000123Bh ; case G_M000_IG166
       	dd	00001DAAh ; case G_M000_IG276
       	dd	00001D84h ; case G_M000_IG275
       	dd	00001D6Ah ; case G_M000_IG273
       	dd	00001D5Ah ; case G_M000_IG272
       	dd	00001BC3h ; case G_M000_IG257
       	dd	00001BC3h ; case G_M000_IG257
       	dd	00001BC3h ; case G_M000_IG257
       	dd	00001B52h ; case G_M000_IG252
       	dd	00001AEBh ; case G_M000_IG247
       	dd	00001AA6h ; case G_M000_IG245
       	dd	00001B52h ; case G_M000_IG252
       	dd	00001B52h ; case G_M000_IG252
       	dd	00001B52h ; case G_M000_IG252
       	dd	00001B52h ; case G_M000_IG252
       	dd	00001B52h ; case G_M000_IG252
       	dd	00001B52h ; case G_M000_IG252
       	dd	00001B52h ; case G_M000_IG252
       	dd	000018D3h ; case G_M000_IG236
       	dd	00001826h ; case G_M000_IG231
       	dd	000017F6h ; case G_M000_IG228
       	dd	00001B52h ; case G_M000_IG252
       	dd	000016E1h ; case G_M000_IG216
       	dd	000016E1h ; case G_M000_IG216
       	dd	000016E1h ; case G_M000_IG216
       	dd	000016E1h ; case G_M000_IG216
       	dd	000016E1h ; case G_M000_IG216
       	dd	000016B4h ; case G_M000_IG214
       	dd	00001218h ; case G_M000_IG164
       	dd	0000110Bh ; case G_M000_IG158
       	dd	00001063h ; case G_M000_IG152
       	dd	0000102Eh ; case G_M000_IG151
RWD292 	dq	006E006B006E0055h, 0020006E0077006Fh, 0063006500780065h, 0062006100740075h
RWD324 	dq	006F00200065006Ch, 0064006F00630070h

; Total bytes of code 14400

