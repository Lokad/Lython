set -eu
root=/home/lokad/lython-bench-checks/string-format-b93-20261102
dotnet=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet
python=/home/lokad/lython-bench-toolchains/cpython/3.13.16/bin/python3.13
export DOTNET_ROOT=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148
case "$1" in
 report) caseid=scripts.report-render.large ;;
 control) caseid=scripts.json-summary-helpers.large ;;
 *) exit 2 ;;
esac
exec 9>/home/lokad/lython-bench-checks/comparison-vm.lock
flock -n 9
notes="$root/$1"
mkdir "$notes"
date -u +%FT%TZ > "$notes/started.utc"
trap 'result=$?; printf "%s\n" "$result" > "$notes/exit-code.txt"; date -u +%FT%TZ > "$notes/stopped.utc"' EXIT
env DOTNET_TieredCompilation=0 "$dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare check-machine --out "$notes/machine-before.json" > "$notes/machine-before.log" 2>&1
python3 -c 'import json,sys;assert json.load(open(sys.argv[1]))["gate"]["quiet"]' "$notes/machine-before.json"
if [ "$1" = report ]; then python3 "$root/reference-check.py" "$root" "$python"; fi
env DOTNET_TieredCompilation=0 "$dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare micro --catalog "$root/catalog.json" --dotnet "$dotnet" --baseline-worker "$root/baseline/Lokad.Lython.Benchmarks.dll" --python "$python" --python-worker "$root/cpython-worker.py" --out "$notes/micro.json" --case "$caseid" --lane warm > "$notes/micro.log" 2>&1
cat "$notes/micro.log"
env DOTNET_TieredCompilation=0 "$dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare check-machine --out "$notes/machine-after.json" > "$notes/machine-after.log" 2>&1
python3 -c 'import json,sys;assert json.load(open(sys.argv[1]))["gate"]["quiet"]' "$notes/machine-after.json"
