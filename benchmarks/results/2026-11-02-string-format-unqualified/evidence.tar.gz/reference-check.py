import json,pathlib,subprocess,sys
root=pathlib.Path(sys.argv[1]);python=sys.argv[2]
goldens=json.loads((root/'semantic-goldens.json').read_text(encoding='utf-8'));records=[]
for value,spec,expected in goldens['cases']:
 source='value='+repr(value)+'\nspec='+repr(spec)+'\n'+goldens['source']
 run=subprocess.run([python,'-I','-S','-X','utf8','-c',source],capture_output=True,timeout=5)
 assert run.returncode==0 and not run.stderr,(value,spec,run.stderr)
 assert run.stdout==expected.encode('utf-8'),(value,spec,run.stdout,expected)
 records.append({'value':value,'spec':spec,'fullGoldenPassed':True})
(root/'semantic-reference-validation.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
