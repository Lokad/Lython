from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess


lab = Path(__file__).resolve().parent
donor = lab.parent / 'adjacent-integer-results-20261123/reference'
catalog = lab / 'comparison/representative.json'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
identity = read(lab / 'comparison/identity.json')
dotnet = Path.home() / '.dotnet11/dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
data = {}
jit = {}
for role, files in identity['imageFiles'].items():
    image = lab / role
    assert len(files) == 32 and all(digest(image / name) == expected for name, expected in files.items())
    for name in ('Inspect.dll', 'Inspect.deps.json', 'Inspect.runtimeconfig.json'):
        shutil.copyfile(donor / name, image / name)
    output = lab / (role + '-tape.json')
    subprocess.run([dotnet, image / 'Inspect.dll', catalog, output], env=env, check=True, timeout=35)
    tape = read(output)
    assert tape['coreSHA256'] == files['Lokad.Lython.dll']
    data[role] = tape['rows']
    listing = lab / (role + '-closed-jit.asm')
    result = lab / (role + '-jit-allocation.json')
    subprocess.run([dotnet, image / 'ValidatedAllocation.dll', image, catalog, result], env=dict(env,
        DOTNET_TieredCompilation='0', DOTNET_JitDisasm='CreateClosedComputedDefinition', DOTNET_JitStdOutFile=str(listing)),
        check=True, timeout=45)
    assert all(row['sharedBudgetBaselineRestored'] for row in read(result)['rows'])
    asm = listing.read_text(encoding='utf-8-sig')
    assert 'Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateClosedComputedDefinition' in asm
    calls = [line.strip() for line in asm.splitlines() if re.match(r'^\s*call\s', line)]
    jit[role] = dict(codeBytes=int(re.search(r'Total bytes of code (\d+)', asm)[1]), calls=calls)
    assert all(digest(image / name) == expected for name, expected in files.items())
assert data['reference'] == data['candidate']
names = [row['id'] for row in data['reference'] if any(body['directDefinitionReturn'] and body['instructions'] == 7
    for body in row['codes'])]
assert len(names) == 3
assert any('StartExecutableDefaults' in call for call in jit['reference']['calls'])
assert not any('StartExecutableDefaults' in call for call in jit['candidate']['calls'])
assert any('AllocateExecutableDefaults' in call for call in jit['candidate']['calls'])
result = dict(sameTapes=sum(len(row['codes']) for row in data['reference']), closedWorkloads=names, jit=jit)
(lab / 'selected-returns.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
print({role: row['codeBytes'] for role, row in jit.items()}, len(names), result['sameTapes'])
