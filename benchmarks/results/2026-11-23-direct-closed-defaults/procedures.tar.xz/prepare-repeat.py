from pathlib import Path


lab = Path(__file__).resolve().parent
template = lab.parent / 'indexed-regex-projection-20261123/prepare-repeat.py'
script = template.read_text(encoding='utf-8')
for old, new in (
    ('b1514', 'b1515'), ('indexed-regex-projection', 'direct-closed-defaults'),
    ("receipt['exitCode'] == '1' and not receipt['fixtures'] and not receipt['receipt']['complete']",
     "receipt['exitCode'] == '0' and not receipt['fixtures'] and receipt['receipt']['complete']"),
    ('[jobs[1], jobs[2], jobs[4]]', '[jobs[4], jobs[5], jobs[2], jobs[6]]'),
    ('bounded confirmation after an idle gate failure', 'confirm factory gains and quote-heavy control debt'),
    ("'assert len(jobs) == 5', 'assert len(jobs) == 3'", "'assert len(jobs) == 7', 'assert len(jobs) == 4'"),
    ('Five bounded lanes', 'Seven bounded lanes'), ('Three bounded lanes', 'Four bounded lanes'),
    ("'seconds=236', 'seconds=180'", "'seconds=363', 'seconds=225'"),
    ("'RuntimeMaxSec=350', 'RuntimeMaxSec=235'", "'RuntimeMaxSec=405', 'RuntimeMaxSec=275'"),
    ("'== 5', '== 3'", "'assert receipt[\"warmJobs\"] == 7', 'assert receipt[\"warmJobs\"] == 4'"),
    ("'==5','==3'", "'len(warm[\"jobs\"])==7','len(warm[\"jobs\"])==4'"),
    ("'timedBatches=140','timedBatches=84'", "'timedBatches=196','timedBatches=112'"),
):
    assert old in script, old
    script = script.replace(old, new)
exec(compile(script, str(template), 'exec'))
