; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateClosedComputedDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Object):Lokad.Lython.Runtime.PyFunctionBase (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 36 single block inlinees; 6 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 248
       lea      rbp, [rsp+0x130]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xB0], ymm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x20], r8
       mov      rsi, rcx
       mov      rdi, rdx
       mov      rbx, r8
       mov      r14, r9
 
G_M000_IG02:                ;; offset=0x004F
       mov      r15, gword ptr [rdi+0x98]
       lea      rcx, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0xC0], rcx
       mov      rcx, gword ptr [rsi+0x10]
       lea      rdx, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x80], rdx
       mov      dword ptr [rbp-0x78], 2
       mov      r13d, dword ptr [r15+0x08]
       test     r13d, r13d
       je       G_M000_IG21
       mov      rdx, gword ptr [r15+0x10]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x80]
       mov      r9, rbx
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       nop      
 
G_M000_IG03:                ;; offset=0x009B
       cmp      r13d, 1
       jbe      G_M000_IG18
       mov      r12, gword ptr [r15+0x30]
       mov      rax, gword ptr [rbx+0xA0]
       mov      gword ptr [rbp-0xB8], rax
       cmp      byte  ptr [rax], al
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00C6
       mov      rcx, gword ptr [rbp-0xB8]
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG05:                ;; offset=0x00D6
       mov      rdx, 0x227B9001C38
       mov      rdx, gword ptr [rdx]
       cmp      r13d, 2
       jbe      G_M000_IG18
       lea      r8, bword ptr [r15+0x50]
       mov      gword ptr [rbp-0x90], rdx
       mov      qword ptr [rbp-0x88], r14
       mov      rdx, r8
       lea      r8, [rbp-0x90]
       mov      r9, gword ptr [rbx+0xA0]
       lea      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       cmp      r13d, 3
       jbe      G_M000_IG18
       mov      r14, gword ptr [r15+0x70]
       mov      r12, gword ptr [rbx+0xA0]
       cmp      byte  ptr [r12], r12b
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0140
       mov      rcx, r12
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG07:                ;; offset=0x014C
       lea      rcx, bword ptr [rbp-0x48]
       cmp      r13d, 4
       jbe      G_M000_IG18
       lea      rdx, bword ptr [r15+0x90]
       mov      r14, gword ptr [rbp+0x30]
       mov      gword ptr [rbp-0x90], r14
       xor      r8d, r8d
       mov      qword ptr [rbp-0x88], r8
       lea      r8, [rbp-0x90]
       mov      r9, gword ptr [rbx+0xA0]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       cmp      r13d, 5
       jbe      G_M000_IG18
       mov      r14, gword ptr [r15+0xB0]
       mov      r15, gword ptr [rbx+0xA0]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x01B2
       mov      rcx, r15
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG09:                ;; offset=0x01BE
       mov      r8, gword ptr [rsi+0x30]
       test     r8, r8
       jne      G_M000_IG16
 
G_M000_IG10:                ;; offset=0x01CB
       mov      rdi, gword ptr [rsi+0x10]
       mov      r15, gword ptr [rsi+0x08]
       mov      rsi, gword ptr [rsi+0x28]
       mov      rcx, rdi
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_DefaultStorageCount():int:this]
       mov      r13d, eax
       cmp      r13d, 2
       ja       G_M000_IG17
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      r12, rax
       lea      r8, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0xA0], r8
       mov      dword ptr [rbp-0x98], r13d
       lea      r8, [rbp-0xA0]
       lea      rcx, [rbp-0x70]
       mov      rdx, rdi
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool):Lokad.Lython.Runtime.FunctionDefaults]
       lea      rcx, bword ptr [rbp-0x58]
       mov      edx, r13d
       shl      rdx, 4
       add      rcx, rdx
       mov      edx, r13d
       neg      edx
       add      edx, 2
       lea      r8, [rbp-0x70]
       mov      qword ptr [rsp+0x20], r8
       xor      r8d, r8d
       mov      dword ptr [rsp+0x28], r8d
       mov      gword ptr [rsp+0x30], rbx
       mov      gword ptr [rsp+0x38], r14
       mov      bword ptr [rbp-0xA0], rcx
       mov      dword ptr [rbp-0x98], edx
       mov      gword ptr [rsp+0x48], rsi
 
G_M000_IG11:                ;; offset=0x0267
       mov      gword ptr [rbp-0xB0], r8
 
G_M000_IG12:                ;; offset=0x026E
       mov      dword ptr [rbp-0xA8], r8d
       mov      byte  ptr [rbp-0xA4], 0
 
G_M000_IG13:                ;; offset=0x027C
       mov      dword ptr [rsp+0x58], r8d
 
G_M000_IG14:                ;; offset=0x0281
       mov      bword ptr [rbp-0x80], r8
 
G_M000_IG15:                ;; offset=0x0285
       mov      dword ptr [rbp-0x78], r8d
       lea      rcx, [rbp-0xB0]
       mov      qword ptr [rsp+0x50], rcx
       lea      rcx, [rbp-0x80]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xA0]
       mov      qword ptr [rsp+0x40], rcx
       mov      rcx, rdi
       mov      rdx, r15
       mov      r8, r12
       xor      r9, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rsi, rax
       mov      edx, r13d
       add      rdx, rdx
       lea      rcx, bword ptr [rbp-0x58]
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
       jmp      SHORT G_M000_IG19
 
G_M000_IG16:                ;; offset=0x02D1
       mov      gword ptr [rsp+0x20], r14
       lea      rdx, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x80], rdx
       mov      dword ptr [rbp-0x78], 2
       lea      rdx, [rbp-0x80]
       mov      qword ptr [rsp+0x28], rdx
       mov      rdx, rdi
       mov      r9, rbx
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedEagerDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ExecutableInstruction[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rsi, rax
       jmp      SHORT G_M000_IG19
 
G_M000_IG17:                ;; offset=0x0302
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG18:                ;; offset=0x0309
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG19:                ;; offset=0x030F
       lea      rax, bword ptr [rbp-0x48]
       mov      rdx, gword ptr [rbx+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:RetireTemporary(Lokad.Lython.Runtime.MemoryGovernor):this]
       mov      rdx, gword ptr [rbx+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       lea      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:RetireTemporary(Lokad.Lython.Runtime.MemoryGovernor):this]
       mov      rax, rsi
 
G_M000_IG20:                ;; offset=0x0345
       add      rsp, 248
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG21:                ;; offset=0x0359
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG22:                ;; offset=0x035F
       sub      rsp, 104
 
G_M000_IG23:                ;; offset=0x0363
       mov      rcx, bword ptr [rbp-0xC0]
       lea      rax, bword ptr [rcx+0x10]
       mov      rbx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbx+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:RetireTemporary(Lokad.Lython.Runtime.MemoryGovernor):this]
       mov      rdx, gword ptr [rbx+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       mov      rcx, bword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:RetireTemporary(Lokad.Lython.Runtime.MemoryGovernor):this]
       nop      
 
G_M000_IG24:                ;; offset=0x03A5
       add      rsp, 104
       ret      
 
; Total bytes of code 938

