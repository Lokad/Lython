from pathlib import Path


lab = Path(__file__).resolve().parent
template_root = lab.parent / 'adjacent-integer-results-20261123'
previous = lab.parent / 'indexed-regex-projection-20261123'
template = (template_root / 'prepare.py').read_text(encoding='utf-8')
prefix = template[:template.index('base = read(')]
prefix = prefix.replace('adjacent-integer-results-20261123', 'direct-closed-defaults-20261123')
prefix = prefix.replace("prior = lab.parent / 'csv-batched-markers-20261123'", "prior = lab.parent / 'indexed-regex-projection-20261123'")
exec(compile(prefix, str(template_root / 'prepare.py'), 'exec'))

base = read(source / 'identity.json')
candidate = (lab / 'built-revision').read_text(encoding='utf-8-sig').strip()
assert not git('-C', tree, 'status', '--porcelain')
assert candidate == git('-C', tree, 'rev-parse', 'HEAD').decode().strip()
assert not git('diff', '--name-only', base['sourceRevision'], candidate + '^', '--', 'src')
catalog = read(lab.parent / 'complete-native-closed-entry-20261123/comparison/representative.json')
eager = 'scripts.annotated-rule-closures.nested-factories'
postponed = eager + '.postponed'
observer = 'scripts.factory-observed-defaults'
supplied = 'scripts.ordinary-fully-supplied-helper'
quoted = 'scripts.csv-invoice.method-policy.quoted-control'
wide = 'calls.positional.wide-native-buffer'
ids = (eager, postponed, observer, supplied, quoted, wide)
catalog['cases'] = [row for row in catalog['cases'] if row['id'] in ids]
assert {row['id'] for row in catalog['cases']} == set(ids)
write(comparison / 'representative.json', catalog)
write(comparison / 'jobs.json', dict(warm=[[name, 'warm'] for name in ids] + [[postponed, 'compile-run']]))

verification = template[template.index('protocol = repo'):template.index('tracked = ')]
verification = verification.replace("proof['caseCount'] == 4", "proof['caseCount'] == 6")
verification = verification.replace('B1513 adjacent integer argument publication', 'B1515 carry owned closed defaults directly')
exec(compile(verification, str(template_root / 'prepare.py'), 'exec'))

# The previous first run and confirmation share two names for one frozen
# core. Only those exact verified replicas may be retired under the lease.
tracked = 'benchmarks/results/2026-11-23-indexed-regex-projection/'
pushed = lambda name: git('show', 'origin/master:' + tracked + name)
archives = []
for role in ('initial-', ''):
    status = json.loads(pushed(role + 'terminal-status.json'))
    assert not status['live'] and not status['fixtures'] and status['receipt']['archivedAndVerifiedUnderLease']
    assert status['receipt']['complete'] == (role == '')
    archived = hash_bytes(pushed(role + 'observations.tar.xz'))
    assert archived == status['receipt']['archiveSHA256']
    archives.append(archived)
files = json.loads(pushed('identity.json'))['imageFiles']['candidate']
assert len(files) == 32 and all(digest(previous / 'candidate' / name) == expected for name, expected in files.items())
replica = gzip.decompress(pushed('candidate-core.dll.gz'))
assert hash_bytes(replica) == files[core]
retirement = dict(core=hash_bytes(replica), size=len(replica), archives=archives)
old_launch = (previous / 'quiet.py').read_text(encoding='utf-8')
old_retirement = old_launch[old_launch.index('   proof='):old_launch.index('  assert free >= minimum')]
adapt('quiet.py', [(old_retirement, f"""   proof={retirement!r}
   earlier=(base/'indexed-regex-projection-b1514-20261123',base/'indexed-regex-projection-b1514-repeat-20261123')
   replicas=[]
   inodes=set()
   for directory, expected_archive in zip(earlier,proof['archives'],strict=True):
    replica=directory/'candidate/Lokad.Lython.dll'
    info=replica.lstat()
    assert replica.resolve()==replica and stat.S_ISREG(info.st_mode)
    assert info.st_uid==os.getuid() and info.st_nlink==2 and info.st_size==proof['size']
    assert digest(replica)==proof['core']
    assert digest(directory/'observations.tar.xz')==expected_archive
    assert not (directory/'guest-fixtures').exists()
    replicas.append(replica)
    inodes.add((info.st_dev,info.st_ino))
   assert len(inodes)==1
   for replica in replicas: replica.unlink()
   free=shutil.disk_usage(base).free
   print(json.dumps(dict(retiredWorkingReplicas=list(map(str,replicas)),sha256=proof['core'],freeAfterRetirement=free)),flush=True)
"""),
    ('lython-b1514-indexed-regex-projection-20261123', 'lython-b1515-direct-closed-defaults-20261123'),
    ('.+b1514-', '.+b1515-'), ('lython-b1514-stage-', 'lython-b1515-stage-'), ('Five bounded lanes', 'Seven bounded lanes'),
    ('RuntimeMaxSec=350', 'RuntimeMaxSec=405'), ('seconds=236', 'seconds=363')])
adapt('stage.py', [('indexed-regex-projection-b1514-20261123', 'direct-closed-defaults-b1515-20261123'),
    ('lython-b1514-fixtures', 'lython-b1515-fixtures'), ('len(jobs) == 5', 'len(jobs) == 7'),
    ('< 307,', '< 367,')])
shutil.copyfile(template_root / 'allocations.py', lab / 'allocations.py')
summary = (template_root / 'summarize.py').read_text(encoding='utf-8')
summary = summary.replace('== 5', '== 7').replace('==5','==7').replace('timedBatches=140','timedBatches=196')
(lab / 'summarize.py').write_text(summary, encoding='utf-8', newline='\n')
