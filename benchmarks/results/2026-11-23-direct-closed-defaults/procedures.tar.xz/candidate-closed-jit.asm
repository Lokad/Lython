; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateClosedComputedDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Object):Lokad.Lython.Runtime.PyFunctionBase (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 34 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 248
       lea      rbp, [rsp+0x130]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xB0], ymm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x20], r8
       mov      rsi, rcx
       mov      rdi, rdx
       mov      rbx, r8
       mov      r14, r9
 
G_M000_IG02:                ;; offset=0x004F
       mov      r15, gword ptr [rdi+0x98]
       mov      rdx, gword ptr [rsi+0x10]
       mov      r13d, dword ptr [r15+0x08]
       test     r13d, r13d
       je       G_M000_IG27
       mov      rcx, gword ptr [r15+0x10]
       mov      gword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0x50]
       mov      r9, rbx
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime:AllocateExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.FunctionDefaults]
       mov      rcx, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0xC0], rcx
       mov      rcx, gword ptr [rbp-0x48]
       mov      gword ptr [rbp-0xC8], rcx
       movzx    rcx, byte  ptr [rbp-0x40]
       mov      dword ptr [rbp-0x54], ecx
 
G_M000_IG03:                ;; offset=0x009D
       cmp      r13d, 1
       jbe      G_M000_IG24
       mov      r12, gword ptr [r15+0x30]
       mov      rax, gword ptr [rbx+0xA0]
       mov      gword ptr [rbp-0xB8], rax
       cmp      byte  ptr [rax], al
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00C8
       mov      rcx, gword ptr [rbp-0xB8]
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG05:                ;; offset=0x00D8
       mov      r8, 0x26CB4401C38
       mov      r8, gword ptr [r8]
       mov      gword ptr [rbp-0x68], r8
       mov      qword ptr [rbp-0x60], r14
       cmp      r13d, 2
       jbe      G_M000_IG24
       mov      r8, gword ptr [r15+0x50]
       mov      gword ptr [rsp+0x20], r8
       lea      r8, [rbp-0x68]
       mov      r9, gword ptr [rbx+0xA0]
       mov      rcx, gword ptr [rbp-0xC0]
       xor      edx, edx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyTuple:SetPrivateDefault(int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState,Lokad.Lython.LythonSourceSpan):this]
       cmp      r13d, 3
       jbe      G_M000_IG24
       mov      r14, gword ptr [r15+0x70]
       mov      r12, gword ptr [rbx+0xA0]
       cmp      byte  ptr [r12], r12b
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0142
       mov      rcx, r12
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG07:                ;; offset=0x014E
       cmp      r13d, 4
       jbe      G_M000_IG24
       mov      r14, gword ptr [r15+0x90]
       mov      r12, gword ptr [rbx+0xA0]
       cmp      byte  ptr [r12], r12b
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x0177
       mov      rcx, r12
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG09:                ;; offset=0x0183
       mov      rcx, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r14, rax
       mov      rcx, gword ptr [rbp-0xC0]
       mov      gword ptr [rbp-0xC0], rcx
       mov      gword ptr [rbp-0xC8], r14
       movzx    rcx, byte  ptr [rbp-0x54]
       mov      dword ptr [rbp-0x54], ecx
       cmp      r13d, 5
       jbe      G_M000_IG24
       mov      r15, gword ptr [r15+0xB0]
       mov      r13, gword ptr [rbx+0xA0]
       cmp      byte  ptr [r13], r13b
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x01D5
       mov      rcx, r13
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG11:                ;; offset=0x01E1
       mov      r8, gword ptr [rsi+0x30]
       test     r8, r8
       je       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x01EA
       mov      rcx, gword ptr [rbp-0xC0]
       mov      gword ptr [rbp-0x50], rcx
       mov      gword ptr [rbp-0x48], r14
       mov      ecx, dword ptr [rbp-0x54]
       mov      byte  ptr [rbp-0x40], cl
       mov      gword ptr [rsp+0x20], r15
       lea      rcx, [rbp-0x50]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, rsi
       mov      rdx, rdi
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedEagerDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ExecutableInstruction[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionDefaults):Lokad.Lython.Runtime.PyFunctionBase]
       jmp      G_M000_IG21
 
G_M000_IG13:                ;; offset=0x0221
       mov      rdi, gword ptr [rsi+0x10]
       mov      r13, gword ptr [rsi+0x08]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      r8, rax
       mov      rdx, gword ptr [rsi+0x28]
       mov      rcx, gword ptr [rbp-0xC0]
       mov      gword ptr [rbp-0x80], rcx
       mov      gword ptr [rbp-0x78], r14
       movzx    rcx, byte  ptr [rbp-0x54]
       mov      byte  ptr [rbp-0x70], cl
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], rbx
       mov      gword ptr [rsp+0x38], r15
 
G_M000_IG14:                ;; offset=0x025F
       mov      bword ptr [rbp-0x90], rcx
 
G_M000_IG15:                ;; offset=0x0266
       mov      dword ptr [rbp-0x88], ecx
       mov      gword ptr [rsp+0x48], rdx
 
G_M000_IG16:                ;; offset=0x0271
       mov      gword ptr [rbp-0xA0], rcx
 
G_M000_IG17:                ;; offset=0x0278
       mov      dword ptr [rbp-0x98], ecx
       mov      byte  ptr [rbp-0x94], 0
 
G_M000_IG18:                ;; offset=0x0285
       mov      dword ptr [rsp+0x58], ecx
 
G_M000_IG19:                ;; offset=0x0289
       mov      bword ptr [rbp-0xB0], rcx
 
G_M000_IG20:                ;; offset=0x0290
       mov      dword ptr [rbp-0xA8], ecx
       lea      rdx, [rbp-0xA0]
       mov      qword ptr [rsp+0x50], rdx
       lea      rdx, [rbp-0x80]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0xB0]
       mov      qword ptr [rsp+0x60], rdx
       lea      rdx, [rbp-0x90]
       mov      qword ptr [rsp+0x40], rdx
       mov      rdx, r13
       mov      rcx, rdi
       xor      r9, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
 
G_M000_IG21:                ;; offset=0x02D2
       xor      rcx, rcx
       mov      gword ptr [rbp-0xC0], rcx
 
G_M000_IG22:                ;; offset=0x02DB
       mov      gword ptr [rbp-0xC8], rcx
 
G_M000_IG23:                ;; offset=0x02E2
       mov      dword ptr [rbp-0x54], ecx
       jmp      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x02E7
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG25:                ;; offset=0x02ED
       mov      rcx, gword ptr [rbx+0xA0]
       mov      ecx, dword ptr [rcx+0x88]
 
G_M000_IG26:                ;; offset=0x02FA
       add      rsp, 248
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG27:                ;; offset=0x030E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG28:                ;; offset=0x0314
       sub      rsp, 104
 
G_M000_IG29:                ;; offset=0x0318
       mov      rbx, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbx+0xA0]
       mov      rbx, gword ptr [rcx+0x88]
       cmp      gword ptr [rbp-0xC0], 0
       je       SHORT G_M000_IG30
       mov      rcx, rbx
       mov      rdx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:RefundUnpublishedValue(System.Object):this]
 
G_M000_IG30:                ;; offset=0x0346
       cmp      byte  ptr [rbp-0x54], 0
       je       SHORT G_M000_IG31
       mov      rcx, 0x7FF9D763D6E8
       call     CORINFO_HELP_GET_NONGCSTATIC_BASE
       mov      rdx, qword ptr [(reloc 0x7ff9d708b118)]
       mov      rcx, rbx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Release(long):this]
       jmp      SHORT G_M000_IG33
 
G_M000_IG31:                ;; offset=0x036F
       mov      rdx, gword ptr [rbp-0xC8]
       mov      rcx, 0x7FF9D7152560
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       je       SHORT G_M000_IG32
       mov      ecx, dword ptr [rax+0x08]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:RecordBytes(int):long]
       mov      rdx, rax
       mov      rcx, rbx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Release(long):this]
       jmp      SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x03A3
       cmp      gword ptr [rbp-0xC8], 0
       je       SHORT G_M000_IG33
       mov      rcx, rbx
       mov      rdx, gword ptr [rbp-0xC8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:RefundUnpublishedValue(System.Object):this]
 
G_M000_IG33:                ;; offset=0x03BF
       nop      
 
G_M000_IG34:                ;; offset=0x03C0
       add      rsp, 104
       ret      
 
; Total bytes of code 965

