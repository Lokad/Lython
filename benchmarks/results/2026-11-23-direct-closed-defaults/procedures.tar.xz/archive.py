from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile


lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
repeat = lab / 'repeat/comparison/quiet'
dest = repo / 'benchmarks/results/2026-11-23-direct-closed-defaults'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(path.read_bytes())
git = lambda *args: subprocess.check_output(['git', *args], cwd=repo)
identity = read(lab / 'comparison/identity.json')
status = read(quiet / 'terminal-status.json')
receipt = status['receipt']
assert not status['live'] and not status['fixtures'] and status['exitCode'] == '0'
assert all(receipt[key] for key in ('complete', 'archivedAndVerifiedUnderLease', 'allWorkersJoined', 'guestFixturesRemoved', 'quietBeforeAndAfter'))
assert digest(quiet / 'observations.tar.xz') == receipt['archiveSHA256']
assert read(quiet / 'summary.json')['timedBatches'] == 196
confirmation = read(repeat / 'terminal-status.json')
assert not confirmation['live'] and not confirmation['fixtures'] and confirmation['exitCode'] == '0'
assert all(confirmation['receipt'][key] for key in ('complete', 'archivedAndVerifiedUnderLease', 'allWorkersJoined', 'guestFixturesRemoved', 'quietBeforeAndAfter'))
assert digest(repeat / 'observations.tar.xz') == confirmation['receipt']['archiveSHA256']
assert read(repeat / 'summary.json')['timedBatches'] == 112
assert read(lab / 'repeat/comparison/identity.json')['imageFiles'] == identity['imageFiles']
rows = read(lab / 'allocation-summary-six.json')
assert len(rows) == 6 and all(row['peakAdmission'][0] == row['peakAdmission'][1] for row in rows)
assert all(row['allocatedBytes'][0] == row['allocatedBytes'][1] for row in rows)
assert read(lab / 'selected-returns.json')['sameTapes'] == 20
changed = git('diff', '--name-only', identity['candidate'] + '^', identity['candidate'], '--', 'src').decode().splitlines()
assert len(changed) == 2
head = git('rev-parse', 'HEAD').decode().strip()
identity['retainedRevision'] = None if git('diff', '--name-only', head, identity['candidate'], '--', 'src') else head
patch = git('diff', '--binary', identity['candidate'] + '^', identity['candidate'], '--', *changed)
(lab / 'comparison.patch').write_bytes(patch)
identity['comparisonPatchSHA256'] = sha(patch)
test_version = lab / 'retained-test-revision'
if test_version.exists():
    identity['retainedTestRevision'] = test_version.read_text(encoding='utf-8-sig').strip()
dest.mkdir(exist_ok=True)
assert all(path.name == 'README.md' for path in dest.iterdir())
for role, files in identity['imageFiles'].items():
    assert len(files) == 32 and all(digest(lab / role / name) == expected for name, expected in files.items())
    core = lab / role / 'Lokad.Lython.dll'
    image = dest / 'candidate-core.dll.gz' if role == 'candidate' else dest.parent / '2026-11-23-retained-call-cpython/candidate-core.dll.gz'
    if role == 'candidate':
        image.write_bytes(gzip.compress(core.read_bytes(), mtime=0))
    assert sha(gzip.decompress(image.read_bytes())) == files[core.name]
(dest / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
for name in ('observations.tar.xz', 'summary.json', 'terminal-status.json'):
    shutil.copyfile(quiet / name, dest / name)
    shutil.copyfile(repeat / name, dest / ('repeat-' + name))
for name in ('allocation-summary-six.json', 'selected-returns.json'):
    shutil.copyfile(lab / name, dest / name)
with tarfile.open(dest / 'procedures.tar.xz', 'w:xz') as archive:
    for name in (
        'archive.py', 'prepare.py', 'prepare-repeat.py', 'stage.py', 'quiet.py', 'comparison.patch', 'summarize.py', 'allocations.py', 'allocations.log',
        'windows-frozen.log', 'windows-public.log', 'windows-white.log', 'ubuntu-public.log', 'ubuntu-white.log',
        'reference-allocation-six.json', 'candidate-allocation-six.json', 'prepare.log', 'stage.log', 'launch.log', 'retrieval.log',
        'comparison/reference-verify.json', 'comparison/candidate-verify.json', 'comparison/quiet/observe-not-before',
        'inspect.py', 'inspect.log', 'candidate-closed-jit.asm', 'reference-closed-jit.asm', 'candidate-tape.json', 'reference-tape.json',
        'inspect-quote.py', 'inspect-quote.log', 'candidate-quote-jit.asm', 'reference-quote-jit.asm', 'quote-jit-summary.json',
        'repeat-initial-stage.log', 'repeat-launch.log', 'repeat-retrieval.log', 'repeat/quiet.py', 'repeat/summarize.py',
        'repeat/comparison/quiet/observe-not-before',
        'probe-reference/cases.json', 'probe-reference/results.jsonl', 'probe-candidate/results.jsonl'):
        archive.add(lab / name, arcname=name)
    for name in ('windows-rollback.log', 'ubuntu-rollback.log', 'windows-retained.log', 'ubuntu-retained.log',
        'negative-rollback.log', 'negative-rollback-single-annotation.log', 'rollback-test.patch',
        'windows-rollback-first.log', 'ubuntu-rollback-first.log', 'windows-rollback-single-annotation.log',
        'ubuntu-rollback-single-annotation.log', 'windows-retained-single-annotation.log', 'ubuntu-retained-single-annotation.log'):
        if (lab / name).is_file():
            archive.add(lab / name, arcname=name)
    observer = lab.parent / 'adjacent-integer-results-20261123/factory-observer-probe'
    for name in ('cases.json', 'tape.json', 'sync.jsonl', 'async.jsonl'):
        archive.add(observer / name, arcname='factory-observer-probe/' + name)
print(dest, identity['retainedRevision'] or 'private')
