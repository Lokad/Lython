from pathlib import Path
import hashlib
import json
import os
import re
import subprocess


lab = Path(__file__).resolve().parent
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
write = lambda path, value: path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')
dotnet = Path.home() / '.dotnet11/dotnet.exe'
catalog = read(lab / 'comparison/representative.json')
catalog['cases'] = [row for row in catalog['cases'] if row['id'].endswith('.quoted-control')]
assert len(catalog['cases']) == 1
input_path = lab / 'quote-inspect-case.json'
write(input_path, catalog)
groups = {}
for role, files in read(lab / 'comparison/identity.json')['imageFiles'].items():
    image = lab / role
    assert len(files) == 32 and all(digest(image / name) == expected for name, expected in files.items())
    output = lab / (role + '-quote-jit.asm')
    allocation = lab / (role + '-quote-jit.json')
    subprocess.run([dotnet, image / 'ValidatedAllocation.dll', image, input_path, allocation], env=dict(os.environ,
        DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent), DOTNET_TieredCompilation='0',
        DOTNET_JitDisasm='TryExecuteNativeCall StartNativeCall CreateClosedComputedDefinition StartExecutableDefaults',
        DOTNET_JitStdOutFile=str(output)), check=True, timeout=60)
    assert read(allocation)['rows'][0]['sharedBudgetBaselineRestored']
    listing = output.read_text(encoding='utf-8-sig')
    methods = re.findall(r'; Assembly listing for method ([^\n]+).*?; Total bytes of code (\d+)', listing, re.S)
    assert methods and all('CreateClosedComputedDefinition' not in name and 'StartExecutableDefaults' not in name
        for name, _ in methods)
    groups[role] = {name.split(':', 1)[-1].split('(', 1)[0]: int(size) for name, size in methods}
    assert len(groups[role]) == 2
write(lab / 'quote-jit-summary.json', groups)
print(groups)
