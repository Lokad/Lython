from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.with_name('remaining-shipment-cpu-20261126')/'prepare.py'
source = template.read_text(encoding='utf-8')
source = source.replace("donor = lab.parent/'short-path-cpython-20261126'", "donor = lab.parent/'identity-comparisons-20261126'")
source = source.replace("archive = donor/'comparison/quiet'", "archive = lab.with_name('identity-comparisons-confirmation-20261126')/'comparison/quiet'")
start = source.index("files = record['imageFiles']['candidate']")
stop = source.index("save(quiet/'identity.json',manifest)",start)
source = source[:start] + '''files = record['imageFiles']
for role, expected in files.items():
    assert len(expected)==32 and {p.name:sha(p) for p in (donor/role).iterdir()}==expected
baseline = record['sourceRevision']
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('37df68bfe')
patch = subprocess.check_output(['git','diff','--binary',baseline,head,'--','src'],cwd=repo)
assert patch == (donor/'candidate.patch').read_bytes() and hashlib.sha256(patch).hexdigest()==record['sourcePatchSHA256']
catalog = read(archive/'representative.json')
case_id='diagnostic.shipment-file-fed-map'
catalog['cases']=[case for case in catalog['cases'] if case['id']==case_id]
assert len(catalog['cases'])==1
save(quiet/'catalog.json',catalog)
manifest=dict(sourceRevision=baseline, inspectedHead=head, sourcePatchSHA256=record['sourcePatchSHA256'],imageFiles=files,
              coreSHA256={role:expected['Lokad.Lython.dll'] for role,expected in files.items()},
              donorArchiveSHA256=receipt['archiveSHA256'], profileCatalogSHA256=sha(quiet/'catalog.json'),
              profiles=[['file-fed-reference-async',case_id,'reference'],['file-fed-candidate-async',case_id,'candidate']],
              purpose='Attribute recurring B1756 file-fed control movement on the original frozen workers.')
''' + source[stop:]
source = source.replace('short-path-cpython-b1750-20261126','identity-comparisons-confirmation-b1756-20261126')
source = source.replace('b1752-fixtures','b1757-fixtures')
source = source.replace('lython-b1752-shipment-cpu-20261126','lython-b1757-file-fed-comparison-cpu-20261126')
source = source.replace('shipment-cpu-b1752-20261126','file-fed-comparison-cpu-b1757-20261126')
old = "compile(source,'quiet.py','exec');write(lab/'quiet.py',source)"
new = """source=source.replace("assert {p.name:sha(p) for p in frozen.iterdir()}==image['imageFiles']['candidate'] and len(image['imageFiles']['candidate'])==32",
    "assert all(len(files)==32 and {p.name:sha(p) for p in (donor/role).iterdir()}==files for role,files in image['imageFiles'].items())")
compile(source,'quiet.py','exec');write(lab/'quiet.py',source)"""
assert source.count(old)==1
source = source.replace(old,new)
start=source.index("proof=quiet/'verification.json'")
stop=source.index("payload=quiet/'stage.tar.gz'",start)
source=source[:start]+'''for role, expected in files.items():
    proof=quiet/f'{role}-verification.json'
    subprocess.run([dotnet,donor/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'catalog.json',
                    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',worker,'--out',proof],
                    cwd=repo,env=env,check=True,timeout=55)
    data=read(proof)
    assert data['state']=='Completed' and data['caseCount']==1 and data['catalogSha256']==manifest['profileCatalogSHA256']
    assert data['launched']['library']['sha256']==expected['Lokad.Lython.dll']
'''+source[stop:]
exec(compile(source,str(template),'exec'),{'__file__':str(lab/'prepare.py')})