from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab/'comparison/quiet'
root = lab.parents[3]
result = root/'benchmarks/results/2026-11-26-file-fed-comparison-attribution'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):
    return json.loads(path.read_text(encoding='utf-8'))
identity = read(quiet/'identity.json')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip() == identity['inspectedHead']
terminal = read(quiet/'terminal-status.json')
receipt = terminal['receipt']
assert terminal['exitCode']=='0' and not terminal['live'] and not terminal['fixtures']
assert all(receipt[field] for field in ('complete','allWorkersJoined','quietBeforeAndAfter','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256']==sha(quiet/'observations.tar.xz')
with tarfile.open(quiet/'observations.tar.xz') as archive:
    assert json.load(archive.extractfile('identity.json')) == identity
    assert hashlib.sha256(archive.extractfile('catalog.json').read()).hexdigest()==identity['profileCatalogSHA256']
rows = read(quiet/'attribution.json')['rows']
assert [r['label'] for r in rows]==[p[0] for p in identity['profiles']]
result.mkdir()
for name in ('identity.json','terminal-status.json','observations.tar.xz','attribution.json'):
    shutil.copyfile(quiet/name,result/name)
with tarfile.open(result/'procedures.tar.xz','w:xz') as archive:
    for name in ('archive.py','prepare.py','quiet.py'):
        archive.add(lab/name,arcname=name)
    for name in ('launch.log','collect.py','ops-profile.py','analyze.py','run.sh','catalog.json','reference-verification.json','candidate-verification.json'):
        archive.add(quiet/name,arcname='quiet/'+name)
    for name in ('remaining-shipment-cpu-20261126/prepare.py','file-processing-profile-20261126/quiet.py'):
        archive.add(lab.parent/name,arcname='template/'+name)
    donor=lab.with_name('affix-text-attribution-20261126')/'comparison/quiet'
    for name in ('collect.py','ops-profile.py','analyze.py','run.sh'):
        archive.add(donor/name,arcname='template/quiet/'+name)
for row in rows:
    print(row['label'],row['invocations'],row['sampleCount'],row['guestRuntimeAncestry'],row['guestRuntimeFocus'])
    print(row['nearestRuntimeMethods'][:12])