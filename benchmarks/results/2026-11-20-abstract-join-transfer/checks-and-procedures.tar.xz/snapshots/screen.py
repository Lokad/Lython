from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys

base = Path(__file__).resolve().parent
notes = base.parent
root = base.parents[3]
lab = base/"refined" if sys.argv[1:] == ["--refined"] else base
trial = root/".git/agent-worktrees/private-abstract-snapshots"


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=trial).strip()
candidate = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=trial, text=True).strip()
ref = notes/"private-json-property-layout"
reference = load(ref/"quiet/identity.json")["imageFiles"]["candidate"]
previous = notes/"one-abstract-expression-dispatch"
catalog = lab/"catalog.json"
sdk = Path.home()/".dotnet11"
dotnet = sdk/"dotnet.exe"
worker = root/"benchmarks/cpython-worker.py"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk)+os.pathsep+os.environ["PATH"])
files = {}
for role in ("reference", "candidate"):
    image = lab/"frozen"/role
    image.mkdir(parents=True)
    for name in reference:
        source = ref/"frozen/candidate"/name
        if role == "candidate" and name == "Lokad.Lython.dll":
            source = trial/"src/Lokad.Lython/bin/Release/net11.0"/name
        shutil.copyfile(source, image/name)
    hashes = {name:sha(image/name) for name in reference}
    files[role] = hashes
    for file in (notes/"direct-statement-emission/frozen/reference").glob("CompileAllocation.*"):
        shutil.copyfile(file, image/file.name)
    with (lab/f"{role}-compile-allocation.json").open("wb") as allocation:
        subprocess.run([dotnet,image/"CompileAllocation.dll",catalog],
                       env=dict(env,DOTNET_TieredCompilation="0"), capture_output=False,
                       stdout=allocation, check=True, timeout=120)
    assert load(lab/f"{role}-compile-allocation.json")["coreSha256"] == hashes["Lokad.Lython.dll"]
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
                    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",worker,
                    "--out",lab/f"{role}-verify.json"],env=env,check=True,timeout=100)
    verify = load(lab/f"{role}-verify.json")
    assert verify["state"] == "Completed" and verify["catalogSha256"] == sha(catalog)
    assert {name:sha(image/name) for name in reference} == hashes
assert files["reference"] == reference
assert [name for name in reference if files["candidate"][name] != reference[name]] == ["Lokad.Lython.dll"]
identity = dict(candidate=candidate, reference="d61cfc85b", catalogSha256=sha(catalog), imageFiles=files)
(lab/"frozen-identity.json").write_text(json.dumps(identity,indent=2)+"\n",encoding="utf-8",newline="\n")
