import json


def read_configuration(path):
    with open(path, encoding="utf-8") as source:
        return json.load(source)


def write_document(path, document):
    with open(path, "w", encoding="utf-8", newline="") as target:
        json.dump(document, target, ensure_ascii=False, indent=2, sort_keys=True)
        target.write("\n")


def project_name(config):
    return config["project"].strip()


def default_labels(config):
    return config.get("defaults", {}).get("labels", [])


def normalize_label(label):
    return label.strip().lower()


def normalize_labels(labels):
    return sorted({normalize_label(label) for label in labels if label.strip()})


def include_target(target):
    return target.get("enabled", True)


def target_name(target):
    return target["name"].strip().lower()


def target_path(target):
    return target["path"].strip()


def target_record(target, labels):
    return {
        "name": target_name(target),
        "path": target_path(target),
        "labels": normalize_labels(labels + target.get("labels", [])),
    }


def target_records(config):
    defaults = default_labels(config)
    return [target_record(item, defaults) for item in config.get("targets", []) if include_target(item)]


def remove_comment(line):
    return line.partition("#")[0].strip()


def normalize_dependency_name(name):
    return name.strip().lower().replace("_", "-")


def dependency_record(line):
    name, separator, version = line.partition("==")
    return {"name": normalize_dependency_name(name), "version": version.strip() if separator else None}


def read_dependencies(path):
    records = {}
    with open(path, encoding="utf-8") as source:
        for raw in source:
            line = remove_comment(raw)
            if line:
                record = dependency_record(line)
                records[record["name"]] = record
    return [records[name] for name in sorted(records)]


def make_summary(targets, dependencies):
    return {"targets": len(targets), "dependencies": len(dependencies)}


def assemble_manifest(project, targets, dependencies):
    return {"project": project, "targets": targets, "dependencies": dependencies}


def main():
    config = read_configuration("config.json")
    dependencies = read_dependencies("requirements.txt")
    targets = target_records(config)
    config["project"] = project_name(config)
    config["targets"] = targets
    config["summary"] = make_summary(targets, dependencies)
    manifest = assemble_manifest(config["project"], targets, dependencies)
    write_document("config.json", config)
    write_document("manifest.json", manifest)
    print(f"{len(targets)} targets / {len(dependencies)} dependencies")


main()
