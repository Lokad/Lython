set -eu
root=$PWD
lab=$root/.git/agent-notes/review-20261031/private-abstract-snapshots/refined
bin=$root/.git/agent-worktrees/private-abstract-snapshots/tests/Lokad.Lython.PublicApi.Tests/bin/Release/net10.0
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dotnet vstest "$bin/Lokad.Lython.PublicApi.Tests.dll" "/TestAdapterPath:$bin" '/TestCaseFilter:(FullyQualifiedName~CompilerCancellation|FullyQualifiedName~FunctionDefinitionIsolation|FullyQualifiedName~GovernedMemoryContract)&Category!=Stress' >"$lab/cancellation-and-admission-vstest-ubuntu.log" 2>&1
tail -n 6 "$lab/cancellation-and-admission-vstest-ubuntu.log"
