from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
root = lab.parents[4]
sdk = Path.home()/".dotnet11"
probe = root/".git/agent-worktrees/private-abstract-snapshots/tools/LythonProbe/bin/Release/net11.0"
old = root/"benchmarks/results/2026-11-18-abstract-branch-maps/checks-and-procedures.tar.xz"

with tarfile.open(old) as archive:
    sources = json.load(archive.extractfile("probe-inputs.json"))
for name in ("ShortCircuitRefinementTests", "SequenceLengthRefinementTests", "AnnotationFlowBoundaryTests"):
    tests = (root/f"tests/Lokad.Lython.PublicApi.Tests/{name}.cs").read_text(encoding="utf-8")
    for text in re.findall(r'\[InlineData\(("(?:[^"\\]|\\.)*")', tests):
        try:
            sources.append(json.loads(text))
        except json.JSONDecodeError:
            continue
sources.extend([
    "def render(flag):\n    x: int = 1\n    y = x and flag\n    value: str = x\n    return y\nprint(render(False))\n",
    "def flag(value):\n    x = value\n    return 2 if x else 'x'\nprint(flag(False))\n",
    "x = [1, 2]\nif 0 < len(x) < 10 and x[0]:\n    print(x[1])\n",
    "def task(done):\n    x: int = 1\n    try:\n        if done: x = 2\n    except ValueError:\n        x = 3\n    finally:\n        output: str = x\nprint(task(False))\n",
    "def select(value):\n    match value:\n        case 0: result = 1\n        case _: result = 2\n    checked: str = result\nprint(select(0))\n",
    "def use(flag):\n    x: int = 1\n    while flag:\n        x = 2\n        break\n    else:\n        x = 3\n    text: str = x\nprint(use(False))\n",
])
sources = list(dict.fromkeys(sources))
request = json.dumps(sources, ensure_ascii=False)
(lab/"probe-inputs.json").write_text(request+"\n",encoding="utf-8",newline="\n")
identity = json.loads((lab/"frozen-identity.json").read_text(encoding="utf-8"))
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ["PATH"])
images = {}
for role in ("reference", "candidate"):
    dest = lab/"probe"/role
    shutil.copytree(probe, dest)
    core = "Lokad.Lython.dll"
    shutil.copyfile(lab/"frozen"/role/core, dest/core)
    files = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.iterdir() if p.is_file()}
    assert files[core] == identity["imageFiles"][role][core]
    images[role] = files
assert [name for name in images["reference"] if images["reference"][name] != images["candidate"][name]] == [core]
(lab/"probe-images.json").write_text(json.dumps(images,indent=2)+"\n",encoding="utf-8",newline="\n")
for mode in ("sync","async"):
    results = []
    for role in ("reference","candidate"):
        args = [sdk/"dotnet.exe", lab/"probe"/role/"LythonProbe.dll", "--batch-json"]
        if mode == "async":
            args.append("--async")
        run = subprocess.run(args,input=request,text=True,encoding="utf-8",capture_output=True,env=env,timeout=45)
        assert run.returncode in (0,1) and not run.stderr, (run.returncode,run.stderr)
        (lab/f"probe-{mode}-{role}.jsonl").write_text(run.stdout,encoding="utf-8",newline="\n")
        results.append([json.loads(line)["Lython"] for line in run.stdout.splitlines()])
    assert len(results[0]) == len(results[1]) == len(sources)
    for left,right in zip(*results,strict=True):
        for field in ("Diagnostics", "StandardOutput", "StandardError", "Success", "ExitCode"):
            assert left[field] == right[field], (field,left,right)
    print(mode,len(sources),"identical ordered diagnostics and outcomes")
