from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
notes = lab.parents[1]
repo = lab.parents[4]
q = lab/"quiet"
q.mkdir()
donor = notes/"private-json-property-layout"
template = donor/"quiet"
core = "Lokad.Lython.dll"


def read(path):
    return path.read_text(encoding="utf-8")


def load(path):
    return json.loads(read(path))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def emit(path, text):
    if path.suffix == ".py":
        compile(text, str(path), "exec")
    path.write_text(text, encoding="utf-8", newline="\n")


def save(path, obj):
    emit(path, json.dumps(obj, indent=2)+"\n")


def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)


old = load(template/"config.json")
receipt = load(template/"archive-receipt.json")
assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
assert receipt["archiveSHA256"] == sha((template/"observations.tgz").read_bytes())
checked = load(lab/"frozen-identity.json")
assert checked["candidate"].startswith("05db3861b")
images = checked["imageFiles"]
assert images["reference"] == old["identity"]["imageFiles"]["candidate"]
assert [name for name in images["reference"] if images["reference"][name] != images["candidate"][name]] == [core]
manifest = lab/"paired-catalog.json"
manifest_hash = sha(manifest.read_bytes())
for role, files in images.items():
    assert len(files) == 32
    assert {name:sha((lab/"frozen"/role/name).read_bytes()) for name in files} == files
    verified = load(lab/f"{role}-verified-paired.json")
    assert verified["state"] == "Completed" and verified["catalogSha256"] == manifest_hash
assert sha((notes/"lexical-definition-delivery-cpython/cpython-worker.py").read_bytes()) == old["protocolSHA256"]

location = "/home/lokad/lython-bench-checks/abstract-join-transfer-b1234-20261120"
unit = "lython-b1234-abstract-join-transfer-20261120"
purpose = "Reuse completed branches for all abstract-state joins"
identity = dict(sourceRevision=git("rev-parse", "d61cfc85b").decode().strip()+" versus "+checked["candidate"],
                purpose=purpose, imageFiles=images, catalogSHA256=manifest_hash, normalAdapterPin="0.4.0",
                coreSHA256={role+suffix:files[core] for role, files in images.items() for suffix in ("","-control")})
save(q/"identity.json", identity)
jobs = [
    ("scripts.config-manifest.helper-guards", "compile"),
    ("scripts.config-generated-guards.medium", "compile"),
    ("scripts.config-manifest.helper-guards", "compile-run"),
    ("scripts.config-manifest.small", "warm"),
]
assert set(case for case,_ in jobs) <= {case["id"] for case in load(manifest)["cases"]}
for name in ("collect.py","archive-owned.py","run.sh","retrieve.py"):
    text = read(template/name).replace(old["root"], location).replace(old["unit"], unit)
    if name == "collect.py":
        start = text.index("\njobs = ")
        end = text.index("\nassert len(jobs)", start)
        text = text[:start]+"\njobs = "+repr(jobs)+text[end:]
    if name in ("archive-owned.py","retrieve.py"):
        text = text.replace("==3", "==4").replace("jobs=3,", "jobs=4,")
    emit(q/name, text)
assert b"\r" not in (q/"run.sh").read_bytes()
assert "len(raw['jobs'])==4" in read(q/"archive-owned.py")
assert "status['receipt']['jobs']==4" in read(q/"retrieve.py")
(q/"candidate").mkdir()
shutil.copyfile(lab/"frozen/candidate"/core, q/"candidate"/core)
shutil.copyfile(manifest, q/"representative.json")
parts = ("identity.json","representative.json","collect.py","archive-owned.py","run.sh","candidate/"+core)
with tarfile.open(q/"payload.tgz","w:gz") as bundle:
    for name in parts:
        bundle.add(q/name, arcname=name)

# A source-matched, one-link comparison replica after the original capture.
# Both its canonical raw archive and the binary are already in Git.
evidence = "benchmarks/results/2026-11-20-direct-declaration-operands"
archived = git("cat-file", "blob", "d61cfc85b:"+evidence+"/confirmation/observations.tgz")
archive_receipt = json.loads(git("cat-file", "blob", "d61cfc85b:"+evidence+"/confirmation/archive-receipt.json"))
assert archive_receipt["archivedAndVerifiedUnderLease"] and sha(archived) == archive_receipt["archiveSHA256"]
canonical = evidence+"/measured-candidate-core.dll.gz"
older_core = gzip.decompress(git("cat-file", "blob", "d61cfc85b:"+canonical))
retirement_root = "declaration-operands-manifest-confirmation-b1221-20261120"
proof = dict(archivePath=retirement_root+"/observations.tgz", canonicalArchiveSHA256=sha(archived),
             paths=[retirement_root+"/candidate/"+core], links=1, bytes=len(older_core), sha256=sha(older_core),
             optional=True, verifiedCanonicalGitImage=canonical)
config = dict(root=location, unit=unit, source=old["root"], sourceRole="candidate",
              sourceFiles=images["reference"],sourceCatalogSHA256=old["catalogSHA256"],
              protocolSHA256=old["protocolSHA256"],catalogSHA256=manifest_hash,identity=identity,
              donorArchiveSHA256=receipt["archiveSHA256"],retireGroups=[proof],
              payloadBytes=(q/"payload.tgz").stat().st_size,payloadSHA256=sha((q/"payload.tgz").read_bytes()),
              unpackedBytes=sum((q/name).stat().st_size for name in parts))
save(q/"config.json", config)
text = read(template/"remote-launch.py")
start = text.index("\nc=")+1
end = text.index("\nb=Path(",start)
text = (text[:start]+"c="+repr(config)+text[end:]).replace("lython-b1231-fixtures","lython-b1234-fixtures")
assert "+64*1024*1024" in text
emit(q/"remote-launch.py",text)
emit(lab/"launch.py",read(donor/"launch-quiet.py").replace("JSON property-layout comparison","Abstract branch-join comparison"))
emit(lab/"summarize.py",read(donor/"summarize-quiet.py"))
print("Staged two verified 32-file images and four short comparison lanes.")
