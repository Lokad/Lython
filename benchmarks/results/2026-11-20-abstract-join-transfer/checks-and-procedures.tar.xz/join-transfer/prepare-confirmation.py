from pathlib import Path
import hashlib
import json
import tarfile

base = Path(__file__).resolve().parent
first = base/"quiet"
lab = base/"confirmation"
q = lab/"quiet"
q.mkdir(parents=True)


def read(path):
    return path.read_text(encoding="utf-8")


def load(path):
    return json.loads(read(path))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def emit(path, text):
    if path.suffix == ".py":
        compile(text, str(path), "exec")
    path.write_text(text,encoding="utf-8",newline="\n")


prior = load(first/"config.json")
receipt = load(first/"archive-receipt.json")
assert receipt["archivedAndVerifiedUnderLease"] and receipt["archiveSHA256"] == sha(first/"observations.tgz")
summary = load(base/"quiet-summary.json")
job = next(row for row in summary["rows"] if row["lane"] == "compile-run")
assert job["case"] == "scripts.config-manifest.helper-guards" and job["elapsedChangePercent"][-1] > 10
location = "/home/lokad/lython-bench-checks/abstract-join-transfer-confirm-b1235-20261120"
unit = "lython-b1235-abstract-join-transfer-confirm-20261120"
emit(q/"identity.json",read(first/"identity.json"))
for name in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    text = read(first/name).replace(prior["root"],location).replace(prior["unit"],unit)
    if name == "collect.py":
        a = text.index("\njobs = ")
        b = text.index("\nassert len(jobs)",a)
        text = text[:a]+"\njobs = "+repr([(job["case"],job["lane"])])+text[b:]
        text = text.replace("len(jobs)==4","len(jobs)==1")
        text = text.replace("labels=['reference-control','candidate-control','reference','candidate']",
                            "labels=['candidate','reference','candidate-control','reference-control']")
        text = text.replace("accumulate 12 seconds","accumulate 15 seconds").replace("warmupSeconds=12","warmupSeconds=15")
        text = text.replace("min(warmed)<12","min(warmed)<15").replace("warmed[i]>=12","warmed[i]>=15")
    if name in ("archive-owned.py","retrieve.py"):
        text = text.replace("==4","==1").replace("jobs=4,","jobs=1,")
    emit(q/name,text)
assert b"\r" not in (q/"run.sh").read_bytes()
assert "len(raw['jobs'])==1" in read(q/"archive-owned.py")
assert "status['receipt']['jobs']==1" in read(q/"retrieve.py")
parts = ("identity.json","collect.py","archive-owned.py","run.sh")
payload = q/"payload.tgz"
with tarfile.open(payload,"w:gz") as bundle:
    for name in parts:
        bundle.add(q/name,arcname=name)
config = dict(prior,root=location,unit=unit,source=prior["root"],sourceRole="reference",
              sourceCatalogSHA256=prior["catalogSHA256"],retireGroups=[],donorArchiveSHA256=receipt["archiveSHA256"],
              payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),
              unpackedBytes=sum((q/name).stat().st_size for name in parts))
emit(q/"config.json",json.dumps(config,indent=2)+"\n")
text = read(first/"remote-launch.py")
a = text.index("\nc=")+1
b = text.index("\nb=Path(",a)
text = text[:a]+"c="+repr(config)+text[b:]
text = text.replace("os.link(source/c['sourceRole']/n,p)","os.link(source/role/n,p)")
text = text.replace("lython-b1234-fixtures","lython-b1235-fixtures")
emit(q/"remote-launch.py",text)
emit(lab/"launch.py",read(base/"launch.py").replace("seconds=325","seconds=108").replace("before 325","before 108"))
emit(lab/"summarize.py",read(base/"summarize.py").replace("len(raw['jobs'])==4","len(raw['jobs'])==1"))
print("One compile-to-result lane using exact previous images, reversed worker order and 15-second warmup.")
