from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess,tarfile
proof=[{'commit': '5a59631f162bab02ae2181691afa9be6946b67a4', 'canonicalArchive': 'benchmarks/results/2026-11-15-closed-word-segment/phase-one/observations.tgz', 'remoteRoot': 'word-segment-b766-20261115', 'archiveSHA256': '8345c1fc2fccf1d8cbaf2c878cb4ee98abba5b0cdc8cc1e1b40414a2ba3df770', 'member': 'confirmation/confirmation.json', 'bytes': 569231, 'sha256': '341cb27ad39cc8b39bcf51e48f204eb2cdb38d3ac6dbdf266707cdef365d56a1'}]
required=5768038
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(p.is_mount()for p in base.glob('*/guest-fixtures'))
 paths=[];observations=[]
 for item in proof:
  root=base/item['remoteRoot'];p=root/item['member'];archive=root/'observations.tgz'
  assert root.resolve()==root and p.resolve()==p and archive.resolve()==archive and p.is_relative_to(base)
  s=p.lstat();assert stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1 and s.st_size==item['bytes']
  assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
  assert hashlib.sha256(archive.read_bytes()).hexdigest()==item['archiveSHA256']
  with tarfile.open(archive)as a:assert hashlib.sha256(a.extractfile(item['member']).read()).hexdigest()==item['sha256']
  assert(root/'exit-code.txt').read_text().strip()=='0'and json.loads((root/'archive-receipt.json').read_text())['complete']
  paths.append(p);observations.append(dict(path=str(p),uid=s.st_uid,inode=s.st_ino,links=s.st_nlink,bytes=s.st_size,archiveStillPresent=str(archive)))
 before=shutil.disk_usage(base).free
 assert before+sum(item['bytes']for item in proof)>254*1024*1024+32768
 for p in paths:p.unlink()
 receipt=dict(committedProof=proof,metadata=observations,allPathsMetadataAndRawArchiveHashesVerifiedBeforeMutation=True,idleLease=True,retiredOnlyDuplicateJson=[str(p)for p in paths],beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,compressedRawArchivesAndLocalGitEvidenceRetained=True,currentImagesCatalogsToolchainsAndFloorsUnchanged=True)
 (base/'b767-proved-archived-json-deduplication.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt),flush=True)
