# Lokad.Lython 0.11.0

Updated 2026-11-15 UTC. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including compile-once/run-once. An isolated experiment does not finish this goal.
Current contracts belong in docs; experimental history and every adverse result
remain in [EXPERIMENTS](benchmarks/EXPERIMENTS.md) and immutable results.

## Delivery status

| State | Evidence and limits |
| --- | --- |
| Committed, delivery qualification in progress | `cf754dc7` / frozen `95798eb9`: shared executable storage and compiled returns. All 585 inputs match committed source with explicit newline normalization. Initial CI `43661215938` FAILED on 43 obsolete internal fixture casts per platform; all 17,849 public .NET 11 tests pass on each. Direct-access fixture correction preserves lifetime assertions; complete internal actual11/10 and one full delivery retry follow. Terminal is cached forever; no runtime image changed. |
| Latest fully qualified baseline | `4beb9ecf` / `bed6e57e`, [43649993181 GREEN, cached](benchmarks/results/2026-11-14-builtin-scalar-publication/delivery/README.md). Both platforms/frameworks, 4,776 internal/17,847 public ordinary and original 13/406 stress per combination, installed consumers. Do not requalify unchanged work. |
| Retained with explicit tradeoffs | [R373](benchmarks/results/2026-11-15-shared-executable-slots/README.md): invoice allocation -7.89%, elapsed -1.81..-2.80% / wider CPU -1.49..-2.94%. Short diagnostic allocation -18.83%. Accept observed-value elapsed +2.83..+4.65% / CPU +4.28..+5.04%, and possible fulfillment fresh regression (+0.30..+2.76% elapsed, CPU mixed), as 0.11 tradeoffs. No broad CPU, latency-tail or physical-heap claim. |
| Current external measurements, qualification pending | B764 on exact `cf754dc7`/`95798eb9` versus stock CPython 3.13.16: invoice 1.21–1.22x warm, fulfillment 1.18–1.21x warm/fresh and 1.12–1.13x compilation, captured text 1.42–1.44x. Five jobs/199.457s/all gates; users/RAM closed. Other guide rows keep named older revisions. No cross-collection causal attribution or debt erasure. |
| Prototypes | R373 phase one is superseded by its completed, retained return-transport refinement. Both exact images, initial failures and adverse B762 results survive. No uncommitted runtime prototype remains. Withdrawn arenas/controllers, side arrays, CSV ranges and cased-buffer designs remain removed. |

Completed: shared compiler facts/nonlocal correction and retention cleanup; direct
UTF-8 formatting/storage; native helper returns; final argument slots/linear
continuations; immutable plain builtins; native/owned loops and tuple returns;
shared arithmetic/range positions; bulk CSV/shared keys; UTF-8 JSON/incremental
XML. Preserve all correctness fixes and cached qualification.
Native helper returns established about 19–20% less allocation; original elapsed
results remain diagnostic. Formatting established -8.67% allocation; [controlled
confirmation](benchmarks/results/2026-11-02-formatting-confirmation/README.md)
supports report elapsed/CPU -5–8%; original adverse 15.125ms remains unexplained.
These are historical revisions, not measurements of current HEAD.

## Prioritized deliverables

1. **Close the coherent R373 delivery checkpoint.** Finish the single active full
   platform/framework, original-stress and installed-consumer qualification.
   Record its actual outcome and the new CPython phases in the current guide;
   retain original B761 and both source pairs. R373 removes separate native long
   arrays, loans, flags, capacity facts and generic cache parameter; function
   arguments, locals, operands and compiled returns share one managed layout.
   Real builtin/callback object ABIs and ordinary/native execution remain.
   Wider reference storage can refuse earlier. Stable identity at aliases,
   collections, public/protocol results and finally observation is preserved.
   Focused checks already pass per actual framework: 319 internal, 6,996 public;
   140 isolated CPython controls and 16 phase goldens match. Do not repeat these
   unchanged. Allocation and CPU are separate outcomes; CSV values still require
   eventual boxes, so moving return publication alone adds no CSV allocation gain.

2. **R375: correct overlapping histogram bindings before further optimization.**
   Current-image R374 attribution found the already-fused raw-word dictionary loop.
   Independent CPython probes demonstrate that reusing its loop word as its total
   can wrongly complete instead of raising TypeError after one dictionary update.
   A parameterized dictionary/word collision also wrongly updates the old dictionary
   instead of raising AttributeError before any update; both APIs diverge from Python.
   Validate the dictionary/word overlap too, distinguishing static rejection from
   actual runtime divergence. Record all original probe outputs.
   Remove invalid fusion eligibility for overlapping dictionary/key/total locals;
   keep the ordinary executable loop and Python errors/effects. No new backend,
   option, resource policy or optimization claim. Add public effect/alias controls
   for both APIs, focused cancellation/ownership and actual11/10 regressions.
   Group full qualification with the next coherent delivery boundary; the current
   shared-slot qualification remains independent and its exact source is preserved.

3. **R374: select the next whole-script text redesign from current attribution.**
   Hypothesis: captured text remains materially slower than CPython; coherent
   dispatch, per-record collection or text-boundary work may still be removable.
   A missing call arena, scalar boxing alone or a particular speedup is not proved.
   One bounded current-image full-text capture (existing worker/catalog, 5s at
   199Hz after guest warmup) plus source mapping should identify an entire stage
   or explicitly decline a patch. Preserve unknown/ambiguous samples and wider
   CPU. Separate observed leaf cost from inferred removable work.

   Already present: direct function binding/final slots/deferred contexts;
   receiver-independent append/get/write/CSV methods; direct DictReader adoption,
   bulk UTF-8 delimiter runs and combined field admission; inline strings, owned
   UTF-8 windows, final split/case output and bulk ASCII casing. Do not claim to
   remove these again. R371's invoice profile was mixed, not proof of a missing
   complete frame. Do not replay slower call-arena/call-control or whole-cased
   buffer designs without a concrete changed design and control explanation.

   Before implementation, name the exact storage/work eliminated, affected
   captured-text and report/file scripts, displaced implementation to delete,
   compatibility tradeoffs and completion point. Acceptance: Unicode/context and
   expansion rules, Python protocols/scoping/order/aliases, real I/O suspension,
   cancellation, terminal refusal and funded cleanup. One usable before/after
   source pair with unchanged controls, compile/warm/fresh boundaries and separate
   allocation/CPU. Justified bounded refinement is allowed. Stop this attribution
   gate after one usable source map and decision; no profiling campaign or new
   framework. A closed gate without a justified patch is a finding, not evidence
   that no substantial redesign is possible. Continue the broader roadmap.

4. **Resolve release tradeoffs explicitly, without micro-optimization churn.**
   R373 observed-helper and possible fulfillment fresh regressions are accepted
   above. Earlier R359/R361/R365/R368 short-helper debt, R362 materialization/text
   uncertainty and R370 invoice regression retain their original failed conditions.
   Correct, accept with a concrete benefit/tradeoff, or withdraw before release;
   a later cross-collection result does not erase source-pair evidence.
   CSV bulk construction already adopts final rows/shared keys; historical 6–8%
   observations missed rigid thresholds, not semantics. R355 raw ranges added
   scratch/state for little benefit. A revised design needs a real remaining stage
   and malformed-record timing, headers, aliases, wide-row and admission checks.
   Frontend shared facts are delivered; fulfillment compiles in ~0.130ms versus
   ~8ms execution. Select a costly fresh-script shape before another frontend/JIT
   redesign. Startup, contention, pending-I/O latency, RSS/heap peaks and embedding
   tails remain unmeasured. Do not infer them from allocation or full-GC counts.

5. **Keep Lython-owned regex development independent of producer publication.**
   The core owns Python semantics, native UTF-8/original-subject windows,
   byte/scalar coordinates, captures/errors, explicit owners and current tokens.
   Development producers and adapter-local bridges are allowed outside core;
   distinguish contract controls, backend semantics/interruption and performance.
   The optional nonpackable adapter stays pinned at 0.4; dev80 qualification is
   cached. [Committed source assessment through d1822732](benchmarks/results/2026-11-14-regex-provider-capabilities/source-update-d1822732.json)
   leaves three final-adapter gaps: separate one-match scratch/escaping-result
   owners, native UTF-8 group-name enumeration/copy, and token-independent cursor
   creation with cancellable preparation. Entry APIs are unchanged; do not repeat
   qualification or promote a pin from source inspection. These gaps defer only
   affected final released-adapter qualification, never Lython development.

## Evidence policy and lasting constraints

Timeouts, unstable unchanged controls and inconclusive results establish
uncertainty, not a failed design. Allow bounded confirmation/refinement or
measurement correction when justified; retain originals and every adverse point.
No one-attempt/no-retiming/permanent-closure rule. Percentages inform decisions,
not automatic vetoes. Architectural simplification, allocation and demonstrated
CPU improvements are independent; temporary regression needs an explicit final
completion/debt decision. Keep the complete-script goal active.

Use focused Release checks during iteration; batch full platforms/frameworks,
original stress and installed consumers at coherent retained boundaries. Freeze
copies, force rebuilds after restores, prove full source/worker/adapter identity.
Keep persistent verified evidence under the VM lease before RAM teardown;
preserve 254/252MiB floors. Deduplicate only exact archived copies with committed
custody and fresh path/UID/link/hash proof. No VM collection is currently active.

[AGENTS](AGENTS.md) remains binding: fully managed/memory-safe, no unsafe/Unsafe,
pointers/PInvoke/native probing; managed stack safety, host mediation, checked
bounds and bounded I/O. Tokens control time; no fuel, quotas or hidden caps.
Borrowed shared allowance funds major capacity, overlap, aliases/results/caches
and pending users through awaited cleanup. First refused admission is terminal;
no retry, tracing, weak reclamation, forced GC or abandoned work. Long streams use
bounded host commands. Only core is packaged; adapter remains nonpackable.
Publication/tagging remain postponed.
