from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
proof={'commit': 'b4e98b91062034f89b6a4c8823a1e8c1c6f47bb0', 'canonicalArchive': 'benchmarks/results/2026-11-15-shared-executable-slots/phase-one-sources-and-checks.tar.xz', 'canonicalArchiveSHA256': '2b47b282c2dbee5e43ddd32fcb138f6706bdacf340fdeb7a9ef568db4a0d6abf', 'member': 'candidate-core.dll', 'bytes': 5748736, 'sha256': '5db7e4f2615947ecd9f021f68ab9a9efc1cc9f3a09f5b39cb43cc4032ede4026', 'paths': ['shared-slots-b762-20261115/candidate-core.dll', 'shared-slots-b762-20261115/candidate/Lokad.Lython.dll'], 'expectedLinks': 2, 'plannedUnpackedBytes': 5768297}
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(p.is_mount() for p in base.glob('*/guest-fixtures'))
 paths=[base/n for n in proof['paths']]
 metadata=[p.lstat() for p in paths]
 observations=[dict(path=str(p),inode=s.st_ino,links=s.st_nlink,uid=s.st_uid,bytes=s.st_size) for p,s in zip(paths,metadata)]
 print(json.dumps(dict(preflight=observations)),flush=True)
 assert all(p.resolve()==p and p.is_relative_to(base) and stat.S_ISREG(s.st_mode) and s.st_uid==os.getuid() and s.st_nlink==proof['expectedLinks'] and s.st_size==proof['bytes'] for p,s in zip(paths,metadata))
 assert len({(s.st_dev,s.st_ino) for s in metadata})==1
 assert all(hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256'] for p in paths)
 before=shutil.disk_usage(base).free
 assert before+proof['bytes']>254*1024*1024+proof['plannedUnpackedBytes']+32768
 for p in paths:p.unlink()
 receipt=dict(proof=proof,allMetadataHashesVerifiedBeforeMutation=True,freshIdleLease=True,retiredOnly=[str(p) for p in paths],beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,current957bedAllCatalogsAuxiliariesAndToolchainsPreserved=True,floorsUnchanged=True)
 (base/'b766-proved-superseded-prototype-retirement.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt),flush=True)
