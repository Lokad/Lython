from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;q=r/'confirmation';out=Path('benchmarks/results/2026-11-16-line-construction/confirmation');out.mkdir()
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined']and receipt['quietBeforeAndAfter'];assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for n in ['identity.json','observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(q/n,out/n)
v=json.loads((r/'summary.json').read_text(encoding='utf-8'));assert v['complete']and v['quietBeforeAndAfter'];v.update(retentionDecisionPending=False,retained=True,fullQualificationPending=True,decision='Retain one shared final split constructor and bounded explicit-context splitlines scanner. Normalization allocation−1.73%; warm elapsed3.81–8.53%lower/CPU5.03–8.29%lower, fresh elapsed3.36–6.30%lower/CPU2.23–3.46%lower. Moving5%JSON reference/control adversity and original failed final quiet gate retained. No universal CPU or embedding-latency claim.');(out/'summary.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'procedures-and-source-proof.tar.xz','w:xz')as a:
 for p in q.iterdir():
  if p.is_file()and p.name not in ['observations.tgz','payload.tgz','representative.json']:a.add(p,arcname='confirmation/'+p.name)
 for n in ['confirm.py','summarize-confirmation.py','preserve-confirmation.py']:a.add(r/n,arcname='procedure/'+n)
 a.add(r.parent/'bulk-text-r429/refined/source-qualification/source-proof.json',arcname='baseline-source-proof.json')
(out/'README.md').write_text('''# Retained shared line construction: bounded confirmation

R430/B828,2026-11-16UTC; unchanged **ecd9e956 versus6cedc733 /efd82707**.
Same600 frozen source/build/test inputs, runtime images, catalogs, complete goldens
and focused checks as the [original B827](../README.md). No source refinement or
repeated correctness qualification. Baseline R429 and this change await one combined
full platform/stress/installed-package delivery; publication held.

All four jobs pass image/golden/budget/quiet/Closed/exit/join/archive gates in
**140.323s**, two processes/source,5s full-request warmup/five rotated approximately
0.5s rounds. The original failed final idle gate stays failed; this is an explicitly
separate bounded confirmation, not substitution of a later gate into the first run.

| Complete workload / phase | Elapsed candidate/reference | Wider CPU | Ref/candidate process-median spreads |
| --- | ---: | ---: | ---: |
| Normalization warm | −8.53..−3.81% | −8.29..−5.03% | 2.09/3.00% |
| Normalization compile-to-result | −6.30..−3.36% | −3.46..−2.23% | 0.92/2.20% |
| Method report warm | −0.48..+0.52% | −0.83..+1.13% | 0.82/0.19% |
| JSON warm control | −4.79..+0.37% | −4.63..+2.00% | 4.99/0.41% |

All four pairings, not confidence intervals. Normalization shows supporting CPU
evidence in both phases. JSON's unchanged reference moves4.99%; its favorable
pairings are not a source gain. Keep all controls/adverse CPU and original failure.
Separate source-pair medians cannot be added to prior gains.

**Retain** the shared final split constructor and bounded native line scanner:
remove incremental list growth, per-fragment admission and per-scalar decoding;
explicit current context fixes the old no-break cancellation gap. Existing range
loans stay charged. No new cache/ownership/dispatch framework. Python's full line
set, CRLF/keepends/trailing semantics, chunk boundaries, truth callbacks, owners,
terminal refusal and rollback are preserved. Whole unchanged same-owner input can
be reused; conservative range capacity/overlap may deny earlier and exact final
capacity may admit earlier. No tiny-budget threshold compatibility promise.

Original local allocation: normalization−1.73%, accounting peak effectively flat;
report/invoice flat, JSON immaterial. No repeated allocation measurement for unchanged
images.487internal/1,656public and4related original-scale stress cases pass each
actual.NET11/10;44CPython goldens agree. Cancellation entry/context coverage and
joined construction stress do not establish a measured scan-interruption latency.
Scan/copy chunks check the active token; CLR allocations/copies are not preemptible.

Same Azure F4as_v7/Ubuntu24.04.4,four EPYC9V45vCPUs,16GiB/no swap,.NET11RC3
ordinary tiering/natural workstation GC. Warm includes mediated RAM I/O, full
stdout/file goldens and prior-result cleanup; excludes compilation/startup,
reset/protocol and final cache teardown. Fresh adds compilation/compiled-owner
disposal; wider CPU includes reset/protocol. No heap/RSS, pending-I/O, contention
or embedding-tail claim; accounting peaks describe estimates.

Persistent archive verified under lease before unmount; all users joined, no RAM
fixture remains. Only exact committed copies of B827 working evidence retired;
both current images/catalogs/toolchains and254/252MiB floors preserved. Terminal
cached. Broader performance work remains open; next source gate must displace a
complete representation, not repeat already-delivered builtin/JSON construction.

[All controls](summary.json),[raw observations](observations.tgz),
[procedure/baseline source proof](procedures-and-source-proof.tar.xz),
[original source/images/checks/allocation](../README.md).
''',encoding='utf-8',newline='\n')
p=out.parent/'README.md';s=p.read_text(encoding='utf-8');s+='\n\n[One bounded unchanged-source/image confirmation passes all gates; implementation retained](confirmation/README.md). Normalization warm3.8–8.5%lower/fresh3.4–6.3%lower with CPU support; original failed gate and moving JSON control remain. Full runtime delivery pending.\n';p.write_text(s,encoding='utf-8',newline='\n')
p=Path('docs/RUNTIME.md');s=p.read_text(encoding='utf-8');needle='Unicode indexing caches use the active caller\'s cancellation context';idx=s.index(needle);s=s[:idx]+'''Line splitting and ordinary text split share range-based final construction. A
bounded UTF-8 scan identifies Python line breaks, including CRLF and Unicode
separators, using the active execution context. Final list capacity and independent
fragments are admitted together before allocation. A whole unchanged same-owner
input can remain an alias. Existing range-loan capacity stays funded when cached;
working overlap and conservative capacity can cause earlier rejection.

'''+s[idx:];p.write_text(s,encoding='utf-8',newline='\n')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8');needle='| --- | --- | ---: | --- |';assert s.count(needle)==1;s=s.replace(needle,needle+'\n| Shared line construction / complete normalization | Warm elapsed3.8–8.5%lower; fresh3.4–6.3%lower, supporting CPU | −1.73% | Retainedecd9e956/efd82707; accounted peak effectively flat. Original failed idle gate and moving JSON control retained. [Confirmation/limits](../benchmarks/results/2026-11-16-line-construction/confirmation/README.md); full delivery pending. |',1);p.write_text(s,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n\n[R430/B828 unchanged-image line-construction confirmation retained](results/2026-11-16-line-construction/confirmation/README.md):ecd9e956/efd82707, four jobs140.323s/all gates. Normalization warm elapsed3.81–8.53%lower/CPU5.03–8.29%lower; fresh elapsed3.36–6.30%lower/CPU2.23–3.46%lower. Original failed final idle gate and4.99%moving JSON reference/adverse CPU retained; no universal gain. Shared final construction and bounded explicit-context scanner retained; full600input delivery next.\n';s+='\n\nR431 bounded source gate at1fe2a174: plain builtin wrappers/signatures already live in SharedFunctions; mutable types remain per run. Default JSON already has one iterative inline/heap-frame constructor, native number/literal/string paths, shared record-key prefixes and one final value-capacity growth. No duplicate row/value or unconditional async-token pipeline identified. A document-wide admission prepass would introduce new machinery rather than remove an existing duplicate; not selected without changed dominant-cost evidence. Complete call/frame/operand displacement remains unresolved; R403/R411 regressions and useful-work overlap in R420 remain. No runtime prototype or speedup claim for this gate.\n';p.write_text(s,encoding='utf-8',newline='\n')
print('R430 retained after bounded unchanged-image confirmation; originals/debt preserved, new full delivery pending.')
