from pathlib import Path
import ast,datetime,hashlib,json,shlex,subprocess,tarfile
r=Path(__file__).parent;old=r/'quiet';q=r/'confirmation';q.mkdir();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();identity=json.loads((old/'identity.json').read_text(encoding='utf-8'));identity.update(purpose='One bounded unchanged-source/image confirmation after originalB827 final quiet gate failed. Original adverse condition and all controls retained; no runtime change/repeated correctness qualification.',confirmationOf='B827',originalFinalQuietGatePassed=False)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
root='/home/lokad/lython-bench-checks/line-confirm-b828-20261116';unit='lython-b828-line-confirm-20261116'
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('line-construction-b827-20261116','line-confirm-b828-20261116').replace('lython-b827-line-construction-20261116',unit).replace('B827','B828')
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
(q/'representative.json').write_bytes((old/'representative.json').read_bytes())
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in ['identity.json','collect.py','archive-owned.py','run.sh']:a.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz')as a:size=sum(m.size for m in a if m.isfile())
archive='benchmarks/results/2026-11-16-line-construction/observations.tgz';raw=Path(archive).read_bytes();assert subprocess.check_output(['git','show',head+':'+archive])==raw;groups=[]
for member in ['confirmation/confirmation.json',None]:
 if member:
  with tarfile.open(archive)as a:body=a.extractfile(member).read()
 else:body=raw
 groups.append(dict(sha256=hashlib.sha256(body).hexdigest(),bytes=len(body),links=1,paths=['line-construction-b827-20261116/'+(member or'observations.tgz')],custody=dict(commit=head,archive=archive,archiveSHA256=hashlib.sha256(raw).hexdigest(),member=member)))
c=dict(root=root,unit=unit,source='/home/lokad/lython-bench-checks/line-construction-b827-20261116',sourceFiles=identity['imageFiles']['candidate'],sourceCatalogSHA256=hashlib.sha256((old/'representative.json').read_bytes()).hexdigest(),catalogSHA256=hashlib.sha256((q/'representative.json').read_bytes()).hexdigest(),identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=size)
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');tree=ast.parse(s);node=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='c'for t in n.targets));lines=s.splitlines(keepends=True);s=''.join(lines[:node.lineno-1])+'c='+repr(c)+'\n'+''.join(lines[node.end_lineno:]);s=s.replace('lython-b827-fixtures','lython-b828-fixtures').replace("os.link(source/'candidate'/n,p)","os.link(source/role/n,p)")
needle=" assert sha(source/'representative.json')==c['sourceCatalogSHA256']";assert needle in s;s=s.replace(needle,needle+"\n for role in ['reference','candidate']:\n  for n,h in c['identity']['imageFiles'][role].items():assert sha(source/role/n)==h\n original=json.loads((source/'archive-receipt.json').read_text());assert not original['complete']and original['workloadJobsComplete']and original['allWorkersJoined']and original['guestFixturesRemoved']")
ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -c '+shlex.quote(s)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=200)).isoformat(),ownerSeconds=240),indent=2)+'\n',encoding='utf-8',newline='\n');print(p.stdout.decode('utf-8'),flush=True)
