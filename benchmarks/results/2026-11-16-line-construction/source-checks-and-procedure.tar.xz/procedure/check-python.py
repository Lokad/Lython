from pathlib import Path
import json,sys
cases=[]
for keep in [False,True]:
 for length in [4094,4095]:
  for sep in ['\r\n','\r','\n','\v','\f','\x1c','\x1d','\x1e','\x85','\u2028','\u2029']:
   prefix='a'*length;content='é\u00a0\u2027😀\x1f';source=prefix+sep+content+sep+sep;ending=sep if keep else'';assert source.splitlines(keep)==[prefix+ending,content+ending,ending]
   cases.append(dict(keepEnds=keep,prefix=length,separator=ascii(sep),agrees=True))
Path(__file__).with_name('cpython-semantics.json').write_text(json.dumps(dict(reference=sys.version,cases=cases),indent=2)+'\n',encoding='utf-8',newline='\n');print('44 chunk/Unicode/keepends goldens match CPython.')
