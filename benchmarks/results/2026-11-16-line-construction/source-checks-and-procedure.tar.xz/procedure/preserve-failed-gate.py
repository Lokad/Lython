from pathlib import Path
import json,subprocess,tarfile,hashlib
r=Path(__file__).parent;q=r/'quiet';c=json.loads((q/'config.json').read_text(encoding='utf-8'))
original=json.loads(sorted(q.glob('observation-*.json'))[-1].read_text(encoding='utf-8'));assert original['exitCode']=='1'and not original['remainingWorkers']and original['remainingTrace']
(q/'terminal-status.json').write_text(json.dumps(original,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,tarfile
c=CONFIG
r=Path(c['root'])
with(r.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert(r/'exit-code.txt').read_text().strip()=='1'and os.path.ismount(r/'guest-fixtures')
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not list((r/'guest-fixtures').iterdir())
 raw=json.loads((r/'confirmation/confirmation.json').read_text());assert not raw['complete']and len(raw['jobs'])==4 and all(j['workersJoinedAndFixturesRemoved']and len(j['samples'])==20 for j in raw['jobs'])
 before=json.loads((r/'confirmation/machine-before.json').read_text());after=json.loads((r/'confirmation/machine-after.json').read_text());assert before['gate']['quiet']and not after['gate']['quiet']
 for role in ['reference','candidate']:
  for n,h in c['identity']['imageFiles'][role].items():assert hashlib.sha256((r/role/n).read_bytes()).hexdigest()==h
 journal=subprocess.check_output(['journalctl','-u',c['unit']+'.service','--no-pager'],text=True);(r/'original-service-journal.txt').write_text(journal)
 files=[p for p in r.rglob('*')if p.is_file()and p.name!='observations.tgz'and not {'candidate','reference'}&set(p.relative_to(r).parts)]
 hashes={p.relative_to(r).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in files}
 with tarfile.open(r/'observations.tgz','w:gz',dereference=True)as a:
  for p in files:a.add(p,arcname=p.relative_to(r).as_posix())
 with tarfile.open(r/'observations.tgz')as a:
  for n,h in hashes.items():assert hashlib.sha256(a.extractfile(n).read()).hexdigest()==h
 assert shutil.disk_usage(r).free>252*1024*1024
 subprocess.run(['sudo','-n','umount',str(r/'guest-fixtures')],check=True);(r/'guest-fixtures').rmdir()
 receipt=dict(complete=False,workloadJobsComplete=True,jobs=4,elapsedSeconds=raw['elapsedSeconds'],allWorkersJoined=True,guestFixturesRemoved=True,quietBeforeAndAfter=False,quietBefore=True,quietAfter=False,originalServiceExitCode=1,archivedAndVerifiedUnderLease=True,archiveSHA256=hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest(),freeBytesAfterArchive=shutil.disk_usage(r).free,performanceQualified=False)
 (r/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(dict(receipt=receipt,failedGate=after['gate'])))
'''.replace('CONFIG',repr(c))
(q/'failed-gate-archive-command.py').write_text(code,encoding='utf-8',newline='\n');ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);(q/'failed-gate-archive.log').write_text(p.stdout+p.stderr,encoding='utf-8',newline='\n');assert p.returncode==0,p.stdout+p.stderr;print(p.stdout)
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['archive-receipt.json','observations.tgz']:
 p=subprocess.run(scp+['lokad@20.166.121.73:'+c['root']+'/'+name,str(q/name)],capture_output=True);assert p.returncode==0,p.stderr
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(q/'observations.tgz')as a:a.extractall(q/'retrieved',filter='data')
s=(r.parent/'bulk-text-r429/summarize.py').read_text(encoding='utf-8').replace("assert raw['complete']and len(raw['jobs'])==4","assert not raw['complete']and len(raw['jobs'])==4").replace('complete=True,elapsedSeconds=', 'complete=False,elapsedSeconds=').replace('quietBeforeAndAfter=True','quietBeforeAndAfter=False')
(r/'summarize-failed-gate.py').write_text(s,encoding='utf-8',newline='\n')
