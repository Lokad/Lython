from pathlib import Path
import ast,datetime,hashlib,json,shlex,subprocess,tarfile
r=Path(__file__).parent;base=r.parent/'bulk-text-r429/refined';old=base/'quiet';q=r/'quiet';q.mkdir();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();proof=json.loads((base/'source-qualification/source-proof.json').read_text(encoding='utf-8'));assert proof['commit']==head and proof['inputCount']==598 and proof['allInputsMatchAfterExplicitUTF8NewlineNormalization']
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));keys=set(json.loads((old/'identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate']);images={role:{n:h for n,h in files.items()if n in keys}for role,files in f['images'].items()}
root='/home/lokad/lython-bench-checks/line-construction-b827-20261116';unit='lython-b827-line-construction-20261116'
identity=dict(sourceRevision='R430 uncommitted'+images['candidate']['Lokad.Lython.dll'][:8]+' versus committed6cedc733/frozenefd82707',purpose='Splitlines shares existing range/final-list-fragment construction and explicit context through bounded UTF8 line-break search; remove duplicate per-scalar/per-fragment/growing list pipeline. Complete normalization warm/fresh, report/JSON controls; no new cache/ownership infrastructure.',coreSHA256={label:images['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['candidate','candidate-control','reference','reference-control']},imageFiles=images,prototype=True,publicationHeld=True,referenceFullQualificationPendingAtStaging=True,referenceQualification='145internal/412public actual11/10/598committed inputs; full qualification batched with this milestone. Earlier810full43800910729GREEN.',candidateSourceIdentitySHA256=hashlib.sha256((r/'frozen/identity.json').read_bytes()).hexdigest())
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('bulk-text-b826-20261116','line-construction-b827-20261116').replace('lython-b826-bulk-text-20261116',unit).replace('B826','B827')
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
(q/'representative.json').write_bytes((old/'representative.json').read_bytes())
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in ['identity.json','collect.py','archive-owned.py','run.sh']:a.add(q/n,arcname=n)
 a.add(r/'frozen/candidate/Lokad.Lython.dll',arcname='candidate/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz')as a:size=sum(m.size for m in a if m.isfile())
v=json.loads((r/'historical-aliases.json').read_text(encoding='utf-8'));archive='benchmarks/results/2026-11-16-bulk-text-construction/refined/source-checks-and-procedure.tar.xz';raw=Path(archive).read_bytes();assert subprocess.check_output(['git','show',head+':'+archive])==raw
with tarfile.open(archive)as a:core=a.extractfile('frozen/reference/Lokad.Lython.dll').read()
assert hashlib.sha256(core).hexdigest()==v['sha256']and len(core)==v['bytes'];v['custody']=dict(commit=head,archive=archive,archiveSHA256=hashlib.sha256(raw).hexdigest(),member='frozen/reference/Lokad.Lython.dll');groups=[v]
for directory,canonical,member in [('bulk-text-b826-20261116','2026-11-16-bulk-text-construction/refined','confirmation/confirmation.json'),('bulk-text-b826-20261116','2026-11-16-bulk-text-construction/refined',None),('bulk-text-b825-20261116','2026-11-16-bulk-text-construction',None),('normalization-profile-b824-20261116','2026-11-16-normalization-attribution',None)]:
 path='benchmarks/results/'+canonical+'/observations.tgz';raw=Path(path).read_bytes();assert subprocess.check_output(['git','show',head+':'+path])==raw
 if member:
  with tarfile.open(path)as a:body=a.extractfile(member).read()
 else:body=raw
 groups.append(dict(sha256=hashlib.sha256(body).hexdigest(),bytes=len(body),links=1,paths=[directory+'/'+(member or'observations.tgz')],custody=dict(commit=head,archive=path,archiveSHA256=hashlib.sha256(raw).hexdigest(),member=member)))
c=dict(root=root,unit=unit,source='/home/lokad/lython-bench-checks/bulk-text-b826-20261116',sourceFiles=images['reference'],sourceCatalogSHA256=hashlib.sha256((old/'representative.json').read_bytes()).hexdigest(),catalogSHA256=hashlib.sha256((q/'representative.json').read_bytes()).hexdigest(),identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=size)
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');tree=ast.parse(s);node=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='c'for t in n.targets));lines=s.splitlines(keepends=True);s=''.join(lines[:node.lineno-1])+'c='+repr(c)+'\n'+''.join(lines[node.end_lineno:]);s=s.replace('lython-b826-fixtures','lython-b827-fixtures');ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -c '+shlex.quote(s)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=200)).isoformat(),ownerSeconds=240),indent=2)+'\n',encoding='utf-8',newline='\n');print(p.stdout.decode('utf-8'),flush=True)
