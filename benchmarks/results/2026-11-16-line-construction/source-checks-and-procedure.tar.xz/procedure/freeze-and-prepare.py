from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
r=Path(__file__).parent;base=r.parent/'bulk-text-r429/refined';f=r/'frozen';f.mkdir();v=json.loads((base/'frozen/identity.json').read_text(encoding='utf-8'));images={}
for role in ['reference','candidate']:
 target=f/role;shutil.copytree(base/'frozen/candidate',target)
 if role=='candidate':shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',target/'Lokad.Lython.dll')
 images[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in target.iterdir()if p.is_file()}
assert images['reference']['Lokad.Lython.dll']=='efd8270751e008587042c729869e214f000f1730a4e05683ae6ed4c6351f62db'
assert all(images['candidate'][n]==h for n,h in images['reference'].items()if n!='Lokad.Lython.dll')
paths=list(v['sources'])+['tests/Lokad.Lython.Tests/LineSplitConstructionTests.cs','tests/Lokad.Lython.Tests/NativeTextConstructionRollbackTests.cs'];assert len(set(paths))==600
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz')as a:
 for n in paths:a.add(n,arcname=n)
 a.add(r/'checks',arcname='checks')
v.update(buildSourceCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),prototype=True,images=images,sources={n:hashlib.sha256(Path(n).read_bytes()).hexdigest()for n in paths},contracts='Splitlines uses bounded UTF8 search with explicit current context and existing range/final-list-fragment construction. Remove scalar scan/geometric list/per-line admission. Preserve Python Unicode breaks/CRLF/keepends/trailing rules, funding, cancellation/refusal and retained ownership. Existing range cache remains charged; no new cache/ownership framework.')
(f/'identity.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};checks=[dict(file=p.name,**E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib)for p in(r/'checks').glob('*.trx')]
assert sorted(int(x['passed'])for x in checks)==[4,4,487,487,1656,1656]and all(x['failed']=='0'for x in checks)
(r/'focused-checks.json').write_text(json.dumps(dict(checks=checks,productionNonincrementalReleaseBuild=True,testOnlyFinalBuildNoDependencies=True,fullQualificationPending=True,originalStressScalesPreserved=True),indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(base/'catalog.json',r/'catalog.json');d=r/'allocation-short';d.mkdir()
for n in ['Program.cs','Allocation.csproj']:shutil.copyfile(base/'allocation-short'/n,d/n)
shutil.copytree(base/'allocation-short/bin',d/'bin');shutil.copyfile(r/'catalog.json',d/'catalog.json');shutil.copyfile(base/'measure-allocation.py',r/'measure-allocation.py')
s=(base/'inspect-vm.py').read_text(encoding='utf-8').replace('bulk-text-b825-20261116/candidate','consume-text-b822-20261116/candidate').replace('5ebd657a11ecd0ddea14f82879c78c033f525cff502479eb51b7fb6da8a1322b','810dafdd2afb684158374098c5b16e850369b7a6ebe2a56e451f3bd96f741d46');(r/'inspect-vm.py').write_text(s,encoding='utf-8',newline='\n')
print('Frozen600 inputs', {n:v['Lokad.Lython.dll']for n,v in images.items()},'complete four-workload allocation ready.')
