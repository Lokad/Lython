from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent;q=r/'quiet';c=json.loads((q/'config.json').read_text(encoding='utf-8'))
code=r'''from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess,tarfile
c=CONFIG
r=Path(c['root'])
with(r.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(r/'guest-fixtures').exists()and(r/'exit-code.txt').read_text().strip()=='1'
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 raw=json.loads((r/'confirmation/confirmation.json').read_text());assert not raw['complete']and len(raw['jobs'])==4 and all(j['workersJoinedAndFixturesRemoved']and len(j['samples'])==20 for j in raw['jobs'])
 with tarfile.open(r/'observations.tgz')as a:
  for m in a.getmembers():
   if m.isfile():assert hashlib.sha256(a.extractfile(m).read()).digest()==hashlib.sha256((r/m.name).read_bytes()).digest()
 before=json.loads((r/'confirmation/machine-before.json').read_text());after=json.loads((r/'confirmation/machine-after.json').read_text());assert before['gate']['quiet']and not after['gate']['quiet']
 assert shutil.disk_usage(r).free>252*1024*1024
 receipt=dict(complete=False,workloadJobsComplete=True,jobs=4,elapsedSeconds=None,allWorkersJoined=True,guestFixturesRemoved=True,quietBeforeAndAfter=False,quietBefore=True,quietAfter=False,originalServiceExitCode=1,archivedAndVerifiedUnderLease=True,archiveSHA256=hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest(),freeBytesAfterArchive=shutil.disk_usage(r).free,performanceQualified=False,missingElapsedSecondsPreserved=True,archivalReceiptCorrection='Original archive verified under lease and fixtures unmounted; receipt construction referenced absent elapsedSeconds after failed gate. Fresh lease verifies every archived byte against persistent working files; no reexecution.')
 (r/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(dict(receipt=receipt,failedGate=after['gate'])))
'''.replace('CONFIG',repr(c))
(q/'receipt-correction-command.py').write_text(code,encoding='utf-8',newline='\n');ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=45);(q/'receipt-correction.log').write_text(p.stdout+p.stderr,encoding='utf-8',newline='\n');assert p.returncode==0,p.stdout+p.stderr;print(p.stdout)
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for n in ['archive-receipt.json','observations.tgz']:
 p=subprocess.run(scp+['lokad@20.166.121.73:'+c['root']+'/'+n,str(q/n)],capture_output=True);assert p.returncode==0,p.stderr
v=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==v['archiveSHA256']
with tarfile.open(q/'observations.tgz')as a:a.extractall(q/'retrieved',filter='data')
s=(r.parent/'bulk-text-r429/summarize.py').read_text(encoding='utf-8').replace("assert raw['complete']and len(raw['jobs'])==4","assert not raw['complete']and len(raw['jobs'])==4").replace('complete=True,elapsedSeconds=', 'complete=False,elapsedSeconds=').replace("raw['elapsedSeconds']","raw.get('elapsedSeconds')").replace('quietBeforeAndAfter=True','quietBeforeAndAfter=False')
(r/'summarize-failed-gate.py').write_text(s,encoding='utf-8',newline='\n')
