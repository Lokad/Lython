from pathlib import Path
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('| Active uncommitted prototype |');b=s.index('\n| Latest external baseline |',a)
s=s[:a]+'''| Committed; next full checkpoint pending | **R429 /6cedc733 /efd82707**, direct final bulk-text construction. [Retained refinement](benchmarks/results/2026-11-16-bulk-text-construction/refined/README.md):145internal/412public eachactual11/10;598committed inputs verified. Normalization allocation−11.46%/accounted peak−3.50%; fresh modestly lower with CPU support, warm uncertain. Original5–7%warm regression not proven recovered; report/JSON adversity accepted debt. |
| Active uncommitted prototype | **R430 /ecd9e956** line construction and cancellation.487internal/1,656public plus4related stress cases eachactual11/10;600inputs frozen. Normalization allocation−1.73%, controls essentially flat; B827warm/fresh pair active. No retention or CPU claim yet. |'''+s[b:]
a=s.index('## Immediate delivery');b=s.index('## Substantial redesign roadmap',a)
s=s[:a]+'''## Immediate delivery

1. **R430 line construction/cancellation — finish the bounded decision.**
   Replace splitlines' scalar decoder, geometric PyList and per-fragment admission
   with existing range/final-list-fragment construction; explicit active context,
   bounded native UTF8 line-break search and one final aggregate output admission.
   Ordinary split now shares that same final constructor. No new cache, tracing,
   output/window ownership protocol, dispatch framework or public option.

   Preserve all Python line breaks, CRLF/keepends/trailing rules, Unicode chunk
   boundaries, custom truth callbacks, independent fragment owners, cancellation,
   terminal refusal and rollback. Existing range loans remain charged when cached;
   range/construction peaks can reject earlier, exact final output can admit earlier.
   Whole unchanged same-owner input may remain an alias. No tiny-threshold promise.
   The old no-break scan had no internal cancellation check: demonstrated source
   gap. New context/entry test and joined construction stress are distinct from
   a measured interruption-latency bound; current scan checks each bounded chunk.

   Nonincremental Release;487internal/1,656public and4related original-scale stress
   cases eachactual11/10 pass.44CPython Unicode/chunk/keepends goldens agree.
   600inputs frozen. Complete normalization allocation−1.73%; report/CSV flat,
   JSON effectively flat; shared accounting returns to baseline/zero. Accounted
   peaks are not heap/RSS. B827four jobs warm/fresh normalization/report/JSON active;
   preserve all timings/controls. Stop at retain/refine/remove with debt explicit.

2. **Batch retained runtime delivery after that decision.** R429committed6cedc733,
   598source inputs agree. Original5eb/B825adverse result and refinedefd/B826 mixed
   result are immutable; no repeat of unchanged qualification or timings. If R430
   is retained, commit it and qualify R429+R430 together: Windows/Ubuntu actual11/10,
   original stress plus the added line case and installed Release package consumers.
   R426GREEN43800910729/597inputs is complete and terminal-cached; never requery.
   Publication/tagging stays held. Do not infer unqualified HEAD from older receipts.

3. **Continue the substantial roadmap.** Another bulk-text experiment does not
   finish the performance objective. Return to a complete call/frame/operand or
   per-record construction displacement from source-backed evidence. Existing
   R420call groups contain useful work; rejected call controller/arena/tail loans
   remain slower evidence. Inspect current whole-script JSON collection construction
   and complete frame lifetime before selecting a redesign: identify an entire
   duplicate representation/admission stage and its owner, or close that bounded
   gate as unresolved. No credit cache, per-object ledger or speculative fast path.
   Profile only the material ambiguity needed to choose a coherent replacement;
   compare affected complete scripts with unchanged controls. Regex development
   continues independently; missing producer APIs defer only final adapter checks.

'''+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
print('Active deliverables condensed; completed receipts and experimental debt remain linked.')
