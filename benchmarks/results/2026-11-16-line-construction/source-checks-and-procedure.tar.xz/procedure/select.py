from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;o=r/'original';o.mkdir()
paths=['src/Lokad.Lython/Runtime/Text/PyStringOps.cs','src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs','src/Lokad.Lython/Runtime/LythonRuntime.StringMembers.Segmentation.cs']
for n in paths:
 p=o/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(n,p)
(r/'selection.json').write_text(json.dumps(dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),baselineCoreSHA256='efd8270751e008587042c729869e214f000f1730a4e05683ae6ed4c6351f62db',sources={n:hashlib.sha256(Path(n).read_bytes()).hexdigest()for n in paths},hypothesis='Replace duplicate incremental splitlines with existing range/final-list-fragment construction and bounded native UTF8 line-break search. Remove per-scalar decoding/per-fragment admission/geometric list backing; fix no-break scan missing cancellation. Reuse current range loans and exact final storage, no new cache/tracing/window ownership framework. Output may be admitted earlier or denied earlier from conservative range capacity; retained ranges remain charged.'),indent=2)+'\n',encoding='utf-8',newline='\n')
