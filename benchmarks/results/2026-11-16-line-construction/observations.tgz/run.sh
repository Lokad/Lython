set -eu
root=/home/lokad/lython-bench-checks/line-construction-b827-20261116
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
