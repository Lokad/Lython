from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;initial=r.parent
prior=json.loads((initial/'identity.json').read_text(encoding='utf8'))
inventory={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in prior['productionSources']}
changed={p for p,h in inventory.items()if h!=prior['productionSources'][p]}
assert changed=={'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Operations.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs'},changed
assert len({hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in ['src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll','tests/Lokad.Lython.Tests/bin/Release/net11.0/Lokad.Lython.dll','tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0/Lokad.Lython.dll']})==1
images=r/'images';images.mkdir()
for role in ['before','candidate']:shutil.copytree(initial/'images/before',images/role,copy_function=os.link)
p=images/'candidate/Lokad.Lython.dll';p.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',p)
cores={role:hashlib.sha256((images/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']}
assert cores['before']==prior['coreSHA256']['before']and cores['candidate']not in prior['coreSHA256'].values()
identity={**prior,'candidateSource':'dee0ef1b plus four-file native return-tree proof; ordinary list factory unchanged, cold native empty-storage borrow','coreSHA256':cores,'productionSources':inventory,'qualification':'205public/42internal focused Release peractual11/10 pass after construction refinement; new-source full delivery pending.'}
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
shutil.copyfile(initial/'catalog.json',r/'catalog.json');shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--',*json.loads((initial/'baseline.json').read_text(encoding='utf8'))['sourceSHA256']]))
s=(initial/'measure.py').read_text(encoding='utf8').replace("r.parent/'integer-utf8-r45/tool/out/complete-jobs.dll'","r.parents[1]/'integer-utf8-r45/tool/out/complete-jobs.dll'").replace("[('warm','sync'),('warm','async'),('compile','sync'),('fresh','sync')]","[('warm','sync'),('warm','async')]")
(r/'measure.py').write_text(s,encoding='utf8')
s=(initial/'assess-local.py').read_text(encoding='utf8').replace("['warm-sync','warm-async','compile-five-sync','fresh-five-sync','compile-confirmation-normal']","['warm-sync','warm-async']")
a=s.index("out['limitations']=");z=s.index("\n(r/'assessment-local",a)
s=s[:a]+"out['limitations']='Refined R106 warm allocation diagnostic, normal GC/tiering and shared ALCs. Elapsed is Run only; allocation includes fixture reset/full validation/result cleanup. Desktop elapsed is not controlled CPU evidence. No repeated frontend measurement: compiler source unchanged from initial67e; original compiler uncertainty retained separately. Original67e observations and all adverse conditions preserved.'"+s[z:]
(r/'assess-local.py').write_text(s,encoding='utf8')
print('Refined R106 frozen',json.dumps(cores),flush=True)

