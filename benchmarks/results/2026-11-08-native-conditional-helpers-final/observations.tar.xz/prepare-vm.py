from pathlib import Path
import ast,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'b464';b=r/'b465';b.mkdir()
source=json.loads((r/'identity.json').read_text(encoding='utf8'));prior=json.loads((old/'identity.json').read_text(encoding='utf8'));jobs=prior['jobs']
identity={**prior,'sourceRevision':source['candidateSource'],'baselineSource':source['baselineSource'],'coreSHA256':{role:source['coreSHA256']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},'productionSources':source['productionSources'],'qualification':source['qualification']}
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
for name in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
 s=(old/name).read_text(encoding='utf8').replace('conditional-helpers-b464-20261108','refined-conditional-helpers-b465-20261108').replace('lython-b464-conditional-helpers','lython-b465-refined-conditional-helpers').replace('conditional-helpers-b464-launch.py','refined-conditional-helpers-b465-launch.py').replace('lython-b464-fixtures','lython-b465-fixtures')
 if name=='collect.py':
  a=s.index("purpose='");z=s.index("',\n",a);s=s[:a]+"purpose='R106 final bounded construction refinement: native return trees reuse unchanged ordinary list factory through cold empty operand storage; same six-job matrix versus qualifieda7"+s[z:]
 if name=='archive-owned.py':s=s.replace(",'space-maintenance.json'","")
 (b/name).write_text(s,encoding='utf8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
for src,name in [(r/'images/candidate/Lokad.Lython.dll','current-core.dll'),(r/'catalog.json','representative.json'),(r/'identity.json','focused.json'),(r/'source.patch','source.patch'),(r/'pre-measurement-plan.md','pre-measurement-plan.md'),(old/'shared-worker-common.json','shared-worker-common.json')]:shutil.copyfile(src,b/name)
(b/'setup-contract.json').write_text(json.dumps(dict(jobs=jobs,ownerSeconds=210,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=7,baselineCore=source['coreSHA256']['before'],candidateCore=source['coreSHA256']['candidate']),indent=2)+'\n',encoding='utf8')
contract="""One bounded final R106 source refinement, a7/aae versus1aa.
Keep initial67e/B464 all source/data/adverse controls separately immutable. Native
empty returns now reuse the established literal factory; general construction
source restored exactly. No separate admission implementation/general zero branch.
NoInlining confines empty operand storage to cold allocation helper, preserving
R71 wide-carrier lesson; no new state/carrier/cache/owner/pool/API.
205public/42internal peractual11/10 pass, real truth I/O/refusal/cancellation/retained
aliases/selected spans/cleanup. Same five warm allocation scripts/unchanged driver.
Compiler source unchanged from67e; no repeated local frontend campaign, original
Windows compiler uncertainty remains. No cause or speedup inferred from code.
Exactly same six-job B464 matrix: guarded sync/async, ordinaryrsplit, CSVcompile,
CSVwarm, JSONwarm. Both copies/core,5swarmup,7rotated150msrounds, normalGC/tiering.
210sowner+30stop+30margin, persistent raw/owned128MiBRAMonlyguestfixtures.
All source/core/aux/Ready/golden/quiet/Closed/join/unmount/archive/local gates.
Warm includes guest I/O/full validation/prior-result cleanup; compile includes
construction/disposal/no guest execution. Startup/staging/finalcached teardown
excluded, no genuine pending-I/O/startup/RSS/tail claim. Reuse archiveda7 baseline,
uploadonly1aa,240MiBOSfloor+7MiBevidence+actualpayload preflight. No new maintenance
or evidence deletion. Final retain/refine/reject debt explicit; no open-ended
retiming or universal gains. Publication/regex unchanged; no external CPython replay.
"""
(b/'contract.md').write_text(contract,encoding='utf8')
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for n in ['collect.py','run.sh','current-core.dll','representative.json','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','shared-worker-common.json','archive-owned.py']:a.add(b/n,arcname=n)
print('B465 same six-job matrix prepared, no maintenance, baselinea7 reused.')

