One bounded final R106 source refinement, a7/aae versus1aa.
Keep initial67e/B464 all source/data/adverse controls separately immutable. Native
empty returns now reuse the established literal factory; general construction
source restored exactly. No separate admission implementation/general zero branch.
NoInlining confines empty operand storage to cold allocation helper, preserving
R71 wide-carrier lesson; no new state/carrier/cache/owner/pool/API.
205public/42internal peractual11/10 pass, real truth I/O/refusal/cancellation/retained
aliases/selected spans/cleanup. Same five warm allocation scripts/unchanged driver.
Compiler source unchanged from67e; no repeated local frontend campaign, original
Windows compiler uncertainty remains. No cause or speedup inferred from code.
Exactly same six-job B464 matrix: guarded sync/async, ordinaryrsplit, CSVcompile,
CSVwarm, JSONwarm. Both copies/core,5swarmup,7rotated150msrounds, normalGC/tiering.
210sowner+30stop+30margin, persistent raw/owned128MiBRAMonlyguestfixtures.
All source/core/aux/Ready/golden/quiet/Closed/join/unmount/archive/local gates.
Warm includes guest I/O/full validation/prior-result cleanup; compile includes
construction/disposal/no guest execution. Startup/staging/finalcached teardown
excluded, no genuine pending-I/O/startup/RSS/tail claim. Reuse archiveda7 baseline,
uploadonly1aa,240MiBOSfloor+7MiBevidence+actualpayload preflight. No new maintenance
or evidence deletion. Final retain/refine/reject debt explicit; no open-ended
retiming or universal gains. Publication/regex unchanged; no external CPython replay.
