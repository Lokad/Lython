from pathlib import Path
import json,statistics
r=Path(__file__).parent;out={}
for phase in ['warm-sync','warm-async']:
 d=json.loads((r/phase/'measurements.json').read_text(encoding='utf8'))
 assert all(d[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
 rows=[]
 for o in d['observations']:
  field='executionMilliseconds'if phase.startswith('warm')else'elapsedMilliseconds'
  roles={role:dict(milliseconds=statistics.median(s[field]/s['jobs']for s in o['samples']if s['image']==role),allocation=statistics.median(s['allocatedBytes']/s['jobs']for s in o['samples']if s['image']==role))for role in ['before','before-control','candidate']}
  row=dict(case=o['caseId'],roles=roles,allocationPercent=[100*(roles['candidate']['allocation']/roles[b]['allocation']-1)for b in ['before','before-control']],elapsedPercent=[100*(roles['candidate']['milliseconds']/roles[b]['milliseconds']-1)for b in ['before','before-control']],oldSpreadPercent=100*(roles['before-control']['milliseconds']/roles['before']['milliseconds']-1))
  rows.append(row);print(phase,o['caseId'],'alloc%',*[round(v,3)for v in row['allocationPercent']],'elapsed%',*[round(v,3)for v in row['elapsedPercent']],'oldSpread',round(row['oldSpreadPercent'],3))
 out[phase]=rows
out['limitations']='Refined R106 warm allocation diagnostic, normal GC/tiering and shared ALCs. Elapsed is Run only; allocation includes fixture reset/full validation/result cleanup. Desktop elapsed is not controlled CPU evidence. No repeated frontend measurement: compiler source unchanged from initial67e; original compiler uncertainty retained separately. Original67e observations and all adverse conditions preserved.'
(r/'assessment-local.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
