One bounded R106 deletion refinement before final source commit.
Initial67e/B464 retains guarded text13–16%gain and observedCSVruntime+2.7–3.7%.
The shared empty-list extraction changed the general list-construction path.
Remove that general-path change: restore the existing literal factory and invoke
it with empty operand storage from a cold native helper. RetireTo(0) on default
storage returns before reading any fields; zero-count factory reads no operands.
Keep that empty storage out of the recursive expression evaluator's frame using
a non-inlined allocation helper, preserving the R71 wide-carrier lesson.
This removes the separate empty-list admission implementation and its general
zero-count branch. No new ownership/state/cache/pool/API. Span/refusal/after-admission
cancellation/refund semantics stay in the established factory.
No CSV causal claim from source; one same-settings controlled pair againsta7,
with guarded bothAPIs/rsplit/CSVcompile/CSVwarm/JSON controls, decides the final
tradeoff. Preserve initial source/results/accepted-debt decision as history.
Focused semantics/ownership/cancellation peractual11/10 first; one short local
allocation diagnostic, full new-source delivery only once at retained boundary.
