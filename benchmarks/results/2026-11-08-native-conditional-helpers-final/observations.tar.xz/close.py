from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;b=r/'b465'
i=json.loads((r/'identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
receipt=json.loads((b/'archive-receipt.json').read_text(encoding='utf8'))
assert receipt['complete'] and receipt['jobs']==6
assert hashlib.sha256((b/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for name in ['public11','public10','internal11','internal10']:
 s=(r/(name+'.log')).read_text(encoding='utf8')
 assert 'Failed:     0' in s and ('Total:   205' in s if name.startswith('public') else 'Total:    42' in s),name
out=Path('benchmarks/results/2026-11-08-native-conditional-helpers-final');out.mkdir()
decision='''Retain refined R106/core1aa68ce9. One native return-tree proof replaces single-block eligibility and unselected final-return span assumptions. Reuse the unchanged literal-list factory from a cold non-inlined native helper; remove initial general-factory changes and duplicate admission. No new engine/carrier/arena/runtime owner/cache/pool/public option.
205public/42internal Release peractual11/10 pass. B465 six jobs168.190s, all gates/archive/local verification pass; no remaining users/fixtures. Guarded sync elapsed-13.42to-16.75%, async-14.63to-16.20%; coarse CPU supports both. Warm allocation neutral. CSV warm-0.12to-1.92%, coarseCPU flat/lower; original67e/B464+3% CSV regression does not recur in this bounded comparison. Its cause remains unresolved; no causal attribution or repayment of unrelated old debt. CSV compile+0.56to+1.48%, CPU mixed; not a compiler improvement. Rsplit/JSON controls mixed/nearbaseline; JSON baseline4.92%spread. Initial compiler allocation+0.08to+0.53%, Windows compiler timing uncertainty/adverse conditions retained. Compiler source unchanged by construction refinement; no repeated local frontend campaign.
Commit coherent source and batch exact full platform/Stress/installed core qualification once. Cached a7 green is independent. Continue substantial remaining roadmap; no publication or whole-objective closure.
'''
(r/'decision.md').write_text(decision,encoding='utf8')
with tarfile.open(out/'observations.tar.xz','w:xz') as a:
 for p in sorted(r.iterdir()):
  if p.name=='images':continue
  if p.name=='b465':
   for q in sorted(p.iterdir()):
    if q.name not in ['retrieved','baseline-core.dll','current-core.dll','payload.tgz']:a.add(q,arcname='b465/'+q.name)
  else:a.add(p,arcname=p.name)
 a.add(r/'images/candidate/Lokad.Lython.dll',arcname='frozen-core/Lokad.Lython.dll')
 for p in ['tests/Lokad.Lython.PublicApi.Tests/NativeConditionalHelperTests.cs','tests/Lokad.Lython.Tests/SimpleFunctionExecutionBoundaryTests.cs']:
  a.add(p,arcname='tests/'+Path(p).name)
with tarfile.open(out/'observations.tar.xz') as a:
 assert hashlib.sha256(a.extractfile('b465/observations.tgz').read()).hexdigest()==receipt['archiveSHA256']
 assert hashlib.sha256(a.extractfile('frozen-core/Lokad.Lython.dll').read()).hexdigest()==i['coreSHA256']['candidate']
for p,n in [(r/'identity.json','identity.json'),(r/'assessment-local.json','allocation-and-local.json'),(b/'assessment.json','controlled-comparison.json')]:shutil.copyfile(p,out/n)
status=dict(status='Refined R106 retained; focused checks and controlled source pair pass. Exact committed-source full qualification pending independently.',coreSHA256=i['coreSHA256'],archiveSHA256=hashlib.sha256((out/'observations.tar.xz').read_bytes()).hexdigest(),controlledArchiveSHA256=receipt['archiveSHA256'],noRemainingVMUsersOrFixtures=True,initialPrototypeCore='67e76e70',referenceGuideSource='15c06863')
(out/'status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf8')
(out/'README.md').write_text('''# Native conditional helper returns: retained refinement

The existing native-return proof now covers acyclic guarded returns. It retains
source indices, proves types before effects and evaluates only the selected branch.
Shared joins, loops, custom truth and data-query format guards use ordinary
executable dispatch. No second engine, control carrier, arena or public option.
Two immutable 32-bit node fields and compiler-only path scratch are explicit costs.

Baseline: fully qualified `a7bd4103`, core `aae80cc7`. Retained source: four-file
patch over `dee0ef1b`, core `1aa68ce9`; exact inventory and binary are archived.
The empty-list branch borrows the unchanged literal-list factory through a cold
non-inlined helper, preserving fresh values, preflight, cancellation and refunds.
The [initial prototype](../2026-11-08-native-conditional-helpers/README.md) and all
its adverse observations remain separate. Final platform qualification is pending;
the primary CPython guide still describes source `15c06863`.

| Complete script / phase | Elapsed change, four median pairings | Coarse CPU change |
| --- | ---: | ---: |
| Guarded text helper, warm sync | −13.42 to −16.75% | −13.51 to −16.00% |
| Guarded text helper, warm async API | −14.63 to −16.20% | −9.15 to −15.94% |
| Ordinary rsplit helper, warm control | −0.55 to −4.21% | −1.22 to −3.66% |
| CSV compilation control | +0.56 to +1.48% | −0.45 to +3.73% |
| CSV warm control | −0.12 to −1.92% | 0 to −2.22% |
| JSON warm control | −2.94 to +3.36% | −2.50 to +5.13% |

Guarded baseline spreads: 2.05% sync / 0.31% async; candidate 1.91% / 1.55%.
Short observations support a workload-specific CPU gain, not confidence intervals
or a universal speedup. The initial stable CSV regression does not recur here;
its cause remains unresolved. Controls show no demonstrated new material debt;
JSON is inconclusive with 4.92% baseline spread. Earlier independent regression
debts are not silently repaid.

Warm allocation is neutral (less than 0.02% diagnostic differences). Original
compiler allocation +0.08–0.53% remains; compiler source was unchanged by this
construction refinement. Windows compilation timing remains uncertain: the initial
CSV +74–79% did not recur in changed-order confirmation, but other compiler controls
were adverse/variable. All initial observations and failed two-case driver invocation
are preserved. Quiet Ubuntu does not establish a Windows compiler improvement.
Desktop elapsed remains diagnostic; refined async old-control spread reached 32.09%.

205 public / 42 internal focused Release checks pass per actual .NET11/.NET10.
Independent Python goldens cover nested/implicit returns, fresh aliases, changing
builtins, formatting, unselected errors, local forwarding and ordinary joins/loops.
Real asynchronous truth, in-flight cancellation, terminal refusal, selected error
spans, caller exception restoration, retained funding and budget reuse are covered.

Same unchanged scripts, full goldens and workers as the initial comparison:
guarded/rsplit text 3,072 lines / 35,840 B, CSV 4,096 records / 57,361 B,
JSON 4,096 records / 110,592 B. Azure F4as_v7 / Ubuntu24.04.4, four EPYC9V45
vCPUs, 16GiB/no swap, actual .NET11 RC3, normal GC/tiering, optional0.4 adapter.
Five-second warmup per role/job, two independent copies/core, seven rotated150ms
rounds; six jobs168.190s. Warm command-v2 includes execution, mediated RAM-file I/O,
full validation and prior-result cleanup. Compilation includes construction/disposal.
Startup, staging and final cached teardown are excluded; no pending-I/O/RSS/tail claim.

All source/core/auxiliary/Ready/golden/quiet/Closed/exit/join/fixture/archive gates
pass. B465 is terminal, all users joined, RAM unmounted, archive verified locally.
No evidence was deleted. The frozen binary predates its commit; inventory is exact.

[Identity](identity.json), [controlled comparison](controlled-comparison.json),
[allocation/local diagnostic](allocation-and-local.json), [status](status.json),
[source patch, binary, tests, logs, raw observations](observations.tar.xz).
''',encoding='utf8')
p=Path('benchmarks/results/2026-11-08-native-conditional-helpers/README.md');s=p.read_text(encoding='utf8');s=s.replace('# Native conditional helper returns — 2026-11-08','# Native conditional helper returns — initial prototype, 2026-11-08',1);s=s.replace('Retain one existing native-return proof extended to acyclic branch returns.','Historical initial core67e76e70, superseded by the [retained refinement](../2026-11-08-native-conditional-helpers-final/README.md). Original archive and measurements are unchanged.\n\nOne existing native-return proof was extended to acyclic branch returns.',1);p.write_text(s,encoding='utf8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf8')+'''
## Native return-tree construction refinement (2026-11-08)

[R106/B465](results/2026-11-08-native-conditional-helpers-final/README.md) retains
the return-tree proof with the unchanged literal-list factory borrowed through a
cold native helper. Initial general-list extraction and duplicate admission removed.
205public/42internal Release peractual11/10 pass. Warm allocation neutral; controlled
guarded elapsed−13–17% both APIs, coarse CPU supports the gain. Initial CSV +3%
does not recur (−0.12to−1.92%, CPU flat/lower); cause remains unresolved, original
source/data preserved. CSV compile+0.56to+1.48%, CPU mixed; JSON control variable.
Windows compiler uncertainty and initial compiler allocation+0.08–0.53% remain.
Six jobs168.190s/all gates/archive/local verification pass; no users/fixtures.
Exact retained-source full delivery is independent/pending; no publication or
completion of the broader performance objective.
''';p.write_text(s,encoding='utf8')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf8');a=s.index('| Native acyclic helper returns');z=s.index('\n',a);s=s[:a]+'| Native acyclic helper returns / guarded text | Allocation neutral; controlled elapsed −13–17% across both APIs, coarse CPU supports the gain | One existing return proof; initial CSV regression did not recur after construction refinement, cause unresolved. Windows compilation uncertain; full qualification pending. [R106](../benchmarks/results/2026-11-08-native-conditional-helpers-final/README.md) |'+s[z:];p.write_text(s,encoding='utf8')
print(json.dumps(status,indent=2))
