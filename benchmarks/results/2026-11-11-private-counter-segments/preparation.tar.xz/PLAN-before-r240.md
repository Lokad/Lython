# Lokad.Lython 0.11.0

Updated2026-11-11. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script improvements,
including compile-to-result. An isolated experiment does not complete it.

## Actual delivery status

- **Committed/pushed:** runtimefe6648b2, evidence56f41bc8. R237 native histogram
  loops reuse existing iteration/arithmetic/local bindings, eliminating repeated
  dispatch and argument preparation. No new owner/value/control framework.
  Both text shapes/APIs improve on the quiet VM; allocation is flat. Twelve
  independent CPython goldens and2692focused Release checks pass on actual11/10.
  [All sources/cores/failures/adverse controls](benchmarks/results/2026-11-11-native-counting-loops/README.md).
- **Full qualification pending:** exactfe CI43024046530. At13:02UTC both platforms
  passed.NET11; actual.NET10 tests in progress, originalStress and installed
  Release consumers still pending. Next query not before13:07:26UTC, then5minutes
  apart. Do not rerun unchanged qualification. Evidence-only HEAD has same runtime.
- **Last fully qualified runtime:**15f457f7, including allocator/admission752d78ce,
  Windows/Ubuntu actual11/10, originalStress and installed consumers. CachedGREEN
  42980759461/42976124076 are terminal; never query again.
- **Subsequent qualification:** exactfe6648b2 CI43024046530 is GREEN on both
  platforms, actual11/10, originalStress and installed consumers. Terminal cached;
  never query again. R236 retained fixes are covered. R239 cleanup8314c02d is
  committed/pushed separately:960focused checks on actual11/10 pass, full delivery
  batches with the next material runtime change; no CPU claim. Original tests
  demonstrate160B of duplicate refund on both APIs.
- **R236 retained698f7e77:** Python factory keyword/variance ordering fixes, direct
  admitted exception-argument tuples, deletion of sync carriers/generic policy.
  11074focused checks passed; full delivery batches withfe. Broad canonical-span
  migration/refinement fully removed: common paths already borrowed, allocation
  flat and clocks mixed/adverse. [Evidence](benchmarks/results/2026-11-11-call-preparation/README.md).
- **External checkpoint completed:** B5779jobs/244.887s. Exactfe sources, frozen
  precommit corebf93, stockCPython3.13.16; original published scripts unchanged.
  Warm ordinary text1.21–1.22x, captured text2.24–2.27x, CSV1.06–1.08x.
  Separate compilation and compile-to-result; table/archive update active.
  [Current performance](docs/BENCHMARKS.md). No active VM collection.
- **Debt/uncertainty:** R237 capturedCSV async control−1.76..+2.74%, neutrality
  unresolved; ordinary text controls wider than captured sync. Earlier15f versus
  4aa ordinary-text async+1.92..+2.55% is historical debt, not directly remeasured
  by the new698source pair. Desktop adverse data survives. Resolve remaining
  material regression debt before publication; RSS/pending-I/O/tail latency unqualified.

## Completed — reuse qualification and preserve history

| Milestone | Established result / remaining limit |
| --- | --- |
| Shared compiler facts | Corrected exponential traversal/nonlocal diagnostics; reused binding/module/scope facts. Fully qualified; no CPU claim. |
| Direct UTF-8 formatting/storage | Fully qualified; allocation−8.67%, controlled elapsed/CPU5–8% lower. Original adverse15.125ms unexplained and preserved. |
| Native helper returns | Fully qualified; allocation−19.92%sync/−19.31%async. Original elapsed diagnostic; no remaining delivery replay. |
| Calls/setup/CSV | Shared immutable metadata, async startup reuse, shared binding/workspaces/receiver entry/native returns delivered. Selective6–8% CSV reassessment led to shared keys/adopted funded rows. Slower arenas/controllers removed. |
| Lexical writes/iteration | Fully qualified4625/4aa. Counter allocation−27–48%, quiet warm12–21% lower with control debt. Returned iteration−4.84%allocation/−15.06%estimated peak, elapsed inconclusive. |
| Canonical construction | Fully qualified752/15f. Correct sealed allocator proof; reentrant capacity funded once, no unfunded publication, first refusal survives refunds. Named/keyword-only/variadic initializers use ordinary binder/runner. |
| Text/JSON/IR | Final UTF-8 casing/split/format/JSON, inline short text, span tuples and same-suite jumps delivered. No presumed per-character/token conversion. |
| Regex | Core-owned Python UTF-8 boundary/provider consistency, windows/effective flags/current tokens/ownership delivered. Coordinate storage consolidated; Unicode allocation−17–18%, no CPU claim. |
| R235 captured operands | Full withdrawal with independent regressions retained. Flat allocation; quiet CSV/text adverse, captured text unstable. No permanent design veto. All sources/JIT/controls survive in historical evidence. |

Detailed experiments/source gates and old plans stay outside docs:
[EXPERIMENTS](benchmarks/EXPERIMENTS.md) and
`.git/agent-notes/review-20261031/`. The previous active plan is archived under R237.

## P1 — close the retained delivery, continue runtime work

1. Finish exactfe Windows/Ubuntu, actual11/10, originalStress and installed package
   qualification. Preserve unrelated failures explicitly; fix real regressions.
   Update docs/status with the exact result. Publication remains postponed.
2. Complete the already-collected B577 external table/archive update. Preserve
   prior guide, source hashes, all observations and variability. Compile/warm/
   compile-to-result separated; I/O/full checks/prior-result cleanup included;
   reset/protocol/startup/final caches excluded. No async-I/O latency claim.
3. **R239 ownership correction source gate:** inspecting complete function cleanup
   found that a native success returns its bound workspace inside a try, then its
   catch returns it again if the first refund callback throws. Verify with a real
   compiled helper and admission reentry. If confirmed, consolidate sync/async
   cleanup into one finally, deleting duplicate returns/catches. Preserve first
   refusal, retained/cache funding, recursion/exception annotation and reuse.
   Focused lifetime/call/cancellation checks on both targets; no CPU claim or
   broad ownership audit. Complete this bounded correction before a new transport
   representation. Batch its eventual full delivery at the next coherent boundary.
4. **R238 source/profile gate completed:** B578 sampled5.873s execution/1151guest
   leaves,58unknown. Native loop12.25%, shared dispatcher11.38%, private word
   preparation7.91%, MoveNext4.00%; useful/inlined work overlaps. This establishes
   current costs, not removable percentages. Raw maps/JIT/cores/outputs archived,
   all users joined; terminal cached. No prior native offsets transferred.

## P2 — R238 complete native word transport, if the gate supports it

**Hypothesis:** the prepared cased-word cursor still constructs one immutable
PyString per word. The two maintained scripts have6144words and allocate about
1.35/1.45MB per job. Removing duplicate-word materialization across an entire
cursor-to-dictionary segment could eliminate meaningful storage and transport.
Source proves construction, not its CPU share or the safe removable fraction.

Source assessment also considers eliminating the admission prepass. A constant
worst-case word-count estimate can overcharge long words/spaceruns by roughly64x,
so it is not a reasonable bounded-streaming replacement. Keep exact scanning
unless a simpler capacity bound avoids that cost. Deferred word binding introduces
alias/resume complexity; do not promote it from sampled shares alone. No prototype
or rejection timing exists for either idea. R239 is the immediate bounded change.

**Next selected R240:** complete private integer-total transport inside the existing
R237 native loop. Its producer/consumer are entirely in one callback-free segment;
current AddExactIntegers is3.65% of sampled guest leaves for both integer operations,
not a predicted CPU saving. Scope the change to uncaptured/unmirrored/non-namespace
totals, retaining the existing seven-byte numeric eligibility and normal promotion.
Keep the total in a managed long until segment exit, invalidation or failure, then
publish one ordinary BigInteger. Remove repeated total boxes/operand stores inside
that entire segment; no scalar bank/tagged representation/owner/cache/options.
Preserve initial/final identity and aliases, consumed-word resume points, current
exception/cancellation spans, first refusal and awaited fallback. Flush before any
actual callback/admission; stop before leaving the small tier so ordinary exact
promotion remains unchanged. One existing six-script pair across both APIs and
compile, including namespace/protocol/promotion/cancellation/ownership checks.
Retain/refine/withdraw on semantic proof, allocation and controls, not a fixed%.
If safe publication requires a new control/identity framework, stop that design.

- Reuse existing scanner/casing, native dictionary probe/arithmetic and batch
  admission. Explore a borrowed final UTF-8 word only across a proven callback-free
  segment, materializing an immutable value before insertion, observable binding,
  admission or genuine suspension. Keep retained keys and final/escaping word
  aliases funded and correct. Do not add R230's range array/word wrappers/caches,
  a scalar representation, general matcher abstraction or new ownership tier.
- **Acceptance:** full Unicode whitespace/casing expansion/final-sigma context;
  empty/final bindings and identity; insertion order/keys, existing aliases,
  dynamic/protocol values and defaults, exact promotion, list mutation, failures
  and original spans. No callback sees deferred state; resume the consumed word
  once. First refusal terminal, per-loop/long-text cancellation effective,
  pending users joined before refunds, capacity/replacement preflight preserved.
- **Removal/completion:** share one cursor/arithmetic loop; remove any displaced
  materialization/transport route with no semantic caller. One complete source
  pair through both APIs with CSV/JSON/report controls, compilation separate.
  Retain/refine/withdraw on combined semantics, simplification, allocation and
  controlled clocks; record remaining debt explicitly. Temporary setbacks can
  have a coherent completion milestone; no automatic percentage veto.
- **Stopping:** one source/CPU gate then a bounded coherent prototype if justified.
  If correctness needs a new identity/ownership/control framework, record the
  concrete obstacle and choose another complete measured boundary. Uncertainty,
  timeouts and unstable controls allow justified correction/confirmation; they
  are not permanent rejection. Do not repeatedly tune the same small guard.

| Other assessed boundary | Evidence required before selection |
| --- | --- |
| Complete calls/frames | Common paths already borrow, bind into shared compiler-sized workspace and defer contexts. R236 blanket ABI staging was flat/slower. Find a complete measured construction/cleanup phase; remove it rather than add carriers/arenas/controllers. |
| Operand/scalar transport | R235 partial banks added shared costs with flat allocation. Require a whole producer/consumer representation to disappear; preserve identity, protocols, promotion and projection. Scalar3% old sampled leaves alone do not justify a universal rewrite. |
| Per-record collections | CSV shared keys/adopted rows already delivered. Select a remaining measured phase; retain duplicate/order/header mutation/protocol/reentry/retention. |
| Frontend | Shared facts, declaration/direct-child/nonlocal analyses delivered. Measure actual duplicate work/retention; preserve lazy annotations, generators, mirrors and executable imports. Current compilation alone does not explain the captured-text gap. |

Both public APIs already share a nonasync instruction prefix and suspend only on
actual incomplete operations. Short text stores up to8UTF-8bytes inline; casing
writes final fragments; native split reserves all eventual words before effects.
R230 added8–9%allocation/163840Bpeak and was removed. Do not assume these existing
mechanisms are missing or revive their extra representations without new evidence.

## Independent regex track

Core architecture/development is independent of producer publication. Optional
nonpackable adapter0.4 remains normal. Immutabledev68/a7e985ed qualified86internal/
532public per target with unchanged Validate bridge/29normal files; reuse proof.
Only affected final adapter qualification awaits these producer capabilities:

1. Independent single-match working and retained-result owners.
2. Native UTF-8 group-name enumeration; lookup already exists.
3. Token-independent cursor creation with cancellable preparation; per-move is insufficient.

Continue core contract/semantic work with immutable development producers or
adapter-local bridges. Remove displaced DetailedData/conversions when native APIs
arrive. Preserve Python Match/FullMatch alternatives, flags/captures/windows,
byte/scalar positions, current tokens, cache/retained funding and no silent dialect
fallback. Backend semantics/CPU/managed safety/SizeOf are distinct claims.

## Lasting constraints and iteration

Fully managed/memory-safe: no unsafe/Unsafe/pointers/PInvoke/native probing. Keep
managed stack admission, host capabilities, cancellation, cycles/XML depth,
checked representation/bounded I/O. No fuel/quotas/independent caps/hidden allowance,
tracing/root inventories/weak reclamation/forcedGC/retries/abandoned users. Borrowed
allowance funds capacity/overlap/results/aliases/caches/pending users through awaited
cleanup; scopes reserve zero. First refusal preserves its original origin and
fails the command despite suppression/finally returns; native cleanup available.
Guest MemoryError remains catchable; long streams use bounded host commands.
Preserve LythonPathRequest/Cwd/component resolution, no delete-before-copy.

Focused Release checks during iteration; batch full qualification at coherent
delivery boundaries. Preserve original stress; no relaxed timeouts/assertions.
Tests forcing process-wide GC/finalizers share existing nonparallel collections.
Quiet comparisons use existing tooling, usable bounded samples, unchanged controls
and normal GC/tiering. Allocation, architectural simplification and CPU improvement
are separate claims; adverse results and failed conditions remain immutable.

VMlokad@20.166.121.73, key~/.ssh/id_lython-bench.pem. B576/B577 terminal/cached,
archives verified, no users/RAM fixtures; last free304484352B. Never query again.
Fresh idle lease/identity/disk proof before staging;240MiBfloor/12MiBheadroom fixed.
Current15f/9ee7/c271/fe images survive. Retired fresh-csv-20261017/source.tar and
all earlier retired paths are off limits; no stale cleanup recipes. Any retirement
needs a verified independent canonical copy plus fresh path/UID/alias/SHA proof.
Workers/logs/maps/evidence persistent, separately from RAM fixtures; archive and
verify before releasing ownership. Core Release packages only through
tools/pack.ps1 to artifacts/nuget/. Adapter stays nonpackable. No publication/tag.
