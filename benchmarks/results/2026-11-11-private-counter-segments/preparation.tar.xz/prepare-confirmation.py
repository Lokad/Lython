from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;q=r/'b580';q.mkdir(exist_ok=False);old=r/'b579';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
root='/home/lokad/lython-bench-checks/private-counter-control-b580-20261111';unit='lython-b580-private-counter-control-20261111'
for name in ['representative.json','identity.json','source-identity.json']:shutil.copyfile(old/name,q/name)
jobs=[['scripts.report-render.large','warm-async'],['scripts.text-summary-helpers.large','warm']]
text=(old/'collect.py').read_text(encoding='utf-8').replace('/private-counter-b579-20261111','/private-counter-control-b580-20261111')
begin=text.index('jobs=');end=text.index('\nenv = ',begin)
text=text[:begin]+'jobs='+repr(jobs)+'\nassert len(jobs)==2 and all(case in cases for case,lane in jobs)\n'+text[end:]
text=text.replace("< 170, 'Reserve40seconds","< 80, 'Reserve40seconds")
text=text.replace("if job_index >= 2: labels.reverse()","if job_index == 0: labels.reverse()")
begin=text.index("purpose='R240");end=text.index("',\n                  warmupSeconds",begin)
text=text[:begin]+"purpose='R240 bounded confirmation of adverse report-async control, which source proves does not execute the changed loop, with ordinary-sync target. Same cores/settings/scripts, fresh independent processes and changed startup order. Preserve original desktop/B579 adversity; no CPython ratio. Warm includes mediated RAM I/O/full checks/prior-result cleanup"+text[end:]
ast.parse(text);(q/'collect.py').write_text(text,encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py']:
 text=(old/name).read_text(encoding='utf-8').replace('private-counter-b579','private-counter-control-b580').replace('lython-b579-private-counter','lython-b580-private-counter-control').replace('B579 five-job','B580 two-job').replace('==5','==2').replace('jobs=5','jobs=2').replace("jobs']==5","jobs']==2").replace("elapsedSeconds']<210","elapsedSeconds']<120")
 if name=='launch.py':text=text.replace('seconds=270','seconds=180').replace('ownerSeconds=210','ownerSeconds=120')
 if name.endswith('.py'):ast.parse(text)
 (q/name).write_text(text,encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for name in ['representative.json','identity.json','source-identity.json','collect.py','archive-owned.py','run.sh']:t.add(q/name,arcname=name)
with tarfile.open(q/'payload.tgz')as t:expanded=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())
identity=json.loads((q/'identity.json').read_text(encoding='utf-8'))
config=dict(root=root,unit=unit,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),requiredFreeBytes=252*1024*1024+expanded+65536,retire=[],identity=identity)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
text=(old/'remote-launch.py').read_text(encoding='utf-8')
text=text.replace("for role in ['reference','candidate']:shutil.copytree(source,root/role,copy_function=os.link)","for role in ['reference','candidate']:\n  origin=base/'private-counter-b579-20261111'/role\n  assert digest(origin/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]\n  shutil.copytree(origin,root/role,copy_function=os.link)\n os.link(root/'reference/Lokad.Lython.dll',root/'baseline-core.dll')\n os.link(root/'candidate/Lokad.Lython.dll',root/'current-core.dll')")
text=text.replace('lython-b579-fixtures','lython-b580-fixtures').replace('jobs=5','jobs=2').replace('ownerSeconds=210','ownerSeconds=120').replace('RuntimeMaxSec=210','RuntimeMaxSec=120')
ast.parse(text.replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
(q/'remote-launch.py').write_text(text,encoding='utf-8',newline='\n')
print('Prepared2fresh-process control/target jobs,120sowner; unchanged original candidate/reference, no new core upload or retirement.')
