from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;repo=Path.cwd();prior=r.parent/'native-counter-loops-r237';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head.startswith('8314c02d')
assert not(r/'before.json').exists()
target='src/Lokad.Lython/Runtime/LythonRuntime.Executable.DictionaryAccumulation.cs'
p=r/'originals'/target;p.parent.mkdir(parents=True);shutil.copyfile(target,p)
for role in ['before','candidate']:
 shutil.copytree(prior/'images/candidate',r/'images'/role)
 shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'images'/role/'Lokad.Lython.dll')
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net10.0/Lokad.Lython.dll',r/'before-net10.dll')
shutil.copyfile(prior/'catalog.json',r/'catalog.json')
for phase in ['warm-sync','warm-async','compile']:
 (r/phase).mkdir();shutil.copyfile(prior/phase/'hash-witness.json',r/phase/'hash-witness.json')
data=dict(head=head,runtimeSource='8314c02d',qualification='Qualifiedfe6648b2 plus960focused actual11/10 R239 checks; full831 delivery batches with next material change. No full831 qualification claim.',
 sourceHashes={p.relative_to(repo).as_posix():sha(p)for p in(repo/'src/Lokad.Lython').rglob('*.cs')if not {'bin','obj'}&set(p.parts)},
 images={role:{p.name:sha(p)for p in(r/'images'/role).iterdir()if p.is_file()}for role in ['before','candidate']},net10SHA256=sha(r/'before-net10.dll'),
 hypothesis='Complete private integer-total transport inside the existing callback-free native histogram segment. Keep the seven-byte tier in a managed long; flush one ordinary BigInteger at every exit/invalidating boundary/failure. Remove per-element total boxing/operand stores. No global bank, value representation, owner/cache/options or new backend.',
 acceptance='Private means uncaptured, unmirrored, no namespace write; shared binding/aliases/initial/final values, exact promotion, effects before error, consumed-word fallback once, current source spans, cancellation, first refusal, awaited users and budget reuse. Real callbacks/admission see flushed values. Normal observable path unchanged.',
 controls='Maintained6whole scripts through both APIs plus compilation separate; both text shapes intended beneficiaries. Preserve all controls/adversity; no fixed speed threshold or guessed CPU improvement.')
(r/'before.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print('Fresh nonincremental831 source/cores frozen on both targets; source-labelled focused baseline, no full qualification claim.')
