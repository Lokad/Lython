from pathlib import Path
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.DictionaryAccumulation.cs')
text=p.read_text(encoding='utf-8')
start=text.index('              while (true)');end=text.index('\n            }\n            finally',start)
lines=text[start:end].splitlines()
lines[0]='                while (true)';lines[1]='                {';lines[-1]='                }'
for i in range(2,len(lines)-1):
 if lines[i]:lines[i]='    '+lines[i]
text=text[:start]+'\n'.join(lines)+text[end:]
p.write_text(text,encoding='utf-8')
