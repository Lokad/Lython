from pathlib import Path
r=Path(__file__).resolve().parent;p=Path('PLAN.md')
(r/'PLAN-before-r240.md').write_bytes(p.read_bytes())
p.write_text('''# Lokad.Lython 0.11.0

Updated 2026-11-11. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial whole-script improvements,
including compile-to-result. One isolated experiment does not complete it.

## Delivery status

- **Fully qualified runtime fe6648b2:** Windows/Ubuntu, actual .NET11/10,
  originalStress and installed Release consumers; GREEN43024046530 cached.
  R237 runs complete native dictionary-counting segments through existing
  cursor/arithmetic/binding paths. Quiet captured sync elapsed9–11% lower;
  other text shapes/APIs improve with wider controls; allocation flat.
  R236 retained698 factory/variance fixes, direct exception tuples and sync-carrier
  deletion are covered. [All source pairs/cores/adversity](benchmarks/results/2026-11-11-native-counting-loops/README.md).
- **Committed/pushed R2398314c02d:** one cleanup finally per function API,
  deleting duplicate workspace returns. Real compiled-helper/refund reentry
  previously refunded160B still cached on both APIs. 960focused actual11/10 checks
  pass; full delivery batches with the next material change. No CPU claim.
  [Proof](benchmarks/results/2026-11-11-native-helper-refund/README.md).
- **Evidence/docs HEAD94d4bd59:** current CPython tables, prior guide and current
  profile archived; runtime equals831. Native helper returns and UTF-8 formatting
  qualification are complete and need no replay.
- **Active/uncommitted R240 prototype:** private integer totals stay in a managed
  long across the existing callback-free native segment, then publish one ordinary
  BigInteger on every exit. Observable storage and wider/promotion paths unchanged.
  2978focused checks pass across actual11/10;16goldens match isolated CPython3.13.
  Six-script before/after active, both APIs/compilation separate; no timing claim.
- **External checkpoint closed:** qualifiedfe/frozenbf93 versus CPython3.13.16,
  original scripts unchanged. Warm ordinary text1.21–1.22x, captured text2.24–2.27x,
  CSV1.06–1.08x. Compilation and compile-to-result separate; captured gap remains.
  [BENCHMARKS](docs/BENCHMARKS.md), [all9jobs/244.887s](benchmarks/results/2026-11-11-native-loops-cpython-checkpoint/README.md).
- **Debt/uncertainty:** R237 capturedCSV async control−1.76..+2.74%, neutrality
  unresolved; ordinary text controls wider than captured sync. Earlier15f versus
  4aa ordinary-text async+1.92..+2.55% is historical debt, not directly remeasured
  by the698source pair. Preserve desktop adverse data. Decide material regression
  debt before publication; RSS/pending-I/O/embedding tail latency unqualified.

## Completed — preserve history, reuse qualification

| Milestone | Established result / limitation |
| --- | --- |
| Shared compiler facts | Exponential traversal and nonlocal diagnostic correction; binding/module/scope facts reused. Fully qualified; no CPU claim. |
| Direct UTF-8 formatting/storage | Fully qualified; allocation−8.67%, controlled elapsed/CPU5–8% lower. Original adverse15.125ms unexplained and preserved. |
| Native helper returns | Fully qualified; allocation−19.92%sync/−19.31%async. Original elapsed diagnostic; no delivery replay. |
| Calls/setup/CSV | Immutable metadata, async startup reuse, shared binding/workspaces/receiver entry delivered. Selective6–8% CSV reassessment produced shared keys/adopted funded rows. Slower arenas/controllers removed. |
| Lexical writes/iteration | Qualified4625/4aa. Counter allocation−27–48%, quiet warm12–21% lower with control debt. Returned iteration−4.84%allocation/−15.06%estimated peak, elapsed inconclusive. |
| Canonical construction | Qualified752/15f, now covered byfe. Correct allocator proof and reentrant capacity/refund behavior; ordinary binder/runner handles named/keyword-only/variadic init. |
| Text/JSON/IR | Final UTF-8 casing/split/format/JSON, inline short text, span tuples/same-suite jumps delivered. No presumed remaining per-character/token conversion. |
| Regex | Core-owned Python UTF-8 boundary, windows/effective flags/current tokens/ownership delivered. Coordinate consolidation−17–18%Unicode allocation; no CPU claim. |
| R235/R236 broad prototypes | Captured operand banks/canonical span staging fully removed, useful regressions/fixes retained. Flat allocation and mixed/adverse controls do not justify their complexity; no permanent veto. |

Old plans/source gates live in `.git/agent-notes/review-20261031/`, including the
R240 archived previous plan. Experiments and rejected alternatives belong in
[EXPERIMENTS](benchmarks/EXPERIMENTS.md), outside current docs.

## P1 — finish the complete private-total segment

**R240 hypothesis:** eliminate repeated total boxes and operand stores across a
complete native histogram segment. Reuse R237 cursor/dictionary algorithms and
its seven-byte tier. No universal value representation, scalar bank, cache, new
owner, control hierarchy, options or backend. Current AddExactIntegers3.65% sampled
leaves covers both integer operations and is not a predicted speedup. With two
words per line, publication still occurs once per line; do not predict eliminating
all total boxes across the stream.

- Eligibility: total uncaptured, code unmirrored, no namespace/mirror store. No
  callbacks/admission inside that segment. Preserve original word binding.
  Publish one BigInteger in finally before any continuation/handler/callback;
  stop the segment at the seven-byte boundary, preserving normal exact promotion.
- Acceptance: initial/empty/final identity and aliases, locals/namespaces/cells,
  dictionary update before total, consumed-word fallback once, custom protocols,
  mutation and source spans, positive/negative boundaries, first refusal and
  active cancellation, real pending callbacks joined before allowance reuse.
- Complete existing six-script local pair across both APIs and compilation,
  with CSV/JSON/report controls. Preserve all adverse data. Confirm/refine if
  warranted; retain or withdraw based on semantics, simplification, allocation
  and controlled clocks together. No rigid percentage veto or one-attempt ban.
- If retained, remove displaced introduced-only code, update current runtime
  guide, commit coherently and batch full platform/stress/package qualification
  together with R239. Reuse already qualifiedfe; do not repeat its CI. If withdrawn,
  restore its production bytes and keep independent regressions. A source/time
  uncertainty does not permanently reject a design.

## Next substantial redesign selection

R238 profile reflects currentfe:1151guest leaves/5.8CPU seconds,58unknown;
native loop12.25%, shared dispatch11.38%, word preparation7.91%, MoveNext4.00%.
Useful/inlined work overlaps. [Raw profile/gate](benchmarks/results/2026-11-11-native-word-costs/README.md).
Do not transfer old native offsets or treat method shares as removable overhead.

| Assessed boundary | Evidence / next coherent selection requirement |
| --- | --- |
| Native word transport/admission | Construction per word is real; removal needs exact alias/binding/resume proof. A constant worst-case admission estimate can overcharge long words/spaceruns about64x, so it is not a reasonable streaming replacement. No prototype or timing rejection. Avoid R230 range arrays/wrappers and new deferred-binding framework. |
| Complete calls/frames | Common calls already borrow, bind into compiler-sized reusable storage and defer contexts. R236 blanket ABI staging was flat/slower. Find a complete measured construction/cleanup phase to remove; no new carriers/arenas/controllers. |
| Operand/scalar transport | R235 partial banks added shared costs with flat allocation. Require a whole producer/consumer representation to disappear while preserving identity/protocols/promotion/projection. R240 is deliberately scoped inside an existing whole segment. |
| Per-record collections | CSV shared keys/adopted rows delivered. Select a remaining measured phase; preserve duplicate/order/header mutation/protocol/reentry/retention. |
| Frontend | Shared binding/module/scope/declaration/direct-child/nonlocal facts delivered. Measure actual duplicate work/retention; preserve annotations/generators/mirrors/executable imports. Compilation does not explain captured-text gap. |

Each selected redesign names removed work/storage and code to delete, affected
scripts, semantic acceptance, one bounded source pair with controls and a
completion/debt decision. Allow justified refinement/measurement correction;
timeouts, unstable controls and inconclusive data establish uncertainty. Fixed
percentages inform decisions, never automatically veto coherent simplification.
Do not treat finishing R240 as completion of the performance objective.

Both APIs already share the same nonasync instruction prefix and suspend only on
incomplete work. Short text stores up to8UTF-8bytes inline; casing writes final
fragments; native split prepays all eventual words. R230's extra ranges added8–9%
allocation/163840Bpeak and are removed. Do not propose these completed mechanisms
again or revive their extra representations without new source evidence.

## Independent regex track

Core development is independent of producer publication. Optional nonpackable
adapter0.4 remains normal. Immutabledev68/a7e985ed qualified86internal/532public
per target, unchanged Validate bridge/29normal files; reuse proof. Only affected
final adapter qualification awaits:

1. Independent single-match working and retained-result owners.
2. Native UTF-8 group-name enumeration; lookup already exists.
3. Token-independent cursor creation with cancellable preparation; per-move insufficient.

Continue core contract/semantics with immutable development producers or adapter
bridges. Remove displaced DetailedData/conversions when native APIs arrive.
Preserve Python Match/FullMatch alternatives, flags/captures/windows, byte/scalar
positions, current tokens/cache funding/no dialect fallback. Backend semantics,
CPU, managed safety and SizeOf remain separate claims. No producer polling loop.

## Lasting constraints and delivery

Fully managed/safe: no unsafe/Unsafe/pointers/PInvoke/native probing. Keep managed
stack admission, host capabilities, cancellation, cycles/XML depth, checked
representations/bounded I/O. No fuel/quotas/independent caps/hidden allowance,
tracing/root inventories/weak reclamation/forcedGC/retries/abandoned users. Borrowed
allowance funds capacity/overlap/results/aliases/caches/pending users until awaited
cleanup; scopes reserve zero. First refusal preserves its origin and fails the
command despite suppression/finally returns; native cleanup stays available.
Guest MemoryError catchable; long streams use bounded host commands. Preserve
LythonPathRequest/Cwd/component resolution; no delete-before-copy/replacement.

Focused Release checks during development; batch full Windows/Ubuntu actual11/10,
originalStress and installed consumers at coherent deliveries. No relaxed
timeouts/assertions; process-wide GC/finalizer tests share existing collections.
CPython primary external baseline, compile/warm/startup separate, I/O/checks/prior
cleanup boundary explicit. Preserve adverse/failed conditions outside docs.

VMlokad@20.166.121.73, key~/.ssh/id_lython-bench.pem. B576/B577/B578 terminal/cached,
raw archives verified/no users or RAM fixtures; never query again. Last recorded
free304484352B precedes the small B578 profile; require fresh idle lease/identity/
disk proof before staging. Fixed240MiBfloor/12MiBheadroom. Protect current15f/4aa/
c271/fe images and references used by active work. Retired fresh-csv source.tar
and all earlier retired paths are off limits; no stale cleanup recipes. Retirement
requires independent canonical evidence and fresh path/UID/all-alias/SHA proof.
Workers/logs/maps/evidence persistent, separate from RAM fixtures; archive/verify
before ownership ends. Terminal GREEN43024046530/42980759461/42976124076 cached.
Core Release packs only via tools/pack.ps1 to artifacts/nuget/; adapter nonpackable.
Publication/tagging postponed.
''',encoding='utf-8')
print('Plan refreshed: qualifiedfe, committed focused831, active R240; completed CPython/profile evidence and pending delivery/debt are separate.')
