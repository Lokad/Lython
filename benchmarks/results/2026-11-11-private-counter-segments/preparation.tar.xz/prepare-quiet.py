from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;q=r/'b579';q.mkdir(exist_ok=False)
old=r.parent/'native-counter-loops-r237/b576';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
for name,h in meta['sourceHashes'].items():assert sha(Path(name))==h,name
root='/home/lokad/lython-bench-checks/private-counter-b579-20261111';unit='lython-b579-private-counter-20261111'
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='R240 private-total prototype versus exact8314c02d sources/fresh cores. Baseline has qualifiedfe plus960focused refund checks; candidate2978focused actual11/10 checks. Both text APIs and report-async adverse control. Fixed common quiet worker differs from local worker. No CPython or isolated-allocation claim.',
 coreSHA256={role:meta['images']['before'if role.startswith('reference')else'candidate']['Lokad.Lython.dll']for role in ['reference','candidate','reference-control','candidate-control']},catalogSHA256=sha(r/'catalog.json'))
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(q/'source-identity.json').write_text(json.dumps(dict(beforeRevision='8314c02d',prototypeUncommitted=True,sourceSHA256=meta['sourceHashes'],changedProductionFiles=meta['changedProductionFiles'],focusedChecks=2978,lastFullyQualified='fe6648b2',acceptance='Private seven-byte total retained in a managedlong for the complete callback-free native segment; ordinary BigInteger at every exit/error/fallback. No numeric bank, new owner/cache/options or new backend.'),indent=2)+'\n',encoding='utf-8')
shutil.copyfile(r/'catalog.json',q/'representative.json')
for role,name in [('before','baseline-core.dll'),('candidate','current-core.dll')]:shutil.copyfile(r/'images'/role/'Lokad.Lython.dll',q/name)
jobs=[['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.text-summary-helpers.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm-async'],['scripts.text-summary-helpers.large','warm-async'],['scripts.report-render.large','warm-async']]
text=(old/'collect.py').read_text(encoding='utf-8').replace('/native-counter-loops-b576-20261111','/private-counter-b579-20261111')
begin=text.index('jobs=');end=text.index('\nenv = ',begin)
text=text[:begin]+'jobs='+repr(jobs)+'\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n'+text[end:]
begin=text.index("purpose='R237");end=text.index("',\n                  warmupSeconds",begin)
text=text[:begin]+"purpose='R240 bounded private-total source pair versus831, four complete text/API targets plus report-async adverse control. Warm includes mediated RAM I/O/full output checks/prior-result cleanup, excludes compile/startup/reset/protocol/final caches; no CPython ratio"+text[end:]
ast.parse(text);(q/'collect.py').write_text(text,encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py']:
 text=(old/name).read_text(encoding='utf-8').replace('native-counter-loops-b576','private-counter-b579').replace('lython-b576-native-counter-loops','lython-b579-private-counter').replace('B576 five-job','B579 five-job')
 if name.endswith('.py'):ast.parse(text)
 (q/name).write_text(text,encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for name in ['baseline-core.dll','current-core.dll','representative.json','source-identity.json','identity.json','collect.py','archive-owned.py','run.sh']:t.add(q/name,arcname=name)
with tarfile.open(q/'payload.tgz')as t:expanded=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())
config=dict(root=root,unit=unit,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),requiredFreeBytes=252*1024*1024+expanded+65536,retire=[],identity=identity)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
text=(old/'remote-launch.py').read_text(encoding='utf-8').replace('lython-b576-fixtures','lython-b579-fixtures')
# Protect the currently selectedfe core as well as the earlier references.
text=text.replace("with(base/'comparison-vm.lock')", "protected[base/'native-counter-loops-b576-20261111/candidate/Lokad.Lython.dll']='bf93c7ce9533fc93c00b4cb315b21d6fce707d0a25ff618b1ca98b7567e6cb22'\nwith(base/'comparison-vm.lock')")
ast.parse(text.replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
(q/'remote-launch.py').write_text(text,encoding='utf-8',newline='\n')
print('Prepared5short text/report source pairs,210sowner; fresh idle/identity/disk inventory required, no retirement candidates.')
