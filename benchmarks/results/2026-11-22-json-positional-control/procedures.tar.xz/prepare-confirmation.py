from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab/"quiet"
out = lab/"confirmation"
remote_base = "/home/lokad/lython-bench-checks"
retire_path = "retained-call-profile-b1370-20261122/observations.tgz"
archive_path = "benchmarks/results/2026-11-22-retained-call-cpu-profile/"

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, content):
    if path.suffix == ".py":
        compile(content, str(path), "exec")
    path.write_text(content, encoding="utf-8", newline="\n")

def pushed(path):
    return subprocess.check_output(["git","show","origin/master:"+path],cwd=repo)

canonical=pushed(archive_path+"observations.tgz")
prior=json.loads(pushed(archive_path+"archive-receipt.json"))
assert prior["complete"] and prior["allWorkersJoined"] and prior["archivedAndVerifiedUnderLease"]
assert sha(canonical)==prior["archiveSHA256"]
config = load(donor/"config.json")
receipt = load(donor/"archive-receipt.json")
assert all(receipt[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
assert sha((donor/"observations.tgz").read_bytes()) == receipt["archiveSHA256"]
identity = load(donor/"identity.json")
files = identity["imageFiles"]
assert len(files["reference"])==len(files["candidate"])==32
assert files==load(lab/"images.json")["imageFiles"]
for role, expected in files.items():
    assert {name:sha((lab/"frozen"/role/name).read_bytes()) for name in expected}==expected

ssh=["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),
     "-o","BatchMode=yes","-o","ConnectTimeout=15","lokad@20.166.121.73"]
inventory="""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat
b=Path(REMOTE_BASE);p=b/RETIRE_FILE
with (b/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not any(p.is_mount() for p in b.glob('*/guest-fixtures'))
 m=p.lstat()
 assert p.resolve()==p and stat.S_ISREG(m.st_mode) and m.st_nlink==1 and m.st_uid==os.getuid()
 print(json.dumps(dict(bytes=m.st_size,links=m.st_nlink,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),free=shutil.disk_usage(b).free)))
""".replace("REMOTE_BASE",repr(remote_base)).replace("RETIRE_FILE",repr(retire_path))
probe=subprocess.run(ssh+["python3 -c "+shlex.quote(inventory)],capture_output=True,timeout=30)
assert probe.returncode==0,probe.stderr.decode()
found=json.loads(probe.stdout)
assert found["bytes"]==len(canonical) and found["sha256"]==sha(canonical) and found["links"]==1
(lab/"confirmation-inventory.json").write_bytes(probe.stdout)

out.mkdir()
root=remote_base+"/json-positional-control-b1377-20261122"
unit="lython-b1377-json-positional-control-20261122"
identity["purpose"]="Reverse worker order for the adverse B1376 positional-call control"
write(out/"identity.json",json.dumps(identity,indent=2)+"\n")
for name in ("collect.py","archive-owned.py","run.sh","retrieve.py"):
    source=(donor/name).read_text(encoding="utf-8").replace(config["root"],root).replace(config["unit"],unit)
    if name=="collect.py":
        start,end=source.index("\njobs = "),source.index("\nassert len(jobs)")
        source=source[:start]+"\njobs = [('calls.positional.large','warm'),('scripts.report-forwarding.expanded','warm')]"+source[end:]
        source=source.replace("len(jobs)==4","len(jobs)==2").replace("started < 245","started < 130")
        source=source.replace("if job_index % 2 != 0: labels.reverse()", "if job_index % 2 == 0: labels.reverse()")
        source=source.replace("if round%2==0 else", "if round%2!=0 else")
    elif name in ("archive-owned.py","retrieve.py"):
        source=source.replace("jobs=4,","jobs=2,").replace("['jobs']==4","['jobs']==2").replace("len(raw['jobs'])==4","len(raw['jobs'])==2")
    write(out/name,source.replace("B1376","B1377"))
assert b"\r" not in (out/"run.sh").read_bytes()
parts=("identity.json","collect.py","archive-owned.py","run.sh")
payload=out/"payload.tgz"
with tarfile.open(payload,"w:gz") as archive:
    for name in parts:
        archive.add(out/name,arcname=name)
unpacked=sum((out/name).stat().st_size for name in parts)
assert found["free"]+len(canonical)>176160768+unpacked+640*1024
recover=dict(paths=[retire_path],archives={},links=1,bytes=found["bytes"],sha256=found["sha256"])
catalogs={leaf:dict(path=config["root"]+"/"+leaf,sha256=entry["sha256"]) for leaf,entry in config["catalogs"].items()}
stage=dict(root=root,unit=unit,identity=identity,source=config["root"],
           donorArchiveSHA256=receipt["archiveSHA256"],protocolSource=config["protocolSource"],
           protocolSHA256=config["protocolSHA256"],payloadBytes=payload.stat().st_size,
           payloadSHA256=sha(payload.read_bytes()),retireGroups=[recover],catalogs=catalogs,unpackedBytes=unpacked)
write(out/"config.json",json.dumps(stage,indent=2)+"\n")
remote=(donor/"remote-launch.py").read_text(encoding="utf-8")
start,end=remote.index("\nc=")+1,remote.index("\nb=Path(")
remote=remote[:start]+"c="+repr(stage)+remote[end:]
remote=remote.replace(" for n,h in c['sourceFiles'].items():assert sha(source/c['sourceRole']/n)==h,n\n"
                      " assert sha(source/'representative.json')==c['sourceCatalogSHA256']\n",
                      " for role,files in c['identity']['imageFiles'].items():\n"
                      "  for n,h in files.items(): assert sha(source/role/n)==h,n\n")
remote=remote.replace("os.link(source/c['sourceRole']/n,p)","os.link(source/role/n,p)")
remote=remote.replace("RuntimeMaxSec=295","RuntimeMaxSec=180").replace("lython-b1376-fixtures","lython-b1377-fixtures")
assert "sourceRole" not in remote and "sourceCatalogSHA256" not in remote
write(out/"remote-launch.py",remote)
write(lab/"launch-confirmation.py",(lab/"launch.py").read_text(encoding="utf-8").replace("parent/'quiet'","parent/'confirmation'")
      .replace("Direct JSON keyword mapping comparison","Reversed-order positional control").replace("255","146"))
write(lab/"summarize-confirmation.py",(lab/"summarize.py").read_text(encoding="utf-8")
      .replace("/'quiet","/'confirmation").replace("len(raw['jobs'])==4","len(raw['jobs'])==2"))
print("Staged the exact source pair with reversed order, reusing both inputs and one verified archived trace replica.")
