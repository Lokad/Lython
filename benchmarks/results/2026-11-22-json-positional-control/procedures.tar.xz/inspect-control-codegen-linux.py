from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import tempfile
import time

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
catalog = lab.parent/"json-ascii-emission-20261122/inline-catalog.json"
identity = json.loads((lab/"images.json").read_text(encoding="utf-8"))
assert hashlib.sha256(catalog.read_bytes()).hexdigest()==json.loads((lab/"quiet/identity.json").read_text(encoding="utf-8"))["catalogs"]["positional.json"]["sha256"]
case = next(x for x in json.loads(catalog.read_text(encoding="utf-8"))["cases"] if x["id"]=="calls.positional.large")
protocol_path=repo/"benchmarks/cpython-worker.py"
assert hashlib.sha256(protocol_path.read_bytes()).hexdigest()==identity["protocolSHA256"]
spec=importlib.util.spec_from_file_location("worker_protocol",protocol_path)
protocol=importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
out=lab/"control-codegen-linux"
out.mkdir()
sdk=Path.home()/".dotnet"
methods=("ExecuteInstructionPrefix","ExecuteOrdinaryCall","StartNativeCall","TryStartDirectIntegerReturn","TryEvaluateDirectIntegerReturn","TryExecuteNativeCall","TryBeginExecutableCall")

results={}
for entry in ("reference","candidate","candidate-repeat","reference-repeat"):
    role=entry.removesuffix("-repeat")
    image=lab/"frozen"/role
    manifest=identity["imageFiles"][role]
    assert len(manifest)==32 and {n:hashlib.sha256((image/n).read_bytes()).hexdigest() for n in manifest}==manifest
    listing=out/f"{entry}.txt"
    env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"],
             DOTNET_JitDisasm=" ".join(methods),DOTNET_JitStdOutFile=str(listing))
    with (out/f"{entry}.stderr").open("wb") as errors:
        worker=subprocess.Popen([sdk/"dotnet",image/"Lokad.Lython.Benchmarks.dll","--compare","worker","--catalog",catalog],
                                stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors,env=env,cwd=tempfile.gettempdir())
        try:
            ready=protocol.read_frame(worker.stdout)
            core=next(v for v in ready["libraries"] if Path(v["path"]).name=="Lokad.Lython.dll")
            assert core["sha256"].lower()==manifest["Lokad.Lython.dll"]
            assert ready["status"]=="Ready" and ready["catalogSha256"]==hashlib.sha256(catalog.read_bytes()).hexdigest()
            requests=[]
            def request(op, count):
                seq=len(requests)+1
                ordered=("sourceSha256","fixtureSha256","expectedOutputSha256")
                fields={n:case[n] for n in ordered}
                protocol.write_frame(worker.stdin,dict(fields,protocolVersion=2,requestId=seq,
                    operation=op,caseId=case["id"],lane="warm",iterations=count))
                response=protocol.read_frame(worker.stdout)
                assert response is not None and response["requestId"]==seq and response["completedInvocations"]==count
                assert response["status"]==("Equivalent" if op=="verify" else "Completed")
                assert response["actualOutputSha256"]==case["expectedOutputSha256"]
                requests.append(dict(operation=op,status=response["status"],completed=count))
            request("verify",2)
            end=time.monotonic()+7
            while time.monotonic()<end:
                request("batch",64)
            request("verify",2)
            protocol.write_frame(worker.stdin,dict(protocolVersion=2,requestId=len(requests)+1,operation="quit"))
            assert protocol.read_frame(worker.stdout)["status"]=="Closed" and worker.wait(timeout=10)==0
        finally:
            if worker.poll() is None:worker.kill();worker.wait()
            worker.stdin.close();worker.stdout.close()
    assert listing.is_file() and listing.stat().st_size and (out/f"{entry}.stderr").stat().st_size==0
    records={}
    for block in listing.read_text(encoding="utf-8",errors="strict").split("; Assembly listing for method ")[1:]:
        head=block.splitlines()[0].strip()
        size=re.search(r"; Total bytes of code (\d+)",block)
        assert size,head
        ops=[]
        for line in block.splitlines()[1:]:
            if line.startswith("       "):
                normalized=re.sub(r'(?i)(?:0x|\b)[0-9a-f]{9,}h?\b',"<address>",line.strip())
                ops.append(normalized)
        key=head.split(" (")[0]+" ("+head.split(" (")[-1]
        records.setdefault(key,[]).append(dict(codeBytes=int(size.group(1)),instructions=len(ops),
            normalizedInstructionSHA256=hashlib.sha256("\n".join(ops).encode()).hexdigest()))
    results[entry]=dict(exactCore=core["sha256"],requests=requests,compiledMethods=records)
summary=dict(case=case["id"],normalTiering=True,platform="WSL Linux x64",
    timingComparison=False,results=results,methods=sorted(set(results["reference"]["compiledMethods"])|set(results["candidate"]["compiledMethods"])))
(out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
for name in summary["methods"]:
    rows=[results[r]["compiledMethods"].get(name) for r in ("reference","candidate","candidate-repeat","reference-repeat")]
    sizes=[[record["codeBytes"] for record in row or []] for row in rows]
    print(name.split('(')[0],name.split(' (')[-1],sizes,"same image matches",rows[0]==rows[3],rows[1]==rows[2])
