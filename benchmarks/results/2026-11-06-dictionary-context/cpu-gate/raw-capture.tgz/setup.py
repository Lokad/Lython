from pathlib import Path
import hashlib,json,os,shutil
root=Path('/home/lokad/lython-bench-checks/whole-script-cost-b349-20261106');base=Path('/home/lokad/lython-bench-checks/context-transport-b348-20261106/candidate')
folder=root/'candidate';folder.mkdir()
for f in base.iterdir():
    if f.name=='Lokad.Lython.pdb':continue
    if f.name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json']:
        os.link(f,folder/f.name)
    else:(folder/f.name).symlink_to(f.resolve(),target_is_directory=f.is_dir())
i=json.loads((root/'identity.json').read_text())
for name,digest in i['files'].items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest
assert shutil.disk_usage(root).free>16*1024*1024
print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,files=i['files'])))
