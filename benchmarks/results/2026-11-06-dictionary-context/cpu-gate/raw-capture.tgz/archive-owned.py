from pathlib import Path
import hashlib,json,os,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/whole-script-cost-b349-20261106');records=[]
for phase in ['before','after']:assert json.loads((root/f'machine-{phase}.json').read_text())['gate']['quiet']
assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
for name in ['text','csv']:
    folder=root/'perf'/name;r=json.loads((folder/'record.json').read_text());records.append(r)
    assert r['exitCode']==0 and r['verificationBefore']['status']=='Equivalent' and r['verificationAfter']['status']=='Equivalent'
    assert r['closed']['status']=='Closed' and r['response']['status']=='Completed'
    data=folder/'perf.data';assert not data.is_symlink() and data.resolve().is_relative_to(root)
    if data.stat().st_uid!=os.getuid():subprocess.run(['sudo','-n','chown',f'{os.getuid()}:{os.getgid()}',str(data)],check=True)
    subprocess.run(['python3',str(root/'analyze-cpu-guest.py'),str(folder)],check=True,timeout=20)
    assert not (folder/'worker.stderr').read_text().strip()
with tarfile.open(root/'raw-capture.tgz','w:gz') as t:
    for f in root.iterdir():
        if f.name not in ['candidate','raw-capture.tgz']:
            if f.is_dir():
                for p in f.rglob('*'):
                    if p.is_file():t.add(p,arcname=str(p.relative_to(root)))
            elif f.is_file():t.add(f,arcname=f.name)
receipt=dict(complete=True,workloads=2,allUsersJoined=True,fixturesRemoved=True,quietBeforeAfter=True,
    archiveSHA256=hashlib.sha256((root/'raw-capture.tgz').read_bytes()).hexdigest(),
    guestCpuSeconds={r['workload']:sum(x['seconds'] for x in r['threadCpuSeconds'] if x['tid'] in r['guestTids']) for r in records})
(root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
