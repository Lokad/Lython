# Lokad.Lython 0.11.0

Updated2026-11-06. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Another isolated experiment, allocation reduction or local deletion does not
complete that objective. Current performance/qualification evidence is separate.

## Actual delivery state

- Last fully qualified runtime **9a152ee0** (R13 B). Terminal CI **42228235593**
  is GREEN/all eight major Windows/Ubuntu, .NET11/.NET10, package and original
  Stress gates. Cached in benchmarks/results/2026-11-06-deferred-contexts/.
  Never query that terminal run again; earlier terminal receipts remain cached.
- **abe0defb** updates the representative CPython guide. Its installed Release
  package consumers pass on actual.NET11RC3 and.NET10.0.8; core dependencies
  empty, optional adapter nonpackable. Outputs only in artifacts/nuget/. No publish.
- Current runtime **66ae029d** (R13 C) removes duplicate scope transport from
  publication. Both-target build0warnings; focused526internal/1,508public per
  actual runtime and B348 whole-script checks pass. Full B qualification does
  not qualify C. Batch C platform/stress/installed consumers with the next
  meaningful runtime delivery, rather than repeating unchanged full checks.
- No live local build/test, CI run or VM collection. B346/B347/B348 are terminal,
  archived and verified; all workers joined and fixtures removed. Programs and
  storage outlive actual users. Source snapshots were not timestamp-restored.

Evidence/history: benchmarks/EXPERIMENTS.md and benchmarks/results/. Earlier plans
and source-gate notes are retained in .git/agent-notes/review-20261031/.
docs/ remains concise/current implementation, not experimental narrative.

## Completed work to preserve

| Milestones | Delivered implementation / evidence |
| --- | --- |
| Compiler facts, direct UTF8, native helper returns | Shared compiler/class-cell correction retained. Native returns allocation−19.92%/−19.31%, elapsed diagnostic; formatting allocation−8.67%, controlledB102 elapsed/CPU−5–8%, original adverse15.125ms unexplained. Historical qualified source pairs, not current-head allocation claims. |
| K01, F02–F05 | One dict/set entry authority; weak/scalar/reclamation machinery gone. One invocation/lexical context, final argument/local storage, shared scope facts, lazy namespaces, receiver/function in operands. No restored copy/arena layers. |
| Q01, R02/R04 | One contextual key preparation, active structural cycle path and final tuple backing. Their affected-workload gains do not compound into a broad CPU claim. |
| R03/R05, Q02, R07 | Shared whitespace/ASCII processing, actual builtin class semantics, async hash/native reads and one native-key proof. Async text debt remains source-scoped. |
| R06/R09/R10 | Shared class extraction, constructor sequence and existing frame runner; Python correctness/retained packets preserved. Original adverse class/source pairs and accepted debt retained. No constructor speedup claim. |
| R12, R13 A/B | Current allocation origins selected context work, not universal value rewriting. Executable frame base/constructors/hidden dispatch removed; one inline work state. B defers eligible helper contexts through the actual instruction switch and adopts existing IP/locals/storage. Native writes promote before growth/admission; one publication helper. No second interpreter/owner/pool. Fully qualified9a152ee0. |
| R13 C | Owned operand services replace the duplicate defining-scope publication argument. NoInlining/liveness, current lexical stores, first refusal and disposal order preserved. Keep the simpler transport; broad performance objective remains open. Focused/measurement qualified66ae029d. |

## Measurement state and explicit debt

Primary guide docs/BENCHMARKS.md measures **9a152ee0/B347**, frozen core1daf56c3
whose normalized production sources match the commit. Fresh Lython/CPython:
CSV1.37–1.38x, text1.88–1.94x, JSON1.20–1.24x, report1.46–1.51x. Compile, warm
and fresh are separate. Mediated RAM I/O, complete validation and prior-result
cleanup included; fresh adds compile/disposal. Startup/staging/reset/transport/
final teardown excluded. CPython imports persist, Lython imports are isolated.
Actual suspended-I/O latency, RSS and embedding latency remain unmeasured.

- **B346** original prototype:12jobs/228.43s, modest CSV gains, adverse text/JSON/
  report, conflicting CPU and18% identical compiler-control divergence. Original
  Slice failure (4,259internal pass;16,185public pass/one fail) and correction
  retained. Source/measurement refinement was justified; uncertainty was not
  treated as a failed design. Final Slice/shared-write/class-cell controls pass.
- **B347** corrected B:12jobs/328.10s, five-second warmup. CSV warm elapsed
  −5.85/−6.24%, fresh−5.53/−5.83% versus88; warm CSV CPU flat. Warm text
  +3.40/+6.45%, JSON mixed/adverse, report variable; identical roles still vary
  2–4% on several jobs. Retain architecture with explicit debt, not broad CPU gain.
- **B348** C:5jobs/139.83s versus9a. CSV effectively flat; text−1.93/−3.64%,
  JSON−1.14/−2.23%, report+2.63/+0.67% with1.91% identical-role split. Retain the
  deletion; uncertainty/report debt and the larger objective remain. Do not
  compound these source pairs or claim a measured allocation reduction.

## Active: R14 explicit dictionary-operation context

B349 completed the bounded current-source gate: two approximately two-second
CPU captures, text/helpers896 and CSV/functions480, runtime66ae029d/frozen977da8d6.
Raw traces, own-process maps/listings and terminal receipt are verified locally;
all goldens, quietness, funding, worker joins and fixture cleanup passed.
These instrumented captures attribute cost; they do not measure an improvement.
Namespace mirroring is not a dominant sampled phase: defer that hypothesis and
preserve the annotation/lambda lifetime correction. CSV has30 leaf TLS samples
among419, including native dictionary/subscript work; text has6 among414.

Selected hypothesis: explicit dictionary reads and already-funded string-key
writes can own contextual provenance once, removing ambient installation and
rediscovery from native operations. Affected scripts: CSV aggregation and text
word counts. Remove caller PushAmbient/implicit lookup in these paths; keep the
existing table, key proof, protocol algorithms and general mutation route. This
does not justify universal value/frame changes or removing cancellation checks.

Acceptance: preserve hash/equality callback order and reentry, error spans and
cancelable missing-key rendering, async protocol I/O, first refusal, retained
aliases, iteration versions, cycles and cleanup. Use focused Release regressions
on both runtimes, then one short CSV warm/fresh plus text/JSON/report warm source
pair versus66 with unchanged controls. Decide explicitly on any regression debt.
Batch C+retainedR14 full platform/stress/package checks at that delivery boundary.

### Completed source/cost gate

Stop further narrow transport tuning without evidence of a dominant removable
phase. Use the existing source/profile evidence and at most one short current
capture (representative text/CSV, about2s each) if needed. Reuse frozen workers,
collector/readers, actual guest TIDs/JIT maps, full goldens/funding/quiet/joins;
archive raw traces persistently before owned collection ends. No new framework.

Specific source lead: typed module helpers emit ExecutableAnnotationsEnabled;
the conservative moduleAnnotationNamespace rule can mirror subsequent local
stores into Variables. Lambda retention has a separate live-namespace contract.
This is real code, not proof of dominant cost or permission to remove correctness
guards. Inspect actual CPU/slot/store paths and namespace lifetimes before selecting
a redesign; preserve the compiler-fact correction and its retained-scope fixes.

If dominant, assess one coherent module binding/publication lifetime: avoid repeated
duplicate stores while using existing slots/scopes, with surviving namespace
capacity funded before allocation. Expected displacement must identify the precise
mirroring propagation/store path removed. Acceptance must preserve live globals
aliases, annotations/lambdas/generators, imports/class bodies, ordinary errors,
first refused admission, cancellation and awaited cleanup. No snapshot allocation
after terminal refusal, unfunded aliases, new tracing or dual namespace framework.
If this requires broader lifetime machinery or CPU evidence is weak, stop that
hypothesis and select a different dominant phase from the roadmap below.

The gate ends with one sourced proposal or explicit deferral. Before coding a
selected redesign, state its hypothesis, eliminated work/storage, affected complete
scripts, semantic acceptance and displaced implementation. Then focused Release
checks and one bounded before/after with unchanged controls; refresh all CPython/
platform/stress/packages only at the next meaningful retained boundary. Temporary
regression debt needs an explicit completion milestone and decision, not silence.

## Further redesign choices (evidence required)

| Area | Current facts and bounded acceptance |
| --- | --- |
| Calls/frames | Arguments already bind final locals; ordinary constructors use existing frames. Text/JSON/report helpers already use NativeReturn, so always-promoting helper setup does not explain those controls. Do not add speculative CFG inventories/passes. Preserve dynamic binding, globals/class cells, real suspension and ownership. |
| Operand/scalar values | BigInteger boxes and dispatch exist, but small BigInteger magnitudes are compact. CPU dominance must select a contained removal before a tagged-value commitment. Preserve exact overflow promotion, identity/aliases and public projection. B61 call records and B69 arenas actually measured slower; do not rename/replay them. |
| Record construction | B150 bulk CSV retained (~10% variable width, peak+63,648B); original6–8% misses kept. B01 cached layouts flat/small, shared keys need substantial mutation/iterator machinery. Reopen only for distinct removable work; ordinary/variable CSV, JSON records and unchanged text controls, preserving order/reentry/aliases/overlap. |
| Text | NativeUTF8 JSON/formatting and fused case/whitespace splitting already exist. R12 allocation ticks are approximate triggering-type attribution, not exact/live/CPU fractions. Inspect actual remaining conversions/metadata; do not propose the same fusion again or reintroduce string-window retention debt. Unicode/callback/cancellation/ownership controls required. |
| Frontend/setup | Compiler facts shared/corrected; compilation is smaller than execution here. Assess immutable call layout/signatures separately from mutable defaults/namespaces. Remove actual per-definition rebuilding if selected; preserve annotations, closures, defaults mutation, diagnostics and compile cancellation. No speculative JIT/compiler rewrite. |
| Imports (later separate milestone) | Consolidate import execution onto the existing executable path, retaining lowered evaluation where classes/annotations/opcode fallbacks still need it. Preserve grants, paths/Cwd, module isolation/caching, Python errors, cancellation and memory ownership; not a general compiler rewrite. |

## Independent regex development

Core owns one Python-specific nativeUTF8 contract across frontend/runtime/imports/
helpers: flags/effective capture analysis, names, byte/scalar ranges, original
windows, replacements/errors, cache ownership and current-operation cancellation.
Missing published producer APIs defer only affected final adapter qualification.
Development pins/adapter-local bridges are allowed; never add backend edges to core.

Normal adapter0.4 stays nonpackable. Private dev40 range-only source (producer
6f6fdab9; Core packageeb5d3ad4/PythonRe31c8d9f2) was qualified against runtime88,
not current HEAD:84internal/421public per actual runtime, real in-flight compile/
match/cursor cancellation, refusal/retention/reuse. Direct-token prototype allocated
+2.29%; selected range-only/local-token-bridge−22.81% on the same producer.
Elapsed diagnostic; no whole-script/released-backend/safety promotion claim.

Precise token gap: creation cancellation must not remain authority over independent
later advances. Creation validates whole input, so None+boundary checks is invalid.
Keep the local bridge until the producer distinguishes these operations. Native
UTF8 names still bridge strings; one-shot ranges/working/cache receipts/reversed
windows need exact API/semantic assessment, not inherited blanket blockers.
Continue contract/core work independently; final adapter against an immutable
released package when available. No sibling edits or automatic promotion.

## Execution and experiment rules

Timeouts/unstable controls/inconclusive runs establish uncertainty. Allow bounded
confirmation, refinement and measurement correction with a concrete reason; retain
all original/adverse conditions. No blanket one-attempt/no-retiming/permanent bans.
Percentages inform decisions; distinguish simplification, allocations and CPU.

Use focused Release regressions, both runtimes when affected. Batch full Windows/
Ubuntu, original Stress and installed consumers at meaningful boundaries. No
overlapping local builds/tests; after timestamp-preserving source restoration force
a nonincremental build. Reuse valid qualification and cached terminal CI receipts.

Quiet VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem. Lease/frozen worker/
actual loaded hashes/owned cleanup mandatory. Disk near full: preflight transfer,
expanded payload and archive headroom. Only hash-verified redundant owned transfers
with retained local copies/terminal owners may be removed; never sole evidence,
dependencies or runtime images. B348 setup had12.8MB free; preflight again next use.

Follow AGENTS.md. Fully managed/memory-safe: no unsafe/Unsafe/pointers/PInvoke/native
stack probing. Preserve managed stack/recursion, host capabilities/paths, cycles,
CancellationToken authority and borrowed shared admission/capacity/replacement/
retained aliases/pending users. No fuel, quotas/watchdogs/hidden caps, tracing/weak
reclamation/forced GC or new memory infrastructure. First refused admission is
terminal; never retry/fallback; await actual cleanup. Scope creation reserves
nothing; bounded host-driven streaming, no guest-heap tracing. No publication/tag.
