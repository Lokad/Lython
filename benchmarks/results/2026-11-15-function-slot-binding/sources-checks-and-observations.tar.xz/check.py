from pathlib import Path
import json,os,re,subprocess,sys

r=Path(__file__).parent;sdk='C:/Users/JoannesVermorel/.dotnet11'
env={k:v for k,v in os.environ.items()if k.casefold()!='path'}
env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';'+next(v for k,v in os.environ.items()if k.casefold()=='path')
internal='(FullyQualifiedName~Executable|FullyQualifiedName~FunctionWorkspaceOwnershipTests|FullyQualifiedName~CasedSplitOwnershipTests|FullyQualifiedName~FunctionBodyTemporaryLifetimeTests|FullyQualifiedName~CapturedScalarObservationTests|FullyQualifiedName~CompletedHelperCallOwnershipTests|FullyQualifiedName~DeferredFunctionOwnershipTests|FullyQualifiedName~ComposedNativeCallTests|FullyQualifiedName~FunctionClassCellBoundaryTests)&Category!=Stress'
public='(FullyQualifiedName~Native|FullyQualifiedName~Binding|FullyQualifiedName~FunctionDefault|FullyQualifiedName~FunctionSlot|FullyQualifiedName~PositionalCallSemanticsTests|FullyQualifiedName~PreparedCallArgumentTests|FullyQualifiedName~OrdinaryFunctionCallTests|FullyQualifiedName~OrdinaryMethodCallTests|FullyQualifiedName~OrderedFunctionContinuationTests|FullyQualifiedName~DeferredFunctionContextTests|FullyQualifiedName~FunctionInputLifetimeTests|FullyQualifiedName~CallInputLifetimeTests|FullyQualifiedName~CapturedScalarExecutionTests|FullyQualifiedName~TransitiveClosureCompatibilityTests|FullyQualifiedName~StackGuardScenarioTests|FullyQualifiedName~RenderingStackAdmissionTests|FullyQualifiedName~AdmissionFailureCommandTests|FullyQualifiedName~AsyncMidFlightCancellationTests)&Category!=Stress'
rows=[];prefix=sys.argv[1]+'-' if len(sys.argv)>1 else ''
for framework in ['net11.0','net10.0']:
 for project,filtertext in [('Lokad.Lython.Tests',internal),('Lokad.Lython.PublicApi.Tests',public)]:
    log=r/(prefix+project+'-'+framework+'.log');assert not log.exists()
    with log.open('w',encoding='utf-8',newline='\n')as stream:
        result=subprocess.run([sdk+'/dotnet.exe','test','tests/'+project+'/'+project+'.csproj','-c','Release','-f',framework,'--no-restore','--nologo','--filter',filtertext],env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=240)
    summaries=[s for s in log.read_text(encoding='utf-8').splitlines()if 'Passed!'in s or 'Failed!'in s]
    print(project,framework,result.returncode,summaries,flush=True)
    assert result.returncode==0 and len(summaries)==1 and 'Failed:     0'in summaries[0]
    rows.append(dict(project=project,framework=framework,passed=int(re.search(r'Passed:\s+(\d+),',summaries[0])[1]),log=log.name))
(r/(prefix+'focused-checks.json')).write_text(json.dumps(dict(complete=True,checks=rows,fullQualificationPending=True,prototype=True,publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
