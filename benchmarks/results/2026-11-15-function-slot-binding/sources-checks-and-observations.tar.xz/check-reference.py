from pathlib import Path
import hashlib,json,shutil,subprocess

r=Path(__file__).parent;sdk='C:/Users/JoannesVermorel/.dotnet11/dotnet.exe'
for count in [4,65,130]:
    last=count-1;parameters=','.join(f'p{i}={i}'for i in range(count))
    source=f"def f({parameters}, *, option='default'):\n return p0, p{last}, option\nprint(f(None, p{last}=None, option=None))\nprint(f())\ntry: f(*range({count}), p0=None)\nexcept TypeError: print('duplicate')\nf.__defaults__=None\ntry: f()\nexcept TypeError: print('missing')\nf.__defaults__=tuple(range({count}))\nf.__kwdefaults__=dict(option=None)\nprint(f())\n"
    expected=f"(None, None, None)\n(0, {last}, 'default')\nduplicate\nmissing\n(0, {last}, None)\n"
    done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],capture_output=True,text=True,encoding='utf-8',timeout=10)
    assert done.returncode==0 and done.stdout==expected,(count,done.stdout,done.stderr)
    (r/f'python-control-{count}.json').write_text(json.dumps(dict(source=source,expected=expected,actual=done.stdout,version='CPython3.13.2',returncode=done.returncode),indent=2)+'\n',encoding='utf-8',newline='\n')
target=r/'reference-tests';shutil.copytree('tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0',target)
shutil.copyfile(r/'reference/Lokad.Lython.dll',target/'Lokad.Lython.dll')
assert hashlib.sha256((target/'Lokad.Lython.dll').read_bytes()).hexdigest().startswith('716176a8')
with(r/'reference-duplicate-failure.log').open('w',encoding='utf-8',newline='\n')as stream:
    done=subprocess.run([sdk,'vstest',str(target/'Lokad.Lython.PublicApi.Tests.dll'),'/TestCaseFilter:FullyQualifiedName~FunctionSlotBindingTests'],stdout=stream,stderr=subprocess.STDOUT,timeout=60)
text=(r/'reference-duplicate-failure.log').read_text(encoding='utf-8')
assert done.returncode==1 and 'Failed:     3'in text and 'duplicate'in text,text[-3500:]
print('All3CPython controls pass; qualified7161 fails the same3duplicate-argument cases. Existing bug confirmed, not a slot-migration regression.',flush=True)
