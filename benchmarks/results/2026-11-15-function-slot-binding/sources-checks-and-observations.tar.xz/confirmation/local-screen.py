from pathlib import Path
import contextlib,hashlib,importlib.util,json,math,os,statistics,subprocess,tempfile,time
r=Path(__file__).parent;sdk='C:/Users/JoannesVermorel/.dotnet11'
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert not(r/'local-screen.json').exists()
env={k:v for k,v in os.environ.items()if k.casefold()!='path'};env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';C:/Python313;'+next(v for k,v in os.environ.items()if k.casefold()=='path')
assert not any(k.startswith(('DOTNET_','COMPlus_'))and k!='DOTNET_ROOT'for k in env)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('protocol','benchmarks/cpython-worker.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
catalog=(r/'catalog.json').resolve();cases={c['id']:c for c in json.loads(catalog.read_text(encoding='utf-8'))['cases']}
out=dict(complete=False,identityCoreSHA256=identity['coreSHA256'],identityFile='candidate-identity.json',location='Local Windows development box; no quiet-machine or portable CPU claim. Same frozen sources and original driver with12sfull-request warmups and.35srequest batches; correct measurement uncertainty, no causal warmup/CPU attribution.',warmupBoundary='full request wall time',elapsedBoundary='Unchanged command-v2 warm: mediated filesystem I/O/full stdout-file validation/prior-result cleanup; excludes compile/startup/reset/protocol/final cache. Fresh adds compile/compiled-owner disposal. No CPU/heap/tail claim.',jobs=[])
def save():(r/'local-screen.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
class Worker:
 def __init__(self,label,case,lane,stack):
  self.label,self.case,self.lane,self.seq,self.process=label,case,lane,0,None
  self.fixture=tempfile.TemporaryDirectory(prefix='lython-comparison-files-');self.errors=tempfile.TemporaryFile();stack.callback(self.close)
  role='candidate'if label.startswith('candidate')else'reference'
  self.process=subprocess.Popen([sdk+'/dotnet.exe',str((r.parent/role/'Lokad.Lython.Benchmarks.dll').resolve()),'--compare','worker','--catalog',str(catalog)],cwd=self.fixture.name,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.errors)
  self.ready=protocol.read_frame(self.process.stdout);assert self.ready and self.ready['status']=='Ready',self.ready
  assert self.ready['catalogSha256']==sha(catalog)
  for name,h in identity['frozenFiles'][role].items():
   library=next((v for v in self.ready['libraries']if Path(v['path']).name==name),None)
   if library:assert library['sha256'].lower()==h
  self.request('verify',2)
 def request(self,op,count):
  self.seq+=1;q={k:self.case[k]for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']};q.update(protocolVersion=2,requestId=self.seq,operation=op,caseId=self.case['id'],lane=self.lane,iterations=count)
  start=time.monotonic();protocol.write_frame(self.process.stdin,q);res=protocol.read_frame(self.process.stdout);self.lastSeconds=time.monotonic()-start
  assert res and res['status']==('Equivalent'if op=='verify'else'Completed'),res
  assert res['completedInvocations']==count and res['actualOutputSha256']==self.case['expectedOutputSha256']and res['actualFilesSha256']==self.case.get('expectedFilesSha256')
  return res
 def close(self):
  try:
   if self.process:
    if self.process.poll()is None:
     protocol.write_frame(self.process.stdin,dict(protocolVersion=2,requestId=self.seq+1,operation='quit'));assert protocol.read_frame(self.process.stdout)['status']=='Closed'
    assert self.process.wait(timeout=10)==0
    self.errors.seek(0);assert not self.errors.read()
  finally:
   if self.process:
    if self.process.poll()is None:self.process.kill();self.process.wait()
    self.process.stdin.close();self.process.stdout.close()
   self.errors.close();self.fixture.cleanup()
started=time.monotonic();save()
jobs=[('scripts.file-search.large.protected','warm'),('scripts.report-render.large','warm'),('scripts.csv-fulfillment.large','warm')]
for caseId,lane in jobs:
 assert time.monotonic()-started<220,'Bounded source screen ended; preserve observations and joined cleanup.'
 with contextlib.ExitStack()as stack:
  workers=[Worker(label,cases[caseId],lane,stack)for label in ['reference','candidate','candidate-control','reference-control']]
  counts=[];warmups=[]
  for w in workers:
   assert not w.ready['serverGc']
   count=1;end=time.monotonic()+12;rows=[]
   while time.monotonic()<end:
    rows.append(w.request('batch',count));count=max(1,min(100000,math.ceil(count*.35/max(w.lastSeconds,.000001))))
   counts.append(count);warmups.append(rows)
  samples=[]
  for round in range(5):
   for i in [(round+offset)%4 for offset in range(4)]:samples.append(dict(round=round,label=workers[i].label,response=workers[i].request('batch',counts[i])))
  med={w.label:statistics.median(1000*x['response']['elapsedTicks']/x['response']['clockFrequency']/x['response']['completedInvocations']for x in samples if x['label']==w.label)for w in workers}
  result=dict(case=caseId,lane=lane,identities={w.label:w.ready for w in workers},counts=counts,warmups=warmups,samples=samples,medianMilliseconds=med,changePercent=sorted(100*(med[a]/med[b]-1)for a in ['candidate','candidate-control']for b in ['reference','reference-control']))
 result['allWorkersJoinedAndFixturesRemoved']=True;out['jobs'].append(result);save();print(caseId,lane,med,result['changePercent'],flush=True)
out.update(complete=True,elapsedSeconds=time.monotonic()-started,allGoldensAndBudgetsPassed=True,allUsersJoined=True,portablePerformanceClaim=False);save()
print('Completed bounded local source screen; all processes joined and fixtures closed. Diagnostic elapsed only; no CPU or quietVM qualification.',flush=True)
