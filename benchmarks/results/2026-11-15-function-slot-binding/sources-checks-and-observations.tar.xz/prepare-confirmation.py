from pathlib import Path
import ast,hashlib,json,shutil

r=Path(__file__).parent;o=r/'confirmation';o.mkdir(exist_ok=True)
assert not(o/'local-screen.py').exists() and not(o/'local-screen.json').exists()
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((r/role/name).read_bytes()).hexdigest()==sha for role,files in identity['frozenFiles'].items()for name,sha in files.items())
for name in ['candidate-identity.json','catalog.json']:shutil.copyfile(r/name,o/name)
s=(r/'local-screen.py').read_text(encoding='utf-8')
old="str((r/role/'Lokad.Lython.Benchmarks.dll').resolve())";assert s.count(old)==1
s=s.replace(old,"str((r.parent/role/'Lokad.Lython.Benchmarks.dll').resolve())")
a=s.index('\njobs=')+1;b=s.index('\nfor caseId,lane',a)
s=s[:a]+"jobs=[('scripts.file-search.large.protected','warm'),('scripts.report-render.large','warm'),('scripts.csv-fulfillment.large','warm')]"+s[b:]
s=s.replace('time.monotonic()+2.5','time.monotonic()+12').replace('count*.15/','count*.35/')
s=s.replace('Function-slot binding construction/transport diagnostic; no CPU or allocation attribution.','Same frozen sources and original driver with12sfull-request warmups and.35srequest batches; correct measurement uncertainty, no causal warmup/CPU attribution.')
ast.parse(s);(o/'local-screen.py').write_text(s,encoding='utf-8',newline='\n')
(o/'prospective.json').write_text(json.dumps(dict(reason='Original report candidate control moves15.2% and adverse pair reaches23.7%; fulfillment control also moves. Preserve original conditions. No runtime change.',allFrozenImageFilesVerified=True,warmupSeconds=12,targetRequestSeconds=.35,jobs=3,portableCPUClaim=False,failedPreparation='An initial shell quoting error occurred before creating this directory or launching any worker.'),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Same-image bounded confirmation prepared; all components verified.',flush=True)
