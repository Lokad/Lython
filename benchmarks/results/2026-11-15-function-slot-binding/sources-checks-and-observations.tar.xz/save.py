from pathlib import Path
import hashlib,io,json,shutil,subprocess,tarfile

root=Path.cwd();r=Path(__file__).parent;out=root/'benchmarks/results/2026-11-15-function-slot-binding';out.mkdir()
first=json.loads((r/'local-screen.json').read_text(encoding='utf-8'));confirm=json.loads((r/'confirmation/local-screen.json').read_text(encoding='utf-8'))
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));checks=json.loads((r/'corrected-focused-checks.json').read_text(encoding='utf-8'))
assert first['complete']and confirm['complete']and len(first['jobs'])==8 and len(confirm['jobs'])==3
assert all(x['allUsersJoined']and x['allGoldensAndBudgetsPassed']for x in [first,confirm])
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert all(sha(p)==h for p,h in identity['sources'].items())
assert all(sha(r/role/name)==h for role,files in identity['frozenFiles'].items()for name,h in files.items())
# Reconstruct immutable measured images from committed prior cores/auxiliaries
# plus the new core, rather than archive unchanged worker assemblies repeatedly.
old=root/'benchmarks/results/2026-11-15-shared-prefix-prototype'
with tarfile.open(old/'owned-metadata-refinement.tar.xz')as aux,tarfile.open(old/'initial-and-routing-refinement.tar.xz')as previous:
    assert hashlib.sha256(previous.extractfile('qualified-reference/Lokad.Lython.dll').read()).hexdigest()==identity['coreSHA256']['reference']
    for name,h in identity['auxiliaryFiles'].items():assert hashlib.sha256(aux.extractfile('owned-metadata-refinement/reference/'+name).read()).hexdigest()==h,name
def observations(run):return [dict(case=j['case'],phase=j['lane'],changePercent=j['changePercent'],processMedianMilliseconds=j['medianMilliseconds'])for j in run['jobs']]
decision=dict(status='retain',reason='Remove redundant function-presence construction/overflow/marking/transport and fix proven Python duplicate-binding defect. No new dispatcher/cache/policy. CPU magnitude remains diagnostic.',core=identity['coreSHA256'],initialElapsedSeconds=first['elapsedSeconds'],confirmationElapsedSeconds=confirm['elapsedSeconds'],focused=checks['checks'],initial=observations(first),confirmation=observations(confirm),fullQualificationPending=True,publicationHeld=True,
    acceptedDebt='Initial short helpers +0.49..+2.48%local elapsed. Other original controls move; report adverse up to23.72%not reproduced with longer warmup, but original condition and unexplained cause remain. No whole-script allocation/portableCPU/CPython/heap/tail claim.',
    correctness='Qualified7161 and initial migrated source fail all3wide/None duplicate tests; CPython3.13.2controls reject. Dynamic positional fill now rejects already-bound slots. All original semantic/ownership assertions retained.',
    unresolvedFixture='One initial net11native-call-continuation fixture exited7 without stdout in its failure message. Direct reference/candidate reproductions and subsequent focused actual11/10pass. Cause unestablished; failure retained and diagnostic stdout added, assertions/deadlines/stacks unchanged.',
    imagesReconstructible=True,allUsersJoined=True,allGoldensAndBudgetsPassed=True)
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(r/'decision.json',out/'summary.json')
files=[p for p in r.iterdir()if p.is_file()and p.suffix in {'.py','.json','.log','.xz'}]
files += [r/'candidate-core.dll']
files += [p for p in (r/'confirmation').iterdir()if p.is_file()and p.suffix in {'.py','.json','.log'}and p.name!='catalog.json']
files += [root/'tests/Lokad.Lython.PublicApi.Tests/FunctionSlotBindingTests.cs',root/'tests/Lokad.Lython.PublicApi.Tests/StackGuardScenarioTests.cs',root/'tests/Lokad.Lython.Tests/FunctionWorkspaceOwnershipTests.cs',root/'tests/Lokad.Lython.Tests/ExecutableAsyncIteratorCleanupTests.cs',r.parent/'migrate-function-slot-binding-r384.py']
def archive_name(p):return p.relative_to(r).as_posix() if p.is_relative_to(r) else p.relative_to(root).as_posix() if p.is_relative_to(root/'tests') else p.name
archive=out/'sources-checks-and-observations.tar.xz'
with tarfile.open(archive,'w:xz')as tar:
    for p in files:tar.add(p,arcname=archive_name(p))
with tarfile.open(archive)as tar:
    for p in files:assert hashlib.sha256(tar.extractfile(archive_name(p)).read()).hexdigest()==sha(p),p
(out/'README.md').write_text('''# Final-slot function binding

2026-11-15. Retained candidate frozen **8fbfa3f0** versus qualified
**a7ab41f5 /716176a8**. Full changed-runtime platform/stress/package qualification
is pending. Publication remains held.

Function binding now uses the existing unassigned-slot sentinel rather than a
parallel ArgumentPresence. Python None remains an ordinary non-null guest value.
Remove function presence creation, marking loops, >64-parameter overflow arrays,
the allocation-failure shell used solely for that overflow, and presence transport
through completed binding, native entry and continuation. Completed arguments carry
only final storage, logical parameter count and their existing owner. Builtins
retain their necessary object-array omission metadata. No new cache, dispatcher,
allowance, quota or ownership policy; preflights, aliases and awaited cleanup remain.

The new public narrow/65/130-parameter controls also expose an existing Python
bug: a starred positional value could overwrite a previously supplied keyword.
Qualified7161 and the first migrated source fail the same three cases; CPython
3.13.2 rejects them. The shared dynamic fill now checks the destination before
writing. Keep None/omission, replaced defaults, failed binding, clean reuse and
budget-baseline assertions for both hosting APIs. No public API change beyond
correctly rejecting those duplicate arguments.

Focused Release: **452 internal /2,396 public on each actual .NET11/10** pass,
covering binding/default protocols, methods, closures/generators, real suspension,
cancellation/refusal, stack protection, aliases, transfer and cleanup. One initial
native-call-continuation fixture exit7 is preserved. Direct reference/candidate
reproduction and subsequent focused checks pass; cause remains unestablished.
Failure messages now include existing fixture stdout; no assertions, stack sizes
or deadlines changed. Initial test-string/preparation errors occurred before their
affected checks/collection and were corrected without changing runtime policy.

The first eight-job local Windows comparison completes122.508s, two independent
processes per source, 2.5sfull-request warmups and five rotating~.15srequest batches.
All goldens, ownership, close, join and fixture-cleanup gates pass. File search is
lower across pairings, but report reaches+23.72%with a moving15.2%candidate control;
fulfillment/text/JSON/observed controls are mixed. Short helpers+0.49–2.48%is a
recorded local debt accepted for the state removal and correctness correction.

That uncertainty justifies one changed-measurement confirmation on the same
verified images: three affected whole scripts,12sfull-request warmups and~.35s
batches. File search−9.66..−2.36%with a moving reference; report−3.96..−1.72%with
closer controls; fulfillment−2.70..+1.44%mixed. The report adverse condition is not
reproduced here; do not erase it or infer warmup as its proven cause. Retain the
architecture without claiming a portable CPU or whole-script allocation gain.

Both runs preserve mediated I/O, full output/file verification and prior-result
cleanup; fresh adds compilation/compiled-owner disposal. Startup/reset/protocol/
final-cache teardown are excluded from elapsed clocks. No quiet-VM, refreshed
CPython, heap/RSS or embedding-tail claim. No new benchmark framework or VM users.
The broader whole-script objective remains open after this construction milestone.

[Decision, every median and adverse range](summary.json),
[exact589source/build inputs, core, focused logs, reference failure, CPython controls,
raw measurements and procedures](sources-checks-and-observations.tar.xz).
Image manifests reconstruct unchanged auxiliaries from the prior
[shared-prefix owned archive](../2026-11-15-shared-prefix-prototype/owned-metadata-refinement.tar.xz)
and reference core from its
[initial archive](../2026-11-15-shared-prefix-prototype/initial-and-routing-refinement.tar.xz).
Every component was independently hash-verified before retaining this evidence.
''',encoding='utf-8',newline='\n')
with(root/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as stream:stream.write('''\n\n[R384 final-slot function binding](results/2026-11-15-function-slot-binding/README.md)
retains8fbfa3f0: removes function presence/overflow/marking/transport and corrects
starred-positional/keyword duplicate binding, confirmed reference-first and CPython.
452internal/2,396public per actual11/10pass. Initial fixtureexit7 and subsequent
passes preserved, no causal fix claimed. Local8job122.508splus justified same-image
3job longer-warmup confirmation keep every adverse control; no portableCPU or
whole-script allocation claim. Accept short-helper+.49–2.48%diagnostic debt for
simplification/correctness; report's original+23.72%moving result not erased.
Full platform/originalstress/installed-consumer qualification pending; publication held.
''')
print(json.dumps(dict(retained=True,archiveBytes=archive.stat().st_size,files=len(files),core=identity['coreSHA256']['candidate'],fullQualificationPending=True),indent=2))
