from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile

root=Path.cwd();r=Path(__file__).parent/'function-slot-binding-r384';r.mkdir()
names=subprocess.check_output(['git','ls-files','--','src/Lokad.Lython'],text=True).splitlines()
assert len(names)==585
names+=['Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not subprocess.check_output(['git','diff','--name-only','--','src/Lokad.Lython','tests'],text=True).strip()
with tarfile.open(r/'reference-sources.tar.xz','w:xz') as tar:
    for name in names:tar.add(name,arcname=name)
(r/'reference-identity.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),runtime='a7ab41f5',core='716176a8',qualification='43675539106GREEN cached',sources={n:sha(n) for n in names}),indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copytree(r.parent/'activation-prefix-r382/reference',r/'reference')
shutil.copyfile(r.parent/'activation-prefix-r382/catalog.json',r/'catalog.json')
def edit(name,changes):
    p=root/name;text=p.read_text(encoding='utf-8');(r/p.name).write_text(text,encoding='utf-8',newline='\n')
    for old,new,count in changes:
        assert text.count(old)==count,(name,old,text.count(old))
        text=text.replace(old,new)
    p.write_text(text,encoding='utf-8',newline='\n')
edit('src/Lokad.Lython/Runtime/Calls/BoundFunctionArguments.cs',[
 ('    ArgumentPresence Assigned,','    int ParameterCount,',1)])
edit('src/Lokad.Lython/Runtime/LythonRuntime.Calls.Binding.cs',[
 ('bound.Assigned.Length','bound.ParameterCount',1),
 ('''        try
        {
            return new BoundFunctionArguments(values, new ArgumentPresence(parameterCount), governor);
        }
        catch
        {
            governor.ReturnFunctionWorkspace(values, parameterCount);
            throw;
        }''','''        return new BoundFunctionArguments(values, parameterCount, governor);''',1),
 ('            var assigned = storage.Assigned;\n','',1),
 ('BindFunctionArgumentsInto(storage.Values, ref assigned,','BindFunctionArgumentsInto(storage.Values,',1),
 ('return storage with { Assigned = assigned };','return storage;',1),
 ('if (bound.Assigned[index]) continue;','if (!values[index].IsUnassigned) continue;',1),
 ('        ref ArgumentPresence assigned,\n','',1),
 ('            assigned.MarkRange(0, positionalIndex);\n','',1),
 ('BindSuppliedFunctionArguments(values, ref assigned,','BindSuppliedFunctionArguments(values,',1),
 ('if (assigned[i])','if (!values[i].IsUnassigned)',2),
 ('            assigned[variadicIndex] = true;\n','',1),
 ('            assigned[keywordDictIndex] = true;\n','',1),
 ('Span<ExecutableSlot> values, ref ArgumentPresence assigned,','Span<ExecutableSlot> values,',1),
 ('                assigned[positionalIndex] = true;\n','',1),
 ('if (assigned[keywordIndex])','if (!values[keywordIndex].IsUnassigned)',1),
 ('            assigned[keywordIndex] = true;\n','',1),
 ('slots are per-call.','slots are per-call. Their null sentinel distinguishes omission from None.',1),
 ('binding fills values','binding fills values',0) # No-op guard below removed before application.
][:-1])
edit('src/Lokad.Lython/Runtime/PyExecutableFunction.cs',[
 ('        var assigned = new ArgumentPresence(BindingPlan.ParameterCount);\n','',1),
 ('            for (var i = 0; i < assigned.Length; i++) assigned[i] = true;\n','',1),
 ('BindFunctionArgumentsInto(values[..BindingPlan.ParameterCount], ref assigned,','BindFunctionArgumentsInto(values[..BindingPlan.ParameterCount],',1),
 ('StartInline(values, assigned, null,','StartInline(values, null,',1),
 ('            bound.Assigned, bound, span,','            bound, span,',1),
 ('Span<LythonRuntime.ExecutableSlot> values, ArgumentPresence assigned, BoundFunctionArguments? existing,','Span<LythonRuntime.ExecutableSlot> values, BoundFunctionArguments? existing,',1),
 ('                    _codeObject.ValueStorageCapacity) with { Assigned = assigned };','                    _codeObject.ValueStorageCapacity);',1)])
for file,old,new,count in [
 ('src/Lokad.Lython/Runtime/PyFunctionBase.cs','boundArguments.Assigned.Length','boundArguments.ParameterCount',2),
 ('src/Lokad.Lython/Runtime/LythonRuntime.Executable.cs','boundArguments.Assigned.Length','boundArguments.ParameterCount',1),
 ('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.cs','bound.Assigned.Length','bound.ParameterCount',1),
 ('tests/Lokad.Lython.Tests/FunctionWorkspaceOwnershipTests.cs','bound.Assigned.Length','bound.ParameterCount',1),
 ('tests/Lokad.Lython.Tests/ExecutableAsyncIteratorCleanupTests.cs','new ArgumentPresence(1)','1',1),
]:edit(file,[(old,new,count)])
print('Function presence creation/marks/transport removed; builtin presence unchanged. Focused checks and source-pair gate pending.',flush=True)
