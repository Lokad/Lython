from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess,tarfile

r=Path(__file__).parent;assert not(r/'candidate-identity.json').exists()
checks=json.loads((r/'corrected-focused-checks.json').read_text(encoding='utf-8'))
assert checks['complete'] and len(checks['checks'])==4
assert sorted((v['framework'],v['passed'])for v in checks['checks'])==sorted([(f,n)for f in ['net11.0','net10.0']for n in [452,2396]])
names=subprocess.check_output(['git','ls-files','--','src/Lokad.Lython'],text=True).splitlines();assert len(names)==585
names+=['Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources={name:sha(name)for name in names};sdk='C:/Users/JoannesVermorel/.dotnet11'
env={k:v for k,v in os.environ.items()if k.casefold()!='path'}
env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';'+next(v for k,v in os.environ.items()if k.casefold()=='path')
with(r/'freeze-build.log').open('w',encoding='utf-8',newline='\n')as log:
    done=subprocess.run([sdk+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','-m:1','-v','quiet'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert done.returncode==0,(r/'freeze-build.log').read_text(encoding='utf-8')
assert all(sha(name)==h for name,h in sources.items())
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as tar:
    for name in sources:tar.add(name,arcname=name)
shutil.copytree(r/'reference',r/'candidate');shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll');shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
files={role:{p.name:sha(p)for p in (r/role).iterdir()if p.is_file()}for role in ['reference','candidate']}
assert files['reference']['Lokad.Lython.dll'].startswith('716176a8')
assert all(files['candidate'][n]==h for n,h in files['reference'].items()if n!='Lokad.Lython.dll')
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),sources=sources,productionInputs=585,additionalBuildInputs=4,
    coreSHA256={role:files[role]['Lokad.Lython.dll']for role in files},auxiliaryFiles={n:h for n,h in files['reference'].items()if n!='Lokad.Lython.dll'},frozenFiles=files,catalogSHA256=sha(r/'catalog.json'),focusedChecks=checks['checks'],fullQualificationPending=True,publicationHeld=True,
    architecture='Final slots are authoritative throughout function binding. Removed function presence map/overflow/marking/transport; retained builtin omission metadata and ordinary native/owned entry engines. Corrected pre-existing expanded duplicate binding.')
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
script=(r.parent/'activation-prefix-r382/local-screen.py').read_text(encoding='utf-8').replace('Initial complete-script source-pair diagnostic.','Function-slot binding construction/transport diagnostic; no CPU or allocation attribution.')
ast.parse(script);(r/'local-screen.py').write_text(script,encoding='utf-8',newline='\n')
print('Frozen exact589inputs/complete copied images',identity['coreSHA256'],'452internal/2396public each actual11/10 pass; bounded8job source pair prepared.',flush=True)
