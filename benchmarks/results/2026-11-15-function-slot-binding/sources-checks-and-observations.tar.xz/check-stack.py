from pathlib import Path
import json,os,shutil,subprocess

r=Path(__file__).parent;reference=r/'reference-fixture'
shutil.copytree('tests/Lokad.Lython.WorkerFixture/bin/Release/net11.0',reference)
shutil.copyfile(r/'reference/Lokad.Lython.dll',reference/'Lokad.Lython.dll')
env=os.environ.copy();env['DOTNET_PROCESSOR_COUNT']='1';sdk='C:/Users/JoannesVermorel/.dotnet11/dotnet.exe'
rows=[]
for label,folder in [('reference',reference),('candidate',Path('tests/Lokad.Lython.WorkerFixture/bin/Release/net11.0'))]:
    done=subprocess.run([sdk,str(folder/'Lokad.Lython.WorkerFixture.dll'),'stack-guard',str(folder/'Lokad.Lython.dll'),'native-call-continuation'],env=env,text=True,encoding='utf-8',capture_output=True,timeout=30)
    row=dict(label=label,returncode=done.returncode,stdout=done.stdout,stderr=done.stderr);rows.append(row);print(json.dumps(row),flush=True)
(r/'initial-stack-diagnostic.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
