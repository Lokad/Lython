
from pathlib import Path
from itertools import product
import hashlib
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
parent=lab.parent
base=parent/"csv-literal-field-scan-20261122"/"comparison"
comparison=lab/"comparison"
inspector=parent/"demanded-jump-targets-20261122"
diagnostic=parent/"future-annotations-single-walk-20261122"
core="Lokad.Lython.dll"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
def hashes(path):return {p.name:sha(p) for p in sorted(path.iterdir()) if p.is_file()}
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
manifest=read(base/"identity.json")["imageFiles"]["candidate"]
for role in ("reference","candidate"):
    image=comparison/f"frozen-{role}"
    files={**manifest,core:read(comparison/f"{role}-allocation.json")["coreSha256"]}
    assert len(files)==32 and all(sha(image/n)==h for n,h in files.items())

module_first=["", "scope_name = 0\n", "global scope_name\n", "nonlocal scope_name\n",
              "scope_name = 1\nglobal scope_name\n"]
before=["", "    global scope_name\n", "    nonlocal scope_name\n",
        "    scope_name = 2\n    global scope_name\n"]
suite_bodies=["    pass\n", "    scope_name: int = 3\n    scope_name = 4\n",
              "    scope_name = [item for item in range(3)]\n",
              "    if False:\n        scope_name = 42\n    else:\n        scope_name = 9\n",
              "    def method(self):\n        return super()\n",
              "    def method(self):\n        return scope_name\n"]
heads=["class Suite:\n","def make(scope_name):\n    class Suite:\n"]
private=[]
for first,head,decl,body in product(module_first,heads,before,suite_bodies):
    block=decl+body
    if head.startswith("def "):block="".join("    "+line for line in block.splitlines(keepends=True))
    private.append(first+head+block)
source=lab/"scope-diagnostic-inputs.json"
write(source,private)
catalog=inspector/"inspect-catalog.json"
original=read(inspector/"inspection-identity.json")
assert sha(catalog)==original["fixtureSHA256"]
diagnostic_proof=read(diagnostic/"diagnostic-comparison.json")["imageHashes"]["reference"]
tools={
    "inspect":(inspector/"reference/inspect",original["workerImages"]["reference"]["inspect"],catalog,"Inspect.dll"),
    "diagnostics":(diagnostic/"diagnostic-image/reference",diagnostic_proof,source,"DiagnosticProbe.dll"),
}
identities={}
details={}
for name,(tool,expected,source,entry) in tools.items():
    assert hashes(tool)==expected
    details[name]={}
    identities[name]={"inputSHA256":sha(source)}
    for role in ("reference","candidate"):
        image=lab/name/role
        shutil.copytree(tool,image)
        shutil.copyfile(comparison/f"frozen-{role}"/core,image/core)
        files={**expected,core:sha(comparison/f"frozen-{role}"/core)}
        assert hashes(image)==files
        result=lab/f"{name}-{role}.json"
        subprocess.run([dotnet,image/entry,source,result],env=env,check=True,timeout=45)
        assert hashes(image)==files
        details[name][role]=read(result)
        identities[name][role]=files
r,c=details["inspect"].values()
assert r["coreSHA256"]==identities["inspect"]["reference"][core]
assert c["coreSHA256"]==identities["inspect"]["candidate"][core]
assert r["rows"]==c["rows"]
r,c=details["diagnostics"].values()
assert r==c
write(lab/"scope-equality.json",dict(exactTapeFixtures=len(details["inspect"]["candidate"]["rows"]),
    diagnostics=len(r),valid=sum(row["IsValid"] for row in r),identities=identities))
print(len(details["inspect"]["candidate"]["rows"]),"exact tape fixtures,",len(r),"identical diagnostic and balance cases",flush=True)

