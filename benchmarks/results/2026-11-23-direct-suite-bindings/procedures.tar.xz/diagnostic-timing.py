
from contextlib import ExitStack
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import statistics
import subprocess
import tempfile
import time

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
comparison=lab/"comparison"
catalog=comparison/"catalog.json"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
manifest_file=lab.parent/"csv-literal-field-scan-20261122"/"comparison"/"identity.json"
base=read(manifest_file)
core="Lokad.Lython.dll"
images={role:comparison/f"frozen-{role}" for role in ("reference","candidate")}
files={role:{**base["imageFiles"]["candidate"],core:read(comparison/f"{role}-allocation.json")["coreSha256"]} for role in images}
def verify_image(role):
    assert len(files[role])==32
    assert {name:sha(images[role]/name) for name in files[role]}==files[role]
for role in images:verify_image(role)
for role in images:
    receipt=read(comparison/f"{role}-verify.json")
    assert receipt["state"]=="Completed" and receipt["catalogSha256"]==sha(catalog) and receipt["caseCount"]==7
proto=repo/"benchmarks/cpython-worker.py"
assert sha(proto)==base["protocolSHA256"]
spec=importlib.util.spec_from_file_location("protocol",proto)
protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
cases={v["id"]:v for v in read(catalog)["cases"]}
out=lab/"local-timing"
out.mkdir()
keys = ("sourceSha256","fixtureSha256","expectedOutputSha256")

class Worker:
    def __init__(self,label,case,lane,stack):
        self.label,self.case,self.lane=label,case,lane
        self.role=label.split("-")[0]
        self.seq=0
        folder=stack.enter_context(tempfile.TemporaryDirectory(prefix="lython-comparison-files-"))
        err=stack.enter_context(tempfile.TemporaryFile())
        self.process=subprocess.Popen([dotnet,images[self.role]/"Lokad.Lython.Benchmarks.dll","--compare","worker","--catalog",catalog],
            cwd=folder,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err)
        def close():
            if self.process.poll() is None:self.process.kill();self.process.wait(timeout=8)
            self.process.stdin.close();self.process.stdout.close()
            err.seek(0); messages=err.read()
            if messages:(out/f"stderr-{case['id']}-{lane}-{label}.log").write_bytes(messages)
        stack.callback(close)
        self.identity=protocol.read_frame(self.process.stdout)
        assert self.identity["status"]=="Ready" and self.identity["catalogSha256"]==sha(catalog)
        libraries={Path(row["path"]).name:row["sha256"].lower() for row in self.identity["libraries"]}
        assert libraries[core]==files[self.role][core] and all(files[self.role].get(n) in (None,d) for n,d in libraries.items())
        self.request("verify",2)

    def request(self,op,count):
        self.seq+=1
        request=dict(protocolVersion=protocol.PROTOCOL_VERSION,requestId=self.seq,operation=op,
                     caseId=self.case["id"],lane=self.lane,iterations=count,**{k:self.case[k] for k in keys})
        start=time.monotonic()
        protocol.write_frame(self.process.stdin,request)
        received=protocol.read_frame(self.process.stdout)
        took=time.monotonic()-start
        assert received["requestId"]==self.seq and received["status"]==("Equivalent" if op=="verify" else "Completed"),received
        assert received["completedInvocations"]==count
        assert all(received[k]==self.case[k] for k in keys)
        compile_only=self.lane=="compile" and op=="batch"
        for key in ("Output","Files"):
            assert received.get(f"actual{key}Sha256")== (None if compile_only else self.case.get(f"expected{key}Sha256"))
        return dict(duration=took,response=received)

    def quit(self):
        self.seq+=1
        protocol.write_frame(self.process.stdin,dict(protocolVersion=protocol.PROTOCOL_VERSION,requestId=self.seq,operation="quit"))
        assert protocol.read_frame(self.process.stdout)["status"]=="Closed"
        assert self.process.wait(timeout=8)==0

ids=("scripts.dataclass-inherited-configuration.generated","scripts.config-edit.small",
     "scripts.config-generated-guards.medium.bad-0.sparse-lexical","compiler.generated-read-only-branches")
jobs=[(name,lane)for name in ids for lane in ("compile","compile-run")]
for index,(name,lane) in enumerate(jobs):
    labels=["reference-1","candidate-1","candidate-2","reference-2"]
    if index%2:labels.reverse()
    with ExitStack() as stack:
        workers=[Worker(label,cases[name],lane,stack)for label in labels]
        counts=[1]*len(workers)
        warm=[0.0]*len(workers)
        for turn in range(12):
            for slot in range(len(workers)):
                i=(turn+slot)%len(workers)
                if warm[i]>=1:continue
                batch=workers[i].request("batch",counts[i])
                warm[i]+=batch["duration"]
                counts[i]=max(1,min(4096, min(4*counts[i],int(counts[i]*.22/max(batch["duration"],.001)))))
            if min(warm)>=1:break
        assert min(warm)>=1
        samples={label:[]for label in labels}
        for n in range(7):
            for slot in range(len(workers)):
                i=(n+slot)%len(workers)
                samples[labels[i]].append(workers[i].request("batch",counts[i]))
        for worker in reversed(workers):worker.quit()
    medians={label:statistics.median(batch["response"]["elapsedTicks"]/batch["response"]["clockFrequency"]/
                     batch["response"]["completedInvocations"]*1000 for batch in observations)
             for label,observations in samples.items()}
    ratios=sorted(100*(medians[c]/medians[r]-1) for c in labels if c.startswith("candidate")
                  for r in labels if r.startswith("reference"))
    write(out/f"{index}.json",dict(case=name,lane=lane,files=files,catalogSHA256=sha(catalog),samples=samples,
                                 timing="local diagnostic",mediansMilliseconds=medians,elapsedChanges=ratios,warmupSeconds=warm))
    print(name,lane,[round(p,2)for p in ratios],flush=True)
for role in images:verify_image(role)

