
from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=lab/"comparison"
archive=lab.parent/"csv-literal-field-scan-20261122"/"comparison"
source_pair=lab.parent/"function-optional-attributes-20261122"
donor=source_pair/"refined-comparison"/"quiet"
profile=source_pair/"profile"/"quiet"
quiet=out/"quiet"
quiet.mkdir()
core="Lokad.Lython.dll"
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda b:hashlib.sha256(b).hexdigest()
def h(p):return sha(p.read_bytes())
def git(*args,cwd=repo):return subprocess.check_output(["git",*args],cwd=cwd)
def write(p,s):
    if p.suffix==".py":compile(s,str(p),"exec")
    p.write_text(s,encoding="utf-8",newline="\n")
def save(p,o):write(p,json.dumps(o,ensure_ascii=False,indent=2)+"\n")
def committed(folder,leaf):return git("show",f"HEAD:benchmarks/results/{folder}/{leaf}")
def receipt(folder):
    record=json.loads(committed(folder,"archive-receipt.json"))
    assert all(record[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
    assert sha(committed(folder,"observations.tgz"))==record["archiveSHA256"]
    return record["archiveSHA256"]

previous=read(donor/"config.json")
trace=read(profile/"config.json")
csv=read(archive/"quiet/config.json")
source=json.loads(committed("2026-11-22-csv-literal-field-scan","source.json"))
assert source["imageFiles"]==csv["identity"]["imageFiles"]
assert not git("diff","--name-only", source["candidate"],"60572c961","--","src","tests")
p1425="2026-11-23-function-optional-attributes"
p1424="2026-11-22-csv-literal-field-scan"
p1426="2026-11-23-function-storage-attribution"
assert read(profile/"identity.json")["imageFiles"]==previous["identity"]["imageFiles"]
assert json.loads(committed(p1425,"source.json"))["imageFiles"]==previous["identity"]["imageFiles"]
assert json.loads(committed(p1426,"identity.json"))["imageFiles"]==previous["identity"]["imageFiles"]
archives={cfg["root"].split("/")[-1]+"/observations.tgz":receipt(folder) for cfg,folder in ((previous,p1425),(trace,p1426),(csv,p1424))}
retire=[]
for role,dirs in (("reference",(previous,trace,csv)),("candidate",(previous,trace))):
    paths=[cfg["root"].split("/")[-1] for cfg in dirs]
    linked=[name+"/"+role+"/"+core for name in paths]
    stored=gzip.decompress(committed(p1424 if role=="reference" else p1425,f"{role}-core.dll.gz"))
    assert sha(stored)==previous["identity"]["imageFiles"][role][core]
    retire.append(dict(paths=linked,bytes=len(stored),sha256=sha(stored),links=len(linked),archives={n+"/observations.tgz":archives[n+"/observations.tgz"]for n in paths}))

tree=repo/".git/agent-worktrees/direct-suite-bindings-20261123"
candidate=git("rev-parse","HEAD",cwd=tree).decode().strip()
assert candidate.startswith("2aa3c25e8") and not git("status","--porcelain",cwd=tree)
patch=git("diff","--binary","60572c961",candidate,"--","src","tests")
assert patch.count(b"diff --git ")==1
(out/"source.patch").write_bytes(patch)
alloc={role:read(out/f"{role}-allocation.json") for role in ("reference","candidate")}
files={role:{**source["imageFiles"]["candidate"],core:alloc[role]["coreSha256"]} for role in alloc}
assert [n for n,h in files["reference"].items()if files["candidate"][n]!=h]==[core]
assert files["reference"]==source["imageFiles"]["candidate"]
assert not {r["sha256"] for r in retire}&{m[core] for m in files.values()}
ids=("scripts.dataclass-inherited-configuration.generated","scripts.config-edit.small",
     "scripts.config-generated-guards.medium.bad-0.sparse-lexical","compiler.generated-read-only-branches")
original=read(out/"catalog.json")
cases={case["id"]:case for case in original["cases"]}
catalog=quiet/"representative.json"
save(catalog,{**original,"cases":[cases[name] for name in ids]})
jobs=[(name,"compile")for name in ids]+[(ids[0],"compile-run"),(ids[2],"compile-run")]
assert len(jobs)==6
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
assert h(protocol)==previous["protocolSHA256"]
for role in files:
    image=out/f"frozen-{role}"
    assert len(files[role])==32 and {n:h(image/n)for n in files[role]}==files[role]
    proof=out/f"{role}-quiet-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",proof],
        env=env,cwd=repo,check=True,timeout=90)
    verify=read(proof)
    assert verify["state"]=="Completed" and verify["caseCount"]==len(ids) and verify["catalogSha256"]==h(catalog)
    assert {n:h(image/n)for n in files[role]}==files[role]
    (quiet/role).mkdir()
    shutil.copyfile(image/core,quiet/role/core)
root="/home/lokad/lython-bench-checks/direct-suite-bindings-b1427-20261123"
unit="lython-b1427-direct-suite-bindings-20261123"
identity=dict(sourceRevision=source["candidate"]+" versus "+candidate,
    reference=source["candidate"],patchBase=git("rev-parse","60572c961").decode().strip(),candidate=candidate,
    purpose="Collect dynamic suite membership once instead of growing and compacting a list and preserving unused order.",
    sourcePatchSHA256=h(out/"source.patch"),normalAdapterPin="0.4.0",imageFiles=files,
    coreSHA256={role+suffix:m[core] for role,m in files.items()for suffix in ("","-control")},
    protocolSHA256=h(protocol),catalogs={"representative.json":{"sha256":h(catalog)}})
save(quiet/"identity.json",identity)
for leaf in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    code=(donor/leaf).read_text(encoding="utf-8").replace(previous["root"],root).replace(previous["unit"],unit)
    if leaf=="collect.py":
        a,b=code.index("\njob_catalog ="),code.index("\nassert len(jobs)")
        code=code[:a]+"\njob_catalog = "+repr({id:"representative.json" for id,_ in jobs})+"\njobs = "+repr(jobs)+code[b:]
        code=code.replace("==7","==6").replace("== 7","== 6")
    elif leaf in ("archive-owned.py","retrieve.py"):
        code=code.replace("len(raw['jobs'])==7","len(raw['jobs'])==6").replace("jobs=7,","jobs=6,").replace("['jobs']==7","['jobs']==6")
    write(quiet/leaf,code.replace("Function optional metadata","Direct suite bindings"))
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py","candidate/"+core,"reference/"+core)
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz")as t:
    for n in parts:t.add(quiet/n,arcname=n)
cfg={**previous,"root":root,"unit":unit,"identity":identity,"source":previous["root"],"sourceRole":"reference",
     "sourceFiles":previous["identity"]["imageFiles"]["reference"],"sourceCatalogSHA256":previous["identity"]["catalogs"]["representative.json"]["sha256"],
     "donorArchiveSHA256":archives[previous["root"].split("/")[-1]+"/observations.tgz"],"retireGroups":retire,
     "payloadBytes":payload.stat().st_size,"payloadSHA256":h(payload),"unpackedBytes":sum((quiet/n).stat().st_size for n in parts)}
save(quiet/"config.json",cfg)
code=(donor/"remote-launch.py").read_text(encoding="utf-8")
a,b=code.index("\nc=")+1,code.index("\nb=Path(")
write(quiet/"remote-launch.py",(code[:a]+"c="+repr(cfg)+code[b:]).replace("b1425-fixtures","b1427-fixtures"))
write(out/"launch.py",(donor.parent/"launch.py").read_text(encoding="utf-8").replace("Function optional metadata","Direct suite bindings").replace("seconds=430","seconds=350").replace("before 430 seconds","before 350 seconds"))
write(out/"summarize.py",(donor.parent/"summarize.py").read_text(encoding="utf-8").replace("len(raw['jobs'])==7","len(raw['jobs'])==6"))
print(candidate,root,cfg["unpackedBytes"],flush=True)

