from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;run=r/'b747';out=Path('benchmarks/results/2026-11-14-range-cpython-checkpoint');out.mkdir();status=json.loads((run/'terminal-status.json').read_text(encoding='utf-8'));summary=json.loads((run/'summary.json').read_text(encoding='utf-8'));assert status['receipt']['complete'] and summary['complete'] and summary['jobs']==9 and not status['remainingWorkers'] and not status['remainingFixtures'] and not status['remainingTrace'];assert hashlib.sha256((run/'observations.tgz').read_bytes()).hexdigest()==status['receipt']['archiveSHA256']
guide=Path('docs/BENCHMARKS.md');shutil.copyfile(guide,out/'prior-BENCHMARKS.md')
for n in ['identity.json','summary.json','terminal-status.json','archive-receipt.json','prospective.json']:shutil.copyfile(run/n,out/n)
shutil.copyfile(r/'refined/delivery/source-proof.json',out/'measured-source-proof.json')
with tarfile.open(out/'observations.tar.xz','w:xz')as t:
    for p in sorted(run.rglob('*')):
        if p.is_file():t.add(p,arcname=p.relative_to(run).as_posix())
    t.add(__file__,arcname='save-external.py')
rows={(v['case'],v['lane']):v for v in summary['timing']}
ids={'CSV invoice / pricing helpers':'scripts.csv-invoice.large','Text / captured helper and counter':'scripts.text-summary-helpers.nonlocal-counter.large','JSON-lines / aggregation helpers':'scripts.json-summary-helpers.large','File search / keyword-default helper':'scripts.file-search.large','JSON-to-Markdown report':'scripts.report-render.large','CSV fulfillment / pricing and validation':'scripts.csv-fulfillment.large','CSV validation / for-loop checksum':'scripts.csv-check-digits.for-text.large'}
def elapsed(row,prefix):
    a,b=sorted(v for n,v in row['medianMilliseconds'].items()if n.startswith(prefix));factor=1000 if b<1 else 1;unit='µs' if b<1 else 'ms';return f'{a*factor:.3f}–{b*factor:.3f} {unit}'
def label(row):return 'Variable'if max(row['lythonControlPercent'],row['cpythonControlPercent'],row['maxIqrPercent'])>=3 else'Diagnostic'
def cells(row):return [elapsed(row,'candidate'),elapsed(row,'CPython'),f'{min(row["ratioRange"]):.2f}–{max(row["ratioRange"]):.2f}×',f'{label(row)}; spreads {row["lythonControlPercent"]:.2f}/{row["cpythonControlPercent"]:.2f}%; max IQR {row["maxIqrPercent"]:.2f}%']
lines=[]
for line in guide.read_text(encoding='utf-8').splitlines():
    if line.startswith('|'):
        parts=[s.strip()for s in line.strip('|').split('|')];name=parts[0]
        if name in ids:line='| '+'|'.join(parts[:2]+cells(rows[ids[name],'warm']))+'|'
        elif name in ['Invoice compilation alone','Invoice compile and execute once']:line='| '+'|'.join([name]+cells(rows['scripts.csv-invoice.large','compile'if name=='Invoice compilation alone'else'compile-run']))+'|'
    lines.append(line)
s='\n'.join(lines)+'\n';a=s.index('First seven rows measured');b=s.index('The96 B configuration row',a)
s=s[:a]+'''First seven rows measured 2026-11-14 UTC: **fa40d674 / frozen 73a1b233**,
against stock **CPython 3.13.16**. Full Windows/Ubuntu actual .NET 11/10,
original stress and installed-package qualification is
[running at this exact source](https://github.com/Lokad/Lython/actions/runs/43625900419).
[Exact sources, raw/wider CPU and controls](../benchmarks/results/2026-11-14-range-cpython-checkpoint/README.md).
Variable cases stay visible; process spreads and within-process IQRs limit
magnitude precision. The [previous qualified checkpoint and guide](../benchmarks/results/2026-11-14-range-cpython-checkpoint/prior-BENCHMARKS.md)
preserve earlier source identities and all adverse conditions. Cross-collection
differences do not attribute individual changes. The separate native numeric
counter is a diagnostic and does not predict these maintained scripts.
'''+s[b:]
guide.write_text(s,encoding='utf-8',newline='\n')
table='\n'.join('| '+name+' | '+' | '.join(cells(rows[case,'warm']))+' |'for name,case in ids.items())
(out/'README.md').write_text(f'''# Representative CPython checkpoint after shared range iteration

2026-11-14 UTC, committed `fa40d674` / frozen `73a1b233`, stock CPython 3.13.16.
[Full platform/stress/installed-package qualification](https://github.com/Lokad/Lython/actions/runs/43625900419)
is pending independently. All 582 frozen inputs match the commit with explicit
newline normalization; independently rebuilt binary identity is not inferred.

Quiet F4as_v7 / Ubuntu 24.04.4 / four EPYC 9V45 / 16 GiB / no swap / .NET11RC3;
normal workstation GC/tiering, CPython GIL/GC. B747 completes nine jobs in
{summary['elapsedSeconds']:.3f} seconds. Four fresh processes/job, full-request
warmups (5 seconds; 12 text/report), five rotating half-second batches. Catalog,
workers/toolchains and boundaries unchanged. All image/catalog/golden/file/budget/
quiet/awaited-cleanup/persistent-archive gates pass. No users/fixtures remain.
Raw SHA256 `{status['receipt']['archiveSHA256']}`.

| Warm workload | Lython | CPython | Lython / CPython | Status |
| --- | ---: | ---: | ---: | --- |
{table}

Ratio above one means slower. Process medians/all pairings, not confidence
intervals. Variable observations are retained; a three-percent label is descriptive,
not a design acceptance veto. Invoice compilation: {' | '.join(cells(rows['scripts.csv-invoice.large','compile']))}.
Invoice compile-to-result: {' | '.join(cells(rows['scripts.csv-invoice.large','compile-run']))}.
No cross-collection attribution or extrapolation of the diagnostic counter gains
to these different complete algorithms. Broader performance objective stays open.

Warm includes mediated RAM I/O, full stdout/file validation and result cleanup;
excludes compile/startup, fixture reset/protocol and final cache disposal. Fresh
adds compilation and compiled-owner disposal. Wider CPU includes reset/protocol.
Startup, real pending-I/O latency, contention, heap/RSS peaks and embedding tail
latency remain unmeasured. No new core/catalog upload, deletion or altered floors.

Exact [sources/binary](../2026-11-14-range-iteration-stage/refined/sources-checks-and-observations.tar.xz),
[source proof](measured-source-proof.json), [all medians/controls](summary.json),
[identity](identity.json), [terminal](terminal-status.json),
[all collection tools/receipts/raw](observations.tar.xz), [previous guide](prior-BENCHMARKS.md).
Publication/tagging and affected final released-adapter checks remain postponed.
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf-8')+f'''
## R362 external representative checkpoint

[B747](results/2026-11-14-range-cpython-checkpoint/README.md), exact fa40d674/73a1b233,
completes nine jobs/{summary['elapsedSeconds']:.3f}s/all gates versus stockCPython3.13.16.
Current guide separates compile/warm/fresh, I/O/validation/cleanup, all controls and
remaining uncertainty; original source/guide/raw retained. No cross-collection
attribution or diagnostic counter extrapolation. Full43625900419 independent;
representative source gate continues, publication held.
''',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('| Latest external checkpoint |');b=s.index('\n',a);s=s[:a]+f'''| Latest external checkpoint | [B747](docs/BENCHMARKS.md), exact fa40/73a against stock CPython3.13.16: nine jobs/{summary['elapsedSeconds']:.3f}s/all gates. Compile/warm/fresh/I/O/cleanup and source qualification separate, all adverse/variable observations retained. Full43625900419 independently pending. No unchanged replay or cross-collection attribution; R363 representative source gate next. |'''+s[b:];a=s.index('B747 representative CPython checkpoint active');b=s.index(' UTC.',a)+5;s=s[:a]+'B747 representative checkpoint complete/all gates; guide and raw evidence refreshed.'+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print('B747 complete/current guide refreshed; qualification pending separately, roadmap continues.',flush=True)
