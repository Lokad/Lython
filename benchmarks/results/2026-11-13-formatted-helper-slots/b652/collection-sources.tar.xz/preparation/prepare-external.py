from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;old=r/'b651';out=r/'b652';out.mkdir()
oldroot='/home/lokad/lython-bench-checks/formatted-helper-b651-20261113';root='/home/lokad/lython-bench-checks/report-external-b652-20261113'
state=json.loads((old/'terminal-status.json').read_text(encoding='utf-8'));assert state['exitCode']=='0'and not state['remainingWorkers']and not state['remainingTrace']
info=json.loads((old/'identity.json').read_text(encoding='utf-8'));info['sourceRevision']='R296 e34cacaf versus CPython3.13.16; affected complete report scripts; retained proposal after B651 controlled before/after'
jobs=[[case,lane]for case in ['scripts.report-render.large','scripts.report-render.utf16.large']for lane in ['warm','compile','compile-run']]
collect=(old/'collect.py').read_text(encoding='utf-8').replace(oldroot,root)
start=collect.index('jobs=');end=collect.index('\nenv = ',start)
collect=collect[:start]+'jobs='+repr(jobs)+'\nassert len(jobs)==6 and all(case in cases for case,lane in jobs)\n'+collect[end:]
collect=collect.replace("labels=['reference','candidate','reference-control','candidate-control']","labels=['candidate','CPython','candidate-control','CPython-control']")
collect=collect.replace('12 if lane!="compile" and case_id=="scripts.text-summary-helpers.nonlocal-counter.large" else 8 if case_id in ("scripts.report-render.large","scripts.report-render.utf16.large","scripts.json-summary-helpers.large") else 5','8 if lane!="compile" else 5')
start=collect.index("purpose='");end=collect.index("',\n",start)
collect=collect[:start]+"purpose='Refresh current complete UTF8 and UTF16 reports against CPython3.13.16; warm/compilation/compile-to-result separate; repeated independent roles; original byte-identical fixtures and complete goldens"+collect[end:]
collect=collect.replace('warmupSeconds=5, affectedWarmupSeconds=8, capturedWarmupSeconds=12','warmupSeconds=8, compilationWarmupSeconds=5')
ast.parse(collect);(out/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
archive=(old/'archive-owned.py').read_text(encoding='utf-8').replace(oldroot,root).replace("len(raw['jobs'])==7","len(raw['jobs'])==6").replace('complete=True,jobs=7','complete=True,jobs=6')
ast.parse(archive);(out/'archive-owned.py').write_text(archive,encoding='utf-8',newline='\n')
(out/'run.sh').write_text('set -eu\nroot='+root+'\ntrap \'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"\' EXIT\npython3 "$root/collect.py"\n',encoding='utf-8',newline='\n')
(out/'identity.json').write_text(json.dumps(info,indent=2)+'\n',encoding='utf-8',newline='\n')
files={name:out/name for name in ['collect.py','archive-owned.py','run.sh','identity.json']}
with tarfile.open(out/'payload.tgz','w:gz')as archive:
 for name,p in files.items():archive.add(p,arcname=name)
config=dict(root=root,unit='lython-b652-report-external-20261113',sourceRoot=oldroot,identity=info,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest())
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
retrieve=(old/'retrieve.py').read_text(encoding='utf-8').replace('formatted-helper-b651-20261113','report-external-b652-20261113').replace('lython-b651-formatted-helper-20261113','lython-b652-report-external-20261113').replace("['jobs']==7","['jobs']==6").replace('B651 seven-job','B652 six-job')
ast.parse(retrieve);(out/'retrieve.py').write_text(retrieve,encoding='utf-8',newline='\n')
print('Six affected CPython jobs prepared; no new binaries, worker/catalog unchanged; 480s owner plus cleanup.',flush=True)
