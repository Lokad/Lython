from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;src=r/'b652';out=Path('benchmarks/results/2026-11-13-formatted-helper-slots/b652');out.mkdir()
state=json.loads((src/'terminal-status.json').read_text(encoding='utf-8'));assert state['exitCode']=='0'and not state['remainingWorkers']and not state['remainingTrace']
receipt=json.loads((src/'archive-receipt.json').read_text(encoding='utf-8'));assert hashlib.sha256((src/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for name in ['archive-receipt.json','observations.tgz','terminal-status.json','summary.json','extraction.json']:shutil.copyfile(src/name,out/name)
with tarfile.open(out/'collection-sources.tar.xz','w:xz')as archive:
 for name in ['config.json','identity.json','collect.py','archive-owned.py','run.sh','launch-command.py','retrieve.py','summarize.py','launch.log','observe-not-before.json']:archive.add(src/name,arcname=name)
 for name in ['prepare-external.py','launch-external.py','record-external.py']:archive.add(r/name,arcname='preparation/'+name)
p=Path('docs/BENCHMARKS.md');prior=p.read_text(encoding='utf-8');(out/'prior-BENCHMARKS.md').write_text(prior,encoding='utf-8',newline='\n');s=prior
summary=json.loads((src/'summary.json').read_text(encoding='utf-8'))
def fmt_range(values,unit):
 factor=1000 if unit=='µs'else 1
 return f'{min(values)*factor:.2f}–{max(values)*factor:.2f} {unit}'
sections=s.split('## Warm execution, compilation and startup')
head,rest=sections
warm,comp=rest.split('Compilation alone includes code construction and disposal under the shared allowance:')
for row in summary['timing']:
 utf16='utf16'in row['case'];label='JSON-to-Markdown / UTF-16 output'if utf16 else'JSON-to-Markdown report'
 med=row['medianMilliseconds'];lane=row['lane'];unit='µs'if lane=='compile'else'ms'
 l=fmt_range([med['candidate'],med['candidate-control']],unit);py=fmt_range([med['CPython'],med['CPython-control']],unit);ratio=f"{min(row['ratioRange']):.2f}–{max(row['ratioRange']):.2f}×"
 status='Variable'if row['lythonControlPercent']>2 or row['maxIqrPercent']>4 else'Diagnostic'
 controls=f"{status}; L{row['lythonControlPercent']:.2f}%, P{row['cpythonControlPercent']:.2f}% / {row['maxIqrPercent']:.2f}%"
 text=f'| {label} | '+('3,072 records /189,441 B | 'if lane=='compile-run'else'')+f'{l} | {py} | {ratio} | `31d65e01` | {controls} |'
 target=head if lane=='compile-run'else comp if lane=='compile'else warm
 lines=target.splitlines();matched=[i for i,line in enumerate(lines)if line.startswith('| '+label+' |')];assert len(matched)==1,(lane,label)
 lines[matched[0]]=text;target='\n'.join(lines)+'\n'
 if lane=='compile-run':head=target
 elif lane=='compile':comp=target
 else:warm=target
s=head+'## Warm execution, compilation and startup'+warm+'Compilation alone includes code construction and disposal under the shared allowance:'+comp
s=s.replace('**Latest measured source:** fully qualified `2d91eb1a`/`161cd935`, collected','''**Latest measured source:** `31d65e01`/`e34cacaf`, collected 2026-11-13 UTC:
complete UTF-8/UTF-16 report warm, compilation and compile-to-result. Six jobs finish
281.260 seconds with complete output/ownership/quiet/join/archive gates. Full
platform/stress/package qualification is pending; focused actual.NET11/10 checks
pass. UTF-8 warm has 3.91% Lython process spread; UTF-16 warm maxIQR is4.04% and
fresh Lython spread2.39%, so those cases remain variable.
[Exact current rows, source and controls](../benchmarks/results/2026-11-13-formatted-helper-slots/README.md).

**Preceding measured source:** fully qualified `2d91eb1a`/`161cd935`, collected''')
s=s.replace('updates CSV and keeps its partial search/compilation rows explicit. Captured-text\nand report comparisons retain their older measured sources and significant gaps. Original/adverse controls and','updates CSV and keeps its partial search/compilation rows explicit. Captured text\nretains its older source. Current report rows are refreshed separately above;\nall retain material warm gaps. Original/adverse controls and')
s=s.replace('five-second warmups per role/job and seven rotated500ms rounds for `2d91eb1a`','eight-second warmups (five for compilation) and seven rotated500ms rounds for\n`31d65e01`; five-second warmups per role/job and seven rotated500ms rounds for `2d91eb1a`')
needle='| Change / affected work | Established result | Limits / evidence |\n| --- | --- | --- |\n'
s=s.replace(needle,needle+'| Formatted helpers in final slots | UTF8/UTF16 report warm elapsed−5.8..−9.1% /−6.5..−8.0%, report compile-to-result−4.9..−8.3%, supporting wider CPU; allocation flat | Shares one formatting kernel; avoids per-row frame/workspace setup. Compilation/text/search uncertainty survives, full delivery pending on31d65e01. External rows above are measured separately. [All source-pair controls](../benchmarks/results/2026-11-13-formatted-helper-slots/README.md) |\n')
p.write_text(s,encoding='utf-8',newline='\n')
p=out.parent/'README.md';s=p.read_text(encoding='utf-8');s+='''

## CPython checkpoint — B652

Same **31d65e01/e34cacaf** runtime, CPython3.13.16, actual.NET11RC3 and common
worker/catalog/adapter. Six affected report jobs complete **281.260s**, with two
independent roles per engine,8s warmups(5s compilation), seven rotated500ms rounds,
normal GC/tiering, complete output/file digests, balanced cleanup, quiet gates,
normal Closed/exit0, joined users and archive/SHA verification before RAM unmount.

| Complete script / phase | Lython | CPython | Lython / CPython | L / P control; maxIQR |
| --- | --- | --- | --- | --- |
'''
for row in summary['timing']:
 med=row['medianMilliseconds'];unit='µs'if row['lane']=='compile'else'ms';label=('UTF16'if'utf16'in row['case']else'UTF8')+' report / '+row['lane']
 s+=f"| {label} | {fmt_range([med['candidate'],med['candidate-control']],unit)} | {fmt_range([med['CPython'],med['CPython-control']],unit)} | {min(row['ratioRange']):.2f}–{max(row['ratioRange']):.2f}× | {row['lythonControlPercent']:.2f}% /{row['cpythonControlPercent']:.2f}%; {row['maxIqrPercent']:.2f}% |\n"
s+='''
Ratio above one means slower. Ranges span independent medians and all four ratio
pairings, not confidence intervals. Warm excludes compilation; compile includes
construction/disposal; compile-run includes both. Timed command-v2 includes mediated
RAM-file I/O, full output validation and prior-result cleanup; startup, fixture
staging/reset, protocol and final teardown are outside those clocks. CPython uses
builtin file I/O; Lython uses efficient host overrides and capability/path checks.

Both reports still have material warm gaps. UTF8 warm process spread3.91%, UTF16
warm maxIQR4.04% and fresh Lython spread2.39% remain visible. This checkpoint does
not qualify other current scripts, async CPU, RSS, pending I/O or embedding tails.
Older/adverse results remain in [the prior guide](b652/prior-BENCHMARKS.md); cross-
collection differences do not isolate one change. Full delivery remains pending.
Last free268935168B; all VM users and RAM fixtures are gone at this terminal state.

[All current rows](b652/summary.json), [raw](b652/observations.tgz),
[collection/analysis](b652/collection-sources.tar.xz), [terminal](b652/terminal-status.json),
[custody](b652/archive-receipt.json).
''';p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');s=s.replace('CPython B652 is active; no new external claim yet.','B652 completes281.260s: current reports are1.23–1.28× CPython warm, UTF8 fresh1.18–1.22× /UTF16 fresh1.22–1.26×; variability visible. Full source qualification pending43350708328.')
s=s.replace('**Active prototype**','**Committed delivery candidate**').replace('| Active prototype |','| Committed delivery candidate |')
s=s.replace('   - B652 is active: six affected report jobs/four independent roles, existing\n     fixed workers/catalog and quiet VM, samee34cacaf source. Refresh','   - B652 complete: six affected report jobs/four independent roles,281.260s,\n     fixed workers/catalog and quiet VM, samee34cacaf source. Current guide refreshed;\n     original/replaced rows remain linked. Reports still have material warm gaps. Refresh')
s=s.replace('B651 is active:','B651 completed:')
p.write_text(s,encoding='utf-8',newline='\n')
print('Current31d65e01 reports versus CPython recorded; six phase rows refreshed, controls/older/adverse evidence retained.',flush=True)
