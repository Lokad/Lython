from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'direct-range-r293/builder-refined'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','src/Lokad.Lython'],text=True).splitlines()
sources={p:sha(p)for p in files}
assert len(sources)==571
for role in ['reference','candidate']:shutil.copytree(old/'candidate',r/role,copy_function=os.link)
(r/'candidate/Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll')
assert sha(r/'reference/Lokad.Lython.dll')=='ed3984730b43db97dca9b0c06f289e57e1124ef232f97537f6eee0c46fe394f3'
shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(head='91064b5d plus R296 shared formatted instructions in final slots',sources=sources,coreSHA256=sha(r/'candidate-core.dll'),referenceSHA256=sha(r/'reference/Lokad.Lython.dll'))
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as archive:
 for p in sources:archive.add(p,arcname=p)
shutil.copyfile(old/'catalog.json',r/'catalog.json');shutil.copytree(old/'tool',r/'tool',copy_function=os.link)
code=(old/'diagnostic.py').read_text(encoding='utf-8').replace("r.parent.parent/'bulk-utf16-r276","r.parent/'bulk-utf16-r276")
(r/'diagnostic.py').write_text(code,encoding='utf-8',newline='\n')
print('R296 frozen',identity['coreSHA256'],'reference',identity['referenceSHA256'],flush=True)
