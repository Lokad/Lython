from pathlib import Path
import os,subprocess,sys
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
phase=sys.argv[1];label=sys.argv[2]
if phase=='build':jobs=[('solution',[str(sdk/'dotnet.exe'),'build','Lokad.Lython.slnx','-c','Release','--disable-build-servers'])]
else:
 names={'internal':['Formatted','FormatProtocolBoundary','DynamicFormattedOwnership','NativeFunctionRefund','SimpleFunctionExecutionBoundary','StringBuilderAdmission','ByteBuilderOwnershipTransaction'],
 'public':['Formatted','FormatProtocol','FormatLifetime','FormatMapping','ConstantFormatLayout','UnicodeStringFormat','NumericFormatPadding','HelperContinuationLifetime']}
 if phase=='focused':
  names['internal']+=['NativeClosure','MemoryBudget','Admission','Ownership','Stack','RecordFieldLookup']
  names['public']+=['CooperativeCancellation','ReturnedIteration','NativeClosure','CallInputLifetime','RecordFieldLookup','Stack','Nonlocal','FunctionDefault','UnicodeFormatCharacter','PercentStringFormatting','TextFileWriteCall','HostFileOutputOwnership']
 jobs=[]
 for framework in (['net11.0']if phase=='quick'else ['net11.0','net10.0']):
  for suite in ['internal','public']:
   project='Lokad.Lython.Tests'if suite=='internal'else'Lokad.Lython.PublicApi.Tests'
   filter='Category!=Stress&('+'|'.join('FullyQualifiedName~'+name for name in names[suite])+')'
   jobs.append((suite+'-'+framework,[str(sdk/'dotnet.exe'),'test',f'tests/{project}/{project}.csproj','-c','Release','-f',framework,'--no-build','--disable-build-servers','--filter',filter]))
for name,args in jobs:
 p=r/f'{phase}-{name}-{label}.log';assert not p.exists()
 with p.open('w',encoding='utf-8',newline='\n')as log:done=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(p.name,'exit',done.returncode,flush=True);print(p.read_text(encoding='utf-8')[-9000:],flush=True)
 if done.returncode:sys.exit(done.returncode)
