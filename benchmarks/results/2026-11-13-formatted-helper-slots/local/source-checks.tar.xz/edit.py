from pathlib import Path
r=Path(__file__).parent
names=['src/Lokad.Lython/Frontend/ExecutableScript.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.PreparedOperations.cs']
for name in names:
 p=Path(name);(r/(p.name+'.before')).write_bytes(p.read_bytes())
p=Path(names[2]);s=p.read_text(encoding='utf-8');start=s.index('        private static bool TryExecuteFormattedInstruction(');end=s.index('        // Only actual protocol values',start)
s=s[:start]+'''        private static bool TryExecuteFormattedInstruction(ref ExecutableWorkState execution,
            ExecutionContext? invocation, in ExecutableInstruction instruction, ExecutionContext context)
        {
            ExecutableFormatField? field = null;
            object? value = null;
            string? specifier = null;
            if (instruction.OpCode is ExecutableOpCode.ConvertFormattedValue or ExecutableOpCode.FormatField)
            {
                var source = instruction.OpCode == ExecutableOpCode.ConvertFormattedValue
                    ? instruction.InputStart : instruction.ResultSlot;
                if (!IsImmediateFormattedValue(execution.Stack[source])) return false;
                if (instruction.OpCode == ExecutableOpCode.FormatField)
                {
                    field = (ExecutableFormatField)execution.Code.Constants[instruction.ConstantIndex]!;
                    specifier = GetExecutableFormatSpecifier(field, field.DynamicSpecifier
                        ? execution.Stack.TakeValue(instruction.ResultSlot + 1, instruction.ResultSlot + 1) : null);
                }
                value = execution.Stack.TakeValue(source, instruction.ResultSlot);
            }
            else if (instruction.OpCode == ExecutableOpCode.AppendFormattedText)
                value = execution.Code.Constants[instruction.ConstantIndex];
            var output = instruction.OpCode is ExecutableOpCode.AppendFormattedText or ExecutableOpCode.FinishFormattedString
                || field?.Append == true ? (GovernedByteBuilder)execution.Stack[instruction.InputStart] : null;
            var result = ExecuteBuiltinFormattedInstruction(instruction, output, value, specifier, field, context);
            if (instruction.OpCode == ExecutableOpCode.FinishFormattedString)
                execution.Stack.RetireTo(instruction.ResultSlot);
            if (result is not null)
            {
                try { PublishInstructionResult(ref execution, invocation, instruction, result); }
                catch { if (result is ExecutableTemporaryValue owned) owned.Dispose(); throw; }
            }
            return true;
        }

'''+s[end:];p.write_text(s,encoding='utf-8',newline='\n')
p=Path(names[1]);s=p.read_text(encoding='utf-8');needle='                    case ExecutableOpCode.Dup:'
assert needle in s;s=s.replace(needle,'''                    case ExecutableOpCode.StartFormattedString or ExecutableOpCode.AppendFormattedText
                        or ExecutableOpCode.FinishFormattedString or ExecutableOpCode.ConvertFormattedValue or ExecutableOpCode.FormatField:
                        if (!Format(instruction)) return false;
                        break;
'''+needle)
needle='        private bool Call(in ExecutableInstruction instruction)'
s=s.replace(needle,'''        private bool Format(in ExecutableInstruction instruction)
        {
            ExecutableFormatField? field = null;
            object? value = null;
            string? specifier = null;
            if (instruction.OpCode is ExecutableOpCode.ConvertFormattedValue or ExecutableOpCode.FormatField)
            {
                var source = instruction.OpCode == ExecutableOpCode.ConvertFormattedValue
                    ? instruction.InputStart : instruction.ResultSlot;
                if (!IsImmediateFormattedValue(Read(source, 0))) return false;
                if (instruction.OpCode == ExecutableOpCode.FormatField)
                {
                    field = (ExecutableFormatField)Code.Constants[instruction.ConstantIndex]!;
                    specifier = GetExecutableFormatSpecifier(field, field.DynamicSpecifier
                        ? TakeFormattedInput(instruction.ResultSlot + 1, instruction.ResultSlot + 1) : null);
                }
                value = TakeFormattedInput(source, instruction.ResultSlot);
            }
            else if (instruction.OpCode == ExecutableOpCode.AppendFormattedText)
                value = Code.Constants[instruction.ConstantIndex];
            var output = instruction.OpCode is ExecutableOpCode.AppendFormattedText or ExecutableOpCode.FinishFormattedString
                || field?.Append == true ? (GovernedByteBuilder)Values[instruction.InputStart] : null;
            var result = ExecuteBuiltinFormattedInstruction(instruction, output, value, specifier, field, _scope);
            if (instruction.OpCode == ExecutableOpCode.FinishFormattedString) Trim(instruction.ResultSlot);
            if (result is not null)
            {
                try { Publish(instruction, result); }
                catch { if (result is ExecutableTemporaryValue owned) owned.Dispose(); throw; }
            }
            return true;
        }

        private object TakeFormattedInput(int source, int liveExtent)
        {
            var value = Values[source];
            Values[source] = null!;
            Trim(liveExtent);
            return value;
        }

'''+needle);p.write_text(s,encoding='utf-8',newline='\n')
p=Path(names[0]);s=p.read_text(encoding='utf-8');needle='        or ExecutableOpCode.MakeList or ExecutableOpCode.MakeTuple or ExecutableOpCode.Return'
assert needle in s;s=s.replace(needle,'''        or ExecutableOpCode.StartFormattedString or ExecutableOpCode.AppendFormattedText
        or ExecutableOpCode.FinishFormattedString or ExecutableOpCode.ConvertFormattedValue or ExecutableOpCode.FormatField
'''+needle);p.write_text(s,encoding='utf-8',newline='\n')
print('Shared semantic kernel, existing instruction/slot transport, no new formatting backend.',flush=True)
