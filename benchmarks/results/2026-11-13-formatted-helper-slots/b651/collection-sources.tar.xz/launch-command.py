from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config={'root': '/home/lokad/lython-bench-checks/formatted-helper-b651-20261113', 'unit': 'lython-b651-formatted-helper-20261113', 'sourceRoot': '/home/lokad/lython-bench-checks/direct-ranges-b648-20261113', 'identity': {'sourceRevision': '91064b5d qualified ed398473 versus R296 e34cacaf formatted helper final slots; same common worker/catalog/adapter', 'coreSHA256': {'reference': 'ed3984730b43db97dca9b0c06f289e57e1124ef232f97537f6eee0c46fe394f3', 'reference-control': 'ed3984730b43db97dca9b0c06f289e57e1124ef232f97537f6eee0c46fe394f3', 'candidate': 'e34cacaf53c3ee96afcfc5b833bb4e40ad05fffc5beaf2cceeb40279570f1c5a', 'candidate-control': 'e34cacaf53c3ee96afcfc5b833bb4e40ad05fffc5beaf2cceeb40279570f1c5a'}, 'auxiliaryFiles': {'Azure.Core.dll': '1d6df436afdc73c30d476be938f6513c90ef8fc884a7bae280091a9bed0a5490', 'Azure.Identity.dll': '31574a3d35ffeb0e25a00ebb317937222fe5283b91af608613f2e3bf0f26c50a', 'BenchmarkDotNet.Annotations.dll': '97974c60500f53a3c7d142088b22d815aae7aac729de69f4b497132cc436594f', 'BenchmarkDotNet.dll': '599ded314fe77dbc17318557e787cf660c1fcb0d69be39994ea462ca95745896', 'CommandLine.dll': '8a55501cd1a1590a4bd93a17c6fdd2c01a0ed5bff1aea9036bdc78d98c9a3fad', 'deniszykov.WebSocketListener.dll': 'c86cfb93e32192ae12fb1a132b4ae785a7d2f325e8583c03c99abf8e832d25d6', 'Dia2Lib.dll': '6c4cac68010fe032218efe5e9fcf46eef9f77bfaa5f3bd33f03c5ff77d5a8fac', 'Gee.External.Capstone.dll': '6dfda67784598de9677173b89d0692593935f1a4024d36040c95dea48c1b5965', 'Iced.dll': 'f058c01321b4cdfc9b9151879e88e59571c8d0ba176fbcf95bc936a8f3d073ed', 'Lokad.Lython.Benchmarks.deps.json': 'b47f293f779ce46eefa92c6eb775842efe363be212c35bf7d155d0b89734d450', 'Lokad.Lython.Benchmarks.dll': 'fec79afdb8425f18aa962d5ff9a3e51ae52f519072ea9d9db8ab69a0c52b69a6', 'Lokad.Lython.Benchmarks.runtimeconfig.json': 'c2ecf2430d6785354d9099b35eef9d6ac3d72f2089dc3dc9fd723558265b83d0', 'Lokad.Lython.Utf8Regex.dll': '9f7282ade883f103956efaf7e46182f7705fb7675f1f46963b9c42ae5aae7f94', 'Lokad.Utf8Regex.dll': 'af5fb1e550cf23559bc7e26ef3d895b45e5ef98d57bcf46b414785a6e24cc857', 'Lokad.Utf8Regex.PythonRe.dll': '96e45b20c1db361a9b3b94bd557405b413510801bdb1488ae5b15d6aae7aedfe', 'Microsoft.Bcl.AsyncInterfaces.dll': 'bf58b47923b2f520c766ca905f68a1a65d217c4d828f05db538c41129cacf9d9', 'Microsoft.CodeAnalysis.CSharp.dll': '1af1de8a162d2312eb2f6b781f5edbe8cec7d5cd268c7e4de24396225e54260f', 'Microsoft.CodeAnalysis.dll': '42c9ce7891470f430267e2dc02d03571f9d046a7e7e121107754bee58d344613', 'Microsoft.Diagnostics.FastSerialization.dll': 'e5bdad179ce97180646f37f357cb7b449f5baaf76f185eb09510eeafc5b773e1', 'Microsoft.Diagnostics.NETCore.Client.dll': 'e2cc9e1f6c97b3c4ee45ebabaa92408eb9b2fc81cb08ceeb342fe48bf79db15f', 'Microsoft.Diagnostics.Runtime.dll': '52d5f113180bb0f70b1a9b10608aef93b187364ac689885d2d3c734102d850a2', 'Microsoft.Diagnostics.Tracing.TraceEvent.dll': '92401392ce1887c3483a3c0085e6cc3656ee39da1be539943096ebabbad6ea21', 'Microsoft.Identity.Client.dll': '5795027e9ae95eececb310a4fed3c502bb368039d186ab0884f64b7792b84717', 'Microsoft.Identity.Client.Extensions.Msal.dll': '07109a2f30df782300077a567ade47cbd0a0502c75cd7c8a62192f7d64bb004e', 'Microsoft.IdentityModel.Abstractions.dll': '24e97b54b6b5c234a124a336757e3116617ac6c30b655cdae74517dc2ecb5746', 'Perfolizer.dll': '4a5508174e2b90a651a29e1de0d2ad88236daaaae01070cd6fc8ca3c36beaa36', 'Pragmastat.dll': '7217e206e47de8a0335f58513019d5805a6e52ca2e8f127e2cc3944f1742bb2e', 'System.ClientModel.dll': 'dec5e22b71a1685c5e6e97cd28b629f0aa6703fb87b6950df28e79fc1804290c', 'System.Memory.Data.dll': '2c1035b0106dbb2de7913d151e06071ed617bb58bbb3d6cd46a2dd0f6a03617b', 'System.Security.Cryptography.ProtectedData.dll': '80566f0839ece5946e66bf9f00d723e59e371ba1341a18e00c7c7a7c49298e1d', 'TraceReloggerLib.dll': '6830c0f1d3f3c17719181e73dd5cfa8ccbb3f3c575329d2120576545103467b5'}, 'catalogSHA256': '61f499f21f914919f422f401bfb8c5b1827a59554662bdd4491873f2238a863f', 'imageSourceArchiveSHA256': 'eab21a1282fa9c09bb43e126e23cbe236662cc5350c8f73760e737e3df54ddf7', 'sourceIdentitySHA256': 'b53d0e33e750efbc185492fc1bc364ce188eba875f6b92c02fa80d599778dd22'}, 'retire': [{'path': 'captured-slots-b638-20261112/candidate/Lokad.Lython.dll', 'sha256': 'e4cc65b251ace242546f337b0846908a4e2a4313953da74df6fb666e1ce87529', 'bytes': 5684736, 'allocatedBytes': 5685248, 'device': 66305, 'inode': 845257, 'links': 11, 'allAliasesInBase': True, 'aliases': ['captured-cpython-b640-20261112/candidate/Lokad.Lython.dll', 'compile-result-b646-20261112/reference/Lokad.Lython.dll', 'ordered-native-b645-20261112/reference/Lokad.Lython.dll', 'captured-slots-b639-20261112/current-core.dll', 'captured-slots-b639-20261112/candidate/Lokad.Lython.dll', 'inline-tuples-b642-20261112/reference/Lokad.Lython.dll', 'captured-slots-b638-20261112/current-core.dll', 'captured-slots-b638-20261112/candidate/Lokad.Lython.dll', 'lexical-cells-b641-20261112/reference/Lokad.Lython.dll', 'ordered-native-b644-20261112/reference/Lokad.Lython.dll', 'ordered-native-b643-20261112/reference/Lokad.Lython.dll'], 'canonical': {'canonical': 'benchmarks/results/2026-11-13-formatted-helper-slots/superseded-vm-cores.tgz', 'member': 'e4cc65b251ace242546f337b0846908a4e2a4313953da74df6fb666e1ce87529/Lokad.Lython.dll', 'bytes': 5684736, 'sha256': 'e4cc65b251ace242546f337b0846908a4e2a4313953da74df6fb666e1ce87529'}}, {'path': 'direct-ranges-b648-20261113/reference/Lokad.Lython.dll', 'sha256': '161cd935023fd95a08488cbf7cfa3ee02ea4b88c69c0ba1231299b6ef0d80447', 'bytes': 5672960, 'allocatedBytes': 5677056, 'device': 66305, 'inode': 845438, 'links': 5, 'allAliasesInBase': True, 'aliases': ['compile-result-b646-20261112/candidate/Lokad.Lython.dll', 'direct-ranges-b648-20261113/reference/Lokad.Lython.dll', 'ordered-native-b645-20261112/current-core.dll', 'ordered-native-b645-20261112/candidate/Lokad.Lython.dll', 'captured-cpu-b647-20261112/candidate/Lokad.Lython.dll'], 'canonical': {'canonical': 'benchmarks/results/2026-11-13-formatted-helper-slots/superseded-vm-cores.tgz', 'member': '161cd935023fd95a08488cbf7cfa3ee02ea4b88c69c0ba1231299b6ef0d80447/Lokad.Lython.dll', 'bytes': 5672960, 'sha256': '161cd935023fd95a08488cbf7cfa3ee02ea4b88c69c0ba1231299b6ef0d80447'}}, {'path': 'direct-ranges-b648-20261113/candidate/Lokad.Lython.dll', 'sha256': '9e53b9fa4e62ba5aa6e7e5154ccbc10c2db086062cc420c8f54fe58483242a8f', 'bytes': 5672960, 'allocatedBytes': 5677056, 'device': 66305, 'inode': 845515, 'links': 4, 'allAliasesInBase': True, 'aliases': ['report-cpu-b649-20261113/candidate/Lokad.Lython.dll', 'direct-ranges-b648-20261113/current-core.dll', 'direct-ranges-b648-20261113/candidate/Lokad.Lython.dll', 'report-cpu-b650-20261113/candidate/Lokad.Lython.dll'], 'canonical': {'canonical': 'benchmarks/results/2026-11-13-direct-range-construction/source-checks.tar.xz', 'member': 'candidate-core.dll', 'bytes': 5672960, 'sha256': '9e53b9fa4e62ba5aa6e7e5154ccbc10c2db086062cc420c8f54fe58483242a8f'}}], 'payloadBytes': 3803480, 'payloadSHA256': 'fe60ce1881b5baf606b94775d32fbe722afb9ae057eb0a7c8add65a85e6cf3de', 'unpackedBytes': 11437669}
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot'])
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and not root.exists()and source.parent==base
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(source/'guest-fixtures').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 for name,sha in config['identity']['auxiliaryFiles'].items():assert digest(source/'candidate'/name)==sha
 before=shutil.disk_usage(base).free;proofs=[]
 for row in config['retire']:
  assert row['allAliasesInBase']and len(row['aliases'])==row['links']
  for name in row['aliases']:
   p=base/name;s=p.lstat()
   assert p.resolve(strict=True)==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()
   assert(s.st_dev,s.st_ino,s.st_size,s.st_nlink)==(row['device'],row['inode'],row['bytes'],row['links'])and digest(p)==row['sha256']
  proofs.append(row)
 required=252*1024*1024+config['unpackedBytes']+1024*1024
 assert before+sum(row['allocatedBytes']for row in proofs)>required
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 def retire(row):
  remaining=row['links']
  for name in row['aliases']:
   p=base/name;s=p.lstat()
   assert p.resolve(strict=True)==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()
   assert(s.st_dev,s.st_ino,s.st_size,s.st_nlink)==(row['device'],row['inode'],row['bytes'],remaining)
   assert digest(p)==row['sha256'];p.unlink();remaining-=1
 # Preserve the currently selected161c reference until the qualifieded398
 # replacement has been installed and hash-verified. All retired bytes are Git-backed.
 for row in proofs:
  if not row['sha256'].startswith('161cd935'):retire(row)
 assert shutil.disk_usage(base).free>252*1024*1024+6*1024*1024
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as archive:
  archive.extract('reference-core.dll',root,filter='data')
  assert digest(root/'reference-core.dll')==config['identity']['coreSHA256']['reference']
  for row in proofs:
   if row['sha256'].startswith('161cd935'):retire(row)
  assert shutil.disk_usage(base).free>252*1024*1024+config['unpackedBytes']-(root/'reference-core.dll').stat().st_size+1024*1024
  for item in archive.getmembers():
   if item.name!='reference-core.dll':archive.extract(item,root,filter='data')
 for role in ['reference','candidate']:
  shutil.copytree(source/'candidate',root/role,copy_function=os.link,ignore=shutil.ignore_patterns('Lokad.Lython.dll'))
  os.link(root/('reference-core.dll'if role=='reference'else'current-core.dll'),root/role/'Lokad.Lython.dll')
  assert digest(root/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]
 os.link(source/'representative.json',root/'representative.json');shutil.copyfile(source/'cpython-worker.py',root/'cpython-worker.py')
 assert digest(root/'representative.json')==config['identity']['catalogSHA256']
 assert digest(root/'source-identity.json')==config['identity']['sourceIdentitySHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 (root/'space-recovery.json').write_text(json.dumps(dict(freshIdleLease=True,beforeFreeBytes=before,afterStagingFreeBytes=shutil.disk_usage(base).free,osFloorMiB=240,evidenceHeadroomMiB=12,requiredBeforeStagingBytes=required,retired=proofs,qualifiedReferenceVerifiedBeforeRetiringPrevious=True),indent=2)+'\n')
 assert shutil.disk_usage(base).free>252*1024*1024
 fixture=root/'guest-fixtures';fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b651-fixtures',str(fixture)],check=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=480','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live
print(live)
