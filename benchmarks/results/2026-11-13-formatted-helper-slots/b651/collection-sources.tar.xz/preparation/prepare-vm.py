from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;out=r/'b651';out.mkdir();old=r.parent/'direct-range-r293/b648'
oldroot='/home/lokad/lython-bench-checks/direct-ranges-b648-20261113';root='/home/lokad/lython-bench-checks/formatted-helper-b651-20261113'
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['sources'].items())
info=json.loads((old/'identity.json').read_text(encoding='utf-8'));info['sourceRevision']='91064b5d qualified ed398473 versus R296 e34cacaf formatted helper final slots; same common worker/catalog/adapter'
info['coreSHA256']={k:identity['referenceSHA256'if k.startswith('reference')else'coreSHA256']for k in ['reference','reference-control','candidate','candidate-control']}
info['sourceIdentitySHA256']=hashlib.sha256((r/'candidate-identity.json').read_bytes()).hexdigest()
jobs=[['scripts.report-render.large','warm'],['scripts.report-render.utf16.large','warm'],['scripts.report-render.large','compile'],['scripts.report-render.large','compile-run'],['scripts.csv-validated-records.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.file-search.large','warm']]
collect=(old/'collect.py').read_text(encoding='utf-8').replace(oldroot,root)
start=collect.index('jobs=');end=collect.index('\nenv = ',start)
collect=collect[:start]+'jobs='+repr(jobs)+'\nassert len(jobs)==7 and all(case in cases for case,lane in jobs)\n'+collect[end:]
collect=collect.replace('< 360,','< 420,').replace('Reserve60seconds','Reserve60seconds')
collect=collect.replace('("scripts.report-render.large","scripts.json-summary-helpers.large")','("scripts.report-render.large","scripts.report-render.utf16.large","scripts.json-summary-helpers.large")')
start=collect.index("purpose='");end=collect.index("',\n",start)
collect=collect[:start]+"purpose='Formatted helper operations shared with native final slots; no new semantic backend or controller; allocation flat; report encodings/compile/compile-run and CSV/captured/search controls"+collect[end:]
ast.parse(collect);(out/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
archive=(old/'archive-owned.py').read_text(encoding='utf-8').replace(oldroot,root).replace("len(raw['jobs'])==6","len(raw['jobs'])==7").replace('complete=True,jobs=6','complete=True,jobs=7').replace("'current-core.dll','candidate-sources.tar.xz'","'current-core.dll','reference-core.dll','candidate-sources.tar.xz'")
ast.parse(archive);(out/'archive-owned.py').write_text(archive,encoding='utf-8',newline='\n')
(out/'run.sh').write_text('set -eu\nroot='+root+'\ntrap \'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"\' EXIT\npython3 "$root/collect.py"\n',encoding='utf-8',newline='\n')
(out/'identity.json').write_text(json.dumps(info,indent=2)+'\n',encoding='utf-8',newline='\n')
files={name:out/name for name in ['collect.py','archive-owned.py','run.sh','identity.json']}
files.update({'reference-core.dll':r/'reference/Lokad.Lython.dll','current-core.dll':r/'candidate-core.dll','source-identity.json':r/'candidate-identity.json'})
with tarfile.open(out/'payload.tgz','w:gz')as archive:
 for name,p in files.items():archive.add(p,arcname=name)
groups=json.loads((r/'core-retirement-inspection.json').read_text(encoding='utf-8'))['groups']
assert len(groups)==3 and all(x['allAliasesInBase']for x in groups)
config=dict(root=root,unit='lython-b651-formatted-helper-20261113',sourceRoot=oldroot,identity=info,retire=groups,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum(p.stat().st_size for p in files.values()))
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
retrieve=(old/'retrieve.py').read_text(encoding='utf-8').replace('direct-ranges-b648-20261113','formatted-helper-b651-20261113').replace('lython-b648-direct-ranges-20261113','lython-b651-formatted-helper-20261113').replace("['jobs']==6","['jobs']==7").replace("['elapsedSeconds']<480","['elapsedSeconds']<540").replace('B648 six-job','B651 seven-job')
ast.parse(retrieve);(out/'retrieve.py').write_text(retrieve,encoding='utf-8',newline='\n')
(out/'summarize.py').write_text((old/'summarize.py').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
print('Seven jobs/four roles;480s owner/30s stop/30s margin; existing quiet VM, sources exact; staged',config['unpackedBytes'],flush=True)
