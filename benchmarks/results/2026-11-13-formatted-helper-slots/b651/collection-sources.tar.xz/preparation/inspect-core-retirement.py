from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent
archives=['benchmarks/results/2026-11-13-formatted-helper-slots/superseded-vm-cores.tgz','benchmarks/results/2026-11-13-direct-range-construction/source-checks.tar.xz']
proofs=[]
for name in archives:
 p=Path(name);assert subprocess.check_output(['git','show','HEAD:'+name])==p.read_bytes()
 with tarfile.open(p)as archive:
  for member in archive.getmembers():
   if member.isfile()and member.name.endswith('.dll'):
    data=archive.extractfile(member).read();proofs.append(dict(canonical=name,member=member.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(r/'core-retirement-canonical.json').write_text(json.dumps(proofs,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Committed binary copies',proofs)
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks')
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 users=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True)
 assert users.returncode==1,users.stdout
 known=[base/'captured-slots-b638-20261112/candidate/Lokad.Lython.dll',base/'direct-ranges-b648-20261113/reference/Lokad.Lython.dll',base/'direct-ranges-b648-20261113/candidate/Lokad.Lython.dll']
 rows=[]
 for p in known:
  s=p.lstat();assert p.resolve()==p and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()
  sha=hashlib.sha256(p.read_bytes()).hexdigest();proof=next((x for x in PROOFS if x['sha256']==sha),None)
  if proof is None: rows.append(dict(path=str(p),canonicalMissing=True,sha256=sha));continue
  aliases=[]
  for root,dirs,files in os.walk(base,followlinks=False):
   for name in files:
    a=Path(root)/name;z=a.lstat()
    if(z.st_dev,z.st_ino)==(s.st_dev,s.st_ino):
     assert a.resolve()==a and stat.S_ISREG(z.st_mode)and z.st_uid==os.getuid()
     aliases.append(str(a.relative_to(base)))
  rows.append(dict(path=str(p.relative_to(base)),sha256=sha,bytes=s.st_size,allocatedBytes=s.st_blocks*512,device=s.st_dev,inode=s.st_ino,links=s.st_nlink,allAliasesInBase=len(aliases)==s.st_nlink,aliases=aliases,canonical=proof))
 print(json.dumps(dict(freshIdleLease=True,freeBytes=shutil.disk_usage(base).free,groups=rows)))
'''.replace('PROOFS',repr(proofs))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
(r/'core-retirement-inspection.json').write_text(done.stdout,encoding='utf-8')
d=json.loads(done.stdout);print('Read-only idle lease free',d['freeBytes']);print([(x['path'],x.get('allocatedBytes'),x.get('links'),x.get('allAliasesInBase'))for x in d['groups']])
