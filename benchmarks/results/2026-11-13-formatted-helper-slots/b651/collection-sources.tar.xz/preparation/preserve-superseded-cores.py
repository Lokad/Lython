from pathlib import Path
import hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-13-formatted-helper-slots');out.mkdir()
old=[('captured-slots-b638-20261112/candidate/Lokad.Lython.dll','e4cc65b251ace242546f337b0846908a4e2a4313953da74df6fb666e1ce87529','9bca1337'),('direct-ranges-b648-20261113/reference/Lokad.Lython.dll','161cd935023fd95a08488cbf7cfa3ee02ea4b88c69c0ba1231299b6ef0d80447','2d91eb1a')]
code='''from pathlib import Path
import fcntl,hashlib,io,json,os,stat,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks')
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz')as archive:
  for name,sha,commit in OLD:
   p=base/name;s=p.lstat();assert p.resolve()==p and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()
   data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==sha
   info=tarfile.TarInfo(sha+'/Lokad.Lython.dll');info.size=len(data);info.mtime=0;archive.addfile(info,io.BytesIO(data))
'''.replace('OLD',repr(old))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code.encode(),capture_output=True);assert done.returncode==0,done.stderr.decode()
p=out/'superseded-vm-cores.tgz';p.write_bytes(done.stdout)
proofs=[]
with tarfile.open(p)as archive:
 for name,sha,commit in old:
  member=sha+'/Lokad.Lython.dll';data=archive.extractfile(member).read();assert hashlib.sha256(data).hexdigest()==sha
  proofs.append(dict(canonical=p.as_posix(),member=member,sha256=sha,bytes=len(data),historicalCommit=commit,formerRemotePath=name))
(out/'superseded-cores.json').write_text(json.dumps(dict(purpose='Preserve exact historical worker cores before retiring superseded VM inode aliases; no historical measurements or source identities changed.',archiveSHA256=hashlib.sha256(done.stdout).hexdigest(),cores=proofs),indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Formatted helper final-slot experiment

Active uncommitted R296 prototype over91064b5d/ed398473. Formatting semantics are
shared by the ordinary frame and native final slots. Initial actual.NET11/10
focused suites and seven complete sync/async scripts pass; allocation is flat and
desktop elapsed controls move. No CPU or CPython gain is claimed at preparation.

The exact historical cores below are preserved before their superseded VM inode
aliases are retired to stage the qualified reference and new candidate without
reducing disk/evidence headroom. Their earlier source proof and raw measurements
remain in the original result directories. These are benchmark evidence, not
release packages. Publication/tagging remain held.

[Historical core copies](superseded-vm-cores.tgz), [identities](superseded-cores.json).
''',encoding='utf-8',newline='\n')
subprocess.run(['git','add','--',str(out)],check=True)
subprocess.run(['git','commit','-m','Preserve superseded benchmark cores before VM staging [skip ci]'],check=True)
print('Historical core bytes committed; remote files unchanged.',flush=True)
