using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;

var assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.GetFullPath(args[0]));
var type = assembly.GetType("Lokad.Lython.Runtime.Text.PyString", throwOnError: true)!;
var method = type.GetMethod("FromOwnedUtf8", BindingFlags.Static | BindingFlags.NonPublic,
    binder: null, types: [typeof(byte[])], modifiers: null)!;
var actual = method.CreateDelegate<Func<byte[], object>>();
Func<byte[], object> model = static bytes => new WindowShape { Utf8 = new(bytes) };
byte[] payload = [65]; // Backing allocated once, outside every observation.
foreach (var factory in new[] { actual, model })
    for (var index = 0; index < 8192; index++) Volatile.Write(ref Sink.Value, factory(payload));
long Observe(Func<byte[], object> factory)
{
    var before = GC.GetAllocatedBytesForCurrentThread();
    for (var index = 0; index < 8192; index++) Volatile.Write(ref Sink.Value, factory(payload));
    return (GC.GetAllocatedBytesForCurrentThread() - before) / 8192;
}
Console.WriteLine(JsonSerializer.Serialize(new
{
    runtime = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
    corePath = assembly.Location,
    coreSha256 = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(assembly.Location))),
    actualBeforeBytes = Observe(actual), modelBytes = Observe(model), actualAfterBytes = Observe(actual),
    note = "Object metadata allocation only, same preallocated payload; synthetic managed window shape, not an implemented runtime or CPU measurement."
}));

static class Sink { public static object? Value; }

// Same retained semantic roles, with segment backing and a shared-payload flag;
// derive cache bytes from RuneByteOffsets rather than keep another long field.
sealed class WindowShape
{
    public ArraySegment<byte> Utf8;
    public object? MemoryGovernor = null;
    public object? AllocationSpan = null;
    public int RuneLength = -1;
    public int[]? RuneByteOffsets = null;
    public int HashCode = 0;
    public bool HashCodeComputed = false;
    public bool SharesPayload = false;
}
