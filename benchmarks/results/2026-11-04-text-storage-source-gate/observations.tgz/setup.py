from pathlib import Path
root=Path('/home/lokad/lython-bench-checks/text-storage-cost-b204-20261104')
(root/'candidate').symlink_to('/home/lokad/lython-bench-checks/list-backing-b203-20261104/refinement/candidate',target_is_directory=True)
