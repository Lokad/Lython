from pathlib import Path
import subprocess,json,hashlib,tarfile,fcntl
root=Path('/home/lokad/lython-bench-checks/csv-frame-cost-b310-20261106')
status=subprocess.check_output(['systemctl','show','lython-b310-csv-frame-cost-20261106','--property=LoadState,ActiveState,Result,MainPID'],text=True)
assert 'ActiveState=inactive' in status and 'MainPID=0' in status and 'Result=success' in status,status
assert (root/'started.utc').is_file() and (root/'stopped.utc').is_file() and (root/'exit-code.txt').read_text().strip()=='0'
(root/'final-service-status.txt').write_text(status,encoding='utf-8')
for n in ['before','after']:assert json.loads((root/f'machine-{n}.json').read_text(encoding='utf-8'))['gate']['quiet']
with open(root.parent/'comparison-vm.lock','w') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 for n in ['csv']:
  record=json.loads((root/'perf'/n/'record.json').read_text(encoding='utf-8'))
  assert record['exitCode']==0 and record['verificationBefore']['status']=='Equivalent' and record['verificationAfter']['status']=='Equivalent'
  assert record['response']['status']=='Completed'
  subprocess.run(['python3',str(root/'analyze-cpu-guest.py'),str(root/'perf'/n)],check=True,timeout=20)
 with tarfile.open(root/'observations.tgz','w:gz') as t:
  for f in root.iterdir():
   if f.name not in ['candidate','core','observations.tgz','payload.tgz']:
    if f.is_dir():
     for x in f.rglob('*'):
      if x.is_file():t.add(x,arcname=str(x.relative_to(root)))
    elif f.is_file():t.add(f,arcname=f.name)
print(hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest())
