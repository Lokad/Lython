from pathlib import Path
import hashlib, json, tarfile

lab=Path(__file__).resolve().parent
out=lab.parents[4]/"benchmarks/results/2026-11-24-shared-function-defaults/confirmation"
quiet=lab/"comparison/quiet"
def read(p): return json.loads(p.read_text(encoding="utf-8-sig"))
identity=read(quiet/"identity.json")
prior=read(lab.parent/"comparison/quiet/identity.json")
assert identity["imageFiles"]==prior["imageFiles"]
assert identity["coreSHA256"]==prior["coreSHA256"] and identity["sourcePatchSHA256"]==prior["sourcePatchSHA256"]
for role in identity["imageFiles"]:
    proof=read(lab/"comparison"/(role+"-verify.json"))
    assert proof["caseCount"]==2 and proof["state"]=="Completed"
    assert proof["catalogSha256"]==identity["catalogs"]["representative.json"]["sha256"]
    assert proof["launched"]["library"]["sha256"]==identity["coreSHA256"][role]
assert hashlib.sha256((out/"quiet-observations.tar.xz").read_bytes()).hexdigest()==read(quiet/"terminal-status.json")["receipt"]["archiveSHA256"]
with tarfile.open(out/"procedures.tar.xz", "w:xz") as archive:
    for name in ("prepare.py", "archive.py", "archive-quiet.py", "quiet.py", "verified-raw-replicas.json",
                 "comparison/candidate-verify.json", "comparison/reference-verify.json", "comparison/quiet/storage-custody.json"):
        archive.add(lab/name, arcname=name, recursive=False)
    for name in ("windows-net10.log", "ubuntu-net10.log"):
        if (lab.parent/name).is_file(): archive.add(lab.parent/name, arcname=name, recursive=False)
