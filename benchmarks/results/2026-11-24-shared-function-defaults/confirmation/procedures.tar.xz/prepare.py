from pathlib import Path
import hashlib, json, shutil, tarfile

lab = Path(__file__).resolve().parent
parent = lab.parent
repo = lab.parents[4]
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True, exist_ok=True)
prior = parent / "comparison/quiet"
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def save(path, value): path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")
identity = read(prior / "identity.json")
for role, manifest in identity["imageFiles"].items():
    assert len(manifest)==32 and {p.name:sha(p) for p in (parent / role).iterdir()} == manifest
assert sha(parent / "candidate.patch") == identity["sourcePatchSHA256"]
jobs = [("scripts.rule-default-closures", "warm"), ("scripts.rule-default-closures", "compile-run"),
        ("scripts.csv-invoice.method-policy.quoted-control", "warm")]
catalog=read(prior / "representative.json")
catalog["cases"]=[row for row in catalog["cases"] if row["id"] in {case for case, _ in jobs}]
save(quiet / "representative.json", catalog)
save(quiet / "jobs.json", {"warm":jobs})
identity["purpose"]="Confirm defaulted-rule timings using the unchanged B1629 worker images"
identity["catalogs"]={name:{"sha256":sha(quiet/name)} for name in ("representative.json","jobs.json")}
save(quiet / "identity.json", identity)
collector=(prior/"collect.py").read_text(encoding="utf-8").replace("len(jobs) == 7","len(jobs) == 3").replace("b1629-fixtures","b1630-fixtures")
compile(collector, "collect.py", "exec")
(quiet/"collect.py").write_text(collector, encoding="utf-8", newline="\n")
shutil.copyfile(prior/"run.sh", quiet/"run.sh")
assert b"\r" not in (quiet/"run.sh").read_bytes()

payload=quiet/"payload.tar.gz"
with tarfile.open(payload, "w:gz", compresslevel=3) as archive:
    for name in ("identity.json","jobs.json","representative.json","collect.py","run.sh"):
        archive.add(quiet/name,arcname=name,recursive=False)
save(quiet/"upload.json",dict(root="shared-function-defaults-confirm-b1630-20261124",
    reference="shared-function-defaults-b1629-20261124",payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
replicas=[]
for location, bundle_path in [
    ("shared-function-defaults-b1629-20261124", prior/"observations.tar.xz"),
    ("closed-line-helper-b1608-20261124", repo/"benchmarks/results/2026-11-24-closed-line-helper/observations.tar.xz"),
]:
    if not bundle_path.is_file(): continue
    with tarfile.open(bundle_path) as bundle:
        raw=bundle.extractfile("confirmation/confirmation.json").read()
    replicas.append(dict(location=location,bytes=len(raw),rawSHA256=hashlib.sha256(raw).hexdigest(),archiveSHA256=sha(bundle_path)))
save(lab/"verified-raw-replicas.json",replicas)
launch=(parent/"quiet.py").read_text(encoding="utf-8")
launch=launch.replace("lython-b1629-shared-function-defaults-", "lython-b1630-shared-function-defaults-confirm-").replace("b1629-","b1630-")
oldsha=read(parent.with_name("accounted-total-20261124")/"comparison/quiet/terminal-status.json")["receipt"]["archiveSHA256"]
newsha=read(prior/"terminal-status.json")["receipt"]["archiveSHA256"]
assert oldsha in launch and sha(prior/"observations.tar.xz")==newsha
launch=launch.replace(oldsha,newsha).replace("RuntimeMaxSec=310","RuntimeMaxSec=175").replace("seconds=236","seconds=111")
launch=launch.replace(",'candidate-core.dll'","")
start=launch.index("   if name=='Lokad.Lython.dll' and role=='candidate':")
end=launch.index("   assert digest(image/name)==sha",start)
launch=launch[:start]+"   os.link(reference/role/name,image/name)\n"+launch[end:]
compile(launch,"quiet.py","exec")
(lab/"quiet.py").write_text(launch,encoding="utf-8",newline="\n")
print("Prepared a repeat using both unchanged immutable images")
