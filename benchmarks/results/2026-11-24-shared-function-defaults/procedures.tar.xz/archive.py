from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
out = repo / "benchmarks/results/2026-11-24-shared-function-defaults"
quiet = lab / "comparison/quiet"
def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

identity = read(quiet / "identity.json")
assert sha(lab / "candidate.patch") == identity["sourcePatchSHA256"]
assert (lab / "candidate.patch").read_bytes() == subprocess.check_output(
    ["git", "diff", "--binary", "--", "src", "tests"], cwd=repo)
for role, manifest in identity["imageFiles"].items():
    assert len(manifest) == 32 and {p.name: sha(p) for p in (lab / role).iterdir()} == manifest
    assert sha(lab / ("probe-" + role) / "Lokad.Lython.dll") == manifest["Lokad.Lython.dll"]
    proof = read(lab / "comparison" / (role + "-verify.json"))
    assert proof["caseCount"] == 4 and proof["state"] == "Completed"
    assert proof["catalogSha256"] == identity["catalogs"]["representative.json"]["sha256"]
    for mode in ("sync", "async"):
        rows = [json.loads(row) for row in (lab / f"oracle-{role}-{mode}.jsonl").read_text(encoding="utf-8").splitlines()]
        assert len(rows) == 5 and all(row["Matches"] and row["Options"]["Async"] == (mode == "async") for row in rows)

for platform in ("windows", "ubuntu"):
    for kind, count in (("white", 817), ("public", 1263)):
        report = (lab / f"{platform}-{kind}.log").read_text(encoding="utf-8-sig")
        assert "Failed:     0" in report and str(count) in report

allocations = read(lab / "allocation-summary.json")
assert len(allocations) == 4
for row in allocations:
    if "dataclass" in row["case"]:
        assert row["allocationBytes"] == [492104, 483600] and row["peakAdmission"] == [392051, 387443]
    else:
        assert row["peakAdmission"][0] == row["peakAdmission"][1] and row["allocationBytes"][0] == row["allocationBytes"][1]

out.mkdir(exist_ok=True)
for path in (quiet / "identity.json", lab / "allocation-summary.json"):
    shutil.copyfile(path, out / path.name)
with tarfile.open(out / "procedures.tar.xz", "w:xz") as archive:
    for name in ["archive.py", "archive-quiet.py", "prepare.py", "oracle-input.json", "oracle.py",
                 "allocations.py", "quiet.py", "candidate.patch", "replicas.py", "verified-raw-replicas.json",
                 "reference-allocation.json", "candidate-allocation.json",
                 "windows-white.log", "windows-public.log", "ubuntu-white.log", "ubuntu-public.log",
                 "comparison/candidate-verify.json", "comparison/reference-verify.json",
                 "comparison/quiet/jobs.json", "comparison/quiet/representative.json",
                 "comparison/quiet/storage-custody.json"] + [
                     f"oracle-{role}-{mode}.jsonl" for role in ("reference", "candidate") for mode in ("sync", "async")]:
        archive.add(lab / name, arcname=name, recursive=False)
