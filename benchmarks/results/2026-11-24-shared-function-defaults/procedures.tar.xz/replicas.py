from pathlib import Path
import hashlib, json, tarfile
lab = Path(__file__).resolve().parent
repo = lab.parents[3]
records = [
    ("forwarded-positional-cpython-b1625-20261124", "2026-11-24-forwarded-positional-cpython",
     1615826, "7d12b410b83d81db1808b5f2f8c0f4f8e3cf462170cce17331a05ad486bad9ae",
     "80f38aa7b7023fd1bad5b5243528aee9a7c715551f62f336c8bfed44ae3acb18"),
    ("prepared-closed-defaults-b1606-20261124", "2026-11-24-prepared-closed-defaults",
     937884, "9dc75fbb8120d102d8babbe44faad1a636ac27ede5489bf50045ded847f5890f",
     "c2d1fb30d37f5f2e60ba459fdd60ff2564eaaab21900d0a82dfb10b69f80c700"),
]
custody = []
for location, folder, size, raw_hash, archive_hash in records:
    archive = next(p for p in (repo / "benchmarks/results" / folder).glob("*.tar.xz")
                   if hashlib.sha256(p.read_bytes()).hexdigest() == archive_hash)
    with tarfile.open(archive) as bundle:
        raw = bundle.extractfile(next(item for item in bundle.getmembers() if item.name.endswith("/confirmation.json"))).read()
        assert len(raw) == size and hashlib.sha256(raw).hexdigest() == raw_hash
    custody.append(dict(location=location, bytes=size, rawSHA256=raw_hash, archiveSHA256=archive_hash))
(lab / "verified-raw-replicas.json").write_text(json.dumps(custody, indent=2) + "\n", encoding="utf-8")
