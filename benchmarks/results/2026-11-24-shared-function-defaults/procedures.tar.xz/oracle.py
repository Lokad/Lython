from pathlib import Path
import hashlib, json, os, shutil, subprocess, textwrap

lab = Path(__file__).resolve().parent
sdk = Path.home() / ".dotnet11"
sources = {
    "class-namespace": """
        events = []
        def seen(tag, obj):
            events.append(tag)
            return obj
        class Handler:
            seed = [3]
            dispatch = lambda first=seen('a', seed), *, left=seen('b', seed), right=seen('c', [9]): (first, left, right)
        f = Handler.dispatch
        first, left, right = f()
        print(events, first is left, first is Handler.seed, right)
        keywords = f.__kwdefaults__
        keywords['left'] = right
        print(keywords is f.__kwdefaults__, f()[1] is right)
    """,
    "class-default-failure": """
        events = []
        def choose(label):
            events.append(label)
            if label == 'fail':
                raise ValueError('stopped')
            return label
        try:
            class Handler:
                dispatch = lambda first=choose('first'), *, left=choose('fail'), right=choose('never'): first
        except ValueError as err:
            print(str(err), events)
    """,
    "dataclass-mixed": """
        from dataclasses import dataclass, field
        @dataclass
        class Request:
            retries: int = field(kw_only=True, default=3)
            path: str = '/input'
            timeout: int = field(kw_only=True)
            labels: list = field(kw_only=True, default_factory=list)
            mode: str = 'read'
        first = Request(timeout=7)
        first.labels.append('seen')
        second = Request('/other', 'write', timeout=12, retries=1)
        def try_missing(build):
            try:
                build()
            except TypeError as err:
                print(type(err).__name__, 'timeout' in str(err))
        try_missing(Request)
        print(first.path, first.mode, first.retries, first.timeout, first.labels)
        print(second.path, second.mode, second.retries, second.timeout, second.labels)
    """,
    "annotation-and-default-order": """
        events = []
        def seen(name):
            events.append(name)
            return int
        def factory(seed):
            def rule(record: seen('record'), base: seen('base')=seed%11, *, weight: seen('weight')=seed%7+1) -> seen('return'):
                return (record+base)*weight
            return rule
        a = factory(13)
        b = factory(8)
        kw = a.__kwdefaults__
        kw['weight'] = 9
        print(events, a(7), b(7), a(7, weight=2))
    """,
    "unicode-keywords": """
        from __future__ import annotations
        def parse(seed):
            def rule(value: 'argument', *, mín=seed, máx=2):
                return mín+máx+value
            return rule
        f = parse(7)
        print(f(2), f(3, mín=4), list(f.__kwdefaults__))
        defaults = f.__kwdefaults__
        f.__kwdefaults__ = {'mín': 1, 'máx': 8}
        print(f(2), defaults, f.__annotations__)
    """,
}
sources = {name: textwrap.dedent(source).strip() + "\n" for name, source in sources.items()}
input_json = json.dumps(list(sources.values()), ensure_ascii=False)
(lab / "oracle-input.json").write_text(json.dumps(sources, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
donor = lab.with_name("accounted-total-20261124")
manifest = json.loads((lab / "comparison/quiet/identity.json").read_text(encoding="utf-8"))["imageFiles"]
for role in ("reference", "candidate"):
    probe = lab / ("probe-" + role)
    shutil.copytree(donor / ("probe-" + role), probe, dirs_exist_ok=True)
    shutil.copyfile(lab / role / "Lokad.Lython.dll", probe / "Lokad.Lython.dll")
    assert hashlib.sha256((probe / "Lokad.Lython.dll").read_bytes()).hexdigest() == manifest[role]["Lokad.Lython.dll"]
    for mode in ("sync", "async"):
        args = [sdk / "dotnet.exe", probe / "LythonProbe.dll", "--batch-json", "--compare-python", "--python", "C:/Python313/python.exe"]
        if mode == "async": args.append("--async")
        result = subprocess.run(args, env=env, input=input_json, encoding="utf-8", capture_output=True, timeout=45)
        raw = result.stdout
        (lab / f"oracle-{role}-{mode}.jsonl").write_text(raw, encoding="utf-8")
        print(role, mode, result.returncode, result.stderr.strip())
        for (name, _), row in zip(sources.items(), raw.splitlines(), strict=True):
            report = json.loads(row)
            if report["Matches"]: print(" ", name, "match")
            else: print(" ", name, "mismatch", report["Lython"], report["CPython"])
