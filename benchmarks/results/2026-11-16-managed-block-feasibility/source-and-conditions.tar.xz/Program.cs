using System.Diagnostics;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text.Json;

// API and compilation-cost feasibility only. No Lython execution/speedup claim.
// Uses only standard managed expression APIs, not raw IL or interop.
var report = new Dictionary<string, object?>
{
    ["purpose"] = "Managed borrowed-storage expression feasibility; not Lython performance",
    ["framework"] = RuntimeInformation.FrameworkDescription,
    ["os"] = RuntimeInformation.OSDescription,
    ["dynamicCodeSupported"] = RuntimeFeature.IsDynamicCodeSupported,
    ["dynamicCodeCompiled"] = RuntimeFeature.IsDynamicCodeCompiled,
    ["localTimingDiagnosticOnly"] = true,
    ["newRuntimeDependency"] = false,
    ["shapeOrder"] = args.Contains("--reverse") ? "ref-state-first" : "span-first",
    ["measurementBoundary"] = "Expression construction/Compile and first invocation separately; independently sampled intervals must not be treated as whole-script latency.",
};
var rows = new List<object>();
foreach (var byRefState in args.Contains("--reverse") ? new[] { true, false } : new[] { false, true })
{
    var observations = new List<object>();
    try
    {
        for (var attempt = 0; attempt < 12; attempt++)
        {
            var started = Stopwatch.GetTimestamp();
            var bytes = GC.GetAllocatedBytesForCurrentThread();
            var input = Expression.Parameter(byRefState ? typeof(MachineState).MakeByRefType() : typeof(Span<long>), "input");
            Expression values = byRefState ? Expression.Field(input, nameof(MachineState.Values)) : input;
            var index = Expression.Variable(typeof(int), "index");
            var total = Expression.Variable(typeof(long), "total");
            var end = Expression.Label(typeof(long), "return");
            var next = Expression.Call(typeof(Operations).GetMethod(nameof(Operations.Read))!, values, index);
            var body = Expression.Block([index, total],
                Expression.Assign(index, Expression.Constant(0)),
                Expression.Assign(total, Expression.Constant(0L)),
                Expression.Loop(Expression.IfThenElse(
                    Expression.LessThan(index, Expression.Call(typeof(Operations).GetMethod(nameof(Operations.Count))!, values)),
                    Expression.Block(
                        Expression.AddAssignChecked(total, Expression.AddChecked(Expression.MultiplyChecked(next, Expression.Constant(2L)), Expression.Constant(1L))),
                        Expression.PostIncrementAssign(index), Expression.Empty()),
                    Expression.Break(end, total)), end));
            Delegate program = byRefState
                ? Expression.Lambda<StateProgram>(body, input).Compile()
                : Expression.Lambda<SpanProgram>(body, input).Compile();
            var elapsed = Stopwatch.GetElapsedTime(started).TotalMilliseconds;
            var allocated = GC.GetAllocatedBytesForCurrentThread() - bytes;
            Span<long> storage = [0, 1, 2, 3];
            var state = new MachineState(storage);
            var invokeStarted = Stopwatch.GetTimestamp();
            var invokeBytes = GC.GetAllocatedBytesForCurrentThread();
            var result = byRefState ? ((StateProgram)program)(ref state) : ((SpanProgram)program)(storage);
            var invokeElapsed = Stopwatch.GetElapsedTime(invokeStarted).TotalMilliseconds;
            var invokeAllocated = GC.GetAllocatedBytesForCurrentThread() - invokeBytes;
            if (result != 16 || !storage.SequenceEqual([0, 1, 2, 3])) throw new InvalidOperationException("Incorrect compiled result or changed borrowed input.");
            observations.Add(new { attempt, firstInShape = attempt == 0, compileMilliseconds = elapsed,
                compileAllocatedBytes = allocated, firstInvocationMilliseconds = invokeElapsed,
                firstInvocationAllocatedBytes = invokeAllocated, correctResult = result, borrowedInputPreserved = true });
        }
        rows.Add(new { shape = byRefState ? "ref-managed-state-containing-span" : "span-argument", supported = true, observations });
    }
    catch (Exception failure)
    {
        rows.Add(new { shape = byRefState ? "ref-managed-state-containing-span" : "span-argument", supported = false, observations,
            error = failure.ToString() });
    }
}
report["rows"] = rows;
Console.WriteLine(JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true }));

public delegate long SpanProgram(Span<long> values);
public delegate long StateProgram(ref MachineState state);
public ref struct MachineState(Span<long> values)
{
    public Span<long> Values = values;
}
public static class Operations
{
    public static long Read(Span<long> values, int index) => values[index];
    public static int Count(Span<long> values) => values.Length;
}
