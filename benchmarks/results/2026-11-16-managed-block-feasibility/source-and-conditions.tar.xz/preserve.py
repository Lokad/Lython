from pathlib import Path
import hashlib,json,shutil,statistics,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-16-managed-block-feasibility';out.mkdir(exist_ok=False)
rows=[]
for name in ['corrected-span-first.json','corrected-state-first.json']:
 data=json.loads((r/name).read_text(encoding='utf-8-sig'))
 for row in data['rows']:
  assert row['supported']and len(row['observations'])==12
  obs=row['observations'];rest=obs[1:]
  assert all(x['correctResult']==16 and x['borrowedInputPreserved']and x['firstInvocationAllocatedBytes']==0 for x in obs)
  rows.append(dict(processOrder=data['shapeOrder'],shape=row['shape'],firstCompileMilliseconds=obs[0]['compileMilliseconds'],firstInvocationMilliseconds=obs[0]['firstInvocationMilliseconds'],warmCompileMedianMilliseconds=statistics.median(x['compileMilliseconds']for x in rest),warmCompileRangeMilliseconds=[min(x['compileMilliseconds']for x in rest),max(x['compileMilliseconds']for x in rest)],warmFirstInvocationMedianMilliseconds=statistics.median(x['firstInvocationMilliseconds']for x in rest),warmCompileAllocatedBytes=statistics.median(x['compileAllocatedBytes']for x in rest)))
identity=dict(sourceRevision='01c6c72a',purpose='Managed API/compilation-cost feasibility only; no Lython CPU or speedup claim',runtimeUnchanged=True,apiSupported=True,newProductionDependency=False,productionPrototypeSelected=False,rows=rows,sourceSHA256={n:hashlib.sha256((r/n).read_bytes()).hexdigest()for n in ['Program.cs','Feasibility.csproj']},programSHA256=hashlib.sha256((r/'bin/Release/net11.0/Feasibility.dll').read_bytes()).hexdigest())
(out/'summary.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for n in ['original-observations.json','corrected-span-first.json','corrected-state-first.json']:shutil.copy2(r/n,out/n)
with tarfile.open(out/'source-and-conditions.tar.xz','w:xz')as a:
 for n in ['Program.cs','Feasibility.csproj','original-Program.cs.txt','original-build.log','corrected-build.log','preserve.py']:a.add(r/n,arcname=n)
 for p in sorted((r/'bin/Release/net11.0').iterdir()):
  if p.is_file()and p.suffix in ['.dll','.json']:a.add(p,arcname='image/'+p.name)
(out/'README.md').write_text('''# Managed native-block API feasibility

R447, 2026-11-16 UTC. Standard managed expression APIs support a borrowed span
and by-reference ref-struct state containing a span. Both execute checked loop
arithmetic correctly without changing input. This resolves API feasibility, not
Lython CPU performance. No runtime source/dependency or public API changes.

Pinned .NET 11 RC3, Windows 10.0.26200 local development machine; diagnostic,
not quiet-VM observations. Twelve new programs per shape/process; corrected fresh
processes reverse order. First construction/Compile costs 19.364 ms span-first /
8.722 ms state-first, including lazy framework/JIT startup. Second-shape first
costs 0.668 / 0.323 ms. Warm medians 0.188–0.211 ms; ranges 0.171–0.506 ms;
about 11.5–11.7 KB allocation per tiny compiled program. First invocation is
separate: warmed median 0.0003 ms, zero measured invocation allocation. These
probes are neither a complete instruction set nor a whole-script speedup forecast.

The original process recorded 16.235 ms first construction/Compile and warm
0.16–0.32 ms, without a separate invocation clock. It remains unchanged. The
correction separates clocks and controls order; it discards no adverse original.
Independent phase observations do not establish compile-to-result latency.

Close the API/cost probe with feasibility established and whole-script merit
unresolved. A complete native-prefix replacement must remove its current dispatch
loop, preserve general no-replay handoff and avoid a third engine. Compilation
scratch/cache ownership, framework cancellation gaps, exact overflow/identity/
fault behavior, host suspension and managed stack remain integration obligations.
No token-bearing cache, raw IL, Unsafe or heap-frame workaround is justified.
New-script compile cost must pay for itself without identical-script caching.
No production prototype is selected from API feasibility alone.

A separate managed allocation check identifies a more contained possibility:
the current iteration result and existing executable scalar slot both have a
16-byte array stride on the tested runtime. Using the slot's unassigned state
for exhaustion could avoid enlarging all results. Canonical observation and copy
rules remain to prove; this is no identity or portability claim. Prioritize that
existing-storage migration ahead of dynamic compilation. No unchanged full
qualification is repeated; publication/tagging remain held.

[Summary](summary.json), [span-first](corrected-span-first.json),
[state-first](corrected-state-first.json), [original](original-observations.json),
[exact source/image/conditions](source-and-conditions.tar.xz).
''',encoding='utf-8',newline='\n')
p=repo/'benchmarks/EXPERIMENTS.md';s=p.read_text(encoding='utf-8');s+='\nR447: [managed block API feasibility](results/2026-11-16-managed-block-feasibility/README.md). Borrowed span/ref-state APIs work without heap frames; original startup and corrected invocation/order controls retained. No Lython speedup or new production backend; one-shot merit and integration obligations remain unresolved.\n';p.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(artifact=str(out),apiFeasible=True,noRuntimeChange=True)))
