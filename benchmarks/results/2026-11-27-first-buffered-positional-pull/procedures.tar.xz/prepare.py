from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
from statistics import median
import json
import os
import subprocess


root = Path(__file__).resolve().parent
repo = root.parents[3]
source = root.parent / 'wsl-shipment-cpython-20261127'
pair = root / 'comparison'
pair.mkdir()
read = lambda path: json.loads(path.read_bytes())
def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


def image(folder):
    return {path.name: digest(path) for path in folder.iterdir()}


original = read(source / 'identity.json')
core = 'Lokad.Lython.dll'
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only', original['sourceRevision'], base, '--', 'src'], cwd=repo)
patch = subprocess.check_output(['git', 'diff', '--binary', base, '--', 'src'], cwd=repo)
assert b'var initialCount = _count;' in patch and patch.count(b'diff --git ') == 1
(root / 'candidate.patch').write_bytes(patch)
assert image(source / 'candidate') == original['imageFiles']['candidate']
for role in ('reference', 'candidate'):
    copytree(source / 'candidate', pair / role)
fresh = repo / 'src/Lokad.Lython/bin/Release/net11.0' / core
assert digest(fresh) == digest(repo / 'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0' / core)
copyfile(fresh, pair / 'candidate' / core)
images = {role: image(pair / role) for role in ('reference', 'candidate')}
assert [name for name, before in images['reference'].items() if images['candidate'][name] != before] == [core]
for name in ('representative.json', 'cpython-worker.py'):
    copyfile(source / name, pair / name)
assert digest(pair / 'representative.json') == original['catalogs']['representative.json']['sha256']
assert digest(pair / 'cpython-worker.py') == original['cpythonWorkerSHA256']

catalog = read(pair / 'representative.json')
iterable = 'diagnostic.shipment-starmap-iterable-rows'
wide = 'diagnostic.shipment-starmap-wide-lists'
file_map = 'diagnostic.shipment-file-fed-map'
write(pair / 'jobs.json', {'warm': [
    [iterable, 'warm'], [wide, 'warm-async'], [iterable, 'warm-async'], [file_map, 'warm-async']]})
identity = dict(sourceRevision=base, productionReference=original['sourceRevision'],
                sourcePatchSHA256=digest(root / 'candidate.patch'), imageFiles=images,
                coreSHA256={role+suffix: hashes[core] for role, hashes in images.items()
                            for suffix in ('', '-control')},
                cpythonWorkerSHA256=original['cpythonWorkerSHA256'], cpythonPath=original['cpythonPath'],
                expectedCPythonSHA256=original['expectedCPythonSHA256'],
                purpose='Direct first buffered pull for native generator arguments in both APIs.')
identity['catalogs'] = {name: {'sha256': digest(pair / name)} for name in ('representative.json', 'jobs.json')}
write(pair / 'identity.json', identity)
donor = root.parent / 'json-eager-traversal-20261127/comparison/local'
collector = (donor / 'collect.py').read_text(encoding='utf-8').replace('len(jobs) == 5', 'len(jobs) == 4')
collector = collector.replace('lython-b1874-eager-traversal-fixture-', 'lython-b1883-first-argument-pull-')
compile(collector, 'collect.py', 'exec')
(pair / 'collect.py').write_text(collector, encoding='utf-8', newline='\n')
launch = (root / 'run.sh').read_bytes()
assert b'\r' not in launch
(pair / 'run.sh').write_bytes(launch)

allocation = root / 'allocation'
allocation.mkdir()
witness = root.parent / 'csv-dictwriter-direct-fields-20261127/allocation/candidate'
for role, files in images.items():
    folder = allocation / role
    copytree(pair / role, folder)
    for path in witness.glob('ValidatedAllocation*'):
        copyfile(path, folder / path.name)
    assert (folder / 'ValidatedAllocation.dll').is_file()
    assert all(digest(folder / name) == checksum for name, checksum in files.items())
sdk = Path.home() / '.dotnet11'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
rows = []
for mode in ('sync', 'async'):
    for case in catalog['cases']:
        case['runAsync'] = mode == 'async'
    selection = allocation / f'{mode}-catalog.json'
    write(selection, catalog)
    comparisons = []
    for role in images:
        folder = allocation / role
        report = allocation / f'{role}-{mode}.json'
        subprocess.run([sdk / 'dotnet.exe', folder / 'ValidatedAllocation.dll', folder, selection, report],
                       env=env, check=True, timeout=90)
        comparisons.append(read(report)['rows'])
    for before, after in zip(*comparisons, strict=True):
        assert before['id'] == after['id']
        assert before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
        row = dict(case=before['id'], mode=mode,
                   clr=[median(r['allocatedBytesPerInvocation']) for r in (before, after)],
                   peak=[r['peakExecutionMemoryBytes'] for r in (before, after)],
                   compiled=[r['compiledReservedBytes'] for r in (before, after)])
        rows.append(row)
        print(row, flush=True)
write(allocation / 'summary.json', rows)
