from pathlib import Path
import json,os,shutil,subprocess,hashlib
r=Path(__file__).parent;env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
for framework in ['net11.0','net10.0']:
 for kind,project,selection in [('internal','Lokad.Lython.Tests','FullyQualifiedName~RecordFieldLookupOwnershipTests|FullyQualifiedName~ExecutableFrameStorageTests|FullyQualifiedName~DirectOperandOwnershipTests|FullyQualifiedName~ExecutableStackAdmissionTests'),('public','Lokad.Lython.PublicApi.Tests','FullyQualifiedName~RecordFieldLookupTests|FullyQualifiedName~MemberCacheBehaviorTests|FullyQualifiedName~ReceiverMethodSemanticsTests|FullyQualifiedName~PreparedConsumerProtocolTests|FullyQualifiedName~Descriptor')]:
  p=r/(kind+framework+'.log')
  with p.open('w',encoding='utf-8')as log:done=subprocess.run([env['DOTNET_HOST_PATH'],'test','tests/'+project,'-c','Release','-f',framework,'--filter','(Category!=Stress)&('+selection+')'],env=env,stdout=log,stderr=subprocess.STDOUT)
  print(kind,framework,p.read_text(encoding='utf-8')[-350:],flush=True);assert done.returncode==0,p
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'images/candidate/Lokad.Lython.dll');files=subprocess.check_output(['git','ls-files','src'],text=True).splitlines();i=dict(baseline='Committed d05b3359/core19b8b5a5, independently active CI; no full qualification yet',candidate='d05 + R120 deletion of unused mutable/protocol member-cache tables',productionSources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in files},coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},qualification='Focused actual11/10 only; no full delivery claim; no metadata/frontend changes')
(r/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf-8');(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src']));shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
for name in ['measure.py','assess-local.py']:
 with (r/(name+'.log')).open('w',encoding='utf-8')as log:done=subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/name)],env=env,stdout=log,stderr=subprocess.STDOUT)
 print(name,(r/(name+'.log')).read_text(encoding='utf-8')[-2200:],flush=True);assert done.returncode==0,name
