from pathlib import Path
import json, shutil, tarfile, hashlib, re
lab=Path(__file__).resolve().parent
out=lab.parents[3]/'benchmarks/results/2026-11-25-arithmetic-call-operands/confirmation'
quiet=lab/'comparison/quiet'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
assert sha(lab/'candidate.patch')==identity['sourcePatchSHA256']
shape=read(lab/'shape-summary.json')
assert shape['coreSHA256']==identity['coreSHA256']['candidate']
assert len(shape['rows'])==2
assert all(next(m for m in row['methods'] if m['name']=='build')['eligibleLoads']==160 for row in shape['rows'])
for name,num in (('Lokad.Lython.PublicApi.Tests-win11.log',148),('Lokad.Lython.PublicApi.Tests-ubuntu10.log',148),
                 ('Lokad.Lython.Tests-win11.log',134),('Lokad.Lython.Tests-ubuntu10.log',134)):
    assert re.search(rf'Failed:\s+0, Passed:\s+{num},', (lab/name).read_text(encoding='utf-8-sig'))
for name in ('identity.json','storage-custody.json'):
    shutil.copyfile(quiet/name,out/name)
for name in ('allocation-summary.json','compile-allocation-summary.json','shape-summary.json'):
    shutil.copyfile(lab/name,out/name)
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for name in ('package-evidence.py','candidate.patch','tests.patch',
       'prepare.py','prepare.log','quiet.py','bench-build.log','archive.py','test-ubuntu.sh',
       'allocations.py','allocations.log','reference-allocation-final.json','candidate-allocation-final.json',
       'compile-allocation.py','compile-allocation.log','reference-compiler-owner.json','candidate-compiler-owner.json',
       'Lokad.Lython.PublicApi.Tests-win11.log','Lokad.Lython.Tests-win11.log','Lokad.Lython.PublicApi.Tests-ubuntu10.log',
       'Lokad.Lython.Tests-ubuntu10.log','verified-raw-replicas.json','launch-console.log','retrieve.log',
       'comparison/reference-verify.json','comparison/candidate-verify.json',
       'inspection.log','inspection/Program.cs','inspection/ArithmeticCallInspection.csproj'):
        bundle.add(lab/name,arcname=name,recursive=False)
