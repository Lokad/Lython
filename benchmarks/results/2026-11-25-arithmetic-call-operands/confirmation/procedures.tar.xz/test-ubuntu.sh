set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/arithmetic-call-operands-confirmation-20261125"
tree="$PWD"
filter='(FullyQualifiedName~DirectGlobalOperand|FullyQualifiedName~FunctionDefault|FullyQualifiedName~SimpleFunctionExecutionBoundary|FullyQualifiedName~PreparedFunctionExecution|FullyQualifiedName~ExecutableFunctionInvocation|FullyQualifiedName~AsyncExecutableFunction|FullyQualifiedName~OrdinaryFunctionTransport|FullyQualifiedName~ClosureRetention|FullyQualifiedName~StackProtection|FullyQualifiedName~Recursion)&Category!=Stress'

for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
 log="$lab/$suite-ubuntu10.log"
 if dotnet test "$tree/tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
  tail -5 "$log"
 else
  tail -40 "$log"
  exit 1
 fi
done
