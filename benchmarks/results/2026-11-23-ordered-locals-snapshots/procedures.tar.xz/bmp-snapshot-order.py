def outer():
    Ω = 1
    é = 2
    﨎 = 3
    def inner():
        observed = Ω + 﨎 + é
        print(tuple(locals()))
    inner()
outer()
