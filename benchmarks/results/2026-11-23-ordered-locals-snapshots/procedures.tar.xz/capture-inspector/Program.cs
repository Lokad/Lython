using System.Collections;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

const BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var cases = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var budget = new LythonMemoryBudget();
    var bindings = new List<object>();
    using (var script = new LythonEngine().Compile(item.GetProperty("source").GetString()!, budget))
    {
        if (!script.IsValid) throw new InvalidOperationException(string.Join("|", script.Diagnostics));
        var target = ((Delegate)typeof(LythonCompiledScript).GetField("_runner", flags)!.GetValue(script)!).Target!;
        var executable = target.GetType().GetFields(flags).Single(f => f.FieldType.Name == "ExecutableScript").GetValue(target)!;
        var seen = new HashSet<object>(ReferenceEqualityComparer.Instance);
        object? Read(object item, string name) => item.GetType().GetProperty(name, flags)?.GetValue(item);
        void Visit(object code, object? parent)
        {
            if (!seen.Add(code)) return;
            var names = (IReadOnlyList<string>)Read(code, "ClosureNames")!;
            var sources = Read(code, "CaptureSources");
            List<object>? capture = null;
            if (sources is not null)
            {
                if (parent is null || !ReferenceEquals(Read(sources, "ParentLocalSlots"), Read(parent, "LocalNameToSlot")))
                    throw new InvalidOperationException("Unexpected capture owner for " + Read(code, "Name"));
                var slots = (int[])Read(sources, "Slots")!;
                var parentLocals = (IReadOnlyList<string>)Read(parent, "LocalNames")!;
                var parentCaptures = (IReadOnlyList<string>)Read(parent, "ClosureNames")!;
                capture = [];
                for (var i = 0; i < names.Count; i++)
                {
                    var slot = slots[i];
                    var origin = slot < 0 ? parentCaptures[~slot] : parentLocals[slot];
                    if (origin != names[i]) throw new InvalidOperationException("Resolved a different capture for " + names[i]);
                    capture.Add(new { name = names[i], slot, origin });
                }
            }
            bindings.Add(new { name = Read(code, "Name"), capture });
            foreach (var constant in (IEnumerable)Read(code, "Constants")!)
            {
                var child = constant?.GetType().Name switch
                {
                    "ExecutableCreateClass" => Read(constant, "Body"),
                    "ExecutableCreateFunction" or "ExecutableCreateLambda" or "ExecutableCreateGeneratorExpression" =>
                        Read(constant, "CodeObject"),
                    _ => null
                };
                if (child is not null) Visit(child, code);
            }
        }
        Visit(Read(executable, "EntryPoint")!, null);
    }
    if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compilation cleanup retained allowance.");
    cases.Add(new { id = item.GetProperty("id").GetString(), bindings });
}
File.WriteAllText(args[1], JsonSerializer.Serialize(new {
    coreSHA256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))),
    cases
}, new JsonSerializerOptions { WriteIndented = true }));
