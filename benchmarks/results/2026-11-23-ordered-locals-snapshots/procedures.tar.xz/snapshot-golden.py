def outer(parameter):
    zebra = 1
    alpha = 2
    def middle():
        def first(): return zebra
        def second(): return alpha
        print(tuple(locals()), first(), second(), parameter)
    plain = 3
    print(tuple(locals()))
    middle()
outer(7)
