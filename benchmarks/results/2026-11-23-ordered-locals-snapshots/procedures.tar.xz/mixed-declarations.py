def outer(zebra,alpha,beta):
    def middle():
        read_zebra=lambda:zebra
        def read_alpha():return alpha
        generator=(beta+x for x in [0])
        return read_zebra(),read_alpha(),tuple(generator)
    return middle()
print(outer(5,6,7))
