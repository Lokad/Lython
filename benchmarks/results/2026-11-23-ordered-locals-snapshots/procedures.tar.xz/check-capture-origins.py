from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path('.git/agent-notes/review-20261031/ordered-locals-snapshots-20261123').resolve()
proof=json.loads((lab/'comparison/identity.json').read_text(encoding='utf-8'))
driver=lab/'capture-inspector/bin/Release/net11.0'
earlier=lab.parent/'strict-short-float-20261123/probe-build/bin/LythonProbe/release_net11.0'
dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
roles={}
for role,names in proof['imageFiles'].items():
    image=lab/role
    assert {n:sha(image/n) for n in names}==names
    tools=lab/('capture-'+role)
    tools.mkdir(exist_ok=True)
    for name in ('Inspect.dll','Inspect.runtimeconfig.json','Inspect.deps.json'):
        shutil.copyfile(driver/name,tools/name)
    shutil.copyfile(image/'Lokad.Lython.dll',tools/'Lokad.Lython.dll')
    result=lab/(role+'-capture-origins.json')
    subprocess.run([dotnet,tools/'Inspect.dll',lab/'inspection-catalog.json',result],env=env,check=True,timeout=45)
    entry=json.loads(result.read_text(encoding='utf-8'))
    assert entry['coreSHA256']==proof['coreSHA256'][role]
    roles[role]=entry['cases']
    for path in earlier.iterdir():
        if path.name!='Lokad.Lython.dll' and path.is_file():shutil.copyfile(path,tools/path.name)
    spec=next(x for x in (json.loads((lab/'inspection-catalog.json').read_text(encoding='utf-8'))['cases'])
              if x['id']=='mixed-declaration-forwarding')
    sample=lab/'mixed-declarations.py'
    sample.write_text(spec['source'],encoding='utf-8',newline='\n')
    with (lab/(role+'-mixed-declarations.log')).open('wb') as log:
        subprocess.run([dotnet,tools/'LythonProbe.dll',sample,'--compare-python','--python','C:/Python313/python.exe'],
            env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=25)
    assert {n:sha(image/n) for n in names}==names
remapped=[]
links=0
for left,right in zip(roles['reference'],roles['candidate'],strict=True):
    assert left['id']==right['id']
    for a,b in zip(left['bindings'],right['bindings'],strict=True):
        assert a['name']==b['name'] and bool(a['capture'])==bool(b['capture'])
        la={e['name']:(e['origin'],e['slot']) for e in a['capture'] or []}
        lb={e['name']:(e['origin'],e['slot']) for e in b['capture'] or []}
        assert {n:o for n,(o,_) in la.items()}=={n:o for n,(o,_) in lb.items()}
        links+=len(la)
        if la!=lb:remapped.append(dict(script=left['id'],code=a['name'],reference=la,candidate=lb))
report=dict(bindingsCompared=links,remapped=remapped,images=proof['coreSHA256'])
(lab/'capture-origins.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
