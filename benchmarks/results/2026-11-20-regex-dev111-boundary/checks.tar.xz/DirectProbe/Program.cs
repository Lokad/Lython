using System.Buffers;
using System.Security.Cryptography;
using Lokad.Utf8Regex.PythonRe;

using var pattern = new Utf8PythonRegex("(?P<é>)"u8);
var name = new byte[4];
if (pattern.TryCopyGroupNameUtf8(1, name, out var length) != OperationStatus.Done ||
    !name.AsSpan(0, length).SequenceEqual("é"u8)) return 1;
var input = "xé"u8.ToArray();
using (var normal = pattern.CreateMatchCursor(input, 1, mode: Utf8PythonMatchMode.Match, endOffsetInBytes: 3))
    if (!normal.MoveNext(out _)) return 2;
Console.WriteLine($"Core bytes {Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(Lokad.Utf8Regex.Utf8Regex).Assembly.Location)))}");
Console.WriteLine($"PythonRe bytes {Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(Utf8PythonRegex).Assembly.Location)))}");
try
{
    using var reversed = pattern.CreateMatchCursor(input, 3, mode: Utf8PythonMatchMode.Match, endOffsetInBytes: 1);
    Console.WriteLine($"Reversed cursor result {reversed.MoveNext(out _)}");
}
catch (ArgumentOutOfRangeException error)
{
    Console.WriteLine($"Reversed cursor refuses {error.ParamName}");
}
return 0;
