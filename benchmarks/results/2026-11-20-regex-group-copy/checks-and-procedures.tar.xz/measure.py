from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess
import sys
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
previous = lab.parent / "private-compiled-annotation-payload"
dotnet = Path.home() / ".dotnet11/dotnet.exe"
python = Path("C:/Python313/python.exe")
protocol = repo / "benchmarks/cpython-worker.py"
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), PATH=str(dotnet.parent) + os.pathsep + os.environ["PATH"])


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(p):
    return json.loads(p.read_text(encoding="utf-8"))


def save(p, v):
    p.write_text(json.dumps(v, indent=2) + "\n", encoding="utf-8", newline="\n")


source_archive = repo / "benchmarks/results/2026-11-18-regex-capture-count/comparison/observations.tgz"
with tarfile.open(source_archive) as archive:
    catalog = json.load(archive.extractfile("representative.json"))
unicode_short = next(c for c in catalog["cases"] if ".unicode-short." in c["id"])
unicode_long = next(c for c in catalog["cases"] if ".unicode-interior." in c["id"])
rows = []
for case in (unicode_short, unicode_long):
    row = dict(case)
    source = row["source"].replace("m.start()+m.end(1)", "len(m.group(1))")
    assert source != row["source"]
    outcome = subprocess.run([python, "-X", "utf8", "-I", "-c", source],
                             check=True, text=True, encoding="utf-8", capture_output=True, timeout=15)
    assert not outcome.stderr
    row.update(id=row["id"].replace(".unicode-", ".group-copy."), source=source, sourceSha256=sha(source.encode("utf-8")),
               expectedOutput=outcome.stdout, expectedOutputSha256=sha(outcome.stdout.encode("utf-8")))
    if "sourceUtf8Bytes" in row:
        row["sourceUtf8Bytes"] = len(source.encode("utf-8"))
    if "expectedOutputUtf8Bytes" in row:
        row["expectedOutputUtf8Bytes"] = len(outcome.stdout.encode("utf-8"))
    rows.append(row)
catalog["cases"] = rows + [unicode_short]
manifest = lab / "representative.json"
save(manifest, catalog)
old = load(previous / "identity.json")["imageFiles"]["reference"]
original = previous / "frozen/reference"
core = "Lokad.Lython.dll"
assert len(old) == 32
assert {name: sha((original / name).read_bytes()) for name in old} == old
images = {}
for role in ("reference", "candidate"):
    p = lab / "frozen" / role
    p.mkdir(parents=True)
    for name in old:
        origin = repo / "src/Lokad.Lython/bin/Release/net11.0" / name if role == "candidate" and name == core else original / name
        shutil.copyfile(origin, p / name)
    images[role] = {name: sha((p / name).read_bytes()) for name in old}
    for name in original.glob("ValidatedAllocation.*"):
        shutil.copyfile(name, p / name.name)
    receipt = lab / f"{role}-verify.json"
    subprocess.run([dotnet, p / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", manifest,
         "--dotnet", dotnet, "--python", python, "--python-worker", protocol, "--out", receipt],
         env=env, check=True, timeout=90)
    verified = load(receipt)
    assert verified["state"] == "Completed" and verified["catalogSha256"] == sha(manifest.read_bytes())
    subprocess.run([dotnet, p / "ValidatedAllocation.dll", p, manifest, lab / f"{role}-allocation.json"],
                   env=env, check=True, timeout=110)
    assert {name: sha((p / name).read_bytes()) for name in old} == images[role]
assert [name for name in old if images["reference"][name] != images["candidate"][name]] == [core]
save(lab / "identity.json", dict(base="78ad4127d", sourceDiffSHA256=sha(subprocess.check_output(
    ["git", "diff", "--no-ext-diff", "78ad4127d", "--", "src"], cwd=repo)),
    catalogSHA256=sha(manifest.read_bytes()), imageFiles=images))
before, after = [load(lab / f"{role}-allocation.json")["rows"] for role in ("reference", "candidate")]
result = []
for a, b in zip(before, after, strict=True):
    assert a["id"] == b["id"] and a["sharedBudgetBaselineRestored"] and b["sharedBudgetBaselineRestored"]
    x, y = [statistics.median(v["allocatedBytesPerInvocation"]) for v in (a, b)]
    p, q = [v["peakExecutionMemoryBytes"] for v in (a, b)]
    result.append(dict(case=a["id"], reference=x, candidate=y, allocationChangePercent=100*(y/x-1),
                       referenceAccountedPeak=p, candidateAccountedPeak=q, allowanceRestored=True))
    print(a["id"], x, y, p, q)
save(lab / "allocation-summary.json", result)
