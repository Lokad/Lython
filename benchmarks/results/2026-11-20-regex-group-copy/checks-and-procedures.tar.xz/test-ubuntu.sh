set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
log=$PWD/.git/agent-notes/review-20261031/direct-regex-group-copy/tests-ubuntu.log
dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 -p:RestoreLockedMode=true --filter 'Category!=Stress&(FullyQualifiedName~Regex|FullyQualifiedName~Fnmatch|FullyQualifiedName~Glob)' >"$log" 2>&1 || { tail -n 45 "$log"; exit 1; }
tail -n 7 "$log"
