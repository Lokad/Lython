using System.Text;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Text;

var trials = JsonSerializer.Deserialize<Trial[]>(File.ReadAllBytes(args[0]))!;
var report = new List<object>();
var span = new LythonSourceSpan(4, 2, 1, 2);
foreach (var trial in trials)
{
    var budget = new LythonMemoryBudget();
    var rows = new List<object[]>();
    string? error = null;
    LythonSourceSpan? failureSpan = null;
    long retained;
    using (var owner = budget.CreateScope())
    {
        var context = new LythonRuntime.ExecutionContext(new NoFileHost(), new() { MemoryBudget = owner });
        var options = new LythonRuntime.CsvOptions(PyString.FromString(trial.Delimiter),
            trial.Quote is null ? null : PyString.FromString(trial.Quote), (LythonRuntime.CsvQuotingMode)trial.Quoting,
            trial.DoubleQuote, trial.Escape is null ? null : PyString.FromString(trial.Escape),
            trial.SkipInitialSpace, PyString.FromString("\r\n"), trial.Strict);
        var parser = new LythonRuntime.CsvRecordParser(options, context, span);
        try
        {
            foreach (var line in trial.Lines)
            {
                var before = parser.InputBuffer.Length;
                parser.InputBuffer.Append(Encoding.UTF8.GetBytes(line));
                parser.FeedOwnedLine(before);
                if (parser.TryTakeReady(out var row)) rows.Add(Project(row));
            }
            parser.Finish();
            if (parser.TryTakeReady(out var last)) rows.Add(Project(last));
        }
        catch (LythonRuntimeException e)
        {
            error = e.ExceptionType + ": " + e.Message;
            failureSpan = e.Span;
        }
        finally { parser.ReleaseScratch(); }
        retained = budget.ReservedBytes;
    }
    if (budget.ReservedBytes != 0) throw new InvalidOperationException("CSV owner failed to refund its retained values.");
    report.Add(new { rows, error, failureSpan, retained, peak = budget.PeakBytes });
}
File.WriteAllBytes(args[1], JsonSerializer.SerializeToUtf8Bytes(report));

static object[] Project(object[] row) => row.Select(x => x is PyString text ? text.AsString() : x).ToArray();

sealed record Trial(string Delimiter, string? Quote, int Quoting, bool DoubleQuote, string? Escape,
    bool SkipInitialSpace, bool Strict, string[] Lines);
sealed class NoFileHost : ILythonHost
{
    public string Cwd => "/";
    public DateTimeOffset LocalNow => DateTimeOffset.UnixEpoch;
    public DateTimeOffset UtcNow => DateTimeOffset.UnixEpoch;
    public ValueTask<bool> ExistsAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask<IReadOnlyList<string>> ListDirAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask MkDirAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask RemoveAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask CopyAsync(LythonPathRequest source, LythonPathRequest destination, CancellationToken token) => throw new NotSupportedException();
    public ValueTask MoveAsync(LythonPathRequest source, LythonPathRequest destination, CancellationToken token) => throw new NotSupportedException();
    public ValueTask<LythonPathStat> StatAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
}

