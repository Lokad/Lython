from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prev=lab.parent/"immediate-definition-depth-20261122"/"comparison"
prior=lab.parent/"factory-and-text-attribution-20261122"/"quiet"
out=lab/"comparison"
quiet=out/"quiet"
core="Lokad.Lython.dll"
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda data:hashlib.sha256(data).hexdigest()
def h(p):return sha(p.read_bytes())
def git(*args):return subprocess.check_output(["git",*args],cwd=repo)
def write(p,s):
    if p.suffix==".py":compile(s,str(p),"exec")
    p.write_text(s,encoding="utf-8",newline="\n")
def save(p,value):write(p,json.dumps(value,indent=2)+"\n")
def committed(p):return git("show","origin/master:"+p)
def verified(archive):
    base=f"benchmarks/results/{archive}/"
    receipt=json.loads(committed(base+"archive-receipt.json"))
    assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
    assert sha(committed(base+"observations.tgz"))==receipt["archiveSHA256"]
    return base,receipt["archiveSHA256"]

p=read(prev/"quiet/config.json")
donor=read(prior/"config.json")
base1422,archive1422=verified("2026-11-22-factory-text-attribution")
base1423,archive1423=verified("2026-11-22-immediate-definition-depth")
past=json.loads(committed(base1422+"identity.json"))
earlier=json.loads(committed(base1423+"source.json"))
assert past==donor["identity"] and earlier["imageFiles"]==p["identity"]["imageFiles"]
before=read(out/"identity.json")
for role in ("reference","candidate"):
    assert [n for n,d in past["imageFiles"]["reference"].items() if before["imageFiles"][role][n]!=d]==[core]
tree=repo/".git/agent-worktrees/csv-literal-field-scan-20261122"
candidate=git("-C",str(tree),"rev-parse","HEAD").decode().strip()
assert candidate.startswith("9e3b826df") and not git("-C",str(tree),"status","--porcelain")
assert not git("diff","--name-only",before["reference"],before["patchBase"],"--","src","tests")
patch=git("diff","--binary",before["patchBase"],candidate,"--","src","tests")
assert sha(patch)==before["sourcePatchSHA256"] and patch==(out/"source.patch").read_bytes()
files=before["imageFiles"]
assert [n for n,d in files["reference"].items() if files["candidate"][n]!=d]==[core]
catalog=out/"representative.json"
ids=[r["id"]for r in read(catalog)["cases"]]
jobs=[tuple(j)for j in read(out/"jobs.json")]
assert len(jobs)==7 and len(ids)==6
for role in files:
    assert len(files[role])==32 and {n:h(out/f"frozen-{role}"/n)for n in files[role]}==files[role]
    proof=read(out/f"{role}-verify.json")
    assert proof["catalogSha256"]==h(catalog) and proof["state"]=="Completed" and proof["caseCount"]==len(ids)
old1422=gzip.decompress(committed(base1422+"sampled-core.dll.gz"))
old1423=gzip.decompress(committed(base1423+"candidate-core.dll.gz"))
assert sha(old1422)==past["imageFiles"]["candidate"][core]==earlier["imageFiles"]["reference"][core]
assert sha(old1423)==earlier["imageFiles"]["candidate"][core]
old_name1422=Path(donor["root"]).name
old_name1423=Path(p["root"]).name
retire=[dict(paths=[old_name1422+"/candidate/"+core,old_name1423+"/reference/"+core],bytes=len(old1422),sha256=sha(old1422),links=2,
             archives={old_name1422+"/observations.tgz":archive1422,old_name1423+"/observations.tgz":archive1423}),
        dict(paths=[old_name1423+"/candidate/"+core],bytes=len(old1423),sha256=sha(old1423),links=1,
             archives={old_name1423+"/observations.tgz":archive1423})]
assert not {sha(old1422),sha(old1423)}&{values[core]for values in files.values()}
before.update(sourceRevision=before["reference"]+" versus "+candidate,candidate=candidate,testedRevision=candidate,
    purpose="Classify literal CSV fields at their start. Exclude interior quote bytes from bare field scanning.",
    normalAdapterPin="0.4.0",coreSHA256={role+suffix:m[core]for role,m in files.items()for suffix in ("","-control")},
    catalogs={"representative.json":{"sha256":h(catalog)}})
root="/home/lokad/lython-bench-checks/csv-literal-field-scan-b1424-20261122"
unit="lython-b1424-csv-literal-field-scan-20261122"
quiet.mkdir()
save(quiet/"identity.json",before)
shutil.copyfile(catalog,quiet/"representative.json")
for role in files:
    (quiet/role).mkdir()
    shutil.copyfile(out/f"frozen-{role}"/core,quiet/role/core)
for leaf in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    code=(prev/"quiet"/leaf).read_text(encoding="utf-8").replace(p["root"],root).replace(p["unit"],unit)
    if leaf=="collect.py":
        a,b=code.index("\njob_catalog ="),code.index("\nassert len(jobs)")
        code=code[:a]+"\njob_catalog = "+repr({id:"representative.json"for id,_ in jobs})+"\njobs = "+repr(jobs)+code[b:]
    write(quiet/leaf,code.replace("Immediate definition","Literal CSV field scan"))
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py","candidate/"+core,"reference/"+core)
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz") as bundle:
    for n in parts:bundle.add(quiet/n,arcname=n)
cfg={**p,"root":root,"unit":unit,"identity":before,"source":donor["root"],"sourceRole":"reference",
     "sourceFiles":past["imageFiles"]["reference"],"sourceCatalogSHA256":past["catalogs"]["representative.json"]["sha256"],
     "donorArchiveSHA256":archive1422,"retireGroups":retire,
     "payloadBytes":payload.stat().st_size,"payloadSHA256":h(payload),"unpackedBytes":sum((quiet/n).stat().st_size for n in parts)}
save(quiet/"config.json",cfg)
code=(prev/"quiet/remote-launch.py").read_text(encoding="utf-8")
a,b=code.index("\nc=")+1,code.index("\nb=Path(")
write(quiet/"remote-launch.py",(code[:a]+"c="+repr(cfg)+code[b:]).replace("b1423-fixtures","b1424-fixtures"))
write(out/"launch.py",(prev/"launch.py").read_text(encoding="utf-8").replace("Immediate definition","Literal CSV field scan"))
write(out/"summarize.py",(prev/"summarize.py").read_text(encoding="utf-8"))
print(candidate,root,cfg["unpackedBytes"],flush=True)
