from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/"factory-and-text-attribution-20261122"
tested=lab.parent/"immediate-definition-depth-20261122"
out=lab/"comparison"
out.mkdir()
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda data:hashlib.sha256(data).hexdigest()
def h(path):return sha(path.read_bytes())
def save(p,value):p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
def git(*args,cwd=repo):return subprocess.check_output(["git",*args],cwd=cwd)
def read_catalog(directory):
    base=f"benchmarks/results/{directory}/"
    receipt=json.loads(git("show","origin/master:"+base+"archive-receipt.json"))
    archive=repo/(base+"observations.tgz")
    assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"] and h(archive)==receipt["archiveSHA256"]
    with tarfile.open(archive) as bundle:
        return json.load(bundle.extractfile("representative.json"))
directories=("2026-11-22-callable-checkpoint-cpython","2026-11-22-unicode-decimal-cpython",
             "2026-11-22-machine-arithmetic-cpython","2026-11-21-cpython-method-invoice",
             "2026-11-21-cpython-csv-restock-checkpoint")
catalogs=[read_catalog(dir) for dir in directories]
cases={}
for catalog in catalogs:
    for row in catalog["cases"]:
        if row["id"] in cases:
            direct=cases[row["id"]]
            assert (row["sourceSha256"],row["fixtureSha256"])==(direct["sourceSha256"],direct["fixtureSha256"])
        cases[row["id"]]=row
quoted="scripts.csv-invoice.method-policy.quoted-control"
ids=[quoted,"scripts.csv-invoice.method-policy","scripts.csv-meter-report.typed-ascii",
     "scripts.csv-meter-report.typed-unicode","scripts.csv-restock-export.ordinary","diagnostic.text-summary.nonlocal-computed-width.large"]
catalog=out/"representative.json"
save(catalog,{**catalogs[0],"performanceQualified":False,"cases":[cases[id]for id in ids]})
save(out/"jobs.json",[(quoted,"warm"),(quoted,"compile-run"),*((id,"warm")for id in ids[1:])])
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
info=read(prior/"identity.json")
source_manifest=info["imageFiles"]["candidate"]
frozen=prior/"frozen"
assert len(source_manifest)==32 and {n:h(frozen/n)for n in source_manifest}==source_manifest
assert h(protocol)==info["protocolSHA256"]
core="Lokad.Lython.dll"
ref=tested/"combined/windows/bin/Lokad.Lython/release_net11.0"/core
cand=lab/"windows/bin/Lokad.Lython/release_net11.0"/core
diag=read(lab/"diagnostic-comparison.json")
assert diag["cases"]==1484 and not diag["errors"]
assert [h(path) for path in (ref,cand)]==[diag["imageFiles"][role][core] for role in ("reference","candidate")]
tree=repo/".git/agent-worktrees/csv-literal-field-scan-20261122"
head=git("rev-parse","HEAD",cwd=tree).decode().strip()
assert head.startswith("9946d48aa")
patch=git("diff","--binary","HEAD","--","src","tests",cwd=tree)
assert patch.count(b"diff --git ")==2
(out/"source.patch").write_bytes(patch)
allocation=lab.parent/"deferred-word-binding-20261122/comparison/frozen-reference"
images={}
results={}
for role,built in (("reference",ref),("candidate",cand)):
    image=out/f"frozen-{role}"
    image.mkdir()
    manifest={**source_manifest,core:h(built)}
    for n in manifest:shutil.copyfile(built if n==core else frozen/n,image/n)
    assert manifest=={n:h(image/n)for n in manifest}
    images[role]=manifest
    for suffix in (".dll",".deps.json",".runtimeconfig.json"):
        n="ValidatedAllocation"+suffix
        shutil.copyfile(allocation/n,image/n)
    receipt=out/f"{role}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",receipt],
        env=env,cwd=repo,check=True,timeout=90)
    check=read(receipt)
    assert check["state"]=="Completed" and check["caseCount"]==len(ids) and check["catalogSha256"]==h(catalog)
    report=out/f"{role}-allocation.json"
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,catalog,report],env=env,cwd=repo,check=True,timeout=85)
    rows=read(report)["rows"]
    assert len(rows)==len(ids) and all(row["sharedBudgetBaselineRestored"] for row in rows)
    results[role]=rows
    assert manifest=={n:h(image/n)for n in manifest}
save(out/"identity.json",dict(reference=head,patchBase=head,imageFiles=images,
    protocolSHA256=h(protocol),catalogSHA256=h(catalog),sourcePatchSHA256=h(out/"source.patch")))
for before,after in zip(results["reference"],results["candidate"],strict=True):
    assert before["id"]==after["id"] and before["peakExecutionMemoryBytes"]==after["peakExecutionMemoryBytes"]
    a,b=(statistics.median(x["allocatedBytesPerInvocation"]) for x in (before,after))
    print(before["id"],a,b,b-a,before["peakExecutionMemoryBytes"],flush=True)
