from itertools import product
from pathlib import Path
import hashlib, json, os, random, shutil, subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
base=lab.parent/"immediate-definition-depth-20261122/combined/windows/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll"
candidate=lab/"windows/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll"
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
def save(p, v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
examples=[]
def append(delimiter,quote,quoting,double_quote,escape,skip,strict,lines):
    examples.append(dict(Delimiter=delimiter,Quote=quote,Quoting=quoting,DoubleQuote=double_quote,
        Escape=escape,SkipInitialSpace=skip,Strict=strict,Lines=["0"+delimiter+"1\n",*lines]))
dialects=[(",",'"',0,True,None,False),(",",'"',2,True,None,False),(",",'"',3,True,None,False),
          (",",'"',0,False,None,False),(";",'"',0,True,None,False),(",","é",0,True,None,False),
          (":","😀",0,True,None,False),(", ",'"',0,True,None,False),(",",",",0,True,None,False),
          ("\n",'"',0,True,None,False),(",","\n",0,True,None,False),(",",None,3,True,None,False),
          (",",'"',0,True,"\\",False),(",",'"',0,True,None,True)]
lines=[["\n"],[""],["\r\n"],["a,\n"],["cat,\rnot-a-second-row\n"],["a,b,c,d,e,f,g,\n"],
       ['a"a"a"a,b,c\n'],['1"2",1,y\n'],['",",3,4\n'],['"a""b",c\n'],['"a"tail,b\n'],
       ['"a,b\n','é,c"\n'],['",",""'],['",",'],['""""\n'],['"\n'],['"'],['a','b\n'],
       ['éaé,b,ë\n'],['ëaé,b,é\n'],['😀a😀:e\r\n'],['🟣a😀:e\r\n'],
       ['0,1,bad,4\n'],['١.٢,۳,4\n'],['"nonnumeric",1\n'],['before\\,after,x\n'],
       ['a'+('"xé'*1500)+',1\n'],['"'+('😀β'*1000)+'",1\n']]
for dialect,strict,sample in product(dialects,(False,True),lines):append(*dialect,strict,sample)
rng=random.Random(29136)
for i in range(700):
    dialect=rng.choice(dialects)
    sample=["".join(rng.choices([",",'"',";",":","\r","\n","x","1","é","ë","😀"," ","\\"],k=rng.randrange(45)))
            for _ in range(rng.randrange(1,4))]
    append(*dialect,bool(i&1),sample)
save(lab/"matrix.json",examples)
with (lab/"probe-build.log").open("wb") as log:
    subprocess.run([dotnet,"build",lab/"CsvProbe.csproj","-c","Release",f"-p:InspectionCorePath={base}"],cwd=repo,
                   env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=65)
rows={}
hashes={}
for name,core in (("reference",base),("candidate",candidate)):
    out=lab/"diagnostics"/name
    out.mkdir(parents=True,exist_ok=True)
    binary="Lokad.Lython.WhiteBox.Tests"
    for ext in (".dll",".deps.json",".runtimeconfig.json"):
        filename=binary+ext
        shutil.copyfile(lab/"bin/Release/net11.0"/filename,out/filename)
    shutil.copyfile(core,out/core.name)
    hashes[name]={p.name:sha(p)for p in sorted(out.iterdir())}
    report=lab/f"{name}-diagnostics.json"
    subprocess.run([dotnet,out/(binary+".dll"),lab/"matrix.json",report],env=env,cwd=repo,check=True,timeout=50)
    assert hashes[name]=={p.name:sha(p)for p in sorted(out.iterdir())}
    rows[name]=read(report)
errors=[dict(i=i,scenario=s,reference=a,candidate=b)
        for i,(s,a,b) in enumerate(zip(examples,rows["reference"],rows["candidate"],strict=True))if a!=b]
save(lab/"diagnostic-comparison.json",dict(cases=len(examples),errors=errors,imageFiles=hashes))
print(len(examples),"CSV parse cases, differences",len(errors),flush=True)
assert not errors,[(e["i"],e["reference"],e["candidate"])for e in errors[:4]]
