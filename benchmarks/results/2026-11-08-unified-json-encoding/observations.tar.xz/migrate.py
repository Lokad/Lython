from pathlib import Path
import shutil
r=Path(__file__).parent;p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Json.Encoder.cs')
r.mkdir(parents=True,exist_ok=True);assert not(r/'before.cs').exists();shutil.copyfile(p,r/'before.cs')
s=p.read_text(encoding='utf-8')
a=s.index('        private async ValueTask<(bool Advanced, bool ChunkReady)> AdvanceAsync(')
z=s.index('        private void AppendPrettyPrefix(',a)
replacement='''        private ValueTask<(bool Advanced, bool ChunkReady)> AdvanceAsync(GovernedByteBuilder builder, bool asynchronous)
        {
            if (_hasRoot)
            {
                _hasRoot = false;
                return AdvanceValueAsync(_rootValue!, 0, builder, asynchronous);
            }

            while (_stack.Count > 0)
            {
                var frame = _stack.Peek();
                if (frame.IsDefault) { CloseFrame(frame); continue; }
                if (!frame.Opened)
                {
                    frame.Opened = true;
                    if (_markers is not null && !_markers.Add(frame.Container))
                        throw new LythonRuntimeException("ValueError", "Circular reference detected.", _span);
                    builder.Append(frame.IsList ? (byte)'[' : (byte)'{');
                    return new((true, true));
                }

                if (frame.IsList)
                {
                    if (frame.ListItems is null || !frame.ListItems.MoveNext())
                    {
                        CloseFrame(frame);
                        if (frame.Index > 0)
                            JsonModule.AppendJsonContainerSuffix(builder, _options, frame.Depth, _context, _span);
                        builder.Append((byte)']');
                        return new((true, true));
                    }

                    var element = frame.ListItems.Current;
                    if (frame.Index > 0)
                        JsonModule.AppendSeparator(builder, _options.ItemSeparator, _context, _span);
                    AppendPrettyPrefix(builder, frame.Depth + 1);
                    frame.Index++;
                    return AdvanceValueAsync(element, frame.Depth + 1, builder, asynchronous);
                }

                var pending = TryTakePairAsync(frame, asynchronous);
                return pending.IsCompleted
                    ? AdvancePairAsync(frame, pending.GetAwaiter().GetResult(), builder, asynchronous)
                    : CompletePairAsync(pending, frame, builder, asynchronous);
            }
            return new((false, false));
        }

        private ValueTask<(bool Advanced, bool ChunkReady)> AdvancePairAsync(EmitFrame frame,
            (bool Found, object Key, object Value) pair, GovernedByteBuilder builder, bool asynchronous)
        {
            if (!pair.Found)
            {
                CloseFrame(frame);
                if (frame.Index > 0)
                    JsonModule.AppendJsonContainerSuffix(builder, _options, frame.Depth, _context, _span);
                builder.Append((byte)'}');
                return new((true, true));
            }

            if (frame.Index > 0)
                JsonModule.AppendSeparator(builder, _options.ItemSeparator, _context, _span);
            AppendPrettyPrefix(builder, frame.Depth + 1);
            var pending = JsonModule.AppendJsonObjectKeyAsync(builder, pair.Key, _options, _context, _span, asynchronous);
            if (!pending.IsCompleted) return CompleteKeyAsync(pending, frame, pair.Value, builder, asynchronous);
            pending.GetAwaiter().GetResult();
            return AdvancePairValueAsync(frame, pair.Value, builder, asynchronous);
        }

        private ValueTask<(bool Advanced, bool ChunkReady)> AdvancePairValueAsync(EmitFrame frame,
            object value, GovernedByteBuilder builder, bool asynchronous)
        {
            JsonModule.AppendSeparator(builder, _options.KeySeparator, _context, _span);
            frame.Index++;
            return AdvanceValueAsync(value, frame.Depth + 1, builder, asynchronous);
        }

        private async ValueTask<(bool Advanced, bool ChunkReady)> CompletePairAsync(
            ValueTask<(bool Found, object Key, object Value)> pending, EmitFrame frame,
            GovernedByteBuilder builder, bool asynchronous)
            => await AdvancePairAsync(frame, await pending.ConfigureAwait(false), builder, asynchronous).ConfigureAwait(false);

        private async ValueTask<(bool Advanced, bool ChunkReady)> CompleteKeyAsync(ValueTask pending,
            EmitFrame frame, object value, GovernedByteBuilder builder, bool asynchronous)
        {
            await pending.ConfigureAwait(false);
            return await AdvancePairValueAsync(frame, value, builder, asynchronous).ConfigureAwait(false);
        }

        private ValueTask<(bool Advanced, bool ChunkReady)> AdvanceValueAsync(object value, int depth,
            GovernedByteBuilder builder, bool asynchronous, int defaultDepth = 0)
        {
            // Completed default replacements stay in the existing traversal.
            // Only a genuinely pending callback retains continuation state.
            while (true)
            {
                _context.CheckExecution(_span);
                if (depth >= ExecutionState.MaxInterpreterDepth || defaultDepth >= ExecutionState.MaxInterpreterDepth)
                    throw RuntimeErrors.Attributed("RecursionError", "maximum recursion depth exceeded while encoding a JSON object",
                        _span, LythonFailureReason.InterpreterStackLimit, ExecutionState.MaxInterpreterDepth,
                        Math.Max(depth, defaultDepth));

                switch (value)
                {
                    case PyNone:
                        builder.Append("null"u8);
                        return new((true, true));
                    case PyString text:
                        JsonModule.AppendJsonString(builder, text, _options.EnsureAscii, _context, _span);
                        return new((true, true));
                    case bool boolean:
                        builder.Append(boolean ? "true"u8 : "false"u8);
                        return new((true, true));
                    case object numericValue when PyNumberOps.TryAsInteger(numericValue, out var integer):
                        _context.CheckExecution(_span);
                        JsonModule.AppendJsonInteger(builder, integer, _context, _span);
                        return new((true, true));
                    case double floating:
                        return CompleteValue(JsonModule.AppendJsonDoubleAsync(builder, floating, _options,
                            _context, _span, asynchronous), chunkReady: true);
                    case PyList list:
                        PushListFrame(list, list.GetEnumerator(), depth);
                        return new((true, false));
                    case object tupleLike when PyTupleLike.TryGetItems(tupleLike, out var tuple):
                        PushListFrame(tupleLike, tuple.GetEnumerator(), depth);
                        return new((true, false));
                    case PyDict dict:
                        return CompleteValue(PushDictFrameAsync(dict, depth, asynchronous), chunkReady: false);
                    case PyCounter counter:
                        return CompleteValue(PushDictFrameAsync(counter.InnerDict, depth, asynchronous), chunkReady: false);
                    case PyDefaultDict defaultDict:
                        return CompleteValue(PushDictFrameAsync(defaultDict.InnerDict, depth, asynchronous), chunkReady: false);
                    default:
                        if (_options.DefaultCallable is null)
                            throw new InvalidOperationException($"Unsupported json.dumps value type: {JsonModule.JsonValueTypeName(value)}");
                        if (_markers is not null)
                        {
                            if (!_markers.Add(value))
                                throw new LythonRuntimeException("ValueError", "Circular reference detected.", _span);
                            _stack.Push(new EmitFrame { IsDefault = true, Opened = true, Container = value });
                        }
                        var replacement = JsonModule.InvokeJsonCallbackCoreAsync(_options.DefaultCallable, value,
                            _context, _span, asynchronous);
                        if (!replacement.IsCompleted)
                            return CompleteDefaultAsync(replacement, depth, builder, asynchronous, defaultDepth + 1);
                        value = replacement.GetAwaiter().GetResult();
                        defaultDepth++;
                        break;
                }
            }
        }

        private static ValueTask<(bool Advanced, bool ChunkReady)> CompleteValue(ValueTask pending, bool chunkReady)
        {
            if (!pending.IsCompleted) return AwaitValueAsync(pending, chunkReady);
            pending.GetAwaiter().GetResult();
            return new((true, chunkReady));
        }

        private static async ValueTask<(bool Advanced, bool ChunkReady)> AwaitValueAsync(ValueTask pending, bool chunkReady)
        {
            await pending.ConfigureAwait(false);
            return (true, chunkReady);
        }

        private async ValueTask<(bool Advanced, bool ChunkReady)> CompleteDefaultAsync(ValueTask<object> pending,
            int depth, GovernedByteBuilder builder, bool asynchronous, int defaultDepth)
            => await AdvanceValueAsync(await pending.ConfigureAwait(false), depth, builder, asynchronous, defaultDepth).ConfigureAwait(false);

'''
s=s[:a]+replacement+s[z:]
a=s.index('        private async ValueTask PushDictFrameAsync(');z=s.index('        private void CloseFrame(',a)
replacement='''        private ValueTask PushDictFrameAsync(PyDict dict, int depth, bool asynchronous)
        {
            var frame = new EmitFrame { IsList = false, Container = dict, Depth = depth };
            if (dict.Count == 0)
            {
                PrepareDictFrame(frame, sorted: false);
                return ValueTask.CompletedTask;
            }
            var pending = JsonOptionTruthAsync(_options.SortKeys, _context, _span, asynchronous);
            if (!pending.IsCompleted) return CompleteDictFrameAsync(pending, frame);
            PrepareDictFrame(frame, pending.GetAwaiter().GetResult());
            return ValueTask.CompletedTask;
        }

        private void PrepareDictFrame(EmitFrame frame, bool sorted)
        {
            var dict = (PyDict)frame.Container;
            if (!sorted)
            {
                frame.DictPairs = dict.GetEnumerator();
                _stack.Push(frame);
                return;
            }

            // Sorting retains one reference pair per entry beside the live
            // dict; fund that scratch before building it like the eager path.
            var estimate = checked(32L * dict.Count);
            GrowScratch(estimate);
            try
            {
                frame.SortedEntries = JsonModule.CollectSortedJsonEntries(dict, _context, _span);
                frame.ScratchBytes = estimate;
                _stack.Push(frame);
            }
            catch
            {
                ReleaseScratch(estimate);
                throw;
            }
        }

        private async ValueTask CompleteDictFrameAsync(ValueTask<bool> pending, EmitFrame frame)
            => PrepareDictFrame(frame, await pending.ConfigureAwait(false));

        private ValueTask<(bool Found, object Key, object Value)> TryTakePairAsync(EmitFrame frame, bool asynchronous)
        {
            while (true)
            {
                _context.CheckExecution(_span);
                object key, value;
                if (frame.SortedEntries is not null)
                {
                    if (frame.SortedIndex >= frame.SortedEntries.Count) return new((false, PyNone.Instance, PyNone.Instance));
                    (key, value) = frame.SortedEntries[frame.SortedIndex++];
                }
                else
                {
                    if (frame.DictPairs is null || !frame.DictPairs.MoveNext()) return new((false, PyNone.Instance, PyNone.Instance));
                    var pair = frame.DictPairs.Current;
                    key = pair.Key; value = pair.Value;
                }
                if (JsonModule.IsSupportedJsonObjectKey(key)) return new((true, key, value));
                var pending = JsonOptionTruthAsync(_options.SkipKeys, _context, _span, asynchronous);
                if (!pending.IsCompleted) return CompleteSkippedPairAsync(pending, frame, asynchronous);
                if (!pending.GetAwaiter().GetResult())
                    throw new InvalidOperationException("json.dumps() requires dictionary keys to be strings, numbers, booleans, or None.");
            }
        }

        private async ValueTask<(bool Found, object Key, object Value)> CompleteSkippedPairAsync(
            ValueTask<bool> pending, EmitFrame frame, bool asynchronous)
        {
            if (!await pending.ConfigureAwait(false))
                throw new InvalidOperationException("json.dumps() requires dictionary keys to be strings, numbers, booleans, or None.");
            return await TryTakePairAsync(frame, asynchronous).ConfigureAwait(false);
        }

'''
s=s[:a]+replacement+s[z:];p.write_text(s,encoding='utf-8',newline='\n')
print('Four default-path async state machines removed; same frames/builder/chunks, continuations only for pending operations. Completed default chains use a loop.')
