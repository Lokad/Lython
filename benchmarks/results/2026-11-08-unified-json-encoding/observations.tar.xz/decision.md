Retain R102 as a renderer consolidation, explicitly accepting eager debt.
One existing frame walker now serves eager final-builder output and streamed
chunks; four recursive eager helpers deleted. Four per-step async methods now
complete native operations directly, pending-only continuations retain real work.
No new lifetime fields, pools/cache/options/parser/native dependency. Private
working metadata uses temporary funding across awaited callbacks and cleanup;
exposed iterators preserve retained charges. Managed depth and exact chunk
semantics preserved. Original50+8 ownership/threshold failures retained.
765public/171internal peractual11/10;42 result-admission checks rerun pertarget
after restoring the independent unchanged-input assertion.
One complete4096-record/110592B normalize workload, independently regenerated
CPython stdout/full-file goldens. Blank-line omission rejected before collection;
original failure/source preserved. Streamed and eager produce identical files.
Eager local allocation+4.95%sync/+4.90%async (about352B/record), streamed neutral.
Desktop elapsed adverse/mixed; baseline drift up to35.8%, not CPU evidence.
Controlled B461 six jobs172.779s, unchanged worker/normalGC/tiering. Eager sync
elapsed+3.27to+5.01%, coarseCPU+6.25%, old spread1.13%/new0.54%: real retained
tradeoff, not a speedup. Streamed sync elapsed-2.02to-4.70%, coarseCPU0to-5.56%;
async-3.28to-6.42%, coarseCPUnear0, so short elapsed improvement is not a universal
CPU claim. Eager async controlled CPU unmeasured.
Config-0.36to+0.47%, nearbaseline/mixedCPU. CSV+1.17to+8.77% with6.14%candidate
spread; unchanged source control is adverse/inconclusive, not a causal gain or
silently discarded. JSONsummary-2.45to+1.20%, mixed/inconclusive.
Completion milestone is removal of the duplicate renderer with full semantics,
cancellation/ownership and independent full delivery. Keep the measured eager
allocation/CPU debt visible; no claim the performance objective is done. A future
encoder redesign must use this common traversal, show a remaining complete storage
phase, preserve suspension/ownership and decide debt against this exact baseline;
do not reinstate a duplicate renderer, add a frame pool or blindly tune capacities.
All VM source/core/aux/Ready/golden/quiet/Closed/join/fixture/archive/local gates
pass; terminal cached, no remaining users/fixtures. Fresh exact-byte hardlink
maintenance recovered28049408B preserving every original path/alias and archive.
240MiBOSfloor+7MiBevidence+payload preflight. Full retained-source delivery pending.
Current CPython guide remains94cb8963; no per-edit refresh/debt repayment.
Regex0.4 and dev55 qualification unchanged; publication/tagging postponed.
