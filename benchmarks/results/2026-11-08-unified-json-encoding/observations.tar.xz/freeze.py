from pathlib import Path
import base64,copy,hashlib,importlib.util,json,os,re,shutil,subprocess,tempfile
r=Path(__file__).parent;old=r.parent/'default-rsplit-r99'
d=json.loads((r.parent/'operand-cpython-r97/representative.json').read_text(encoding='utf-8'));cases={c['id']:c for c in d['cases']}
template=cases['scripts.json-summary-helpers.large'];affected=[]
spec=importlib.util.spec_from_file_location('protocol',r.parent/'operand-cpython-r97/retrieved/cpython-worker.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
base="""import json
def normalize(line:str)->dict:
 record=json.loads(line)
 record['amount'] += 1
 record['valid'] = record['amount'] >= 0
 record['label'] = 'café😀'
 record['scale'] = 1.25
 record['tags'] = ['α',None,True]
 return record
count=0
with open('input.jsonl') as source:
 with open('report.json','w',newline='') as target:
  for line in source:
   if not line.strip():continue
   record=normalize(line)
   EMIT
   target.write('\\n')
   count+=1
print(count)
"""
for mode in ['eager','streamed']:
 c=copy.deepcopy(template);c['id']='scripts.json-normalize-'+mode+'.large'
 emit="target.write(json.dumps(record,ensure_ascii=False,separators=(',',':')))"if mode=='eager'else"json.dump(record,target,ensure_ascii=False,separators=(',',':'))"
 c['source']=base.replace('EMIT',emit)
 fixture=json.loads(c['fixtureJson'])
 with tempfile.TemporaryDirectory(prefix='trusted-cpython-',dir=r.resolve())as owned:
  root=Path(owned)
  for name,data in fixture['inputFiles'].items():(root/name).write_bytes(base64.b64decode(data))
  done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',c['source']],cwd=root,text=True,encoding='utf-8',capture_output=True);assert done.returncode==0,done.stderr
  c['expectedOutput']=done.stdout;actual={name:(root/name).read_bytes()for name in fixture['outputFiles']}
  c['expectedFilesSha256']=protocol.file_digest(actual);fixture['outputFiles']={name:base64.b64encode(value).decode('ascii')for name,value in actual.items()}
 c['fixtureJson']=json.dumps(fixture,ensure_ascii=False,separators=(',',':'))
 for field,digest in [('source','sourceSha256'),('fixtureJson','fixtureSha256'),('expectedOutput','expectedOutputSha256')]:c[digest]=hashlib.sha256(c[field].encode()).hexdigest()
 c['sourceUtf8Bytes']=len(c['source'].encode());c['expectedOutputUtf8Bytes']=len(c['expectedOutput'].encode());affected.append(c)
assert affected[0]['expectedFilesSha256']==affected[1]['expectedFilesSha256']
d['cases']=affected+[cases[k]for k in ['scripts.config-edit.small','scripts.csv-summary-functions.large','scripts.json-summary-helpers.large']]
assert len(d['cases'])==5
(r/'catalog.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
checks={}
for name,expected in [('public-final11',765),('public-final10',765),('internal-final11',171),('internal-final10',171)]:
 s=(r/(name+'.log')).read_text(encoding='utf-8');assert 'Failed:     0'in s and re.search(r'Passed:\s+'+str(expected)+r'\b',s);checks[name]=expected
for role in ['before','candidate']:shutil.copytree(old/'images/candidate',r/'images'/role,copy_function=os.link)
core=r/'images/candidate/Lokad.Lython.dll';core.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',core)
inventory={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*')if p.is_file()and not {'bin','obj'}&set(p.parts)}
identity=dict(baselineSource='Fully qualified c74c5802/core3fb37cc3, cached CI42479543467',candidateSource='b03fd326 plus completed JSON traversal/unified eager rendering and temporary private working metadata',coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},productionSources=inventory,focusedChecks=checks,qualification='765public/171internal focused JSON Release peractual11/10 pass; hooks/chunks/real suspension/refusal/retained aliases/cleanup. Full retained-boundary pending.',controls='Config is secondary affected (encoding once/run), JSON summary is decode-heavy with one encoded report; CSV unchanged. Duplicated same-source processes are drift controls.')
assert identity['coreSHA256']['before'].startswith('3fb37cc3')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython']))
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
for name in ['measure.py','assess-local.py']:
 s=(old/name).read_text(encoding='utf-8').replace('changed source removes default-rsplit intermediate storage','changed source unifies JSON rendering and removes completed-operation state machines; initial ownership/test-boundary failures preserved')
 (r/name).write_text(s,encoding='utf-8')
selection='''R102 one JSON encoding traversal, completed operations direct.
Remove four default-path async state machines and four eager recursive value/
dict/sequence/default helpers. Existing iterator frame stack/markers/key/scalar
writers serve eager final-builder output and exposed/streamed chunks.
Small continuations exist only for actual pending callbacks. No lifetime fields,
new state/pool/cache/options/backend. Eager working metadata preflighted with the
existing temporary128B unit, held through pending work; exposed iterators retain
their value charge. Initial unified50accounting failures found wrong private
retained-value charge. Corrected to temporary lifetime;8tiny fixture failures then
targeted result admission explicitly with existing host hook, six duplicate
pressure variants removed without weakening publication/refund/first-origin tests.
765public/171internal peractual11/10 pass. Exact chunks/options/defaults/cycles/
mutation/managed nesting, real suspension/reentry/token/terminal refusal/cleanup.
Two complete4096record/110592B JSON normalize scripts, eager versus streamed output,
same independent Python stdout/file goldens. Config secondary affected, CSV
unchanged, JSON summary decode-heavy with one small encoded report. Existing
five-case driver/both APIs, normalGC/tiering. Metadata/frame allocation changes
are intentional measured tradeoffs, not predicted speedups. Preserve all original
failures/adverse results. One bounded controlled source pair follows.
Publication/regex0.4 unchanged; no repeated external CPython checkpoint.
'''
(r/'selection.md').write_text(selection,encoding='utf-8')
print(json.dumps(identity['coreSHA256']),'Whole-script goldens/checks/source frozen.')
