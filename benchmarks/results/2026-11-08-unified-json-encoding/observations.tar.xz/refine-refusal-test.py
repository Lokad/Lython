from pathlib import Path
import shutil
r=Path(__file__).parent;p=Path('tests/Lokad.Lython.Tests/JsonStringEmissionAdmissionTests.cs');shutil.copyfile(p,r/'string-admission-before.cs')
text=p.read_text(encoding='utf-8');m=text.index('    public async Task SmallResultStillRequiresAdmissionForRetainedUtf8');a=text.rfind('    [Theory]',0,m);z=text.index('    public static IEnumerable<object[]> Refusals()',m)
replacement='''    [Theory]
    [InlineData("dumps", false)] [InlineData("dumps", true)]
    [InlineData("encode", false)] [InlineData("encode", true)]
    [InlineData("iterator", false)] [InlineData("iterator", true)]
    public async Task SmallResultStillRequiresAdmissionForRetainedUtf8(string route, bool asynchronous)
    {
        var budget = new LythonMemoryBudget(1024 * 1024);
        using (var owner = budget.CreateScope())
        {
            var hook = new AdmissionHookMemoryBudget(owner);
            var context = new Context(new MockLythonHost(), new LythonRunOptions
                { MemoryBudget = hook }, regexProvider: Utf8RegexProvider.Instance);
            var governor = context.MemoryGovernor;
            var input = PyString.FromString("a", governor, Span);
            var callable = Load(context, route);
            CallArgumentValue[] arguments = [CallArgumentValue.Positional(input)];
            var iterator = route == "iterator"
                ? Assert.IsType<LythonRuntime.JsonEncodeIterator>(callable.Invoke(arguments, Span, context)) : null;
            var resultBytes = PyString.EstimateApproximateBytes(3); // "a"
            // Refuse retained UTF-8 output independently of temporary working
            // storage; exact tiny-budget thresholds are not this contract.
            hook.RefuseGrowth = bytes => bytes == resultBytes;
            var committed = governor.CurrentCommittedBytes;
            object? published = null;
            var error = await Assert.ThrowsAsync<LythonRuntimeException>(async () =>
            {
                if (iterator is null)
                    published = asynchronous ? await callable.InvokeAsync(arguments, Span, context)
                        : callable.Invoke(arguments, Span, context);
                else if (asynchronous) published = await iterator.TryMoveNextAsync();
                else { iterator.TryMoveNext(out var chunk); published = chunk; }
            });
            Assert.Null(published);
            Assert.Equal(LythonFailureReason.SharedMemoryAllowance, error.Attribution?.Reason);
            Assert.Same(governor.AdmissionFailure, error);
            Assert.Same(Span, error.Span);
            Assert.Equal(resultBytes, governor.LastDeniedReservationBytes);
            Assert.Equal(committed, governor.CurrentCommittedBytes);
            Assert.Equal(0, governor.CurrentReservedBytes);
            Assert.Equal(0, context.State.CurrentInterpreterDepth);
        }
        Assert.Equal(0, budget.ReservedBytes);
    }

'''
text=text[:a]+replacement+text[z:];p.write_text(text,encoding='utf-8',newline='\n')
print('Small-output refusal now targets retained output via existing host hook; six duplicated pressure variants removed, semantic/refund assertions preserved.')
