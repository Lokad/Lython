from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;b=r/'b461'
i=json.loads((r/'identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
receipt=json.loads((b/'archive-receipt.json').read_text(encoding='utf8'))
assert receipt['complete']and receipt['jobs']==6 and hashlib.sha256((b/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
vm=json.loads((b/'assessment.json').read_text(encoding='utf8'));local=json.loads((r/'assessment-local.json').read_text(encoding='utf8'))
assert vm['complete']and len(vm['jobs'])==6 and all(len(local[k])==5 for k in ['warm-sync','warm-async'])
out=Path('benchmarks/results/2026-11-08-unified-json-encoding');out.mkdir()
(r/'tested-tests').mkdir()
shutil.copyfile('tests/Lokad.Lython.Tests/JsonStringEmissionAdmissionTests.cs',r/'tested-tests/JsonStringEmissionAdmissionTests.cs')
decision="""Retain R102 as a renderer consolidation, explicitly accepting eager debt.
One existing frame walker now serves eager final-builder output and streamed
chunks; four recursive eager helpers deleted. Four per-step async methods now
complete native operations directly, pending-only continuations retain real work.
No new lifetime fields, pools/cache/options/parser/native dependency. Private
working metadata uses temporary funding across awaited callbacks and cleanup;
exposed iterators preserve retained charges. Managed depth and exact chunk
semantics preserved. Original50+8 ownership/threshold failures retained.
765public/171internal peractual11/10;42 result-admission checks rerun pertarget
after restoring the independent unchanged-input assertion.
One complete4096-record/110592B normalize workload, independently regenerated
CPython stdout/full-file goldens. Blank-line omission rejected before collection;
original failure/source preserved. Streamed and eager produce identical files.
Eager local allocation+4.95%sync/+4.90%async (about352B/record), streamed neutral.
Desktop elapsed adverse/mixed; baseline drift up to35.8%, not CPU evidence.
Controlled B461 six jobs172.779s, unchanged worker/normalGC/tiering. Eager sync
elapsed+3.27to+5.01%, coarseCPU+6.25%, old spread1.13%/new0.54%: real retained
tradeoff, not a speedup. Streamed sync elapsed-2.02to-4.70%, coarseCPU0to-5.56%;
async-3.28to-6.42%, coarseCPUnear0, so short elapsed improvement is not a universal
CPU claim. Eager async controlled CPU unmeasured.
Config-0.36to+0.47%, nearbaseline/mixedCPU. CSV+1.17to+8.77% with6.14%candidate
spread; unchanged source control is adverse/inconclusive, not a causal gain or
silently discarded. JSONsummary-2.45to+1.20%, mixed/inconclusive.
Completion milestone is removal of the duplicate renderer with full semantics,
cancellation/ownership and independent full delivery. Keep the measured eager
allocation/CPU debt visible; no claim the performance objective is done. A future
encoder redesign must use this common traversal, show a remaining complete storage
phase, preserve suspension/ownership and decide debt against this exact baseline;
do not reinstate a duplicate renderer, add a frame pool or blindly tune capacities.
All VM source/core/aux/Ready/golden/quiet/Closed/join/fixture/archive/local gates
pass; terminal cached, no remaining users/fixtures. Fresh exact-byte hardlink
maintenance recovered28049408B preserving every original path/alias and archive.
240MiBOSfloor+7MiBevidence+payload preflight. Full retained-source delivery pending.
Current CPython guide remains94cb8963; no per-edit refresh/debt repayment.
Regex0.4 and dev55 qualification unchanged; publication/tagging postponed.
"""
(r/'decision.md').write_text(decision,encoding='utf8')
with tarfile.open(out/'observations.tar.xz','w:xz')as a:
 for p in sorted(r.iterdir()):
  if p.name=='images':continue
  if p.name=='b461':
   for child in sorted(p.iterdir()):
    if child.name not in ['retrieved','baseline-core.dll','current-core.dll','payload.tgz']:a.add(child,arcname='b461/'+child.name)
  else:a.add(p,arcname=p.name)
with tarfile.open(out/'observations.tar.xz')as a:assert hashlib.sha256(a.extractfile('b461/observations.tgz').read()).hexdigest()==receipt['archiveSHA256']
for src,name in [(r/'identity.json','identity.json'),(r/'assessment-local.json','allocation-and-local.json'),(b/'assessment.json','controlled-comparison.json')]:shutil.copyfile(src,out/name)
status=dict(status='Retained consolidation with explicit eager allocation/CPU debt; focused checks pass. Full retained-boundary qualification pending.',coreSHA256=i['coreSHA256'],focusedChecks=i['focusedChecks'],archiveSHA256=hashlib.sha256((out/'observations.tar.xz').read_bytes()).hexdigest(),controlledArchiveSHA256=receipt['archiveSHA256'],noRemainingVMUsersOrFixtures=True,referenceGuideSource='94cb8963')
(out/'status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf8')
readme="""# Unified JSON encoding — 2026-11-08

Retain one iterative frame traversal for eager final UTF-8 builder output and
incremental chunks. Delete the independent recursive value/dictionary/sequence/
default walker. Four per-step helpers complete native operations directly; small
continuations retain actual pending callbacks. Scalar/key/string writers remain.
No new lifetime fields, pools, caches, public options or parser changes.

Baseline fully qualified c74c5802/core3fb37cc3; candidate b03fd326 plus archived
two-file production patch/core1674a06c. Full production hashes in identity.json.
Source platform/Stress/installed-core qualification is separate/pending. The main
CPython guide remains the named94cb8963 checkpoint.

| Complete JSON normalization | Allocation sync / async | Controlled elapsed, all four median pairings |
| --- | ---: | ---: |
| Eager JSON output, sync | +4.95% / +4.90% | +3.27 to +5.01% |
| Streamed JSON output, sync | neutral / — | −2.02 to −4.70% |
| Streamed JSON output, async API | — / neutral | −3.28 to −6.42% |

Eager coarse process CPU+6.25% agrees with the adverse elapsed result; baseline
spread1.13%/candidate0.54%. This is an accepted cost of deleting the separate
recursive renderer, **not a performance improvement**. Extra eager metadata is
about352B/record. Eager async controlled CPU remains unmeasured. Streamed sync
coarseCPU0to−5.56%, async nearzero at this clock resolution: elapsed observations
do not establish a universal CPU gain. The broader performance objective remains.

Config secondary-affected control−0.36to+0.47%, nearbaseline/mixedCPU.
Unchanged CSV+1.17to+8.77% with6.14%candidate spread: adverse/inconclusive, retained.
Decode-heavy JSONsummary−2.45to+1.20%, mixed/inconclusive. Original desktop eager
adverse timings and baseline drift up to35.8% remain. No historical regression debt
is repaid by this different pair. Future encoder work must preserve one traversal,
identify remaining whole storage/work and explicitly decide this eager debt;
no duplicate renderer/frame pool/blind capacity tuning is justified by these data.

Both affected scripts read4096records/110592B, edit fields/construct nested values,
and write the full UTF-8 JSON-lines result. Eager dumps and streamed dump have
identical independent isolated CPython stdout/file goldens, including non-ASCII
text, floats, lists, bool/None and source blank lines. An initial missing blank-line
filter failed the Python oracle before any measurement; source/failure preserved.

765public/171internal focused JSON Release tests peractual11/10 pass, including
options/order/chunks/numbers/Unicode/cycles/mutation/managed nesting, actual
suspended hooks/reentry/cancellation, terminal first refusal, retained chunks and
awaited cleanup. Private eager traversal has temporary128B working admission held
across callbacks; exposed iterators keep their retained value charge. Earlier
storage stays funded through final-result admission. The initial50accounting
failures exposed private storage incorrectly charged as escaping; correction and
eight threshold-fixture failures are preserved. Result-admission tests now use the
existing host hook instead of an exact tiny-budget threshold, retaining first
origin, no publication, unchanged input and all cleanup balances.42rechecked pertarget.

Quiet Ubuntu24.04.4/AzureF4as_v7,4EPYC9V45vCPUs/16GiB/noswap, actual.NET11RC3.
Same worker7cf37ca5/optional0.4adapter, normalGC/tiering;5swarmup/process/job,
two processes/core,7rotated150msrounds. Six jobs172.779s. Command-v2 includes full
execution, mediated RAM I/O, output checks and prior-result cleanup; excludes
compilation/startup/staging/final cached teardown. I/O completes inline; real
suspension is independently tested. No startup/RSS/embedding-tail claim.

All source/core/aux/Ready/golden/quiet/Closed/exit/join/fixture/archive/local gates
pass. B461 terminal/cached; all users joined and guest RAM unmounted before the
owned persistent archive. Exact-byte hardlink maintenance recovered28049408B while
preserving every original path/alias/content and archive; fresh proof included.
240MiB OSfloor+7MiB evidence+actual payload preflight. No discarded evidence.

[Controlled results](controlled-comparison.json), [allocation/desktop evidence](allocation-and-local.json),
[identity](identity.json), [status](status.json), [sources/cores/tests/failures/raw](observations.tar.xz).
"""
(out/'README.md').write_text(readme,encoding='utf8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf8')+"""
## Unified JSON encoding (2026-11-08)

[R102/B461](results/2026-11-08-unified-json-encoding/README.md) retains one existing
frame traversal for eager and streamed output, deleting four recursive renderer
helpers and completing ordinary operations without per-step async state machines.
765public/171internal peractual11/10 pass. Private metadata temporary ownership
fix and original50+8accounting/threshold failures retained. Eager allocation+4.9%,
controlled sync elapsed+3.27to+5.01%/coarseCPU+6.25%: accepted renderer-consolidation
debt, not a speedup. Streamed elapsed−2.02to−4.70%sync/−3.28to−6.42%async with mixed/
coarseCPUnearzero. CSVcontrol+1.17to+8.77%/6.14%candidate spread and JSON/config
uncertainty preserved, as are desktop adverse/35.8%baseline drift. All full goldens/
quiet/join/archive gates pass,172.779s; no remaining users/fixtures. Full retained
source delivery pending separately. Future JSON changes must preserve one walker
and explicitly decide debt; the broader whole-script performance goal remains.
"""
p.write_text(s,encoding='utf8')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf8');needle='| Shared default-rsplit preparation / text reports |';a=s.index(needle)
s=s[:a]+'| Unified JSON encoder / normalization | Eager allocation +4.9%, elapsed +3–5%; streamed elapsed −2–6% with mixed coarse CPU | Duplicate renderer removed; eager regression accepted explicitly. Controls variable; full source qualification pending. [R102](../benchmarks/results/2026-11-08-unified-json-encoding/README.md) |\n'+s[a:];p.write_text(s,encoding='utf8')
p=Path('PLAN.md');s=p.read_text(encoding='utf8')
s=s.replace('**Active prototype R102:**','**Retained, uncommitted R102:**').replace('Not committed\n  or fully qualified. Controlled B461 running; observation not before13:21:55UTC.','Controlled B461 complete172.779s: eager elapsed+3.27to+5.01%/CPU+6.25%, streamed\n  elapsed−2.02to−6.42%/coarseCPU mixed or nearzero. CSVcontrol adverse/inconclusive\n  with6.14%candidate spread. Consolidation retained with explicit eager debt; full\n  retained-source qualification pending. All evidence/gates/archive verified.')
s=s.replace('**Close R102 coherently.**','**Commit/qualify R102 coherently.**')
s=s.replace('B461 is the only active VM collection.','B461 terminal/archived/locally verified; no active VM users/fixtures.')
s=s.replace('Full platform/Stress/installed checks only at the retained coherent boundary.','Retain the coherent deletion with eager allocation+4.9%/CPU+6.25% debt explicit;\n   next encoder work must preserve one walker and decide this debt. No CPU gain\n   inferred from mixed coarse-clock observations. Commit and run full retained\n   platform/Stress/installed delivery once; continue independent roadmap meanwhile.')
p.write_text(s,encoding='utf8')
print('R102 retained with explicit eager debt, exact source and all original evidence. Archive',status['archiveSHA256'])

