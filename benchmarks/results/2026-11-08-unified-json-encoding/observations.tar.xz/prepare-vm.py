from pathlib import Path
import ast,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'default-rsplit-r99/b459';b=r/'b461';b.mkdir()
source=json.loads((r/'identity.json').read_text(encoding='utf8'));previous=json.loads((old/'identity.json').read_text(encoding='utf8'))
jobs=[['scripts.json-normalize-eager.large','warm'],['scripts.json-normalize-streamed.large','warm'],['scripts.json-normalize-streamed.large','warm-async'],['scripts.config-edit.small','warm'],['scripts.csv-summary-functions.large','warm'],['scripts.json-summary-helpers.large','warm']]
identity={**previous,'sourceRevision':source['candidateSource'],'baselineSource':source['baselineSource'],'coreSHA256':{role:source['coreSHA256']['before' if role.startswith('reference') else 'candidate']for role in ['reference','reference-control','candidate','candidate-control']},'productionSources':source['productionSources'],'qualification':source['qualification'],'jobs':jobs}
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
for name in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
 s=(old/name).read_text(encoding='utf8').replace('default-rsplit-b459-20261108','completed-json-b461-20261108').replace('lython-b459-default-rsplit','lython-b461-completed-json').replace('default-rsplit-b459-launch.py','completed-json-b461-launch.py').replace('lython-b459-fixtures','lython-b461-fixtures')
 if name=='collect.py':
  a=s.index('jobs=');z=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[z:]
  a=s.index("purpose='");z=s.index("',\n",a)
  s=s[:a]+"purpose='R102 unified eager and streamed JSON traversal, completed operation helpers, temporary private metadata; full normalization scripts and config/CSV/decode controls"+s[z:]
 if name=='launch.py':
  s=s.replace("reference=base/'direct-operands-b457-20261108/candidate'","reference=base/'default-rsplit-b459-20261108/candidate'")
  needle=" assert hashlib.sha256((root/'baseline-core.dll').read_bytes()).hexdigest()==identity['coreSHA256']['reference']"
  assert needle in s
  s=s.replace(needle," assert hashlib.sha256((reference/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256']['reference']\n os.link(reference/'Lokad.Lython.dll',root/'baseline-core.dll')")
 (b/name).write_text(s,encoding='utf8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
for src,name in [(r/'images/candidate/Lokad.Lython.dll','current-core.dll'),(r/'catalog.json','representative.json'),(r/'identity.json','focused.json'),(r/'source.patch','source.patch'),(r/'pre-measurement-plan.md','pre-measurement-plan.md'),(old/'shared-worker-common.json','shared-worker-common.json'),(old/'setup-contract.json','setup-contract.json'),(r/'dedup-proof.json','space-maintenance.json')]:shutil.copyfile(src,b/name)
contract='''R102 one controlled source pair, unchanged worker/protocol/GC/tiering.
Baseline fully qualified c74c5802/core3fb37cc3, candidate core1674a06c.
Four completed-operation helpers and four recursive eager renderer helpers
replaced by one existing traversal and pending-only continuations.
Complete4096-record UTF8 JSON line normalization, eager and streamed output with
independent CPython full stdout/file goldens. Eager sync and streamed both APIs.
Config secondary affected, CSV unchanged, JSON summary decode-heavy with one
small encoded report. Eager async CPU controlled timing unmeasured.
Existing local diagnostic: eager allocation+4.9%; streamed neutral. Elapsed mixed
and desktop baseline drift up to35.8%; original adverse evidence retained.
Each core two processes;5s warmup/process/job,7x150ms rotated, coarse process CPU.
Guest RAM I/O/full validation and prior cleanup included; compile/startup/staging/
cache teardown excluded.210s owner+30stop+30margin. Persistent observations,
owned128MiB only guest files,240MiB OS floor+7MiB evidence+payload preflight.
All source/core/aux/Ready/goldens/quiet/Closed/join/fixture/archive/local gates.
Fresh exact-byte core hardlinks preserve all original paths/aliases and archives.
765public/171internal JSON checks peractual11/10. Temporary private metadata
funded across pending callbacks; exposed iterators retain their ordinary charge.
No new owners/caches/lifetime fields/parser/backend/memory layer/unsafe code.
Architecture/allocation/CPU decisions separate. All initial ownership/threshold
failures and original blank-line golden failure preserved. Full retained-boundary
qualification pending; publication/regex0.4/overall objective unchanged.
'''
(b/'contract.md').write_text(contract,encoding='utf8')
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for n in ['collect.py','run.sh','current-core.dll','representative.json','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','shared-worker-common.json','archive-owned.py','space-maintenance.json']:a.add(b/n,arcname=n)
print('B461 six jobs prepared, upload only candidate; existing baseline and auxiliary bytes verified at launch.')

