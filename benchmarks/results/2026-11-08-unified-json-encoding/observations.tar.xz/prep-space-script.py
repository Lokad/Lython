from pathlib import Path
import json
r=Path(__file__).parent
c=json.loads((r/'catalog.json').read_text(encoding='utf8'))
print([(x['id'],x['expectedOutput'],x['size'],x['fixtureTextUtf8Bytes']) for x in c['cases'][:2]])
s=(r/'selection.md').read_text(encoding='utf8').replace('4096record','1024record')
(r/'selection.md').write_text(s,encoding='utf8')
s=(r.parent/'default-rsplit-r99/prepare-space.py').read_text(encoding='utf8')
s=s.replace("('578496bb2cd4','0050f188b079')","('0873ec4624d2','6c6697991864','547825f9dfe5','137b563ac198')")
s=s.replace('r99-core-dedup-proof','r102-core-dedup-proof').replace('.r99-identical-link','.r102-identical-link')
s=s.replace('assert len(groups)==2','assert len(groups)==4').replace('two known immutable groups','four known immutable groups')
(r/'prepare-space.py').write_text(s,encoding='utf8')

