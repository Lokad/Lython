R102 one controlled source pair, unchanged worker/protocol/GC/tiering.
Baseline fully qualified c74c5802/core3fb37cc3, candidate core1674a06c.
Four completed-operation helpers and four recursive eager renderer helpers
replaced by one existing traversal and pending-only continuations.
Complete4096-record UTF8 JSON line normalization, eager and streamed output with
independent CPython full stdout/file goldens. Eager sync and streamed both APIs.
Config secondary affected, CSV unchanged, JSON summary decode-heavy with one
small encoded report. Eager async CPU controlled timing unmeasured.
Existing local diagnostic: eager allocation+4.9%; streamed neutral. Elapsed mixed
and desktop baseline drift up to35.8%; original adverse evidence retained.
Each core two processes;5s warmup/process/job,7x150ms rotated, coarse process CPU.
Guest RAM I/O/full validation and prior cleanup included; compile/startup/staging/
cache teardown excluded.210s owner+30stop+30margin. Persistent observations,
owned128MiB only guest files,240MiB OS floor+7MiB evidence+payload preflight.
All source/core/aux/Ready/goldens/quiet/Closed/join/fixture/archive/local gates.
Fresh exact-byte core hardlinks preserve all original paths/aliases and archives.
765public/171internal JSON checks peractual11/10. Temporary private metadata
funded across pending callbacks; exposed iterators retain their ordinary charge.
No new owners/caches/lifetime fields/parser/backend/memory layer/unsafe code.
Architecture/allocation/CPU decisions separate. All initial ownership/threshold
failures and original blank-line golden failure preserved. Full retained-boundary
qualification pending; publication/regex0.4/overall objective unchanged.
