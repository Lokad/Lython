R102 one JSON encoding traversal, completed operations direct.
Remove four default-path async state machines and four eager recursive value/
dict/sequence/default helpers. Existing iterator frame stack/markers/key/scalar
writers serve eager final-builder output and exposed/streamed chunks.
Small continuations exist only for actual pending callbacks. No lifetime fields,
new state/pool/cache/options/backend. Eager working metadata preflighted with the
existing temporary128B unit, held through pending work; exposed iterators retain
their value charge. Initial unified50accounting failures found wrong private
retained-value charge. Corrected to temporary lifetime;8tiny fixture failures then
targeted result admission explicitly with existing host hook, six duplicate
pressure variants removed without weakening publication/refund/first-origin tests.
765public/171internal peractual11/10 pass. Exact chunks/options/defaults/cycles/
mutation/managed nesting, real suspension/reentry/token/terminal refusal/cleanup.
Two complete4096record/110592B JSON normalize scripts, eager versus streamed output,
same independent Python stdout/file goldens. Config secondary affected, CSV
unchanged, JSON summary decode-heavy with one small encoded report. Existing
five-case driver/both APIs, normalGC/tiering. Metadata/frame allocation changes
are intentional measured tradeoffs, not predicted speedups. Preserve all original
failures/adverse results. One bounded controlled source pair follows.
Publication/regex0.4 unchanged; no repeated external CPython checkpoint.
