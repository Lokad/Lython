from pathlib import Path
import shutil
r=Path(__file__).parent
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');needle='   Preserve original scalar/key/container order, exact exposed iterencode chunks,'
assert needle in s
s=s.replace(needle,'''   Source refinement: eager SerializeJsonTextCoreAsync still has a second,
   recursive value/dictionary/sequence/default walker. Route eager output through
   the existing frame traversal directly into its caller-owned admitted builder,
   with no intermediate chunks/strings. Delete AppendJsonValueAsync,
   AppendJsonDictionaryAsync, AppendJsonSequenceAsync and AppendJsonReplacementAsync.
   This makes completed-operation changes apply to eager and streamed encoding.
   No new lifetime fields: the awaited driver borrows the caller builder; existing
   iterator cleanup owns only its frames/markers/sorted scratch. Eager operations
   acquire the existing iterator shell/frame metadata; conservative admission/order
   can change and extra per-container storage is a measured compatibility tradeoff.
   Measure eager and streamed complete workloads separately; retain/correct/reject
   remaining CPU/allocation debt explicitly. Preserve pure string/scalar/key writers.
'''+needle)
p.write_text(s,encoding='utf-8',newline='\n')
encoder=Path('src/Lokad.Lython/Runtime/LythonRuntime.Json.Encoder.cs')
shutil.copyfile(encoder,r/'prefix-only.cs')
s=encoder.read_text(encoding='utf-8');needle='        private void GrowScratch(long bytes)'
assert needle in s
driver='''        // Eager encoding borrows its caller's final builder. Frames, markers and
        // pending callbacks use the same traversal as exposed/streamed chunks;
        // Finish never owns this builder or refunds it while a callback is live.
        internal async ValueTask WriteToBuilderAsync(GovernedByteBuilder builder, bool asynchronous)
        {
            if (Interlocked.CompareExchange(ref _advancing, 1, 0) != 0)
            {
                _context.CheckExecution(_span);
                throw new LythonRuntimeException("ValueError", "generator already executing", _span);
            }
            try
            {
                while (true)
                {
                    _context.CheckExecution(_span);
                    var (advanced, _) = await AdvanceAsync(builder, asynchronous).ConfigureAwait(false);
                    if (!advanced) return;
                }
            }
            finally
            {
                try { Finish(); }
                finally { Volatile.Write(ref _advancing, 0); }
            }
        }

'''
s=s.replace(needle,driver+needle);encoder.write_text(s,encoding='utf-8',newline='\n')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Json.Serialize.cs');shutil.copyfile(p,r/'serialize-before.cs')
s=p.read_text(encoding='utf-8')
old='''                    var active = options.CheckCircular ? new HashSet<object>(ReferenceEqualityComparer.Instance) : null;
                    await AppendJsonValueAsync(builder, value, options, context, span, depth: 0, defaultDepth: 0, active, asynchronous).ConfigureAwait(false);'''
assert old in s;s=s.replace(old,'''                    var iterator = new JsonEncodeIterator(value, options, context, span);
                    await iterator.WriteToBuilderAsync(builder, asynchronous).ConfigureAwait(false);''')
a=s.index('        private static async ValueTask AppendJsonDictionaryAsync(');z=s.index('        internal static string JsonValueTypeName(',a);s=s[:a]+s[z:]
a=s.index('        private static async ValueTask AppendJsonSequenceAsync(');z=s.index('        internal static ValueTask AppendJsonObjectKeyAsync(',a);s=s[:a]+s[z:]
for name in ['AppendJsonValueAsync','AppendJsonDictionaryAsync','AppendJsonSequenceAsync','AppendJsonReplacementAsync']:assert name not in s
p.write_text(s,encoding='utf-8',newline='\n')
print('Eager output now borrows its final builder through the existing frame traversal; four recursive renderer helpers deleted. No new lifetime fields.')
