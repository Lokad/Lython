from pathlib import Path
r=Path(__file__).parent
p=Path('PLAN.md')
(r/'plan-before-condense.md').write_text(p.read_text(encoding='utf8'),encoding='utf8')
p.write_text("""# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
An isolated experiment does not complete this objective. Current contracts belong
in docs; completed/rejected designs and adverse evidence stay in
[EXPERIMENTS](benchmarks/EXPERIMENTS.md) and its linked immutable results.

## Actual delivery status

- **Fully qualified:** compiler-fact correction, direct UTF-8 formatting/storage,
  native helper returns and retained R62–R99 runtime changes. Latest runtime
  c74c5802/core3fb37cc3, cached CI42479543467: Windows/Ubuntu actual .NET11/10,
  original Stress and installed core consumers. R98 independently qualified.
  No replay of completed qualification.
- **Measured separately:** native returns allocation−19.92/−19.31%; original
  elapsed remains diagnostic. Formatting allocation−8.67%, controlled B102
  elapsed/CPU−5–8%; original adverse15.125ms remains unexplained/preserved.
  R99 default-rsplit allocation−16.46%lower/−11.88%upper; controlled lower
  elapsed−14–17%sync/about−13%async, upper−8–12%sync; coarseCPU agrees.
- **Current external baseline:** R97/94cb8963/cored6254b2e versus CPython3.13.16,
  26jobs539.873s, separate compile/warm/compile-to-result. Current guide accurately
  names that source; it does not describe HEAD. Warm CSV1.07×, JSON0.90–0.91×,
  returned CSV1.24–1.25×, rsplit1.80×, guarded text2.01–2.02×. Full I/O/validation/
  cleanup boundaries and uncertainty are in [BENCHMARKS](docs/BENCHMARKS.md).
- **Completed selection gates R100/R101:** integer sum already has unboxed64-bit
  accumulation; imports already execute compiled code; immutable builtin functions/
  signatures already shared. Setup profile atc74:552guest samples,31unknown5.62%;
  inclusive builtin factory3.44%, context ctor6.34%, JSON16.67%, filehost49.64%,
  kernel leaves60.33%. Groups overlap; no setup dominance or causal encoder timing.
  No lazy/global-root/scalar prototype selected.
- **Active prototype R102:** two-file unified JSON encoding traversal, four
  ordinary completed-operation helpers replace per-step async state machines;
  four recursive eager walker helpers removed.765public/171internal focused JSON
  checks peractual11/10 pass. Private eager working metadata now temporary, not
  an escaping iterator charge; original50+8 accounting failures preserved.
  Allocation diagnostic: eager complete normalization+4.9%, streamed neutral;
  desktop elapsed mixed/adverse with baseline drift up to35.8%. Not committed
  or fully qualified. Controlled B461 running; observation not before13:21:55UTC.
- **Independent regex:** exact dev55/d6067925 development qualification remains
  86internal/514public peractual11/10; supplied core/PythonRe SHAs unchanged at
  12:10UTC. Normal optional0.4 pin unchanged; only affected final released adapter
  qualification pending. Core development remains independent.

Historical regression debt remains explicit: R76 float, R79 CSV, R95 text,
R96 possible report, R98 desktop uncertainty and older native-text/control
uncertainty are not repaid by unrelated newer pairs. Old bulk CSV6–8% evidence
and its control regression remain; current shared keys/array adoption already
remove its proposed copying phase. Slower call-arena/control/wide-carrier designs
remain rejected with their lessons; no automatic revival.

## Prioritized execution

1. **Close R102 coherently.** One existing frame traversal serves eager final UTF-8
   builder output and streamed/exposed chunks; retain scalar/key/string writers.
   Default/native work completes directly; continuations only retain genuinely
   pending callbacks. Delete AppendJsonValueAsync/DictionaryAsync/SequenceAsync/
   ReplacementAsync; no second sync walker, new lifetime fields, cache/pool or
   parser redesign. Private shell uses an existing temporary128B reservation held
   through callbacks; exposed iterators keep their retained charge. Conservative
   admission thresholds and eager frame allocations change explicitly.
   Acceptance: original chunks/options/default/key order/cycles/mutation/Unicode/
   numeric/managed depth, real suspension/reentry, current cancellation, terminal
   first refusal, retained aliases and awaited refunds/cleanup.
   One complete4096-record eager/streamed normalization comparison, config secondary
   affected, CSV unchanged and JSON-decode-heavy controls, duplicate same-source
   processes; independent CPython full goldens. B461 sourcepair3fb/1674, normal
   GC/tiering, six jobs,210s owner+30stop+30margin. Persistent evidence, owned RAM
   only guest files. Source/allocation/CPU decisions separate: explicitly retain,
   refine or reject eager allocation/CPU debt. Preserve every failed condition.
   Full platform/Stress/installed checks only at the retained coherent boundary.
   If substantial regression remains, allow bounded correction with a named
   completion decision; do not silently accumulate performance debt.

2. **Next substantial runtime boundary.** Use current source/profile evidence to
   select a whole remaining phase and name its displaced code before editing.
   Calls/frames/operand transport already have direct argument projection, native
   workstate/returns and final slots; avoid reintroducing slower arenas or duplicate
   engines. For per-record construction, assess remaining admission/enumerator/
   final-storage costs rather than reviving copying already removed. For text/JSON,
   remove a real conversion/construction phase, preserving Unicode and callback
   semantics. Frontend work must show repeated facts on compile-to-result scripts;
   no speculative visitor/cache/JIT project. For each selected redesign record
   hypothesis, complete affected workloads, eliminated work/storage, source-level
   semantic acceptance and one bounded controlled before/after with controls.
   Finish the coherent deletion and decide remaining regression debt before moving
   to another optimization. Cancellation/admission/aliases must stay effective.

3. **Combined representative checkpoint.** Refresh maintained CPython cases at the
   next combined retained boundary, not after each local change. Separate compile,
   warm, compile-to-result/startup; report exact source/core/date/machine and included
   host I/O, validation and cleanup. Startup/pending-I/O/RSS/embedding tail remain
   unmeasured until actually measured. Preserve historical named-source tables.

4. **Independent regex contract/implementation.** Continue Python-owned native
   UTF-8, byte ranges/scalar positions/original windows, flags/captures/replacements/
   errors, cache ownership/current token and consistent frontend/runtime/import
   provider. Core has no backend dependency; optional adapter remains nonpackable.
   Development producers/adapter-local bridges support tests. Distinguish contract
   forwarding/unwind tests, semantic compatibility and real backend performance.
   Exact dev55 gaps: DetailedData lacks separate preparation/working owner, native
   names lack enumeration, cursor creation retains a token despite per-move tokens.
   Existing bridges remain justified. A published producer blocks only affected
   final adapter qualification, never independent work. Qualify released semantics,
   managed safety and performance when supplied; no sibling edits/builds or repeats.

## Evidence and stopping policy

Bounded confirmation, refinement and measurement correction are allowed when
justified. Timeout, unstable unchanged controls or inconclusive observations mean
uncertainty, not permanent design failure. Size runs for usable observations on the
quiet VM; keep adverse data and original failed conditions. Fixed percentages inform
decisions rather than veto useful simplification. Distinguish architecture,
allocation, demonstrated CPU and embedding latency. Temporary regressions require
an explicit completion milestone and retain/correct/reject decision.

AGENTS.md governs managed safety/stack admission, host capabilities, cooperative
tokens and shared coarse memory/preflights/replacement overlap. No unsafe/Unsafe/
native probing, independent caps/fuel/quotas, heap tracing/weak reclamation/forced
GC, silent regex dialect or abandoned work. Keep retained aliases/cache/results/
pending users funded until awaited cleanup. Refusal remains terminal; no retries
or optional-storage escape. Initial long streams use bounded host executions.

Focused Release iteration; no overlapping local builds/tests/measurements; force
fresh builds after timestamp-preserving restores. Batch actual11/10 Windows/Ubuntu,
original Stress and installed core consumers at retained boundaries. Explicit UTF-8.
Only core Release pack into artifacts/nuget; no publication. VM lokad@20.166.121.73,
key ~/.ssh/id_lython-bench.pem. Persistent evidence separate from owned RAM; join,
unmount/archive under lease and verify locally. Exact-byte hardlink maintenance
requires fresh proof and preserves every original path/alias/byte/archive.
B450–B460 and all recorded terminal CI runs are cached; never query/restart them.
B461 is the only active VM collection. CI observations>=5min apart; no duplicate
dispatch. Prior verbose status is preserved in R102 private pre-measurement history.
""",encoding='utf8',newline='\n')
print('Ignored PLAN condensed; status, R102 decision, independent roadmap, evidence and contracts preserved.')

