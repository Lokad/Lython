# Lokad.Lython 0.11.0

Updated 2026-11-12. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial whole-script improvements,
including compile-to-result. Another isolated experiment does not finish it.

## Delivery status

| State | Evidence / limitations |
| --- | --- |
| Committed and fully qualified `2ec9d67f` | Retained R250/R251 native word storage and borrowed call inputs, regressions and runtime documentation. **43119174279 terminal GREEN**, Windows/Ubuntu actual .NET 11/10, original stress and installed Release consumers. [Exact-source delivery](benchmarks/results/2026-11-12-native-inputs/delivery/README.md). No repeat qualification of unchanged production. |
| Earlier retained CPython checkpoint complete | B598, exact frozen `2ec9d67f` source/core with precommit assembly metadata; stock CPython 3.13.16. Eighteen jobs/487.070s, all gates/joins/RAM/archive pass. Compile, warm and compile-to-result separate; mediated RAM I/O, full validation and prior-result cleanup included, startup excluded. [Current guide](docs/BENCHMARKS.md), [raw/source evidence](benchmarks/results/2026-11-12-native-inputs-cpython-checkpoint/README.md). |
| Development regex input qualified | Immutable dev73/eae880c8, unchanged adapter-local Validate bridge: 86 internal/532 public per actual target, exact loaded package and 29 normal-file isolation proofs pass. First incomplete observation and terminal resumed checks retained. Normal adapter remains 0.4; no core dependency or sibling edits. [Evidence](benchmarks/results/2026-11-12-regex-development-73/README.md). Final capability gaps below remain. |
| Committed and fully qualified `82ed92d4` | R256 shared canonical receiver/truth services and awaited replacement-count protocols. **43139754244 terminal GREEN/cached**, Windows/Ubuntu actual11/10, original stress and installed Release consumers. 4562focused checks and seven complete scripts bothAPIs/compile pass; B602 ninejobs/251.083s all gates/joins/RAM/archive pass. Guarded allocation−71%, elapsed−23..−30% with supporting CPU; additional native-search/capturedRun CPU debt accepted explicitly. [Delivery](benchmarks/results/2026-11-12-receiver-operations/delivery/README.md). |
| Current affected CPython checkpoint | B603 exact frozen82ed/0106:9jobs/247.974s, all gates/joins/RAM/archive pass. Captured warm1.73–1.79x, native search1.61–1.64x, guarded search2.30–2.33x. Compile/warm/compile-to-result separate; unchanged clocks/worker/host. Four unaffected scripts retain2ec labels, older cases retain original revisions. [Guide](docs/BENCHMARKS.md). |
| Committed R259, delivery active `7114021e` | Direct completed function entry removes pending function/receiver and runner preparation; child result staging remains necessary.12938focused checks and7whole scripts bothAPIs/compile pass. B6059jobs251.294s allgates/joins/RAM/archive pass. GuardedAsyncelapsed−8.61..−6.75%, nativeRun−4.62..−3.22%, ordinaryRun−3.62..−0.82%, supportingCPU; allocationflat, other clocks/debt explicit. Full workflow43148511620 active; publication held. [Evidence](benchmarks/results/2026-11-12-completed-call-lifecycle/README.md). |

Completed milestones (reuse existing evidence/qualification):

- Shared compiler facts correct repeated/exponential analysis and nonlocal
  diagnostics; shared scope/binding facts ship. No CPU claim.
- Direct UTF-8 formatting/storage: allocation −8.67%; controlled elapsed/CPU
  5–8% lower. Original adverse 15.125ms remains unexplained and preserved.
- Original native helper returns: allocation −19.92% Run / −19.31% RunAsync;
  original elapsed changes are diagnostic. Fully qualified. Real double-refund
  during throwing cleanup/reentry corrected; do not repeat unchanged checks.
- Invocation setup/worker reuse, ordinary direct calls/receiver entry, lexical
  writes, returned iteration, bulk UTF-8/JSON, CSV capacity/adoption/shared keys,
  private totals, shared compiled workspace and captured native sequences ship.
  Former bulk CSV 6–8% work was reassessed/revised into current construction.
- R245 dictionary integer storage removes intermediate boxes; text allocation
  −14.90..−16.13%, CSV−3.13%, JSON-lines−4.20%, compile flat. Additional8B/key
  conservatively admitted; exposed integer identity/copies preserved. Fully
  qualified8f8628a4/458be840. Its reportAsync wider CPU+1.91..+6.38% is accepted
  historical debt, with a different reference from R250/R251.
- R250/R251 keep the ordinary ABI and cased iterator, avoid duplicate short-word
  objects in private histogram segments and share canonical UTF8 key lookup.
  Real insertion/observable binding materializes funded immutable strings.
  R251 deletes captured packing/clearing, the second16-slot buffer, appended-cell
  indexes and combined-capacity convention; one non-owning readonly input view
  borrows actual parameters and definition-owned live cells. The real binder's
  necessary parameter buffer remains. No new ledger/cache/controller/result ABI.
  Combined allocation−20.43..−22.44% for complete text; eager allowance unchanged.
  B597 capturedRun elapsed−8.74..−4.66%, ordinaryRun−9.68..−8.54% and ordinaryAsync
  −12.48..−9.49%, supporting CPU. CapturedAsync CPU remains uncertain. Additional
  reportAsync widerCPU0..+6.25% versus8f862 is accepted uncertainty; elapsed overlaps
  zero. Do not equate/compound earlier report debt or claim allocation implies CPU.
  [Source pair](benchmarks/results/2026-11-12-native-inputs/README.md).

Current warm Lython/CPython: captured text1.74×, ordinary0.99–1.06×variable,
CSV1.08–1.09×, JSON-lines0.85–0.89×variable, report1.26–1.31×variable, keyword-default
search1.61–1.64×current; guarded search2.30–2.33×. Captured text current1.73–1.79×.
Compilation near CPython; captured compile0.82–0.83×. Native search compile-to-result
1.48–1.61×variable; guarded2.02–2.07×. Older config/literal-search/CSV-summary/
manifest/patch rows remain revision-labelled. Synchronous external rows do not
settle async source-pair debt. RSS, pending-I/O/embedding tail latency and large-
file throughput remain unqualified; no single-change attribution across checkpoints.

## Next — coherent runtime redesign from current costs

1. **R256 delivery closed; reuse unchanged qualification.** Workflow43139754244
   terminalGREEN/cached; do not query again. B603 affected CPython refresh is
   complete. Native-search/capturedRun CPU debt versus2ec is explicitly accepted
   for this milestone, to be re-evaluated or accepted before publication. No new
   external ratio can be inferred by multiplying source-pair percentages.

2. **R259 delivery; R260 cell-write authority source gate.** Current committed7114
   awaits full workflow43148511620 (Windows/Ubuntu actual11/10, stress, installed
   Release consumers), check minutes apart and cache terminal. Keep working.
   Source pair above is complete; no unchanged retiming or external-row inference.
   Additional captured/report/CSV CPU uncertainty versus82ed is accepted at this
   milestone, separately from older82ed/2ec debt. Continue the wider objective.

   R260 hypothesis: reuse one existing cell assignment policy to keep its value,
   owned local-slot cache and genuinely mirrored namespace coherent. Currently
   StoreThroughOwner repeats name→slot lookup and unconditionally writes Variables;
   Value setter already has conditional mirroring, local stores also duplicate
   writes, and generator Resume refreshes all captured slots after suspension.
   Cache the immutable owned local slot when creating a cell, with identity checks
   against live storage; Value assignment updates that slot even while suspended.
   Namespace-backed comprehension/class cells keep their current explicit policy.
   Delete StoreThroughOwner shim, repeated mapping/unconditional mirror, duplicate
   local-store mirroring and the now-unnecessary Resume refresh. Keep the fast
   local operand cache; this is not tagged scalars or general heap ownership work.
   Source must prove inactive/detached owners and namespace-backed cells remain
   correct. Existing generator probe matchesCPython9 beforechanges because current
   Resume refresh works; no pre-existing bug is claimed. Preserve captured aliases,
   deleted cells/handlers, escaping lambdas/lowered annotations/class bodies,
   generator send/throw/close, callback reentry, cancellation, firstrefusal and
   retained funding. Focused closure/generator/nonlocal/native ownership tests on
   actual11/10, then short whole captured/ordinarytext+report control diagnostics.
   Retain only if this consolidates the invariant without new synchronization
   machinery; refine/restore on source/semantic evidence, performance claims require
   measured support. Wider scalar representation remains separate, no automatic
   follow-on redesign. No new cache/registry, owner, tracing, quota or policy switch.

R257 primitive counting increment is withdrawn:574focused tests and three complete
scripts bothAPIs pass; allocation flat, desktop timing mixed/adverse. The constant
was already unboxed outside the loop. A plain long replaces a checked argument
with an implicit signed-seven-byte precondition; rechecking recreates the removed
work, a new wrapper adds machinery. This small tradeoff is not the selected redesign.
Exact82ed production restored, nonincremental actual11/10 solution build23.35s zero
warnings/errors and coupled identity test1pass per target. Full unchanged delivery
is not repeated. [Evidence](benchmarks/results/2026-11-12-counting-increment-withdrawn/README.md).

3. Implement the selected coherent milestone below. State hypothesis, complete
   affected/control scripts, removed implementation, semantic acceptance and a
   bounded before/after comparison. Preserve ordinary/async semantic paths and
   real suspension/reentry. Temporary setbacks require a completion milestone
   and an explicit regression-debt disposition; continue the roadmap afterward.
4. Focused actual11 correctness/cancellation/ownership while iterating; actual10
   affected checks before freeze. Compare complete scripts through both APIs,
   separate compile. Batch full platform/stress/installed-package checks at the
   next coherent retained-source delivery; refresh external baseline when material.

| Candidate / hypothesis | Work to eliminate / affected scripts | Acceptance / displaced implementation |
| --- | --- | --- |
| Complete calls, frames and operand transport | Find actual duplicate preparation or transport in captured text/search and report. R241 already shares backing, context already is the frame, borrowed prefix already defers context creation. | Live defaults, receiver/descriptors/keywords/expansion, closures, protocol suspension/reentry, Python errors/order and funded aliases. Choose one existing representation, delete the displaced storage/dispatch stage; no revived measured-slower arenas/controllers or partial banks without a complete demonstrated convention. |
| Per-record/text construction | Current preparation/probing/value construction is real work; find removable rescanning/materialization/format transport in text/report/CSV. | Admission before first effects, Unicode expansion/sigma, formatting/protocol hooks, key order/header mutation, reentry and retained values. Remove actual scanner/conversion/backing, not a stage already absent. No new two-word vector or worst-case streaming allowance. |
| Scoped scalar/storage work | R245 removes container intermediates; establish remaining dominant allocation/CPU before generalizing. | Exact promotion, bool/int semantics, stable identity/aliases/projection/ownership. No universal tagged stack based solely on boxing. Name displaced representation and decide remaining regression debt. |
| Frontend consolidation | Compilation near CPython cannot explain captured warm gap. Merge only an actual repeated analysis. | Diagnostics/spans, annotations/generators/imports, cancellation and compilation ownership. Reuse facts, remove displaced traversal/tree; measure compile-to-result. No speculative heavyweight JIT. |

Source facts already checked: native nodes72B/instruction copy32B in actual Unix
code; shared frame/local backing already exists. Raw UTF8 read windows and CSV
caller-owned storage already avoid decoding; these text scripts have no strip().
Multipart formatting already writes primitives into one builder without field
strings; .NET11 grouped integers already use UTF8 TryFormat, .NET10 char bridge
intentional. Keyword-default PyString names prepared once per definition; no
per-call name conversion. Fixed binder buffer performs real binding; overwriting
caller operands before failed proof needs a new fallback/ownership convention.
Do not force a rewrite of an absent duplicate stage.

## Evidence and experimental decisions

Historical source pairs, adverse results, rejected designs and original failed
conditions live in [EXPERIMENTS](benchmarks/EXPERIMENTS.md), immutable results and
prior ignored plans under `.git/agent-notes/review-20261031/`. Keep docs current.
R247 native-loop stack-scope hoist and all R249 general return/iteration transport
forms are withdrawn; qualified baseline restored and regression coverage retained.
R244 known-call maps likewise withdrawn. No surviving production prototype.
Call arenas/controllers measured slower: retain those lessons, not permanent bans.

Initial R250 async-search/CSV adversity survives separately; B596 paired profile
and structural IL comparison do not identify a JIT cause. B597 combined source
does not reproduce it, without a recovery attribution. Original desktop CSV and
ordinaryAsync adversity also survives. No more unchanged B596 captures/retiming.

Bounded confirmation/refinement/measurement correction is allowed when justified.
Timeout, unstable unchanged controls and inconclusive observations establish
uncertainty, not failed design/permanent closure. Percentages inform decisions,
not automatic vetoes. Distinguish architectural simplification, physical allocation,
reserved allowance and demonstrated CPU. Size quiet runs for usable observations;
retain original failures and adverse data. Before publication explicitly resolve
or accept remaining material report/CSV/compile uncertainty at a coherent checkpoint.

## Independent regex track

Core Python/native-UTF8 contract, byte/scalar coordinates, original windows,
effective flags, current tokens, explicit owners and cache semantics delivered.
Optional nonpackable adapter0.4; immutable dev73 development qualification above
reuses the validated bridge and isolates pins/assets/outputs. No final pin promotion.

Only affected final adapter qualification awaits these exact producer capabilities:

- Independent single-match working/result owners.
- Native UTF8 group-name enumeration; native lookup already exists.
- Token-independent cursor creation with cancellable preparation; per-move
  cancellation alone does not prove interruption during preparation.

Four relevant producer API files remain byte-identical dev68→73. No additional
core plumbing/bridge rewrite justified. Adapter-local temporary conversions and
cursor cancellation bridge support independent development; remove displaced
conversions/DetailedData when real capabilities arrive. No publication polling.
Contract tests, semantic validation and actual backend CPU/safety/SizeOf are
separate claims. Missing published APIs never stop core work.

## Lasting contracts and delivery

Fully managed/safe: no unsafe/Unsafe/pointers/PInvoke/native probing. Preserve
managed stack admission, host capabilities, cancellation, cycle/XML-depth checks,
checked representation bounds and bounded I/O. No fuel/quotas/independent caps/
hidden allowance, tracing/root inventories/weak reclamation/forcedGC/retries or
abandoned users. Borrowed allowance funds capacity/overlap/results/aliases/caches/
pending borrows until awaited cleanup. First refusal fails command with original
structured origin despite suppression/finally return; guest MemoryError catchable.
Long streams use bounded host commands. Preserve LythonPathRequest/Cwd/component
resolution and old destination on refused copy.

Never relax assertions/timeouts. GC/deadline fixtures use existing nonparallel
collections. Restored-source builds must be nonincremental before no-build/freeze.
43119174279GREEN,43087005596GREEN,43081976930failed and older terminal CI are
cached: never requery. B576–B600terminal/cached; B600failed with11partial warm
jobs, archived recovery and no remaining VM users/RAM. Its fresh proof retired
all predecessor75a14core aliases and B599raw/catalog duplicates against committed
canonical archives. Those paths are off limits. B601fresh proof additionally retires all withdrawn
R254first-core aliases, B600partial raw/catalog and B446raw duplicates against
committed canonical evidence. c982reference and R256candidate remain protected.
B601is the only live owned comparison; exact bound above. No restart/requery of
terminal older handles, and no full prototype delivery until retention is decided.
New staging requires fresh lease/identity/disk/UID/inode/all-alias proof; never
reference retired duplicates. Selected reference is now fully qualified2ec9d; the predecessor8f862 core is
eligible only for explicitly proven all-alias retirement. Current2ec9d and selected R256candidate cores stay protected. Verify committed canonical archives before
retiring duplicate evidence. No redundant full qualification. Publication held.
