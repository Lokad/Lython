from pathlib import Path
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.cs');s=p.read_text(encoding='utf-8');s=s.replace('        private readonly string? _name;','        private readonly string? _name;\n        private readonly int _ownerSlot;',1)
s=s.replace('public ExecutableCell(object? value, ExecutionContext? owner = null, string? name = null)','public ExecutableCell(object? value, ExecutionContext? owner = null, string? name = null, int ownerSlot = -1)')
s=s.replace('            _name = name;','            _name = name;\n            _ownerSlot = ownerSlot;',1)
needle='''                _value = value;
                if (_owner is { MirrorsExecutableLocals: true } || _owner?.MirrorLocalStores == true)'''
assert needle in s;s=s.replace(needle,'''                _value = value;
                // A live local cache belongs to this exact cell. Update it even
                // while its generator is suspended; detached owners have no
                // local-cell backing. Namespace-backed cells have no own slot.
                if (_owner?._execution.LocalCells is { } cells && (uint)_ownerSlot < (uint)cells.Length
                    && ReferenceEquals(cells[_ownerSlot], this))
                    _owner._execution.Locals[_ownerSlot] = value!;
                if (_owner is { MirrorsExecutableLocals: true } || _owner?.MirrorLocalStores == true)''',1)
a=s.index('        // Incoming writes already know');b=s.index('        // MG11:',a);s=s[:a]+s[b:]
s=s.replace('''                _execution.Locals[localSlot] = value;
                if (_execution.LocalCells?[localSlot] is ExecutableCell localCell)
                {
                    localCell.Value = value;
                }
''','''                if (_execution.LocalCells?[localSlot] is ExecutableCell localCell) localCell.Value = value;
                else _execution.Locals[localSlot] = value;
''',1)
s=s.replace('''                _execution.Locals[localSlot] = null!;
                if (_execution.LocalCells?[localSlot] is ExecutableCell localCell)
                {
                    removed |= localCell.Value is not null;
                    localCell.Value = null;
                }
''','''                if (_execution.LocalCells?[localSlot] is ExecutableCell localCell)
                {
                    removed |= localCell.Value is not null;
                    localCell.Value = null;
                }
                else _execution.Locals[localSlot] = null!;
''',1)
s=s.replace('new ExecutableCell(argumentsAreLocals ? locals[slot] : null, context, codeObject.LocalNames[slot])','new ExecutableCell(argumentsAreLocals ? locals[slot] : null, context, codeObject.LocalNames[slot], slot)')
p.write_text(s,encoding='utf-8')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs');s=p.read_text(encoding='utf-8');a=s.index('            // A retained closure can write a cell while this generator is');b=s.index('            HasYield = false;',a);s=s[:a]+s[b:]
a='''            locals[slot] = value;
            if (localCells?[slot] is ExecutableCell localCell)
            {
                localCell.Value = value;
            }

            if (guestName && (codeObject.RequiresLocalVariableMirroring || context?.MirrorLocalStores == true))
            {
                context!.Variables[name] = value;
            }'''
b='''            if (localCells?[slot] is ExecutableCell localCell)
            {
                // The cell owns both its local cache and namespace policy.
                localCell.Value = value;
            }
            else
            {
                locals[slot] = value;
                if (guestName && (codeObject.RequiresLocalVariableMirroring || context?.MirrorLocalStores == true))
                    context!.Variables[name] = value;
            }'''
assert a in s;s=s.replace(a,b);p.write_text(s,encoding='utf-8')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Binding.cs');s=p.read_text(encoding='utf-8').replace('cells[slot].StoreThroughOwner(value);','cells[slot].Value = value;').replace('if (cell.CanStoreThroughOwner) cell.StoreThroughOwner(value);','if (cell.CanStoreThroughOwner) cell.Value = value;');p.write_text(s,encoding='utf-8')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs');s=p.read_text(encoding='utf-8').replace('arguments.Cells![instruction.ClosureSlot].StoreThroughOwner(stored);','arguments.Cells![instruction.ClosureSlot].Value = stored;');p.write_text(s,encoding='utf-8')
print('Cell assignment owns live/suspended cache and existing conditional namespace mirror; removed owner-store method and Resume refresh.')
