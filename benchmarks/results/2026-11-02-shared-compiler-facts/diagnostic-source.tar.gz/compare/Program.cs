using System.Diagnostics;
using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;

var root = Path.GetFullPath(args[0]);
using var original = new Image(Path.Combine(root, "baseline-probe", "Lokad.Lython.dll"), "original");
using var candidate = new Image(Path.Combine(root, "candidate-probe", "Lokad.Lython.dll"), "candidate");
using var control = new Image(Path.Combine(root, "baseline-probe", "Lokad.Lython.dll"), "identical-original");
var images = new[] { original, candidate, control };
if (images.Select(x => x.Core).Distinct().Count() != 3 || original.Hash != control.Hash || original.Hash == candidate.Hash)
    throw new InvalidDataException("Frozen core identity/isolation failure.");
foreach (var image in images) for (var i = 0; i < 16; i++) image.Compile("value = 1\ndel value\n");
var rows = new List<object>();
foreach (var (name, source, iterations, rounds) in new[] {
    ("shared-tuple-8", File.ReadAllText(Path.Combine(root,"shared-tuple-8.py")), 32, 3),
    ("shared-tuple-24", File.ReadAllText(Path.Combine(root,"shared-tuple-24.py")), 1, 3),
    ("csv-helper-control", File.ReadAllText(args[1]), 128, 5) })
{
    for (var round = 0; round < rounds; round++) for (var offset = 0; offset < images.Length; offset++)
    {
        var image = images[(round + offset) % images.Length];
        long compile = 0, cleanup = 0, allocated = 0, maxCharge = 0;
        for (var index = 0; index < iterations; index++)
        {
            var sample = image.Compile(source);
            compile += sample.compileTicks; cleanup += sample.cleanupTicks;
            allocated += sample.allocated; maxCharge = Math.Max(maxCharge, sample.charge);
        }
        rows.Add(new { name, round, image = image.Label, iterations,
            compileMicroseconds = compile * 1e6 / Stopwatch.Frequency / iterations,
            cleanupMicroseconds = cleanup * 1e6 / Stopwatch.Frequency / iterations,
            currentThreadAllocatedBytes = (double)allocated / iterations, maxLiveCharge = maxCharge, finalBalance = image.Balance });
        Save();
    }
}
var large = candidate.Compile(File.ReadAllText(Path.Combine(root,"shared-tuple-128.py")));
Save();
Console.WriteLine(JsonSerializer.Serialize(new { candidateOnly128CompileUs = large.compileTicks * 1e6 / Stopwatch.Frequency,
    candidateOnly128CleanupUs = large.cleanupTicks * 1e6 / Stopwatch.Frequency, allBalancesZero = images.All(x=>x.Balance==0) }));
void Save() => File.WriteAllText(Path.Combine(root,"comparison.json"), JsonSerializer.Serialize(new {
    purpose = "One bounded local compilation diagnostic, not a CPython or ordinary-workload speed qualification",
    sourceBase = "6418de81", runtime = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
    machine = Environment.MachineName, processors = Environment.ProcessorCount,
    frequency = Stopwatch.Frequency, coreImages = images.Select(x=>new{x.Label,x.Hash}),
    boundary = "Reflection into public Compile(source, finite shared budget); compilation and deterministic script-owner cleanup have separate clocks. Startup, execution and I/O excluded. Ordinary GC/tiering, shared CoreLib, rotating image order.",
    allBalancesZero = images.All(x=>x.Balance==0), observations = rows }, new JsonSerializerOptions { WriteIndented = true }));

sealed class Image : IDisposable
{
    readonly AssemblyLoadContext context;
    readonly object engine, budget;
    readonly MethodInfo compile;
    readonly PropertyInfo balance, valid;
    public string Label { get; }
    public string Hash { get; }
    public Assembly Core { get; }
    public long Balance => (long)balance.GetValue(budget)!;
    public Image(string path, string label)
    {
        Label = label; Hash = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(path)));
        context = new AssemblyLoadContext(label,isCollectible:true);
        Core = context.LoadFromAssemblyPath(path);
        var engineType = Core.GetType("Lokad.Lython.LythonEngine",true)!;
        var budgetType = Core.GetType("Lokad.Lython.LythonMemoryBudget",true)!;
        engine = Activator.CreateInstance(engineType)!;
        budget = Activator.CreateInstance(budgetType,[16L * 1024 * 1024])!;
        compile = engineType.GetMethod("Compile",[typeof(string),Core.GetType("Lokad.Lython.ILythonMemoryBudget",true)!])!;
        balance = budgetType.GetProperty("ReservedBytes")!;
        valid = Core.GetType("Lokad.Lython.LythonCompiledScript",true)!.GetProperty("IsValid")!;
        if (engineType.BaseType!.Assembly != typeof(object).Assembly) throw new InvalidDataException("CoreLib mismatch.");
    }
    public (long compileTicks,long cleanupTicks,long allocated,long charge) Compile(string source)
    {
        if (Balance != 0) throw new InvalidDataException("Prior compiler owner was not relinquished.");
        var before = GC.GetAllocatedBytesForCurrentThread();
        var start = Stopwatch.GetTimestamp();
        var script = compile.Invoke(engine,[source,budget])!;
        var compiled = Stopwatch.GetTimestamp();
        var allocated = GC.GetAllocatedBytesForCurrentThread()-before;
        long charge, cleanupStart = 0, done = 0;
        try
        {
            if (!(bool)valid.GetValue(script)!) throw new InvalidDataException("Compilation rejected the golden source.");
            charge = Balance;
        }
        finally
        {
            cleanupStart = Stopwatch.GetTimestamp();
            ((IDisposable)script).Dispose();
            done = Stopwatch.GetTimestamp();
        }
        if (charge <= 0 || Balance != 0) throw new InvalidDataException("Compiler ownership imbalance.");
        return (compiled-start,done-cleanupStart,allocated,charge);
    }
    public void Dispose() { if (Balance != 0) throw new InvalidDataException("Leaked allowance."); context.Unload(); }
}
