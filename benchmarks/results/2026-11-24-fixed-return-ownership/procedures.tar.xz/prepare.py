from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/'.git/agent-worktrees/fixed-return-ownership-20261124'
donor=lab.with_name('compiled-regex-receivers-20261124')
comparison=lab/'comparison'
comparison.mkdir(exist_ok=True)


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')


metadata=read(donor/'comparison/identity.json')
reference=metadata['candidate']
assert reference.startswith('81ce6201e')
subprocess.run(['git','diff','--exit-code',reference,'HEAD','--','src','tests'],cwd=repo,check=True)
assert not subprocess.check_output(['git','status','--porcelain','--','src','tests'],cwd=tree)
candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip()
assert candidate!=reference
catalog=read(lab.with_name('current-rule-closures-cpython-20261124')/'external/representative.json')
assert [c['id'] for c in catalog['cases']]==[
    'scripts.rule-default-closures','scripts.annotated-rule-closures','scripts.captured-rule-closures']
quote,=[c for c in read(donor/'comparison/representative.json')['cases'] if c['id'].endswith('quoted-control')]
catalog['cases']=[catalog['cases'][2],catalog['cases'][0],catalog['cases'][1],quote]
representative=comparison/'representative.json'
save(representative,catalog)
save(comparison/'jobs.json',{'warm':[[case['id'],'warm'] for case in catalog['cases']]})
files=metadata['imageFiles']['candidate']
runtime=Path.home()/'.dotnet11'
dotnet=runtime/'dotnet.exe'
protocol=repo/'benchmarks/cpython-worker.py'
assert digest(protocol)==metadata['cpythonWorkerSHA256']
env=dict(os.environ,DOTNET_ROOT=str(runtime),DOTNET_ROOT_X64=str(runtime))
assert len(files)==32 and all(digest(donor/'candidate'/name)==expected for name,expected in files.items())
core='Lokad.Lython.dll'
images={}
helpers={}
for role in ('reference','candidate'):
    image=lab/role
    image.mkdir(exist_ok=True)
    for name in files:
        source=lab/'frozen/bin/Lokad.Lython/release_net11.0'/core if role=='candidate' and name==core else donor/'candidate'/name
        shutil.copyfile(source,image/name)
    for suffix in ('.dll','.deps.json','.runtimeconfig.json'):
        helper='ValidatedAllocation'+suffix
        shutil.copyfile(donor/'candidate'/helper,image/helper)
        helpers[helper]=digest(image/helper)
    observed={name:digest(image/name) for name in files}
    result=comparison/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',
        representative,'--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',
        protocol,'--out',result],env=env,check=True,timeout=90)
    proof=read(result)
    assert proof['state']=='Completed' and proof['caseCount']==4 and proof['launched']['library']['sha256']==observed[core]
    assert all(digest(image/name)==expected for name,expected in observed.items())
    assert all(digest(image/name)==expected for name,expected in helpers.items())
    images[role]=observed
assert files==images['reference']
assert [name for name in files if images['reference'][name]!=images['candidate'][name]]==[core]
save(comparison/'identity.json',dict(sourceRevision=reference,candidate=candidate,
    purpose='B1566 fund fixed unpack scalar publication through caller-backed slots',
    imageFiles=images,helperFiles=helpers,cpythonWorkerSHA256=metadata['cpythonWorkerSHA256'],
    expectedCPythonSHA256=metadata['expectedCPythonSHA256'],
    catalogs={name:dict(sha256=digest(comparison/name)) for name in ('representative.json','jobs.json')},
    coreSHA256={label:images[role][core] for role in images for label in (role,role+'-control')}))
shutil.copyfile(donor/'allocations.py',lab/'allocations.py')
