#!/usr/bin/env bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
cd /mnt/d/code/Lython/.git/agent-worktrees/final-function-defaults-r612
public='FullyQualifiedName~FunctionDefault|FullyQualifiedName~DefinitionIdentity|FullyQualifiedName~LambdaLifetime|FullyQualifiedName~FunctionDocstringLifetime'
white='FullyQualifiedName~ExecutableFunction|FullyQualifiedName~FunctionDefault|FullyQualifiedName~LambdaExecutable|FullyQualifiedName~SimpleFunctionExecutionBoundary|FullyQualifiedName~BoundBoxCleanup|FullyQualifiedName~NativeFunctionRefund'
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path artifacts/r612-combined-wsl --filter "$public"
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --artifacts-path artifacts/r612-combined-wsl --filter "$white"
