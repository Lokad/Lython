from pathlib import Path
import json,subprocess
r=Path(__file__).parent;q=r/'profile';c=json.loads((q/'config.json').read_text(encoding='utf-8'))
observed=sorted(q.glob('observation-*.json'));assert observed
original=json.loads(observed[-1].read_text(encoding='utf-8'));assert not original['live']and original['exitCode']=='1'and not original['remainingWorkers']and original['remainingTrace']
(q/'original-failed-postprocessing-status.json').write_text(json.dumps(original,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import fcntl,gzip,hashlib,json,os,shutil,stat,subprocess,tarfile
c=CONFIG
root=Path(c['root']);assert root.resolve()==root and root.parent==Path('/home/lokad/lython-bench-checks')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 state=subprocess.check_output(['systemctl','show',c['unit']+'.service','--property=MainPID,ActiveState'],text=True);assert'MainPID=0'in state and'ActiveState=failed'in state
 assert(root/'exit-code.txt').read_text().strip()=='1'and os.path.ismount(root/'guest-fixtures')
 for n,h in c['sourceFiles'].items():assert hashlib.sha256((root/'candidate'/n).read_bytes()).hexdigest()==h
 trace=root/'guest-fixtures/profiles';folder=trace/'normalization';record=json.loads((folder/'record.json').read_text())
 assert record['exitCode']==0 and record['closed']['status']=='Closed'and record['verificationBefore']['status']=='Equivalent'and record['verificationAfter']['status']=='Equivalent'
 assert json.loads((root/'machine-before.json').read_text())['gate']['quiet']
 raw=folder/'perf.data';m=raw.lstat();assert raw.resolve()==raw and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid();rawhash=hashlib.sha256(raw.read_bytes()).hexdigest()
 prior=folder/'perf-report.txt';prior.rename(folder/'original-failed-perf-report.txt')
 with(folder/'perf-report.txt').open('w')as report:subprocess.run(['perf','report','-i',str(raw),'--stdio','--tid',record['activeCpuTid'],'--no-children','--sort','comm,dso,symbol','--percent-limit','1'],stdout=report,stderr=subprocess.STDOUT,check=True,timeout=15)
 for name,args in [('perf-stacks.txt.gz',['--tid',record['activeCpuTid']]),('all-thread-stacks.txt.gz',[])]:
  data=subprocess.check_output(['perf','script','-i',str(raw),*args],stderr=subprocess.STDOUT,timeout=15)
  with gzip.open(folder/name,'wb')as f:f.write(data)
 for name in ['perf.map','perfinfo.map']:
  p=folder/name
  if p.exists():
   data=p.read_bytes()
   with gzip.open(str(p)+'.gz','wb')as f:f.write(data)
   with gzip.open(str(p)+'.gz','rb')as f:assert f.read()==data
   p.unlink()
 assert hashlib.sha256(raw.read_bytes()).hexdigest()==rawhash
 env=os.environ.copy();env['DOTNET_ROOT']='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148'
 subprocess.run([env['DOTNET_ROOT']+'/dotnet',str(root/'candidate/Lokad.Lython.Benchmarks.dll'),'--compare','check-machine','--out',str(root/'machine-after.json')],env=env,check=True)
 assert json.loads((root/'machine-after.json').read_text())['gate']['quiet']
 proof=dict(originalServiceExitCode=1,workerExitCode=0,workerClosedAndGoldensVerified=True,recoveredOnlyOfflinePostprocessing=True,noCaptureOrGuestReexecution=True,rawPerfSHA256=rawhash,originalBadCommand="perf normalization",correctedCommand="perf report")
 (root/'postprocessing-recovery.json').write_text(json.dumps(proof,indent=2)+'\n')
 rawfiles={p.relative_to(trace).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in trace.rglob('*')if p.is_file()}
 with tarfile.open(root/'observations.tgz','w:gz',dereference=True)as a:
  for p in sorted(root.iterdir()):
   if p.is_file()and p.name!='observations.tgz':a.add(p,arcname=p.name)
  a.add(trace,arcname='profiles')
 with tarfile.open(root/'observations.tgz')as a:
  for n,h in rawfiles.items():assert hashlib.sha256(a.extractfile('profiles/'+n).read()).hexdigest()==h
 assert shutil.disk_usage(root).free>252*1024*1024
 subprocess.run(['sudo','-n','umount',str(root/'guest-fixtures')],check=True);(root/'guest-fixtures').rmdir()
 receipt=dict(complete=True,allWorkersJoined=True,quietBeforeAndAfter=True,guestFixturesRemoved=True,archivedAndVerifiedUnderLease=True,ramTraceArchivedAndVerifiedBeforeUnmount=True,freeBytes=shutil.disk_usage(root).free,archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest(),source='0a04e253/frozen810dafdd',performanceComparison=False,postprocessingRecovered=True,originalServiceExitCode=1)
 (root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
'''.replace('CONFIG',repr(c))
(q/'recovery-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);(q/'recovery.log').write_text(p.stdout+p.stderr,encoding='utf-8',newline='\n');assert p.returncode==0,p.stdout+p.stderr
print(p.stdout)
s=(q/'retrieve.py').read_text(encoding='utf-8').replace("assert status['exitCode']=='0'and status['receipt']['complete']", "assert status['exitCode']=='1'and status['receipt']['complete']and status['receipt']['postprocessingRecovered']")
(q/'retrieve-recovered.py').write_text(s,encoding='utf-8',newline='\n')
