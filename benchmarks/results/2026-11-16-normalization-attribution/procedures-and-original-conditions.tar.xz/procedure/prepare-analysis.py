from pathlib import Path
import ast
r=Path(__file__).parent
s=(r.parent/'calls-current-r420/analyze.py').read_text(encoding='utf-8').replace("['report']","['normalization']")
a=s.index(' groups=');b=s.index('\n inclusive=',a)
s=s[:a]+''' groups={'generator lifecycle':['PyGenerator::','EnterExecutableSlots','LeaveExecutableSlots','EnterFunctionCall','EnterInterpreterFrame'],
 'iteration/drain':['PyIteration','MaterializeLeased','DrainLeased','EnumerateJoinParts','MoveNext'],
 'call/operand transport':['InvokeExecutableGeneralTargetAsync','PrepareExecutableCallArguments','InvokeBorrowedCallableTarget','BoundCallable','CallBinder','LoadCallMember','ExecuteInstruction'],
 'bulk text':['ExpandTabs','Replace','JoinStrings','RStrip','Strip','Split'],
 'admission/checks':['MemoryGovernor','TryResize','CheckExecution','ReserveTemporary','ReleaseReserved'],
 'byte storage':['GovernedByteBuilder'],
 'host/file':['FileRead','TextFile','FileWrite','ComparisonHost'],
 'execution dispatch':['ExecutionContext::Execute','Executable','Interpreter']}
'''+s[b:]
ast.parse(s);(r/'analyze.py').write_text(s,encoding='utf-8',newline='\n')
s=(r.parent/'consume-text-r426/poll-delivery.py').read_text(encoding='utf-8').replace("parent/'delivery'","parent/'delivery-corrections'")
(r.parent/'consume-text-r426/poll-corrected-delivery.py').write_text(s,encoding='utf-8',newline='\n')
