from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;q=r/'profile';out=Path('benchmarks/results/2026-11-16-normalization-attribution');out.mkdir()
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['postprocessingRecovered']and receipt['allWorkersJoined']
assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for n in ['identity.json','observations.tgz','archive-receipt.json','terminal-status.json','original-failed-postprocessing-status.json']:shutil.copyfile(q/n,out/n)
for n in ['attribution.json','lambda-identities.json']:shutil.copyfile(r/n,out/n)
with tarfile.open(out/'procedures-and-original-conditions.tar.xz','w:xz')as a:
 for p in r.iterdir():
  if p.is_file():a.add(p,arcname='procedure/'+p.name)
  elif p.name.startswith('original-'):a.add(p,arcname=p.name)
 for p in q.iterdir():
  if p.is_file()and p.name not in ['observations.tgz','payload.tgz']:a.add(p,arcname='profile/'+p.name)
 for n in ['Program.cs','Inspect.csproj']:a.add(r/'inspect'/n,arcname='inspect/'+n)
 a.add(r.parent/'consume-text-r426/delivery-corrections/source-proof.json',arcname='source-proof.json')
(out/'README.md').write_text('''# Complete normalization CPU attribution

R428/B824, 2026-11-16 UTC; committed **0a04e253 / measured810dafdd**. Same
52,224-byte/4,096-line script as the [CPython comparison](../2026-11-16-normalization-cpython-checkpoint/README.md).
597 source/build/test inputs verified; production unchanged by test-only corrections.
Full43800910729 is pending. No source comparison or performance gain measured.

Eight guest seconds warmup; **4.841 guest seconds /3,840 complete invocations**
sampled at199Hz CPU-clock/frame-pointer, diagnostic DOTNET_PerfMapEnabled=3.
Whole worker includes mediated RAM I/O, resets/protocol/goldens and prior-result
cleanup, wider than execution clocks. Quiet F4as_v7/Ubuntu24.04.4, four EPYC9V45
vCPUs,16GiB/no swap,.NET11RC3 ordinary tiering/natural workstation GC.

981 active-thread samples,193 unknown leaves; execution worker4.62 CPU seconds,
GC0.33,JIT0.08. Other-thread CPU/raw samples retained. Inclusive overlapping
groups:521 iteration/drain,399 generator lifecycle,261 bulk text,192 admission.
They include useful/inlined work and are not removable overhead shares. Execution
dispatch/call groups overlap most guest work and cannot justify replacing the ABI.
Nearest frames include75 instruction prefix,57 Reserve,44 rstrip,31 generator
advance and21 drain. Managed reflection resolves the94-nearest/78-leaf anonymous
method as **ExpandTabsMethod** (7.95% of active leaves); splitlines and TextWrite
anonymous methods are also identified. No inference that all text/call/GC work
can be eliminated.

Select **R429 direct bulk-output construction**: expandtabs currently decodes,
checks and appends each scalar; join has already materialized private input but
adds another iterator and growing byte builder. Replace both output-construction
pipelines with measured native UTF8, existing one final admitted PyString storage
and bounded copies/fills. Remove their growing-builder representation and join
iterator/helper; preserve arbitrary iterable draining, error order, native string
coercion, Unicode columns/newline resets, cancellation and funded inputs/output.
This is a bounded coherent storage milestone, not a prediction that it closes the
whole gap. Generator/frame construction remains a later independent source gate.
Measure complete normalization warm/fresh, report and unchanged JSON controls;
allocation/CPU/elapsed decisions stay separate and all adverse conditions remain.

Original capture worker verified both goldens, Closed and exit0. A preparation
replacement accidentally changed `perf report` to `perf normalization`; service
exit1 and original failed report are preserved. Recovered only offline processing
of the same immutable perf.data: no guest or capture reexecution. Fresh quiet
gate and persistent archive/hash verification completed under lease before RAM
unmount; all users joined. Two staging failures (missing old working archive and
disk headroom) also retained; both stopped before mutation/capture. Only exact
Git-archived VM replicas were retired after path/hash/ownership/all-alias checks;
current core images/toolchains and254/252MiB floors preserved. No trace abandoned.
The failed service terminal remains failed and cached; the recovery is explicit.

[All samples](attribution.json), [method identities](lambda-identities.json),
[raw capture/recovery](observations.tgz), [procedures/original conditions](procedures-and-original-conditions.tar.xz).
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n\n[R428/B824 complete normalization CPU attribution](results/2026-11-16-normalization-attribution/README.md): 0a04e253/810dafdd;981active-thread samples/193unknown,4.841guest seconds. Expanding tabs resolved by managed metadata to94nearest/78leaf samples; overlapping generator/iteration groups are not removable shares. R429 selects whole expandtabs/join output construction for one bounded storage milestone. Original staging failures and mistaken perf-report command retained; same raw capture recovered offline, no reexecution; users joined/RAM archived. Full43800910729pending, broader objective remains open.\n';p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('2. **R427 baseline complete;');b=s.index('\nR423replaces',a)
s=s[:a]+'''2. **R427/R428 completed; R429 direct bulk-output construction selected.**
   [Normalization CPython](benchmarks/results/2026-11-16-normalization-cpython-checkpoint/README.md)
   warm1.63–1.68× /fresh1.49–1.58×; moving control/IQR retained. One bounded
   [current CPU capture](benchmarks/results/2026-11-16-normalization-attribution/README.md)
   identifies expandtabs94nearest/78leaf of981active samples;193unknown preserved.
   Overlapping iteration/generator/call groups are not removable shares. Original
   capture's offline report command was corrected without guest/capture reexecution;
   original failed terminal and staging conditions stay. Users joined/archive verified.

   **Hypothesis/work removed:** expandtabs per-scalar decoding/check/append and
   already-drained join's iterator/growing byte representation waste bulk work.
   Use existing final PyString storage with measured nativeUTF8 construction and
   bounded copies/fills. Delete both output builders, EnumerateJoinParts and the
   mislocated JoinStrings helper. No new output/scope framework, cache or policy.
   Keep arbitrary iterable drain before validation, native coercion once, error
   indices/order, Unicode scalar columns, CR/LF reset, zero/negative tab widths,
   exact representation bounds, cancellation during measurement/writing, terminal
   admission and retained aliases. Inputs/drain stay funded through output admission.
   Exact final capacity may admit earlier and refunds scratch sooner; identical
   tiny-budget thresholds are not contractual. Update architectural fixture charges
   without relaxing budgets or independent failure/cleanup assertions.

   **Acceptance/completion:** focused string/join/generator/error/cancellation/
   refusal/pending-I/O/retained-result checks on actual11/10, nonincremental Release;
   complete normalization and report allocation + one bounded warm/fresh pair with
   unchanged JSON controls on the quiet VM. Separate removal/allocation/CPU claims;
   retain/refine/remove with adverse observations and regression debt explicit.
   No fixed-percent veto or predicted whole-gap closure. One justified refinement
   is allowed; stop measurement with usable evidence or precise uncertainty.
   Batch new full platform/stress/package checks at the retained delivery boundary;
   do not alter the already-running0a04e253 qualification or repeat R424 checks.
   Continue to generator/operand/collection/frontend milestones from source-backed
   displaced work afterward; this bounded milestone is not the broader objective.
'''+s[b:]
s=s.replace('New full delivery pending; do not requery failed terminal.','New full43800910729 active at0a04e253; do not requery failed terminal.')
p.write_text(s,encoding='utf-8',newline='\n')
print('R428 evidence and originals archived; R429 selected with explicit removal, semantics and bounded completion.')
