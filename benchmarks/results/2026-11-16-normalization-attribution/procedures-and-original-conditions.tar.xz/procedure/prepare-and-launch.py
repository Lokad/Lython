from pathlib import Path
import ast,datetime,hashlib,json,shlex,shutil,subprocess,tarfile
r=Path(__file__).parent;q=r/'profile'
if q.exists():
 assert not(q/'observe-not-before.json').exists();shutil.copytree(q,r/('original-stage-'+str(len(list(r.glob('original-stage-*'))))))
q.mkdir(exist_ok=True);old=r.parent/'calls-current-r420/profile';base=r.parent/'normalization-checkpoint-r427/checkpoint'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();oldid=json.loads((base/'identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision=head+'/frozen810dafdd',runtimeCommit=head,purpose='R428 one bounded complete normalization CPU capture; select an entire iteration/generator/operand or bulk-text displacement, not removable shares from inclusive groups.',coreSHA256={'candidate':oldid['coreSHA256']['candidate']},auxiliaryFiles=oldid['auxiliaryFiles'],catalogSHA256=oldid['catalogSHA256'],qualification='100 internal /2555 public actual11/10;597 source inputs match0a04e253;full43800910729 active. Original failed43797131423 preserved; test-only corrections, unchanged810 core.',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
newroot='normalization-profile-b824-20261116';newunit='lython-b824-normalization-profile-20261116'
for n in ['ops-profile.py','collect.py','run.sh','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('current-calls-b815-20261115',newroot).replace('lython-b815-current-calls-20261115',newunit)
 s=s.replace("'report'","'normalization'").replace('scripts.report-render.format-method.large','scripts.text-normalization.large')
 s=s.replace('count = 128 # Complete report; ~0.7s batches, one bounded capture.','count = 256 # Complete normalization; roughly0.3s batches, one bounded capture.')
 s=s.replace('Committedc023042d/frozen0393331a; R420 current complete method-report call attribution','Committed0a04e253/frozen810dafdd; R428 complete normalization attribution')
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
retire=[]
for directory,path in [('current-calls-b815-20261115','benchmarks/results/2026-11-16-current-call-attribution/observations.tgz'),('compiler-cpython-b821-20261116','benchmarks/results/2026-11-16-compiler-cpython-checkpoint/observations.tgz'),('consume-text-b822-20261116','benchmarks/results/2026-11-16-consuming-text-completion/observations.tgz'),('normalization-cpython-b823-20261116','benchmarks/results/2026-11-16-normalization-cpython-checkpoint/observations.tgz'),('compiler-store-b820-20261116','benchmarks/results/2026-11-16-compiler-instruction-store/observations.tgz'),('finally-prefix-b819-20261116','benchmarks/results/2026-11-16-finally-prefix/observations.tgz')]:
 raw=Path(path).read_bytes();assert subprocess.check_output(['git','show',head+':'+path])==raw
 retire.append(dict(sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),links=1,paths=[directory+'/observations.tgz'],custody=dict(commit=head,archive=path,archiveSHA256=hashlib.sha256(raw).hexdigest(),member=None)))
for directory,path in [('consume-text-b822-20261116','benchmarks/results/2026-11-16-consuming-text-completion/observations.tgz'),('normalization-cpython-b823-20261116','benchmarks/results/2026-11-16-normalization-cpython-checkpoint/observations.tgz')]:
 raw=Path(path).read_bytes();assert subprocess.check_output(['git','show',head+':'+path])==raw
 with tarfile.open(path)as a:data=a.extractfile('confirmation/confirmation.json').read()
 retire.append(dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),links=1,paths=[directory+'/confirmation/confirmation.json'],custody=dict(commit=head,archive=path,archiveSHA256=hashlib.sha256(raw).hexdigest(),member='confirmation/confirmation.json')))
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in ['identity.json','ops-profile.py','collect.py','run.sh']:a.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz')as a:unpacked=sum(m.size for m in a if m.isfile())
files=dict(identity['auxiliaryFiles']);files['Lokad.Lython.dll']=identity['coreSHA256']['candidate']
c=dict(root='/home/lokad/lython-bench-checks/'+newroot,unit=newunit,source='/home/lokad/lython-bench-checks/normalization-cpython-b823-20261116',sourceFiles=files,sourceCatalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=retire,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'launch-command.py').read_text(encoding='utf-8');tree=ast.parse(s);n=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='c'for t in n.targets));lines=s.splitlines(keepends=True);s=''.join(lines[:n.lineno-1])+'c='+repr(c)+'\n'+''.join(lines[n.end_lineno:])
s=s.replace("source/'additional.json'","source/'representative.json'").replace('lython-b815-fixtures','lython-b824-fixtures')
ast.parse(s);(q/'launch-command.py').write_text(s,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -c '+shlex.quote(s)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,done.stdout+done.stderr
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(launchedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=75)).isoformat()),indent=2)+'\n',encoding='utf-8',newline='\n');print(done.stdout.decode('utf-8'))
