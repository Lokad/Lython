using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;
var path=Path.GetFullPath(args[0]);
var a=AssemblyLoadContext.Default.LoadFromAssemblyPath(path);
const BindingFlags flags=BindingFlags.Static|BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic;
var rows=new List<object>();
foreach(var name in new[]{"StringMembers","ReceiverMethods"})
foreach(var field in a.GetType("Lokad.Lython.Runtime.LythonRuntime+"+name)!.GetFields(flags).Where(f=>f.IsStatic&&f.FieldType.Name=="ReceiverMethod"))
{
 var value=field.GetValue(null)!;
 foreach(var operation in value.GetType().GetFields(flags).Select(f=>f.GetValue(value)).OfType<Delegate>())
  rows.Add(new{field=name+"."+field.Name,method=operation.Method.ToString(),declaringType=operation.Method.DeclaringType?.FullName});
}
File.WriteAllText(args[1],JsonSerializer.Serialize(new{coreSHA256=Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(path))),rows},new JsonSerializerOptions{WriteIndented=true})+"\n",new System.Text.UTF8Encoding(false));
