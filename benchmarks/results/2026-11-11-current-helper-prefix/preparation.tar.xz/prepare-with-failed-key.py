from pathlib import Path
import ast, hashlib, json, subprocess, tarfile

repo=Path.cwd(); r=Path(__file__).parent; out=r/'b571'; out.mkdir()
old=r.parent/'captured-text-r224/b569'
prior=json.loads((r.parent/'iteration-returns-r225/b570/identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision='R227 fully qualified4aa2d46d source at evidence HEAD4f571df0; exact corrected9ee7e700 freeze. CachedGREEN42953725339; current all568 source hashes verified. One diagnostic captured-helper CPU/generated-code attribution after R225, not an elapsed source pair.',
    coreSHA256=prior['coreSHA256']['candidate'],auxiliaryFiles=prior['auxiliaryFiles'],performanceQualified=False)
proof={}
for p,h in json.loads((repo/'benchmarks/results/2026-11-11-ordinary-return-consumption/source-identity.json').read_text(encoding='utf-8'))['before']['normalizedSource'].items():
    # The baseline predates R225. Compare current production to its qualified
    # committed revision instead; do not equate different source variants.
    data=(repo/p).read_bytes().replace(b'\r\n',b'\n')
    assert data==subprocess.check_output(['git','show','4aa2d46d:'+p]).replace(b'\r\n',b'\n'),p
    proof[p]=hashlib.sha256(data).hexdigest()
assert len(proof)==568
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
write(out/'identity.json',json.dumps(identity,indent=2)+'\n')
write(out/'catalog.json',(old/'catalog.json').read_text(encoding='utf-8'))
write(r/'source-proof.json',json.dumps(proof,indent=2)+'\n')
write(out/'contract.md','''# R227: remaining captured-helper execution work

R225 changes the path by removing materialized split results from ordinary direct
returns. Existing pre-R225 samples cannot establish current cost shares. One
warmed six-second CPU capture of that same complete script, on qualified4aa/9ee7,
will distinguish remaining VM/result transport from useful text/hash/scalar work.
The existing same-process JIT-listing matcher is reused for the exact prefix/tier/
extent; no native offsets are transferred between source revisions or processes.
Unmatched/ambiguous code remains unattributed. No elapsed comparison or speed claim.

Do not revive the earlier lazy builtin registry: source/history already shows
per-run mutable caches and only12/545 old config samples in builtin initialization.
Do not infer a new numeric cache from sampled allocation associations. Ordinary
binding already borrows operands/reuses compiled storage; no assumed second copy.
Stop with an evidenced complete removable phase and acceptance, or explicitly
record uncertainty and move on. No broad measurement/ownership-audit campaign.

Existing finite90s owner/30s stop/30s margin; persistent maps/stacks/generated code,
full outputs and stable shared-budget checks, joined users/RAM removal/archive.
''')
for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','retrieve.py']:
    s=(old/name).read_text(encoding='utf-8')
    s=s.replace('captured-text-b569-20261111','return-prefix-b571-20261111').replace('lython-b569-captured-text-20261111','lython-b571-return-prefix-20261111')
    if name=='ops-profile.py':
        s=s.replace('if perf_mode:env["DOTNET_PerfMapEnabled"] = "3"','if perf_mode:env["DOTNET_PerfMapEnabled"] = "3"\nenv["DOTNET_JitDisasm"]="ExecuteInstructionPrefix"\nenv["DOTNET_JitStdOutFile"]=str(output/"prefix-jit.txt")')
        s=s.replace('["DOTNET_PerfMapEnabled"]','["DOTNET_PerfMapEnabled","DOTNET_JitDisasm","DOTNET_JitStdOutFile"]')
        s=s.replace("{'DOTNET_PerfMapEnabled'}","{'DOTNET_PerfMapEnabled','DOTNET_JitDisasm','DOTNET_JitStdOutFile'}")
    if name.endswith('.py'): ast.parse(s)
    write(out/name,s)
with tarfile.open(out/'payload.tgz','w:gz')as a:
    for name in ['catalog.json','identity.json','contract.md','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh']:a.add(out/name,arcname=name)
payload=(out/'payload.tgz').read_bytes()
canonical='benchmarks/results/2026-11-11-ordinary-return-consumption/quiet/observations.tgz'
data=(repo/canonical).read_bytes()
assert data==subprocess.check_output(['git','show','HEAD:'+canonical])
retire=[dict(relative='iteration-returns-b570-20261111/observations.tgz',canonical=canonical,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())]
config=dict(root='/home/lokad/lython-bench-checks/return-prefix-b571-20261111',unit='lython-b571-return-prefix-20261111',payloadBytes=len(payload),payloadSHA256=hashlib.sha256(payload).hexdigest(),identity=identity,retire=retire)
s=(old/'launch-command.py').read_text(encoding='utf-8')
node=next(n for n in ast.parse(s).body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='c'for t in n.targets))
lines=s.splitlines();lines[node.lineno-1:node.end_lineno]=['c='+repr(config)];s='\n'.join(lines)+'\n'
s=s.replace('captured-text-b569-20261111','return-prefix-b571-20261111').replace('lython-b569-captured-text-20261111','lython-b571-return-prefix-20261111').replace('lython-b569-fixtures','lython-b571-fixtures')
s=s.replace("source=base/'text-cpython-b568-20261111/candidate'","source=base/'iteration-returns-b570-20261111/candidate'")
s=s.replace("canonicalCommit='6c11b5cf'","canonicalCommit='4f571df0'")
assert 'text-cpython-b568'not in s
ast.parse(s);write(out/'launch-command.py',s)
write(out/'exact-copies.json',json.dumps(retire,indent=2)+'\n')
write(out/'footprint.json',json.dumps(dict(payloadBytes=len(payload),requiredFreeBytes=252*1024*1024+max(128*1024+3*len(payload),128*1024+len(payload))),indent=2)+'\n')
s=(r.parent/'captured-text-r224/launch.py').read_text(encoding='utf-8').replace("r=Path(__file__).parent/'b569'","r=Path(__file__).parent/'b571'")
s=s.replace('captured-text-b569-launch.py','return-prefix-b571-launch.py')
ast.parse(s);write(r/'launch.py',s)
print('Prepared one qualified-source capture and same-process generated-code attribution; no runtime edit or launch yet.')
