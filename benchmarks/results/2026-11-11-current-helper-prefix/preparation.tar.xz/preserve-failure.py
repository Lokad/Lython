from pathlib import Path
import hashlib,json,subprocess,tarfile

r=Path(__file__).parent/'b571'
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,hashlib,json,subprocess,tarfile,shutil
r=Path('/home/lokad/lython-bench-checks/return-prefix-b571-20261111')
with(r.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not(r/'guest-fixtures').exists()
 journal=subprocess.check_output(['journalctl','-u','lython-b571-return-prefix-20261111.service','--no-pager'])
 (r/'journal.txt').write_bytes(journal)
 assert not(r/'failure.tgz').exists()
 with tarfile.open(r/'failure.tgz','w:gz')as a:
  for p in sorted(r.rglob('*')):
   if p.is_file()and p.name not in ['failure.tgz','current-core.dll']and 'candidate'not in p.relative_to(r).parts:a.add(p,arcname=p.relative_to(r).as_posix())
 print(json.dumps(dict(noWorkerStarted=True,noTimedData=True,noRemainingUsers=True,ramRemoved=True,freeBytes=shutil.disk_usage(r).free,archiveSHA256=hashlib.sha256((r/'failure.tgz').read_bytes()).hexdigest())))
'''
done=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
assert done.returncode==0,done.stderr
(r/'failure-receipt.json').write_text(done.stdout,encoding='utf-8')
receipt=json.loads(done.stdout)
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
done=subprocess.run(scp+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/return-prefix-b571-20261111/failure.tgz',str(r/'failure.tgz')],capture_output=True)
assert done.returncode==0,done.stderr
assert hashlib.sha256((r/'failure.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(r/'failure.tgz')as a:
    for m in a.getmembers():
        if m.isfile():a.extractfile(m).read()
print(json.dumps(receipt))
