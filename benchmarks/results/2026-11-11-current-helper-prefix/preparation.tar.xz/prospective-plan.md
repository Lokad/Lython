# Lokad.Lython 0.11.0

Updated 2026-11-11. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial whole-script improvement,
including compilation. Another isolated experiment does not complete the objective.

## Actual delivery status

- **Committed runtime:** `4aa2d46d`, pushed; evidence revision `4f571df0`.
  R222 compiler-fact correction and R225 ordinary direct-return iteration are
  **fully qualified**: cached GREEN [42953725339](https://github.com/Lokad/Lython/actions/runs/42953725339),
  inspected 04:00:37 UTC. Required Windows/Ubuntu Release, actual .NET 11/.NET 10,
  original stress and installed consumers all pass. [Receipt](benchmarks/results/2026-11-11-ordinary-return-consumption/delivery-ci.json).
  No active runtime prototype, local checks or CI qualification. R227 capture is
  running corrected B572: unit `lython-b572-return-prefix-20261111`, PID3535996
  acknowledged04:27:35UTC, owner90/stop30/margin30; observe>=04:30:05UTC.
  B571 is terminal: an invalid environment
  key stopped subprocess creation before any worker/warmup/sample. Original error
  and source archived; all users joined, RAM removed. Do not query B571 again. Never query
  terminal runs again. Later documentation commits leave production unchanged.
- **R225 established benefits/uncertainty:** captured-helper text CLR allocation
  -4.84% both APIs; estimated execution-allowance peak -15.06%, not RSS. Compile
  allocation +0.05-0.16%. Quiet elapsed -1.88..+0.34% is inconclusive; ordinary
  control CPU up to +3.31% remains possible debt. All adverse observations survive.
  Preserve the independent custom-intermediate-result type-error correction.
- **R226 development input qualified:** immutable `0.5.0-dev.68` / `a7e985ed`,
  unchanged Validate bridge, 86 internal/532 public focused checks per actual
  target. Loaded binaries match pinned input; 29 normal-state files unchanged.
  Normal adapter pin stays 0.4. No backend performance/safety or final producer
  certification. [Evidence](benchmarks/results/2026-11-11-regex-development-68/README.md).
- **R223 representative comparison complete:** qualified `4625d83e`/`cb03fd47`,
  six jobs/164.378 seconds/all gates. Ordinary text warm 1.41-1.43x/complete
  1.35-1.40x CPython; captured-helper/counter 2.61-2.62x/2.29-2.37x. Compilation
  separate. Historical source measurements, not HEAD or isolated counter costs.

## Completed milestones

| Delivered | Established result / remaining limits |
| --- | --- |
| Shared compiler facts | Fixes exponential shared-expression traversal; reuses binding/module/scope facts. R222 uses resolved nonlocal targets, preserving global barriers/runtime checks after deletion and handler cleanup. Read-only declarations conservatively defer diagnosis too. No speed claim. |
| Direct UTF-8 formatting/storage | Fully qualified. Allocation -8.67%; controlled elapsed/CPU about 5-8% lower. Original adverse 15.125 ms retained, unexplained. No unchanged replay needed. |
| Native helper returns | Fully qualified. Allocation -19.92% sync/-19.31% async; original elapsed gains diagnostic. No pending delivery checks. |
| Calls/setup/CSV | Shared immutable builtin metadata, reused async startup workers, shared binding/workspace, receiver entry and deferred contexts delivered. CSV shares keys/adopts funded rows after selective reassessment of earlier 6-8% results. Slower arenas/control paths removed; no presumed second row copy/argument packet. |
| R221 lexical writes | Fully qualified `4625`. Existing owner updates slot/namespace once, removing context promotion/name search/duplicate synchronization. Counter CSV/text/report allocation -41.4/47.9/27.5%, quiet warm elapsed about 16-17/19-21/12-15% lower with supporting wider CPU. Control neutrality unresolved; desktop adversity retained. |
| Text/JSON/storage | Native casing/split/formatting/final JSON UTF-8, private iteration, span tuple construction and same-suite jumps delivered. R217 removes 156 net runtime lines; allocation neutral on current short strings, elapsed uncertain. |
| Regex architecture | Core-owned Python UTF-8 contract, consistent provider, effective flags/original windows, current tokens and ownership delivered. R219 removes two per-match coordinate arrays/reservation and caller plumbing; Unicode iteration allocation -17-18%, no CPU claim. Core decoupled; adapter non-packable. |

[Current source-labelled performance](docs/BENCHMARKS.md); all failures, rejected
variants, source pairs and detailed qualification in [experimental history](benchmarks/EXPERIMENTS.md).
Prior plans/source gates preserved under `.git/agent-notes/review-20261031/`.
Do not repeat completed qualification or put experimental history into docs/.

## Prioritized runtime roadmap

**P1: substantial representation and execution simplification.** R224's captured-helper
profile shows VM/transport work (19.21%/9.78% observed leaves), not removable shares.
Call entry is only 5.23%; binding already reuses compiled storage and this helper
creates no lexical context. R225 removes the demonstrated transient-list phase.
Post-delivery source gate: ordinary calls already borrow caller operands and reuse
compiled storage; no second argument packet or unconditional lexical frame remains.
Pure input forwarding and direct local-result publication already exist; the store
continuation preserves awaited-cleanup ordering. No call/frame prototype selected.
Receipt: `.git/agent-notes/review-20261031/iteration-returns-r225/post-delivery-source-gate.json`.
Next: **R227 current captured-helper prefix attribution**, one warmed six-second
capture with same-process JIT listing. R225 materially changes the source path;
pre-R225 samples cannot select current costs. Reuse the existing collector and
exact qualified9ee7 core; no elapsed comparison, runtime prototype or full replay.
Stop with a demonstrated complete removable phase plus semantic acceptance, or
explicit uncertainty. Same-process method/tier/extent matching only; no transferred
native offsets. Preserve all unknowns and wider I/O/reset/protocol distinctions.
Do not revive a lazy builtin registry: prior config CPU has only12/545 builtin
samples and mutable per-run descriptor/owner caches. No new capture for that
unchanged question. Private selection/source proof/commands live under
`.git/agent-notes/review-20261031/return-prefix-r227/`.

Hypothesis: a repeated operation crosses more frame/result boundaries than its
semantics need. Select a redesign only after identifying a real repeated phase;
remove its displaced implementation at completion. Fewer fields alone is not the
criterion: R204 packet reconstruction, R214 target mutation and earlier call
arenas retained necessary binding and measured adversity. Do not revive them
unchanged or add another side path. Stop the source gate on no removable phase;
record the negative finding and proceed to the next boundary. One targeted six-
second capture is permitted only for a concrete changed-path question unanswered
by source/existing evidence; no unchanged R225 retiming or broad audit campaign.

Affected scripts: captured CSV/text helpers, class report, ordinary text/JSON
controls. Acceptance: defaults/keywords, descriptors, closures, active exceptions,
evaluation order, generators, genuine suspension, diagnostics, managed stack
admission and awaited cleanup remain correct. Current tokens and terminal shared-
budget refusal stay effective; retain aliases/results and prove budget reuse.
Record compile/retained-capacity costs and one bounded before/after with unchanged
controls. End with retain/refine/withdraw and explicit regression debt. No partial
preparatory abstraction alone; no predicted speedup from sample shares.

| Later boundary | Selection/completion criteria |
| --- | --- |
| Scalar/operand representation | Coherent producers/consumers, exact promotion, identity/aliases/hooks/projection; remove displaced transport rather than adding a sidecar. Earlier scalar shares modest; R176/R188 allocation alone did not justify dispatch complexity. |
| Per-record construction | CSV already shares keys/adopts funded capacity. Native dictionaries/live namespaces are real storage users. Find a remaining parse/construction/copy boundary. Preserve mutable headers/order/duplicates/protocols/retention and reentrant refusal. |
| Remaining text conversions | Casing/split/formatting/JSON already write final UTF-8; .NET 11 numbers use UTF-8 TryFormat, .NET 10 an admitted char bridge. Remove an observed intermediate phase; preserve Unicode/context/expansion/hooks/errors/cancellation. |
| Frontend | Shared facts, precedence parsing, compact declarations/direct children delivered. Distinct visitors retain different facts. Select demonstrated repeated analysis; preserve diagnostics/scoping. Import execution already uses the executable engine. |

For each selected milestone: hypothesis, eliminated work/storage/functions,
affected whole scripts, semantic gates, bounded comparison and debt decision.
Temporary setbacks are acceptable during justified redesign with an explicit
completion milestone. Fixed percentages inform decisions; they do not veto them.

**P2: representative CPython refresh at a material checkpoint.** CSV/text rows
retain `e543`, JSON/report `e122`, text refresh `4625`. Refresh affected scripts
after material retained work or a fairness gap, not every patch. Separate compile,
warm/startup and I/O/cleanup. Current warm includes mediated RAM I/O/output checks/
prior-result cleanup, excludes reset/protocol/final caches. Compilation includes
construction/disposal; independent medians need not add. Pending I/O, RSS and
embedding tail latency remain unqualified. CPython is the primary baseline.

## Independent regex track

Core/contract development continues independently of producer publication. Test
providers, immutable development producers and adapter-local bridges are allowed.
R226 finds no relevant new public signature to streamline the bridge. Missing
capabilities defer only affected final adapter qualification:

1. Single-match working ownership independent of retained-result ownership.
2. Native UTF-8 group-name enumeration; native lookup already exists.
3. Token-independent cursor creation with cancellable preparation; per-move tokens
   do not establish interruption during creation/preparation.

When native APIs arrive, remove displaced DetailedData/conversion plumbing and
qualify an immutable released input. Preserve Match/FullMatch alternative selection,
captures, windows, scalar/byte offsets, effective flags, tokens, caches and funding;
filtering Search is not equivalent. Contract/semantic validation, actual backend
performance, safety and SizeOf assessment remain distinct. Normal 0.4 unchanged;
no core dependency, dialect fallback or new ownership infrastructure.

## Iteration and lasting constraints

Timeouts, unstable unchanged controls and inconclusive observations establish
uncertainty. Permit bounded justified confirmation/refinement/measurement correction;
retain original failures/adversity. Size quiet runs for usable observations.
Distinguish simplification/allocation/CPU/accounted capacity/latency claims.

Focused Release correctness/cancellation/ownership during iteration; no overlapping
local build/test/timing. Nonincremental build after timestamped source restoration.
Batch Windows/Ubuntu, actual .NET 11/.NET 10, original stress and installed Release
consumers at coherent boundaries; keep working meanwhile. Active CI queries >=5min
apart; cache terminals/never query completed runs. Only core Release packages via
tools/pack.ps1 into artifacts/nuget/. Publication/tagging postponed.

Fully managed/memory-safe: no unsafe/Unsafe APIs/pointers/PInvoke/native stack
probing. Preserve managed stack admission, capabilities, current-token checks in
actual work, cycle detection, XML depth, checked representation bounds/bounded I/O.
No fuel/quotas, independent caps/hidden allowances, guest tracing/root inventories,
weak reclamation/forced GC, admission retries or abandoned users.

Borrowed shared allowance funds major capacity/replacement overlap, results/aliases/
caches/pending users until awaited cleanup. Scope creation reserves zero. First
refusal fails the command with structured origin despite guest suppression/finally
returns; native cleanup/refunds remain available. Guest MemoryError stays catchable.
Long streaming uses bounded host commands. Paths preserve LythonPathRequest/original
text/contained Cwd and host component resolution; never delete to emulate replacement.

## VM/evidence boundary

lokad@20.166.121.73; key ~/.ssh/id_lython-bench.pem. R227/B571 failed before worker creation; original conditions preserved.
Corrected B572 is acknowledged under its finite owner; no collection overlap.
B572 setup free265,482,240B; no additional retirement or source/settings change. Fresh idle lease/core/aux hashes pass;
setup free265,666,560B. Only exact committed B570 compressed archive retired after
path/UID/nlink/size/SHA proof; its remote path is now off limits. Canonical bytes
remain tracked. All previous runs are terminal/cached; no repeat queries.
B570/all earlier runs terminal/cached; never re-query. Final free 262,049,792 B,
setup 266,133,504 B; fixed 240 MiB floor/12 MiB setup headroom. Qualified c271/9dadd
images unchanged; f6c8/9ee7 measured images retained. Persistent canonical archives
preserve raw/source/identity evidence. New work needs a fresh idle lease/identity/
disk proof. Retired paths/aliases are off limits: consult the preserved prior plan
and R225 retirement receipts, never replay stale staging recipes.
