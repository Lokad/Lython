from pathlib import Path
import ast,hashlib,json,tarfile

r=Path(__file__).parent;old=r/'b571';out=r/'b572';out.mkdir()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
for name in ['catalog.json','identity.json','contract.md','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','retrieve.py']:
    s=(old/name).read_text(encoding='utf-8').replace('return-prefix-b571-20261111','return-prefix-b572-20261111').replace('lython-b571-return-prefix-20261111','lython-b572-return-prefix-20261111')
    if name=='ops-profile.py':
        failed='env["DOTNET_PerfMapEnabled","DOTNET_JitDisasm","DOTNET_JitStdOutFile"] = "3"'
        assert failed in s
        s=s.replace(failed,'env["DOTNET_PerfMapEnabled"] = "3"')
        assert 'for k in ["DOTNET_PerfMapEnabled","DOTNET_JitDisasm","DOTNET_JitStdOutFile"]'in s
        tree=ast.parse(s)
        assert not any(isinstance(n,ast.Subscript)and isinstance(n.value,ast.Name)and n.value.id=='env'and isinstance(n.slice,ast.Tuple)for n in ast.walk(tree))
    if name.endswith('.py'):ast.parse(s)
    write(out/name,s)
with tarfile.open(out/'payload.tgz','w:gz')as a:
    for name in ['catalog.json','identity.json','contract.md','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh']:a.add(out/name,arcname=name)
payload=(out/'payload.tgz').read_bytes()
identity=json.loads((out/'identity.json').read_text(encoding='utf-8'))
config=dict(root='/home/lokad/lython-bench-checks/return-prefix-b572-20261111',unit='lython-b572-return-prefix-20261111',payloadBytes=len(payload),payloadSHA256=hashlib.sha256(payload).hexdigest(),identity=identity,retire=[])
s=(old/'launch-command.py').read_text(encoding='utf-8')
node=next(n for n in ast.parse(s).body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='c'for t in n.targets))
lines=s.splitlines();lines[node.lineno-1:node.end_lineno]=['c='+repr(config)];s='\n'.join(lines)+'\n'
s=s.replace('return-prefix-b571-20261111','return-prefix-b572-20261111').replace('lython-b571-return-prefix-20261111','lython-b572-return-prefix-20261111').replace('lython-b571-fixtures','lython-b572-fixtures')
assert 'iteration-returns-b570-20261111/observations.tgz'not in s
ast.parse(s);write(out/'launch-command.py',s)
write(out/'exact-copies.json','[]\n')
write(out/'footprint.json',json.dumps(dict(payloadBytes=len(payload),requiredFreeBytes=252*1024*1024+max(128*1024+3*len(payload),128*1024+len(payload))),indent=2)+'\n')
s=(r/'launch.py').read_text(encoding='utf-8').replace("/'b571'","/'b572'").replace('return-prefix-b571-launch.py','return-prefix-b572-launch.py')
ast.parse(s);write(r/'launch-corrected.py',s)
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s=s.replace('running: acknowledged systemd unit `lython-b571-return-prefix-20261111`, PID\n  3535368 at04:23:15UTC. Owner90/stop30/margin30; observe not before04:25:45UTC. Never query','prepared for corrected B572 launch. B571 is terminal: an invalid environment\n  key stopped subprocess creation before any worker/warmup/sample. Original error\n  and source archived; all users joined, RAM removed. Do not query B571 again. Never query')
s=s.replace('R227/B571 active under its\nfinite owner; do not overlap collections.','R227/B571 failed before worker creation; original conditions preserved.\nCorrected B572 needs its own acknowledged finite owner; no collection overlap.')
p.write_text(s,encoding='utf-8')
print('Corrected environment only; original input/source/runtime/settings unchanged. No extra retirement.')
