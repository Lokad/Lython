from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
c={'root': '/home/lokad/lython-bench-checks/return-prefix-b572-20261111', 'unit': 'lython-b572-return-prefix-20261111', 'payloadBytes': 10631, 'payloadSHA256': 'f69539c58390f180a211f85505a4db933b89f9b5fe385f3ef0affe764c3eb9fc', 'identity': {'sourceRevision': 'R227 fully qualified4aa2d46d source at evidence HEAD4f571df0; exact corrected9ee7e700 freeze. CachedGREEN42953725339; current all568 source hashes verified. One diagnostic captured-helper CPU/generated-code attribution after R225, not an elapsed source pair.', 'coreSHA256': '9ee7e700580399ff80d803f0a7535d2de5ff0f10d35a736370f457383be1b67f', 'auxiliaryFiles': {'Azure.Core.dll': '1d6df436afdc73c30d476be938f6513c90ef8fc884a7bae280091a9bed0a5490', 'Azure.Identity.dll': '31574a3d35ffeb0e25a00ebb317937222fe5283b91af608613f2e3bf0f26c50a', 'BenchmarkDotNet.Annotations.dll': '97974c60500f53a3c7d142088b22d815aae7aac729de69f4b497132cc436594f', 'BenchmarkDotNet.dll': '599ded314fe77dbc17318557e787cf660c1fcb0d69be39994ea462ca95745896', 'CommandLine.dll': '8a55501cd1a1590a4bd93a17c6fdd2c01a0ed5bff1aea9036bdc78d98c9a3fad', 'deniszykov.WebSocketListener.dll': 'c86cfb93e32192ae12fb1a132b4ae785a7d2f325e8583c03c99abf8e832d25d6', 'Dia2Lib.dll': '6c4cac68010fe032218efe5e9fcf46eef9f77bfaa5f3bd33f03c5ff77d5a8fac', 'Gee.External.Capstone.dll': '6dfda67784598de9677173b89d0692593935f1a4024d36040c95dea48c1b5965', 'Iced.dll': 'f058c01321b4cdfc9b9151879e88e59571c8d0ba176fbcf95bc936a8f3d073ed', 'Lokad.Lython.Benchmarks.deps.json': 'b47f293f779ce46eefa92c6eb775842efe363be212c35bf7d155d0b89734d450', 'Lokad.Lython.Benchmarks.dll': 'fec79afdb8425f18aa962d5ff9a3e51ae52f519072ea9d9db8ab69a0c52b69a6', 'Lokad.Lython.Benchmarks.runtimeconfig.json': 'c2ecf2430d6785354d9099b35eef9d6ac3d72f2089dc3dc9fd723558265b83d0', 'Lokad.Lython.Utf8Regex.dll': '9f7282ade883f103956efaf7e46182f7705fb7675f1f46963b9c42ae5aae7f94', 'Lokad.Utf8Regex.dll': 'af5fb1e550cf23559bc7e26ef3d895b45e5ef98d57bcf46b414785a6e24cc857', 'Lokad.Utf8Regex.PythonRe.dll': '96e45b20c1db361a9b3b94bd557405b413510801bdb1488ae5b15d6aae7aedfe', 'Microsoft.Bcl.AsyncInterfaces.dll': 'bf58b47923b2f520c766ca905f68a1a65d217c4d828f05db538c41129cacf9d9', 'Microsoft.CodeAnalysis.CSharp.dll': '1af1de8a162d2312eb2f6b781f5edbe8cec7d5cd268c7e4de24396225e54260f', 'Microsoft.CodeAnalysis.dll': '42c9ce7891470f430267e2dc02d03571f9d046a7e7e121107754bee58d344613', 'Microsoft.Diagnostics.FastSerialization.dll': 'e5bdad179ce97180646f37f357cb7b449f5baaf76f185eb09510eeafc5b773e1', 'Microsoft.Diagnostics.NETCore.Client.dll': 'e2cc9e1f6c97b3c4ee45ebabaa92408eb9b2fc81cb08ceeb342fe48bf79db15f', 'Microsoft.Diagnostics.Runtime.dll': '52d5f113180bb0f70b1a9b10608aef93b187364ac689885d2d3c734102d850a2', 'Microsoft.Diagnostics.Tracing.TraceEvent.dll': '92401392ce1887c3483a3c0085e6cc3656ee39da1be539943096ebabbad6ea21', 'Microsoft.Identity.Client.dll': '5795027e9ae95eececb310a4fed3c502bb368039d186ab0884f64b7792b84717', 'Microsoft.Identity.Client.Extensions.Msal.dll': '07109a2f30df782300077a567ade47cbd0a0502c75cd7c8a62192f7d64bb004e', 'Microsoft.IdentityModel.Abstractions.dll': '24e97b54b6b5c234a124a336757e3116617ac6c30b655cdae74517dc2ecb5746', 'Perfolizer.dll': '4a5508174e2b90a651a29e1de0d2ad88236daaaae01070cd6fc8ca3c36beaa36', 'Pragmastat.dll': '7217e206e47de8a0335f58513019d5805a6e52ca2e8f127e2cc3944f1742bb2e', 'System.ClientModel.dll': 'dec5e22b71a1685c5e6e97cd28b629f0aa6703fb87b6950df28e79fc1804290c', 'System.Memory.Data.dll': '2c1035b0106dbb2de7913d151e06071ed617bb58bbb3d6cd46a2dd0f6a03617b', 'System.Security.Cryptography.ProtectedData.dll': '80566f0839ece5946e66bf9f00d723e59e371ba1341a18e00c7c7a7c49298e1d', 'TraceReloggerLib.dll': '6830c0f1d3f3c17719181e73dd5cfa8ccbb3f3c575329d2120576545103467b5'}, 'performanceQualified': False}, 'retire': []}
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(c['root']);source=base/'iteration-returns-b570-20261111/candidate';fixture=root/'guest-fixtures'
assert root.parent==base
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not fixture.exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 payload=sys.stdin.buffer.read(c['payloadBytes']+1);assert len(payload)==c['payloadBytes'] and hashlib.sha256(payload).hexdigest()==c['payloadSHA256']
 for name,digest in {**c['identity']['auxiliaryFiles'],'Lokad.Lython.dll':c['identity']['coreSHA256']}.items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest,name
 protected=[(base/'json-string-b565-20261111/reference/Lokad.Lython.dll','c27160d53d66489976b181fb425b2f46c927fa85156433b80dc6f5477a3e5506'),(base/'json-cpython-b566-20261111/candidate/Lokad.Lython.dll','9dadd59bd75528186c66a9a95e2efcf411e611e0ccaa718ff38c4facdb191e33')]
 for p,h in protected:assert hashlib.sha256(p.read_bytes()).hexdigest()==h
 before=shutil.disk_usage(base).free;retired=[]
 for item in c['retire']:
  target=base/item['relative'];info=target.lstat()
  assert target.resolve()==target and target.is_relative_to(base) and stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid() and info.st_nlink==1
  assert info.st_size==item['bytes'] and hashlib.sha256(target.read_bytes()).hexdigest()==item['sha256']
  retired.append({**item,'allocatedBytes':info.st_blocks*512})
 required=(240+12)*1024*1024+max(128*1024+3*c['payloadBytes'],128*1024+len(payload))
 assert before+sum(item['allocatedBytes']for item in retired)>required,(before,required)
 for item in retired:(base/item['relative']).unlink()
 for p,h in protected:assert hashlib.sha256(p.read_bytes()).hexdigest()==h
 assert shutil.disk_usage(base).free>required
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 (root/'space-recovery.json').write_text(json.dumps(dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,retiredFiles=retired,canonicalCommit='4f571df0',fixedFloorBytes=240*1024*1024,setupHeadroomBytes=12*1024*1024),indent=2)+'\n')
 os.link(source/'Lokad.Lython.dll',root/'current-core.dll');shutil.copytree(source,root/'candidate',copy_function=os.link)
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b572-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,captures=1,ownerSeconds=90,stopSeconds=30,marginSeconds=30,performanceQualified=False)
 assert setup['freeBytes']>(240+12)*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit='+c['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=90','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show',c['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert 'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
