from pathlib import Path
import datetime,json,shlex,subprocess

r=Path(__file__).parent/'b571'
assert not (r/'observe-not-before.json').exists()
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/return-prefix-b571-launch.py'
script=(r/'launch-command.py').read_bytes()
code='from pathlib import Path;import sys;p=Path('+repr(stage)+');assert not p.exists();p.write_bytes(sys.stdin.buffer.read())'
done=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=script,capture_output=True)
assert done.returncode==0,done.stderr
done=subprocess.run(ssh+['python3 '+stage],input=(r/'payload.tgz').read_bytes(),capture_output=True)
(r/'launch.stdout').write_bytes(done.stdout);(r/'launch.stderr').write_bytes(done.stderr)
assert done.returncode==0,done.stderr.decode('utf-8')
assert b'ActiveState=active' in done.stdout and b'MainPID=0' not in done.stdout
now=datetime.datetime.now(datetime.timezone.utc)
bound=dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=150)).isoformat(),ownerSeconds=90,stopSeconds=30,marginSeconds=30)
(r/'observe-not-before.json').write_text(json.dumps(bound,indent=2)+'\n',encoding='utf-8')
print(done.stdout.decode('utf-8'));print(json.dumps(bound))
