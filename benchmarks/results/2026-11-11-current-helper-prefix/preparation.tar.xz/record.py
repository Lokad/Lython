from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile

repo=Path.cwd();r=Path(__file__).parent;b=r/'b572'
out=repo/'benchmarks/results/2026-11-11-current-helper-prefix';out.mkdir()
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
receipt=load(b/'archive-receipt.json');a=load(r/'attribution.json')
assert receipt['allWorkersJoined']and receipt['guestFixturesRemoved']and receipt['quietBeforeAndAfter']
assert hashlib.sha256((b/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
assert a['samples']==1166 and a['unknown']==51 and a['stackPresence']['materializingSplitCore']==0
g=load(r/'generated-code-attribution.json')['ExecuteInstructionPrefix']
assert g['status']=='Unique method/tier/size match'and g['codeBytes']==12586 and g['selfSamples']==274
assert not subprocess.check_output(['git','diff','4aa2d46d','--','src/Lokad.Lython'])
for name in ['attribution.json','generated-code-attribution.json','source-proof.json']:shutil.copyfile(r/name,out/name)
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','identity.json','footprint.json','observe-not-before.json']:shutil.copyfile(b/name,out/name)
shutil.copyfile(b/'retrieved/space-recovery.json',out/'space-recovery.json')
(out/'failed-start').mkdir()
for name in ['failure.tgz','failure-receipt.json','terminal-status.json','failure-inspection.stdout','failure-inspection.stderr']:shutil.copyfile(r/'b571'/name,out/'failed-start'/name)
decision=dict(selected='R228: explicit-terminator dispatch, removing the generic per-instruction jumped state/test and implicit end-of-array completion. Preserve the existing single engine and pause/cleanup protocol.',
    established=['The same-process Tier1 listing separates the loop-bound block (50 samples), instruction fetch/refusal/cancellation block (44), switch-selection block (32) and generic jumped test (7). Each includes useful work and sample skid; these are not removable shares.',
        'Compiler Linearize already emits Complete for unterminated blocks, including empty ones; other terminators explicitly return, jump or throw. The engine still treats array end as a second implicit successful completion.',
        'Ordinary operations set/check a generic jumped flag even though only control operations and exception routes can take a target. Taken routes can reenter dispatch directly; actual pending cleanup must still preserve whether advancement is required.',
        'VM self includes inlined useful whitespace scanning. The23.5%method share does not justify predicting a dispatch speedup or treating the method as pure overhead.'],
    acceptance='Complete all module/function/import/class/generator paths; retain returned-list semantics, branch/self-loop targets, finally/with and handler cleanup, pending host/protocol operations, source spans/current instructions until awaited disposal, active cancellation/first memory refusal, aliases and allowance reuse. No helper/backend/mode or new mutable state.',
    comparison='One bounded existing six-complete-script before/after across warm sync/async and compilation, with unchanged controls. Exact qualified9ee7 baseline; same common worker/auxiliary images. Quiet confirmation only if source/desktop evidence justifies it; retain all original adversity.',
    stop='Retain/refine/withdraw the complete dispatch change, removing all introduced-only machinery on withdrawal. An isolated instruction tweak alone does not complete the whole-script performance objective.')
(out/'source-gate.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
with tarfile.open(out/'preparation.tar.xz','w:xz')as t:
    for p in sorted(r.rglob('*')):
        if p.is_file()and 'retrieved'not in p.parts and '__pycache__'not in p.parts and p.suffix not in ['.tgz','.xz']:t.add(p,arcname=p.relative_to(r).as_posix())
    for p in ['src/Lokad.Lython/Frontend/ExecutableStackLayout.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Results.cs']:
        t.add(repo/p,arcname='qualified-source/'+p)
    t.add(repo/'PLAN.md',arcname='prospective-plan.md')
manifest={}
for name in ['observations.tgz','preparation.tar.xz','failed-start/failure.tgz']:
    p=out/name
    with tarfile.open(p)as t:
        for m in t.getmembers():
            if m.isfile():t.extractfile(m).read()
    manifest[name]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(out/'archive-identity.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
(out/'README.md').write_text('''# R227 — remaining captured-helper prefix work

2026-11-11, fully qualified4aa2d46d / frozen9ee7e700, all568 production source
hashes equal evidence HEAD4f571df0. Same captured-helper/counter complete text
script; R225 changed its path, so prior samples could not select current costs.
One6.079s wall capture /5.934worker execution seconds /5.87guest CPU seconds on
the existing quiet F4as_v7/Ubuntu24.04.4/.NET11RC3. Normal GC/tiering; diagnostic
perf maps and same-process prefix JIT listing. No elapsed source pair or CPU gain.

**1,166guest samples,51unknown(4.37%)**, no ambiguous mapped leaves/frames. VM
self274(23.50%), operand/result92(7.89%), text115(9.86%), dictionary/hash112(9.61%),
call entry50(4.29%). Categories include useful/inlined work; ancestry overlaps.
Zero stacks contain materializingSplitCore;102contain private preparation,
consistent with the delivered construction removal. [All leaves/coverage](attribution.json).

A unique method/tier/12,586-byte extent matches all274prefix self samples in the
same process. Loop-bound block50samples, fetch/refusal/cancellation44, switch32,
generic jumped-test7. The prefix also inlines real Unicode/whitespace scanning.
These blocks contain useful work and sampling skid; counts are not removable CPU
or a speedup forecast. No native offsets are transferred across runs/revisions.
[Exact blocks/listing match](generated-code-attribution.json).

Source identifies two redundant completion mechanisms: the compiler already emits
explicit Complete/return/jump/throw terminators, while the loop also treats array
end as implicit success. Ordinary operations additionally carry a generic jumped
flag used only by control/exception routes. R228 will consolidate completion and
direct taken routes back to dispatch, keeping the same engine and actual pending
disposal advancement protocol. No new frame/mode/packet. All cancellation/refusal,
protected/generator/suspension and ownership semantics remain acceptance criteria.
[Prospective source gate](source-gate.json),[qualified source hashes](source-proof.json).

Earlier builtin evidence is reused:12/545 old config samples and mutable per-run
type/descriptor caches do not justify a new lazy registry. No unchanged builtin
profile, numeric cache, broad ownership audit or full delivery replay is selected.
The overall whole-script objective remains open.

The first launch failed before worker creation: a broad metadata replacement
introduced a tuple environment key. No warmup/sample ran; original source/error
and joined RAM cleanup survive under [failed-start](failed-start/failure-receipt.json).
The corrected launch changed only that key; no runtime/source/workload/settings
change or timed restart. One early local observation was refused by its time guard
before SSH; the successful terminal observation occurred after the original bound.

All source/output/budget/quiet/Closed/zeroexit/join/map-retirement/RAM-removal and
archive-under-lease/localSHA gates pass.90sowner/30stop/30margin, terminalcached,
no remaining users or fixtures. Only exact committed B570 compressed bytes were
retired after fresh path/UID/link/size/SHA proof; that path is off limits. Protected
qualified images unchanged. Fixed240MiBfloor/12MiBsetupheadroom retained; exact final
free space was not recorded, floor assertions passed. No publication/pin change.
[Receipt](archive-receipt.json),[raw core/maps/stacks/listing](observations.tgz),
[source/conditions/commands](preparation.tar.xz),[archive hashes](archive-identity.json).
''',encoding='utf-8')
print(json.dumps(manifest))
