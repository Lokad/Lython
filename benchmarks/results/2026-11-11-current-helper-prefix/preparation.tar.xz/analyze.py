from pathlib import Path
import bisect, collections, datetime, hashlib, json, re, shutil, subprocess, tarfile

repo=Path.cwd();root=Path(__file__).parent;b=root/'b572';p=b/'retrieved/profiles/text-warm'
out=root
receipt=json.loads((b/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert hashlib.sha256((b/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
record=json.loads((p/'record.json').read_text(encoding='utf-8'))
original=json.loads((p/'guest-cpu-leaves.json').read_text(encoding='utf-8'))
entries=[]
for line in (p/'perf.map').read_text(encoding='utf-8').splitlines():
    start,size,name=line.split(' ',2);entries.append((int(start,16),int(size,16),name))
duplicate_starts=sum(n>1 for n in collections.Counter(a for a,_,_ in entries).values())
entries=sorted(set(entries));starts=[a for a,_,_ in entries];ends=[]
for a,n,_ in entries:ends.append(max(a+n,ends[-1] if ends else 0))
def resolve(address,native):
    i=bisect.bisect_right(starts,address)-1;names=set()
    while i>=0 and ends[i]>address:
        a,n,name=entries[i]
        if address<a+n:names.add(name)
        i-=1
    if len(names)==1:return next(iter(names)),False
    if names:return '<ambiguous mapped ranges>',True
    return native,False
samples=[];frames=[];tid=None;guest=set(record['guestTids'])
def finish():
    if tid in guest and frames:samples.append(frames.copy())
for line in (p/'perf-stacks.txt').read_text(encoding='utf-8').splitlines():
    h=re.fullmatch(r'(\d+)/(\d+)\s*',line)
    if h:finish();tid=h[2];frames=[]
    elif m:=re.match(r'\s+([0-9a-f]+)\s+(.*)',line):frames.append(resolve(int(m[1],16),m[2]))
finish()
counts=collections.Counter(sample[0][0] for sample in samples)
assert len(samples)==original['samples'] and counts['[unknown]']==original['unknown']
rules=[('VM instruction prefix',['::ExecuteInstructionPrefix']),
('Operand/result transport',['::CompleteLocalResult','::ExecuteStackTransfer','::ExecuteInputInstruction','ExecutableValueStorage']),
('Native dictionary/hash',['::TryExecuteDictionaryAccumulation','::TryAccumulateWithoutAdmission','::ComputeStructuralHashCode','::FindNativeIndex']),
('Whitespace/casing',['PyStringOps::']),
('Call binding/entry',['::BindPositionalFunctionArguments','::BeginBoundCall','::BeginPendingCall']),
('Native call selection',['::TryExecuteNativeCall','::TryLoadDirectCallReceiver','::EvaluateNativeReturn']),
('Scalar arithmetic',['::AddExactIntegers','PyNumberOps::']),
('Monitor locking',['System.Threading.Monitor::']),('Unmapped',['[unknown]']),('Ambiguous map',['<ambiguous mapped ranges>'])]
groups=collections.Counter()
for name,n in counts.items():groups[next((label for label,needles in rules if any(s in name for s in needles)),'Other mapped leaves')]+=n
materializing=sum(any('PyStringOps::SplitCore' in frame[0] for frame in sample) for sample in samples)
private=sum(any('PrepareCasedWhitespaceIteration' in frame[0] for frame in sample) for sample in samples)
result=dict(sourceRevision='Qualified4aa2d46d/frozen9ee7e700, source-equivalent to4f571df0. Current captured-helper/counter shape after R225; diagnostic JIT/perf maps, no elapsed source pair.',
    samples=len(samples),unknown=counts['[unknown]'],ambiguousLeafSamples=counts['<ambiguous mapped ranges>'],ambiguousFrames=sum(a for s in samples for _,a in s),duplicateMapStartGroups=duplicate_starts,
    wallCaptureSeconds=(datetime.datetime.fromisoformat(record['stoppedUtc'])-datetime.datetime.fromisoformat(record['startedUtc'])).total_seconds(),workerExecutionSeconds=receipt['capturedSeconds'],selectedThreadCPUSeconds=original['cpuSeconds'],allThreadCPU=record['threadCpuSeconds'],
    groups=[dict(name=k,samples=n,percent=100*n/len(samples))for k,n in groups.most_common()],allLeaves=counts.most_common(),
    stackPresence=dict(materializingSplitCore=materializing,privateCasedWhitespacePreparation=private),
    limits='Innermost groups include useful/inlined work and wider worker checks/reset/protocol; stack presence is overlapping ancestry, not removable CPU. All-containing-range mapping keeps stub aliases explicit; caller return addresses unadjusted. No elapsed comparison or speedup forecast.')
(out/'attribution.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items()if k not in ['allLeaves','allThreadCPU']},indent=2))
