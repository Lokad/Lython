# R227: remaining captured-helper execution work

R225 changes the path by removing materialized split results from ordinary direct
returns. Existing pre-R225 samples cannot establish current cost shares. One
warmed six-second CPU capture of that same complete script, on qualified4aa/9ee7,
will distinguish remaining VM/result transport from useful text/hash/scalar work.
The existing same-process JIT-listing matcher is reused for the exact prefix/tier/
extent; no native offsets are transferred between source revisions or processes.
Unmatched/ambiguous code remains unattributed. No elapsed comparison or speed claim.

Do not revive the earlier lazy builtin registry: source/history already shows
per-run mutable caches and only12/545 old config samples in builtin initialization.
Do not infer a new numeric cache from sampled allocation associations. Ordinary
binding already borrows operands/reuses compiled storage; no assumed second copy.
Stop with an evidenced complete removable phase and acceptance, or explicitly
record uncertainty and move on. No broad measurement/ownership-audit campaign.

Existing finite90s owner/30s stop/30s margin; persistent maps/stacks/generated code,
full outputs and stable shared-budget checks, joined users/RAM removal/archive.
