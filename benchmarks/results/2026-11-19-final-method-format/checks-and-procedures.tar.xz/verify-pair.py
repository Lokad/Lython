from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess

lab = Path(__file__).resolve().parent
prior = lab.parent / "definition-record-construction-r604"
work = Path(".git/agent-worktrees/final-method-format-r609")
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
source_files = load(prior / "frozen-identity.json")["images"]["candidate"]
auxiliary = prior / "frozen/candidate"
assert len(source_files) == 32 and {name: sha(auxiliary / name) for name in source_files} == source_files
reference = subprocess.check_output(["git", "rev-parse", "e93356adc"], text=True).strip()
assert not subprocess.check_output(["git","diff","--name-only","c5ff4542d",reference,"--","src","tests"])
candidate = subprocess.check_output(["git", "-C", str(work), "rev-parse", "HEAD"], text=True).strip()
assert reference.startswith("e93356adc") and candidate.startswith("3744d19c")
assert not subprocess.check_output(["git", "-C", str(work), "status", "--porcelain"])
assert not subprocess.check_output(["git", "diff", "--name-only", "2409f0596", candidate, "--",
    "benchmarks/Lokad.Lython.Benchmarks", "benchmarks/cpython-worker.py", "src/Lokad.Lython.Utf8Regex"])
(lab / "measured-source.patch").write_bytes(subprocess.check_output(
    ["git", "diff", "--binary", reference, candidate, "--", "src", "tests"]))
catalog = lab / "catalog.json"
data = load(prior / "catalog.json")
base = {case["id"]: case for case in data["cases"]}
forward = base["scripts.report-forwarding.expanded"]
positional = base["calls.positional.large"]
scripts = {case["id"]:case for case in load(lab.parent / "prepared-format-selectors-r598/catalog.json")["cases"]}
named = next(case for case in load(lab.parent / "borrowed-format-packet-r574/method-format-catalog.json")["cases"]
             if case["id"] == "strings.named-format-report.medium")
direct = dict(forward)
direct["id"] = "scripts.report-forwarding.positional-format"
source = direct["source"]
assert source.count("def line(label, **fields):") == 1 and source.count("target.write(line(label, **fields))") == 1
source = source.replace("def line(label, **fields):", "def line(label, fields):")
source = source.replace("target.write(line(label, **fields))", "target.write(line(label, fields))")
direct["source"] = source
direct["sourceSha256"] = hashlib.sha256(source.encode("utf-8")).hexdigest()
direct["sourceUtf8Bytes"] = len(source.encode("utf-8"))
data["cases"] = [forward, direct, positional, named, scripts["scripts.report-render.format-selectors.large"],
                 scripts["scripts.report-render.format-method.large"], scripts["scripts.report-render.large"]]
catalog.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
cases = data["cases"]
assert len({case["id"] for case in cases})==7

core = "Lokad.Lython.dll"
worker = "Lokad.Lython.Benchmarks.dll"
images = {}
def run(args, output):
    with (lab / output).open("wb") as log:
        subprocess.run(args, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=120, check=True)
for role, directory in (("reference", Path.cwd()), ("candidate", work)):
    image = lab / "frozen" / role
    image.mkdir(parents=True, exist_ok=True)
    for name, digest in source_files.items():
        source = directory / "src/Lokad.Lython/bin/Release/net11.0" / core if name == core and role == "candidate" else auxiliary / name
        if not (image / name).exists():
            shutil.copyfile(source, image / name)
        assert sha(source) == sha(image / name)
        if name != core:
            assert sha(image / name) == digest
    for source in auxiliary.glob("ValidatedAllocation.*"):
        shutil.copyfile(source, image / source.name)
    images[role] = {name: sha(image / name) for name in source_files}
    run([dotnet, image / worker, "--compare", "verify", "--catalog", catalog, "--dotnet", dotnet,
         "--python", "C:/Python313/python.exe", "--python-worker", Path.cwd() / "benchmarks/cpython-worker.py",
         "--out", lab / (role + "-verify.json")], role + "-verify.log")
    verification = load(lab / (role + "-verify.json"))
    assert verification["state"] == "Completed" and verification["catalogSha256"] == sha(catalog)
    run([dotnet, image / "ValidatedAllocation.dll", image, catalog, lab / (role + "-allocation.json")],
        role + "-allocation.log")
    assert images[role] == {name: sha(image / name) for name in source_files}
assert images["reference"] == source_files and images["candidate"][core] != images["reference"][core]
identity = dict(referenceCommit=reference, candidateCommit=candidate, casesSHA256=sha(catalog), images=images)
(lab / "frozen-identity.json").write_text(json.dumps(identity, indent=2) + "\n", encoding="utf-8")
left = load(lab / "reference-allocation.json")["rows"]
right = load(lab / "candidate-allocation.json")["rows"]
for before, after in zip(left, right, strict=True):
    assert before["id"] == after["id"] and before["sharedBudgetBaselineRestored"] and after["sharedBudgetBaselineRestored"]
    a = statistics.median(before["allocatedBytesPerInvocation"])
    b = statistics.median(after["allocatedBytesPerInvocation"])
    print(before["id"], f"{a:,} to {b:,}", f"{100 * (b / a - 1):+.2f}%",
          "accounted", before["peakExecutionMemoryBytes"], after["peakExecutionMemoryBytes"], flush=True)
print("Verified both 32-file images and exact canonical cases against CPython.", flush=True)
