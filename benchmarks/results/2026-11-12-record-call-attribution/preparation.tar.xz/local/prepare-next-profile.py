from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
base=Path(__file__).resolve().parents[2];r=base/'record-call-r267';r.mkdir(exist_ok=False);q=r/'b615';q.mkdir()
old=base/'call-boundary-r264/b610';current=base/'conditional-helper-r266/normalized/b614'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((current/'identity.json').read_text(encoding='utf-8'))
identity['coreSHA256']={'candidate':identity['coreSHA256']['candidate']}
identity['sourceRevision']='da9e5066 R266 retained compiler-only predicate; exact a552 core. R267 two6s CSVvalidation/report Run captures; separate actual construction/format/dispatch before coherent next redesign. No elapsed comparison or removable-tax forecast. Full CI43183343974 independently running.'
with tarfile.open(old/'observations.tgz')as t:catalog=t.extractfile('catalog.json').read()
(q/'catalog.json').write_bytes(catalog);identity['catalogSHA256']=sha(q/'catalog.json')
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8');shutil.copyfile(current/'source-identity.json',q/'source-identity.json')
name='record-call-profile-b615-20261112';unit='lython-b615-record-call-profile-20261112'
for filename in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','launch.py','retrieve-original.py','remote-launch.py']:
 s=(old/filename).read_text(encoding='utf-8').replace('call-boundary-profile-b610-20261112',name).replace('lython-b610-call-boundary-profile-20261112',unit).replace('lython-b610-fixtures','lython-b615-fixtures').replace('call-boundary-profile-b610-launch.py','record-call-profile-b615-launch.py').replace('B610','B615')
 if filename=='ops-profile.py':
  a=s.index('for name, case_id, lane in [');b=s.index(':\n',a)
  s=s[:a]+'for name, case_id, lane in [("csv-validation", "scripts.csv-validated-records.large", "warm"),("report", "scripts.report-render.large", "warm")]'+s[b:]
  s=s.replace('total_capture_seconds > 8','total_capture_seconds > 16')
  s=s.replace('BeginFunctionCall BeginBoundCall BindFunctionArgumentsInto ExecuteInstructionPrefix','BeginFunctionCall BeginBoundCall BindFunctionArgumentsInto ExecuteInstructionPrefix TryMoveNextCoreAsync TryExecuteFormattedInstruction AppendInterpolatedStringPart')
 if filename=='run.sh':s=s.replace('in guarded-search;','in csv-validation report;')
 if filename=='archive.py':s=s.replace("['guarded-search']","['csv-validation','report']").replace('seconds<8','seconds<16')
 if filename=='retrieve-original.py':s=s.replace("['capturedSeconds']<8","['capturedSeconds']<16")
 if filename=='remote-launch.py':s=s.replace("source=base/'text-batches-b608-20261112/candidate'","source=base/'conditional-normalized-b614-20261112/candidate'").replace('sampledSeconds=8','sampledSeconds=16')
 (q/filename).write_text(s,encoding='utf-8',newline='\n')
 if filename.endswith('.py')and filename!='remote-launch.py':ast.parse(s)
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['catalog.json','identity.json','source-identity.json','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh']:t.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz')as t:expanded=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())
archive=Path('benchmarks/results/2026-11-12-conditional-helper-bodies/normalized/b614/observations.tgz')
assert archive.read_bytes()==subprocess.check_output(['git','show','HEAD:'+archive.as_posix()])
retire=[]
for member in [None,'representative.json','confirmation/confirmation.json']:
 with tarfile.open(archive)as t:b=archive.read_bytes()if member is None else t.extractfile(member).read()
 spec=dict(kind='exact',knownPath='conditional-normalized-b614-20261112/'+(member or 'observations.tgz'),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),canonicalStorage=archive.as_posix(),reason='Exact committed da9e5066 B614 evidence duplicates only; a552 and b2 images protected. Fresh idle lease/UID/path/inode/all-alias proof, unchanged floors.')
 if member:spec.update(canonicalEntry=member,canonicalArchiveSHA256=sha(archive))
 retire.append(spec)
config=dict(root='/home/lokad/lython-bench-checks/'+name,unit=unit,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),requiredFreeBytes=252*1024*1024+expanded+65536,retire=retire,identity=identity)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
ast.parse((q/'remote-launch.py').read_text(encoding='utf-8').replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
print('Two short existing-protocol profiles staged; no new benchmark framework or elapsed claim.')
