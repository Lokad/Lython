from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;q=r/'b615';out=Path('benchmarks/results/2026-11-12-record-call-attribution');out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));identity=json.loads((q/'identity.json').read_text(encoding='utf-8'))
assert receipt['complete']and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']and receipt['quietBeforeAndAfter']and receipt['archivedAndVerifiedUnderLease']
assert sha(q/'observations.tgz')==receipt['archiveSHA256']
with tarfile.open(q/'observations.tgz')as t:
 assert hashlib.sha256(t.extractfile('current-core.dll').read()).hexdigest()==identity['coreSHA256']['candidate']
 for name in ['csv-validation','report']:
  record=json.loads(t.extractfile('profiles/'+name+'/record.json').read())
  for key in ['verificationBefore','verificationAfter']:assert record[key]['status']=='Equivalent'
  assert record['exitCode']==0 and record['closed']['status']=='Closed'
  image=next(p for p in record['identity']['libraries']if Path(p['path']).name=='Lokad.Lython.dll')
  assert image['sha256'].lower()==identity['coreSHA256']['candidate']
for name in ['observations.tgz','archive-receipt.json','identity.json','source-identity.json','terminal-status.json','inventory.json','launch.log','observe-not-before.json']:shutil.copyfile(q/name,out/name)
shutil.copyfile(r/'attribution.json',out/'attribution.json')
with tarfile.open(out/'preparation.tar.xz','w:xz')as t:
 for p in sorted(q.iterdir()):
  if p.is_file()and p.name not in ['observations.tgz','payload.tgz']:t.add(p,arcname=p.name)
 t.add(r.parent/'conditional-helper-r266/normalized/prepare-next-profile.py',arcname='local/prepare-next-profile.py')
 t.add(__file__,arcname='local/archive.py')
(out/'README.md').write_text('''# R267 — remaining CSV/report work

2026-11-12, retained `da9e5066`, frozen a55202fb, same fec79 worker and optional
adapter0.4. Two current-image Run captures on quiet F4as_v7 / Ubuntu24.04.4 /
.NET11RC3, ordinary GC/tiering plus recorded perf-map/JIT diagnostics. Total guest
execution clocks 11.771 seconds; selected CPU 5.98 seconds CSV and 5.38 report.
All actual-image, stdout/files, allowance, verification/close, quiet, join,
unmount and independently verified archival gates pass. No elapsed comparison.

| Complete script | Selected samples / unknown | Instruction/input/result/comparison | Binding/entry/work | Other visible work |
| --- | --- | --- | --- | --- |
| CSV validation | 1,189 / 70 (5.89%) | 267 (22.46%) | 90 (7.57%) | CSV scanner/materialization/adoption 129; shared-root lock entry/exit 41 |
| Report | 1,068 / 68 (6.37%) | 196 (18.35%) | 17 (1.59%) | Formatting/write 160; shared-root lock entry/exit 72; JSON construction/string work also present |

Groups cover saved top-24 leaves only, not complete exclusive subsystem costs.
Useful/inlined work is included; these shares are not removable taxes or speedup
forecasts. Whole-batch sampling includes mediated RAM I/O, reset/protocol/output
validation and cleanup beyond execution clocks. Raw stacks/maps, thread CPU,
unknowns and all diagnostics survive in observations.tgz.

Source gate: there is no duplicate frame or second argument array. Ordinary
deferred helpers already run without an invocation context until actual protocol
or namespace requirements; binding locals and operands share backing. CSV already
admits all normal field payloads together, stores small strings inline, and adopts
row storage into dictionaries with shared keys. Report fields already append
direct UTF-8 into transferred final storage; constant specifiers are prepared.
Do not reintroduce those completed projects as new optimizations.

The remaining broad lead is instruction/operand transport, not a binding-loop or
per-character-string patch. A bounded source proof must identify an actual stage
to eliminate before another prototype. Prior arenas added access/save/restore
work and measured slower; integer-local variants saved allocation without a
general CPU gain. These observations allow a materially different refinement,
but do not support an unchanged replay or a universal tagged-value commitment.

Important obstacle for whole-body preparation: report field formatting may admit
storage before a later dictionary read. Host reentry can mutate that dictionary.
Reading all values early, or restarting ordinary execution after effects, changes
semantics. Any consolidation must preserve ordered reads, live intermediate
values, original spans, actual suspension and funded cleanup. No second mini-VM,
extra dispatcher or hidden memory grant is selected from these leaf counts.

This closes the two-capture investigation; do not repeat it unchanged. Next is a
concrete operand/lifetime deletion proof, or explicit obstacle followed by another
stage. The performance objective remains active. Exact-head full delivery is
tracked separately; no new CPython ratio, allocation or final adapter claim.

The retrieval time guard initially rejected a local attempt 23 seconds before
the existing observation bound; it contacted no remote process and changed no
conditions. Retrieval after the bound succeeded. Only exact committed B614
archive/catalog/record duplicates were retired, with fresh lease, UID/path/inode/
all-alias and canonical Git/SHA proofs. Current/reference images remain protected;
OS/evidence floors unchanged. Terminal state is cached; no live users/RAM traces.
Publication remains postponed.
''',encoding='utf-8')
files={p.relative_to(out).as_posix():sha(p)for p in out.rglob('*')if p.is_file()};(out/'files-sha256.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8')
with Path('.gitattributes').open('a',encoding='utf-8')as f:f.write('\nbenchmarks/results/2026-11-12-record-call-attribution/** -text whitespace=cr-at-eol\n')
print('Two short profiles archived with source exclusions, unknowns and concrete ordering obstacle; no speedup claim.')
