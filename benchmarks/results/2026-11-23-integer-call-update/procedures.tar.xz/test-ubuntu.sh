set -e
export DOTNET_ROOT=/home/vermorel/.dotnet
export DOTNET_ROOT_X64=$DOTNET_ROOT
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/supplied-call-accumulation-20261123
public='(FullyQualifiedName~SharedIntegerChain|FullyQualifiedName~NativeTupleReturn|FullyQualifiedName~ExecutableOperandStack|FullyQualifiedName~AssignmentTarget|FullyQualifiedName~NumericArithmetic|FullyQualifiedName~Cancellation|FullyQualifiedName~MemoryOwnership)&Category!=Stress'
white='(FullyQualifiedName~ExecutableUnpacking|FullyQualifiedName~ExecutableLoopTarget|FullyQualifiedName~ExecutableOperandStack|FullyQualifiedName~NativeTupleReturn|FullyQualifiedName~ExecutableStack|FullyQualifiedName~Cancellation)&Category!=Stress'
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$public" > "$lab/ubuntu-public.log" 2>&1 || { tail -28 "$lab/ubuntu-public.log"; exit 1; }
tail -7 "$lab/ubuntu-public.log"
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$white" > "$lab/ubuntu-white.log" 2>&1 || { tail -28 "$lab/ubuntu-white.log"; exit 1; }
tail -7 "$lab/ubuntu-white.log"
