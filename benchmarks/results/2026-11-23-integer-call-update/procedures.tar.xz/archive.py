from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
quiet=lab/'comparison/quiet'
dest=root/'benchmarks/results/2026-11-23-integer-call-update'
sha=lambda data:hashlib.sha256(data).hexdigest()
digest=lambda path:sha(path.read_bytes())
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
git=lambda *args:subprocess.check_output(['git',*args],cwd=root)
identity=read(lab/'comparison/identity.json')
receipt=read(quiet/'terminal-status.json')
assert receipt['exitCode']=='0' and not receipt['live'] and not receipt['fixtures']
assert all(receipt['receipt'][key] for key in ('complete','quietBeforeAndAfter','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert digest(quiet/'observations.tar.xz')==receipt['receipt']['archiveSHA256']
assert read(quiet/'summary.json')['timedBatches']==140
assert read(lab/'tape-summary.json')['sameBodies']==10
assert read(lab/'negative-evidence.json')['affectedInvocations']==2048
assert all(row['allocatedBytes'][0]==row['allocatedBytes'][1] and row['peakAdmission'][0]==row['peakAdmission'][1]
    for row in read(lab/'allocation-summary-six.json'))
revision=(lab/'retained-revision').read_text(encoding='utf-8-sig').strip()
assert not git('diff','--name-only',revision,identity['candidate'],'--','src','tests')
identity['retainedRevision']=revision
patch=git('diff','--binary',identity['sourceRevision'],identity['candidate'],'--','src','tests')
(lab/'comparison.patch').write_bytes(patch)
identity['comparisonPatchSHA256']=sha(patch)
dest.mkdir(exist_ok=True)
assert all(path.name=='README.md' for path in dest.iterdir())
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and all(digest(lab/role/name)==value for name,value in files.items())
    core=lab/role/'Lokad.Lython.dll'
    assert digest(core)==files[core.name]
    (dest/(role+'-core.dll.gz')).write_bytes(gzip.compress(core.read_bytes(),mtime=0))
(dest/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ('observations.tar.xz','summary.json','terminal-status.json'):
    shutil.copyfile(quiet/name,dest/name)
for name in ('allocation-summary-six.json','tape-summary.json','negative-evidence.json'):
    shutil.copyfile(lab/name,dest/name)
original=lab/'reference-allocation-attribution'
diagnostic=lab/'boxing-diagnostic'
original_sample=read(original/'supplied-call/sampled-allocation.json')
diagnostic_sample=read(diagnostic/'supplied-call/sampled-allocation.json')
name='System.Numerics.BigInteger'
share=lambda sample:next(row['SampleWeightPercent'] for row in sample['Rows'] if row['Type']==name)
stacks=read(diagnostic/'supplied-call/allocation-stacks.json')
assert all(all(method in row['Stack'] for method in ('PublishInteger','ReadLocalValue','LoadLocal'))
    for row in stacks if row['Type']==name)
(dest/'boxing-summary.json').write_text(json.dumps(dict(referenceBigIntegerWeight=share(original_sample),
    diagnosticBigIntegerWeight=share(diagnostic_sample),referenceSamples=original_sample['Samples'],
    diagnosticSamples=diagnostic_sample['Samples'],resolvedPublication='PublishInteger from ReadLocalValue / LoadLocal'),indent=2)+'\n',
    encoding='utf-8',newline='\n')
with tarfile.open(dest/'procedures.tar.xz','w:xz') as archive:
    for name in ('archive.py','prepare.py','stage.py','quiet.py','summarize.py','allocations.py','comparison.patch','semantic-golden.json',
        'windows-first-build.log','windows-reference.log','windows-frozen.log','windows-public.log','windows-white.log',
        'ubuntu-public.log','ubuntu-white.log','windows-retained.log','ubuntu-retained.log','test-ubuntu.sh','test-ubuntu-retained.sh',
        'reference-allocation-six.json','candidate-allocation-six.json','prepare.log','stage.log','launch.log','retrieval.log',
        'comparison/reference-verify.json','comparison/candidate-verify.json','comparison/quiet/observe-not-before',
        'reference-tape.json','candidate-tape.json','regression.patch','negative.patch','negative-build.log','negative.log',
        'negative-catalog.json','negative-verification.json'):
        archive.add(lab/name,arcname=name)
    for folder in (original,diagnostic):
        run=read(folder/'run-summary.json')
        record=read(folder/'supplied-call/record.json')
        assert run['allProcessesJoined'] and record['allProcessesJoined'] and record['nettraceSha']==digest(folder/'supplied-call/warm.nettrace')
        for name in ('profile-allocation.py','profile.log','verification.json','catalog.json','run-summary.json','stacks.log',
            'supplied-call/warm.nettrace','supplied-call/capture.log','supplied-call/record.json',
            'supplied-call/sampled-allocation.json','supplied-call/allocation-stacks.json'):
            archive.add(folder/name,arcname=folder.name+'/'+name)
    for name in ('diagnostic-identity.json','diagnostic.patch','build.log'):
        archive.add(diagnostic/name,arcname=diagnostic.name+'/'+name)
    for name in ('read-il/Program.cs','read-il/ReadIl.csproj','local-read-il.log'):
        archive.add(original/name,arcname=original.name+'/'+name)
print(dest,revision)

