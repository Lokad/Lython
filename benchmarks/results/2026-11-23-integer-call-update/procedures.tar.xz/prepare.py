from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/'.git/agent-worktrees/supplied-call-accumulation-20261123'
reference_tree=repo/'.git/agent-worktrees/supplied-call-accumulation-reference-20261123'
notes=lab.parent
donor=notes/'csv-short-utf8-20261123/typed-reader'
prior=notes/'csv-short-utf8-20261123'
helper=notes/'parallel-assignment-operands-20261123'
comparison=lab/'comparison'
comparison.mkdir(exist_ok=True)
sha=lambda data: hashlib.sha256(data).hexdigest()
digest=lambda p: sha(p.read_bytes())
read=lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,data):
    p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
reference=git('-C',reference_tree,'rev-parse','HEAD').decode().strip()
candidate=(lab/'built-revision').read_text(encoding='utf-8-sig').strip()
assert reference==git('rev-parse',candidate+'^').decode().strip()
assert candidate==git('-C',tree,'rev-parse','HEAD').decode().strip()
assert not any(git('-C',path,'status','--porcelain') for path in (tree,reference_tree))
tracked='benchmarks/results/2026-11-23-short-csv-utf8-slots/'
pushed=lambda name:git('show','origin/master:'+tracked+name)
proof=json.loads(pushed('typed-reader-identity.json'))
receipt=json.loads(pushed('typed-reader-terminal-status.json'))['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archivedAndVerifiedUnderLease']
assert sha(pushed('typed-reader-observations.tar.xz'))==receipt['archiveSHA256']
files=proof['imageFiles']['candidate']
assert len(files)==32 and all(digest(donor/'candidate'/name)==expected for name,expected in files.items())
protocol=repo/'benchmarks/cpython-worker.py'
assert digest(protocol)==proof['cpythonWorkerSHA256']

csv=read(donor/'comparison/representative.json')
supplied='scripts.ordinary-fully-supplied-helper'
quote='scripts.csv-invoice.method-policy.quoted-control'
floating='scripts.csv-meter-report.explicit-float'
word='diagnostic.text-summary.nonlocal-computed-width.large'
catalogs=(csv,read(helper/'comparison/representative.json'))
lookup={item['id']:item for catalog in reversed(catalogs) for item in catalog['cases']}
csv['cases']=[lookup[name] for name in (supplied,quote,floating,word)]
write(comparison/'representative.json',csv)
write(comparison/'jobs.json',dict(warm=[[supplied,'warm'],[supplied,'compile-run'],
    [quote,'warm'],[word,'compile-run'],[floating,'warm']]))
dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
inspector=notes/'adjacent-integer-results-20261123/reference'
core='Lokad.Lython.dll'
actual={}
for role,build in (('reference','reference-build'),('candidate','frozen')):
    image=lab/role
    image.mkdir(exist_ok=True)
    for name,expected in files.items():
        source=donor/'candidate'/name
        if name==core:source=lab/build/'bin/Lokad.Lython/release_net11.0'/core
        target=image/name
        if not target.exists():shutil.copyfile(source,target)
        assert digest(target)==digest(source)
    for name in ('ValidatedAllocation.dll','ValidatedAllocation.deps.json','ValidatedAllocation.runtimeconfig.json'):
        shutil.copyfile(donor/'candidate'/name,image/name)
    for name in ('Inspect.dll','Inspect.deps.json','Inspect.runtimeconfig.json'):
        shutil.copyfile(inspector/name,image/name)
    actual[role]={name:digest(image/name) for name in files}
    verification=comparison/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',comparison/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',verification],
        env=env,check=True,timeout=95)
    data=read(verification)
    assert data['state']=='Completed' and data['caseCount']==4
    assert data['launched']['library']['sha256']==actual[role][core]
    subprocess.run([dotnet,image/'Inspect.dll',comparison/'representative.json',lab/(role+'-tape.json')],
        env=env,check=True,timeout=35)
    assert read(lab/(role+'-tape.json'))['coreSHA256']==actual[role][core]
    assert all(digest(image/name)==expected for name,expected in actual[role].items())
assert [name for name in files if actual['reference'][name]!=actual['candidate'][name]]==[core]
old,new=(read(lab/(role+'-tape.json'))['rows'] for role in ('reference','candidate'))
assert old==new
module=next(row for row in old if row['id']==supplied)['codes'][0]['tape']
opcodes=(tree/'src/Lokad.Lython/Frontend/ExecutableScript.cs').read_text(encoding='utf-8')
names=re.findall(r'^\s*(\w+),\s*$',opcodes.split('enum ExecutableOpCode',1)[1].split('}',1)[0],flags=re.M)
assert [names[entry['<OpCode>k__BackingField']] for entry in module[16:19]]==['Call','Augmented','StoreLocal']
assert module[16]['_resultSlot']==module[17]['_secondaryOperand']==5
assert module[17]['_inputStart']==module[17]['_resultSlot']==4
write(lab/'tape-summary.json',dict(suppliedCallSite=module[16:19],sameBodies=sum(len(row['codes']) for row in old)))
write(comparison/'identity.json',dict(sourceRevision=reference,candidate=candidate,
    purpose='B1522 consume completed integer returns without interim publication',imageFiles=actual,
    coreSHA256={k:rows[core] for role,rows in actual.items() for k in (role,role+'-control')},
    cpythonWorkerSHA256=proof['cpythonWorkerSHA256'],expectedCPythonSHA256=proof['expectedCPythonSHA256'],
    catalogs={name:dict(sha256=digest(comparison/name)) for name in ('representative.json','jobs.json')}))

def adapt(name,changes):
    source=(prior/name).read_text(encoding='utf-8')
    for before,after in changes:
        assert source.count(before)==1,(name,before,source.count(before))
        source=source.replace(before,after)
    compile(source,str(lab/name),'exec')
    (lab/name).write_text(source,encoding='utf-8',newline='\n')

adapt('stage.py',(
    ('csv-short-utf8-b1520-20261123','supplied-call-accumulation-b1522-20261123'),
    ('parallel-assignment-refined-b1517-20261123','csv-short-utf8-typed-reader-b1520-20261123'),
    ("'reference':root.parent/'{reference}'/'candidate'","'reference':root/'reference'"),
    ('lython-b1520-fixtures','lython-b1522-fixtures'),('len(jobs) == 6','len(jobs) == 5'),('< 320,','< 270,'),
    ('    bundle.add(lab/"candidate/Lokad.Lython.dll",arcname="candidate-core.dll")',
     '    for role in ("candidate","reference"):\n        bundle.add(lab/role/"Lokad.Lython.dll",arcname=role+"-core.dll")'),
))
runner=(prior/'quiet.py').read_text(encoding='utf-8')
start=runner.index(" image=root/'candidate';image.mkdir()")
end=runner.index(" os.link(reference/'cpython-worker.py'",start)
adapt('quiet.py',(
    ('lython-b1520-short-csv-utf8-20261123','lython-b1522-supplied-call-accumulation-20261123'),
    ('.+b1520-','.+b1522-'),('lython-b1520-stage-','lython-b1522-stage-'),
    ('Six bounded lanes write under 1 MiB of receipts. An 81 MiB','Five bounded lanes write under 1 MiB of receipts. A 49 MiB'),
    ('81 * 1024 * 1024','49 * 1024 * 1024'),
    ('needs one core, publication archive and working-room floor','needs two cores, receipts and working room'),
    ("'collect.py','candidate-core.dll'}","'collect.py','candidate-core.dll','reference-core.dll'}"),
    (runner[start:end],""" for role,files in identity['imageFiles'].items():
  image=root/role;image.mkdir()
  for name,sha in files.items():
   if name=='Lokad.Lython.dll':
    (root/(role+'-core.dll')).rename(image/name)
    assert digest(image/name)==sha
   else:
    src=reference/'candidate'/name
    assert digest(src)==sha,name
    os.link(src,image/name)
"""),
    ('RuntimeMaxSec=380','RuntimeMaxSec=320'),('seconds=298','seconds=253'),
))
adapt('summarize.py',(
    ('== 6\nassert hashlib','== 5\nassert hashlib'),('len(warm["jobs"])==6','len(warm["jobs"])==5'),
    ('timedBatches=168','timedBatches=140'),
))
shutil.copyfile(prior/'allocations.py',lab/'allocations.py')

