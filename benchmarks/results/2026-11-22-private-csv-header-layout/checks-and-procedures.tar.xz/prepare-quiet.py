from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / "native-single-capture-construction-20261122"
donor = prior / "quiet"
procedures = prior
template = procedures / "quiet"
template_config = json.loads((template / "config.json").read_text(encoding="utf-8"))
out = lab / "quiet"
out.mkdir(exist_ok=True)

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    return sha_bytes(path.read_bytes())

def emit(path, source):
    if path.suffix == ".py":
        compile(source, str(path), "exec")
    path.write_text(source, encoding="utf-8", newline="\n")

def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")

retirement_proof = load(lab / "retire-proof.json")
retire = retirement_proof["proof"]
prior_config = load(donor / "config.json")
prior_receipt = load(donor / "archive-receipt.json")
prior_identity = load(donor / "identity.json")
reference_donor = prior_identity["imageFiles"]["candidate"]
assert prior_receipt["complete"] and prior_receipt["archivedAndVerifiedUnderLease"]
assert len(reference_donor) == 32 and reference_donor == {name:sha(prior / "frozen" / "candidate" / name) for name in reference_donor}

manifest = out / "representative.json"
catalog = load(lab / "representative.json")
cases = [case["id"] for case in catalog["cases"]]
assert len(cases) == 4
save(manifest, catalog)
local = load(lab / "identity.json")
reference, candidate = (subprocess.check_output(["git", "rev-parse", local[key]], cwd=repo, text=True).strip()
                       for key in ("reference", "candidate"))
assert reference.startswith("2f9f818b9") and candidate.startswith("e04d22fc2")
image_files = local["imageFiles"]
core = "Lokad.Lython.dll"
for role, hashes in image_files.items():
    image = lab / "frozen" / role
    assert len(hashes) == 32 and {name: sha(image / name) for name in hashes} == hashes
    assert all(reference_donor[name] == value for name, value in hashes.items() if name != core)
    if role == "reference":
        assert hashes == reference_donor
    for suite, count in (("white", 123), ("public", 405)):
        for platform in ("win", "ubuntu"):
            log = (lab / f"{suite}-{platform}.log").read_text(encoding="utf-8-sig")
            quiet_success = "Passed!" in log and f"Passed: {count:5d}, Skipped:" in log
            detailed_success = "Test Run Successful." in log and f"Passed: {count}" in log
            assert quiet_success or detailed_success
    sdk = Path.home() / ".dotnet11"
    dotnet = sdk / "dotnet.exe"
    env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
    receipt = lab / f"quiet-{role}-verify.json"
    protocol = repo / "benchmarks/cpython-worker.py"
    assert sha(protocol) == prior_config["protocolSHA256"]
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
        "--catalog", manifest, "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
        "--python-worker", protocol, "--out", receipt], check=True, env=env, timeout=95)
    proof = load(receipt)
    assert proof["state"] == "Completed" and proof["caseCount"] == 4 and proof["catalogSha256"] == sha(manifest)

identity = dict(sourceRevision=reference + " versus " + candidate, purpose="Reuse a private CSV header layout",
                imageFiles=image_files, normalAdapterPin="0.4.0", catalogSHA256=sha(manifest),
                coreSHA256={role + suffix: hashes[core] for role, hashes in image_files.items() for suffix in ("", "-control")})
save(out / "identity.json", identity)
root = "/home/lokad/lython-bench-checks/private-csv-header-layout-b1355-20261122"
unit = "lython-b1355-private-csv-header-layout-20261122"
invoice = "scripts.csv-invoice.large"
jobs = [(case, "warm") for case in cases] + [(invoice, "compile-run")]
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    original = (template / name).read_text(encoding="utf-8").replace(template_config["root"], root).replace(template_config["unit"], unit)
    if name == "collect.py":
        start, end = original.index("\njobs = "), original.index("\nassert len(jobs)")
        original = (original[:start] + "\njobs = " + repr(jobs) + original[end:])
        original = original.replace("job_index % 2 != 0", "job_index % 2 == 0")
        original = original.replace("len(jobs)==6", "len(jobs)==5").replace("started < 341", "started < 280")
    if name in ("archive-owned.py", "retrieve.py"):
        original = original.replace("jobs=6,", "jobs=5,").replace("['jobs']==6", "['jobs']==5").replace("len(raw['jobs'])==6", "len(raw['jobs'])==5")
    if name == "archive-owned.py":
        assert "len(raw['jobs'])==5" in original and "jobs=5," in original
    emit(out / name, original)
assert b"\r" not in (out / "run.sh").read_bytes()
for role in image_files:
    (out / role).mkdir(exist_ok=True)
    shutil.copyfile(lab / "frozen" / role / core, out / role / core)
    assert sha(out / role / core) == image_files[role][core]
parts = ("identity.json", "collect.py", "archive-owned.py", "run.sh", "representative.json",
         "candidate/" + core)
payload = out / "payload.tgz"
with tarfile.open(payload, "w:gz") as file:
    for name in parts:
        file.add(out / name, arcname=name)
unpacked = sum((out / name).stat().st_size for name in parts)
if retirement_proof["free"] > 176160768 + unpacked + 640*1024:
    retire = []
stage = dict(root=root, unit=unit, identity=identity, source=prior_config["root"], sourceRole="candidate",
             sourceFiles=reference_donor, sourceCatalogSHA256=prior_config["catalogSHA256"],
             donorArchiveSHA256=prior_receipt["archiveSHA256"], protocolSource=prior_config["root"] + "/cpython-worker.py",
             protocolSHA256=prior_config["protocolSHA256"], payloadBytes=payload.stat().st_size,
             payloadSHA256=sha(payload), retireGroups=retire, catalogSHA256=sha(manifest),
             unpackedBytes=sum((out / name).stat().st_size for name in parts))
save(out / "config.json", stage)
source = (template / "remote-launch.py").read_text(encoding="utf-8")
start, end = source.index("\nc=") + 1, source.index("\nb=Path(")
source = source[:start] + "c=" + repr(stage) + source[end:]
source = source.replace("lython-b1354-fixtures", "lython-b1355-fixtures").replace("RuntimeMaxSec=405", "RuntimeMaxSec=340")
assert "c['unpackedBytes']+640*1024" in source
emit(out / "remote-launch.py", source)
emit(lab / "launch.py", (procedures / "launch.py").read_text(encoding="utf-8")
     .replace("Native singleton capture construction comparison", "Private CSV header layout comparison").replace("365", "310"))
emit(lab / "summarize.py", (procedures / "summarize.py").read_text(encoding="utf-8").replace("len(raw['jobs'])==6", "len(raw['jobs'])==5"))
print(f"Prepared five lanes with {stage['unpackedBytes']} bytes of persistent working data.")
