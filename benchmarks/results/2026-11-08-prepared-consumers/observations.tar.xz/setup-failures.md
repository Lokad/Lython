Initial six-case catalog was rejected by the existing five-case harness before samples.
The five-case attempt reached the new arithmetic control and failed its file golden:
the copied report metadata still contained the report artifact digest despite an empty
control fixture. All originals/stderr retained. Earlier cases had run, and their individual per-case snapshots are preserved in the failed directory.
The aggregate JSON is unavailable because emission follows all cases. No results
are discarded or used as controlled evidence. Correct control size/output/
fixture/file digests; validate all source/fixture/output hashes before retrying.
No runtime source or golden expectation was relaxed to pass this correction.
