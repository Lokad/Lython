from pathlib import Path
import base64,copy,hashlib,json,os,shutil,subprocess,tempfile
r=Path(__file__).resolve().parent;prior=r.parent/'activation-r79/source-pair'
d=json.loads((prior/'catalog.json').read_text(encoding='utf-8'))
control=copy.deepcopy(d['cases'][-1]);control.update(id='diagnostic.integer-loop-control.small',source='total=0\nfor index in range(4096):\n total+=index\nprint(total)\n',expectedOutput='8386560\n')
fixture=json.loads(control['fixtureJson']);fixture['inputFiles']={};fixture['outputFiles']={};control['fixtureJson']=json.dumps(fixture)
control['sourceUtf8Bytes']=len(control['source'].encode('utf-8'));control['sourceSha256']=hashlib.sha256(control['source'].encode('utf-8')).hexdigest()
d['cases'].append(control)
goldens=[]
for case in d['cases']:
 fixture=json.loads(case['fixtureJson'])
 with tempfile.TemporaryDirectory(prefix='lython-consumer-golden-') as folder:
  for f,v in fixture['inputFiles'].items():(Path(folder)/f).write_bytes(base64.b64decode(v))
  done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',case['source']],cwd=folder,capture_output=True)
  assert done.returncode==0 and not done.stderr and done.stdout.replace(b'\r\n',b'\n')==case['expectedOutput'].encode('utf-8'),(case['id'],done.stderr)
  assert all((Path(folder)/f).read_bytes()==base64.b64decode(v)for f,v in fixture['outputFiles'].items())
 assert not Path(folder).exists()
 goldens.append(dict(case=case['id'],sourceSHA256=case['sourceSha256'],fullStdoutAndFiles=True))
(r/'catalog.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(r/'independent-goldens.json').write_text(json.dumps(goldens,indent=2)+'\n',encoding='utf-8')
for role in ['before','candidate']:shutil.copytree(prior/'images/candidate',r/'images'/role,copy_function=os.link)
core=r/'images/candidate/Lokad.Lython.dll';core.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',core)
inventory={str(f).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest()for f in Path('src/Lokad.Lython').rglob('*')if f.is_file()and not {'bin','obj'}&set(f.parts)}
(r/'identity.json').write_text(json.dumps(dict(baselineSource='913ea550',candidateSource='71445454 plus R82 prepared consumer patch',coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},productionSources=inventory,qualification='332internal/155public actual.NET11 Release focused checks pass. New runtime is a prototype, not fully qualified.'),indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests/Lokad.Lython.PublicApi.Tests/OperandReadFailureTests.cs']))
(r/'measure.py').write_text((prior.parent/'measure.py').read_text(encoding='utf-8').replace('all five golden','all six golden'),encoding='utf-8')
print('Frozen six-case source pair/all full CPython goldens verified; current consumer prototype, no speed claim.')
