from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;out=Path('benchmarks/results/2026-11-08-prepared-consumers');out.mkdir(exist_ok=True)
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
vm=json.loads((r/'b445/assessment.json').read_text(encoding='utf-8'));assert vm['complete']
assessment=dict(decision='Retain completion of existing prepared single-input representation; allocation neutral, emitted leaf dispatch removed. No broad CPU improvement established. Do not expand into a per-opcode micro-optimization series.',source=identity,focused=json.loads((r/'focused-final.json').read_text(encoding='utf-8')),vm=vm,limitations=['Synchronous text elapsed lower0.13–1.85%, but coarseCPU−1.67to+6.67%; not a CPU win.','Asynchronous text elapsed lower0.98–4.74%, but old process spread3.60%; magnitude uncertain.','Guarded text−0.77to+1.76%, CSV−0.24to+1.50%: near baseline, possible CSV regression retained explicitly rather than repaid by other gains.','Report−4.02to+2.15%, candidate spread5.32%: inconclusive. Arithmetic control−1.53to+0.92%, near baseline.','Earlier R76float/R79CSV debt remains separate. No CPython/startup/RSS/embedding-tail/universal CPU claim.','Timing uses completed I/O; genuine protocol suspension/cancellation/awaited cleanup is independently tested.','Full Windows/Ubuntu actual11/10, originalStress and installed consumers pending retained delivery.'])
(out/'assessment.json').write_text(json.dumps(assessment,indent=2)+'\n',encoding='utf-8')
shutil.copyfile('tests/Lokad.Lython.PublicApi.Tests/PreparedConsumerProtocolTests.cs',r/'PreparedConsumerProtocolTests.cs')
with tarfile.open(out/'observations.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if p.is_file() and not any(part in ['images','retrieved','__pycache__']for part in p.relative_to(r).parts) and p.name not in ['payload.tgz','current-core.dll','baseline-core.dll']:
   a.add(p,arcname=p.relative_to(r).as_posix())
with tarfile.open(out/'observations.tar.xz')as a:
 for m in a.getmembers():
  assert m.isfile();assert hashlib.sha256(a.extractfile(m).read()).digest()==hashlib.sha256((r/m.name).read_bytes()).digest()
print('Retained source/focused/controlled/failed/adverse originals archived and verified:',(out/'observations.tar.xz').stat().st_size,'bytes')
