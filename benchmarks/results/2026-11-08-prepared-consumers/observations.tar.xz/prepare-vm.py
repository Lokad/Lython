from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;b=r/'b445';b.mkdir();prior=r.parent/'activation-r79/b443'
old='native-workstate-b443-20261108';new='operand-consumers-b445-20261108'
unitOld='lython-b443-native-workstate';unitNew='lython-b445-operand-consumers'
jobs=[['scripts.text-summary-rsplit-helpers.large','warm'],['scripts.text-summary-rsplit-helpers.large','warm-async'],['scripts.text-summary-guarded-helpers.large','warm'],['scripts.csv-summary-functions.large','warm'],['scripts.report-render.large','warm-async'],['diagnostic.integer-loop-control.small','warm']]
for n in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
 s=(prior/n).read_text(encoding='utf-8').replace(old,new).replace(unitOld,unitNew)
 if n=='collect.py':
  a=s.index('jobs=');z=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[z:]
  s=s.replace('R79 native workstate receiver dispatch and exact list/tuple iteration; complete ordinary/guarded helpers and unaffected controls','R82 prepared single-input consumers; affected complete scripts, report and identical-instruction arithmetic control')
 if n=='launch.py':
  s=s.replace("reference=base/'method-binding-b441-20261108/candidate'","reference=base/'native-workstate-b443-20261108/candidate'")
 (b/n).write_text(s,encoding='utf-8',newline='\n')
 if n.endswith('.py'):ast.parse(s)
source=json.loads((r/'identity.json').read_text(encoding='utf-8'));base=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision=source['candidateSource'],baselineSource='913ea550 fully qualified CI42447193207',coreSHA256={role:source['coreSHA256']['before' if role.startswith('reference') else 'candidate']for role in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles=base['auxiliaryFiles'],productionSources=source['productionSources'],baselineProductionSources=json.loads((r.parent/'activation-r79/source-pair/identity.json').read_text(encoding='utf-8'))['productionSources'],jobs=jobs,included=base['included'],qualification=source['qualification'])
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'focused.json').write_text(json.dumps(dict(net11Internal=332,net11Public=155,net10='pending',newProtocolCases=6,coreSHA256=source['coreSHA256']['candidate']),indent=2)+'\n',encoding='utf-8')
for src,name in [(r/'images/candidate/Lokad.Lython.dll','current-core.dll'),(r/'images/before/Lokad.Lython.dll','baseline-core.dll'),(r/'catalog.json','representative.json'),(r/'source.patch','source.patch'),(r/'focused.json','focused.json'),(Path('PLAN.md'),'pre-measurement-plan.md'),(prior/'shared-worker-library.json','shared-worker-library.json')]:shutil.copyfile(src,b/name)
contract=(r/'selection.md').read_text(encoding='utf-8')+'''
One six-job quiet F4as_v7 comparison: rsplit sync/async, guarded sync, CSV sync,
report async and arithmetic loop sync. Two old/two candidate processes, 5s warmup
per role/job, seven rotated150ms rounds, normal GC/tiering. Report is affected;
arithmetic is an identical-instruction control, not an unchanged-binary claim.
Retain original adverse desktop controls and both metadata/setup failures, including
per-case snapshots produced before the stale-control failure. Allocation neutral;
static instruction counts are not CPU shares. All exact source/core/auxiliary/Ready/
runtime/golden/quiet/Closed/exit/join/fixture/archive gates retained. Persistent
evidence separate from owned128MiB RAM fixture; archive underlease/verify locally.
210s owner+30s stop+30s margin;240MiB OS floor+7MiB evidence headroom. No new VM
deletion/hardlink cleanup. Retain/refine/reject decision remains open; publication
postponed, full platform/package/Stress follows retention, not this prototype.
'''
(b/'contract.md').write_text(contract,encoding='utf-8');(b/'setup-contract.json').write_text(json.dumps(dict(jobs=jobs,ownerSeconds=210,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=7),indent=2)+'\n',encoding='utf-8')
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for name in ['collect.py','run.sh','current-core.dll','baseline-core.dll','representative.json','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','shared-worker-library.json','archive-owned.py']:a.add(b/name,arcname=name)
p=r/'setup-failures.md';s=p.read_text(encoding='utf-8');s=s.replace('but this\nprivate driver emits observations only after all cases: their partial measurements\nare unavailable and no performance inference is made.','and their individual per-case snapshots are preserved in the failed directory.\nThe aggregate JSON is unavailable because emission follows all cases. No results\nare discarded or used as controlled evidence.')
p.write_text(s,encoding='utf-8')
print('One six-job controlled comparison prepared; original driver/worker/core identities and ownership gates retained.')
