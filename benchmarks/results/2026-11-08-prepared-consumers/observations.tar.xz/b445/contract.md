R82: complete existing prepared single-input transport for member/receiver loads,
iterator acquisition and conditional branches. Source baseline913ea550 (production
unchanged by delivery/evidence71445454), frozen18b563e9 core in R79 source-pair.

Hypothesis: common single-input consumers still dispatch adjacent pure local or
constant loads and publish their temporary, although the existing operand
representation already forwards these for operators, assignment and return.
Removing this complete transport phase should reduce executed instructions in
ordinary text/CSV/helper/search scripts. Static counts are not CPU attribution;
normal-settings complete-script comparison decides magnitude/regression debt.

Use the existing eligibility proof: only constants and uncaptured, nonmirrored
local leaves directly adjacent to the consumer; never move across another effect.
Use existing ReadOperand/original operand spans. Keep physical output slots
distinct from borrowed sources; snapshot receiver/condition/iterable before any
protocol, admission callback or suspension. Preserve original retirement order,
pending iterator disposal, native list/tuple position ownership, first refusal,
host cancellation, awaited cleanup and escaping aliases. NativeBody preparation
and its unchanged proof remain separate, not expanded by operation name.

Displaced implementation: emitted leaf load/temporary publication at the selected
consumers, old assumption that source and result occupy the same physical slot,
duplicated raw source reads in synchronous/asynchronous handlers. No new argument
view, arena, dispatch framework, cache, owner, option or cancellation counter.

Bounded acceptance: source census before/after; focused Release tests covering
unbound names/spans, snapshots, captured/mirrored names, genuine async protocols,
iterator cleanup/cancellation/refusal/aliases. One existing diagnostic source pair
for text, CSV, guarded search, report control (both APIs). If needed one quiet-VM
confirmation sized for stable observations, retain all original adverse/failed
conditions. Explicit retain/refine/reject decision; no rigid percentage veto or
universal speedup claim. Batch full platform/package/stress only on retention.

One six-job quiet F4as_v7 comparison: rsplit sync/async, guarded sync, CSV sync,
report async and arithmetic loop sync. Two old/two candidate processes, 5s warmup
per role/job, seven rotated150ms rounds, normal GC/tiering. Report is affected;
arithmetic is an identical-instruction control, not an unchanged-binary claim.
Retain original adverse desktop controls and both metadata/setup failures, including
per-case snapshots produced before the stale-control failure. Allocation neutral;
static instruction counts are not CPU shares. All exact source/core/auxiliary/Ready/
runtime/golden/quiet/Closed/exit/join/fixture/archive gates retained. Persistent
evidence separate from owned128MiB RAM fixture; archive underlease/verify locally.
210s owner+30s stop+30s margin;240MiB OS floor+7MiB evidence headroom. No new VM
deletion/hardlink cleanup. Retain/refine/reject decision remains open; publication
postponed, full platform/package/Stress follows retention, not this prototype.
