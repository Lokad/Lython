from pathlib import Path
import hashlib,json,statistics
r=Path(__file__).parent;out={}
for api in ['warm-sync','warm-async']:
 d=json.loads((r/api/'measurements.json').read_text(encoding='utf-8'))
 assert all(d[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
 rows=[]
 for o in d['observations']:
  med={role:statistics.median(s['executionMilliseconds']/s['jobs']for s in o['samples']if s['image']==role)for role in ['before','before-control','candidate']}
  alloc={role:statistics.median(s['allocatedBytes']/s['jobs']for s in o['samples']if s['image']==role)for role in med}
  row=dict(case=o['caseId'],executionMilliseconds=med,allocationBytes=alloc,candidateElapsedPercent=[100*(med['candidate']/med[b]-1)for b in ['before','before-control']],oldSpreadPercent=100*(med['before-control']/med['before']-1))
  rows.append(row);print(api,o['caseId'],'elapsed%',*[round(v,2)for v in row['candidateElapsedPercent']],'old spread',round(row['oldSpreadPercent'],2))
 out[api]=rows
a=json.loads((r/'census-selected-before.json').read_text(encoding='utf-8'));b=json.loads((r/'census-selected-after.json').read_text(encoding='utf-8'))
out['instructionCensus']=[dict(case=x['id'],codes=[dict(name=m['name'],before=m['instructionCount'],after=n['instructionCount'])for m,n in zip(x['codes'],y['codes'])])for x,y in zip(a['cases'],b['cases'])]
assert a['cases'][-1]['codes']==b['cases'][-1]['codes'],'Control instructions differ.'
out['conclusion']='Allocation neutral; desktop elapsed is diagnostic/inconclusive with substantial unchanged-control/tiering variability. All original adverse and partial failed-attempt per-case observations retained. One quiet-VM confirmation selected.'
(r/'assessment-local.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
checks=dict(net11Internal=332,net11Public=155,net10Internal=332,net10Public=155,coreSHA256={f:hashlib.sha256(Path(f'src/Lokad.Lython/bin/Release/{f}/Lokad.Lython.dll').read_bytes()).hexdigest()for f in ['net11.0','net10.0']},productionInventoryMatchesFrozenCandidate=True,fullPlatformStressInstalled='pending retention')
assert checks['coreSHA256']['net11.0']==identity['coreSHA256']['candidate']
(r/'focused-final.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
print('Both actual frameworks focused pass, production inventory/core frozen match, arithmetic control instruction graph identical.')
