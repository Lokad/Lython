from pathlib import Path
import hashlib,json,struct
r=Path(__file__).resolve().parent;assert Path.cwd().resolve() in r.parents
p=r/'catalog.json';d=json.loads(p.read_text(encoding='utf-8'))
(r/'stale-control-metadata-catalog.json').write_bytes(p.read_bytes())
c=d['cases'][-1];assert c['id']=='diagnostic.integer-loop-control.small'
c['scale']='small';c['size']=4096;c['expectedOutputUtf8Bytes']=len(c['expectedOutput'].encode('utf-8'))
f=json.loads(c['fixtureJson']);f['size']=4096;c['fixtureJson']=json.dumps(f)
c['fixtureSha256']=hashlib.sha256(c['fixtureJson'].encode('utf-8')).hexdigest()
c['expectedOutputSha256']=hashlib.sha256(c['expectedOutput'].encode('utf-8')).hexdigest()
c['expectedFilesSha256']=hashlib.sha256(struct.pack('>i',0)).hexdigest()
for case in d['cases']:
 for text,digest in [('source','sourceSha256'),('fixtureJson','fixtureSha256'),('expectedOutput','expectedOutputSha256')]:assert hashlib.sha256(case[text].encode('utf-8')).hexdigest()==case[digest],(case['id'],digest)
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(r/'warm-sync').rename(r/'stale-control-metadata-failure')
(r/'setup-failures.md').write_text('''Initial six-case catalog was rejected by the existing five-case harness before samples.
The five-case attempt reached the new arithmetic control and failed its file golden:
the copied report metadata still contained the report artifact digest despite an empty
control fixture. All originals/stderr retained. Earlier cases had run, but this
private driver emits observations only after all cases: their partial measurements
are unavailable and no performance inference is made. Correct control size/output/
fixture/file digests; validate all source/fixture/output hashes before retrying.
No runtime source or golden expectation was relaxed to pass this correction.
''',encoding='utf-8')
print('All five catalog hashes verified; empty-file digest corrected, original failed metadata/results retained.')
