from pathlib import Path
import ast

lab = Path(__file__).resolve().parent
previous = lab.parent / 'retained-runtime-cpython-r661'

def read(path):
    return path.read_text(encoding='utf-8-sig')

def write(name, source):
    ast.parse(source)
    (lab / name).write_text(source, encoding='utf-8', newline='\n')

collect = read(previous / 'collect-evidence.py')
collect = collect.replace('2026-11-19-inline-forwarding-cpython', '2026-11-19-retained-defaults-cpython')
collect = collect.replace('== 6', '== 7').replace('B1091', 'B1102')
collect = collect.replace('assert len(job["samples"]) == len(labels)*3*5',
    'lanes = job["lanes"]\n    assert tuple(lanes) == (("compile-run", "compile") if case["id"] == "scripts.config-generated-guards.medium" else ("warm", "compile-run", "compile"))\n    assert len(job["samples"]) == len(labels)*len(lanes)*5')
collect = collect.replace('for lane in ["compile","warm","compile-run"]:', 'for lane in lanes:')
collect = collect.replace('out.mkdir(exist_ok=True)', 'assert len(rows) == 20\nout.mkdir(exist_ok=False)')
collect = collect.replace('memoryMeasurementIncluded=False)', 'memoryMeasurementIncluded=False, builtImageSource=built["imageSource"], verifiedBatches=400)')
write('collect-evidence.py', collect)

guide = read(previous / 'update-guide.py')
guide = guide.replace('2026-11-19-inline-forwarding-cpython', '2026-11-19-retained-defaults-cpython')
guide = guide.replace('06b40a712', '80cbf4988').replace('B1091', 'B1102')
guide = guide.replace("assert set(rows) == {(case, lane) for case in labels for lane in ('warm', *phases)}",
    "validator = 'scripts.config-generated-guards.medium'\nassert set(rows) == ({(case, lane) for case in labels for lane in ('warm', *phases)} | {(validator, lane) for lane in phases})")
where = guide.index("path = Path('docs/BENCHMARKS.md')")
guide = guide[:where] + '''phase.extend(f'| Generated validator | {name} | {metrics(rows[validator,lane],lane)} |' for lane,name in phases.items())
''' + guide[where:]
guide = guide.replace("start = text.index('B1084 measured')", "start = text.index('B1091 measured')")
guide = guide.replace('on duplicate processes per engine.', 'on duplicate processes per engine. The generated validator has compilation\nand compile-to-result rows only.')
guide = guide.replace('[Earlier B1084]', '[B1091 history](../benchmarks/results/2026-11-19-inline-forwarding-cpython/README.md) ·\n[Earlier B1084]')
write('update-guide.py', guide)
