from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = Path.cwd()
previous = lab.parent / 'retained-runtime-cpython-r661'
donor = lab.parent / 'positional-default-slots-r670'
validator_catalog = lab.parent / 'child-declaration-preparation-r668' / 'catalog.json'

def read(path):
    return path.read_text(encoding='utf-8-sig')

def load(path):
    return json.loads(read(path))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(name, source):
    if name.endswith('.py'):
        ast.parse(source)
    (lab / name).write_text(source, encoding='utf-8', newline='\n')

def save(name, data):
    write(name, json.dumps(data, ensure_ascii=False, indent=2) + '\n')

old = load(donor / 'quiet/config.json')
receipt = load(donor / 'quiet/archive-receipt.json')
pair = load(donor / 'frozen-identity.json')
files = pair['images']['candidate']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease'] and receipt['guestFixturesRemoved']
assert files == old['identity']['imageFiles']['candidate'] and len(files) == 32
revision = subprocess.check_output(['git','rev-parse','80cbf4988'], text=True).strip()
subprocess.run(['git','diff','--exit-code',pair['candidateCommit'],revision,'--','src','tests'],check=True)
save('build-revision.json', dict(sourceRevision=revision, imageSource=pair['candidateCommit'],
                                coreSHA256=files['Lokad.Lython.dll']))
frozen = lab / 'frozen/candidate'
frozen.mkdir(parents=True, exist_ok=True)
for name, h in files.items():
    source = donor / 'frozen/candidate' / name
    assert sha(source) == h
    if not (frozen / name).exists():
        shutil.copyfile(source, frozen / name)
assert {name: sha(frozen / name) for name in files} == files

catalog = load(previous / 'representative.json')
validator = 'scripts.config-generated-guards.medium'
extra = next(case for case in load(validator_catalog)['cases'] if case['id'] == validator)
catalog['cases'].append(extra)
assert len(catalog['cases']) == 7
save('representative.json', catalog)
shutil.copyfile(repo / 'benchmarks/cpython-worker.py', lab / 'cpython-worker.py')
catalog_hash = sha(lab / 'representative.json')
worker_hash = sha(lab / 'cpython-worker.py')
identity = dict(sourceRevision=revision, imageSource=pair['candidateCommit'],
    purpose='B1102 retained defaults and compiler checkpoint against CPython',
    imageFiles={'candidate':files}, auxiliaryFiles={k:v for k,v in files.items() if k != 'Lokad.Lython.dll'},
    coreSHA256={role:files['Lokad.Lython.dll'] for role in ('candidate','candidate-control')},
    catalogSHA256=catalog_hash, cpythonWorkerSHA256=worker_hash, normalAdapterPin='0.4.0')
save('identity.json', identity)
sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab / 'verify.log').open('wb') as log:
    subprocess.run([dotnet, frozen/'Lokad.Lython.Benchmarks.dll', '--compare','verify',
        '--catalog',lab/'representative.json','--dotnet',dotnet,'--python',Path('C:/Python313/python.exe'),
        '--python-worker',lab/'cpython-worker.py','--out',lab/'verify.json'],
        env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120,check=True)
verified = load(lab / 'verify.json')
assert verified['state'] == 'Completed' and verified['catalogSha256'] == catalog_hash
assert {name: sha(frozen / name) for name in files} == files

root = '/home/lokad/lython-bench-checks/retained-defaults-cpython-b1102-20261119'
unit = 'lython-b1102-retained-defaults-cpython-20261119'
previous_root = load(previous / 'config.json')['root']
lanes = ['warm', 'compile-run', 'compile']
jobs = [(case['id'], False) for case in catalog['cases']]
for name in ('collect.py', 'archive-owned.py', 'launch.py', 'retrieve.py', 'run.sh'):
    source = read(previous / name).replace(previous_root, root).replace('B1091','B1102')
    if name == 'collect.py':
        a = source.index('    for case_id,diagnostic in ')
        b = source.index('\n', a)
        source = source[:a] + f'    for case_id,diagnostic in {jobs!r}:' + source[b:]
        begin = '        with contextlib.ExitStack()as stack:'
        source = source.replace(begin, f'        lanes = ["compile-run", "compile"] if case_id == {validator!r} else {lanes!r}\n' + begin)
        source = source.replace('(["warm", "compile-run", "compile"] if index%2==0 else list(reversed(["warm", "compile-run", "compile"])))',
                                '(lanes if index%2==0 else reversed(lanes))')
        source = source.replace('for lane in ["warm", "compile-run", "compile"]]', 'for lane in lanes]')
        source = source.replace('result=dict(case=case_id,diagnostic=diagnostic,', 'result=dict(case=case_id,lanes=lanes,diagnostic=diagnostic,')
        assert source.count('for lane in lanes') == 1 and 'reversed(lanes)' in source
    elif name == 'archive-owned.py':
        source = source.replace("len(raw['jobs'])==6","len(raw['jobs'])==7").replace('jobs=6,','jobs=7,')
        assert "len(raw['jobs'])==7" in source and 'jobs=7,' in source
    elif name == 'retrieve.py':
        source = source.replace("['jobs']==6","['jobs']==7")
        assert "['jobs']==7" in source
    elif name == 'launch.py':
        source = source.replace('475','520')
        assert 'timedelta(seconds=520)' in source
    write(name, source)
    if name == 'run.sh':
        assert bytes([13]) not in (lab / name).read_bytes()

payload = lab / 'payload.tgz'
names = ['representative.json','identity.json','collect.py','archive-owned.py','run.sh','cpython-worker.py']
with tarfile.open(payload,'w:gz') as evidence:
    for name in names:
        evidence.add(lab / name, arcname=name)
config = dict(root=root,unit=unit,source=old['root'],sourceRole='candidate',sourceFiles=files,
    sourceCatalogSHA256=old['catalogSHA256'],catalogSHA256=catalog_hash,identity=identity,retireGroups=[],
    donorArchiveSHA256=receipt['archiveSHA256'],payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),
    unpackedBytes=sum((lab/name).stat().st_size for name in names),cpythonWorkerSHA256=worker_hash)
assert receipt['freeBytesAfterArchive'] > 182452224 + config['unpackedBytes'] + 1835008
save('config.json', config)
launcher = read(previous / 'remote-launch.py')
a, b = launcher.index('\nc=')+1, launcher.index('\nb=Path(')
launcher = launcher[:a] + 'c=' + repr(config) + launcher[b:]
write('remote-launch.py', launcher.replace('lython-b1091-fixtures','lython-b1102-fixtures'))
print('Verified all 32 files and seven CPython goldens. Quiet run uses the source-equivalent immutable image.')
