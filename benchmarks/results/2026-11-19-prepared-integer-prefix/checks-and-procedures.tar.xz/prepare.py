from pathlib import Path
import ast
import hashlib
import json

lab = Path(__file__).resolve().parent
old = lab.parent / 'positional-default-slots-r669'
external = lab.parent / 'retained-defaults-cpython-b1102'
read = lambda p: p.read_text(encoding='utf-8-sig')
load = lambda p: json.loads(read(p))
source = load(external / 'representative.json')
original = load(old / 'catalog.json')
selected = {
    'scripts.rule-default-closures',
    'scripts.annotated-rule-closures',
    'scripts.captured-rule-closures',
    'calls.defaults.medium',
    'scripts.report-forwarding.expanded',
    'scripts.config-generated-guards.medium',
}
source['cases'] = [case for case in source['cases'] if case['id'] in selected]
source['cases'].append(next(case for case in original['cases'] if case['id'] == 'calls.defaults.medium'))
assert {case['id'] for case in source['cases']} == selected
jobs = [
    ('scripts.rule-default-closures', 'warm'),
    ('scripts.annotated-rule-closures', 'warm'),
    ('scripts.captured-rule-closures', 'warm'),
    ('calls.defaults.medium', 'warm'),
    ('scripts.report-forwarding.expanded', 'warm'),
    ('scripts.config-generated-guards.medium', 'compile'),
    ('calls.defaults.medium', 'compile-run'),
]
def write(name, data):
    if name.endswith('.py'):
        ast.parse(data)
    (lab / name).write_text(data, encoding='utf-8', newline='\n')

write('catalog.json', json.dumps(source, indent=2, ensure_ascii=False) + '\n')
freeze = read(old / 'freeze-and-verify.py')
freeze = freeze.replace('child-declaration-preparation-r668', 'retained-defaults-cpython-b1102')
freeze = freeze.replace('positional-default-slots-r669', 'integer-chain-prefix-r665')
freeze = freeze.replace('3156df3b9', 'bc65698dd').replace('f8a7920e7', '80cbf4988')
freeze = freeze.replace("manifest=load(previous/'frozen-identity.json')", "manifest=load(previous/'identity.json')")
freeze = freeze.replace("manifest['candidateCommit']", "manifest['imageSource']")
freeze = freeze.replace("manifest['images']", "manifest['imageFiles']")
freeze = freeze.replace('== 7', '== 6').replace('all seven', 'all six')
write('freeze-and-verify.py', freeze)

stage = read(old / 'stage-quiet.py')
stage = stage.replace('"child-declaration-preparation-r668" / "quiet"', '"retained-defaults-cpython-b1102"')
stage = stage.replace('R669 final positional default tuple from evaluated slots', 'R671 compiler-prepared machine integer continuations')
stage = stage.replace('positional-default-slots-b1099', 'prepared-integer-prefix-b1103')
stage = stage.replace('b1099-positional-default-slots', 'b1103-prepared-integer-prefix').replace('b1099-fixtures','b1103-fixtures')
stage = stage.replace('seven-case, eight-job', 'six-case, seven-job')
stage = stage.replace("==8", "==7").replace("jobs=8,", "jobs=7,").replace("400", "398")
a, b = stage.index('        jobs = '), stage.index('        source=source[:a]')
stage = stage[:a] + "        jobs = " + repr(jobs) + "\n" + stage[b:]
marker = '    if name == "archive-owned.py":'
insert = '''    if name == "collect.py":
        source = source.replace("accumulate8seconds", "accumulate10seconds").replace("warmupSeconds=8", "warmupSeconds=10")
        source = source.replace("min(warmed)<8", "min(warmed)<10").replace("warmed[i]>=8", "warmed[i]>=10")
        source = source.replace("Deferred factory frame source pair", "Compiler-prepared integer prefix source pair")
    if name == "retrieve.py":
        source = source.replace("Deferred factory frame source pair", "Compiler-prepared integer prefix source pair")
'''
assert marker in stage
stage = stage.replace(marker, insert + marker)
stage = stage.replace('Prepared binding diagnostics source pair', 'Compiler-prepared integer prefix source pair')
stage += """
assert 'warmupSeconds=10' in collector and 'warmed[i]>=10' in collector
assert 'RuntimeMaxSec=540' in read(quiet / 'remote-launch.py')
assert len({case for case, lane in ast.literal_eval(re.search(r'^jobs = (.*)$', collector, re.M).group(1))}) == 6
"""
write('stage-quiet.py', stage)
write('quiet-space.json', json.dumps(dict(freeBytes=load(external / 'archive-receipt.json')['freeBytesAfterArchive'], replicas=[])) + '\n')
