set -eu
cd /mnt/d/code/Lython/.git/agent-worktrees/integer-chain-prefix-r665
notes=/mnt/d/code/Lython/.git/agent-notes/review-20261031/prepared-integer-prefix-r671
spec='(FullyQualifiedName~IntegerChain|FullyQualifiedName~ArithmeticPrecedence|FullyQualifiedName~IntegerBinarySemantics|FullyQualifiedName~CounterIntegerAdmission|FullyQualifiedName~FloatArithmeticPipeline|FullyQualifiedName~FrameIntegerLifetime|FullyQualifiedName~AugmentedIntegerCompatibility|FullyQualifiedName~ExactInteger|FullyQualifiedName~ExecutableStack|FullyQualifiedName~OperandLayout|FullyQualifiedName~BoundLoopNameStorage)&Category!=Stress'
status=0
for suite in Tests PublicApi.Tests; do
    log="$notes/ubuntu-net10-$suite.log"
    if ! ~/.dotnet/dotnet test "tests/Lokad.Lython.$suite" -c Release -f net10.0 --artifacts-path ~/lython-r671-artifacts --filter "$spec" > "$log" 2>&1; then
        status=1
    fi
    tail -n 8 "$log"
done
exit "$status"
