# Native operation facts — deletion proof and migration gate

Baseline: fully qualified8ec7bfab/beeb828e production, evidence throughc3d2d96e.
R272's frame-cache and lifetime-only forms are withdrawn; no flag/cache survives.

NativeReturnValue embeds an entire ExecutableInstruction. Every native consumer
is in LythonRuntime.Executable.NativeReturn.cs. Read operands need opcode and one
local/global/constant/closure index. Stores need closure index; calls need call-site
index; arithmetic needs its operator; formatting needs conversion/constant index.
All need the original Span. Conditional/None/empty-list-or-tuple need their opcode
and span, with graph branch inputs already recorded separately. Native consumers
never read physical InputStart/ResultSlot/LiveExtent/SecondInput/ThirdInput,
lookup slots, generic jump targets or ordinary prepared-result state.

Selected migration: NativeReturnValue retains opcode/span/one data word and its
existing operation/graph inputs/method/return/member spans. Extract the operand
once in its compiler construction, using existing checked opcode getters; reject
unknown compiler shapes explicitly. Delete Instruction field and every native
consumer of the ordinary instruction representation. Do not create another
instruction wrapper, evaluator, shape solver, guard VM, cache, controller or option.
Use readonly native node borrows where existing synchronous evaluation permits it;
no span/reference may escape or cross genuine suspension. Ordinary executable code
and the measured native guard/evaluator/calling convention remain.

Hypothesis: smaller compiled graph storage and less native node transport/property
redispatch, not elimination of all guard/evaluation work. Quantify allocation/CPU
separately with the existing complete-script tools. Preserve exact enum operators,
leaf source spans/live cells, conditional effects, eager arguments/defaults/keywords,
returns/annotations, Python errors, Unicode, cancellation, terminal admission,
reentry and explicit ownership. Existing native/helper/closure/error/storage tests
on actual11/10, six complete scripts compile/warm/fresh, then one short affected/
control VM comparison only if useful. No repeated unchanged package qualification.

Stop/revise if an actual consumer needs physical instruction positions or the
replacement does not eliminate the full embedded instruction. No speedup forecast;
any regression debt requires an explicit decision before retention. This is not
R268's slower whole-prefix routing migration. Publication remains postponed.
