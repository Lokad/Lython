from pathlib import Path
import json,subprocess,tempfile
r=Path(__file__).parent
wide={f'k{i:02}':i for i in range(17)};rows=[wide,{k:v+100 for k,v in wide.items()},dict(reversed(list(wide.items())))]
document='['+','.join(json.dumps(x,separators=(',',':'))for x in rows)+',{"k03":300,"k00":-1,"k03":301},{},{"é😀":[{"k00":7},{}]}]'
programs=[('shapes',"import json\nrows=json.loads("+repr(document)+")\nrows[0]['k00']=999\nassert rows[1]['k00']==100\nreturn json.dumps([rows,[list(row) for row in rows]],ensure_ascii=False,separators=(',',':'))",False)]
hook_document='['+','.join(json.dumps(x,separators=(',',':'))for x in rows[:2])+',{"k00":-1,"k00":-2}]'
programs.append(('hooks',"""import json
seen=[]
def hook(item):
 seen.append(item)
 nested=json.loads('{"probe":1,"data":[]}')
 item['alias']=[item['k00'],len(nested['data'])]
 with open('value.txt') as file:
  item['alias'].append(int(file.read()))
 return item
rows=json.loads(DOCUMENT,object_hook=hook)
assert seen[0] is rows[0] and seen[1] is rows[1]
rows[0]['alias'].append(rows[-1]['k00'])
return json.dumps([rows,[list(row) for row in rows]],ensure_ascii=False,separators=(',',':'))
""".replace('DOCUMENT',repr(hook_document)),True))
programs.append(('errors',"import json\nfirst=json.loads("+repr(json.dumps(wide))+")\nerrors=[]\nfor document in ['{\"k00\":','{\"k00\":0,}','{\"k00\":0,\"k01\": [1,2,]}']:\n try:json.loads(document)\n except json.JSONDecodeError as error:errors.append([error.pos,error.lineno,error.colno,error.doc==document])\nreturn json.dumps([first,errors],separators=(',',':'))",False))
cases=[]
for name,source,io in programs:
 # Lython's top-level return is wrapped in a function for independent CPython.
 wrapped='def script():\n'+''.join(' '+line+'\n'for line in source.splitlines())+'print(script())\n'
 with tempfile.TemporaryDirectory(prefix='lython-r110-semantics-')as folder:
  Path(folder,'value.txt').write_text('1',encoding='utf8')
  cp=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',wrapped],cwd=folder,text=True,encoding='utf8',capture_output=True,check=True)
  assert not cp.stderr;expected=cp.stdout.removesuffix('\n')
 cases.append(dict(name=name,source=source,expected=expected,io=io))
(r/'semantic-programs.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
cs='''using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.PublicApi.Tests;

public sealed class JsonRecordShapeTests
{
    [Theory]
    [MemberData(nameof(Programs))]
    public async Task ChangingRecordsPreservePythonValuesOrderAndOwnedResults(string name, string source, string expected, bool readsFile, bool asynchronous)
    {
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        using (var script = new LythonEngine().Compile(source, budget))
        {
            Assert.True(script.IsValid, string.Join(";", script.Diagnostics));
            var baseline = budget.ReservedBytes;
            async Task<LythonExecutionResult> Run()
            {
                var delayed = asynchronous ? new DelayedLythonHost() : null;
                var immediate = asynchronous ? null : new MockLythonHost();
                if (delayed is not null) delayed.SeedFile("/value.txt", "1");
                else immediate!.SeedFile("/value.txt", "1");
                ILythonHost host = (ILythonHost?)delayed ?? immediate!;
                var result = asynchronous ? await script.RunAsync(host) : script.Run(host);
                try
                {
                    Assert.True(result.Success, result.Failure?.Message);
                    Assert.Equal(expected, result.ReturnValue);
                    if (readsFile && delayed is not null) Assert.True(delayed.CompletedAsynchronously > 0);
                    return result;
                }
                catch { result.Dispose(); throw; }
            }
            using (var first = await Run())
            {
                var retained = budget.ReservedBytes;
                Assert.True(retained > baseline);
                using (var second = await Run())
                {
                    Assert.True(budget.ReservedBytes > retained);
                    Assert.Equal(expected, first.ReturnValue);
                }
                Assert.Equal(retained, budget.ReservedBytes);
            }
            Assert.Equal(baseline, budget.ReservedBytes);
        }
        Assert.Equal(0, budget.ReservedBytes);
    }

    // Independent isolated CPython 3.13 results, including full key order.
    public static IEnumerable<object[]> Programs()
    {
'''
for c in cases:
 for asynchronous in [False,True]:cs+='        yield return ['+', '.join([json.dumps(c['name']),json.dumps(c['source'],ensure_ascii=False),json.dumps(c['expected'],ensure_ascii=False),str(c['io']).lower(),str(asynchronous).lower()])+'];\n'
cs+='    }\n}\n'
Path('tests/Lokad.Lython.PublicApi.Tests/JsonRecordShapeTests.cs').write_text(cs,encoding='utf8')
print('Six public shape/hook/error/retained-owner cases generated with independent full CPython goldens.')
