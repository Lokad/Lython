from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).parent
for name in ['catalog.json','growth-catalog.json']:
 p=r/name;shutil.copyfile(p,r/('before-stdout-normalization-'+name));d=json.loads(p.read_text(encoding='utf8'))
 for c in d['cases']:
  stdout=c['expectedOutput'].replace('\r\n','\n');c['expectedOutput']=stdout;c['expectedOutputUtf8Bytes']=len(stdout.encode());c['expectedOutputSha256']=hashlib.sha256(stdout.encode()).hexdigest()
 p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(r/'stdout-correction.txt').write_text('Initial growth diagnostic completed successfully but stdout golden rejected Windows CPython raw CRLF against protocol LF. Original catalogs/tool/source retained. Normalize captured CPython stdout as existing comparison workers do; guest files remain byte-exact. No performance collection or runtime mutation occurred.\n',encoding='utf8')
print('Independent CPython stdout normalized to protocol LF; raw catalogs preserved.')
