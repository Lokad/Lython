# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Current contracts belong in docs. Historical designs, failures and adverse data
remain in [EXPERIMENTS](benchmarks/EXPERIMENTS.md) and linked immutable evidence.

## Actual delivery status

- **Committed/pushed, fully qualified production7265538c/core1aa68ce9.** Cached
  CI42496463028: Windows/Ubuntu actual .NET11/.NET10 full Release, original Stress
  both and installed core consumers. Later commits contain evidence/docs only.
  Shared compiler-fact correction, direct UTF-8 formatting/storage, original native
  returns and retained R62–R106 changes are delivered; do not replay qualification.
- **R106 delivered:** one existing native-return proof handles acyclic guards and
  selected return spans, with unchanged list factory borrowed by cold helper.
  No new engine/carrier/arena/owner/cache/options.205public/42internal focused per
  actual11/10. Guarded whole-script elapsed−13–17% across both APIs; coarse CPU
  supports gain, warm allocation neutral. Initial67e CSV+3% did not recur in1aa's
  bounded refinement; cause unresolved, original source/data retained. Compiler
  allocation+0.08–0.53%; Windows compiler timing uncertain, no universal compile gain.
- **Distinct established claims:** original native-return allocation−19.92/−19.31%,
  elapsed diagnostic. Formatting allocation−8.67%; controlled B102 elapsed/CPU−5–8%,
  original adverse15.125ms unexplained/preserved. R105 native JSON construction
  eager allocation−27–28%/elapsed−9–12%, streamed allocation−24%/elapsed−6–7%.
  Config coarseCPU+4–6% possible debt and older R76/R79/R95/R96/R102 debts remain
  separate. Favorable newer pairs do not silently repay old source-pair debt.
- **Current external baseline R109:** committed726/core1aa, CPython3.13.16,
  28jobs581.729s, all gates/archive/local verification pass; no users/fixtures.
  [BENCHMARKS](docs/BENCHMARKS.md) separates compile/warm/compile-to-result and names
  I/O/validation/cleanup boundaries. Warm CSV1.11x, returned CSV1.22–1.23x,
  JSON-lines0.92–0.93x, guarded text1.76–1.78x, eager normalization1.23–1.25x,
  streamed0.61–0.62x. Text/report controls remain variable. These are diagnostic
  named-source comparisons, no isolated causal gain. Startup/RSS/pending-I/O/
  embedding tails unmeasured. Prior15c and older guides preserved.
- **R108 assessment closed:**1110guest samples/5.58CPU seconds/64unknown5.77%.
  Formatting/JSON/dictionaries material; contexts0.72%leaf and call/frame3.96%
  despite84%inclusive. Groups overlap/inlining limits apply. No packaging dominance.
  Direct record filling, completed parser loops, UTF8 windows and final-buffer
  formatting already exist. R26/c4729 removed a stale-proof native formatted
  evaluator for correctness; preserve it. Original/corrected offline classifiers
  and failed pre-collection catalog ID retained; no profile retiming/prototype.

## Prioritized deliverables

1. **R110 selected next: capacity planning for complete known-layout JSON records.**
   Source-backed hypothesis: ReadJsonContainerAsync seeds four value slots even
   when expected immutable RecordKeys.Count knows a wider preceding object.
   EnsureRecordValueCapacity then performs replacement admission/allocation/copies.
   Use the existing layout/capacity machinery to fund the expected final value
   capacity once. Remove the fixed first-block heuristic for known layouts; retain
   growth for changed shapes and generic dictionaries. CSV's actual-width factory
   and owned-array adoption remain; no new builder/cache/pool/owner abstraction.
   Affects repeated wide JSON records, configuration/report/manifest scripts.
   Existing three-field comparisons do not measure this proposed benefit.
   Acceptance: identical Python keys/order/duplicates, nested and alternating wide/
   narrow shapes, partial/invalid documents, hooks that mutate or genuinely suspend,
   admission reentry, cancellation, first refusal before publication, retained
   aliases/results and cleanup/budget reuse. Capacity/overlap remains funded.
   Tradeoff: a narrower object following a wide layout may retain excess capacity
   or be refused earlier; document this conservative policy explicitly, never
   silently bypass refusal or refund unused storage still retained.
   First confirm exact factory/capacity source and actual growth on one wide-record
   full script; if absent stop this hypothesis. Then smallest coherent change,
   existing focused Release JSON/ownership checks, one short affected-script
   before/after with unchanged short-record/CSV controls. No new framework or broad
   ownership audit. Retain/correct/reject with explicit regression debt; bounded
   confirmation/refinement allowed for demonstrated uncertainty. Full delivery at
   a coherent retained boundary, not another per-edit CPython checkpoint.

2. **Remaining substantial redesign roadmap.** Complete call/frame construction,
   operand transport, per-record storage, text conversions and repeated frontend
   analysis remain candidates requiring demonstrated removable work. Current gates
   already establish direct arguments/final slots/native workstate, unboxed64-bit
   sum, cheap small-counter admission, UInt128 parsing, shared lexical facts and
   immutable builtins, executable imports and efficient comparison file handles.
   Do not reimplement absent phases. Old bulk CSV6–8% evidence/control regression
   remains; current keys/array adoption removed its proposed copying. Preserve
   slower R71 arena/control/wide-carrier lessons. Before a new prototype name its
   complete affected scripts, hypothesis, eliminated work/storage and displaced
   implementation, semantic/ownership/cancellation acceptance, bounded controlled
   comparison and completion/debt decision. Source selection~20min; unresolved
   attribution means uncertainty, not permission for speculative tags/caches/JIT/
   duplicate evaluators. No permanent ban on evidence-backed reconsideration.

3. **Independent regex contract/implementation.** Lython owns native UTF8 names,
   byte captures/scalar positions/original windows, Python flags/replacements/errors,
   ownership/current cancellation and one frontend/runtime/import provider. Core
   remains backend-independent; optional adapter nonpackable, ordinary0.4 pin.
   Exact dev55/d6067925 development checks86internal/514public peractual11/10 remain.
   Missing producer capabilities: DetailedData separate preparation/working owner,
   native-name enumeration and cursor creation without retaining an earlier token.
   Existing adapter-local bridges remain justified; development producers are valid.
   Separate contract forwarding/unwind, semantic tests and actual backend performance.
   Qualify affected final adapter against a released package when supplied; this
   never stops independent core work. No sibling edits/builds or unchanged replays.

## Acceptance and operating policy

Bounded confirmation, refinement and measurement correction are allowed. Timeout,
unstable unchanged controls or inconclusive data establish uncertainty, not failed
design. Size runs for usable quiet-VM observations. Preserve adverse results and
original failed conditions. Percentages inform decisions rather than veto useful
simplification. Separate architecture, allocation, demonstrated CPU and latency.
Temporary setbacks require an explicit completion milestone and regression decision.

AGENTS.md governs managed safety/stack admission, host mediation, cancellation and
shared coarse admission/preflights/replacement overlap. No unsafe/Unsafe/native
probing, independent caps/fuel/quotas, tracing/weak reclamation/forced GC, silent
regex fallback or abandoned work. Aliases/results/cache/pending users remain funded
until awaited cleanup; first refusal is terminal, no retries. Bounded host executions
remain the initial long-stream ownership boundary. No hidden default allowance.

Focused Release iteration; no overlapping local builds/tests/measurements. Fresh
build after timestamp-preserving restores. Batch actual11/10 Windows/Ubuntu/original
Stress/installed core at delivery. UTF8 text. Only core explicit Release pack into
artifacts/nuget; no publication/tagging. VM lokad@20.166.121.73, key
~/.ssh/id_lython-bench.pem. Persistent evidence separate from owned RAM: join users,
copy/verify maps, unmount, archive under lease and verify locally. No evidence deletion;
core hardlinks require fresh exact-byte/inode proof preserving paths and aliases.

B450–B467 terminal/cached/archived/locally verified; no VM users/fixtures. All recorded
terminal CI runs cached, including42496463028/726,42488128858/a7 and42484943603/15c;
never query again. Observations>=5min, no duplicate dispatch. Prior active plans
preserved privately; immutable measurement/qualification history stays separate.
