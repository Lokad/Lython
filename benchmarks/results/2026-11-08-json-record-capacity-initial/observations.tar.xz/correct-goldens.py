from pathlib import Path
import base64,hashlib,json,shutil,struct,subprocess,tempfile
r=Path(__file__).parent
for filename in ['catalog.json','growth-catalog.json']:
 p=r/filename;shutil.copyfile(p,r/('initial-'+filename));d=json.loads(p.read_text(encoding='utf8'))
 for c in d['cases']:
  if c['id'] not in ['scripts.report-render.wide-records','scripts.report-render.alternating-records','scripts.report-render.wide-growth-proof']:continue
  f=json.loads(c['fixtureJson'])
  with tempfile.TemporaryDirectory(prefix='lython-r110-goldens-corrected-')as folder:
   folder=Path(folder)
   for n,v in f['inputFiles'].items():(folder/n).write_bytes(base64.b64decode(v))
   result=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',c['source']],cwd=folder,capture_output=True,check=True);assert not result.stderr
   outputs={n:(folder/n).read_bytes()for n in f['outputFiles']}
   digest=hashlib.sha256();digest.update(struct.pack('>I',len(outputs)))
   for n,v in sorted(outputs.items()):
    key=n.encode();digest.update(struct.pack('>I',len(key)));digest.update(key);digest.update(struct.pack('>I',len(v)));digest.update(v)
   f['outputFiles']={n:base64.b64encode(v).decode()for n,v in outputs.items()}
   c['fixtureJson']=json.dumps(f,ensure_ascii=False,separators=(',',':'));c['fixtureSha256']=hashlib.sha256(c['fixtureJson'].encode()).hexdigest()
   c['expectedFilesSha256']=digest.hexdigest();c['expectedOutput']=result.stdout.decode();c['expectedOutputSha256']=hashlib.sha256(result.stdout).hexdigest();c['expectedOutputUtf8Bytes']=len(result.stdout)
 p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(r/'golden-correction.txt').write_text('Before any worker/timing: initial generator used JSON-map digest instead of the existing length-prefixed ComparisonFileFixture.Digest and left the small growth fixture output map at3072rows. Corrected to existing protocol digest and actual independent CPython files. Initial source/catalogs retained. No worker/runtime/timing changes.\n',encoding='utf8')
print('Corrected to the existing fixture digest and complete independent CPython output maps before worker validation.')
