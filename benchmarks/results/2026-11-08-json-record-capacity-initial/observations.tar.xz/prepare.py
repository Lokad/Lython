from pathlib import Path
import base64,copy,hashlib,json,os,shutil,subprocess,tempfile
r=Path(__file__).parent;old=r.parent/'conditional-helpers-r106/refinement';r.mkdir(exist_ok=True)
i=json.loads((old/'identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
baseline=dict(sourceRevision='7265538c',coreSHA256=i['coreSHA256']['candidate'],productionSources=i['productionSources'],qualification='Cached full CI42496463028, Windows/Ubuntu actual11/10/originalStress/installed core. Current HEADdea4504d has unchanged production.')
(r/'baseline.json').write_text(json.dumps(baseline,indent=2)+'\n',encoding='utf8')
images=r/'images';images.mkdir()
for role in ['before','candidate']:shutil.copytree(old/'images/candidate',images/role,copy_function=os.link)
assert hashlib.sha256((images/'before/Lokad.Lython.dll').read_bytes()).hexdigest()==baseline['coreSHA256']
shutil.copyfile('PLAN.md',r/'pre-implementation-plan.md')
catalog=json.loads((r.parent/'json-cpython-r103/representative.json').read_text(encoding='utf8'))
plain=next(c for c in catalog['cases'] if c['id']=='scripts.report-render.large')
base=json.loads(plain['fixtureJson']);records=json.loads(base64.b64decode(base['inputFiles']['records.json']))
assert len(records)==3072
def make_case(kind,rows):
 c=copy.deepcopy(plain);c['id']='scripts.report-render.'+kind;c['scale']=kind
 f=copy.deepcopy(base);f['size']=len(rows)
 f['inputFiles']['records.json']=base64.b64encode(json.dumps(rows,ensure_ascii=False,separators=(',',':')).encode()).decode()
 c['size']=len(rows);c['fixtureJson']=json.dumps(f,ensure_ascii=False,separators=(',',':'));c['fixtureSha256']=hashlib.sha256(c['fixtureJson'].encode()).hexdigest()
 # Independent trusted CPython, complete stdout and written-file golden.
 with tempfile.TemporaryDirectory(prefix='lython-r110-goldens-') as folder:
  folder=Path(folder)
  for n,v in f['inputFiles'].items():(folder/n).write_bytes(base64.b64decode(v))
  result=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',c['source']],cwd=folder,capture_output=True,check=True)
  assert not result.stderr
  c['expectedOutput']=result.stdout.decode();c['expectedOutputUtf8Bytes']=len(result.stdout);c['expectedOutputSha256']=hashlib.sha256(result.stdout).hexdigest()
  outputs={n:base64.b64encode((folder/n).read_bytes()).decode() for n in f['outputFiles']}
  c['expectedFilesSha256']=hashlib.sha256(json.dumps(outputs,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 return c
def widen(row,index):return {**row,**{f'column_{j:02}':index*(j+1)+index%7 for j in range(3,24)}}
wide=[widen(v,i)for i,v in enumerate(records)]
mixed=[widen(v,i)if i%2==0 else v for i,v in enumerate(records)]
cases=[make_case('wide-records',wide),make_case('alternating-records',mixed),plain,*[next(c for c in catalog['cases']if c['id']==id)for id in ['scripts.csv-summary-functions.large','scripts.json-summary-helpers.large']]]
assert len(cases)==5
out={**catalog,'cases':cases};(r/'catalog.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(r/'growth-catalog.json').write_text(json.dumps({**catalog,'cases':[make_case('wide-growth-proof',wide[:8])]},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
proposal='''R110 selected one existing-capacity change. JSON seeds4slots even when preceding immutable RecordKeys.Count knows24fields, causing admitted8/16/32replacement arrays. Confirm actual EnsureRecordValueCapacity admissions in one8record complete read/parse/render/write script through a public budget wrapper (diagnostic stacks only, never timed). Existing catalog/report source and exact independent CPython3.13 full stdout/files reused; two affected3072record24field/alternating24and3field scripts, three unchanged report/CSV/JSON controls. Baseline726/core1aa fully qualified. No new framework/API/cache/pool/owner, CSV actual-width/arrayadoption unchanged. Retain growth for changing shapes; capacity hint stays charged and may deny a narrow following record earlier. Semantic/cancellation/refusal/reentry/retained-alias/cleanup checks before freezing. Warm allocation diagnostic bothAPIs plus one bounded controlled source pair on existing VM/worker/protocol. No speed predicted; keep all adverse controls. Full qualification only at retained boundary, no per-edit CPython campaign/publication.
'''
(r/'proposal.md').write_text(proposal,encoding='utf8')
print('R110 baseline frozen, five-case catalog and independent full CPython goldens prepared.',flush=True)
