from pathlib import Path
import ast,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'conditional-helpers-r106/refinement/b465';b=r/'b468';b.mkdir()
source=json.loads((r/'identity.json').read_text(encoding='utf8'));prior=json.loads((old/'identity.json').read_text(encoding='utf8'))
jobs=[['scripts.report-render.wide-records','warm'],['scripts.report-render.wide-records','warm-async'],['scripts.report-render.alternating-records','warm'],['scripts.report-render.large','warm'],['scripts.csv-summary-functions.large','warm'],['scripts.json-summary-helpers.large','warm']]
identity={**prior,'sourceRevision':source['candidateSource'],'baselineSource':source['baselineSource'],'coreSHA256':{role:source['coreSHA256']['before' if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},'productionSources':source['productionSources'],'qualification':source['qualification'],'jobs':jobs}
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
for name in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
 s=(old/name).read_text(encoding='utf8').replace('refined-conditional-helpers-b465-20261108','json-record-capacity-b468-20261108').replace('lython-b465-refined-conditional-helpers','lython-b468-json-record-capacity').replace('refined-conditional-helpers-b465-launch.py','json-record-capacity-b468-launch.py').replace('lython-b465-fixtures','lython-b468-fixtures')
 if name=='collect.py':
  a=s.index('jobs=');z=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[z:]
  a=s.index("purpose='");z=s.index("',\n",a);s=s[:a]+"purpose='R110 known-layout capacity; complete wide both APIs and alternating wide/narrow reports, unchanged short report/CSV/JSON controls"+s[z:]
 if name=='launch.py':s=s.replace("reference=base/'native-json-b463-20261108/candidate'","reference=base/'refined-conditional-helpers-b465-20261108/candidate'")
 if name=='archive-owned.py':s=s.replace(",'shared-worker-common.json'",'').replace(", 'shared-worker-common.json'",'')
 (b/name).write_text(s,encoding='utf8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
for src,name in [(r/'images/candidate/Lokad.Lython.dll','current-core.dll'),(r/'catalog.json','representative.json'),(r/'identity.json','focused.json'),(r/'source.patch','source.patch'),(r/'pre-measurement-plan.md','pre-measurement-plan.md')]:shutil.copyfile(src,b/name)
(b/'setup-contract.json').write_text(json.dumps(dict(jobs=jobs,ownerSeconds=210,stopSeconds=30,observationMarginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=7,referenceSource='7265538c',referenceCore=source['coreSHA256']['before'],noEvidenceDeleted=True),indent=2)+'\n',encoding='utf8')
contract='''R110 one six-job controlled source pair1aa/eb14 (exact hashes identity). Only one known-layout capacity choice; earlier4slots become retained-layout count, preserving generic growth. Baseline726 fully qualified cachedCI42496463028.897public/193internal focused Release peractual11/10 pass. Eight-record complete report budget diagnostic: old21replacement admissions, new0; full stdout/file goldens and balance0, never timed. Two affected3072record24field/alternating24and3field complete read/parse/format/write scripts, same existing report source, independent CPython3.13 full stdout/files. Three byte-identical short report/CSV/JSON controls. No new framework/runtime cache/owner/dispatch/policy; smaller shapes may retain excess hinted capacity or deny earlier, document it; all storage funded. Current token/refusal/reentry/retained aliases/awaited cleanup unchanged. Initial malformed fixture digest/Windows stdout and unused theory-name analyzer failures retained, all corrected before collection.
Same frozen worker7cf/normal optional0.4/normalGC/tiering, two processes percore,5swarmup/job,7rotated150msrounds, coarse process CPU.210sowner+30stop+30margin. Complete mediated RAM I/O/full validation/prior-result cleanup included; compilation/startup/staging/final cached teardown excluded. No frontend/sourcepublication/regexperformance/heap/startup/tail claim, no new CPython checkpoint. Keep all adverse controls and actual budget tradeoffs. Source exact full delivery independent/pending.
Reuse archived B4651aa/baseline allauxverified, uploadonly newcore.240MiBOSfloor+7MiBevidence+actualuncompressedpayload fresh preflight; no maintenance unless needed, no deletion. Persistent data, owned128MiB RAM fixtures, all Ready/source/core/aux/quiet/golden/Closed/exit/join/unmount/archive/local gates.
'''
(b/'contract.md').write_text(contract,encoding='utf8')
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for n in ['collect.py','run.sh','current-core.dll','representative.json','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','archive-owned.py']:a.add(b/n,arcname=n)
print('B468 six jobs prepared, same worker/protocol, baseline1aa reused, no framework/producer changes.')
