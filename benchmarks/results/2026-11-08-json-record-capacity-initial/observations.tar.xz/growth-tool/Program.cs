using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

// Public-budget admission evidence only. Stack capture is never timed.
var image=Path.GetFullPath(args[0]);
AssemblyLoadContext.Default.Resolving+=(_,name)=>File.Exists(Path.Combine(image,name.Name+".dll"))?Assembly.LoadFrom(Path.Combine(image,name.Name+".dll")):null;
var benchmark=Assembly.LoadFrom(Path.Combine(image,"Lokad.Lython.Benchmarks.dll"));
using var catalog=JsonDocument.Parse(File.ReadAllBytes(args[1]));var item=catalog.RootElement.GetProperty("cases")[0];
var fixtureType=benchmark.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileFixture",true)!;
var fixture=fixtureType.GetMethod("Parse")!.Invoke(null,[item.GetProperty("fixtureJson").GetString()])!;
var path=Path.GetFullPath(Path.Combine(Path.GetTempPath(),"lython-comparison-files-r110-proof-"+Guid.NewGuid().ToString("N")));
var hostType=benchmark.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileHost",true)!;
var host=(ILythonHost)Activator.CreateInstance(hostType,BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance,null,[fixture,path],null)!;
var root=new Hook(new LythonMemoryBudget(16*1024*1024));
try
{
 using(var script=new LythonEngine().Compile(item.GetProperty("source").GetString()!,root))
 {
  if(!script.IsValid)throw new InvalidDataException(string.Join(";",script.Diagnostics));
  hostType.GetMethod("Reset")!.Invoke(host,null);root.Armed=true;
  using(var result=script.Run(host))
  {
   root.Armed=false;
   if(!result.Success||result.StandardOutput!=item.GetProperty("expectedOutput").GetString())throw new InvalidDataException(result.Failure?.Message??"stdout golden");
   var outputs=hostType.GetMethod("ReadOutputs")!.Invoke(host,null)!;
   var digest=(string)fixtureType.GetMethod("Digest")!.Invoke(null,[outputs])!;
   if(digest!=item.GetProperty("expectedFilesSha256").GetString())throw new InvalidDataException("complete file golden");
  }
 }
 if(root.Budget.ReservedBytes!=0)throw new InvalidDataException("ownership did not end");
 Console.WriteLine(JsonSerializer.Serialize(new{coreSHA256=Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))),growthAdmissions=root.Growth,recordAdmissions=root.Records,fullGoldensPassed=true,balance=root.Budget.ReservedBytes,diagnosticOnly=true}));
}
finally
{
 (host as IDisposable)?.Dispose();
 var temp=Path.GetFullPath(Path.GetTempPath()).TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar;
 if(!path.StartsWith(temp,StringComparison.OrdinalIgnoreCase)||!Path.GetFileName(path).StartsWith("lython-comparison-files-r110-proof-",StringComparison.Ordinal))throw new InvalidDataException("owned fixture boundary");
 if(Directory.Exists(path))Directory.Delete(path,true);
}

sealed class Hook(LythonMemoryBudget budget):ILythonMemoryBudget
{
 public LythonMemoryBudget Budget=>budget;
 public bool Armed;
 public List<long> Growth=[];
 public List<long> Records=[];
 public ILythonMemoryScope CreateScope()=>new Scope(budget.CreateScope(),this);
 public bool TryReserve(long bytes,[NotNullWhen(true)]out ILythonMemoryReservation? reservation)=>Wrap(budget,bytes,out reservation);
 public bool Wrap(ILythonMemoryBudget owner,long bytes,[NotNullWhen(true)]out ILythonMemoryReservation? reservation)
 {
  if(!owner.TryReserve(bytes,out var inner)){reservation=null;return false;}
  reservation=new Reservation(inner,this);return true;
 }
 public void Observe(long previous,long next)
 {
  if(!Armed||next<=previous)return;
  var names=new StackTrace().GetFrames().Select(f=>f.GetMethod()?.Name).ToArray();
  if(names.Contains("EnsureRecordValueCapacity"))Growth.Add(next-previous);
  if(names.Contains("CreateRecord"))Records.Add(next-previous);
 }
 sealed class Scope(ILythonMemoryScope inner,Hook root):ILythonMemoryScope
 {
  public ILythonMemoryScope CreateScope()=>new Scope(inner.CreateScope(),root);
  public bool TryReserve(long bytes,[NotNullWhen(true)]out ILythonMemoryReservation? reservation)=>root.Wrap(inner,bytes,out reservation);
  public void Dispose()=>inner.Dispose();
 }
 sealed class Reservation(ILythonMemoryReservation inner,Hook root):ILythonMemoryReservation
 {
  public long Bytes=>inner.Bytes;
  public bool TryResize(long bytes){var previous=inner.Bytes;if(!inner.TryResize(bytes))return false;root.Observe(previous,bytes);return true;}
  public void Dispose()=>inner.Dispose();
 }
}
