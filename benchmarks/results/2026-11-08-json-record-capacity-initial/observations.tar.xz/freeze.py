from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;b=json.loads((r/'baseline.json').read_text(encoding='utf8'))
sources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in b['productionSources']}
changed={p for p,h in sources.items()if h!=b['productionSources'][p]};assert changed=={'src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs'},changed
counts={}
for label in ['public11','public10','internal11','internal10']:
 import re
 s=(r/(label+'.log')).read_text(encoding='utf8');match=re.search(r'Passed!.*Failed:\s+0, Passed:\s+(\d+),',s);assert match,label;counts[label]=int(match[1])
copies=[Path(p)/'Lokad.Lython.dll'for p in ['src/Lokad.Lython/bin/Release/net11.0','tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0','tests/Lokad.Lython.Tests/bin/Release/net11.0']]
assert len({hashlib.sha256(p.read_bytes()).hexdigest()for p in copies})==1
core=r/'images/candidate/Lokad.Lython.dll';core.unlink();shutil.copyfile(copies[0],core)
identity=dict(baselineSource='Fully qualified7265538c/core1aa68ce9, cached CI42496463028',candidateSource='dea4504d plus one known-layout JSON capacity choice, no new ownership or dispatch machinery',coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},productionSources=sources,focusedChecks=counts,qualification='Focused actual11/10 semantic/ownership/cancellation/refusal/retained-result checks pass. Exact new-source full qualification pending independently.',controls='Three unchanged report/CSV/JSON controls, same worker/host/optional0.4/normalGC/tiering. Two affected3072record24field/alternating24and3field read/parse/render/write scripts; independent CPython full goldens.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs']))
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
tool=r/'candidate-growth-tool';shutil.copytree(r/'growth-tool/out',tool,copy_function=os.link);p=tool/'Lokad.Lython.dll';p.unlink();shutil.copyfile(core,p)
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
with(r/'candidate-growth.json').open('w',encoding='utf8')as output:subprocess.run([env['DOTNET_HOST_PATH'],str(tool/'growth.dll'),str(r/'images/candidate'),str(r/'growth-catalog.json')],env=env,stdout=output,check=True)
proof=json.loads((r/'candidate-growth.json').read_text(encoding='utf8'));assert proof['fullGoldensPassed']and proof['balance']==0 and not proof['growthAdmissions']
assert proof['coreSHA256']==identity['coreSHA256']['candidate']
old=r.parent/'native-json-construction-r105'
for name in ['measure.py','assess-local.py']:
 s=(old/name).read_text(encoding='utf8').replace('R105','R110')
 if name=='assess-local.py':
  a=s.index("out['limitations']=");z=s.index("\n(r/'assessment-local",a)
  s=s[:a]+"out['limitations']='R110 existing same-process ALC allocation diagnostic, normalGC/tiering; elapsed is Run only, allocation includes host reset/full validation/result cleanup. Desktop elapsed/coarseCPU not controlled CPU confirmation. Wide and alternating-shape complete reports are affected, three unchanged report/CSV/JSON controls. No new frontend measurement or speed claim from allocations alone.'"+s[z:]
 (r/name).write_text(s,encoding='utf8')
print('R110 frozen',json.dumps(identity['coreSHA256']),counts,'actual growth admissions',len(proof['growthAdmissions']),flush=True)
