from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;i=json.loads((r/'identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
with tarfile.open(r/'initial-checked-source.tar.xz','w:xz')as a:
 for p in ['src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs','src/Lokad.Lython/Runtime/PyDict.Records.cs','docs/RUNTIME.md','CHANGELOG.md','tests/README.md','tests/Lokad.Lython.PublicApi.Tests/JsonRecordShapeTests.cs','tests/Lokad.Lython.PublicApi.Tests/JsonReadContinuationTests.cs']:a.add(p,arcname=p)
f=r/'refinement';f.mkdir();shutil.copyfile('PLAN.md',f/'pre-implementation-plan.md')
proposal='''One bounded R110 refinement justified by observed mixed-shape allocation+14.7%, not speculative elapsed attribution. Initialeb14/B468 source, binaries, all goldens/logs/measurements and startup capacity tradeoff retained. Restore the baseline JSON four-slot unknown-record seed. In the existing ordered-prefix EnsureRecordValueCapacity, replace geometric targetCount sizing with the already-authoritative immutable layout.Count only when a prefix actually outgrows its current storage. Eliminate8/16replacement arrays for a24field known layout, retain initial4/one32growth. A3field narrow record afterwide never grows and keeps its small storage. Prefixes beyond the initial capacity can still conservatively retain extra layout slots or deny earlier; document that remaining tradeoff. Existing guard targetCount<=currentCapacity, reserve replacement overlap, cancellation and partial-write rollback remain. No new threshold/cache/predictor/owner/branch/options; generic shape mutation and CSV actual-width/adoption unchanged.
Recheck same897public/193internal peractual11/10, same full five-script allocation diagnostic/growth proof and same six-job controlled source pair against unchanged1aa, then decide retention/debt. Initial compiler/worker/CPython protocols unchanged; no new framework or external refresh. Full exact-source delivery only at retained boundary. No causal claim for initial timing until B468 archived.\n'''
(f/'proposal.md').write_text(proposal,encoding='utf8')
# Restore bytes normally, with a fresh timestamp; do not preserve stale snapshots.
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs')
import subprocess
p.write_bytes(subprocess.check_output(['git','show','HEAD:'+p.as_posix()]))
p=Path('src/Lokad.Lython/Runtime/PyDict.Records.cs');s=p.read_text(encoding='utf8');needle='''        var capacity = NativeCapacity(targetCount);
        using var replacement = _memoryGovernor!.ReserveTemporary''';assert s.count(needle)==1
s=s.replace(needle,'''        // The ordered prefix has outgrown its backing. Its remaining keys are
        // already immutable, so admit the layout's final value capacity once.
        var capacity = NativeCapacity(_recordKeys!.Count);
        using var replacement = _memoryGovernor!.ReserveTemporary''');p.write_text(s,encoding='utf8')
p=Path('docs/RUNTIME.md');s=p.read_text(encoding='utf8');a=s.index('Nonempty objects with a retained layout');z=s.index('Mutable records remain independent.',a)
s=s[:a]+'''When an ordered record prefix outgrows its value backing, it reserves the
retained layout's full value capacity, avoiding repeated replacement arrays.
Shorter prefixes can keep their initial storage. A narrower record that does grow
can retain spare hinted capacity or be refused earlier; that capacity stays funded.
Refusal never retries a smaller allocation. Changed shapes retain ordinary
admitted dictionary growth.
'''+s[z:];p.write_text(s,encoding='utf8')
p=Path('CHANGELOG.md');s=p.read_text(encoding='utf8').replace('Use retained JSON record layouts to admit value capacity before construction,\n  avoiding repeated replacement arrays for wide records.','Use retained JSON record layouts to admit their final value capacity on growth,\n  avoiding repeated replacement arrays for wide records.');p.write_text(s,encoding='utf8')
shutil.copyfile(r/'qualify.py',f/'qualify.py')
p=Path('PLAN.md');s=p.read_text(encoding='utf8');s=s.replace('R110 active prototype: capacity planning','R110 bounded construction refinement: capacity planning')
s=s.replace('   now implemented;9new public shape/real-async/lifetime cases plus897focused\n   .NET11public checks pass, .NET10/internal checks pending. No speed claim yet.','   initially implemented;897public/193internal peractual11/10 pass. Initial wide\n   allocation−11%, alternating24/3field+14.7%; desktop elapsed variable. Initial\n   eb14/B468 preserved. One refinement restores baseline object seeding and uses\n   immutable layout.Count on actual value-storage growth, removing intermediate\n   replacement arrays while short prefixes keep small storage. Same semantic/growth/\n   allocation and controlled checks before final decision; full delivery pending.')
p.write_text(s,encoding='utf8')
print('Initial source frozen; one shared value-growth capacity choice refined without a new mechanism.')
