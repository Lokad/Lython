from pathlib import Path
import ast
import hashlib
import json
import os
import re
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = Path.cwd()
prior = lab.parent / 'remaining-runtime-attribution'
donor = lab.parent / 'shared-executable-graph'
read = lambda path: path.read_text(encoding='utf-8-sig')
load = lambda path: json.loads(read(path))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def write(name, source):
    if name.endswith('.py'):
        ast.parse(source)
    (lab / name).write_text(source, encoding='utf-8', newline='\n')

def save(name, value):
    write(name, json.dumps(value, ensure_ascii=False, indent=2) + '\n')

revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert revision.startswith('645a0fcd1')
assert not subprocess.check_output(['git', 'status', '--porcelain'])
measured = load(donor / 'frozen-identity.json')['candidateCommit']
assert measured.startswith('356a93e25')
subprocess.run(['git','diff','--exit-code',measured,revision,'--','src','global.json','Directory.Build.props',
    'Directory.Packages.props','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py'],check=True)
old = load(donor / 'quiet/config.json')
terminal = load(donor / 'quiet/terminal-status.json')
receipt = load(donor / 'quiet/archive-receipt.json')
assert terminal['exitCode'] == '0' and terminal['receipt'] == receipt
assert all(receipt[name] for name in ('complete','allWorkersJoined','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256'] == sha(donor/'quiet/observations.tgz')
source = donor/'frozen/candidate'
files = old['identity']['imageFiles']['candidate']
assert len(files) == 32 and {name:sha(source/name) for name in files} == files
image = lab/'candidate'
image.mkdir(exist_ok=True)
for name in files:
    shutil.copyfile(source/name,image/name)
assert {name:sha(image/name) for name in files} == files

catalog = load(lab.parent/'captured-factory-delivery-cpython/representative.json')
jobs = [
    ('candidate-annotated', 'scripts.annotated-rule-closures', 'warm'),
    ('candidate-nested', 'scripts.annotated-rule-closures.nested-factories', 'warm'),
    ('candidate-postponed-nested', 'scripts.annotated-rule-closures.nested-factories.postponed', 'warm'),
]
prior_postponed = load(lab.parent/'postponed-cpython-b1156/representative.json')
cases = {case['id']:case for case in catalog['cases'] + prior_postponed['cases']}
catalog['cases'] = [cases[case] for _,case,_ in jobs]
save('catalog.json',catalog)
catalog_path=lab/'catalog.json'
sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as output:
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog_path,
                    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',repo/'benchmarks/cpython-worker.py',
                    '--out',lab/'verify.json'],env=env,stdout=output,stderr=subprocess.STDOUT,check=True,timeout=140)
verified = load(lab/'verify.json')
assert verified['state']=='Completed' and verified['catalogSha256']==sha(catalog_path)
assert {name:sha(image/name) for name in files}==files

root='/home/lokad/lython-bench-checks/post-capture-factory-attribution-b1214-20261120'
unit='lython-b1214-post-capture-factory-attribution-20261120'
original=load(prior/'config.json')
purpose='B1214 post-capture factory attribution'
core='Lokad.Lython.dll'
identity=dict(sourceRevision=revision,imageSource=measured,purpose=purpose,diagnosticOnly=True,
              imageFiles={'candidate':files},catalogSHA256=sha(catalog_path),coreSHA256={'candidate':files[core]})
save('identity.json',identity)
labels=[label for label,_,_ in jobs]
old_labels=['candidate-annotated', 'candidate-forwarding', 'candidate-named-report']
old_labels_rendered=repr(old_labels)
profile_floor=168*1024*1024
headroom=1024*1024
for name in ('ops-profile.py','collect.py','run.sh','launch.py','retrieve.py','analyze.py'):
    body=read(prior/name).replace(original['root'],root).replace(original['identity']['purpose'],purpose)
    body=body.replace(old_labels_rendered,repr(labels))
    body=body.replace('182452224',str(profile_floor))
    if name=='ops-profile.py':
        source_jobs = "[('candidate-annotated', 'scripts.annotated-rule-closures', 'warm'), ('candidate-forwarding', 'scripts.report-forwarding.expanded', 'warm'), ('candidate-named-report', 'scripts.report-render.named-format-selectors.large', 'warm')]"
        assert source_jobs in body
        body=body.replace(source_jobs,repr(jobs)).replace('count = 512','count = 256')
    if name=='launch.py':
        body=body.replace('seconds=85','seconds=135').replace('before 85','before 135')

    write(name,body)
assert repr(jobs) in read(lab/'ops-profile.py') and b'\r' not in (lab/'run.sh').read_bytes()

payload=lab/'payload.tgz'
names=('identity.json','catalog.json','ops-profile.py','collect.py','run.sh')
with tarfile.open(payload,'w:gz') as output:
    for name in names:
        output.add(lab/name,arcname=name)
expanded=sum((lab/name).stat().st_size for name in names)
config=dict(root=root,unit=unit,source=old['root'],sourceFiles={'candidate':files},
            sourceCatalogSHA256=old['catalogSHA256'],catalogSHA256=sha(catalog_path),identity=identity,retireGroups=[],
            payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),unpackedBytes=expanded,donorArchive=receipt['archiveSHA256'])
save('config.json',config)
launcher=read(prior/'remote-launch.py')
a,b=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=launcher[:a]+'c='+repr(config)+launcher[b:]
launcher=launcher.replace('lython-b1204-fixtures','lython-b1214-fixtures').replace('B1204','B1214')
launcher=launcher.replace('182452224',str(profile_floor)).replace('3145728',str(headroom)).replace('RuntimeMaxSec=155','RuntimeMaxSec=225')
write('remote-launch.py',launcher)
print('All 32 source-matched worker files and three CPython goldens verified. VM stages the immutable candidate image from B1212.')
