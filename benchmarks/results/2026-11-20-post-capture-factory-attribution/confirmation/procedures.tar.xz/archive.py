from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
out = Path('benchmarks/results/2026-11-20-post-capture-factory-attribution/confirmation')
load = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
receipt = load(lab/'archive-receipt.json')
terminal = load(lab/'terminal-status.json')
image = load(lab/'identity.json')
files = image['imageFiles']['candidate']
assert len(files) == 32 and {n:sha(lab/'candidate'/n) for n in files} == files
assert image['sourceRevision'].startswith('0f584586e') and image['imageSource'].startswith('356a93e25')
assert terminal['receipt'] == receipt
assert sha(lab/'observations.tgz') == receipt['archiveSHA256']
assert not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert receipt['archivedAndVerifiedUnderLease'] and receipt['persistentTraceArchivedAndVerifiedBeforeUnmount']
catalog = load(lab/'catalog.json')
assert sha(lab/'catalog.json') == image['catalogSHA256']
verified=load(lab/'verify.json')
assert verified['state'] == 'Completed' and verified['catalogSha256'] == image['catalogSHA256']
if receipt['complete']:
    assert terminal['exitCode'] == '0' and receipt['quietBeforeAndAfter']
    subprocess.run(['C:/Python313/python.exe','-X','utf8',str(lab/'analyze.py')],check=True)
    attribution=load(lab/'attribution.json')
    assert [x['case'] for x in attribution['rows']] == [x['id'] for x in catalog['cases']]
    for row,case in zip(attribution['rows'],catalog['cases'],strict=True):
        record=load(lab/'retrieved/profiles'/row['label']/'record.json')
        assert record['closed']['status']=='Closed' and record['warmupSeconds']>=8
        for verification in ('verificationBefore','verificationAfter'):
            result=record[verification]
            assert result['status']=='Equivalent' and result['actualOutputSha256']==case['expectedOutputSha256']
out.mkdir(exist_ok=False)
for name in ('archive-receipt.json','terminal-status.json','observations.tgz'):
    shutil.copyfile(lab/name,out/name)
if receipt['complete']:
    shutil.copyfile(lab/'attribution.json',out/'attribution.json')
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for path in sorted(lab.iterdir()):
        if path.suffix in {'.json','.py','.sh','.log'}:
            archive.add(path,arcname=path.name)
print('Archived B1215 profiles, source identity and procedure.')
