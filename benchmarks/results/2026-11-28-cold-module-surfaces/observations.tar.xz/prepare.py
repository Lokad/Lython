from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json

lab = Path(__file__).resolve().parent
previous = lab.parent/'first-command-phases-b1927-20261128'
current = lab.parent/'current-shipment-checkpoint-b1943-20261128/comparison/quiet'
identity = json.loads((current/'identity.json').read_bytes())
image = identity['imageFiles']['candidate']
assert len(image)==32 and {p.name:sha256(p.read_bytes()).hexdigest() for p in (current/'local-image').iterdir()}==image
copy2(previous/'config.json',lab/'config.json')
prior = json.loads((previous/'summary.json').read_bytes())
assert sha256((lab/'config.json').read_bytes()).hexdigest()==prior['payloadSHA256']
proof=dict(sourceRevision=identity['sourceRevision'], reference=image, payloadSHA256=prior['payloadSHA256'])
(lab/'summary.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
code=(previous/'collect-trace.py').read_text(encoding='utf-8').replace("image=lab/'reference'", "image=lab.parent/'current-shipment-checkpoint-b1943-20261128/comparison/quiet/local-image'")
code=code.replace("assert frame['identity']['catalogSha256']==summary['payloadSHA256']", """assert frame['identity']['catalogSha256']==summary['payloadSHA256']
        libraries={Path(value['path']).name:value['sha256'].lower() for value in frame['identity']['libraries']}
        for name in ('Lokad.Lython.dll','Lokad.Lython.Benchmarks.dll'):
            assert libraries[name]==summary['reference'][name]""")
compile(code,'collect-trace.py','exec')
(lab/'collect-trace.py').write_text(code,encoding='utf-8',newline='\n')
