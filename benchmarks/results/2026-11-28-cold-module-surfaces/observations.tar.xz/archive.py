from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
previous=lab.parent/'first-command-phases-b1927-20261128'
image=lab.parent/'current-shipment-checkpoint-b1943-20261128/comparison/quiet/local-image'
out=repo/'benchmarks/results/2026-11-28-cold-module-surfaces'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
identity=read(lab/'summary.json')
assert identity['sourceRevision'].startswith('bf10eeaea')
assert len(identity['reference'])==32 and {p.name:digest(p) for p in image.iterdir()}==identity['reference']
assert digest(lab/'config.json')==identity['payloadSHA256']
case,=read(lab/'config.json')['cases']
records=read(lab/'trace-receipt.json')
parsed=read(lab/'module-jit-summary.json')
assert len(records)==len(parsed)==2
for record,jit in zip(records,parsed,strict=True):
    assert digest(lab/record['trace'])==record['traceSha256'] and record['workerAndTracerJoined'] and jit['trace']==record['trace']
    assert jit['completed']==2680
    frame=record['frame']; response=frame['response']
    assert response['status']=='Equivalent' and response['completedInvocations']==1
    for name in ('sourceSha256','fixtureSha256','expectedOutputSha256','expectedFilesSha256'):
        key={'expectedOutputSha256':'actualOutputSha256','expectedFilesSha256':'actualFilesSha256'}.get(name,name)
        assert response[key]==case[name]
    assert frame['identity']['catalogSha256']==identity['payloadSHA256']
    assert any(row['Method']=='.cctor' and row['IlBytes']==8741 and row['Namespace']=='Lokad.Lython.Frontend.StaticModuleCatalog' for row in jit['methods'])
    assert any(row['Method']=='.cctor' and row['IlBytes']==2210 and row['Namespace']=='Lokad.Lython.Runtime.LythonRuntime+BuiltinModuleCatalog' for row in jit['methods'])
out.mkdir(exist_ok=True)
for name,path in {'identity.json':lab/'summary.json','module-jit-summary.json':lab/'module-jit-summary.json'}.items():
    copy2(path,out/name)
    assert digest(out/name)==digest(path)
files={name:lab/name for name in ('summary.json','config.json','prepare.py','collect-trace.py','collection.log','initial-verifier.log',
    'initial-path-verifier.log','trace-receipt.json','jit-intervals.jsonl','archive.py')}
for ordinal in range(2):
    for extension in ('frame','log','stderr','nettrace'):
        path=lab/f'startup-{ordinal}.{extension}'
        files[path.name]=path
for name in ('Program.cs','TraceReader.csproj'):
    files['trace-reader/'+name]=previous/'trace-reader'/name
with tarfile.open(out/'observations.tar.xz','w:xz') as archive:
    for name,path in files.items(): archive.add(path,arcname=name)
with tarfile.open(out/'observations.tar.xz') as archive:
    assert all(digest(path)==sha256(archive.extractfile(name).read()).hexdigest() for name,path in files.items())
print('Cold module catalog traces verified and archived.')
