from pathlib import Path
from tempfile import TemporaryDirectory
from hashlib import sha256
import json
import os
import subprocess

lab=Path(__file__).resolve().parent
summary=json.loads((lab/'summary.json').read_bytes())
image=lab.parent/'current-shipment-checkpoint-b1943-20261128/comparison/quiet/local-image'
dotnet=Path.home()/'.dotnet/dotnet'
trace=Path.home()/'.dotnet/tools/dotnet-trace'
worker=image/'Lokad.Lython.Benchmarks.dll'
catalog=lab/'config.json'
case,=json.loads(catalog.read_bytes())['cases']
assert {p.name:sha256(p.read_bytes()).hexdigest() for p in image.iterdir()}==summary['reference']
assert sha256(catalog.read_bytes()).hexdigest()==summary['payloadSHA256']
env={k:v for k,v in os.environ.items() if not k.startswith(('DOTNET_','COMPlus_'))}
env.update(DOTNET_ROOT=str(dotnet.parent),TMPDIR='/dev/shm',LC_ALL='C.UTF-8')
proof=[]
for ordinal in range(2):
    raw=lab/f'startup-{ordinal}.nettrace'
    output=lab/f'startup-{ordinal}.frame'
    errors=lab/f'startup-{ordinal}.stderr'
    log=lab/f'startup-{ordinal}.log'
    if not raw.exists():
        with TemporaryDirectory(prefix='lython-comparison-files-',dir='/dev/shm') as folder,log.open('wb') as stream:
            command=[trace,'collect','--clrevents','jit','--clreventlevel','verbose','--buffersize','32',
                 '--rundown','false','--output',raw,'--','/bin/sh','-c','exec "$1" "$2" --compare once --catalog "$3" > "$4" 2> "$5"',
                 'capture',dotnet,worker,catalog,output,errors]
            run=subprocess.run(command,cwd=folder,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,timeout=40)
            assert run.returncode==0,(run.returncode,log.read_text())
        assert not Path(folder).exists()
    else:
        assert ordinal == 0 and 'Trace completed' in log.read_text(encoding='utf-8')
    stdout=output.read_bytes()
    assert int.from_bytes(stdout[:4],'big')==len(stdout)-4 and not errors.read_bytes()
    frame=json.loads(stdout[4:])
    assert frame['response']['status']=='Equivalent' and frame['response']['completedInvocations']==1
    assert frame['response']['actualOutputSha256']==case['expectedOutputSha256']
    assert frame['response']['actualFilesSha256']==case['expectedFilesSha256']
    assert frame['identity']['catalogSha256']==summary['payloadSHA256']
    libraries={Path(value['path']).name:Path(value['path']).resolve() for value in frame['identity']['libraries']}
    for name in ('Lokad.Lython.dll','Lokad.Lython.Benchmarks.dll'):
        assert libraries[name]==(image/name).resolve()
    assert raw.stat().st_size>8192
    proof.append(dict(trace=raw.name,traceSha256=sha256(raw.read_bytes()).hexdigest(),frame=frame,workerAndTracerJoined=True))
assert {p.name:sha256(p.read_bytes()).hexdigest() for p in image.iterdir()}==summary['reference']
(lab/'trace-receipt.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
print([(row['trace'],row['traceSha256']) for row in proof])
