using System.Text.Json;
using Microsoft.Diagnostics.Tracing;

foreach (var path in args)
{
    using var trace = new EventPipeEventSource(path);
    var pending = new Dictionary<(int Thread, ulong Method), JitStart>();
    var completed = new List<JitInterval>();
    var starts = 0;
    var overwritten = 0;
    trace.Clr.MethodJittingStarted += data =>
    {
        starts++;
        var key = (data.ThreadID, unchecked((ulong)data.MethodID));
        var start = new JitStart(data.MethodNamespace, data.MethodName, data.MethodSignature,
            data.MethodILSize, data.TimeStampRelativeMSec);
        if (pending.TryAdd(key, start)) return;
        overwritten++;
        pending[key] = start;
    };
    trace.Clr.MethodLoadVerbose += data =>
        Finish(data.ThreadID, unchecked((ulong)data.MethodID), data.TimeStampRelativeMSec);
    trace.Clr.MethodLoad += data =>
        Finish(data.ThreadID, unchecked((ulong)data.MethodID), data.TimeStampRelativeMSec);
    trace.Process();
    if (starts == 0 || completed.Count == 0) throw new InvalidDataException("No matched JIT events in " + path);
    Console.WriteLine(JsonSerializer.Serialize(new
    {
        trace = Path.GetFileName(path), starts, overwritten, completed = completed.Count,
        unmatched = pending.Values, intervals = completed
    }));

    void Finish(int thread, ulong method, double end)
    {
        if (!pending.Remove((thread, method), out var start)) return;
        if (end < start.Timestamp) throw new InvalidDataException("JIT timestamp regressed.");
        completed.Add(new(thread, start.Namespace, start.Method, start.Signature, start.IlBytes, start.Timestamp, end));
    }
}

record JitStart(string Namespace, string Method, string Signature, int IlBytes, double Timestamp);
record JitInterval(int Thread, string Namespace, string Method, string Signature, int IlBytes, double Start, double End);
