#!/bin/bash
set -euo pipefail
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/csv-dictwriter-native-validation-20261127
cd "$lab/comparison/local"
flock -n "$lab/comparison/collection.lock" timeout --signal=TERM 275s taskset -c 27 bash ./run.sh
