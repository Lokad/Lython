using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Frontend;

var fields = typeof(ExecutableInstruction).GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
    .OrderBy(field => field.Name, StringComparer.Ordinal).ToArray();
using var catalog = JsonDocument.Parse(File.ReadAllText(args[0]));
var tapes = new List<object>();
foreach (var entry in catalog.RootElement.GetProperty("cases").EnumerateArray())
    Collect(entry.GetProperty("id").GetString()!, entry.GetProperty("source").GetString()!);
Collect("protected-match-and-abrupt-control", """
def choose(n):
    for i in range(n):
        try:
            if i == 1:
                continue
            try:
                match i:
                    case 0:
                        pass
                    case 2:
                        break
                    case _:
                        return i
            except ValueError:
                raise
            finally:
                print(i)
        finally:
            print(n)
    return n
    print('unreachable')
print(choose(5))
""");
Console.WriteLine(JsonSerializer.Serialize(new {
    coreSha256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))),
    tapes,
}));

void Collect(string id, string source)
{
    var syntax = LythonFrontend.Compile(source);
    if (syntax.Script is null) throw new InvalidOperationException($"Cannot parse {id}.");
    var entry = ExecutableScript.Compile(LoweredScript.Lower(syntax.Script)).EntryPoint;
    tapes.Add(new { id, code = Describe(entry) });
}

object Describe(ExecutableCodeObject code) => new {
    code.Name,
    code.EntryIndex,
    code.NativePrefixEnd,
    code.ValueStorageCapacity,
    code.LastOwnedTemporarySlot,
    code.ExceptionRegions,
    instructions = code.Instructions.Select(instruction => fields.Select(field => field.GetValue(instruction)).ToArray()).ToArray(),
    children = code.Constants.Select(value => value switch {
        ExecutableCreateFunction function => function.Binding.CodeObject,
        ExecutableCreateLambda lambda => lambda.CodeObject,
        ExecutableCreateGeneratorExpression generator => generator.CodeObject,
        _ => null,
    }).OfType<ExecutableCodeObject>().Distinct().Select(Describe).ToArray(),
};
