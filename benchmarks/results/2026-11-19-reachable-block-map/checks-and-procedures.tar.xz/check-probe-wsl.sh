set -e
cd /mnt/d/code/Lython/.git/agent-worktrees/reachable-block-map-r652
export PATH="$HOME/.dotnet:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/reachable-block-map-r652
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 --artifacts-path "$PWD/tests/artifacts/r652-wsl" > "$logs/probe-wsl-net10.log" 2>&1
expected=tools/LythonProbe/bin/Release/net10.0
mkdir -p "$expected"
cp -R tests/artifacts/r652-wsl/bin/LythonProbe/release_net10.0/. "$expected"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --no-build --artifacts-path "$PWD/tests/artifacts/r652-wsl" --filter 'FullyQualifiedName~RecursiveExceptionPropagationTests&FullyQualifiedName~CaughtMethodFailure' > "$logs/probed-tests-wsl-net10.log" 2>&1 || (tail -23 "$logs/probed-tests-wsl-net10.log"; exit 1)
tail -6 "$logs/probed-tests-wsl-net10.log"
