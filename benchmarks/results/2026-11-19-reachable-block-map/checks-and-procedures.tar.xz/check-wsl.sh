set -e
cd /mnt/d/code/Lython/.git/agent-worktrees/reachable-block-map-r652
export PATH="$HOME/.dotnet:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/reachable-block-map-r652
filter='(FullyQualifiedName~ProtectedLoop|FullyQualifiedName~ProtectedHelper|FullyQualifiedName~Finally|FullyQualifiedName~ExceptionHeader|FullyQualifiedName~ExceptionState|FullyQualifiedName~ExecutableStack|FullyQualifiedName~ExecutableOperand|FullyQualifiedName~JumpTarget|FullyQualifiedName~MatchCase|FullyQualifiedName~PatternMatching|FullyQualifiedName~GeneratorDefinition|FullyQualifiedName~ComposedNativeCall|FullyQualifiedName~GovernedMemoryContract|FullyQualifiedName~AsyncMidFlightCancellation)&Category!=Stress'
for project in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$logs/$project-wsl-net10.log"
    code=0
    dotnet test "tests/$project" -c Release -f net10.0 --artifacts-path "$PWD/tests/artifacts/r652-wsl" --filter "$filter" > "$log" 2>&1 || code=$?
    if [ "$code" != 0 ]; then tail -27 "$log"; exit "$code"; fi
    tail -4 "$log"
done
