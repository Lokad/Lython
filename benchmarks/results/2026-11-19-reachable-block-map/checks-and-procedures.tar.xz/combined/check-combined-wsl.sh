set -e
cd /mnt/d/code/Lython
export PATH="$HOME/.dotnet:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/reachable-block-map-r652
out="$PWD/tests/artifacts/r652-combined-wsl"
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 --artifacts-path "$out" > "$logs/probe-combined-wsl-net10.log" 2>&1
expected=tools/LythonProbe/bin/Release/net10.0
mkdir -p "$expected"
cp -R "$out/bin/LythonProbe/release_net10.0/." "$expected"
filter='(FullyQualifiedName~ProtectedLoop|FullyQualifiedName~ProtectedHelper|FullyQualifiedName~Finally|FullyQualifiedName~ExceptionHeader|FullyQualifiedName~ExceptionState|FullyQualifiedName~ExecutableStack|FullyQualifiedName~ExecutableOperand|FullyQualifiedName~JumpTarget|FullyQualifiedName~FunctionDefault|FullyQualifiedName~Governor|FullyQualifiedName~GovernedMemoryContract|FullyQualifiedName~AsyncMidFlightCancellation)&Category!=Stress'
for p in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$logs/$p-combined-wsl-net10.log"
    dotnet test "tests/$p" -c Release -f net10.0 --artifacts-path "$out" --filter "$filter" > "$log" 2>&1 || (tail -23 "$log"; exit 1)
    tail -5 "$log"
done
