from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=Path.cwd()
donor=lab.parent/'deferred-definition-r651'
load=lambda p:json.loads(p.read_text(encoding='utf8'))
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only','188cdf6ff',revision,'--','src','tests'])
image=lab/'combined-frozen'
image.mkdir(exist_ok=False)
files=load(donor/'frozen-identity.json')['images']['candidate']
source=donor/'frozen/candidate'
assert len(files)==32 and {name:digest(source/name) for name in files}==files
core='Lokad.Lython.dll'
built=lab/'combined-build-win/bin/Lokad.Lython/release_net11.0'/core
for name in files:
    shutil.copyfile(built if name==core else source/name,image/name)
expected=files | {core:digest(built)}
assert {name:digest(image/name) for name in expected}==expected
catalog=load(donor/'catalog.json')
additional=load(lab/'catalog.json')
assert {row['id'] for row in catalog['cases']}.isdisjoint(row['id'] for row in additional['cases'])
catalog['cases'].extend(additional['cases'])
path=lab/'combined-catalog.json'
path.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
sdk=Path.home()/'.dotnet11'; dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'combined-verify.log').open('wb') as log:
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',path,
        '--dotnet',dotnet,'--python',Path('C:/Python313/python.exe'),'--python-worker',repo/'benchmarks/cpython-worker.py',
        '--out',lab/'combined-verify.json'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
result=load(lab/'combined-verify.json')
assert result['state']=='Completed' and result['catalogSha256']==digest(path)
assert {name:digest(image/name) for name in expected}==expected
(lab/'combined-identity.json').write_text(json.dumps(dict(revision=revision,imageFiles=expected,catalogSha256=digest(path)),indent=2)+'\n',encoding='utf8',newline='\n')
print(f"Verified {len(catalog['cases'])} CPython goldens on the complete 32-file combined image.")
