from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile


lab = Path(__file__).resolve().parent
quiet = lab / "quiet"
out = Path("benchmarks/results/2026-11-21-compiler-literal-newlines")


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


identity = load(lab / "identity.json")
for role, files in identity["imageFiles"].items():
    assert len(files) == 32
    assert {name: sha(lab / "frozen" / role / name) for name in files} == files
    verification = load(lab / f"{role}-verify.json")
    assert verification["state"] == "Completed" and verification["caseCount"] == 4
assert sha(lab / "representative.json") == identity["catalogSHA256"]
for platform in ("windows", "ubuntu"):
    for suite, count in (("white", 141), ("public", 1681)):
        log = (lab / f"{suite}-{platform}.log").read_text(encoding="utf-8-sig")
        assert any(line.strip().startswith("Passed!") and f"Passed: {count:5d}, Skipped:" in line
                   for line in log.splitlines()), (suite, platform)

receipt = load(quiet / "archive-receipt.json")
terminal = load(quiet / "terminal-status.json")
assert terminal["exitCode"] == "0" and terminal["receipt"] == receipt
assert not terminal["remainingTrace"] and not terminal["remainingWorkers"]
assert all(receipt[k] for k in ("complete", "allWorkersJoined", "guestFixturesRemoved",
                                "archivedAndVerifiedUnderLease", "quietBeforeAndAfter"))
assert sha(quiet / "observations.tgz") == receipt["archiveSHA256"]
staged = load(quiet / "identity.json")
assert staged["imageFiles"] == identity["imageFiles"]
assert staged["catalogSHA256"] == identity["catalogSHA256"]
raw = load(quiet / "retrieved/confirmation/confirmation.json")
assert raw["warmupSeconds"] == 8 and raw["targetBatchSeconds"] == .65
cases = {case["id"]: case for case in load(lab / "representative.json")["cases"]}
assert raw["complete"] and len(raw["jobs"]) == receipt["jobs"] == 5 and len(cases) == 4
assert [(job["case"], job["lane"]) for job in raw["jobs"]] == [
    ("scripts.embedded-restock-templates", "compile"),
    ("scripts.embedded-restock-templates", "compile-run"),
    ("scripts.config-generated-guards.medium.bad-0", "compile"),
    ("scripts.config-generated-guards.medium.bad-0", "compile-run"),
    ("scripts.dataclass-inherited-configuration.generated", "compile"),
]
for job in raw["jobs"]:
    case = cases[job["case"]]
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"]) == 28
    for sample in job["samples"]:
        response = sample["response"]
        assert response["completedInvocations"] > 0 and response["status"] == "Completed"
        assert response["sourceSha256"] == case["sourceSha256"]
        assert response["fixtureSha256"] == case["fixtureSha256"]
        compile_only = job["lane"] == "compile"
        assert response.get("actualOutputSha256") == (None if compile_only else case["expectedOutputSha256"])
        assert response.get("actualFilesSha256") == (None if compile_only else case.get("expectedFilesSha256"))

summary = load(quiet / "quiet-summary.json")
del summary["retentionDecisionPending"]
summary.update(collection="B1280", reference=identity["reference"], candidate=identity["candidate"],
               verifiedTimedBatches=140, coreSHA256=staged["coreSHA256"], archiveSHA256=receipt["archiveSHA256"],
               retentionDecision="Retain after eliminating the literal rescan and reducing template compilation CPU. Time to result remains inconclusive.")
out.mkdir(exist_ok=True)
(out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
for name in ("README.md", "allocation-summary.json", "phase-attribution.json", "local-timing-summary.json"):
    shutil.copyfile(lab / name, out / name)
for name in ("archive-receipt.json", "terminal-status.json", "observations.tgz"):
    shutil.copyfile(quiet / name, out / name)
for role in ("reference", "candidate"):
    core = (lab / "frozen" / role / "Lokad.Lython.dll").read_bytes()
    target = out / (role + "-core.dll.gz")
    target.write_bytes(gzip.compress(core, mtime=0))
    assert gzip.decompress(target.read_bytes()) == core
(lab / "measured-source.patch").write_bytes(subprocess.check_output(
    ["git", "diff", identity["reference"], identity["candidate"], "--", "src", "tests"]))
with tarfile.open(out / "checks-and-procedures.tar.xz", "w:xz", preset=6) as archive:
    for folder in (lab, lab / "snapshot", quiet):
        for path in sorted(folder.iterdir()):
            if (path.is_file() and path.suffix not in {".dll", ".tgz"}
                    and path.name not in {"inventory.py", "launch.py", "retrieve.py"}):
                archive.add(path, arcname=path.relative_to(lab).as_posix())
print("140 timed batches and both complete frozen worker images verified.")
