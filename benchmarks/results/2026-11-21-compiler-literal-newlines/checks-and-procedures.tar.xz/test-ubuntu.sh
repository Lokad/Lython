set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/pinned-unicode-casing-20261121
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/compiler-literal-newlines
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 | tee "$logs/probe-ubuntu.log"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Parser|FullyQualifiedName~Token|FullyQualifiedName~Lexical|FullyQualifiedName~Diagnostic|FullyQualifiedName~Compiler|FullyQualifiedName~Formatted|FullyQualifiedName~SourceSpan)&Category!=Stress' | tee "$logs/white-ubuntu.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Syntax|FullyQualifiedName~FString|FullyQualifiedName~Format|FullyQualifiedName~Diagnostic|FullyQualifiedName~Compilation|FullyQualifiedName~SourceSpan|FullyQualifiedName~Dataclass)&Category!=Stress' | tee "$logs/public-ubuntu.log"
