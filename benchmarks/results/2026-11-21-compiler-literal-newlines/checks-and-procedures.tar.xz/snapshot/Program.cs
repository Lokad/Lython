using System.Diagnostics;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Frontend;

var engine = new LythonEngine();
var budget = new LythonMemoryBudget();
using var source = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var rows = new List<object>();
foreach (var item in source.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = item.GetProperty("id").GetString()!;
    var text = item.GetProperty("source").GetString()!;
    if (args[2] == "measure")
    {
        const int iterations = 80;
        for (var i = 0; i < 240; i++) CompileText(text);
        var samples = new List<object>();
        for (var round = 0; round < 9; round++)
        {
            var prior = GC.GetAllocatedBytesForCurrentThread();
            var start = Stopwatch.GetTimestamp();
            for (var i = 0; i < iterations; i++) CompileText(text);
            var elapsed = Stopwatch.GetElapsedTime(start).TotalMicroseconds / iterations;
            var bytes = (GC.GetAllocatedBytesForCurrentThread() - prior) / (double)iterations;
            samples.Add(new { elapsed, bytes });
        }
        rows.Add(new { id, samples });
    }
    else
    {
        var tokens = PythonTokenization.Read(text);
        using var compiled = engine.Compile(text, budget);
        var cursor = tokens.Tokens.Select(t =>
        {
            var span = tokens.SpanOf(t, t.Length);
            return new { kind = t.Token.ToString(), t.Start, t.Length, t.LineIndex, span };
        }).ToArray();
        var lines = Enumerable.Range(0, text.Length + 1).Select(p =>
        {
            tokens.LineOfPosition(p, out var line, out var column);
            return ((long)line << 32) | (uint)column;
        }).ToArray();
        rows.Add(new { id, cursor, lines, tokens.HasInvalidTokens, tokens.LexicalDiagnostic, tokens.GluedNumbers,
            compiled.IsValid, compiled.Diagnostics });
    }
}
if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compile budget failed to refund.");
var result = new { sha256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))), rows };
File.WriteAllText(args[1], JsonSerializer.Serialize(result) + "\n");

void CompileText(string text)
{
    using (var script = engine.Compile(text, budget))
        if (!script.IsValid) throw new InvalidOperationException("Comparison source is invalid.");
    if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compile budget failed to refund.");
}
