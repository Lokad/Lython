using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Frontend;

using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var rows = new List<object>();
const int Warmup = 96, Rounds = 7, Iterations = 48;
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = item.GetProperty("id").GetString()!;
    var source = item.GetProperty("source").GetString()!;
    var engine = new LythonEngine();
    var budget = new LythonMemoryBudget();
    for (var i = 0; i < Warmup; i++) Compile();
    var samples = new List<object>();
    for (var i = 0; i < Rounds; i++)
    {
        LocalCompilerPassMeter.Reset();
        var startBytes = GC.GetAllocatedBytesForCurrentThread();
        var startTicks = Stopwatch.GetTimestamp();
        for (var j = 0; j < Iterations; j++) Compile();
        var ticks = Stopwatch.GetTimestamp() - startTicks;
        var bytes = GC.GetAllocatedBytesForCurrentThread() - startBytes;
        samples.Add(new
        {
            compileMicroseconds = Micros(ticks),
            compileBytes = Bytes(bytes),
            phaseMicroseconds = LocalCompilerPassMeter.Ticks.Select(Micros).ToArray(),
            phaseBytes = LocalCompilerPassMeter.Bytes.Select(Bytes).ToArray(),
            phaseCalls = LocalCompilerPassMeter.Calls.Select(Bytes).ToArray(),
            acceptedLiteralCharacters = Bytes(LocalCompilerPassMeter.LiteralCharacters)
        });
    }
    rows.Add(new { id, sourceCharacters = source.Length, samples });

    void Compile()
    {
        using (var code = engine.Compile(source, budget))
            if (!code.IsValid || code.Diagnostics.Count != 0)
                throw new InvalidOperationException("Public compiler rejected measured source.");
        if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compiler budget failed to refund.");
    }
}

var image = File.ReadAllBytes(typeof(LythonEngine).Assembly.Location);
var catalogBytes = File.ReadAllBytes(args[0]);
var result = new
{
    referenceProductionSource = "86da4a942",
    instrumentedBuild = true,
    boundary = "Local compile only, new admitted compiled owner with disposal and budget reuse check each invocation. Total tokenization includes the two literal phases. Per-pass timing is diagnostic and includes modified instrumentation and timer overhead.",
    imageSHA256 = Convert.ToHexString(SHA256.HashData(image)).ToLowerInvariant(),
    catalogSHA256 = Convert.ToHexString(SHA256.HashData(catalogBytes)).ToLowerInvariant(),
    runtime = Environment.Version.ToString(),
    phases = new[] { "tokenization", "find literal termination", "rescan literal newlines" },
    rows,
};
File.WriteAllText(args[1], JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }) + "\n", Encoding.UTF8);

static double Micros(long ticks) => ticks * 1e6 / Stopwatch.Frequency / Iterations;
static double Bytes(long bytes) => (double)bytes / Iterations;
