from pathlib import Path
import hashlib
import json
import shutil
import subprocess

lab=Path(__file__).resolve().parent
config=json.loads((lab/'config.json').read_text(encoding='utf8'))
failed=lab/'initial-failure'
failed.mkdir(exist_ok=True)
for path in [*lab.glob('observation-*.json'),*(lab/name for name in (
        'prepare.py','config.json','identity.json','remote-launch.py','collect.py','archive-owned.py',
        'run.sh','launch.py','launch.log','observe-not-before.json','retrieval.log'))]:
    shutil.copyfile(path,failed/path.name)
code=r"""
from pathlib import Path
import fcntl, hashlib, json, os, stat, subprocess, tarfile
base=Path('/home/lokad/lython-bench-checks')
root=base/'factory-cpython-b1151-20261119'
fixture=root/'guest-fixtures'
unit='lython-b1151-factory-cpython-20261119.service'
assert root.resolve()==root and root.parent==base and fixture.resolve()==fixture
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    state=subprocess.check_output(['systemctl','show',unit,'--property=ActiveState,MainPID,Result'],text=True)
    assert 'ActiveState=failed' in state and 'MainPID=0' in state
    assert (root/'exit-code.txt').read_text().strip()=='1'
    assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],
                          capture_output=True).returncode==1
    journal=subprocess.check_output(['journalctl','-u',unit,'--no-pager'],text=True)
    assert "KeyError: 'auxiliaryFiles'" in journal
    (root/'failure-journal.txt').write_text(journal,encoding='utf8')
    assert os.path.ismount(fixture)
    paths=[p for tree in (root/'confirmation',fixture) for p in tree.rglob('*') if p.is_file()]
    paths += [root/'failure-journal.txt',root/'exit-code.txt',root/'identity.json',root/'retirement-receipt.json']
    archive=root/'failed-observations.tgz'
    with tarfile.open(archive,'w:gz') as out:
        for p in paths:
            assert p.resolve()==p and p.is_relative_to(root) and stat.S_ISREG(p.lstat().st_mode)
            out.add(p,arcname=p.relative_to(root).as_posix())
    with tarfile.open(archive) as saved:
        for p in paths:
            assert saved.extractfile(p.relative_to(root).as_posix()).read()==p.read_bytes()
    subprocess.run(['sudo','-n','umount',str(fixture)],check=True)
    fixture.rmdir()
    result=dict(complete=False,cause='missing auxiliaryFiles in initial staging identity',allWorkersJoined=True,
                initialDataVerifiedBeforeUnmount=True,guestFixturesRemoved=True,
                archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest())
    (root/'failed-recovery.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(json.dumps(result))
"""
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),
     '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
result=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf8',capture_output=True,timeout=60)
assert result.returncode==0,result.stdout+result.stderr
receipt=json.loads(result.stdout)
(failed/'recovery.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8',newline='\n')
archive=failed/'failed-observations.tgz'
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
subprocess.run(scp+['lokad@20.166.121.73:'+config['root']+'/'+archive.name,str(archive)],check=True,timeout=60)
assert hashlib.sha256(archive.read_bytes()).hexdigest()==receipt['archiveSHA256']
for name in ('launch.log','observe-not-before.json'):
    (lab/name).unlink()
print('Original failed collection archived and the verified fixture mount removed.')
