from pathlib import Path
import json

out=Path('benchmarks/results/2026-11-19-factory-cpython-checkpoint')
summary=json.loads((out/'summary.json').read_text(encoding='utf8'))
assert summary['source'].startswith('0d74b5b18') and summary['builtImageSource'].startswith('249d5522b')
rows={(row['case'],row['lane']):row for row in summary['rows']}
ordinary='scripts.annotated-rule-closures'
nested=ordinary+'.nested-factories'
invoice='scripts.csv-invoice.large'

def interval(values, digits, suffix):
    formats=[f'{value:.{digits}f}' for value in values]
    return (formats[0] if formats[0]==formats[1] else '–'.join(formats))+suffix

def clocks(row):
    digits=5 if row['lane']=='compile' else 3
    return [interval(row['lythonMs'],digits,' ms'),interval(row['cpythonMs'],digits,' ms'),interval(row['ratio'],2,'×')]

def note(row):
    return f"B1151 diagnostic. Controls L/C {row['lythonControlPercent']:.2f} / {row['cpythonControlPercent']:.2f}%. IQR ≤{row['maxIQRPercent']:.2f}%."

def line(first, row):
    return '| '+' | '.join([*first,*clocks(row),note(row)])+' |'

doc=Path('docs/BENCHMARKS.md')
text=doc.read_text(encoding='utf8')
assert 'B1151' not in text
old_warm=[]
old_other=[]
rewritten=[]
for entry in text.splitlines():
    if entry.startswith('| Annotated rule closures |') and 'B1143 diagnostic.' in entry:
        phase=entry.split(' | ')[1]
        if phase.startswith('2,048'):
            old_warm.append(entry)
            rewritten.append(line(['Annotated rule closures','2,048 inputs / 2,048 definitions'],rows[ordinary,'warm']))
            rewritten.append(line(['Nested annotated factories','2,048 inputs / 4,096 definitions'],rows[nested,'warm']))
        else:
            old_other.append(entry)
            lane={'Compilation only':'compile','Compile-to-result':'compile-run'}[phase]
            rewritten.append(line(['Annotated rule closures',phase],rows[ordinary,lane]))
            if lane=='compile-run':
                for nested_phase,nested_lane in [('Compilation only','compile'),('Compile-to-result','compile-run')]:
                    rewritten.append(line(['Nested annotated factories',nested_phase],rows[nested,nested_lane]))
    elif entry.startswith('| CSV invoice | 4,096 data records') and 'B1143 diagnostic.' in entry:
        old_warm.append(entry)
        rewritten.append(line(['CSV invoice','4,096 data records / 127,031 B'],rows[invoice,'warm']))
    else:
        rewritten.append(entry)
assert len(old_warm)==2 and len(old_other)==2
text='\n'.join(rewritten)+'\n'
historic=text.index('## Earlier measured workloads')
warm=text.index('| CSV invoice | 4,096',historic)
text=text[:warm]+'\n'.join(old_warm)+'\n'+text[warm:]
other=text.index('| CSV invoice | Compile-to-result',historic)
text=text[:other]+'\n'.join(old_other)+'\n'+text[other:]
text=text.replace('B1143 measures the CSV invoice and annotated rules at **353ec074c / frozen 5e40c428**.',
    f"B1151 measures annotated and nested factories and the warm CSV invoice at\n"
    f"**0d74b5b18 / frozen {summary['coreSHA256'][:8]}**. The frozen executable sources\n"
    f"match the delivered core.\n"
    f"B1143 measures the earlier CSV invoice and annotated rules at **353ec074c / frozen 5e40c428**.")
text=text.replace('[B1143 observations]', '[B1151 observations](../benchmarks/results/2026-11-19-factory-cpython-checkpoint/README.md) ·\n[B1143 observations]',1)
doc.write_text(text,encoding='utf8',newline='\n')
for key in (ordinary,nested,invoice):
    for lane in ('warm','compile','compile-run'):
        if (row:=rows.get((key,lane))) is not None: print(line([key,lane],row))
