set -eu
root=/home/lokad/lython-bench-checks/factory-cpython-b1151-corrected-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
