from pathlib import Path
import os,subprocess
r=Path(__file__).parent
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
for target in ['net11.0','net10.0']:
    with(r/('cleanup-'+target+'.log')).open('wb')as log:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',target,'--no-restore','--filter','FullyQualifiedName~XmlIterparseTests.CancellationWaitsForOwnedCleanup','--logger','trx;LogFileName=cleanup-'+target+'.trx','--results-directory',str((r/('cleanup-'+target)).resolve())],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    print(target,done.returncode,(r/('cleanup-'+target+'.log')).read_text(encoding='utf-8')[-1200:],flush=True)
    assert done.returncode==0
