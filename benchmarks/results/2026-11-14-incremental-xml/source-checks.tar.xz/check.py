from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH']
rows=[]
for target in ['net11.0','net10.0']:
    for assembly,filter in [('Lokad.Lython.Tests','FullyQualifiedName~Xml|FullyQualifiedName~ElementTree'),('Lokad.Lython.PublicApi.Tests','FullyQualifiedName~Xml|FullyQualifiedName~ElementTree')]:
        log=r/(assembly+'-'+target+'.log')
        command=[env['DOTNET_ROOT']+'/dotnet.exe','test','tests/'+assembly+'/'+assembly+'.csproj','-c','Release','-f',target,'--no-restore','--filter',filter,'--logger','trx;LogFileName=r335-'+target+'.trx','--results-directory',str(r.resolve()/('results-'+assembly+'-'+target))]
        with log.open('wb')as output:done=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT,env=env,timeout=180)
        text=log.read_text(encoding='utf-8',errors='replace');print(assembly,target,done.returncode,text[-1800:],flush=True)
        rows.append(dict(assembly=assembly,target=target,returncode=done.returncode,log=log.name))
        (r/'focused-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
        assert done.returncode==0
