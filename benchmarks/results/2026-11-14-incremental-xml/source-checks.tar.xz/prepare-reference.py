from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).parent;prior=r.parent/'utf8-byte-ownership-r334'
d=json.loads((prior/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in d['sources'].items())
for name in ['candidate-core.dll','candidate-sources.tar.xz','candidate-identity.json']:
    shutil.copyfile(prior/name,r/name.replace('candidate','reference'))
shutil.copytree(prior/'candidate',r/'reference')
print('Reused exact frozen0b2929ca/R334 reference before source edits; no rebuild or unchanged qualification.',flush=True)
