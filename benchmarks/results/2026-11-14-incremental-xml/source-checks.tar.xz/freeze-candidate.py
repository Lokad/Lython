from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((r.parent/'utf8-byte-ownership-r334/candidate-identity.json').read_text(encoding='utf-8'))
reference=dict(head='d888ee478f7d5c5503ac6c930cbb3abca486405c',coreSHA256=old['coreSHA256']['candidate'],sources=old['sources'],productionFiles=old['productionFiles'],auxiliaryFiles=old['auxiliaryFiles']['candidate'],qualified=True,qualification='Combined GREEN43530265063, Windows/Ubuntu actual11/10 ordinary, stress and installed consumers')
assert sha(r/'reference-core.dll')==reference['coreSHA256']
(r/'reference-identity.json').write_text(json.dumps(reference,indent=2)+'\n',encoding='utf-8',newline='\n')
paths=sorted(set(old['sources'])|{str(p).replace('\\','/')for p in Path('src/Lokad.Lython/Runtime').glob('LythonRuntime.ElementTree.*.cs')})
sources={p:sha(p)for p in paths}
changed=[p for p in sources if sources[p]!=reference['sources'].get(p)]
assert len(changed)==6,changed
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH']
with(r/'candidate-build.log').open('wb')as log:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0,(r/'candidate-build.log').read_text(encoding='utf-8')[-3000:]
assert sources=={p:sha(p)for p in sources}
out=r/'candidate';out.mkdir()
for p in(r/'reference').iterdir():
    if p.is_file():shutil.copyfile(p,out/p.name)
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',out/'Lokad.Lython.dll')
shutil.copyfile(out/'Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),coreSHA256={'reference':reference['coreSHA256'],'candidate':sha(out/'Lokad.Lython.dll')},sources=sources,productionFiles=len(sources),changedProductionInputs=changed,auxiliaryFiles={role:{p.name:sha(p)for p in(r/role).iterdir()if p.is_file()and p.name!='Lokad.Lython.dll'}for role in ['reference','candidate']},qualified=False,sourceAndScriptDifferIntentionally=True)
assert identity['auxiliaryFiles']['candidate']==identity['auxiliaryFiles']['reference']
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
    for name in sources:t.add(name,arcname=name)
print('Frozen candidate',identity['coreSHA256'],len(sources),'inputs; six changed/new production sources; worker/adapter bytes identical.',flush=True)
