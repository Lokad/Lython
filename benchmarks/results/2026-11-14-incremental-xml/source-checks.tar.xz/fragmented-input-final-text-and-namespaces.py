import xml.etree.ElementTree as ET
class Source:
    def __init__(self,data): self.data=data;self.position=0
    def read(self,n):
        value=self.data[self.position:self.position+1]
        self.position+=1
        return value
text='<r xmlns="urn:r" xmlns:p="urn:p" p:key="é">A<!--ignored-->B<?pi ignored?><p:x><![CDATA[Ω😀]]></p:x>tail&amp;&#13;</r>'
for encoding in ['utf-8','utf-8-sig','utf-16','utf-16-le','utf-16-be']:
    parser=ET.iterparse(Source(text.encode(encoding)),events=['start','end'])
    print(encoding,[(event,node.tag) for event,node in parser])
    root=parser.root
    print(root.attrib,repr(root.text),repr(root[0].text),repr(root[0].tail))
