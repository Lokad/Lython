from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent
out=r/'b706';out.mkdir(exist_ok=True)
prior=r.parent/'utf8-byte-ownership-r334/b705'
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
aux=json.loads((prior/'identity.json').read_text(encoding='utf-8'))['candidateAuxiliaryFiles']
assert all(source['auxiliaryFiles'][role][name]==sha for role in ['candidate','reference']for name,sha in aux.items())
identity=dict(sourceRevision='R335 frozen'+source['coreSHA256']['candidate'][:8]+' vs fully qualified R334/d888ee47 frozen0b2929ca',purpose='Complete early-exit XML/report scripts with changed algorithms, warm and compile-to-result; unchanged whole-document XML control. No external CPU comparison.',coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},candidateAuxiliaryFiles=aux,referenceAuxiliaryFiles=aux,catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),referenceCase='scripts.xml-early-exit.whole',variantCase='scripts.xml-early-exit.incremental',controlCase='scripts.xml-settings.large',sourceAndScriptDifferIntentionally=True)
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
oldroot='/home/lokad/lython-bench-checks/utf8-byte-ownership-b705-20261113'
root='/home/lokad/lython-bench-checks/xml-iterparse-b706-20261114'
unit='lython-b706-xml-iterparse-20261114'
jobs=[['scripts.xml-early-exit.whole','warm'],['scripts.xml-early-exit.whole','compile-run'],['scripts.xml-settings.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py']:
    s=(prior/name).read_text(encoding='utf-8').replace(oldroot,root).replace('lython-b705-utf8-byte-ownership-20261113',unit).replace('B705','B706')
    for old,new in [("len(raw['jobs'])==4","len(raw['jobs'])==3"),("['jobs']==4","['jobs']==3"),('jobs=4','jobs=3')]:s=s.replace(old,new)
    if name=='collect.py':
        a=s.index('jobs=');b=s.index('\nenv =',a)
        s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n'+s[b:]
    if name=='summarize.py':
        s=s.replace('sourceAndScriptDifferIntentionally=False','sourceAndScriptDifferIntentionally=True')
        s=s.replace('No new external timing measurement; CPython3.13.2 exact XML goldens only','No external timing; two distinct source algorithms have isolated CPython3.13.2 exact file/stdout goldens. Control has identical guest source.')
    if name.endswith('.py'):ast.parse(s)
    (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
    for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
    for name,arc in [('catalog.json','representative.json'),('candidate-core.dll','candidate-core.dll'),('reference-core.dll','reference-core.dll'),('candidate-identity.json','source-identity.json'),('reference-identity.json','reference-source-identity.json')]:t.add(r/name,arcname=arc)
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root=root,sourceRoot='/home/lokad/lython-bench-checks/current-external-b704-20261113',unit=unit,identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prepared three bounded jobs: early-exit warm/fresh and unchanged whole-document control; changed script algorithms explicit.',flush=True)
