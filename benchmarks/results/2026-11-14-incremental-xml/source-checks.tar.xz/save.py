from pathlib import Path
import hashlib,json,re,shutil,tarfile
r=Path(__file__).parent
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
timing=json.loads((r/'b706/summary.json').read_text(encoding='utf-8'))
receipt=json.loads((r/'b706/archive-receipt.json').read_text(encoding='utf-8'))
assert timing['complete']and timing['jobs']==3 and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']
assert hashlib.sha256((r/'b706/observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
counts={}
for assembly in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
    for target in ['net11.0','net10.0']:
        name=assembly+'-'+target+'.log';data=(r/name).read_text(encoding='utf-8')
        match=re.search(r'Passed!.*?Failed:\s+0, Passed:\s+(\d+)',data);assert match,name
        counts[name]=int(match[1])
assert list(counts.values())==[35,35,106,106]
out=Path('benchmarks/results/2026-11-14-incremental-xml');out.mkdir()
for name in ['candidate-identity.json','reference-identity.json','workload-python-controls.json','python-controls.json','worker-verification.json','focused-checks.json']:shutil.copyfile(r/name,out/name)
for name in ['summary.json','archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copyfile(r/'b706'/name,out/name)
with tarfile.open(out/'source-checks.tar.xz','w:xz')as t:
    for name in ['prepare-reference.py','reference-core.dll','reference-sources.tar.xz','freeze-candidate.py','candidate-build.log','candidate-core.dll','candidate-sources.tar.xz','python-controls.py','prepare-catalog.py','catalog.json','workload-python-controls.json','check.py','check-cleanup.py','prepare-comparison.py','verify-worker.py','save.py']+list(counts):t.add(r/name,arcname=name)
    for pattern in ['*.stdout','*.stderr','cleanup-*.log']:
        for p in r.glob(pattern):t.add(p,arcname=p.name)
    for p in r.glob('results-*/*.trx'):t.add(p,arcname=p.relative_to(r).as_posix())
    for p in r.glob('cleanup-*/*.trx'):t.add(p,arcname=p.relative_to(r).as_posix())
    for name in ['events-root-and-borrowed-reader','default-empty-events-and-writable-root','fragmented-input-final-text-and-namespaces','errors-stay-lazy-and-close-is-idempotent']:t.add(r/(name+'.py'),arcname=name+'.py')
    for name in ['tests/Lokad.Lython.Tests/XmlIterparseOwnershipTests.cs','tests/Lokad.Lython.PublicApi.Tests/XmlIterparseTests.cs']:t.add(name,arcname=name)
    for name in ['identity.json','config.json','collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py','launch-command.py','launch.log','observe-not-before.json','extraction.json','first-config.json','setup-correction.json','launch-preflight-missing-allocation-helper.log']:t.add(r/'b706'/name,arcname='b706/'+name)
table='| Complete script / phase | Reference ms | Candidate ms | Elapsed change | Wider CPU change | Process spread candidate/reference | Max IQR |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: |\n'
for row in timing['timing']:
    ref=[v for k,v in row['medianMilliseconds'].items()if k.startswith('reference')]
    cand=[v for k,v in row['medianMilliseconds'].items()if k.startswith('candidate')]
    elapsed=row['lythonSourcePairElapsedPercent'];cpu=row['lythonSourcePairWiderCpuPercent']
    label=('early-exit, changed algorithm'if row['case'].endswith('.whole')else'whole-document, identical source')+' /'+row['lane']
    table+=f"|{label}|{min(ref):.4f}–{max(ref):.4f}|{min(cand):.4f}–{max(cand):.4f}|{min(elapsed):+.2f}..{max(elapsed):+.2f}%|{min(cpu):+.2f}..{max(cpu):+.2f}%|{row['candidateProcessSpreadPercent']:.2f}/{row['referenceProcessSpreadPercent']:.2f}%|{max(row['iqrPercent'].values()):.2f}%|\n"
inputBytes=json.loads((r/'workload-python-controls.json').read_text(encoding='utf-8'))['checks'][0]['inputBytes']
(out/'README.md').write_text(f'''# Incremental XML input and shared construction

2026-11-14UTC, R335committedcdd92944/frozenf4c4f027 against fully qualified
R334d888ee47/frozen0b2929ca. Same581candidate production inputs and fixed worker/
adapter bytes are recorded. Full R335platform/stress/installed qualification is
[running43536449801](https://github.com/Lokad/Lython/actions/runs/43536449801);
focused correctness and the bounded measurement below are complete.

`iterparse` supports start/end events, root and close over mediated filenames
or borrowed read objects. It replaces eager acquisition for early-exit jobs.
`fromstring` and events share one tree builder; the old inline build loop is
removed. Existing opened-file transport, protocol calls and execution cleanup
serve actual asynchronous reads and awaited disposal. No new resource registry,
memory policy, tracing, unsafe code or background work is introduced.

Private reader/buffer/construction storage retires at close. Before publication,
failures refund only unpublished values. Published prefixes keep command ownership;
their rollback ledger retires. Aliases remain funded. Reader/name/token estimates
can grow with supplied bytes until reader disposal, and graph charges remain
conservative. This is **early-exit capability, not constant-memory arbitrary scans**;
long streams still use bounded host executions. Partial-node traversal admits
remaining permitted depth, including after clear. Other event kinds/custom parsers
fail explicitly; the depth1024 and DTD/entity restrictions remain.

## Correctness

35internal/106public XML Release cases pass each actual.NET11/10, plus two
strengthened joined-cleanup cases per target. Four isolated CPython3.13.2 event/
root/close/error controls agree exactly. Existing Python encoding goldens are
reused through byte-fragmented readers, including declaration aliases/mismatches.
They expose and fix a prototype bug accepting UTF8 bytes declaring UTF16. Coverage
includes long tokens with genuinely asynchronous reads, retained results over two
executions/shared allowance, terminal refusal before I/O and inside read hooks,
cancelled reads with held cleanup, borrowed-source ownership, reentry, partial
trees/clear, malformed XML and depth. Frozen worker verification independently
checks full file/stdout goldens and accounting reuse for both script algorithms.

## One bounded complete-script comparison

{table}
B706finishes{timing['elapsedSeconds']:.3f}s under one300s owner on quiet
AzureF4as_v7/Ubuntu24.04.4/.NET11RC3, ordinary workstation GC/tiering. Two fresh
processes per revision/job, eight-second full-request wall warmups and five
rotating0.5s wall-sized batches. The raw collection preserves all points.

The early-exit input is{inputBytes:,}bytes: one wanted item followed by16,384
unused records. Reference reads/parses the complete document then searches;
candidate uses iterparse and closes after the first wanted end event. Both print
`kept`, write the same result file and preserve the entire original input.
**Both runtime and script algorithm differ.** The large improvement demonstrates
avoided input/tree work on this shape, not a same-source interpreter or CPython
speedup. Reference processes vary4.61–5.49%; exact speedup magnitude is diagnostic.
The unchanged settings/report control supports a modest elapsed/CPU improvement
from shared construction; no broad runtime claim or allocation percentage follows.
Retain the usable capability and shared builder; no remaining measured CPU debt
is established by these three jobs. Unrelated text/search debt remains open.

Guest clocks include mediated RAM-file I/O, complete stdout/file validation and
prior-result cleanup. Compile-to-result adds compilation/compiled-owner disposal;
startup, fixture reset/protocol and final caches are excluded. Wider CPU includes
reset/protocol. Ranges pair process medians, not confidence intervals. There is no
new external CPython timing, allocation or embedding-tail measurement.

All identity/golden/balance/quiet/join/archive gates pass. Persistent evidence is
SHA-verified after all users join and RAM fixtures unmount. No evidence/image is
retired and no disk floor relaxed. The first missing diagnostic-helper preflight
and corrected fixed-worker dependency selection remain archived; no timing was
discarded or restarted. A duplicate launch request refuses the existing root;
the original unit alone completes. Publication/tagging remain postponed.

[Timing/wider CPU](summary.json), [raw observations](observations.tgz),
[frozen source/bits/checks and setup conditions](source-checks.tar.xz).
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md')
with p.open('a',encoding='utf-8',newline='\n')as f:f.write('''
## R335 — incremental XML and one construction loop

[Retained capability/source pair](results/2026-11-14-incremental-xml/README.md)
adds mediated/borrowed iterparse start/end/root/close and replaces the separate
fromstring build loop. Existing transport/cleanup/ownership serve actual async
reads. Published aliases stay funded; conservative reader/graph accounting does
not promise constant-memory arbitrary scans.35internal/106public XML cases pass
per actual11/10. Fragmented encoding controls uncover/fix a prototype mismatch.
B706three jobs finish140.181s/all gates: early-exit whole scripts drop from25–26ms
to0.081ms warm with a deliberately different script algorithm; unchanged
whole-document source improves3.21–4.13%elapsed with wider CPU support. No external
speedup, allocation percentage or general runtime claim. Original setup failures,
all controls/raw points survive. Full delivery43536449801runs separately;
publication held and broader text/search performance objective remains open.
''')
print('Saved R335 exact sources/checks and B706 terminal evidence; performance scope and ownership limitations explicit.',flush=True)
