from pathlib import Path
import base64,copy,hashlib,json,struct,subprocess,tempfile
r=Path(__file__).parent
catalog=json.loads((r.parent/'utf8-byte-ownership-r334/catalog.json').read_text(encoding='utf-8'))
control=next(c for c in catalog['cases']if c['id']=='scripts.xml-settings.large')
data=b'<records><item id="wanted">kept</item>'+b'<item id="other">unused payload</item>'*16384+b'</records>'
baseline="""import xml.etree.ElementTree as ET
from pathlib import Path
with open('input.xml','rb') as source:
    root=ET.fromstring(source.read())
for item in root.iter('item'):
    if item.get('id')=='wanted':
        answer=item.text
        break
print(answer)
Path('result.txt').write_text(answer)
"""
variant="""import xml.etree.ElementTree as ET
from pathlib import Path
parser=ET.iterparse('input.xml')
try:
    for event,item in parser:
        if item.tag=='item' and item.get('id')=='wanted':
            answer=item.text
            break
finally: parser.close()
print(answer)
Path('result.txt').write_text(answer)
"""
fixture=json.loads(control['fixtureJson'])
fixture['size']=16385
fixture['inputFiles']={'input.xml':base64.b64encode(data).decode()}
fixture['outputFiles']={'result.txt':base64.b64encode(b'kept').decode()}
cases=[];checks=[]
for label,source in [('whole',baseline),('incremental',variant)]:
    c=copy.deepcopy(control)
    c.update(id='scripts.xml-early-exit.'+label,source=source,sourceUtf8Bytes=len(source.encode()),sourceSha256=hashlib.sha256(source.encode()).hexdigest(),fixtureJson=json.dumps(fixture,separators=(',',':'),ensure_ascii=False),expectedOutput='kept\n',expectedOutputSha256=hashlib.sha256(b'kept\n').hexdigest())
    c['fixtureSha256']=hashlib.sha256(c['fixtureJson'].encode()).hexdigest()
    c['expectedOutputUtf8Bytes']=5
    c['fixtureTextUtf8Bytes']=len(fixture.get('text','').encode())
    c['fixtureTextCodePoints']=len(fixture.get('text',''))
    c['size']=16385
    c['family']='scripts.xml-early-exit'
    name=b'result.txt';output=b'kept'
    c['expectedFilesSha256']=hashlib.sha256(struct.pack('>i',1)+struct.pack('>i',len(name))+name+struct.pack('>i',len(output))+output).hexdigest()
    with tempfile.TemporaryDirectory(prefix='xml-early-exit-control-',dir=r.resolve())as folder:
        work=Path(folder).resolve();assert work.parent==r.resolve()
        (work/'input.xml').write_bytes(data)
        done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=work,capture_output=True,text=True,encoding='utf-8',timeout=15)
        assert done.returncode==0 and not done.stderr and done.stdout=='kept\n',(done.stdout,done.stderr)
        assert(work/'result.txt').read_bytes()==b'kept'and(work/'input.xml').read_bytes()==data
    cases.append(c);checks.append(dict(case=c['id'],sourceSHA256=c['sourceSha256'],fixtureSHA256=c['fixtureSha256'],inputBytes=len(data),stdout=done.stdout,exactFilesAndUnchangedInput=True))
catalog['cases']=[*cases,control]
(r/'catalog.json').write_text(json.dumps(catalog,separators=(',',':'),ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
(r/'workload-python-controls.json').write_text(json.dumps(dict(reference='CPython3.13.2 isolated',checks=checks,unchangedControl=control['id'],sourceAndScriptDifferIntentionally=True,timingNotMeasured=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prepared two algorithm variants with identical full input/output files and stdout; unchanged whole-document control.',flush=True)
