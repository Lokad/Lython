import xml.etree.ElementTree as ET
class Source:
    def __init__(self,parts): self.parts=iter(parts)
    def read(self,n): return next(self.parts,b'')
for parts in [[b''],[b'<r>',b''],[b'<r/>',b'<other/>'],[b'<r>\xff</r>']]:
    parser=ET.iterparse(Source(parts))
    print('created')
    try: list(parser)
    except ET.ParseError: print('ParseError')
    print(parser.root,parser.close(),next(parser,None))
try: ET.iterparse(Source([]),events=['unknown'])
except ValueError: print('ValueError')
class Broken:
    def read(self,n): raise MemoryError('guest')
parser=ET.iterparse(Broken())
try: next(parser)
except MemoryError as error: print(error)
print(next(parser,None))
