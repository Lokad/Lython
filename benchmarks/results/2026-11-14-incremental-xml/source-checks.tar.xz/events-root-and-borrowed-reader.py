import xml.etree.ElementTree as ET
class Source:
    def __init__(self): self.parts=iter([b'<r a="kept">before<x>inside</x>after<y/></r>',b''])
    def read(self,n): return next(self.parts,b'')
    def close(self): print('must not close')
parser=ET.iterparse(Source(),events=('start','end','start'))
print(iter(parser) is parser,parser.root)
saved=[]
for event,node in parser:
    saved.append(node)
    print(event,node.tag)
root=parser.root
print(root is saved[0],root is saved[-1],saved[1] is saved[2],saved[3] is saved[4])
print(root.attrib,repr(root.text),repr(root[0].text),repr(root[0].tail),root[1].text)
print(parser.close(),next(parser,None),parser.root is root)
