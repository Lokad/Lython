from pathlib import Path
import hashlib,json,re,subprocess,textwrap
r=Path(__file__).parent
source=Path('tests/Lokad.Lython.PublicApi.Tests/XmlIterparseTests.cs').read_text(encoding='utf-8')
cases=re.findall(r'yield return \["([^"]+)", """\n(.*?)\n            """, "((?:\\.|[^"\\])*)"\];',source,re.S)
assert len(cases)==4,len(cases)
rows=[]
for name,body,expected in cases:
    script=textwrap.dedent(body)+'\n'
    path=r/(name+'.py');path.write_text(script,encoding='utf-8',newline='\n')
    done=subprocess.run(['C:/Python313/python.exe','-X','utf8','-I',str(path.resolve())],capture_output=True,text=True,encoding='utf-8')
    (r/(name+'.stdout')).write_text(done.stdout,encoding='utf-8',newline='\n')
    (r/(name+'.stderr')).write_text(done.stderr,encoding='utf-8',newline='\n')
    target=json.loads('"'+expected+'"')
    rows.append(dict(name=name,sourceSHA256=hashlib.sha256(script.encode()).hexdigest(),returncode=done.returncode,matches=done.stdout==target))
    print(name,done.returncode,done.stdout==target,flush=True)
    if done.returncode or done.stdout!=target: print(repr(done.stdout),repr(target),done.stderr,flush=True)
(r/'python-controls.json').write_text(json.dumps(dict(reference='CPython3.13.2 isolated local',cases=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
assert all(row['matches'] and not row['returncode'] for row in rows)
