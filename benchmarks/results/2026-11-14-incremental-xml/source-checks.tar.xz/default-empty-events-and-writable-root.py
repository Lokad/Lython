import xml.etree.ElementTree as ET
class Source:
    def __init__(self): self.done=False
    def read(self,n):
        if self.done: return ''
        self.done=True
        return '<?xml version="1.0" encoding="latin1"?><r>Ω😀<x/></r>'
for events in [None,[],['end']]:
    parser=ET.iterparse(Source(),events=events)
    parser.root='temporary'
    print(parser.root,[node.tag for event,node in parser],parser.root.tag,repr(parser.root.text))
parser=ET.iterparse(Source(),events=['start'])
print(next(parser)[1].tag,parser.close(),next(parser,None),parser.root)
