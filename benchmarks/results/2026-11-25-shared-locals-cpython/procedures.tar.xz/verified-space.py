from pathlib import Path

lab=Path(__file__).resolve().parent
shared=lab.with_name('shared-function-local-slots-20261125')
script=(shared/'verify-and-free-space.py').read_text(encoding='utf-8')
script=script.replace('lab/\'comparison/quiet\'','lab/\'external\'')
script=script.replace("source=operand/'candidate'/core", "source=lab.with_name('direct-callback-return-20261125')/'candidate'/core")
script=script.replace('verified-b1659-candidate.dll','verified-b1661-candidate.dll')
start=script.index('stages=(')
end=script.index('copies=[]',start)
script=script[:start]+'''shared=lab.with_name('shared-function-local-slots-20261125')
frontend=lab.with_name('frontend-cpython-20261124')
stages=(
    ('direct-callback-return-b1661-20261125','b1661-direct-callback-return-20261125','candidate',callback/'comparison/quiet'),
    ('shared-function-local-slots-b1662-20261125','b1662-shared-function-local-slots-20261125','reference',shared/'comparison/quiet'),
    ('shared-function-local-slots-confirm-b1662-20261125','b1662-shared-function-local-slots-confirm-20261125','reference',shared/'confirmation'),
)
replicas=(stages[-1],
    ('frontend-cpython-b1643-20261124','b1643-frontend-cpython-20261124','candidate',frontend/'external'))
'''+script[end:]
path=lab/'verify-and-free-space.py'
compile(script,str(path),'exec')
path.write_text(script,encoding='utf-8',newline='\n')
