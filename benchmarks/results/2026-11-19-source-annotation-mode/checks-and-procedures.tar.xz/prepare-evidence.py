from pathlib import Path
import subprocess
import sys

lab = Path(__file__).resolve().parent
template = lab.parent / 'selected-abstract-path-r713' / 'archive-evidence.py'
source = template.read_text(encoding='utf-8')
source = source.replace('2026-11-19-selected-abstract-paths', '2026-11-19-source-annotation-mode')
start = source.index("initial['stagingConditions']")
end = source.index('out.mkdir')
source = source[:start] + source[end:]
start = source.index('    for name in (\n', source.index("with tarfile.open(out / 'checks-and-procedures.tar.xz'"))
end = source.index("    for name in ('config.json'", start)
source = source[:start] + '''    for name in (
        'measured-source.patch', 'catalog.json', 'frozen-identity.json', 'freeze-and-verify.py',
        'reference-verify.json', 'candidate-verify.json', 'reference-allocation.json', 'candidate-allocation.json',
        'reference-compile-allocation.json', 'candidate-compile-allocation.json', 'reference-build.log', 'candidate-build.log',
        'public-windows.log', 'white-windows.log', 'public-ubuntu.log', 'white-ubuntu.log', 'source-pair.log',
        'prepare-pair.py', 'prepare-quiet.py', 'prove-quiet-space.py', 'stage-quiet.py', 'preflight.json',
        'quiet-space.json', 'summarize-quiet.py', 'launch-quiet.py', 'retrieval.log',
        'prepare-evidence.py', 'archive-evidence.py',
    ):
        tar.add(lab / name, arcname=name)
''' + source[end:]
(lab / 'archive-evidence.py').write_text(source, encoding='utf-8', newline='\n')
subprocess.run([sys.executable, '-X', 'utf8', lab / 'archive-evidence.py', sys.argv[1]], check=True)
