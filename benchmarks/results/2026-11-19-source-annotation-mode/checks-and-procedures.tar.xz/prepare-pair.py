from pathlib import Path
import json
import subprocess
import sys

lab = Path(__file__).resolve().parent
old = lab.parent / 'selected-abstract-path-r713'
load = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
catalog = load(lab.parent / 'function-binding-inline-r712' / 'catalog.json')
observed = next(case for case in load(lab.parent / 'retained-annotations-r700' / 'catalog.json')['cases']
                if case['id'] == 'scripts.annotated-rule-closures.observed')
catalog['cases'].append(observed)
assert len(catalog['cases']) == 6
(lab / 'catalog.json').write_text(json.dumps(catalog, indent=2, ensure_ascii=False) + '\n',
                                encoding='utf-8', newline='\n')
freeze = (old / 'freeze-and-verify.py').read_text(encoding='utf-8')
freeze = freeze.replace('selected-abstract-path-r713', 'source-annotation-mode-r714').replace("'ee057fd12'", "'802c7130e'")
freeze = freeze.replace('["cases"]) == 5', '["cases"]) == 6').replace('all five cases', 'all six cases')
assert "git('rev-parse','802c7130e')" in freeze and '["cases"]) == 6' in freeze
(lab / 'freeze-and-verify.py').write_text(freeze, encoding='utf-8', newline='\n')
subprocess.run([sys.executable, '-X', 'utf8', lab / 'freeze-and-verify.py'], check=True)
allocation = lab.parent / 'postfix-statement-r699' / 'measure-compile-allocation.py'
subprocess.run([sys.executable, '-X', 'utf8', allocation, lab], check=True)
