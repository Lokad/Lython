from pathlib import Path
import json
import subprocess
import sys

lab = Path(__file__).resolve().parent
old = lab.parent / 'selected-abstract-path-r713'
stage = (old / 'stage-quiet.py').read_text(encoding='utf-8')
stage = stage.replace('selected-abstract-path-b1144', 'source-annotation-mode-b1145')
stage = stage.replace('lython-b1144-selected-abstract-path', 'lython-b1145-source-annotation-mode')
stage = stage.replace('lython-b1144-fixtures', 'lython-b1145-fixtures')
stage = stage.replace('R713 selected abstract binding paths', 'R714 source-selected annotation mode')
stage = stage.replace('Selected abstract binding paths', 'Source-selected annotation mode')
first = stage.index('        jobs = [')
last = stage.index('\n', first)
case = 'scripts.annotated-rule-closures'
jobs = [(case, 'warm'), (case, 'compile-run'), (case, 'compile'),
        (case + '.observed', 'warm'), ('scripts.rule-default-closures', 'warm'), ('scripts.csv-invoice.large', 'warm')]
available = {row['id'] for row in json.loads((lab / 'catalog.json').read_text(encoding='utf-8'))['cases']}
assert all(name in available for name, _ in jobs)
stage = stage[:first] + '        jobs = ' + repr(jobs) + stage[last:]
stage = stage.replace('three-case, six-job', 'four-case, six-job').replace('}) == 3', '}) == 4')
proof = (old / 'prove-quiet-space.py').read_text(encoding='utf-8')
a, b = proof.index('pairs = '), proof.index('\n', proof.index('pairs = '))
proof = proof[:a] + 'pairs = []' + proof[b:]
for name, value in [('prove-quiet-space.py', proof), ('stage-quiet.py', stage)]:
    (lab / name).write_text(value, encoding='utf-8', newline='\n')
    subprocess.run([sys.executable, '-X', 'utf8', lab / name], check=True)
