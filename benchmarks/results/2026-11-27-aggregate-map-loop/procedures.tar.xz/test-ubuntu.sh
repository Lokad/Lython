set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
repo=/mnt/d/code/Lython
notes="$repo/.git/agent-notes/review-20261031"
lab="$notes/aggregate-map-loop-20261127"
work=$(tr -d '\r\n' < "$notes/current-short-script-profile-20261127/ubuntu-source.txt")
case "$work" in "$HOME"/lython-starmap-rows-*) ;; *) exit 4 ;; esac
cd "$work"
for part in src/Lokad.Lython/Runtime/PyIteration.cs src/Lokad.Lython/Runtime/PyBuiltinIterators.cs src/Lokad.Lython/Runtime/LythonRuntime.BuiltinIterables.Aggregates.cs tests/Lokad.Lython.PublicApi.Tests/SumCursorCompatibilityTests.cs; do
    cp "$repo/$part" "$part"
    cmp "$repo/$part" "$part"
done
filter='Category!=Stress&(FullyQualifiedName~Sum|FullyQualifiedName~IteratorAdapterCallback|FullyQualifiedName~IteratorScalarIdentity|FullyQualifiedName~IteratorValueAccounting|FullyQualifiedName~Generator|FullyQualifiedName~Starmap|FullyQualifiedName~AdmissionFailureCommand|FullyQualifiedName~ExecutableStackAdmission)'
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
  log="$lab/$suite-ubuntu10.log"
  if dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --filter "$filter" > "$log" 2>&1; then tail -7 "$log"; else tail -40 "$log"; exit 1; fi
done
