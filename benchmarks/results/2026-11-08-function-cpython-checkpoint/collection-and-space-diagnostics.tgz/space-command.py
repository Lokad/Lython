from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();groups={'4c64ac3c8f928db96c24a04f953d153f68ef73e7cb9f79fdd35592bff873aa5c': ['/home/lokad/lython-bench-checks/frame-transfer-8366e832-20261013/before/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/call-transfer-09aeae83-20261013/before/Lokad.Lython.dll'], 'cb0030174b3e11db90fd16136175582e88a3cd74512771746814c265fcb53957': ['/home/lokad/lython-bench-checks/file-search-b79-20261102/worker/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/compile-native-b86-20261102/wrapper/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/cfg-b81-20261102/baseline/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/frontend-b80-20261102/wrapper/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/frontend-b80-20261102/worker/Lokad.Lython.dll'], '48f4690c8501a2e0205d7c1bc2c4149dea67ebe098830844ec22b551c3d3b0a7': ['/home/lokad/lython-bench-checks/dict-views-b303-20261105/baseline/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/dict-views-b303-20261105/reference/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/counter-keys-final-b302-20261105/candidate/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/counter-keys-final-b302-20261105/core/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/dict-views-final-b304-20261105/baseline/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/dict-views-final-b304-20261105/reference/Lokad.Lython.dll'], 'e55e7fcc0edd975339007c85c70bde53eb29ec500ff0089d9e282b5ffd3747d5': ['/home/lokad/lython-bench-checks/instruction-boundary-b287-20261105/candidate/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/instruction-boundary-b287-20261105/core/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/instruction-boundary-confirm-b288-20261105/candidate/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/instruction-boundary-confirm-b288-20261105/core/Lokad.Lython.dll']}
with(base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 before=shutil.disk_usage(base).free;inventory={};aliases={}
 for digest,names in groups.items():
  rows=[]
  for name in names:
   p=Path(name).resolve();assert base in p.parents and p.name in ('Lokad.Lython.dll','baseline-core.dll','current-core.dll')
   assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
   aliases[name]=dict(path=str(p),sha256=digest)
   if any(row['path']==str(p) for row in rows):continue
   st=p.stat();rows.append(dict(path=str(p),inode=st.st_ino,bytes=st.st_size,links=st.st_nlink))
  inventory[digest]=rows
 selected=[];saved=0
 for digest,rows in inventory.items():
  canonical=rows[0];byinode={row['inode']:[x for x in rows if x['inode']==row['inode']] for row in rows}
  for inode,paths in byinode.items():
   if inode==canonical['inode'] or len(paths)!=paths[0]['links']:continue
   selected.append(dict(sha256=digest,canonical=canonical,paths=paths));saved+=paths[0]['bytes']
   break
  if saved>=4*1024*1024:break
 assert 4*1024*1024<=saved<=8*1024*1024,(saved,inventory)
 proof=base/'r122-core-dedup-proof.json';assert not proof.exists()
 for group in selected:
  for row in [group['canonical'],*group['paths']]:
   p=Path(row['path']);st=p.stat();assert st.st_ino==row['inode'] and st.st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==group['sha256']
 for group in selected:
  canonical=Path(group['canonical']['path'])
  for row in group['paths']:
   p=Path(row['path']);temporary=p.with_name(p.name+'.r122-identical-link');assert not temporary.exists()
   os.link(canonical,temporary);os.replace(temporary,p)
 for name,row in aliases.items():
  p=Path(name);assert str(p.resolve())==row['path'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
 receipt=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,groups=selected,freshInventory=inventory,aliases=aliases,allPathsAndBytesPreserved=True,archivesUntouched=True,allOriginalAliasesVerified=True)
 proof.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
