from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'function-cpython-b481-20261108';reference=base/'function-lookups-b479-20261108/candidate'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(106574+1);assert len(payload)==106574 and hashlib.sha256(payload).hexdigest()=='b84727a26814f27d84b948da4f7ee44c5228725382fb985988c9884ec9ccdd74'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:
  payloadRequired=sum(((m.size+4095)//4096)*4096 for m in a.getmembers());assert payloadRequired<12582912
  required=251658240+12582912+payloadRequired
  assert shutil.disk_usage(base).free>required,(shutil.disk_usage(base).free,required)
  root.mkdir();a.extractall(root,filter='data')
 identity=json.loads((root/'identity.json').read_text());assert set(identity['coreSHA256'])=={'candidate','candidate-control'}
 proof=json.loads((root/'core-source.json').read_text());archive=base/proof['vmArchive']
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==proof['archiveSHA256']
 with tarfile.open(archive)as a:assert hashlib.sha256(a.extractfile(proof['member']).read()).hexdigest()==proof['coreSHA256']
 shutil.copytree(reference,root/'candidate',copy_function=os.link);os.link(reference/'Lokad.Lython.dll',root/'current-core.dll')
 assert hashlib.sha256((root/'current-core.dll').read_bytes()).hexdigest()==identity['coreSHA256']['candidate']
 assert identity['coreSHA256']['candidate']==identity['coreSHA256']['candidate-control']
 for n,h in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/'candidate'/n).read_bytes()).hexdigest()==h
 (root/'cpython-worker.py').symlink_to(base/'prepared-call-layout-b384-20261107/cpython-worker.py')
 for n in ['collect.py','archive-owned.py']:ast.parse((root/n).read_text())
 assert 'assert len(jobs)==15 'in(root/'collect.py').read_text()and"len(r['jobs'])==15"in(root/'archive-owned.py').read_text()
 assert "labels=['CPython','candidate','candidate-control']"in(root/'collect.py').read_text()
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b481-fixtures',str(fixture)],check=True)
 try:
  setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndEveryAuxiliaryVerified=True,all15JobsValidated=True,ownerSeconds=360,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,totalEvidenceAllowanceBytes=12582912,payloadRoundedBytes=payloadRequired)
  assert setup['freeBytes']>251658240+12582912
  (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
  fcntl.flock(lease,fcntl.LOCK_UN)
  subprocess.run(['sudo','-n','systemd-run','--unit=lython-b481-function-cpython-20261108','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=360','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
 except BaseException:
  subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
