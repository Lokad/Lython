from pathlib import Path
import json,subprocess
r=Path(__file__).parent
assert (r/'terminal-status.json').exists() and not (r/'space-post-audit.json').exists()
s=json.loads((r/'terminal-status.json').read_text(encoding='utf-8'));assert s['exitCode']=='0' and not s['remainingWorkers']
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=(r/'space-post-audit-command.py').read_bytes(),capture_output=True)
(r/'space-post-audit.stdout').write_bytes(p.stdout);(r/'space-post-audit.stderr').write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode()
d=json.loads(p.stdout);assert d['readOnlyAudit'] and d['allKnownPathsAndBytesPreserved'];(r/'space-post-audit.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8');print('Idle-lease audit passed:',len(d['aliases']),'original aliases unchanged, temporary links:',d['temporaryLinks'])
