from pathlib import Path
import json, shutil, tarfile

root = Path('D:/code/Lython')
private = Path(__file__).parent
dest = root / 'benchmarks/results/2026-11-08-function-cpython-checkpoint'
dest.mkdir(exist_ok=True)
for name in ['summary.json', 'identity.json', 'archive-receipt.json', 'sizing.json',
             'prior-BENCHMARKS.md', 'space-post-audit.json', 'observations.tgz']:
    assert not (dest / name).exists(), name
    shutil.copy2(private / name, dest / name)
with tarfile.open(dest / 'collection-and-space-diagnostics.tgz', 'w:gz') as archive:
    for path in sorted(private.iterdir()):
        if path.is_file() and path.suffix != '.tgz':
            archive.add(path, arcname=path.name)

summary = json.loads((private / 'summary.json').read_text(encoding='utf8'))
cases = [
    ('scripts.csv-validated-records.large', 'CSV validation/helper calls', '5,120 records / 68,625 B'),
    ('scripts.csv-summary-functions.large', 'CSV summary/helpers', '4,096 records / 57,361 B'),
    ('scripts.text-summary-helpers.large', 'Text summary/helpers', '3,072 lines / 35,840 B'),
    ('scripts.json-summary-helpers.large', 'JSON-lines/helpers', '4,096 records / 110,592 B'),
    ('scripts.report-render.large', 'JSON-to-Markdown report', '3,072 records / 189,441 B'),
]

def table(lane):
    include_input = lane == 'compile-run'
    rows = ['| Workload | ' + ('Input | ' if include_input else '') +
            'Lython | CPython | Lython / CPython | Status; control / max IQR |',
            '| --- | ' + ('--- | ' if include_input else '') + '---: | ---: | ---: | --- |']
    for key, title, size in cases:
        item = next(x for x in summary['timing'] if x['case'] == key and x['lane'] == lane)
        factor, unit, digits = (1000, 'µs', 1) if lane == 'compile' else (1, 'ms', 3)
        low, high = item['timeRangeMilliseconds']
        ref = item['medianMilliseconds']['CPython']
        a, b = item['ratioRange']
        rows.append(f'| {title} | ' + (f'{size} | ' if include_input else '') +
                    f'{low*factor:.{digits}f}–{high*factor:.{digits}f} {unit} | '
                    f'{ref*factor:.{digits}f} {unit} | {a:.2f}–{b:.2f}× | '
                    f'{item["status"]}; {item["controlPercent"]:.2f}% / '
                    f'{max(item["iqrPercent"].values()):.2f}% |')
    return '\n'.join(rows)

path = root / 'docs/BENCHMARKS.md'
doc = path.read_text(encoding='utf8')
for lane, occurrence in [('compile-run', 0), ('warm', 1), ('compile', 2)]:
    start = [i for i in range(len(doc)) if doc.startswith('| Workload |', i)][occurrence]
    end = doc.index('\n\n', start)
    doc = doc[:start] + table(lane) + doc[end:]
doc = doc.replace('source `b1e17b64`', 'source `6f76f99d`')
start = doc.index('These measurements describe')
end = doc.index('## Warm execution', start)
doc = doc[:start] + '''These measurements describe the named runtime source, rather than subsequent HEAD
changes. Frozen core `c6172fec` matches the production inventory. Test-only commit
`d97ca8f2` corrects a stale internal fixture; combined Windows/Ubuntu actual.NET11/
.NET10, original stress and installed-core qualification is pending. Source
qualification and performance evidence are separate.

The [R122 checkpoint](../benchmarks/results/2026-11-08-function-cpython-checkpoint/README.md)
reuses five unchanged scripts, catalog/goldens and workers: 15 jobs / 311.685s.
All quiet/output/ownership/cleanup/archive gates pass; no remaining VM users or
fixtures. The [prior guide](../benchmarks/results/2026-11-08-function-cpython-checkpoint/prior-BENCHMARKS.md)
preserves the earlier qualified `b1e17b64` comparison. Ratios from separate
checkpoints do not isolate individual optimization gains.

''' + doc[end:]
doc = doc.replace('not b1e17b64', 'not `6f76f99d`')
marker = '| Primitive helper proof / complete accounting |'
index = doc.index(marker)
doc = doc[:index] + '''| Execution-owned function lookup facts / report and CSV helpers | Controlled report elapsed −6.09–6.66%; validated CSV −3.30–5.45%, supporting CPU; allocation neutral | Separate R121 source pair; inline control ±0.60%, async float variable. Combined earlier pair retains possible +1–2% async-float debt. [R121](../benchmarks/results/2026-11-08-function-lookup-lifetimes/README.md) |
| Flat lookup storage / shared record fields | Complete CSV/JSON elapsed roughly −5–10%; custom CSV −3–6%, supporting CPU | R119 source pair; text uncertain, report CPU +1.53–6.25% possible debt. Subsequent exclusion cleanup reduces custom allocation 1.71%, without a CPU claim. [R119](../benchmarks/results/2026-11-08-record-field-resolution/README.md), [R120](../benchmarks/results/2026-11-08-cache-eligibility/README.md) |
''' + doc[index:]
path.write_text(doc, encoding='utf8')

(dest / 'README.md').write_text('''# Representative function-lookup-source CPython checkpoint

2026-11-08, R122/B481. Measured runtime `6f76f99d876ad7f3678ed4f4ecc416619c648642`,
frozen core `c6172fec`; exact production inventory and auxiliary hashes in
[identity](identity.json). Test-only fixture fix `d97ca8f2` leaves runtime source
unchanged. Combined platform/stress/installed-core qualification is pending;
earlier qualified revisions retain independent receipts.

Five unchanged maintained scripts, separately compilation, warm execution and
compile-to-result: 15 jobs / 311.685s. Isolated CPython 3.13.16 versus .NET 11 RC3,
dedicated Azure F4as_v7, Ubuntu 24.04.4, four EPYC 9V45 vCPUs, 16 GiB/no swap.
Normal GC/tiering, two independent Lython processes, five-second warmup per
role/job and seven rotated 150ms rounds. Frozen worker `7cf`, optional adapter
0.4, existing catalogs, full stdout/file goldens and protocol unchanged.

''' + table('compile-run') + '''

Ratio = Lython elapsed / CPython elapsed; above one means slower. Ranges span two
independent Lython medians, not confidence intervals. Control is their absolute
difference; max IQR includes CPython. Variable observations remain inconclusive.
All compile/warm roles, process CPU and controls are in [summary](summary.json).

Warm includes invocation, mediated RAM-file I/O, complete validation and cleanup
of the previous result. Compilation includes construction/disposal under the
shared allowance; compile-to-result includes both. Startup, staging/reset,
protocol and final cache teardown are outside clocks. CPython retains imports;
Lython isolates execution imports. Pending I/O, RSS and embedding-tail impact
remain unmeasured. Historical configuration/search/manifest cases were not rerun.
No isolated causal gain, source-pair subtraction or new regex qualification.

All Ready/source/core/auxiliary/golden/balance/quiet/Closed/exit/join/unmount/
archive/local-verification gates pass. Finite 360s owner; persistent raw evidence
separate from owned RAM fixtures. No users or fixtures remain. Archive SHA256:
`6ca0ff4988817f2b057fd29c64429025e4ab2ddd76f0fba13c974c98df49f7ca`.

The optional historical exact-byte hardlink preparation failed with EPERM on a
root-owned old DLL. Original stderr/command and all conditions are preserved.
Launch independently passed actual payload + 240MiB OS floor + 12MiB headroom.
A subsequent read-only audit under a fresh idle lease verified all 17 original
aliases and hashes unchanged, with no temporary links. Future preparation must
preflight permitted canonical ownership/writable parents and journal before
mutation. No deletion, chmod workaround or measurement rerun.

[Raw observations](observations.tgz), [receipt](archive-receipt.json),
[sizing](sizing.json), [alias audit](space-post-audit.json),
[collection/source/failure diagnostics](collection-and-space-diagnostics.tgz),
[prior guide](prior-BENCHMARKS.md). Current source-pair gains and adverse controls
remain in the separate R119–R121 evidence; this checkpoint does not repay them.
''', encoding='utf8')

history = root / 'benchmarks/EXPERIMENTS.md'
with history.open('a', encoding='utf8') as f:
    f.write('''

## Function-lookup-source CPython checkpoint (2026-11-08)

[R122/B481](results/2026-11-08-function-cpython-checkpoint/README.md), runtime6f76/
corec617, CPython3.13.16, 15jobs/311.685s/allgates/archive/local verified.
Compile-to-result validatedCSV1.17x, CSV1.01–1.03xvariable, text1.52–1.53x,
JSON0.91–0.96xvariable, report1.32–1.33x. Compile/warm/CPU/control separate;
not source-pair causal gains or repayment of earlier debts. Prior guide and
historical726cases retained. Optional dedup EPERM preserved, independent launch
space preflight passed; fresh idle audit17aliases unchanged/no temporarylinks.
Test-only fixture fixd97 leaves measured runtime unchanged; combined full delivery
pending. No new framework, unchanged producer qualification or publication.
''')
print('Published verified R122 evidence and refreshed all three benchmark tables.')
