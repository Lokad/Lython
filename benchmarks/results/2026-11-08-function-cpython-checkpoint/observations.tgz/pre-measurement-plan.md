# Lokad.Lython 0.11.0

Updated2026-11-08. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Current contracts belong in docs; history/adverse results live in
[EXPERIMENTS](benchmarks/EXPERIMENTS.md) and linked immutable results.

## Delivery status

- **Earlier fully qualified b1e17b64/core93e926fe:** cached CI42512127664,
  Windows/Ubuntu actual.NET11/.NET10 full Release, original Stress both, installed
  core consumers. Shared compiler-fact correction, direct UTF8 formatting/storage,
  native helper returns and R105/R106/R110 are delivered; R113–R115 shares primitive
  result-shape facts and removes proof source offsets/ordinary-forwarding exclusion.
  Do not repeat completed qualification.
- **Fully qualified production R119 d05b3359/core19b8b5a5:** flat
  existing lookup storage/shared immutable CSV/JSON field positions. No new opcode,
  owner/engine/framework/public API. Refined33internal/14public peractual11/10 pass.
  Cached CI42519822299success observed20:49:16UTC: Windows/Ubuntu actual11/10
  full Release, original Stress both and installed core consumers. No requery.
- **Committed/pushed R120 ca83509f:** delete unused member-cache table acquisition
  for receivers already excluded from caching. Existing exclusion is consolidated;
  existing stale slots clear without allocating a new table. Baseline d05/core19b8;
  24internal/214public per actual11/10 and five-case diagnostic pass. Custom
  allocation−1.71% across APIs, others nearneutral; adverse text/custom desktop
  timing preserved, no CPU claim. Retained cleanup; full new-source delivery
  pending the next coherent boundary.
- **Distinct claims:** original native-return allocation−19.92/−19.31%, elapsed
  diagnostic. Formatting allocation−8.67%, controlledB102elapsed/CPU−5–8%; original
  adverse15.125ms unexplained/preserved. R110wide allocation−8.56–8.58%. R115native
  integer/float gains and compile metadata cost remain source-pair-specific. Do not
  net independent measurements or silently settle earlier custom/config/report debts.
- **R119 measured outcome:** B4788jobs224.323s, all gates/archive/localverified.
  Integer/float CSV and integer JSON elapsed~5–10%lower/supportingCPU; custom CSV
  ~3–6%lower across APIs. Allocation near neutral except custom+0.575% (~64KiB);
  compile allocation unchanged. Text inconclusive, reportCPU+1.53–6.25%possible debt.
  Accepted this bounded debt with measured gains; R120 addresses its actual cause.
  Initial138b6a09 report+9.02%allocation and adverse timings remain. Census corrected
  the mistaken native-report inference: ordinary render acquired a96B array percall;
  only reusable loop/eager-comprehension field slots now allocate, removing that cost.
- **External baseline:** [BENCHMARKS](docs/BENCHMARKS.md), R117qualifiedb1/core93e9
  versus CPython3.13.16,15jobs311.431s. Compile-to-result CSV1.06–1.07x, returnedCSV
  1.23–1.25x, text1.52x, JSON0.92–0.96xvariable, report1.42–1.46xvariable. Separate
  compilation/warm/I/O/validation/cleanup. These do not describe newer HEAD.
  Config/search/manifest/extra variants remain historical726; startup/RSS/pending-I/O/
  embedding tails unmeasured. Refresh representative comparisons at next coherent
  checkpoint, not every edit. No general causal speed inference from diagnostic rows.

## Prioritized deliverables

1. **Close R119 delivery and R120 cleanup, continue independent work meanwhile.**
   Observe the single R119CI at its recorded boundary; handle real failures without
   repeating old green jobs. R120 removes cache allocation/reservation work for
   instance/type/super/function/contextual-dynamic targets that cannot ever publish
   a cached value. Preserve cacheable receiver preflights, fresh method identity,
   mutation/descriptors/real suspension, terminal refusal, retained aliases and
   awaited cleanup. No new owner/pool/table policy or scalar representation. Existing
   focused Release tests actual11/10 and one short unchanged five-case allocation
   diagnostic; distinguish allocation/simplification from CPU. Retain/refine/reject
   explicitly, then batch its full qualification with the next coherent delivery.
   Do not call R119CI qualification of later R120 source.

2. **R121 retained redesign: qualify function-lifetime lookup facts.**
   Existing function ownership may permit flat lookup facts to survive calls,
   eliminating function per-frame cache construction and repeated shared-record
   field hashing in report/CSV/JSON helpers. Keep canonical executable formatting/
   reads; admission can change later fields into suspending values. No second
   formatter, speculative mutable type proof, global code dictionary or new cache
   owner/framework. Source gate~20min: prove existing definition/cache/retained and
   pending lifetimes, reentrant first admission, recursion/closures and independent
   runs. If it needs new ownership/reachability/API machinery, record uncertainty
   and stop that candidate. Source gate supports a bounded prototype; baseline9ae0 frozen before edits.
   Committed/pushed 6f76f99d/frozen c6172fec:83internal/2133public per actual11/10 pass,
   including reentrant allocation/cancel/refusal and actual suspended formatting.
   Initialc54 frame-width+8B/custom allocation+0.871% explained/preserved;
   single existing storage slot restores72/120B frames and neutral allocations.
   Desktop custom+22–25% adverse/unstable controls preserved. B4798jobs224.145s
   combined source comparison variable: report8.35%candidate spread, possible
   asyncfloat+1–2%debt. B480four-job confirmation194.529s isolates R121 versus
   ca835: report−6.09–6.66%, validatedCSV−3.30–5.45%/supportingCPU; inline
   control±0.60%, asyncfloat−1.36..+1.08%variable. Allgates/archive/local pass.
   Retain c617 with explicit original/control debt, no universal CPU claim.
   Function per-call cache construction and repeated field hashing/probing are
   displaced; fixed frame width72/120B preserved. Focused actual11/10 and bounded
   complete report/CSV/JSON/control comparisons done; add15provider callbacks per
   target. Document longer execution-owned capacity retention and cleanup.
   Next commit and one combined full delivery,
   compile/allocation/CPU separate. Batch retained delivery with R120.

3. **Select the next substantial redesign from surviving work.** Text/report gaps
   remain~1.5x; completion of another isolated experiment does not close the objective.
   For each selection record hypothesis, work/storage removed, affected complete
   scripts, semantic/cancellation/ownership acceptance, displaced code to delete and
   bounded before/after controls BEFORE implementation. Temporary setbacks need an
   explicit completion milestone and a regression-debt decision.

   - Complete calls/frames/operand transport: direct arguments, deferred contexts,
     reusable workspaces and native returns already remove older packaging phases.
     R116binding/context0leaf; R108routing3.96%leaf, inclusive84%contains useful work.
     Current ordinary render borrows bound locals; no captures/patterns means zero
     frame-storage admission and Reserve(0) does not resize the root. Do not invent
     another removable frame array. Assess shared canonical operation execution
     across ordinary/native routes while preserving later mutable/suspending fields.
     No revival of the rejected separate formatter or slower R71arena/control/carrier.
   - Per-record construction: JSON direct values/shared layouts and CSV array
     adoption already eliminate earlier copies. Bulk CSV6–8% was reassessed with
     its adverse control; the proposed copying is gone, no automatic promotion.
     Further work must identify actual current intermediates and preserve key/order/
     duplicate/hooks/retained rows. R119 removes repeated field resolution, not row
     construction; R118 guarded get/add/store would duplicate conditional CFG/proofs
     plus the original sequence and selected no prototype. Not a permanent ban.
   - Text/frontend: native UTF8/inline strings/casing-split/final-buffer formatting/
     shared compiler facts are established. Unchanged UTF8 file windows already borrow
     raw bytes; returned copies preserve immutability across refill. Borrowed string
     views need a representation/ownership tradeoff, not deletion of an absent decode
     copy. Native strings already cache hashes; scalar dict updates/split commits do
     not resize the root. No second evaluator/parser/formatter or universal tagged
     slots/JIT/stack rewrite from boxing/inclusive samples alone. Selected conversion/
     analysis work needs exact callers and measured allocation/CPU; compile separately.

   Source gate~20min, then use existing capture or one short targeted diagnostic if
   material attribution is missing. Stop gathering when a coherent candidate is
   attributable/testable, or record specific uncertainty and pursue an independent
   track. No open-ended inventory/measurement campaign or unmeasured narrow paths.

4. **Independent regex contract and implementation.** Core owns Python/nativeUTF8
   names, byte captures/scalar positions/original windows, flags/errors/replacements,
   cache ownership/current tokens, one frontend/runtime/import provider. Optional
   adapter nonpackable, ordinary0.4pin. Dev55/d6067925 checks86internal/514public per
   actual11/10 completed; no unchanged replays or sibling edits/builds. Missing released
   producer capabilities: DetailedData separate preparation/working owner, native-name
   enumeration, cursor creation without retaining an earlier token. Adapter-local
   bridges/development producers support development. Missing release defers only
   affected final adapter qualification, never core work. Separate contract forwarding/
   unwind, Python semantics and actual backend performance. Publication postponed.

## Operating policy

Bounded confirmation/refinement/measurement correction is allowed when justified.
Timeout, unstable unchanged controls or inconclusive timing mean uncertainty, not
failed design or permanent closure. Percentages inform decisions, not automatic
vetoes. Preserve all adverse/source/control conditions; do not quietly retime them away.

AGENTS.md governs fully managed memory safety, stack admission, host mediation,
current-token cancellation, shared coarse admission/preflights/replacement overlap,
funded aliases/results/caches/pending users and awaited cleanup. Refusal is terminal.
No unsafe/Unsafe/native probes, tracing/weak reclaim/forcedGC, independent caps/fuel/
quotas, hidden default allowance, silent regex fallback or abandoned work. No local
build/test/measurement overlap; fresh nonincremental build after timestamp-preserving
restores. Explicit UTF8. Only core Release pack to artifacts/nuget.

VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem. Persistent worker/catalog/raw,
owned RAMfixtures separate; join, verify maps, unmount, archive under lease and verify
locally. No evidence deletion. Exact-byte hardlinks need fresh inode/SHA/all-alias
proof. B450–B478terminal/cached/archived locally verified, no VM users/fixtures;
never requery. All older terminal CI including42512127664 and42519822299 cached, never query again.

Metadata HEAD 7ddf7056 records cached R119delivery only; production ca835 cleanup remains focused, R121 retained at 6f76f99d. No new CI dispatch or old terminal query.

B479 andB480terminal/cached, raw/maps archived locally verified, no VM users or fixtures remain; never requery. B480 inherited allEightJobs setup label/offline eight-job assertion were corrected in interpretation/analyzer only; actual four-job runtime/finite240s/archive facts preserved, no rerun.

Combined R120/R121 committed/pushed 6f76f99d876ad7f3678ed4f4ecc416619c648642: one full delivery dispatch; qualification pending. First observation after 2026-11-08T21:35:55.049941+00:00. No old terminal query or duplicate dispatch.
