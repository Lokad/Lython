from pathlib import Path
import hashlib,json,subprocess,tarfile,shutil
r=Path('/home/lokad/lython-bench-checks/ordered-helper-profile-b619-20261112')
assert all(json.loads((r/n).read_text())['gate']['quiet']for n in ['machine-before.json','machine-after.json'])
assert not Path('/home/lokad/lython-bench-checks/ordered-helper-profile-b619-20261112/guest-fixtures').exists()
assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
assert shutil.disk_usage(r).free>240*1024*1024
seconds=0
for name in ['native-search-reference', 'native-search-candidate']:
 p=r/'profiles'/name;record=json.loads((p/'record.json').read_text())
 assert record['exitCode']==0 and record['closed']['status']=='Closed'
 assert all(record[n]['status']=='Equivalent'for n in ['verificationBefore','verificationAfter'])
 assert (p/'worker.stderr').stat().st_size==0
 assert record['redundantTemporaryMapsRetiredAfterJoin']
 assert (p/'perf.map').stat().st_size>0
 elapsed=record['response']['elapsedTicks']/record['response']['clockFrequency'];assert elapsed<10;seconds+=elapsed
assert seconds<16
with tarfile.open(r/'observations.tgz','w:gz',dereference=True)as a:
 for p in sorted(r.rglob('*')):
  if p.is_file()and p.name!='observations.tgz'and 'candidate'not in p.relative_to(r).parts:a.add(p,arcname=p.relative_to(r).as_posix())
assert shutil.disk_usage(r).free>240*1024*1024
with tarfile.open(r/'observations.tgz')as a:
 for name in ['native-search-reference', 'native-search-candidate']:assert json.loads(a.extractfile('profiles/'+name+'/record.json').read())['exitCode']==0
receipt=dict(complete=True,allWorkersJoined=True,guestFixturesRemoved=True,quietBeforeAndAfter=True,archivedAndVerifiedUnderLease=True,capturedSeconds=seconds,archiveSHA256=hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest(),performanceQualified=False)
(r/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
