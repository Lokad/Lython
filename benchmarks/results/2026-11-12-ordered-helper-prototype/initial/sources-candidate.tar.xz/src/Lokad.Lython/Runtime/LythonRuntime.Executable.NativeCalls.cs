using System.Numerics;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    // Conditional branches and unary not need the same closed truth contract.
    // Other values may run Python protocols and require their invocation frame.
    private static bool CanUseNativeTruth(object value)
        => value is PyNone or bool or BigInteger or double or PyString or PyBytes
            or PyList or PyTuple or PyDict or PySet or PyRange;

    // Exact receiver arguments stay in the common prefix. Protocol values
    // acquire an invocation context before the ordinary binder runs.
    private static NativeStringOperation? SelectNativeStringOperation(object? target, int argumentCount)
        => ReferenceEquals(target, ReceiverMethods.StringSplit) && argumentCount is 1 or 2 ? NativeStringOperation.Split
            : ReferenceEquals(target, ReceiverMethods.StringReplace) && argumentCount is 2 or 3 ? NativeStringOperation.Replace
            : ReferenceEquals(target, ReceiverMethods.StringStartsWith) && argumentCount == 1 ? NativeStringOperation.StartsWith
            : ReferenceEquals(target, ReceiverMethods.StringEndsWith) && argumentCount == 1 ? NativeStringOperation.EndsWith
            : null;

    private static bool CanUseNativeStringArguments(NativeStringOperation operation, object? first, object? second, object? third)
        => operation switch
        {
            NativeStringOperation.Split => first is null or PyNone or PyString
                && second is null or PyNone or BigInteger or bool,
            NativeStringOperation.Replace => first is PyString && second is PyString
                && third is null or PyNone or BigInteger or bool,
            NativeStringOperation.StartsWith or NativeStringOperation.EndsWith => first is PyString,
            _ => throw new InvalidOperationException("Unknown string operation.")
        };

    private static object InvokeNativeStringOperation(NativeStringOperation operation, PyString receiver,
        object? first, object? second, object? third, LythonSourceSpan span, ExecutionContext context)
        => operation switch
        {
            NativeStringOperation.Split => InvokeStringSplit(receiver, first, second, span, context),
            NativeStringOperation.Replace => InvokeStringReplace(receiver, first!, second!, third, span, context),
            NativeStringOperation.StartsWith or NativeStringOperation.EndsWith =>
                InvokeStringAffix(receiver, first!, span, context, operation == NativeStringOperation.StartsWith),
            _ => throw new InvalidOperationException("Unknown prepared string operation."),
        };

    private static Func<object, LythonSourceSpan, ExecutionContext, object>? SelectNativeUnaryOperation(
        object? target, object? value)
    {
        if (target is not BuiltinCallable builtin) return null;
        return builtin.Name switch
        {
            "int" when value is PyString or PyBytes => IntegerTextOperation,
            "float" when value is PyString or PyBytes => FloatTextOperation,
            "str" when value is BigInteger or PyString => NativeStrOperation,
            "abs" when ExecutionContext.IsAbsoluteBuiltin(target) && value is BigInteger or double or bool => AbsoluteOperation,
            "sum" when ExecutionContext.IsSumBuiltin(target) && value is PyBytes => SumBytesOperation,
            "len" when ExecutionContext.IsLengthBuiltin(target) && value is not null and not PyInstance => LengthOperation,
            _ => null
        };
    }
}
