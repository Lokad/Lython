using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    // A synchronous borrow, never an owner or an asynchronous continuation.
    // The same operations serve persistent arrays and transient managed slots.
    internal partial struct ExecutableValueStorage
    {
        internal ref struct BorrowedValues(ref ExecutableValueStorage owner, Span<object> values)
        {
            private ref ExecutableValueStorage _owner = ref owner;
            private Span<object> _values = values;
            internal Span<object> Values => _values;
            internal int LiveExtent => _owner.LiveExtent;
            internal bool HasPendingDisposals => _owner.HasPendingDisposals;
            internal void CheckExecution(LythonSourceSpan span) => _owner.CheckExecution(span);
            internal ExecutableLookupCache[] GetLookupCaches(int count, LythonSourceSpan span) => _owner.GetLookupCaches(count, span);
            internal void ClearLookupCache(int index) => _owner.ClearLookupCache(index);
            public object this[int index]
            {
                get => _values[index].RequireNotNull();
                set => _values[index] = value;
            }

            internal void PublishValue(int resultSlot, int liveExtent, object result)
            {
                // Inputs and their owner stay live through callbacks/suspension.
                // Retire only after success, preserving failed-disposal behavior.
                if (liveExtent < _owner.LiveExtent) RetireTo(liveExtent);
                _values[resultSlot] = result;
                _owner.LiveExtent = liveExtent;
            }

            internal object TakeValue(int inputSlot, int liveExtent)
            {
                var value = _values[inputSlot].RequireNotNull();
                _values[inputSlot] = null!;
                _owner.LiveExtent = liveExtent;
                return value;
            }

            // The completed operation consumed this input, as PublishValue would
            // overwrite it. Its result goes directly to a binding instead.
            internal void ForgetResultInput(int resultSlot)
            {
                _values[resultSlot] = null!;
                _owner.LiveExtent = resultSlot;
            }

            internal bool TryPrepareNativeIteration(object source, int slot, int liveExtent, LythonSourceSpan span)
            {
                if (source is PyStringOps.CasedWhitespaceIteration)
                {
                    PublishValue(slot, liveExtent, source);
                    return true;
                }
                if (source is not (PyList or PyTuple)) return false;
                if (_owner._nativeIterationPositions is null)
                {
                    // The existing private operand keeps the source alive. One
                    // admitted position array replaces repeated native cursor and
                    // enumerator objects; it shares this frame's storage lifetime.
                    var bytes = checked(32L + 4L * (_values.Length - _owner._firstTemporarySlot));
                    var frameBytes = checked(_owner._ownedStorageBytes + bytes);
                    using var storage = _owner._state.MemoryGovernor.ReserveTemporary(bytes, span);
                    var positions = new int[_values.Length - _owner._firstTemporarySlot];
                    storage.Commit(bytes);
                    _owner._nativeIterationPositions = positions;
                    _owner._ownedStorageBytes = frameBytes;
                }
                _owner._nativeIterationPositions[slot - _owner._firstTemporarySlot] = 0;
                PublishValue(slot, liveExtent, source);
                return true;
            }

            internal bool TryAdvanceNativeIteration(int slot, out PyIterationResult next)
            {
                switch (_values[slot])
                {
                    case PyStringOps.CasedWhitespaceIteration words:
                        next = words.MoveNext();
                        return true;
                    case PyList list:
                        var listIndex = _owner._nativeIterationPositions![slot - _owner._firstTemporarySlot];
                        next = listIndex < list.Count ? PyIterationResult.Yield(list[listIndex]) : PyIterationResult.End;
                        if (next.HasValue) _owner._nativeIterationPositions[slot - _owner._firstTemporarySlot] = listIndex + 1;
                        return true;
                    case PyTuple tuple:
                        var tupleIndex = _owner._nativeIterationPositions![slot - _owner._firstTemporarySlot];
                        next = tupleIndex < tuple.Count ? PyIterationResult.Yield(tuple[tupleIndex]) : PyIterationResult.End;
                        if (next.HasValue) _owner._nativeIterationPositions[slot - _owner._firstTemporarySlot] = tupleIndex + 1;
                        return true;
                    default:
                        next = PyIterationResult.End;
                        return false;
                }
            }

            public ReadOnlySpan<object?> Slice(int start, int count) => _values.Slice(start, count);

            public void RetireTo(int liveExtent)
            {
                if (liveExtent == _owner.LiveExtent)
                {
                    return;
                }

                var newCount = liveExtent;
                // Compiler-owned wrappers cannot occur above this conservative bound.
                // Still clear every retired guest reference after private cleanup.
                for (var i = Math.Min(_owner.LiveExtent - 1, _owner._lastOwnedTemporarySlot); i >= newCount; i--)
                {
                    if (_owner.DeferAsyncDisposal && _values[i] is PyIteration.Cursor cursor)
                    {
                        if (_owner._pendingDisposalTail is null) _owner._pendingDisposalHead = cursor;
                        else _owner._pendingDisposalTail.NextPendingDisposal = cursor;
                        _owner._pendingDisposalTail = cursor;
                        // Ownership moved to the pending chain. A later synchronous
                        // disposal can fail; retrying the trim must not enqueue twice.
                        _values[i] = null!;
                    }
                    else if (_values[i] is ExecutableTemporaryValue temporary) temporary.Dispose();
                }
                _values.Slice(newCount, _owner.LiveExtent - newCount).Clear();
                _owner.LiveExtent = newCount;
            }
        }
    }

    internal ref struct ExecutableWork(ref ExecutableWorkState state, Span<object> values)
    {
        private ref ExecutableWorkState _state = ref state;
        internal ExecutableValueStorage.BorrowedValues Stack = new(ref state.Stack, values);
        internal ref ExecutableWorkState State => ref _state;
        internal ExecutableCodeObject Code => _state.Code;
        internal Span<object> Locals => Stack.Values;
        internal ExecutableCell?[]? LocalCells => _state.LocalCells;
        internal IReadOnlyList<ExecutableCell>? ClosureCells => _state.ClosureCells;
        internal ref int InstructionIndex => ref _state.InstructionIndex;
        internal bool ReturnConsumedByIteration => _state.ReturnConsumedByIteration;
        internal ref object? ReturnValue => ref _state.ReturnValue;
    }
}
