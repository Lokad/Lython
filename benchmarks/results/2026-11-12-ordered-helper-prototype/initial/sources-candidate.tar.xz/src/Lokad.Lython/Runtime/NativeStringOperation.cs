namespace Lokad.Lython.Runtime;

internal enum NativeStringOperation { Split, Replace, StartsWith, EndsWith }
