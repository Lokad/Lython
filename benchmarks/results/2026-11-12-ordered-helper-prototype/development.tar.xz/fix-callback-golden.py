from pathlib import Path
import json,hashlib,os,shutil,subprocess
r=Path(__file__).resolve().parent;out=r/'callback-control';p=out/'catalog.json';shutil.copyfile(p,out/'catalog.original-stdout.json')
catalog=json.loads(p.read_text(encoding='utf-8'));c=catalog['cases'][0];assert c['expectedOutput']=='3072\r\n';c['expectedOutput']=c['expectedOutput'].replace('\r\n','\n');c['expectedOutputUtf8Bytes']=len(c['expectedOutput'].encode('utf-8'));c['expectedOutputSha256']=hashlib.sha256(c['expectedOutput'].encode('utf-8')).hexdigest();p.write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
(out/'golden-correction.json').write_text(json.dumps(dict(originalRawReference='python-golden.json',originalCatalog='catalog.original-stdout.json',correction='Windows pipe print emittedCRLF. Normalize stdoutonly toLF, consistent with Lython captured output and existing Linux protocol. Filegoldens untouched (source uses newline empty). Original golden check failed before timing; no adverse timing erased.'),indent=2)+'\n',encoding='utf-8')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH'];dotnet=env['DOTNET_ROOT']+'/dotnet.exe';before=r.parent/'conditional-helper-r266/normalized/candidate'
for phase in ['warm-sync','warm-async']:
 d=out/phase;d.mkdir(exist_ok=True);shutil.copyfile(r/'warm-sync/hash-witness.json',d/'hash-witness.json')
 for n in ['measurements.json','stderr.log']:
  if(d/n).exists():shutil.copyfile(d/n,d/(n+'.original-output-mismatch'))
 cmd=[dotnet,str(out/'tool/bin/Release/net11.0/complete-jobs.dll'),str(before/'Lokad.Lython.Benchmarks.dll'),str(r/'candidate/Lokad.Lython.Benchmarks.dll'),str(out/'catalog.json'),str(d/'hash-witness.json'),'forward','warm','async'if phase=='warm-async'else'sync']
 with(d/'measurements.json').open('wb')as f,(d/'stderr.log').open('wb')as err:done=subprocess.run(cmd,env=env,stdout=f,stderr=err)
 assert done.returncode==0,(phase,(d/'stderr.log').read_text(encoding='utf-8'))
 print(phase,'complete callback report goldens/balances/cleanup pass',flush=True)
shutil.copyfile(r/'summarize.py',out/'summarize.py');subprocess.run(['python','-X','utf8',str(out/'summarize.py')],check=True)
