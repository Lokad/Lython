from pathlib import Path
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('| Active isolated prototype |');b=s.index('\n',a)
s=s[:a]+'''| Active isolated prototype | R268 refined, uncommitted: one ordered prefix with concrete managed span borrow, live export and shared owned callback preparation. Compiler native body tree/proof/evaluator/input-shape machinery removed. 1,366 focused actual-target checks and six whole scripts both APIs/compile pass. Initial callback allocation+40% corrected; original evidence preserved. Warm allocation flat, compile allocation −0.14..−1.34%; desktop timing mixed/adverse. Quiet B617 seven affected/control jobs running under 300s owner. No retention or CPU claim. |'''+s[b:]
s=s.replace('4. Next design milestone: shared ordered helper execution with transient operands,\n   below. First prove its export/lifetime invariant against current code; do not\n   add another wrapper around the same array-backed work. A prototype remains\n   unqualified until it removes the displaced route and preserves native gains.','''4. R268 is implemented as an isolated coherent prototype: one existing prefix,
   transient slots and live export; callbacks/wide calls share owned preparation.
   The displaced native body/proof/evaluator route is deleted. Close B617 (seven
   jobs, five-second warmups except captured text twelve seconds, 250ms batches;
   300s owner/265s last start/360s observation). Preserve refined desktop native
   Run +25..33%, captured Async −1.28..+2.55%, callback Async −5.74..+4.16%, and
   original +40% callback allocation/first stdout-golden failure and correction.
   Decide retain/refine/withdraw against real native/callback and whole-script
   costs. If retained, complete current architecture docs and exact-source full
   delivery; if refining, identify actual work before further changes. No fixed
   percentage veto, stale qualification replay or publication.''')
s=s.replace('### Next selected design: one ordered helper body','### Active design: one ordered helper body',1)
p.write_text(s,encoding='utf-8')
print('Ignored plan now records implemented deletion, corrected callback debt and bounded live comparison, without a qualification claim.')
