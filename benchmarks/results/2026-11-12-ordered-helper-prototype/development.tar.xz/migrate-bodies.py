from pathlib import Path
import re
r=Path('src/Lokad.Lython/Runtime');front=Path('src/Lokad.Lython/Frontend')
# The existing storage owner carries optional cache/cursor state. Only its slots
# are borrowed transiently; no span escapes when the owner is exported.
p=r/'LythonRuntime.Executable.cs';s=p.read_text(encoding='utf-8');i=s.index('        internal object[] Values => _items;');s=s[:i]+'''        internal static ExecutableValueStorage CreateTransient(ExecutableCodeObject code,
            ExecutionContext context, PyExecutableFunction function)
            => new()
            {
                _items = [], _state = context.State,
                _firstTemporarySlot = code.FirstTemporarySlot,
                _lastOwnedTemporarySlot = code.LastOwnedTemporarySlot,
                _lookupStorage = function, LiveExtent = code.FirstTemporarySlot
            };

        internal void AdoptExportedValues(object[] values) => _items = values;

'''+s[i:];p.write_text(s,encoding='utf-8')
p=r/'PyExecutableFunction.cs';s=p.read_text(encoding='utf-8');a=s.index('    internal override bool TryExecuteWithoutFrame');b=s.index('    protected override object ExecuteBody(',a);s=s[:a]+'''    internal FunctionBindingPlan InvocationBinding => BindingPlan;

    // Default protocols and lexical/protected frames enter the existing owned
    // route before work. Completed bounded bodies share the ordinary prefix.
    internal bool CanUseTransientOperands => CanDeferInvocationContext
        && _codeObject.ValueStorageCapacity <= LythonRuntime.TransientValueCapacity
        && BindingPlan.ParameterCount <= LythonRuntime.TransientValueCapacity
        && BindingPlan.VariadicListIndex < 0 && BindingPlan.VariadicDictionaryIndex < 0
        && BindingPlan.PositionalDefaults is null or PyTuple
        && (BindingPlan.KeywordDefaultStorage is null || BindingPlan.KeywordDefaultStorage.SupportsNativeStringReads);

'''+s[b:]
s=s.replace('        if (LythonRuntime.TryExecuteNativeReturn(_codeObject, frame, boundArguments.Values.AsSpan(0, boundArguments.Assigned.Length), span, out var result))\n            return result;\n','')
s=s.replace('        // Only statically proven bodies without callbacks use this shared shortcut.\n','');p.write_text(s,encoding='utf-8')
p=r/'PyFunctionBase.cs';s=p.read_text(encoding='utf-8');s=s.replace('''            if (TryExecuteWithoutFrame(boundArguments.Values.AsSpan(0, boundArguments.Assigned.Length), span, out var result))
            {
                return result;
            }
''','');a=s.index('    internal virtual bool TryExecuteWithoutFrame');b=s.index('    internal LythonRuntime.ExecutionContext EnterInvocationFrame(',a);s=s[:a]+s[b:];p.write_text(s,encoding='utf-8')
p=r/'LythonRuntime.Executable.Calls.Invoke.cs';s=p.read_text(encoding='utf-8');a=s.index('            // Closed helpers complete here');b=s.index('            // These existing native receiver operations',a);s=s[:a]+s[b:];p.write_text(s,encoding='utf-8')
p=r/'LythonRuntime.Executable.Calls.cs';s=p.read_text(encoding='utf-8');i=s.index('                var positional = !ordinaryCall');s=s[:i]+'''                if (function.CanUseTransientOperands)
                {
                    prepared = true;
                    return new(BeginTransientCall(function, operands, receiver, site, start, span, completion, callEntered));
                }
'''+s[i:]
s=s.replace('                var nativeAttempted = ordinaryCall && positional && function.CanBorrowPositionalArguments(argumentCount, receiver);\n','')
s=s.replace(', callEntered, nativeAttempted)',', callEntered)').replace(', callEntered, nativeAttempted: false)',', callEntered)').replace('bool callEntered, bool nativeAttempted)','bool callEntered)')
a=s.index('                var arguments = bound.Values.AsSpan');b=s.index('                if (function.CanDeferInvocationContext)',a);s=s[:a]+s[b:]
a=s.index('                    if (TryExecuteNativeReturn(');b=s.index('                    InitializeExecutableFrame(',a);s=s[:a]+s[b:]
a=s.index('                frame.EnterExecutableSlots();');b=s.index('                transferred = true;',a);s=s[:a]+'''                PublishChildCallFrame(frame, site, start, span, completion, bound.StorageOwner);
'''+s[b:];p.write_text(s,encoding='utf-8')
# Keep the shared exact operation facts used by ordinary builtin/receiver calls.
p=r/'LythonRuntime.Executable.NativeReturn.cs';s=p.read_text(encoding='utf-8');a=s.index('    internal enum NativeReturnShape');b=s.index('    // One pure fact serves frontend eligibility',a);facts=s[a:b]
p=r/'LythonRuntime.Executable.NativeCalls.cs';s=p.read_text(encoding='utf-8');head='internal sealed partial class LythonRuntime\n{\n';i=s.index(head)+len(head);s=s[:i]+facts+'\n'+s[i:];s=s.replace('NativeReturnOperation','NativeStringOperation');p.write_text(s,encoding='utf-8')
for p in r.glob('*.cs'):
 s=p.read_text(encoding='utf-8');updated=s.replace('NativeReturnOperation','NativeStringOperation')
 if updated!=s:p.write_text(updated,encoding='utf-8')
p=front/'ExecutableScript.cs';s=p.read_text(encoding='utf-8');s=re.sub(r'^.*NativeBody = PrepareNativeBody.*\n','',s,flags=re.M);s=re.sub(r'^.*public ExecutableNativeBody\? NativeBody.*\n','',s,flags=re.M)
# Input provenance belonged only to the discarded native expression tree.
s=s.replace('        NativeInput = int.MaxValue;\n','')
s=re.sub(r'^.*public int NativeInput.*\n','',s,flags=re.M)
s=re.sub(r'^.*public int NativeArgumentSource.*\n.*\? Arguments\[index\].NativeInput.*\n','',s,flags=re.M)
p.write_text(s,encoding='utf-8')
for p in [front/'ExecutableScript.NativeReturns.cs',front/'ExecutableNativeBody.cs',r/'LythonRuntime.Executable.NativeReturn.cs']:p.unlink()
(r/'NativeStringOperation.cs').write_text('''namespace Lokad.Lython.Runtime;

internal enum NativeStringOperation { Split, Replace, StartsWith, EndsWith }
''',encoding='utf-8')
print('Transient body route connected; compiler native tree and recursive proof/evaluator removed, shared ordinary operation facts retained.')
