from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;out=Path('benchmarks/results/2026-11-12-ordered-helper-prototype');out.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for label,base in [('initial',r),('refined',r/'refined')]:
 d=out/label;d.mkdir()
 for n in ['diagnostic-identity.json','sources-candidate.tar.xz','focused-checks.json','freeze-and-measure.py','focused.py']:
  if(base/n).exists():shutil.copyfile(base/n,d/n)
 for phase in ['warm-sync','warm-async','compile']:shutil.copytree(base/phase,d/phase)
 shutil.copytree(base/'tests',d/'tests')
 for p in base.glob('*.log'):shutil.copyfile(p,d/p.name)
with tarfile.open(out/'development.tar.xz','w:xz')as t:
 for base in [r,r/'refined',r/'tool',r/'refined/tool']:
  for p in base.iterdir():
   if p.is_file()and(p.suffix in ['.py','.md','.json','.patch','.dll']or p.name.endswith('.log')):t.add(p,arcname=p.relative_to(r).as_posix())
 t.add(r/'callback-control',arcname='callback-control',filter=lambda m:None if '/bin/'in m.name or'/obj/'in m.name else m)
 for p in Path('tests').rglob('*.cs'):
  if p.name in ['NativeClosureSequenceTests.cs','NativeFunctionRefundTests.cs','SimpleFunctionExecutionBoundaryTests.cs','HelperContinuationLifetimeTests.cs']:t.add(p,arcname=p.as_posix())
(out/'implementation.patch').write_bytes(subprocess.check_output(['git','diff','--','src','tests']))
q=r/'refined/b617';d=out/'refined/b617';d.mkdir();receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));identity=json.loads((q/'identity.json').read_text(encoding='utf-8'))
assert receipt['complete']and receipt['jobs']==7 and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']and receipt['quietBeforeAndAfter']and receipt['archivedAndVerifiedUnderLease'];assert sha(q/'observations.tgz')==receipt['archiveSHA256']
with tarfile.open(q/'observations.tgz')as t:assert hashlib.sha256(t.extractfile('current-core.dll').read()).hexdigest()==identity['coreSHA256']['candidate']
for n in ['observations.tgz','archive-receipt.json','identity.json','source-identity.json','summary.json','terminal-status.json','inventory.json','launch.log','observe-not-before.json']:shutil.copyfile(q/n,d/n)
with tarfile.open(d/'preparation.tar.xz','w:xz')as t:
 for p in q.iterdir():
  if p.is_file()and p.name not in ['observations.tgz','payload.tgz','current-core.dll']:t.add(p,arcname=p.name)
(out/'README.md').write_text('''# Ordered helper prototype — not promoted

2026-11-12. Uncommitted R268 versus fully qualified da9e5066/a552. Production is
an active prototype, not a delivered improvement. The proposed coherent migration
replaces the compiler native body tree/recursive proof/evaluation and shape/input
transport with the existing instruction prefix, a concrete managed span borrow,
live-state export and shared owned callback preparation. No second interpreter,
generic accessor framework, window arena, unsafe code or resource policy.

First complete form passes1,366 focused actual .NET11/10 checks and five complete
scripts both APIs/separatecompile, goldens/files/allowance/cleanup. Warm allocation
is flat; compile allocation falls0.14–1.34%. Private desktop driver accidentally
retained its R266 purpose prose; recorded image hashes/case IDs identify R268,
and the explicit metadata correction preserves original raw files. No timing
replay follows from this label correction.

A complete sorted-report callback control with independent CPython3.13.2 file
golden exposes+40.03% allocation from eager callback frames. Original Windows
stdoutCRLF golden mismatch failed before timing; stdout-only normalization toLF
matches the existing Linux/captured protocol, with original golden/catalog/error
preserved. Original callback sync elapsed−56..−41% has35.8% control drift and
supports no CPU claim; async+5.29..5.49% has0.19% drift.

The refined form shares owned prefix preparation across callbacks and ordinary
calls, clearing full compiler workspace extents once. 1,366focused checks again
pass (226internal/457public per actual target), including partial f-string values
through real protocol I/O, cancellation, retained results and cleanup baseline.
Six whole scripts both APIs/compile pass. Callback allocation returns to flat;
all warm allocations are essentially flat, compilation falls0.14–1.34%.

B617 completes seven jobs249.221s, all identity/output/ownership/quiet/join/RAM/
archive gates. Same fec79worker/adapter0.4 on quietF4as_v7/Ubuntu24.04.4/.NET11RC3,
normalGC/tiering. 5s warmups except captured12s,7rotating250msrounds,fourprocess
roles. **Material regressions remain:**

| Complete script / API | Elapsed change | Wider process CPU change |
| --- | --- | --- |
| Native search / Run | +14.48..+23.44% | +13.96..+22.86% |
| Guarded search / Run | +8.80..+30.70% | +9.95..+25.27% |
| Guarded search / RunAsync | +21.09..+30.52% | +14.04..+20.37% |
| Captured text / RunAsync | +17.71..+29.34% | +14.03..+28.57% |
| CSV / Run | +0.85..+1.40% | 0..+1.79% |
| Report / Run | −2.93..+0.40% | −4.86..+1.23% |
| Sorted callback report / RunAsync | −1.60..+1.40% | −1.56..+3.85% |

Ranges span all four process-median pairings, not confidence intervals. Guarded
Run reference/candidate spread9.65/7.87%, captured candidate8.04%; these add
uncertainty but do not erase consistent native-path regressions. Refined desktop
nativeRun+25..33%, guardedAsync−1.10..+18.82%, capturedAsync−1.28..+2.55%, callback
Async−5.74..+4.16%, and all compilation adversity remain unchanged.

Warm clocks include invocation, mediated RAM I/O, validation/prior-result cleanup;
exclude startup/compile/reset/protocol/finalcache. WiderCPU includes reset/protocol.
Desktop includes immediate disposal. No CPython ratio/RSS/tail/largefile claim.

Do not promote this form. One paired six-second profile of the affected native
script will distinguish actual preparation/dispatch cost from useful work and
decide a bounded correction or withdrawal. No permanent architecture ban or
fixed-percentage veto; the performance objective remains active. Full new-source
platform/stress/package qualification has not run. Publication stays postponed.

Terminal VM state is cached and raw SHA independently verified. Exact committed
B616 archive/catalog/records and all aliases of superseded qualified b2 physical
image were retired under fresh lease/UID/path/inode/link and canonical Git/SHA
proof. Current a552 reference stays protected; floors unchanged. No live users or
sole RAM evidence remain.
''',encoding='utf-8')
files={p.relative_to(out).as_posix():sha(p)for p in out.rglob('*')if p.is_file()};(out/'files-sha256.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8')
with Path('.gitattributes').open('a',encoding='utf-8')as f:f.write('\nbenchmarks/results/2026-11-12-ordered-helper-prototype/** -text whitespace=cr-at-eol\nbenchmarks/results/2026-11-12-ordered-helper-prototype/**/*.patch -text -whitespace\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');i=s.index('[R266 delivery]');s=s[:i]+'''[Ordered helper prototype](results/2026-11-12-ordered-helper-prototype/README.md)
removes the native tree/proof/evaluator with one existing prefix, managed span
borrow and live export. 1,366focusedactual-target checks/sixwhole scripts pass.
Shared callback preparation corrects first-form+40% allocation. B617sevenjobs
249.221s retains material native/search/captured CPU regressions about14–29%,
while CSV/report/callback controls are much less affected. All adverse observations
and first stdout-golden correction survive. Not promoted; one paired native-path
profile precedes a bounded correction/withdrawal decision. No full delivery claim.

'''+s[i:];p.write_text(s,encoding='utf-8')
print('Unpromoted initial/refined sources, tests, all adversity and verified B617 archived; production remains uncommitted.')
