from pathlib import Path
import re
root=Path('tests/Lokad.Lython.Tests')
for name in ['NativeFunctionRefundTests.cs','NativeClosureSequenceTests.cs','SimpleFunctionExecutionBoundaryTests.cs']:
 p=root/name;s=p.read_text(encoding='utf-8')
 s=re.sub(r'^\s*Assert\.NotNull\([^\n]*NativeBody\);\n','\n',s,flags=re.M)
 s=re.sub(r'^\s*Assert\.Contains\([^\n]*NativeBody\.Values[^\n]*\n','\n',s,flags=re.M)
 s=s.replace('                Assert.False(function.TryExecuteWithoutFrame([], span, out _));\n','')
 p.write_text(s,encoding='utf-8')
p=root/'SimpleFunctionExecutionBoundaryTests.cs';s=p.read_text(encoding='utf-8');a=s.index('                var function = Assert.IsType<PyExecutableFunction>(context.Variables["f"]);',s.index('public void KeywordDefaultPrefix'));b=s.index('                Assert.Equal("NEEDLE: kept", line.AsString());',a)
s=s[:a]+'''                context.Variables["value"] = line;
                long baseline = -1;
                context.Variables["arm"] = new BudgetAction(() =>
                {
                    baseline = budget.ReservedBytes;
                    hook.RefuseGrowth = _ => true;
                });
                context.Variables["check"] = new BudgetAction(() =>
                {
                    Assert.Null(context.MemoryGovernor.AdmissionFailure);
                    Assert.Equal(baseline, budget.ReservedBytes);
                });
                var invocation = ExecutableScript.Compile(LoweredScript.Lower(
                    LythonFrontend.Compile("arm()\\nresult=f(value)\\ncheck()\\nreturn result").Script.RequireNotNull()));
                try
                {
                    Assert.True(Assert.IsType<bool>(LythonRuntime.ExecuteExecutableCodeObject(
                        invocation.EntryPoint, context, default, null)));
                    Assert.Equal(0, context.State.CurrentInterpreterDepth);
                    Assert.Equal(0, context.State.CurrentRecursionDepth);
                }
                finally { context.State.CloseResources(); }
'''+s[b:]
i=s.index('    private static (PyExecutableFunction Function,')
s=s[:i]+'''    private sealed class BudgetAction(Action action) : LythonRuntime.ICallable
    {
        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        {
            action();
            return PyNone.Instance;
        }
    }

'''+s[i:];p.write_text(s,encoding='utf-8')
print('Discarded native-tree assertions/direct internal calls removed; semantic/refusal/alias/cleanup assertions retained, funded-default check now uses actual executable entry.')
