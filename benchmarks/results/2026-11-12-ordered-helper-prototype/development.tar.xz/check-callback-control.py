from pathlib import Path
import base64,copy,hashlib,json,os,shutil,struct,subprocess,tarfile,tempfile
r=Path(__file__).resolve().parent;out=r/'callback-control';out.mkdir();catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'));c=copy.deepcopy(next(c for c in catalog['cases']if c['id']=='scripts.report-render.large'))
c['id']='scripts.report-render.sorted-callback.large';assert "for record in records:"in c['source'];c['source']=c['source'].replace('for record in records:',"for record in sorted(records,key=lambda record:record['amount']):")
fixture=json.loads(c['fixtureJson'])
with tempfile.TemporaryDirectory(prefix='lython-r268-callback-golden-')as tmp:
 path=Path(tmp)
 for name,b in fixture['inputFiles'].items():(path/name).write_bytes(base64.b64decode(b))
 done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',c['source']],cwd=tmp,capture_output=True)
 assert done.returncode==0,done.stderr
 c['expectedOutput']=done.stdout.decode('utf-8');fixture['outputFiles']={n:base64.b64encode((path/n).read_bytes()).decode('ascii')for n in fixture['outputFiles']}
(out/'python-golden.json').write_text(json.dumps(dict(version=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip(),source=c['source'],stdout=c['expectedOutput'],stderr=done.stderr.decode('utf-8'),trustedTemporaryFiles=True),indent=2)+'\n',encoding='utf-8')
c['fixtureJson']=json.dumps(fixture,separators=(',',':'));c['sourceUtf8Bytes']=len(c['source'].encode());c['expectedOutputUtf8Bytes']=len(c['expectedOutput'].encode());digest=lambda v:hashlib.sha256(v.encode('utf-8')).hexdigest()
for field,key in [('sourceSha256','source'),('fixtureSha256','fixtureJson'),('expectedOutputSha256','expectedOutput')]:c[field]=digest(c[key])
h=hashlib.sha256();h.update(struct.pack('>i',len(fixture['outputFiles'])))
for n,b in sorted(fixture['outputFiles'].items()):
 p=n.encode('utf-8');v=base64.b64decode(b);h.update(struct.pack('>i',len(p)));h.update(p);h.update(struct.pack('>i',len(v)));h.update(v)
c['expectedFilesSha256']=h.hexdigest();catalog['cases']=[c];(out/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
tool=out/'tool';tool.mkdir();shutil.copyfile(r/'tool/complete-jobs.csproj',tool/'complete-jobs.csproj')
s=(r/'tool/Program.cs').read_text(encoding='utf-8').replace('cases.Length != 5','cases.Length != 1').replace('R266 compiler-only negated branch normalization; five complete scripts','R268 callback control: complete sorted JSON-to-report, independent CPython3.13.2 output')
(tool/'Program.cs').write_text(s,encoding='utf-8')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH'];dotnet=env['DOTNET_ROOT']+'/dotnet.exe'
with(out/'build.log').open('wb')as f:done=subprocess.run([dotnet,'build',str(tool/'complete-jobs.csproj'),'-c','Release','--nologo','--tl:off'],env=env,stdout=f,stderr=subprocess.STDOUT)
assert done.returncode==0
before=r.parent/'conditional-helper-r266/normalized/candidate'
for phase in ['warm-sync','warm-async']:
 d=out/phase;d.mkdir();shutil.copyfile(r/'warm-sync/hash-witness.json',d/'hash-witness.json')
 cmd=[dotnet,str(tool/'bin/Release/net11.0/complete-jobs.dll'),str(before/'Lokad.Lython.Benchmarks.dll'),str(r/'candidate/Lokad.Lython.Benchmarks.dll'),str(out/'catalog.json'),str(d/'hash-witness.json'),'forward','warm','async'if phase=='warm-async'else'sync']
 with(d/'measurements.json').open('wb')as f,(d/'stderr.log').open('wb')as err:done=subprocess.run(cmd,env=env,stdout=f,stderr=err)
 assert done.returncode==0,(phase,(d/'stderr.log').read_text(encoding='utf-8'))
 print(phase,'whole callback report goldens/balances/cleanup pass',flush=True)
shutil.copyfile(r/'summarize.py',out/'summarize.py');subprocess.run(['python','-X','utf8',str(out/'summarize.py')],check=True)
