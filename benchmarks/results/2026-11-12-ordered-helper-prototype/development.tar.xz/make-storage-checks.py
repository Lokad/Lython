from pathlib import Path
r=Path(__file__).parent
s=(r.parent/'conditional-helper-r266/normalized/focused.py').read_text(encoding='utf-8')
s=s.replace("for framework in ['net11.0','net10.0']:","for framework in ['net11.0']:")
s=s.replace("'NativeUnaryReentryTests']","'NativeUnaryReentryTests','ExecutableCallFrameTests','NativeFunctionRefundTests','NativeClosureSequenceTests','StorageOwnershipBalanceTests','NestedFrameLifetimeTests','LocalAugmentedLifetimeTests','ExecutableAugmentedSubscriptTests','StringFormattingLifetimeTests','StarredDisplayExecutableTests']")
s=s.replace("r/'focused-checks.json'","r/'storage-focused-checks.json'").replace("r/'tests'","r/'storage-tests'").replace("label+'-'+framework","'storage-'+label+'-'+framework")
(r/'storage-focused.py').write_text(s,encoding='utf-8')
