from pathlib import Path
import json
r=Path(__file__).parent;out=r/'refined'
s=(r/'freeze-and-measure.py').read_text(encoding='utf-8')
s=s.replace("previous=r.parent/'conditional-helper-r266/normalized'","previous=r.parent.parent/'conditional-helper-r266/normalized'")
s=s.replace("(r/'baseline.json')","(r.parent/'baseline.json')").replace('len(added)==3','len(added)==4')
s=s.replace("shutil.copyfile(previous/'tool/Program.cs',tool/'Program.cs')","program=(previous/'tool/Program.cs').read_text(encoding='utf-8').replace('cases.Length != 5','cases.Length != 6').replace('R266 compiler-only negated branch normalization; five complete scripts','R268 shared ordered prefix and callback preparation; six complete scripts');(tool/'Program.cs').write_text(program,encoding='utf-8')")
s=s.replace("shutil.copyfile(previous/'catalog.json',r/'catalog.json');", "catalog=json.loads((previous/'catalog.json').read_text(encoding='utf-8'));catalog['cases']+=json.loads((r.parent/'callback-control/catalog.json').read_text(encoding='utf-8'))['cases'];(r/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\\n',encoding='utf-8');")
s=s.replace("len(j['observations'])==5","len(j['observations'])==6").replace("'five whole scripts outputs/allowance/cleanup pass'","'six whole scripts outputs/allowance/cleanup pass'")
s=s.replace('One existing instruction prefix over concrete managed span borrow;','Refined one existing instruction prefix, shared owned invocation preparation for callbacks/opcodes, plus concrete managed span borrow;')
s=s.replace('Small managed inline slots retain existing managed stack protection;','Firstformcallback allocation+40% and original desktop adversity preserved; callbacks now borrow existing bound workspace until actual context requirement. Small managed inline slots retain existing managed stack protection;')
(out/'freeze-and-measure.py').write_text(s,encoding='utf-8')
(r/'desktop-purpose-correction.json').write_text(json.dumps(dict(originalPurposeRetained=True,scope='Initial5script desktop measurements only',correction='Private driver retainedR266purpose prose. Actual perimage DLL hashes/source inventory/case IDs identifyR268firstform. No data/timing changed or replayed. Callback and refined drivers use currentR268purpose.',evidence='warm-sync/measurements.json,warm-async/measurements.json,compile/measurements.json'),indent=2)+'\n',encoding='utf-8')
print('Refined six complete-script comparison includes independently checked callback control; original source and adversity remain unchanged.')
