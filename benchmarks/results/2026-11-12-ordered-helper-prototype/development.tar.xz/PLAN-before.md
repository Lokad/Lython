# Lokad.Lython 0.11.0

Updated 2026-11-12; delivery/evidence pushed through 2f2154a5. Git-ignored; never force-add. Publication and tagging postponed.
Objective: simplify the design and substantially improve complete scripts,
including compile-to-result latency. An isolated experiment is not completion.

## Delivery status

| State | Outcome |
| --- | --- |
| Fully qualified | Native storage/borrowed inputs, shared receiver/truth services, completed calls, captured-cell assignment, lexical/generator fixes and final-byte text output. Latest baseline production `983bab96`, fixture-only `796c3218`: Windows/Ubuntu, actual .NET 11/10, original stress and installed Release consumers green. Run 43166350709 is terminal/cached. [Delivery](benchmarks/results/2026-11-12-text-output-batches/delivery/README.md). Do not repeat unchanged qualification. |
| Current fully qualified runtime | `da9e5066`: compiler-only negated helper predicates. Exact run 43183343974 is terminal green/cached: Windows/Ubuntu, actual .NET 11/10, original stress and installed Release consumers. All 568 frozen sources match. [Delivery](benchmarks/results/2026-11-12-conditional-helper-bodies/delivery/README.md). Accepted native-search debt and captured source-pair uncertainty remain explicit. |
| Closed investigations; no active runtime prototype | R267: two short CSV/report profiles and operand/lifetime source proof. Shared backing and deferred frames already exist; array-backed resumable work cannot simply borrow an arbitrary stack span. Early record snapshots reorder observable admission/mutation. No duplicate frame, new arena or proof vector is selected. [Proof](benchmarks/results/2026-11-12-record-cpython-checkpoint/operand-proof.md). |
| Not promoted | R265 binding-loop sharing retained ordinary setup and added uncertain/adverse cost. R266 raw unary enum/shape/guard/evaluator additions were displaced by the compiler-only form. Original sources and adverse evidence survive in [history](benchmarks/EXPERIMENTS.md). |
| External baseline | Current `da9e5066` versus CPython 3.13.16: warm CSV 1.03–1.04×, JSON-lines 0.85–0.91×, guarded search 1.81–1.99×, captured text 1.65–1.67×. Prior qualified report rows retain 1.26–1.33× UTF-8 / 1.44–1.51× UTF-16; ordinary text remains variable. Compile/result are separate. [Guide](docs/BENCHMARKS.md). |
| Independent regex | Immutable dev73/eae880c8 compatibility passes 86 internal/532 public checks per actual target. Normal optional, nonpackable adapter remains 0.4. Only precise producer gaps below defer final released-adapter qualification. |

Completed measurement corrections: shared compiler facts fix repeated/exponential
analysis and nonlocal diagnostics; no CPU claim from that correctness change.
Direct UTF-8 formatting/storage reduces allocation 8.67%; controlled elapsed/CPU
supports 5–8% improvement, while original adverse 15.125 ms remains unexplained
and preserved. Native helper returns reduce allocation 19.92% Run / 19.31%
RunAsync; original elapsed gains remain diagnostic. Their qualification and
throwing-cleanup refund correction are complete.

Direct calls, reused workers, shared workspace, lexical cells, captured helpers,
CSV adoption/shared keys, bulk UTF-8/JSON, private totals and integer container
storage already ship. Former bulk CSV work with 6–8% gains was reassessed and
revised into current construction; do not replay the old patch. Slower arena,
controller and shared-prefix forms remain useful evidence, not permanent bans.

## Immediate delivery and next redesign

1. Exact `da9e5066` qualification is complete and cached. No unchanged replay.
   B616 refreshed older CSV/JSON/guarded-search rows and captured warm control,
   ten jobs in 301.542 seconds with every identity/output/ownership/quiet/join/
   archival gate. Captured absolute timing is stable; original source-pair
   causality remains unresolved. Other source/date labels remain historical.
2. Retain R266's compiler-only form. Branch parity swaps existing conditional
   roots; no new runtime unary machinery survives. Guarded search omits ordinary
   binding/workspace/body dispatch. B614: Run elapsed −28.45..−22.30%, supporting
   CPU −23.51..−18.27%; RunAsync elapsed −25.05..−14.58%, CPU −20.54..−9.90%.
   Warm allocation is flat; compile allocation +1.02% is accepted. Native-search
   CPU +0.46..+1.54% is accepted control debt. Captured-text CPU −3.19..+9.05%,
   with 9.11% candidate-control drift, remains unresolved. Track this at a useful
   combined checkpoint; no repeated unchanged-image campaign. [Evidence](benchmarks/results/2026-11-12-conditional-helper-bodies/normalized/README.md).
3. R267 closes after two captures (11.771 seconds execution). CSV selected
   instruction/input/result/comparison work is 267/1,189 leaves; binding/entry/work
   90. Report is 196/1,068 and 17, with formatting/write and JSON also material.
   Unknowns remain 5.89%/6.37%; no removable-tax forecast. Existing bulk CSV,
   inline strings and final UTF-8 storage are excluded as new projects.
   [Evidence and ordering obstacle](benchmarks/results/2026-11-12-record-call-attribution/README.md).
   Stop unchanged captures. Prove an operand/lifetime stage can disappear before
   prototyping: inline spans would require real changes to the current array-
   backed resumable work, not a new carrier; pre-reading later record fields would
   reorder observable admission/mutation. Keep existing native gains and ordinary
   continuation at the exact effect frontier.
4. Next design milestone: shared ordered helper execution with transient operands,
   below. First prove its export/lifetime invariant against current code; do not
   add another wrapper around the same array-backed work. A prototype remains
   unqualified until it removes the displaced route and preserves native gains.

## Substantial redesign roadmap

| Priority | Evidence and affected scripts | Completion criteria |
| --- | --- | --- |
| Complete call/body and operand construction | CSV validation, report formatting, captured text. R264 shows real binding/entry/dispatch, including useful inlined work; no duplicate frame or argument array exists. R265 merely sharing loops was insufficient. | Remove a complete preparation or representation stage. Preserve mutable defaults, keywords/descriptors, native gains, closures, promotion, actual suspension/reentry and cleanup before publication. Remove displaced implementation; avoid accumulating receiver/arity special cases or replaying unchanged slower arenas. |
| Per-record construction and remaining conversions | Current CSV, text, JSON and reports. Exclude already eliminated word materialization, decoding, shared-key/totals, multipart and integer-format transports. | Eliminate a complete scanner/storage/conversion stage. Preserve Python Unicode/context, hooks, header mutation/order, aliases, admission peaks and refusal effects. Validate whole scripts and realistic retained sets, without a broad ownership audit. |
| Scoped scalar/operand representation | Separate boxing from dispatch/binding with actual dominant-cost evidence; integer container intermediates are already removed. | Preserve exact promotion, bool/int semantics, identity/aliases and funded projection. Universal tagged slots require an end-to-end migration and explicit regression-debt decision; boxing alone is insufficient justification. |
| Repeated frontend analysis | Shared compiler facts already exist. Identify an actual repeated traversal or retained tree; near-CPython compilation does not explain warm gaps. | Delete the displaced pass/representation; preserve diagnostics, scopes, annotations, generators, imports, cancellation and ownership. Compare compile-to-result; no speculative heavyweight JIT. |

### Next selected design: one ordered helper body

Hypothesis: one existing executable prefix, able to borrow transient managed
operand storage and export it only when a real context/continuation is required,
could replace both ordinary workspace preparation and the separate recursive
native proof/evaluation tree. This is a design hypothesis, not a measured gain.
Current profiles identify dispatch/transport as material; they do not forecast
how much is removable. No CLR-recursion/stack-policy change is included.

- Affected complete scripts: guarded/native file search, captured and ordinary
  text, CSV validation and report rendering. CSV/JSON are near or faster than
  CPython today; preserve them as controls rather than justify broad rewrites.
- Work to eliminate: owned binding/workspace for completed bounded helpers and
  duplicate `NativeReturnValue` body/`GuardNativeReturn`/`EvaluateNativeReturn`
  traversal. Keep the existing engine and shared operation kernels; do not build
  a second mini-VM, generic storage-access framework or caller-window arena.
- First stopping point: a concrete managed view/export design that fits the
  existing prefix, or an explicit obstacle before mutation. A stack span cannot
  survive suspension; a wrapper around object[] proves no deletion. Prototype
  only a materially different transport, preserving previous arena lessons.
- Semantic acceptance: ordered operand reads and exception spans; actual protocol
  and host suspension once; mutable defaults, keywords/descriptors, closures,
  generators and aliases; cleanup before publication; active cancellation,
  terminal first refusal and funded inputs/temporaries until joined cleanup.
  Never pre-read later record fields across admission or restart after effects.
- Completion: remove the displaced native tree and ordinary completed-call setup
  from migrated paths, with one continuation authority. Temporary setbacks are
  acceptable during the isolated migration, not silent delivery debt. Before
  retention, decide each affected/control regression against preserved native
  gains; refine, accept justified debt explicitly, or withdraw the whole form.
- Comparison: existing frozen workers and five complete scripts, separate compile
  and warm allocation diagnostics, then a bounded quiet affected/control pair.
  Confirm or correct moving controls when justified; no fixed-percentage veto.
  Full platform/stress/installed consumers only at coherent delivery.

Each selected redesign gets focused Release semantics, cancellation and ownership
checks, then a bounded affected/control comparison on the existing quiet VM.
Batch full Windows/Ubuntu, actual .NET 11/10, original stress and installed package
consumers at coherent delivery boundaries. Never relax assertions or timeouts.

## Measurements and stopping criteria

- Allocation, shared allowance, architectural simplification and CPU improvement
  are separate outcomes. Fixed percentages inform decisions; they do not veto a
  useful simplification automatically.
- Timeout, unstable unchanged controls and inconclusive results establish
  uncertainty. Allow bounded confirmation, refinement or measurement correction
  when evidence justifies it. Retain every adverse result and original failed
  condition. Size batches/warmups for usable observations; no routine ten-minute
  lanes, one-attempt bans or open-ended qualification campaigns.
- The report/text and record/search CPython refreshes are complete. Refresh rows at the
  next useful combined checkpoint, separating compilation, warm execution and
  compile-to-result. State included host I/O, validation and cleanup. Do not
  multiply source-pair gains into external ratios or silently relabel history.
- Pending-I/O/tail latency, RSS and large-file throughput remain unqualified.
  Detailed experiments and rejected approaches live in [history](benchmarks/EXPERIMENTS.md)
  and immutable results; private notes retain ignored plan snapshots.

## Independent regex track

Continue the Lython-owned Python/native UTF-8 contract: byte/scalar positions,
original-subject windows, effective flags, current tokens and explicit cache/result
owners. Core remains decoupled. Adapter-local bridges and immutable development
producers may support testing; contract semantics and actual backend performance,
memory and safety qualification remain distinct.

Only affected final released-adapter qualification awaits:

- Independent single-match working/result owners.
- Native UTF-8 group-name enumeration; lookup already exists.
- Token-independent cursor creation with cancellable preparation; per-move checks
  alone do not establish preparation interruption.

Relevant APIs are unchanged through dev68–73: do not repeat unchanged qualification
or poll producer releases. Remove adapter conversions/DetailedData when supported.
Missing publication never blocks independent development. Adapter is nonpackable.

## Lasting contracts

Fully managed and memory-safe; preserve managed stack admission, host capabilities,
cancellation, cycle/XML-depth protection, checked bounds and bounded I/O. No unsafe
code, fuel/quotas, independent caps, hidden allowances, tracing/weak reclamation,
forced GC, admission retry or abandoned users. Borrowed shared allowance funds
capacity, replacement overlap, results, aliases, caches and pending users through
awaited cleanup. First admission refusal remains terminal with its original
origin; explicit guest MemoryError stays catchable. Original path requests and
contained Cwd remain host-mediated; refused copy preserves its destination.
Host-driven commands bound streaming; output batching does not reclaim arbitrary
guest references.

Restored sources require nonincremental builds before no-build checks or freezes.
GC tests stay nonparallel. Cache terminal CI/VM observations and space active CI
checks minutes apart. Persistent evidence is verified after joined users before
RAM cleanup. Duplicate retirement needs fresh lease, UID/path/inode/all-alias and
committed canonical Git/SHA proofs with unchanged OS/evidence floors. Protect
current/reference images; never reuse retired paths. Publication remains held.
