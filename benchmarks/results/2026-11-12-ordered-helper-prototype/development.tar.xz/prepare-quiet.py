from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;current=r/'refined';q=current/'b617';q.mkdir();old=r.parent/'conditional-helper-r266/normalized/b614'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();meta=json.loads((current/'diagnostic-identity.json').read_text(encoding='utf-8'));assert all(sha(Path(n))==h for n,h in meta['sourceHashes'].items())
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'));identity['coreSHA256']={k:meta['beforeCoreSHA256']if k.startswith('reference')else meta['candidateCoreSHA256']for k in ['reference','reference-control','candidate','candidate-control']}
identity['sourceRevision']='UncommittedR268 refined ordered helper execution,569production sources. Remove compilerNativeBody tree/recursiveGuard/Eval/shapes; concrete managed span borrow and same existing prefix, live state export once before realprotocol/host suspension. Shared callback/ordinary owned preparation fixes initial+40% callbackallocation.1366focusedactual11/10,6whole scriptsbothAPIs/compile goldens/balances/cleanup pass. Warmallocationflat; compile-.14..-1.34%. DesktopnativeRun+25..33%,capturedAsync+2.55..-1.28%,callbackAsync+4.16..-5.74% withmovingcontrols; alladversity/initialgoldenstdoutmismatch preserved. Qualifiedda9/a552reference. No CPU/retention claim.'
shutil.copyfile(current/'catalog.json',q/'representative.json');shutil.copyfile(current/'candidate/Lokad.Lython.dll',q/'current-core.dll');identity['catalogSHA256']=sha(q/'representative.json');(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(q/'source-identity.json').write_text(json.dumps(dict(sourceSHA256=meta['sourceHashes'],changedProductionFiles=meta['changedProductionFiles'],removedProductionFiles=meta['removedProductionFiles'],addedProductionFiles=meta['addedProductionFiles'],focusedChecks=meta['focusedChecks'],uncommittedPrototype=True),indent=2)+'\n',encoding='utf-8')
jobs=[['scripts.file-search.large','warm'],['scripts.file-search.guarded-helper.large','warm'],['scripts.file-search.guarded-helper.large','warm-async'],['scripts.text-summary-helpers.nonlocal-counter.large','warm-async'],['scripts.csv-validated-records.large','warm'],['scripts.report-render.large','warm'],['scripts.report-render.sorted-callback.large','warm-async']]
root='ordered-helper-b617-20261112';unit='lython-b617-ordered-helper-20261112'
for n in ['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py','summarize.py','remote-launch.py']:
 s=(old/n).read_text(encoding='utf-8').replace('conditional-normalized-b614-20261112',root).replace('lython-b614-conditional-normalized-20261112',unit).replace('conditional-normalized-b614-launch.py','ordered-helper-b617-launch.py').replace('lython-b614-fixtures','lython-b617-fixtures').replace('B614','B617')
 if n=='collect.py':
  a=s.index('jobs=');b=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[b:];s=s.replace('len(jobs)==4','len(jobs)==7')
  a=s.index("purpose='");b=s.index("',\n                  warmupSeconds",a);s=s[:a]+"purpose='R268 sharedorderedhelperprefix andcallbackpreparation vsqualifiedda9/a552. Sevenaffected/control wholejobs. Preserve native/captured/callbackdesktopadversity; no CPUforecast or newexternalbaseline"+s[b:]
  s=s.replace('warmupSeconds=12, targetBatchSeconds=.35','warmupSeconds=5, capturedWarmupSeconds=12, targetBatchSeconds=.25').replace('end=time.monotonic()+12','end=time.monotonic()+(12 if case_id=="scripts.text-summary-helpers.nonlocal-counter.large" else 5)').replace('count*.35','count*.25')
 if n=='remote-launch.py':s=s.replace("source=base/'text-batches-b608-20261112/candidate'","source=base/'conditional-normalized-b614-20261112/candidate'").replace('jobs=4,ownerSeconds=300','jobs=7,ownerSeconds=300')
 if n=='archive-owned.py':s=s.replace("len(raw['jobs'])==4","len(raw['jobs'])==7").replace('complete=True,jobs=4','complete=True,jobs=7')
 if n=='retrieve.py':s=s.replace("['jobs']==4","['jobs']==7").replace('four-job','seven-job')
 if n=='summarize.py':s=s.replace("len(raw['jobs'])==4","len(raw['jobs'])==7").replace('complete=True,jobs=4','complete=True,jobs=7')
 (q/n).write_text(s,encoding='utf-8',newline='\n')
 if n.endswith('.py')and n!='remote-launch.py':ast.parse(s)
# Exact unique links need no whole-tree walk; shared images retain all-alias proof.
p=q/'remote-launch.py';s=p.read_text(encoding='utf-8');a=s.index('   aliases=[]');b=s.index('   assert len(aliases)',a);s=s[:a]+'''   aliases=[spec['knownPath']] if s.st_nlink==1 else []
   if s.st_nlink!=1:
    for folder,dirs,files in os.walk(base):
     for name in files:
      p=Path(folder)/name;q=p.lstat()
      if(q.st_dev,q.st_ino)!=(s.st_dev,s.st_ino):continue
      assert p.resolve(strict=True)==p and p.is_relative_to(base)and stat.S_ISREG(q.st_mode)and q.st_uid==os.getuid()
      aliases.append(p.relative_to(base).as_posix())
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['representative.json','source-identity.json','identity.json','collect.py','archive-owned.py','run.sh','current-core.dll']:t.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz')as t:expanded=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())
retire=[];archive=Path('benchmarks/results/2026-11-12-record-cpython-checkpoint/observations.tgz');assert archive.read_bytes()==subprocess.check_output(['git','show','HEAD:'+archive.as_posix()])
for member in [None,'representative.json','confirmation/confirmation.json']:
 with tarfile.open(archive)as t:b=archive.read_bytes()if member is None else t.extractfile(member).read()
 spec=dict(kind='exact',knownPath='record-cpython-b616-20261112/'+(member or 'observations.tgz'),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),canonicalStorage=archive.as_posix(),reason='ExactterminalB616 evidence duplicates only; committed2f2154a5 canonicalGit/SHA verified. Freshlease/UID/path/inode/link proof; qualifieda552referenceprotected, floorsunchanged.')
 if member:spec.update(canonicalEntry=member,canonicalArchiveSHA256=sha(archive))
 retire.append(spec)
archive=Path('benchmarks/results/2026-11-12-text-output-batches/refined/b608/observations.tgz');assert archive.read_bytes()==subprocess.check_output(['git','show','HEAD:'+archive.as_posix()])
with tarfile.open(archive)as t:b=t.extractfile('current-core.dll').read()
retire.append(dict(kind='all-aliases',knownPath='text-batches-b608-20261112/candidate/Lokad.Lython.dll',bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),canonicalStorage=archive.as_posix(),canonicalEntry='current-core.dll',canonicalArchiveSHA256=sha(archive),reason='Olderb2baseline supersededbyfullyqualifiedda9/a552. Exactsource/core/oldadversity preserved incommittedcanonicalGit; allaliases provedfresh before retiring onlythisphysicalimage. a552currentreferenceprotected, floorsunchanged.'))
config=dict(root='/home/lokad/lython-bench-checks/'+root,unit=unit,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),requiredFreeBytes=expanded+252*1024*1024,retire=retire,identity=identity);(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
ast.parse((q/'remote-launch.py').read_text(encoding='utf-8').replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
print('7 existing-worker jobs,5s/12s capturedwarmups,250msrounds;300sowner/265slaststart/360sobservation. Initial/refined sources/adversity preserved; no final retention claim.')
