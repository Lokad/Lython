from pathlib import Path
r=Path('src/Lokad.Lython/Runtime');p=r/'LythonRuntime.Executable.NativeCalls.cs';s=p.read_text(encoding='utf-8');a=s.index('    internal enum NativeReturnShape');b=s.index('    // Conditional branches',a);s=s[:a]+s[b:]
a=s.index('    // Compiler preparation');b=s.index('    private static object InvokeNativeStringOperation',a)
s=s[:a]+'''    // Exact receiver arguments stay in the common prefix. Protocol values
    // acquire an invocation context before the ordinary binder runs.
    private static NativeStringOperation? SelectNativeStringOperation(object? target, int argumentCount)
        => ReferenceEquals(target, ReceiverMethods.StringSplit) && argumentCount is 1 or 2 ? NativeStringOperation.Split
            : ReferenceEquals(target, ReceiverMethods.StringReplace) && argumentCount is 2 or 3 ? NativeStringOperation.Replace
            : ReferenceEquals(target, ReceiverMethods.StringStartsWith) && argumentCount == 1 ? NativeStringOperation.StartsWith
            : ReferenceEquals(target, ReceiverMethods.StringEndsWith) && argumentCount == 1 ? NativeStringOperation.EndsWith
            : null;

    private static bool CanUseNativeStringArguments(NativeStringOperation operation, object? first, object? second, object? third)
        => operation switch
        {
            NativeStringOperation.Split => first is null or PyNone or PyString
                && second is null or PyNone or BigInteger or bool,
            NativeStringOperation.Replace => first is PyString && second is PyString
                && third is null or PyNone or BigInteger or bool,
            NativeStringOperation.StartsWith or NativeStringOperation.EndsWith => first is PyString,
            _ => throw new InvalidOperationException("Unknown string operation.")
        };

'''+s[b:]
a=s.index('    // Select the existing operation without doing native work.');s=s[:a]+'''    private static Func<object, LythonSourceSpan, ExecutionContext, object>? SelectNativeUnaryOperation(
        object? target, object? value)
    {
        if (target is not BuiltinCallable builtin) return null;
        return builtin.Name switch
        {
            "int" when value is PyString or PyBytes => IntegerTextOperation,
            "float" when value is PyString or PyBytes => FloatTextOperation,
            "str" when value is BigInteger or PyString => NativeStrOperation,
            "abs" when ExecutionContext.IsAbsoluteBuiltin(target) && value is BigInteger or double or bool => AbsoluteOperation,
            "sum" when ExecutionContext.IsSumBuiltin(target) && value is PyBytes => SumBytesOperation,
            "len" when ExecutionContext.IsLengthBuiltin(target) && value is not null and not PyInstance => LengthOperation,
            _ => null
        };
    }
}
''';p.write_text(s,encoding='utf-8')
p=r/'LythonRuntime.Executable.Calls.Invoke.cs';s=p.read_text(encoding='utf-8');s=s.replace('TryGetNativeStringCallShape(operation, NativeReturnShape.String,\n                    ReturnShape(first), ReturnShape(second), ReturnShape(third), out _)','CanUseNativeStringArguments(operation, first, second, third)');s=s.replace('            var shape = NativeReturnShape.Other;\n','');s=s.replace('SelectNativeUnaryOperation(target, argument, NativeReturnShape.Other, out shape)','SelectNativeUnaryOperation(target, argument)');s=s.replace('            if (invocation is null && shape == NativeReturnShape.Other) unary = null;','''            // Length keeps its broader ordinary error/protocol selection, but
            // unknown receivers require their invocation context first.
            if (invocation is null && ReferenceEquals(unary, LengthOperation)
                && argument is not (PyString or PyBytes or PyList or PyTuple or PyDict or PySet or PyRange or PyDeque))
                unary = null;''');p.write_text(s,encoding='utf-8')
p=r/'PyFunctionBase.cs';s=p.read_text(encoding='utf-8');s=s.replace('    internal bool CanBorrowPositionalArguments(int count, object? receiver)\n        => receiver is null && SupportsPositionalBinding && count == _bindingPlan.PositionalCount;\n\n','');p.write_text(s,encoding='utf-8')
p=r/'LythonRuntime.Executable.BorrowedValues.cs';s=p.read_text(encoding='utf-8');p.write_text('\n'.join(line.rstrip()for line in s.splitlines())+'\n',encoding='utf-8')
print('Removed recursive-proof shape transport, obsolete input provenance and operand-borrow eligibility; actual builtin/receiver checks remain.')
