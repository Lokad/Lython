# R268 — one ordered helper body

Qualified reference da9e5066/a552, no previous runtime prototype active.
One concrete ref-struct borrow exposes a Span of existing or transient slots;
the existing instruction loop and handlers remain the only operation authority.
Persistent work keeps ownership, iteration positions, cache links and cleanup.
No generic accessor framework, arena/window offsets, policy or public option.

Stage 1: move slot operations into a concrete span view, preserving array-backed
execution and focused semantics. This intermediate refactor is not a deliverable
or performance claim. Stage 2: bind completed bounded helpers into a managed
inline array, run the same prefix, export live state under overlap admission
before real namespace/protocol/suspension. Never restart after effects. Remove
NativeReturnValue/GuardNativeReturn/EvaluateNativeReturn and frontend body tree.
Keep shared native operation facts with real ordinary-call consumers.

Existing compilation and caller owners fund immutable metadata/arguments.
Transient major slots require conservative admission; export holds both owners
through copy and awaited cleanup. First refusal stays terminal. No CLR stack
policy change or unsafe APIs. Wide/captured/region/default-protocol functions
retain ordinary storage, not a syntax restriction. Callback/very-wide performance
debt must be measured/decided before delivery; no automatic promotion.

Focused checks cover Python binding/defaults/closures/classes, parity/truth and
formatting order, actual host suspension, aliases, original spans, cancellation,
refusal, stack bounds and joined cleanup. Whole file/CSV/text/report workloads,
separate compilation and warm allocation, then bounded quiet affected/controls.
Preserve all prior native gains/adversity. Temporary regression is acceptable
inside this isolated migration; completion removes the displaced route and
resolves or explicitly accepts debt. Full delivery only after coherent retention.

Stop at a concrete C# lifetime or operation-order obstacle if it requires another
interpreter, generic storage framework or an unbounded redesign. Preserve the
prototype/evidence and restore qualified source nonincrementally if withdrawing.
No new measurement campaign, publication or producer dependency.
