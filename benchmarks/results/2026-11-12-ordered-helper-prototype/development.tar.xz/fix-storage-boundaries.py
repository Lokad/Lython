from pathlib import Path
r=Path('src/Lokad.Lython/Runtime')
p=r/'LythonRuntime.Executable.Results.cs';s=p.read_text(encoding='utf-8').replace('            => PublishInstructionResult(ref _execution, this, instruction, value);','''        {
            var execution = new ExecutableWork(ref _execution, _execution.Stack.Values);
            PublishInstructionResult(ref execution, this, instruction, value);
        }''');p.write_text(s,encoding='utf-8')
p=r/'LythonRuntime.Executable.Interpreter.cs';s=p.read_text(encoding='utf-8')
anchor='        private static object ReadOperand(ref ExecutableWork execution'
wrapper='''        private static object ReadOperand(ref ExecutableWorkState state, int source, ExecutionContext scope, int input)
        {
            var execution = new ExecutableWork(ref state, state.Stack.Values);
            return ReadOperand(ref execution, source, scope, input);
        }

        private static object TakeOperand(ref ExecutableWorkState state, in ExecutableInstruction instruction, ExecutionContext scope)
        {
            var execution = new ExecutableWork(ref state, state.Stack.Values);
            return TakeOperand(ref execution, instruction, scope);
        }

'''
s=s.replace(anchor,wrapper+anchor,1)
anchor='        private static void ExecuteSliceValueOperation(ref ExecutableWork execution'
wrapper='''        private static void ExecuteSliceValueOperation(ref ExecutableWorkState state, ExecutionContext scope,
            ExecutionContext? invocation, in ExecutableInstruction instruction)
        {
            var execution = new ExecutableWork(ref state, state.Stack.Values);
            ExecuteSliceValueOperation(ref execution, scope, invocation, instruction);
        }

'''
s=s.replace(anchor,wrapper+anchor,1)
s=s.replace('                        execution.Locals,\n                        execution.LocalCells,','                        execution.State.Locals,\n                        execution.LocalCells,')
s=s.replace('AssignExecutableBoundName(execution.Code, execution.Locals,','AssignExecutableBoundName(execution.Code, execution.State.Locals,')
s=s.replace('ref execution.Stack, execution.InstructionIndex, new PendingReturn','ref execution.State.Stack, execution.InstructionIndex, new PendingReturn')
s=s.replace('ReadExecutableSliceBounds(in _execution.Stack,','ReadExecutableSliceBounds(_execution.Stack.Values,').replace('ExecuteExecutableSlice(in execution.Stack,','ExecuteExecutableSlice(execution.Stack.Values,')
p.write_text(s,encoding='utf-8')
p=r/'LythonRuntime.Executable.CasedSplits.cs';s=p.read_text(encoding='utf-8').replace('in execution, resultCall','in execution.State, resultCall');p.write_text(s,encoding='utf-8')
p=r/'LythonRuntime.Executable.Comparisons.cs';s=p.read_text(encoding='utf-8').replace('return CompleteComparisonBranch(ref _execution, this, instruction, truth);','var execution = new ExecutableWork(ref _execution, _execution.Stack.Values);\n                return CompleteComparisonBranch(ref execution, this, instruction, truth);');p.write_text(s,encoding='utf-8')
p=r/'LythonRuntime.Executable.Operations.cs';s=p.read_text(encoding='utf-8').replace('in ExecutableValueStorage storage','ReadOnlySpan<object> storage').replace('ReadExecutableSliceBounds(in storage,','ReadExecutableSliceBounds(storage,').replace('ref ExecutableValueStorage stack','ref ExecutableValueStorage.BorrowedValues stack').replace('stack.Values.AsSpan(start, count)','stack.Values.Slice(start, count)');p.write_text(s,encoding='utf-8')
for name in ['LythonRuntime.Executable.Interpreter.Async.cs','LythonRuntime.Executable.Targets.cs']:
 p=r/name;s=p.read_text(encoding='utf-8').replace('ReadExecutableSliceBounds(in _execution.Stack,','ReadExecutableSliceBounds(_execution.Stack.Values,');p.write_text(s,encoding='utf-8')
p=r/'LythonRuntime.Executable.NativeReturn.cs';s=p.read_text(encoding='utf-8').replace('return CreateListFromStack(ref empty, 0, 0, span, context);','var values = new ExecutableValueStorage.BorrowedValues(ref empty, Span<object>.Empty);\n        return CreateListFromStack(ref values, 0, 0, span, context);');p.write_text(s,encoding='utf-8')
print('Persistent continuation boundaries borrow concrete views; cold namespace/region operations retain persistent owners.')
