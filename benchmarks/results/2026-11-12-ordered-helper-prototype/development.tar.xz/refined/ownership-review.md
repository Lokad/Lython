# Ordered prefix lifetime review

Current uncommitted refined source a08292cf / 569 C# files, versus qualified
da9e5066 / a552. This records source/lifetime evidence, not full qualification.

Transient calls choose eligibility before binding/body work. A fixed 32-reference
managed inline buffer replaces the former small managed native parameter packet
and recursive native evaluation locals. This is minor CLR stack storage under
the unchanged managed admission, not a new heap allowance or a Python limit.
Inputs/defaults retain caller/definition funding. Wider layouts, captures,
protected suites and protocol defaults use existing admitted storage.

The shared synchronous prefix uses one concrete span borrow of those slots.
Its code, closure cells, cursor/cache ownership and instruction index belong to
the existing work state. The C# ref-struct borrow cannot become a continuation.
Context-required operations decline before that operation's effects. Earlier
completed instructions retain their index, temporaries and local values.

Export rents admitted heap capacity while source references and temporary owners
remain live, checks terminal refusal/cancellation, then copies the live storage.
Only that array is attached to an actual continuation frame. No operation restarts.
The parent keeps inputs until the child and its cleanup finish. All private slots
clear before return/refund; frame/cache/result aliases keep their proper owners.
No async operation begins on transient storage and is then abandoned.

Owned callback and wide-call inputs share PrepareFunctionInvocation. It runs the
same prefix against their existing bound array, returning a completed value or
the actual frame at the original instruction. The callback's outer owner clears
the full compiler extent once after preparation/body cleanup. This fixes the
measured first-form eager-frame allocation increase without restoring the tree.

Allocation preflights, original path/host mediation, active cancellation and first
terminal refusal remain in shared operations. New partial-formatting regression
holds values/builder through real host I/O, checks success/cancellation and one
formatter effect, retained result funding, joined cleanup and budget baseline.
Existing protocol/default/closure/generator/stack/lifetime checks pass: 1,366
focused checks across actual .NET 11/10. Six whole scripts both APIs plus compile
pass goldens/files/balances. Full delivery awaits retention, then platform/stress/
installed-consumer checks. No unsafe/native API, fuel, quota, weak reclamation,
tracing, forced GC, admission retry or replacement budget layer was added.
