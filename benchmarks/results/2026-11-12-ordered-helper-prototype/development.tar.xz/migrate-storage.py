from pathlib import Path
import re
root=Path('src/Lokad.Lython/Runtime');p=root/'LythonRuntime.Executable.cs';s=p.read_text(encoding='utf-8')
a=s.index('        public object this[int index]');b=s.index('\n    public LythonExecutionResult Run(',a)
blob=s[a:b];assert blob.endswith('    }\n');blob=blob[:-6]
blob=blob.replace('public ReadOnlyMemory<object?> Slice(int start, int count) => _items.AsMemory(start, count);','public ReadOnlySpan<object?> Slice(int start, int count) => _items.Slice(start, count);')
blob=blob.replace('Array.Clear(_items, newCount, LiveExtent - newCount);','_items.Slice(newCount, LiveExtent - newCount).Clear();')
blob=blob.replace('_items','_values')
for field in ['_nativeIterationPositions','_lookupStorage','_state','_ownedStorageBytes','_firstTemporarySlot','_lastOwnedTemporarySlot','_pendingDisposalHead','_pendingDisposalTail','DeferAsyncDisposal','LiveExtent']:
 blob=re.sub(r'\b'+re.escape(field)+r'\b','_owner.'+field,blob)
view='''using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    // A synchronous borrow, never an owner or an asynchronous continuation.
    // The same operations serve persistent arrays and transient managed slots.
    internal partial struct ExecutableValueStorage
    {
        internal ref struct BorrowedValues(ref ExecutableValueStorage owner, Span<object> values)
        {
            private ref ExecutableValueStorage _owner = ref owner;
            private Span<object> _values = values;
            internal Span<object> Values => _values;
            internal int LiveExtent => _owner.LiveExtent;
            internal bool HasPendingDisposals => _owner.HasPendingDisposals;
            internal void CheckExecution(LythonSourceSpan span) => _owner.CheckExecution(span);
            internal ExecutableLookupCache[] GetLookupCaches(int count, LythonSourceSpan span) => _owner.GetLookupCaches(count, span);
            internal void ClearLookupCache(int index) => _owner.ClearLookupCache(index);
'''+''.join('    '+line+'\n'for line in blob.splitlines())+'''        }
    }

    internal ref struct ExecutableWork(ref ExecutableWorkState state, Span<object> values)
    {
        private ref ExecutableWorkState _state = ref state;
        internal ExecutableValueStorage.BorrowedValues Stack = new(ref state.Stack, values);
        internal ref ExecutableWorkState State => ref _state;
        internal ExecutableCodeObject Code => _state.Code;
        internal Span<object> Locals => Stack.Values;
        internal ExecutableCell?[]? LocalCells => _state.LocalCells;
        internal IReadOnlyList<ExecutableCell>? ClosureCells => _state.ClosureCells;
        internal ref int InstructionIndex => ref _state.InstructionIndex;
        internal bool ReturnConsumedByIteration => _state.ReturnConsumedByIteration;
        internal ref object? ReturnValue => ref _state.ReturnValue;
    }
}
'''
(root/'LythonRuntime.Executable.BorrowedValues.cs').write_text(view,encoding='utf-8')
wrappers='''        public object this[int index]
        {
            get => _items[index].RequireNotNull();
            set => _items[index] = value;
        }

        internal void PublishValue(int resultSlot, int liveExtent, object result)
        {
            var values = new BorrowedValues(ref this, _items);
            values.PublishValue(resultSlot, liveExtent, result);
        }

        internal object TakeValue(int inputSlot, int liveExtent)
        {
            var values = new BorrowedValues(ref this, _items);
            return values.TakeValue(inputSlot, liveExtent);
        }

        internal void ForgetResultInput(int resultSlot)
        {
            var values = new BorrowedValues(ref this, _items);
            values.ForgetResultInput(resultSlot);
        }

        internal bool TryPrepareNativeIteration(object source, int slot, int liveExtent, LythonSourceSpan span)
        {
            var values = new BorrowedValues(ref this, _items);
            return values.TryPrepareNativeIteration(source, slot, liveExtent, span);
        }

        internal bool TryAdvanceNativeIteration(int slot, out PyIterationResult next)
        {
            var values = new BorrowedValues(ref this, _items);
            return values.TryAdvanceNativeIteration(slot, out next);
        }

        public ReadOnlyMemory<object?> Slice(int start, int count) => _items.AsMemory(start, count);

        public void RetireTo(int liveExtent)
        {
            var values = new BorrowedValues(ref this, _items);
            values.RetireTo(liveExtent);
        }
    }
'''
s=s[:a]+wrappers+s[b:];s=s.replace('internal struct ExecutableValueStorage','internal partial struct ExecutableValueStorage',1);p.write_text(s,encoding='utf-8')
files=[]
for p in root.glob('LythonRuntime.Executable*.cs'):
 s=p.read_text(encoding='utf-8');old=s
 # Persistent work transfers and metadata-only readers keep their existing form.
 s=s.replace('ref ExecutableWorkState execution','ref ExecutableWork execution')
 s=s.replace('AdoptExecutableExecution(ref ExecutableWork execution','AdoptExecutableExecution(ref ExecutableWorkState execution')
 if p.name=='LythonRuntime.Executable.Interpreter.Dispatch.cs':
  anchor='        private static InstructionPause ExecuteInstructionPrefix(ref ExecutableWork execution'
  assert anchor in s
  wrapper='''        private static InstructionPause ExecuteInstructionPrefix(ref ExecutableWorkState execution, ExecutionContext scope,
            ExecutionContext? invocation, bool asynchronous, out ValueTask<bool> pending, out LythonSourceSpan? pendingSpan,
            out ValueTask<ExecutionContext?> nextCall)
        {
            var work = new ExecutableWork(ref execution, execution.Stack.Values);
            return ExecuteInstructionPrefix(ref work, scope, invocation, asynchronous, out pending, out pendingSpan, out nextCall);
        }

'''
  s=s.replace(anchor,wrapper+anchor,1)
 # Only these core handlers borrow the view; instance resumptions retain memory.
 if 'ref ExecutableWork execution'in s:
  s=s.replace('in execution, call','in execution.State, call').replace('in execution, site','in execution.State, site')
  s=s.replace('TryLoadClosure(in execution,','TryLoadClosure(in execution.State,')
  s=re.sub(r'(execution\.Stack\.Slice\([^;\n]*?\))\.Span',r'\1',s)
 if s!=old:p.write_text(s,encoding='utf-8');files.append(p.name)
# These pure slot helpers can borrow either representation, with no escape.
p=root/'LythonRuntime.Executable.Binding.cs';s=p.read_text(encoding='utf-8').replace('ExecutableCodeObject codeObject, object[] locals, int slot','ExecutableCodeObject codeObject, ReadOnlySpan<object> locals, int slot',1);p.write_text(s,encoding='utf-8')
p=root/'LythonRuntime.Executable.Interpreter.cs';s=p.read_text(encoding='utf-8');a=s.index('        private static void StoreLocalValue(');b=s.index('        private static void StoreExecutableLocal(',a);part=s[a:b].replace('object[] locals','Span<object> locals');s=s[:a]+part+s[b:];p.write_text(s,encoding='utf-8')
print('Concrete span borrow wired into existing prefix/handlers; persistent storage remains normal for stage1.',len(files),'handler files')
