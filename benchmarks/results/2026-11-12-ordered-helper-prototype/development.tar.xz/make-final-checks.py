from pathlib import Path
r=Path(__file__).parent;s=(r/'storage-focused.py').read_text(encoding='utf-8')
s=s.replace("for framework in ['net11.0']:","for framework in ['net11.0','net10.0']:")
s=s.replace("'TruthTypeSlotDelayedTests','ExactIntegerUnaryTests']","'TruthTypeSlotDelayedTests','ExactIntegerUnaryTests','HelperContinuationLifetimeTests','AsyncFunctionHostingTests','AsyncMidFlightCancellationTests','CooperativeCancellationTests','RepresentativeProtocolCancellationTests','GeneratorCleanupCompositionTests','GeneratorExpressionBoundaryLifetimeTests','FunctionWrapperContainmentTests','FunctionWorkspaceCapacityTests','FunctionValueAccountingScenarioTests']")
s=s.replace('storage-focused-checks.json','focused-checks.json').replace('storage-tests','tests').replace('storage-','final-')
(r/'focused.py').write_text(s,encoding='utf-8')
