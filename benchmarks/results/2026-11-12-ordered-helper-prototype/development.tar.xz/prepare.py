from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent
assert not subprocess.check_output(['git','status','--porcelain']).strip()
before=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
meta=json.loads((r.parent/'conditional-helper-r266/normalized/diagnostic-identity.json').read_text(encoding='utf-8'))
source={n:hashlib.sha256(Path(n).read_bytes()).hexdigest()for n in meta['sourceHashes']}
assert source==meta['sourceHashes']
(r/'baseline.json').write_text(json.dumps(dict(revision=before,productionRevision='da9e5066ecdf03b990ddb53137fc5e43f7dcf73d',qualifiedRun=43183343974,coreSHA256=meta['candidateCoreSHA256'],sourceHashes=source),indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'before-source.tar.xz','w:xz')as t:
 for folder in ['src','tests']:
  for p in Path(folder).rglob('*'):
   if p.is_file()and not any(part in ['bin','obj','TestResults']for part in p.parts)and p.suffix in ['.cs','.csproj']:t.add(p,arcname=p.as_posix())
shutil.copyfile('PLAN.md',r/'PLAN-before.md')
(r/'milestone.md').write_text('''# R268 — one ordered helper body

Qualified reference da9e5066/a552, no previous runtime prototype active.
One concrete ref-struct borrow exposes a Span of existing or transient slots;
the existing instruction loop and handlers remain the only operation authority.
Persistent work keeps ownership, iteration positions, cache links and cleanup.
No generic accessor framework, arena/window offsets, policy or public option.

Stage 1: move slot operations into a concrete span view, preserving array-backed
execution and focused semantics. This intermediate refactor is not a deliverable
or performance claim. Stage 2: bind completed bounded helpers into a managed
inline array, run the same prefix, export live state under overlap admission
before real namespace/protocol/suspension. Never restart after effects. Remove
NativeReturnValue/GuardNativeReturn/EvaluateNativeReturn and frontend body tree.
Keep shared native operation facts with real ordinary-call consumers.

Existing compilation and caller owners fund immutable metadata/arguments.
Transient major slots require conservative admission; export holds both owners
through copy and awaited cleanup. First refusal stays terminal. No CLR stack
policy change or unsafe APIs. Wide/captured/region/default-protocol functions
retain ordinary storage, not a syntax restriction. Callback/very-wide performance
debt must be measured/decided before delivery; no automatic promotion.

Focused checks cover Python binding/defaults/closures/classes, parity/truth and
formatting order, actual host suspension, aliases, original spans, cancellation,
refusal, stack bounds and joined cleanup. Whole file/CSV/text/report workloads,
separate compilation and warm allocation, then bounded quiet affected/controls.
Preserve all prior native gains/adversity. Temporary regression is acceptable
inside this isolated migration; completion removes the displaced route and
resolves or explicitly accepts debt. Full delivery only after coherent retention.

Stop at a concrete C# lifetime or operation-order obstacle if it requires another
interpreter, generic storage framework or an unbounded redesign. Preserve the
prototype/evidence and restore qualified source nonincrementally if withdrawing.
No new measurement campaign, publication or producer dependency.
''',encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');s=s.replace('| Closed investigations; no active runtime prototype |','| Closed investigations |',1);i=s.index('| Not promoted |');s=s[:i]+'''| Active isolated prototype | R268 ordered helper body: concrete span borrow over existing ownership, same instruction loop, explicit live-state export at context/suspension. Remove native body tree/proof/evaluator before delivery. Stage 1 storage refactor is intermediate, not a claimed improvement. Baseline da9/a552 and private source/test snapshot preserved. |
'''+s[i:];p.write_text(s,encoding='utf-8')
print('Qualified baseline/source/tests/ignored plan preserved; coherent deletion/export milestone activated.')
