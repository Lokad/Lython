from pathlib import Path
import shutil
r=Path(__file__).parent;out=r/'refined';out.mkdir()
# Preserve all measured source and all first-form/callback adversity in place.
shutil.copyfile('PLAN.md',out/'PLAN-before-refinement.md')
root=Path('src/Lokad.Lython/Runtime')
p=root/'PyFunctionBase.cs';s=p.read_text(encoding='utf-8');s=s.replace('            frame = EnterInvocationFrame(boundArguments, span);','''            frame = PrepareInvocation(boundArguments, span, out var completed);
            if (frame is null) return completed!;''')
s=s.replace('frame is null ? boundArguments.Assigned.Length : _storageCapacity ?? boundArguments.Assigned.Length','_storageCapacity ?? boundArguments.Assigned.Length')
i=s.index('    internal LythonRuntime.ExecutionContext EnterInvocationFrame(')
s=s[:i]+'''    protected virtual LythonRuntime.ExecutionContext? PrepareInvocation(
        BoundCallArguments arguments, LythonSourceSpan span, out object? completed)
    {
        completed = null;
        return EnterInvocationFrame(arguments, span);
    }

'''+s[i:];p.write_text(s,encoding='utf-8')
p=root/'PyExecutableFunction.cs';s=p.read_text(encoding='utf-8');a=s.index('    protected override object ExecuteBody(')
s=s[:a]+'''    protected override LythonRuntime.ExecutionContext? PrepareInvocation(
        BoundCallArguments arguments, LythonSourceSpan span, out object? completed)
        => LythonRuntime.ExecutionContext.PrepareFunctionInvocation(this, arguments, span, false, out completed);

    protected override object ExecuteBody(LythonRuntime.ExecutionContext frame,
        BoundCallArguments boundArguments, LythonSourceSpan span)
        => frame.ExecutePreparedFunction(span) ?? PyNone.Instance;

    protected override async ValueTask<object> ExecuteBodyAsync(LythonRuntime.ExecutionContext frame,
        BoundCallArguments boundArguments, LythonSourceSpan span)
        => await frame.ExecutePreparedFunctionAsync(span).ConfigureAwait(false) ?? PyNone.Instance;
}
''';p.write_text(s,encoding='utf-8')
p=root/'LythonRuntime.Executable.Calls.cs';s=p.read_text(encoding='utf-8');a=s.index('            ExecutableWorkState work = default;');b=s.index('            var functionEntered',a);s=s[:a]+s[b:]
a=s.index('                if (function.CanDeferInvocationContext)');b=s.index('                PublishChildCallFrame(',a)
s=s[:a]+'''                frame = PrepareFunctionInvocation(function, bound, span, consumedByIteration, out completedValue);
                if (frame is null) goto Completed;
                functionEntered = true;
'''+s[b:]
s=s.replace('                        try { if (ownsWork) work.Stack.ReleaseStorage(); }','                        try { if (frame is not null) frame._execution.Stack.ReleaseStorage(); }')
p.write_text(s,encoding='utf-8')
# No remaining partial declaration is needed for the single code representation.
p=Path('src/Lokad.Lython/Frontend/ExecutableScript.cs');s=p.read_text(encoding='utf-8').replace('internal sealed partial class ExecutableCodeObject','internal sealed class ExecutableCodeObject');p.write_text(s,encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');i=s.index('### Next selected design: one ordered helper body');s=s[:i]+'''R268 first complete form removes the native tree/proof/evaluator and passes
1,366 focused actual-target checks plus five complete scripts/both APIs/compile.
Warm allocation is flat, compilation allocation falls 0.14–1.34%; desktop elapsed
is mixed/adverse. A new complete sorted-report callback control preserves its
independent CPython golden and original Windows stdout mismatch correction.
It exposes +40% allocation from eager callback frames; sync timing has35.8% control
drift, async is+5.3–5.5%. Refine shared invocation preparation before VM retention.
Original source/binaries/checks/adversity stay private and immutable. No CPU claim.

'''+s[i:];p.write_text(s,encoding='utf-8')
print('Ordinary opcode and callback preparation share one ordered prefix; completed callback workspaces clear their full logical extent. First-form adversity preserved.')
