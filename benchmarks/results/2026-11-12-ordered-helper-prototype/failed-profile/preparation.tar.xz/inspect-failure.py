from pathlib import Path
import json,subprocess
r=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,json,subprocess,shutil
r=Path('/home/lokad/lython-bench-checks/ordered-helper-profile-b618-20261112')
with(r.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 status=subprocess.check_output(['systemctl','show','lython-b618-ordered-helper-profile-20261112.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],text=True)
 assert 'MainPID=0'in status
 users=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],text=True,capture_output=True).stdout;assert not users
 journal=subprocess.check_output(['sudo','-n','journalctl','-u','lython-b618-ordered-helper-profile-20261112.service','--no-pager','-n','45'],text=True)
 files=[dict(name=p.relative_to(r).as_posix(),bytes=p.stat().st_size)for p in(r/'profiles').rglob('*')if p.is_file()]
 print(json.dumps(dict(terminal=status,remainingWorkers=users,freeBytes=shutil.disk_usage(r).free,journal=journal,files=files,fixtureFiles=[p.name for p in(r/'guest-fixtures').iterdir()]if(r/'guest-fixtures').exists()else[])))
'''
done=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True);assert done.returncode==0,done.stderr
(r/'failure-inspection.json').write_text(done.stdout,encoding='utf-8');data=json.loads(done.stdout);print(data['terminal'],data['journal'],flush=True);print('freeBytes',data['freeBytes'],'files',data['files'],'fixtureFiles',data['fixtureFiles'])
