from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess,tarfile
r=Path('/home/lokad/lython-bench-checks/ordered-helper-profile-b618-20261112');fixture=r/'guest-fixtures'
with(r.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 service=subprocess.check_output(['systemctl','show','lython-b618-ordered-helper-profile-20261112.service','--property=MainPID,ActiveState,SubState,Result,ExecMainStatus'],text=True);assert'MainPID=0'in service and'ExecMainStatus=1'in service
 assert not Path('/proc/3591119').exists()
 users=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout;assert not users
 assert fixture.resolve()==fixture and fixture.parent==r and fixture.is_mount()
 items=[]
 for p in fixture.iterdir():
  s=p.lstat();assert p.resolve()==p and p.parent==fixture and s.st_uid==os.getuid() and(stat.S_ISFIFO(s.st_mode)or stat.S_ISSOCK(s.st_mode));items.append(dict(name=p.name,mode=s.st_mode,uid=s.st_uid,inode=s.st_ino,bytes=s.st_size))
 terminal=dict(complete=False,terminalService=service,exitCode=1,remainingWorkers=users,workerPIDAbsent=True,partialEvidence=True,reason='Collector checked reference DLL against candidate hash before verification/sampling. Runtime design not evaluated by this failed collection.',fixtureMetadata=items)
 (r/'failure-terminal.json').write_text(json.dumps(terminal,indent=2)+'\\n')
 with tarfile.open(r/'observations-partial.tgz','w:gz',dereference=True)as t:
  for p in sorted(r.rglob('*')):
   if p.is_file()and p.name!='observations-partial.tgz'and not any(v in ['candidate','reference','guest-fixtures']for v in p.relative_to(r).parts):t.add(p,arcname=p.relative_to(r).as_posix())
 with tarfile.open(r/'observations-partial.tgz')as t:assert json.loads(t.extractfile('failure-terminal.json').read())['exitCode']==1
 digest=hashlib.sha256((r/'observations-partial.tgz').read_bytes()).hexdigest()
 # Only dead-worker diagnostic endpoints remain in RAM. Metadata is archived;
 # no active users or ordinary trace payloads are discarded.
 for row in items:
  p=fixture/row['name'];s=p.lstat();assert s.st_ino==row['inode']and s.st_uid==row['uid']and p.resolve()==p;p.unlink()
 assert not list(fixture.iterdir());subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 receipt=dict(complete=False,terminalFailureCached=True,allWorkersJoined=True,guestFixturesRemoved=True,partialArchiveVerifiedUnderLease=True,archiveSHA256=digest,freeBytes=shutil.disk_usage(r).free,reason=terminal['reason'])
 (r/'partial-archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n');print(json.dumps(receipt))
'''
done=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True);assert done.returncode==0,done.stderr;print(done.stdout)
(r/'terminal-status.json').write_text(done.stdout,encoding='utf-8')
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
remote='/home/lokad/lython-bench-checks/ordered-helper-profile-b618-20261112'
for n in ['observations-partial.tgz','failure-terminal.json','partial-archive-receipt.json']:
 done=subprocess.run(scp+['lokad@20.166.121.73:'+remote+'/'+n,str(r/n)],capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
receipt=json.loads((r/'partial-archive-receipt.json').read_text(encoding='utf-8'));assert hashlib.sha256((r/'observations-partial.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
out=Path('benchmarks/results/2026-11-12-ordered-helper-prototype/failed-profile');out.mkdir()
for n in ['observations-partial.tgz','failure-terminal.json','partial-archive-receipt.json','terminal-status.json','failure-inspection.json','identity.json','inventory.json','launch.log','observe-not-before.json']:shutil.copyfile(r/n,out/n)
with tarfile.open(out/'preparation.tar.xz','w:xz')as t:
 for p in r.glob('*.py'):t.add(p,arcname=p.name)
(out/'README.md').write_text('''# B618 — collector role assertion, no profile result

The terminal service exits1 before verification/sampling because inherited code
compares the reference DLL with the candidate hash. Actual source/images remain
unchanged. No elapsed or attribution result follows. The original journal,
reference identity/JIT/worker record and endpoints metadata survive in the
independently verified partial archive. The worker is joined; after a fresh
lease/PID/UID/path/inode proof, only its dead diagnostic endpoints are removed
and RAM unmounted. Terminal status is cached. No runtime source change or
weakened identity assertion is justified; a corrected collector must compare
each role with its own recorded hash. Publication remains postponed.
''',encoding='utf-8')
manifest={p.relative_to(out).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in out.rglob('*')if p.is_file()};(out/'files-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8');print('Terminal failure/partial evidence preserved, endpoint-only cleanup verified; no VM users or RAM fixture remains.')
