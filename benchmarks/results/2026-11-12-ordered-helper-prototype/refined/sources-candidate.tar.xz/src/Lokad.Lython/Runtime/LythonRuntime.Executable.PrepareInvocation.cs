using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed partial class ExecutionContext
    {
        // A bound caller owns its input workspace. Return either its completed
        // value or the actual continuation frame, never a request to restart.
        internal static ExecutionContext? PrepareFunctionInvocation(PyExecutableFunction function,
            in BoundCallArguments bound, LythonSourceSpan span, bool consumedByIteration, out object? completed)
        {
            completed = null;
            var scope = function.DefinitionContext;
            ExecutionContext? frame = null;
            ExecutableWorkState work = default;
            var ownsWork = false;
            var entered = false;
            var transferred = false;
            try
            {
                if (function.CanDeferInvocationContext)
                {
                    scope.EnterFunctionCall(span);
                    entered = true;
                    var entryException = scope.State.CurrentException;
                    try
                    {
                        work = CreateExecutableWorkState(function.CodeObject, scope, bound, function.ClosureCells,
                            argumentsAreLocals: true, lookupOwner: function, returnConsumedByIteration: consumedByIteration);
                        ownsWork = true;
                        var pause = ExecuteInstructionPrefix(ref work, scope, null, false, out _, out _, out _);
                        if (pause == InstructionPause.Boundary)
                        {
                            completed = work.ReturnValue ?? PyNone.Instance;
                            return null;
                        }
                        if (pause != InstructionPause.ContextRequired)
                            throw new InvalidOperationException("A borrowed invocation cannot suspend before acquiring a continuation.");
                        frame = function.EnterInvocationFrame(bound, span, enterFunctionCall: false);
                        frame.AdoptExecutableExecution(ref work, entryException);
                        ownsWork = false;
                    }
                    finally { scope.State.SetCurrentException(entryException); }
                }
                else
                {
                    frame = function.EnterInvocationFrame(bound, span);
                    entered = true;
                    InitializeExecutableFrame(function.CodeObject, frame, bound, function.ClosureCells,
                        argumentsAreLocals: true, lookupOwner: function, returnConsumedByIteration: consumedByIteration);
                }
                transferred = true;
                return frame;
            }
            catch (LythonRuntimeException error)
            {
                if (entered) PyFunctionBinding.AnnotateException(error, frame ?? scope, function.Name, span);
                throw;
            }
            finally
            {
                if (!transferred)
                {
                    try
                    {
                        if (ownsWork)
                        {
                            try { work.Stack.RetireTo(function.CodeObject.FirstTemporarySlot); }
                            finally { work.Stack.ReleaseStorage(); }
                        }
                    }
                    finally
                    {
                        if (entered) scope.State.LeaveFunctionCall();
                        frame?.DetachExecutableExecution();
                    }
                }
            }
        }

        internal object? ExecutePreparedFunction(LythonSourceSpan span)
        {
            ExecutionState.EnsureInterpreterStack(span);
            try
            {
                EnterExecutableSlots();
                Execute();
                return HasFrameReturn ? FrameReturnValue : null;
            }
            finally { LeaveExecutableSlots(); DetachExecutableExecution(); }
        }

        internal async ValueTask<object?> ExecutePreparedFunctionAsync(LythonSourceSpan span)
        {
            ExecutionState.EnsureInterpreterStack(span);
            try
            {
                EnterExecutableSlots();
                await ExecuteAsync().ConfigureAwait(false);
                return HasFrameReturn ? FrameReturnValue : null;
            }
            finally { LeaveExecutableSlots(); DetachExecutableExecution(); }
        }
    }
}
