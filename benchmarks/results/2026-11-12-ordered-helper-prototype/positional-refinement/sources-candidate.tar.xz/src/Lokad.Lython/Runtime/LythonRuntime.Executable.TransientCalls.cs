using System.Runtime.CompilerServices;
using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    // Small managed stack storage, like the former native argument packet.
    // Larger layouts keep ordinary admitted workspaces; this is no syntax cap.
    internal const int TransientValueCapacity = 32;
    [InlineArray(TransientValueCapacity)]
    private struct TransientValues { private object _first; }

    internal sealed partial class ExecutionContext
    {
        [MethodImpl(MethodImplOptions.NoInlining)]
        private ExecutionContext BeginTransientCall(PyExecutableFunction function, ReadOnlySpan<object?> arguments,
            object? receiver, ExecutableCallSite? site, int start, LythonSourceSpan span,
            CallCompletion completion, bool callEntered)
        {
            TransientValues buffer = default;
            Span<object> values = buffer;
            var code = function.CodeObject;
            values = values[..code.ValueStorageCapacity];
            var scope = function.DefinitionContext;
            var consumed = completion == CallCompletion.Call && site is not null
                && CallResultConsumedByIteration(in _execution, site);
            var work = new ExecutableWorkState
            {
                Code = code,
                ClosureCells = function.ClosureCells,
                Stack = ExecutableValueStorage.CreateTransient(code, scope, function),
                InstructionIndex = code.EntryIndex,
                ReturnConsumedByIteration = consumed
            };
            var ownsWork = true;
            var entered = false;
            var transferred = false;
            object[]? exported = null;
            ExecutionContext? frame = null;
            object? completed = null;
            Exception? failure = null;
            try
            {
                var assigned = new ArgumentPresence(function.InvocationBinding.ParameterCount);
                if (function.SupportsDirectPositional && (site is null || site.IsPositionalOnly))
                    BindPositionalFunctionArgumentsInto(values, ref assigned, arguments, span, function.InvocationBinding, receiver);
                else
                    BindFunctionArgumentsInto(values, ref assigned, [], span, function.InvocationBinding,
                        this, receiver: receiver, callSite: site, operands: arguments);
                scope.EnterFunctionCall(span);
                entered = true;
                var entryException = State.CurrentException;
                try
                {
                    var execution = new ExecutableWork(ref work, values);
                    var pause = ExecuteInstructionPrefix(ref execution, scope, null, false, out _, out _, out _);
                    if (pause == InstructionPause.Boundary)
                    {
                        completed = work.ReturnValue ?? PyNone.Instance;
                    }
                    else
                    {
                        if (pause != InstructionPause.ContextRequired)
                            throw new InvalidOperationException("A transient invocation cannot suspend before exporting its operands.");
                        // Admission precedes allocation/copy while all source values
                        // and temporary owners remain live. Continue this instruction;
                        // no earlier guest operation is evaluated again.
                        exported = scope.MemoryGovernor.RentFunctionWorkspace(code.ValueStorageCapacity, span);
                        scope.CheckExecution(span);
                        values.CopyTo(exported);
                        work.Locals = exported;
                        work.Stack.AdoptExportedValues(exported);
                        var bound = new BoundCallArguments(exported, assigned, scope.MemoryGovernor);
                        frame = function.EnterInvocationFrame(bound, span, enterFunctionCall: false);
                        frame.AdoptExecutableExecution(ref work, entryException);
                        ownsWork = false;
                        var child = PublishChildCallFrame(frame, site, start, span, completion, scope.MemoryGovernor);
                        transferred = true;
                        return child;
                    }
                }
                finally { State.SetCurrentException(entryException); }
            }
            catch (Exception error)
            {
                if (TryTranslateCallableException(error, span, out var translated)) error = translated;
                if (entered && error is LythonRuntimeException runtimeError)
                    PyFunctionBinding.AnnotateException(runtimeError, frame ?? scope, function.Name, span);
                failure = error;
            }
            finally
            {
                try
                {
                    if (!transferred)
                    {
                        try
                        {
                            if (ownsWork)
                            {
                                var execution = new ExecutableWork(ref work, values);
                                try { execution.Stack.RetireTo(code.FirstTemporarySlot); }
                                finally { work.Stack.ReleaseStorage(); }
                            }
                        }
                        finally
                        {
                            try
                            {
                                if (entered) State.LeaveFunctionCall();
                                if (exported is not null)
                                    ReturnBoundArguments(exported, scope.MemoryGovernor, code.ValueStorageCapacity);
                            }
                            finally
                            {
                                frame?.DetachExecutableExecution();
                                if (callEntered) LeaveInterpreterFrame();
                            }
                        }
                    }
                }
                finally { values.Clear(); }
            }
            ApplyCallResult(start, span, completion, completed, failure);
            return this;
        }

        private ExecutionContext PublishChildCallFrame(ExecutionContext frame, ExecutableCallSite? site,
            int start, LythonSourceSpan span, CallCompletion completion, MemoryGovernor? storageOwner)
        {
            frame.EnterExecutableSlots();
            _pendingCallSite = site;
            _protocolCallSpan = site is null ? span : null;
            _pendingCallStart = start;
            _callCompletion = completion;
            frame._caller = this;
            frame._boundStorageOwner = storageOwner;
            return frame;
        }
    }
}
