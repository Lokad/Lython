from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;repo=Path.cwd();initial=r/'initial';initial.mkdir()
ids=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
with tarfile.open(initial/'source.tar.xz','w:xz')as t:
 for name,h in ids['sourceSHA256'].items():
  p=repo/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==h;t.add(p,arcname=name)
 t.add(repo/'tests/Lokad.Lython.Tests/InstanceAttributeAccountingTests.cs',arcname='tests/Lokad.Lython.Tests/InstanceAttributeAccountingTests.cs')
for name in ['warm-sync','warm-async','compile','diagnostic-identity.json','focused-checks.json','source.patch','diff-errors.log']:(r/name).rename(initial/name)
for framework,name in [('net11.0','candidate-core.dll'),('net10.0','candidate-net10.dll')]:
 shutil.copyfile(r/'images/candidate/Lokad.Lython.dll'if framework=='net11.0'else r/'candidate-net10.dll',initial/name)
for phase in ['warm-sync','warm-async','compile']:
 (r/phase).mkdir();shutil.copyfile(initial/phase/'hash-witness.json',r/phase/'hash-witness.json')
p=repo/'tests/Lokad.Lython.Tests/PrivateR232SourceProbe.cs'
assert p.parent.resolve()==(repo/'tests/Lokad.Lython.Tests').resolve() and p.read_text(encoding='utf-8').startswith('using System.Text.Json;')
shutil.copyfile(p,r/'private-source-probe.cs.txt');p.unlink()
(r/'refinement.json').write_text(json.dumps(dict(reason='Initial constructor allocation is flat. Private source probe establishes CanDefer=true/MemberWriteCount=1, but first opcode LoadName forces promotion before the field store. Permit unresolved reads from a proven module-root definition context only; preserve ambiguous lexical contexts. Also guard general attribute mutation if successful reentrant admission filled its prepared capacity, rather than allow unadmitted dictionary growth.',controls='Same six scripts, images/auxiliaries and measurement settings. Preserve all initial adverse observations/source. No CPU claim or relaxed qualification.',scope='No compiler-fact rewrite or new frame/ownership/cache/option. Root scope is an existing runtime fact; class/free-variable ambiguity retains context promotion.'),indent=2)+'\n',encoding='utf-8')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');where=s.index('R231 source gate is complete:')
s=s[:where]+'''R232 justified refinement: initial exact pair has flat allocation, mixed/adverse
clocks. The private source probe proves CanDefer=true/MemberWriteCount=1, but a
leading LoadName promotes before storage. Permit namespace reads without an
invocation only for a proven module-root definition context and no nonlocal
directive; ambiguous lexical/class/type scopes keep promotion. Same scripts and
controls, preserve original flat/adverse observations. No new compiler walk/cache.
General attribute mutation must reject if a successful admission callback fills
its prepared capacity; do not allocate an unfunded dictionary growth or retry.
The independent same-instance reentry regression fails frozen4aa(928B vs544B) and
passes the initial candidate; preserve that correctness fix independently.

'''+s[where:]
p.write_text(s,encoding='utf-8',newline='\n')
print('Initial source/cores/all desktop observations preserved; private probe removed, refinement prospectively recorded.')
