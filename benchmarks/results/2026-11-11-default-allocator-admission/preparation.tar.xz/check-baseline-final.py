from pathlib import Path
import hashlib,json,os,shutil,subprocess,xml.etree.ElementTree as ET
repo=Path.cwd();r=Path(__file__).parent;image=r/'baseline-tests-final';shutil.copytree(repo/'tests/Lokad.Lython.Tests/bin/Release/net11.0',image)
core=r/'images/before/Lokad.Lython.dll';sha=hashlib.sha256(core.read_bytes()).hexdigest()
assert sha=='9ee7e700580399ff80d803f0a7535d2de5ff0f10d35a736370f457383be1b67f'
shutil.copyfile(core,image/'Lokad.Lython.dll');assert hashlib.sha256((image/'Lokad.Lython.dll').read_bytes()).hexdigest()==sha
dotnet='C:/Users/JoannesVermorel/.dotnet11/dotnet.exe';env=os.environ.copy();env['DOTNET_ROOT']=str(Path(dotnet).parent);env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH']
cmd=[dotnet,'test',str(image/'Lokad.Lython.WhiteBox.Tests.dll'),'--filter','FullyQualifiedName~ReentrantAttributeGrowthFundsSharedCapacityOnce|FullyQualifiedName~ReentrantGrowthCannotPublishBeyondFundedCapacity|FullyQualifiedName~RefusalDuringAttributeRefundPreventsPublication','--logger','trx;LogFileName=baseline-reentry-final.trx','--results-directory',str(r/'baseline-results')]
with(r/'baseline-reentry-final.log').open('wb')as log:done=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
tree=ET.parse(r/'baseline-results/baseline-reentry-final.trx');counts=tree.find('.//{*}Counters').attrib
error=tree.find('.//{*}ErrorInfo/{*}Message').text
assert done.returncode!=0 and counts['failed']=='3' ,(done.returncode,counts,error)
(r/'baseline-reentry-final.json').write_text(json.dumps(dict(command=cmd,exitCode=done.returncode,counts=counts,message=error,coreSHA256=sha,testSHA256=hashlib.sha256((image/'Lokad.Lython.WhiteBox.Tests.dll').read_bytes()).hexdigest(),isolatedCopiedImage=True,normalOutputsUnmodified=True),indent=2)+'\n',encoding='utf-8')
print('Frozen qualified4aa fails all3 independent attribute regressions in an isolated copied image; normal outputs unchanged.')
