using System.Numerics;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Numbers;
using System.Runtime.CompilerServices;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal enum JsonBaseKind
{
    None,
    Encoder,
    Decoder,
}

internal sealed class PyType : IPyRenderableValue, LythonRuntime.ICallable, IPyHashableValue
{
    internal static readonly PyBuiltinRuntimeType ModuleType = CreateOpaqueRuntimeType("module");
    internal static readonly PyBuiltinRuntimeType RegexPatternType = CreateOpaqueRuntimeType("re.Pattern");
    internal static readonly PyBuiltinRuntimeType RegexMatchType = CreateOpaqueRuntimeType("re.Match");
    internal static readonly PyBuiltinRuntimeType GeneratorType = CreateOpaqueRuntimeType("generator");
    internal static readonly PyBuiltinRuntimeType FunctionType = CreateOpaqueRuntimeType("function");
    internal static readonly PyBuiltinRuntimeType MethodType = CreateOpaqueRuntimeType("method");
    internal static readonly PyBuiltinRuntimeType BuiltinFunctionType = CreateOpaqueRuntimeType("builtin_function_or_method");
    internal static readonly PyBuiltinRuntimeType WrapperDescriptorType = CreateOpaqueRuntimeType("wrapper_descriptor");
    internal static readonly PyBuiltinRuntimeType MethodWrapperType = CreateOpaqueRuntimeType("method-wrapper");
    internal static readonly PyBuiltinRuntimeType MethodDescriptorType = CreateOpaqueRuntimeType("method_descriptor");
    internal static readonly PyBuiltinRuntimeType GetSetDescriptorType = CreateOpaqueRuntimeType("getset_descriptor");
    internal static readonly PyBuiltinRuntimeType MemberDescriptorType = CreateOpaqueRuntimeType("member_descriptor");
    internal static readonly PyBuiltinRuntimeType TupleGetterType = CreateOpaqueRuntimeType("collections._tuplegetter");
    internal static readonly PyBuiltinRuntimeType NoneType = CreateOpaqueRuntimeType("NoneType");
    internal static readonly PyBuiltinRuntimeType EllipsisType = CreateOpaqueRuntimeType("ellipsis");
    internal static readonly PyBuiltinRuntimeType NotImplementedType = CreateOpaqueRuntimeType("NotImplementedType");

    private readonly Dictionary<string, object> _members;
    private PyDict? _namespace;
    internal static readonly PyBuiltinRuntimeType MappingProxyType = CreateOpaqueRuntimeType("mappingproxy");
    internal PyMappingProxy GetNamespace(LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        // Views share the live dictionary/version, not their Python identity.
        // Every returned proxy is admitted through its actual caller's owner.
        _namespace ??= new PyDict(new ObjectNamespaceStorage(_members, null, context.MemoryGovernor, span), context.MemoryGovernor, span);
        return new PyMappingProxy(_namespace, context.MemoryGovernor, span);
    }

    public PyType(string name, IReadOnlyList<PyType> bases, Dictionary<string, object> members, MemoryGovernor? governor = null, LythonSourceSpan? span = null)
    {
        Name = name;
        Bases = bases;
        _members = members;
        // Only the original class namespace receives Python's implicit
        // classmethod wrapper. Later assignments keep ordinary binding rules.
        if (members.TryGetValue("__class_getitem__", out var subscription) && subscription is PyFunctionBase function)
        {
            governor?.Reserve(64, span);
            var method = new PyClassMethod(function);
            governor?.Commit(64);
            members["__class_getitem__"] = method;
        }
        // Python installs this slot at class creation. Assigning __eq__ later
        // does not revoke an existing hash, and inherited hashes do not prevent it.
        if (members.ContainsKey("__eq__") && !members.ContainsKey("__hash__"))
        {
            governor?.Reserve(64, span);
            governor?.Commit(64);
            members.Add("__hash__", PyNone.Instance);
        }
        Mro = BuildMro(this, bases);
        NameValue = governor is null ? PyString.FromString(name) : PyString.FromString(name, governor, span);
        BasesTuple = OwnTypeTuple(Bases, governor, span);
        MroTuple = OwnTypeTuple(Mro, governor, span);
        BindOwnedMembers();
    }

    private static PyTuple OwnTypeTuple(IReadOnlyList<PyType> values, MemoryGovernor? governor, LythonSourceSpan? span)
    {
        var items = new object[values.Count];
        for (var i = 0; i < values.Count; i++)
        {
            items[i] = values[i];
        }

        return governor is null ? PyTuple.FromOwnedArray(items) : PyTuple.FromOwnedArray(items, governor, span);
    }

    public string Name { get; }

    public IReadOnlyList<PyType> Bases { get; }

    public IReadOnlyList<PyType> Mro { get; }

    public PyString NameValue { get; }

    public PyTuple BasesTuple { get; }

    public PyTuple MroTuple { get; }

    public IReadOnlyList<DataclassFieldSpec>? DataclassFields { get; private set; }

    public DataclassFieldSpec[]? DataclassReprFields { get; private set; }

    public DataclassFieldSpec[]? DataclassComparableFields { get; private set; }

    public bool DataclassReprEnabled { get; private set; }

    public bool DataclassEqEnabled { get; private set; }

    public bool DataclassOrderEnabled { get; private set; }

    public DataclassHashMode DataclassHashMode { get; private set; }

    public PyType? MetaType { get; private set; }

    // Only the original type is its own metatype. Its single original base
    // identifies object independently of guest class names or builtin rebinding.
    internal bool IsBuiltinMetatype => ReferenceEquals(MetaType, this);
    internal bool IsBuiltinObject => MetaType is { IsBuiltinMetatype: true } meta
        && meta.Bases.Count == 1 && ReferenceEquals(meta.Bases[0], this);

    public bool TryGetOwnMember(string name, [MaybeNullWhen(false)] out object value) => _members.TryGetValue(name, out value);

    public IEnumerable<KeyValuePair<string, object>> EnumerateOwnMembers() => _members;

    public IEnumerable<string> EnumerateMemberNames()
    {
        var seen = new HashSet<string>(StringComparer.Ordinal);
        foreach (var type in Mro)
        {
            foreach (var name in type._members.Keys)
            {
                if (seen.Add(name))
                {
                    yield return name;
                }
            }
        }
    }

    public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        => PyAttributeLookup.TryResolveTypeMember(this, name, out value);

    public bool TryLookupInMro(string name, int startIndex, [MaybeNullWhen(false)] out object value, out PyType? ownerType)
    {
        for (var i = startIndex; i < Mro.Count; i++)
        {
            var current = Mro[i];
            if (current._members.TryGetValue(name, out value))
            {
                ownerType = current;
                return true;
            }
        }

        value = PyNone.Instance;
        ownerType = null;
        return false;
    }

    public bool TryGetSuccessorMroIndex(PyType anchorType, out int index)
    {
        for (var i = 0; i < Mro.Count; i++)
        {
            if (ReferenceEquals(Mro[i], anchorType))
            {
                index = i + 1;
                return true;
            }
        }

        index = -1;
        return false;
    }

    public bool TrySetMember(string name, object value)
    {
        // Ordinary assignment does not call a descriptor's __set_name__.
        // Property name metadata retains its existing assignment behavior.
        if (value is PyProperty property) property.BindName(name);

        if (value is IClassOwnedMember owned)
        {
            owned.BindOwner(this);
        }

        var added = !_members.ContainsKey(name);
        _members[name] = value;
        if (added) _namespace?.NotifyNamespaceMutation();
        return true;
    }

    public bool RemoveOwnMember(string name)
    {
        if (!_members.Remove(name)) return false;
        _namespace?.NotifyNamespaceMutation();
        return true;
    }

    public void InitializeClassMembers(LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        foreach (var pair in _members)
        {
            if (TryGetSetNameCallable(pair.Value, context, span, out var callable))
            {
                _ = CallableInvocation.InvokeBinary(
                    callable,
                    this,
                    PyString.FromString(pair.Key),
                    span,
                    context);
            }
        }
    }

    public bool IsSubtypeOf(PyType other)
    {
        return Mro.Any(type => ReferenceEquals(type, other));
    }

    public void SetDataclassMetadata(IReadOnlyList<DataclassFieldSpec> fields, bool reprEnabled, bool eqEnabled, bool orderEnabled, DataclassHashMode hashMode)
    {
        DataclassFields = fields;
        DataclassReprFields = fields.Where(static field => field.Repr).ToArray();
        DataclassComparableFields = fields.Where(static field => field.Compare).ToArray();
        DataclassReprEnabled = reprEnabled;
        DataclassEqEnabled = eqEnabled;
        DataclassOrderEnabled = orderEnabled;
        DataclassHashMode = hashMode;
    }

    public void SetMetaType(PyType metaType) => MetaType = metaType;

    internal JsonBaseKind JsonBase { get; private set; }

    internal void SetJsonBase(JsonBaseKind kind) => JsonBase = kind;

    public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        => InvokeCoreAsync(arguments, span, context, false).GetAwaiter().GetResult();

    public ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        => InvokeCoreAsync(arguments, span, context, true);

    internal bool CanPrepareExecutableConstructor
        => JsonBase == JsonBaseKind.None && MetaType is { } meta &&
            !IsBuiltinMetatype && meta.IsBuiltinMetatype &&
            TryLookupInMro("__new__", 0, out var allocator, out _) && LythonRuntime.IsDefaultObjectNew(allocator);

    internal bool TryGetExecutableInitializer([MaybeNullWhen(false)] out PyExecutableFunction initializer)
    {
        if (TryLookupInMro("__init__", 0, out var value, out _) &&
            value is PyExecutableFunction { SupportsDirectPositional: true } function)
        {
            initializer = function;
            return true;
        }
        initializer = null;
        return false;
    }

    private async ValueTask<object> InvokeCoreAsync(CallArgumentValue[] arguments, LythonSourceSpan span,
        LythonRuntime.ExecutionContext context, bool asynchronous)
    {
        context.CheckExecution(span);
        if (IsBuiltinMetatype)
            return InvokeBuiltInType(arguments, span, context);

        object instance;
        if (!TryGetMember("__new__", out var allocator) || LythonRuntime.IsDefaultObjectNew(allocator))
        {
            // The sealed engine allocator only checks the prepended class and
            // creates this admitted instance. No class-prefixed argument copy.
            instance = new PyInstance(this, context.MemoryGovernor, span);
        }
        else if (allocator is PyFunctionBase function)
        {
            instance = asynchronous
                ? await function.InvokeAsync(arguments, span, context, this).ConfigureAwait(false)
                : function.Invoke(arguments, span, context, this);
        }
        else
        {
            if (allocator is not LythonRuntime.ICallable callable)
                throw new LythonRuntimeException("TypeError", $"Class '{Name}' has a non-callable __new__.", span);
            // Dynamic engine callables may retain their argument array. Admit
            // and commit its owned copy rather than refunding it after the call.
            var count = arguments.Length;
            var bytes = checked(32L + 32L * (count + 1L));
            using var storage = context.MemoryGovernor.ReserveTemporary(bytes, span);
            context.CheckExecution(span);
            var prefixed = new CallArgumentValue[checked(count + 1)];
            prefixed[0] = CallArgumentValue.Positional(this);
            for (var i = 0; i < count; i++)
            {
                if ((i & 63) == 0) context.CheckExecution(span);
                prefixed[i + 1] = arguments[i];
            }
            storage.Commit(bytes);
            instance = asynchronous
                ? await callable.InvokeAsync(prefixed, span, context).ConfigureAwait(false)
                : callable.Invoke(prefixed, span, context);
        }
        context.CheckExecution(span);
        if (instance is not PyInstance result || !result.Type.IsSubtypeOf(this)) return instance;

        return await InitializeInstanceAsync(result, arguments, span, context, asynchronous).ConfigureAwait(false);
    }

    internal async ValueTask<object> InitializeInstanceAsync(PyInstance result, CallArgumentValue[] arguments,
        LythonSourceSpan span, LythonRuntime.ExecutionContext context, bool asynchronous)
    {
        context.CheckExecution(span);
        var actualType = result.Type;
        if (actualType.JsonBase != JsonBaseKind.None && !LythonRuntime.JsonSubclassSupport.HasGuestInit(actualType, context))
        {
            if (asynchronous)
                await LythonRuntime.JsonSubclassSupport.RunEngineInitAsync(actualType, result, arguments, span, context).ConfigureAwait(false);
            else LythonRuntime.JsonSubclassSupport.RunEngineInit(actualType, result, arguments, span, context);
            context.CheckExecution(span);
            return result;
        }
        if (!actualType.TryLookupInMro("__init__", 0, out var initializer, out _)) return result;
        object initialized;
        if (initializer is PyFunctionBase initialize)
        {
            // Ordinary functions bind self directly into invocation-owned locals.
            // No transient bound method or receiver-prefixed argument array.
            initialized = asynchronous
                ? await initialize.InvokeAsync(arguments, span, context, result).ConfigureAwait(false)
                : initialize.Invoke(arguments, span, context, result);
        }
        else
        {
            var bound = asynchronous
                ? await PyAttributeLookup.BindForInstanceAsync(result, initializer, context, span).ConfigureAwait(false)
                : PyAttributeLookup.BindForInstance(result, initializer, context, span);
            context.CheckExecution(span);
            if (bound is not LythonRuntime.ICallable callable)
                throw new LythonRuntimeException("TypeError", $"Class '{actualType.Name}' has a non-callable __init__.", span);
            // Python functions bind values before suspension. Other engine
            // callables may retain the packet; do not expose the caller's pool.
            if (bound is not PyFunctionBase and not PyBoundMethod { Function: PyFunctionBase })
                arguments = CopyArguments(arguments, context, span);
            initialized = asynchronous
                ? await callable.InvokeAsync(arguments, span, context).ConfigureAwait(false)
                : callable.Invoke(arguments, span, context);
        }
        context.CheckExecution(span);
        if (!ReferenceEquals(initialized, PyNone.Instance))
            throw new LythonRuntimeException("TypeError", $"__init__ for class '{actualType.Name}' must return None.", span);
        return result;
    }

    private static CallArgumentValue[] CopyArguments(CallArgumentValue[] source,
        LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        if (source.Length == 0) return [];
        var bytes = checked(32L + 32L * source.Length);
        using var storage = context.MemoryGovernor.ReserveTemporary(bytes, span);
        context.CheckExecution(span);
        var arguments = new CallArgumentValue[source.Length];
        for (var i = 0; i < arguments.Length; i++)
        {
            if ((i & 63) == 0) context.CheckExecution(span);
            arguments[i] = source[i];
        }
        storage.Commit(bytes);
        return arguments;
    }

    public PyString RenderPython(PyRenderingContext context) => PyString.FromString($"<class '{Name}'>");

    public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);

    public int GetPyHashCode() => RuntimeHelpers.GetHashCode(this);

    public override string ToString() => $"<class '{Name}'>";

    private object InvokeBuiltInType(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
    {
        if (arguments.Length == 1 && arguments[0].IsPositional)
        {
            return GetRuntimeTypeObject(arguments[0].Value, context, span);
        }

        throw new LythonRuntimeException(
            "TypeError",
            "type(value) supports exactly one argument in Lython; dynamic metaclass construction is unsupported.",
            span);
    }

    private static object GetRuntimeTypeObject(object value, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        // Callable and value classes resolve through the shared helper so
        // x.__class__ is type(x) everywhere both exist; the switch below keeps
        // instance, named-tuple and import-independent paths.
        if (LythonRuntime.TryGetValueClass(value, context, out var classValue))
        {
            return classValue;
        }

        return value switch
        {
            PyInstance instance => instance.Type,
            PyType type => type.MetaType ?? GetBuiltinTypeObject(context, "type", span),
            PyNamedTupleType => GetBuiltinTypeObject(context, "type", span),
            PyNone => NoneType,
            bool => GetBuiltinTypeObject(context, "bool", span),
            _ when PyNumberOps.IsInteger(value) => GetBuiltinTypeObject(context, "int", span),
            double => GetBuiltinTypeObject(context, "float", span),
            PyList => GetBuiltinTypeObject(context, "list", span),
            PyTuple => GetBuiltinTypeObject(context, "tuple", span),
            PyNamedTupleObject namedTuple => namedTuple.Type,
            PyDict => GetBuiltinTypeObject(context, "dict", span),
            PySet => GetBuiltinTypeObject(context, "set", span),
            PyString => GetBuiltinTypeObject(context, "str", span),
            PyBytes => GetBuiltinTypeObject(context, "bytes", span),
            PyPath path => LythonRuntime.PathClass(path),
            PyModule => ModuleType,
            LythonRuntime.RePatternObject => RegexPatternType,
            LythonRuntime.ReMatchObject => RegexMatchType,
            LythonRuntime.ElementTreeModule.Element => LythonRuntime.ElementTreeModule.ElementType,
            PyTimedelta => PyDateTimeOps.TimedeltaType,
            PyDate => PyDateTimeOps.DateType,
            PyTime => PyDateTimeOps.TimeType,
            PyDateTime => PyDateTimeOps.DateTimeType,
            PyTimezone => PyDateTimeOps.TimezoneType,
            LythonRuntime.StatisticsModule.PyNormalDist => LythonRuntime.StatisticsModule.NormalDistType,
            LythonRuntime.RandomModule.PyRandom => LythonRuntime.RandomModule.RandomType,
            _ => throw new LythonRuntimeException("TypeError", "type(value) does not support this value in Lython.", span)
        };
    }

    private static PyBuiltinRuntimeType CreateOpaqueRuntimeType(string name)
        => new(name, static (_, span, _) => throw new LythonRuntimeException(
            "TypeError",
            "Runtime type objects cannot be constructed directly in Lython.",
            span));

    private static object GetBuiltinTypeObject(LythonRuntime.ExecutionContext context, string name, LythonSourceSpan span)
    {
        if (context.TryGetBuiltin(name, out var value))
        {
            return value;
        }

        throw new LythonRuntimeException("RuntimeError", $"Builtin type '{name}' is not available.", span);
    }

    private static IReadOnlyList<PyType> BuildMro(PyType self, IReadOnlyList<PyType> bases)
    {
        // C3 merges each base MRO with the declared base list. A candidate head
        // is eligible only when it occurs in no other remaining tail; advancing
        // offsets instead of modifying the source MROs preserves their identity.
        var result = new List<PyType> { self };
        if (bases.Count == 0)
        {
            return result;
        }

        var sequences = new IReadOnlyList<PyType>[bases.Count + 1];
        for (var i = 0; i < bases.Count; i++)
        {
            sequences[i] = bases[i].Mro;
        }

        sequences[^1] = bases;
        var offsets = new int[sequences.Length];
        var tailOccurrences = new Dictionary<PyType, int>(ReferenceEqualityComparer.Instance);
        foreach (var sequence in sequences)
        {
            for (var i = 1; i < sequence.Count; i++)
            {
                tailOccurrences[sequence[i]] = tailOccurrences.GetValueOrDefault(sequence[i]) + 1;
            }
        }

        while (true)
        {
            PyType? candidate = null;
            var hasRemainingSequence = false;
            for (var sequenceIndex = 0; sequenceIndex < sequences.Length; sequenceIndex++)
            {
                var sequence = sequences[sequenceIndex];
                var offset = offsets[sequenceIndex];
                if (offset == sequence.Count)
                {
                    continue;
                }

                hasRemainingSequence = true;
                var head = sequence[offset];
                if (!tailOccurrences.ContainsKey(head))
                {
                    candidate = head;
                    break;
                }
            }

            if (!hasRemainingSequence)
            {
                return result;
            }

            if (candidate is null)
            {
                throw new InvalidOperationException(
                    $"Cannot create a consistent method resolution order (MRO) for bases {string.Join(", ", bases.Select(b => b.Name))}.");
            }

            result.Add(candidate);
            for (var sequenceIndex = 0; sequenceIndex < sequences.Length; sequenceIndex++)
            {
                var sequence = sequences[sequenceIndex];
                var offset = offsets[sequenceIndex];
                if (offset < sequence.Count && ReferenceEquals(sequence[offset], candidate))
                {
                    var nextHeadIndex = offset + 1;
                    if (nextHeadIndex < sequence.Count)
                    {
                        var nextHead = sequence[nextHeadIndex];
                        var remainingOccurrences = tailOccurrences[nextHead] - 1;
                        if (remainingOccurrences == 0)
                        {
                            tailOccurrences.Remove(nextHead);
                        }
                        else
                        {
                            tailOccurrences[nextHead] = remainingOccurrences;
                        }
                    }

                    offsets[sequenceIndex]++;
                }
            }
        }
    }

    private void BindOwnedMembers()
    {
        foreach (var pair in _members)
        {
            if (pair.Value is IClassNamedMember named)
            {
                named.BindName(pair.Key);
            }

            if (pair.Value is IClassOwnedMember owned)
            {
                owned.BindOwner(this);
            }
        }
    }

    private static bool TryGetSetNameCallable(object value, LythonRuntime.ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out LythonRuntime.ICallable callable)
    {
        if (value is PyInstance instance && instance.Type.TryLookupInMro("__set_name__", 0, out var rawMethod, out _))
        {
            var bound = rawMethod switch
            {
                IPyBindableCallable bindable => bindable.Bind(instance),
                IPyDescriptor descriptor => descriptor.Get(instance, instance.Type, context, span),
                _ => rawMethod
            };

            if (bound is not LythonRuntime.ICallable resolved)
            {
                throw new LythonRuntimeException("TypeError", "__set_name__ must be callable.", span);
            }

            callable = resolved;
            return true;
        }

        callable = null;
        return false;
    }
}
