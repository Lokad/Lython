from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
repo=Path.cwd();r=Path(__file__).parent;out=repo/'benchmarks/results/2026-11-11-default-allocator-admission';out.mkdir()
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
ids=load(r/'diagnostic-identity.json')
for name,h in ids['sourceSHA256'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==h,name
checks=load(r/'focused-checks.json');assert len(checks)==4 and all(x['exitCode']==0 and x['counts']['failed']=='0'for x in checks.values())
for name in ['before.json','diagnostic-identity.json','focused-checks.json','baseline-reentry.json','baseline-reentry-final.json','canonical-selection.json','entry-inspection.json','entry-inspection-refined.json','entry-inspection-allocator.json','refinement.json']:shutil.copyfile(r/name,out/name)
for variant in ['', 'initial','storage-refinement']:
 dest=out/variant if variant else out/'canonical';dest.mkdir(parents=True,exist_ok=True)
 for phase in ['warm-sync','warm-async','compile']:
  folder=dest/phase;folder.mkdir()
  raw=load(r/variant/phase/'measurements.json');assert all(raw[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
  for name in ['measurements.json','summary.json','hash-witness.json','stderr.log']:shutil.copyfile(r/variant/phase/name,folder/name)
decision=dict(status='Retain the sealed default allocator proof correction and independent attribute-admission fixes; full platform/stress/package delivery pending.',
    runtime='Three production files only. Ordinary inherited PyStaticMethod(ObjectNewMethod) now qualifies for the existing canonical constructor frame runner; no guest descriptor evaluation or new dispatch mode. Remove unused funding local.',
    correctness='Actual reentrant capacity is funded once; reject a write whose prepared capacity was filled by callbacks before publication. Recheck terminal refusal after native refund. All3 new regressions fail on immutable qualified4aa/core9ee7 for the expected accounting/publication causes and pass on both actual targets. Existing constructor fixture now asserts the canonical path is available before testing admission mutation.',
    removed='Both earlier eight-file field-storage performance variants are gone: no member-write metadata/extra compiler analysis, constructor capacity hints, native field hooks or root LoadName broadening remain. The R231 signature-only trial is also completely restored.',
    allocation='Maintained constructor CSV complete-job CLR allocation -3.77% through both hosting APIs. Other current scripts and compile allocation unchanged within diagnostic noise. Existing owned packets/frame construction are displaced by the normal canonical route, not a new arena/helper proof.',
    elapsed='Diagnostic desktop constructor sync envelope -3.55..-1.72%, async -9.20%; moving unchanged controls and adverse text/report observations prevent CPU/equivalence claims. Captured-text async +7.95..+8.00%, ordinary text async +3.93..+7.26% remain unresolved regression debt. No quieter confirmation or external CPython ratio yet.',
    contracts='No public API/dependency/options change. Conservative terminal refusal when reentrant host mutations invalidate pending attribute capacity is documented. Existing allocated capacity stays charged, first origin preserved, cleanup refunds remain available.',
    next='Batch full Windows/Ubuntu actual11/10, original Stress and installed Release consumers. A short affected quiet source-pair checkpoint can assess constructor/text elapsed debt; preserve all original variants and adverse conditions. Broader call/frame/whole-script objective stays active; publication postponed.')
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
with tarfile.open(out/'preparation.tar.xz','w:xz')as t:
 for p in sorted(r.rglob('*')):
  rel=p.relative_to(r)
  if not p.is_file()or rel.parts[0]in ['images','baseline-tests','baseline-tests-final']or '__pycache__'in p.parts:continue
  t.add(p,arcname=rel.as_posix())
 t.add(r/'images/before/Lokad.Lython.dll',arcname='cores/before/Lokad.Lython.dll')
 t.add(r/'images/candidate/Lokad.Lython.dll',arcname='cores/canonical/Lokad.Lython.dll')
 t.add(r/'baseline-tests-final/Lokad.Lython.WhiteBox.Tests.dll',arcname='baseline-test/Lokad.Lython.WhiteBox.Tests.dll')
p=out/'preparation.tar.xz'
with tarfile.open(p)as t:
 for m in t.getmembers():
  if m.isfile():t.extractfile(m).read()
(out/'archive-identity.json').write_text(json.dumps(dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8')
(out/'README.md').write_text('''# R232 — canonical default construction and attribute admission

2026-11-11, qualified4aa/frozen9ee7 baseline, evidence HEADc0b42f43. **Runtime retained;
full delivery qualification pending.** Only three production files change. Existing
ordinary classes inherit raw PyStaticMethod(ObjectNewMethod), but the canonical
constructor proof previously accepted only raw ObjectNewMethod. Recognize the sealed
wrapper without invoking guest descriptor code. Normal eligible construction now
uses the existing linear frame runner, avoiding generic type-call packet preparation.
Allocator/metaclass guards, post-allocation initializer selection, same-instance
dynamic handoff, real suspension and cleanup remain. No new runner, public API,
option, cache, pool or dependency. [Decision](decision.json),[frozen source/core pair](diagnostic-identity.json).

## Independent correctness

Host admission can grow the same instance attribute table. Charge actual additional
capacity once; a callback that fills the prepared table must stop the outer write
before unadmitted growth. Native refund can also trigger first refusal; stop before
publication and preserve that exact origin. Existing table capacity stays funded
through cleanup. Conservative earlier refusal on invalidated admission is an explicit
ownership contract, not another memory cap or retry policy.

All **three new observable accounting/publication regressions fail on frozen4aa**:
equivalent reentrant construction charges928B instead of544B; filled-capacity and
refund-refusal cases incorrectly publish instead of failing. The isolated copied
test image uses exact9ee7 and the same new test binary. Failure reasons are inspected,
not inferred from exit code; no dependency/type-loading failure. [Red evidence](baseline-reentry-final.json).
The corrected source passes **93internal/143public focused checks per actual.NET11/
.NET10** after fresh nonincremental build21.75s/zero warnings/errors. Existing
constructor ownership fixtures now assert their canonical-route precondition.
Coverage includes metadata mutation without allocation restart, dynamic hooks,
descriptors, cancellation/first refusal, pending cleanup, retained aliases and
shared-budget reuse. [Checks](focused-checks.json). No timeout/assertion relaxed.

## Bounded complete-script comparison

Same six complete scripts and fixedfec79 worker/optional0.4/auxiliaries; only core
differs. The frozen R151 constructor CSV replaces the CSV-counter diagnostic;
ordinary CSV/text/report/JSON and captured-text controls retain their exact sources.
Windows/.NET11RC3, ordinary GC/tiering;256warmups/image,5rotated16-invocation rounds,
two identical baseline ALCs. All goldens, image isolation, stable/final-zero shared
balances and fixture cleanup pass. Compile construction/disposal is separate.
Warm envelope includes mediated file I/O, fixture reset, full checks and result
disposal; excludes compile/startup/final caches. Run-only clocks exclude reset,
post-return validation/disposal. Coarse process CPU is wider than guest execution.

Constructor CSV CLR allocation is **3.77% lower through both APIs**. Other scripts
and compile allocation are unchanged within diagnostic noise. Constructor desktop
envelope is sync−3.55..−1.72%, async−9.20%; these are **diagnostic elapsed observations**,
not a CPU claim. Text/report adversity remains: captured-text async+7.95..+8.00%,
ordinary text async+3.93..+7.26%; some unchanged controls vary substantially.
Neutrality/regression attribution is unresolved. [Canonical sync](canonical/warm-sync/summary.json),
[async](canonical/warm-async/summary.json),[compilation](canonical/compile/summary.json)
link every original sample and wider CPU. No new CPython ratio or pending-I/O/RSS claim.

Two earlier field-storage variants have flat allocation and mixed/adverse clocks.
Inspection proves their intended constructor route was blocked by raw allocator
recognition; an additional dynamic-name barrier exists. Both entire variants are
removed: no field-write-count metadata, speculative capacity prepayment, native
field hooks or root-name special case. Their [initial](initial/warm-sync/measurements.json)
and [refined](storage-refinement/warm-sync/measurements.json) observations, exact
source/cores and private source probes survive. They are not CPU/permanent design
rejections. The smallest concrete canonical correction is retained instead.

Full platform/original-Stress/installed-consumer qualification is next, independently
of deferred regex publication. A bounded quiet constructor/text comparison may
resolve elapsed debt; no full lane or broad campaign. The broader whole-script
performance objective remains open. [Preparation/all source, binaries, probes,
failures and checks](preparation.tar.xz),[archive identity](archive-identity.json).
Publication/tagging postponed.
''',encoding='utf-8',newline='\n')
print('R232 canonical correction/three red-green regressions/all original variants frozen; delivery pending.')
