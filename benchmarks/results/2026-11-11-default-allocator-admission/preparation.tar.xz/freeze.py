from pathlib import Path
import hashlib,json,shutil,subprocess
repo=Path.cwd();r=Path(__file__).parent;meta=json.loads((r/'before.json').read_text(encoding='utf-8'))
hash=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
changes=subprocess.check_output(['git','diff','--name-only','--','src/Lokad.Lython'],text=True,stderr=subprocess.DEVNULL).splitlines()
assert set(changes)=={'src/Lokad.Lython/Runtime/PyType.cs','src/Lokad.Lython/Runtime/PyInstance.cs','src/Lokad.Lython/Runtime/LythonRuntime.ObjectAttributeSlots.cs'}
with(r/'diff-errors.log').open('wb')as err:(r/'source.patch').write_bytes(subprocess.check_output(['git','diff'],stderr=err))
for role in ['candidate']:
 shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'images'/role/'Lokad.Lython.dll')
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net10.0/Lokad.Lython.dll',r/'candidate-net10.dll')
ids=dict(beforeRevision='4aa2d46d',sourceRevision='R232 sealed default allocator proof correction plus independent attribute reentry/refund correctness fixes; speculative storage metadata/hooks fully removed; baseline fully qualified4aa/frozen9ee7. Existing fec79 worker/optional0.4, frozen R151 constructor CSV plus five maintained controls. No CPU claim.',
sourceSHA256={p:hash(repo/p)for p in changes},images={role:{p.name:hash(p)for p in(r/'images'/role).iterdir()if p.is_file()}for role in ['before','candidate']},net10SHA256=hash(r/'candidate-net10.dll'))
assert ids['images']['before']['Lokad.Lython.dll']=='9ee7e700580399ff80d803f0a7535d2de5ff0f10d35a736370f457383be1b67f'
for name,h in ids['images']['before'].items():
 if name!='Lokad.Lython.dll':assert ids['images']['candidate'][name]==h
(r/'diagnostic-identity.json').write_text(json.dumps(ids,indent=2)+'\n',encoding='utf-8')
print('R232 fresh dual-target cores/source frozen; only core differs in existing comparison images.')
