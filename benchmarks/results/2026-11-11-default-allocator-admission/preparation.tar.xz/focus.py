from pathlib import Path
import json,os,subprocess,xml.etree.ElementTree as ET
r=Path(__file__).parent;dotnet='C:/Users/JoannesVermorel/.dotnet11/dotnet.exe'
env=os.environ.copy();env['DOTNET_ROOT']=str(Path(dotnet).parent);env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH']
filters={
'Lokad.Lython.Tests':'(FullyQualifiedName~InstanceAttributeAccountingTests|FullyQualifiedName~InstanceStorageOwnershipTests|FullyQualifiedName~ConstructorOwnershipTests|FullyQualifiedName~DefaultObjectAttributeBoundaryTests|FullyQualifiedName~InstanceMroLookupBoundaryTests|FullyQualifiedName~SimpleFunctionExecutionBoundaryTests)&Category!=Stress',
'Lokad.Lython.PublicApi.Tests':'(FullyQualifiedName~DefaultObjectAttributeTests|FullyQualifiedName~ConstructorSemanticsTests|FullyQualifiedName~ConstructorLifetimeTests|FullyQualifiedName~ReceiverFunctionEntryTests|FullyQualifiedName~ReceiverFunctionLifetimeTests|FullyQualifiedName~CallInputLifetimeTests|FullyQualifiedName~FunctionDefaultMetadataTests|FullyQualifiedName~NonlocalRebindingTests|FullyQualifiedName~NamedFunctionBindingTests|FullyQualifiedName~PropertyConstructorCompatibilityTests)&Category!=Stress'}
checks={}
for framework in ['net11.0','net10.0']:
 for project,filter in filters.items():
  name=project+'-'+framework;trx=name+'.trx'
  cmd=[dotnet,'test','tests/'+project+'/'+project+'.csproj','-c','Release','-f',framework,'--no-build','--no-restore','--filter',filter,'--logger','trx;LogFileName='+trx,'--results-directory',str(r/'tests')]
  with (r/(name+'.log')).open('wb')as log:done=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
  tree=ET.parse(r/'tests'/trx);counts=tree.find('.//{*}Counters').attrib
  checks[name]=dict(command=cmd,exitCode=done.returncode,counts=counts)
  (r/'focused-checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
  print(name,counts,flush=True);assert done.returncode==0 and counts['failed']=='0'
