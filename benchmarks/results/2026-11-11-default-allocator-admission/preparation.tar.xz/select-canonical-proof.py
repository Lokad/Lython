from pathlib import Path
import hashlib,json,shutil,tarfile
repo=Path.cwd();r=Path(__file__).parent;refined=r/'storage-refinement';refined.mkdir()
ids=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
with tarfile.open(refined/'source.tar.xz','w:xz')as t:
 for name,h in ids['sourceSHA256'].items():
  p=repo/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==h;t.add(p,arcname=name)
 t.add(repo/'tests/Lokad.Lython.Tests/InstanceAttributeAccountingTests.cs',arcname='tests/Lokad.Lython.Tests/InstanceAttributeAccountingTests.cs')
for name in ['warm-sync','warm-async','compile','diagnostic-identity.json','focused-checks.json','source.patch','diff-errors.log']:(r/name).rename(refined/name)
shutil.copyfile(r/'images/candidate/Lokad.Lython.dll',refined/'candidate-core.dll');shutil.copyfile(r/'candidate-net10.dll',refined/'candidate-net10.dll')
for phase in ['warm-sync','warm-async','compile']:
 (r/phase).mkdir();shutil.copyfile(refined/phase/'hash-witness.json',r/phase/'hash-witness.json')
p=repo/'tests/Lokad.Lython.Tests/PrivateR232SourceProbe.cs';assert p.parent.resolve()==(repo/'tests/Lokad.Lython.Tests').resolve()
shutil.copyfile(p,r/'private-allocator-probe.cs.txt');p.unlink()
with tarfile.open(r/'before-source.tar')as t:
 for m in t.getmembers():
  if m.isfile():
   p=repo/m.name;assert hashlib.sha256(p.read_bytes()).hexdigest()==ids['sourceSHA256'][m.name];p.write_bytes(t.extractfile(m).read())
for name in ['src/Lokad.Lython/Runtime/PyType.cs','tests/Lokad.Lython.Tests/ConstructorOwnershipTests.cs']:
 shutil.copyfile(repo/name,r/('before-'+Path(name).name))
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');start=s.index('**R232 selected:');end=s.index('R231 source gate is complete:',start)
s=s[:start]+'''**R232 selected: correct the default allocator proof; preserve independent
attribute-admission fixes.** Source inspection proves ordinary classes inherit
raw PyStaticMethod(ObjectNewMethod), while CanPrepareExecutableConstructor tests
only raw ObjectNewMethod. The existing canonical frame path is consequently
missed. Recognize only the sealed static wrapper without executing guest descriptor
code; preserve live allocator/metaclass guards, one post-allocation initializer
selection and same-instance dynamic handoff. No new calling convention or runner.

- Eliminated work: ordinary eligible constructor calls use the already-delivered
  linear engine instead of generic type invocation/raw packet preparation. Existing
  dynamic/metaclass/descriptor paths remain for their actual semantics. No public
  API/option, new metadata/caches/pool/ownership layer.
- Both earlier eight-file field-storage variants have flat allocation and mixed/
  adverse desktop clocks. Root LoadName and wrapped allocator block their intended
  reach. Preserve all source/cores/failures/measurements; remove field-write-count
  metadata, speculative prepayment and native field read/write hooks completely.
  No speed/design rejection follows from unreachable construction removal. Fix
  the concrete canonical proof before selecting further field/frame work.
- Independent correctness: reentrant host admission can establish the same table
  capacity. Fund its actual additional growth once; if reentry fills the available
  capacity, refuse before unadmitted publication rather than retry. Conservative
  earlier denial on invalidated admission is an explicit ownership tradeoff. Keep
  the two observable balance/refusal regressions and remove unused funding local.
- Validate inherited/explicit static default allocators and real custom allocators,
  metaclasses, positional/keyword/default/variadic init, None-return checks, closures,
  descriptors, generators, order, stack/cancellation/terminal refusal/retained aliases,
  actual suspension and awaited cleanup/budget reuse. Strengthen existing ownership
  fixture preconditions so they actually exercise the canonical constructor route.
- Same six-script exact pair: frozen R151 constructor CSV plus ordinary CSV/text/
  JSON/report/captured-text controls, compile separate, allocation and Run-only/
  envelope labelled. One short quiet confirmation if warranted; preserve original
  variants, no threshold adjustment or blind retiming. Retain/refine/withdraw with
  regression debt. Full platform/stress/installed consumers at retained delivery.

'''+s[end:]
p.write_text(s,encoding='utf-8',newline='\n')
(r/'canonical-selection.json').write_text(json.dumps(dict(reason='Both storage variants haveflat allocation; source probes prove the canonical allocator gate rejects the normal sealed PyStaticMethod(ObjectNewMethod) wrapper. Correct that gate instead of promoting speculative field hints/access hooks.',removal='Restore all eight performance-prototype source files exactly; retain only separately re-applied attribute correctness changes plus sealed allocator proof correction. No root LoadName broadening/field metadata/native-storage hooks remain.',evidence='entry-inspection-allocator.json, original and storage-refinement frozen pairs',measurement='Same six existing scripts/settings and original baseline/control images. No performance claim before controlled observations.'),indent=2)+'\n',encoding='utf-8')
print('Both storage variants preserved and removed; canonical allocator proof selected before final source edit.')
