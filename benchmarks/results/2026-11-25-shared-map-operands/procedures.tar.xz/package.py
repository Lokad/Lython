from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
out=lab.parents[3]/'benchmarks/results/2026-11-25-shared-map-operands'
quiet=lab/'comparison/quiet'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert out.is_dir()
identity=read(quiet/'identity.json')
assert sha(lab/'candidate.patch')==identity['sourcePatchSHA256']
assert all({p.name:sha(p) for p in (lab/role).iterdir()}==files for role,files in identity['imageFiles'].items())
for folder, name in ((quiet,'identity.json'),(lab,'allocation-summary.json'),(lab,'tape-summary.json')):
    shutil.copyfile(folder/name,out/name)
procedures=['candidate.patch','test.patch','freeze.py','allocations.py','check-tape.py','prepare-quiet.py','quiet.py','archive.py','package.py','test-ubuntu.sh',
 'candidate-build.log','build-recovery.txt','draft/decision.txt','draft/candidate.patch','draft/candidate-build.log','draft/candidate-verify.json',
 'draft/windows-net11.0-Lokad.Lython.PublicApi.Tests.log','draft/ubuntu-net11.0-Lokad.Lython.PublicApi.Tests.log','draft/ubuntu-net11.0-Lokad.Lython.Tests.log','ubuntu-net11.0-Lokad.Lython.PublicApi.Tests.log','ubuntu-net11.0-Lokad.Lython.Tests.log','windows-net11.0-Lokad.Lython.PublicApi.Tests.log','windows-net10.0-Lokad.Lython.PublicApi.Tests.log',
 'candidate-allocation-final.json','reference-allocation-final.json','tape-candidate.json','tape-reference.json',
 'comparison/candidate-verify.json','comparison/reference-verify.json','comparison/quiet/storage-custody.json','comparison/quiet/upload.json']
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for n in procedures:
        archive.add(lab/n,arcname=n,recursive=False)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert archive.getnames()==procedures
    assert all(hashlib.sha256(archive.extractfile(n).read()).hexdigest()==sha(lab/n) for n in procedures)
