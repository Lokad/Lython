set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
trap 'status=$?; printf "%s\n" "$status" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
