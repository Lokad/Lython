from pathlib import Path
import ast,datetime,hashlib,json,shlex,subprocess,tarfile

r=Path(__file__).parent
delivery=json.loads((r.parent/'compiler-instruction-store-r424/delivery/delivery-candidate.json').read_text(encoding='utf-8'))
proof=json.loads((r.parent/'compiler-instruction-store-r424/delivery/source-proof.json').read_text(encoding='utf-8'))
assert delivery['head'].startswith('a2d20928') and proof['allInputsMatchAfterExplicitUTF8NewlineNormalization'] and proof['inputCount']==590
q=r/'quiet';q.mkdir();old=r.parent/'compiler-instruction-store-r424/quiet'
root='/home/lokad/lython-bench-checks/consume-text-b822-20261116';unit='lython-b822-consume-text-20261116'
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));keys=set(json.loads((old/'identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate'])
images={role:{n:h for n,h in files.items()if n in keys}for role,files in f['images'].items()}
identity=dict(sourceRevision='R426 uncommitted'+images['candidate']['Lokad.Lython.dll'][:8]+' versus committeda2d20928/frozen9d26d408; full43789371043GREEN',purpose='Thirteen terminal text builders consume admitted backing instead of a final copy/temporary lease; reusable JSON snapshots unchanged. Complete text normalization/report warm, report fresh and unchanged JSON control. No new memory policy, infrastructure or public API.',coreSHA256={label:images['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['candidate','candidate-control','reference','reference-control']},imageFiles=images,prototype=True,publicationHeld=True,referenceQualificationRun='43789371043',referenceFullQualificationPendingAtStaging=False,candidateSourceIdentitySHA256=hashlib.sha256((r/'frozen/identity.json').read_bytes()).hexdigest())
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.text-normalization.large','warm'],['scripts.report-render.format-method.large','warm'],['scripts.report-render.format-method.large','compile-run'],['scripts.json-summary-helpers.large','warm']]
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
    s=(old/n).read_text(encoding='utf-8').replace('compiler-store-b820-20261116','consume-text-b822-20261116').replace('lython-b820-compiler-store-20261116',unit).replace('B820','B822')
    if n=='collect.py':
        a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+"\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n"+s[b:]
    if n.endswith('.py'):ast.parse(s)
    (q/n).write_text(s,encoding='utf-8',newline='\n')
(q/'representative.json').write_bytes((r/'catalog.json').read_bytes())
with tarfile.open(q/'payload.tgz','w:gz')as a:
    for n in ['identity.json','collect.py','archive-owned.py','run.sh','representative.json']:a.add(q/n,arcname=n)
    a.add(r/'frozen/candidate/Lokad.Lython.dll',arcname='candidate/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz')as a:size=sum(m.size for m in a if m.isfile())
groups=json.loads((r/'retirement-groups.json').read_text(encoding='utf-8'))
for proof in groups:
    assert subprocess.check_output(['git','show',proof['custody']['commit']+':'+proof['custody']['archive']])==Path(proof['custody']['archive']).read_bytes()
c=dict(root=root,unit=unit,source='/home/lokad/lython-bench-checks/compiler-store-b820-20261116',sourceFiles=images['reference'],sourceCatalogSHA256=hashlib.sha256((old/'representative.json').read_bytes()).hexdigest(),catalogSHA256=hashlib.sha256((q/'representative.json').read_bytes()).hexdigest(),identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=size)
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
oldcode=(old/'remote-launch.py').read_text(encoding='utf-8');code=oldcode[:oldcode.index('c=')]+ 'c='+repr(c)+'\n'+oldcode[oldcode.index("b=Path("):]
code=code.replace('lython-b820-fixtures','lython-b822-fixtures')
ast.parse(code);(q/'remote-launch.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=200)).isoformat(),ownerSeconds=240),indent=2)+'\n',encoding='utf-8',newline='\n')
print(p.stdout.decode('utf-8'),flush=True)
