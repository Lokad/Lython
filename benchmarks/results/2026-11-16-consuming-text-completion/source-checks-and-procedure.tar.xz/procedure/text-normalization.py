with open('input.txt', newline='') as source:
    text = source.read()
text = text.replace('\r\n', '\n').replace('\r', '\n').expandtabs(4)
cleaned = '\n'.join(line.rstrip() for line in text.split('\n')).strip() + '\n'
with open('normalized.txt', 'w', newline='') as target:
    target.write(cleaned)
print(len(cleaned), len(cleaned.splitlines()))
