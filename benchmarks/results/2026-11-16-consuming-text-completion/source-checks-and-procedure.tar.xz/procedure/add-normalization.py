from pathlib import Path
import base64,hashlib,json,struct,subprocess,tempfile
r=Path(__file__).parent
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'))
(r/'original-three-case-catalog.json').write_bytes((r/'catalog.json').read_bytes())
blocks=1024
raw=('  Café😀\tβeta\tvalue  \r\n\t中\tStraße  \n\tΩ\r   \r\n'*blocks).encode('utf-8')
expected=('\n'.join(['  Café😀 βeta    value','    中   Straße','    Ω','']*blocks).strip()+'\n').encode('utf-8')
source="""with open('input.txt', newline='') as source:
    text = source.read()
text = text.replace('\\r\\n', '\\n').replace('\\r', '\\n').expandtabs(4)
cleaned = '\\n'.join(line.rstrip() for line in text.split('\\n')).strip() + '\\n'
with open('normalized.txt', 'w', newline='') as target:
    target.write(cleaned)
print(len(cleaned), len(cleaned.splitlines()))
"""
(r/'text-normalization.py').write_text(source,encoding='utf-8',newline='\n')
stdout=f'{len(expected.decode())} {4*blocks-1}\n'
with tempfile.TemporaryDirectory(prefix='lython-normalization-python-') as directory:
    Path(directory,'input.txt').write_bytes(raw)
    cp=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=directory,capture_output=True,text=True,encoding='utf-8',timeout=30)
    assert cp.returncode==0,cp.stderr
    assert cp.stdout==stdout and Path(directory,'normalized.txt').read_bytes()==expected
(r/'normalization-cpython.json').write_text(json.dumps(dict(version='CPython3.13.2',inputBytes=len(raw),inputLines=4*blocks,
    outputBytes=len(expected),outputLines=4*blocks-1,stdout=stdout,independentExpectedRows=True,
    inputSHA256=hashlib.sha256(raw).hexdigest(),outputSHA256=hashlib.sha256(expected).hexdigest(),matched=True),indent=2)+'\n',encoding='utf-8',newline='\n')
def digest(files):
    h=hashlib.sha256();h.update(struct.pack('>i',len(files)))
    for n,v in sorted(files.items()):
        name=n.encode();h.update(struct.pack('>i',len(name)));h.update(name);h.update(struct.pack('>i',len(v)));h.update(v)
    return h.hexdigest()
case=dict(catalog['cases'][1]);case.update(id='scripts.text-normalization.large',family='scripts',category='file-processing',scale='4096-lines',size=4*blocks,
    source=source,fixtureJson=json.dumps(dict(size=4*blocks,text=None,inputFiles={'input.txt':base64.b64encode(raw).decode()},
    outputFiles={'normalized.txt':base64.b64encode(expected).decode()}),ensure_ascii=False,separators=(',',':')),
    expectedOutput=stdout,sourceUtf8Bytes=len(source.encode()),fixtureTextUtf8Bytes=len(raw),fixtureTextCodePoints=len(raw.decode()),
    expectedOutputUtf8Bytes=len(stdout.encode()),expectedFilesSha256=digest({'normalized.txt':expected}))
for n,k in [('sourceSha256','source'),('fixtureSha256','fixtureJson'),('expectedOutputSha256','expectedOutput')]:case[n]=hashlib.sha256(case[k].encode()).hexdigest()
catalog['cases'].append(case)
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
d=r/'normalization-allocation';d.mkdir();new=dict(catalog);new['cases']=[case]
(d/'catalog.json').write_text(json.dumps(new,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
driver=d/'bin/Release/net11.0';driver.mkdir(parents=True)
import shutil
for p in (r/'allocation-short/bin/Release/net11.0').glob('ValidatedAllocation.*'):shutil.copyfile(p,driver/p.name)
script=(r/'measure-allocation.py').read_text(encoding='utf-8').replace("d=r/'allocation-short'", "d=r/'normalization-allocation'").replace("r/'allocation-summary.json'", "r/'normalization-allocation-summary.json'")
(r/'measure-normalization.py').write_text(script,encoding='utf-8',newline='\n')
print(dict(inputBytes=len(raw),inputLines=4*blocks,outputBytes=len(expected),independentPythonMatch=True))
