from pathlib import Path
import json
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');r=Path(__file__).parent
a=s.index('| Committed and fully qualified |');b=s.index('| Latest external baseline |',a)
s=s[:a]+'''| Committed and fully qualified | **a2d20928 / 9d26d408**, one compiler instruction store. [Full43789371043](benchmarks/results/2026-11-16-compiler-instruction-store/delivery/README.md) GREEN: Windows/Ubuntu actual.NET11/10 each4,777internal/17,912public ordinary, original13/406stress and installed Release consumers.16summaries/590inputs verified; receipt committed/pushed38fc0d73. R423native-finally-prefix qualification remains complete. Both terminals cached; never requery. |
| Active runtime prototype | **R426 / 810dafdd**, thirteen consuming text completions.87internal/2,547public eachactual11/10 pass;593inputs frozen. Terminal copy/metadata threshold fixtures corrected with refusal/ownership intact; original failures preserved. Local report allocation−6.29%/accounted peak+0.86%, new complete normalization−9.07%/peak+3.71%; unchanged controls flat. B822four jobs active; retention decision pending. |
''' +s[b:]
s=s.replace('1. Finish R424full43789371043: Windows/Ubuntu actual11/10, original stress and\n   installed Release consumers; verify all16summaries and590committed source inputs.\n   Keep development independent of CI; use focused Release checks for new changes.\n2. **R426selected:',
'''R424full43789371043is GREEN;16summaries/590inputs archived, receipt38fc0d73.
Do not repeat its unchanged platform/stress/package checks.

1. **R426active:''')
s=s.replace('   and invoice construction; current R420storage samples include useful work and',
'''   and file normalization; current R420storage samples include useful work and''')
s=s.replace('   do not establish an isolated removable CPU share. Use complete method-report\n   warm/fresh, invoice warm and unchanged JSON helper control; a short local\n   allocation/peak-accounting comparison precedes one bounded quiet source pair.',
'''   do not establish an isolated removable CPU share. Complete normalization (52,224B,
   4,096lines) has independently constructed stdout/file goldens matching CPython.
   Use normalization warm, method-report warm/fresh and unchanged JSON control.
   Invoice is an unchanged allocation control; its current path already transfers
   final output. Original three-case local allocation evidence remains intact.''')
s=s.replace('   Stop with retain/refine/remove after correctness and one controlled comparison,',
'''   Implementation810dafddpasses87internal/2,547public eachactual11/10, independent
   CPython controls and all local golden/budget cleanup gates.593inputs frozen.
   Report allocation−6.29%/accounted execution peak+0.86%; normalization−9.07%/peak
   +3.71%. Peaks are conservative governor estimates, not heap/RSS. Controls flat.
   B822active: four jobs, existing240sowner/quiet/archive/floors. Observe after
   '''+json.loads((r/'quiet/observe-not-before.json').read_text(encoding='utf-8'))['doNotObserveBeforeUTC']+'''. No other prototype.
   Stop with retain/refine/remove after correctness and one controlled comparison,''')
p.write_text(s,encoding='utf-8',newline='\n')
print('PLAN now distinguishes qualified9d, active810, allocation/peak tradeoffs and pending CPU decision.')
