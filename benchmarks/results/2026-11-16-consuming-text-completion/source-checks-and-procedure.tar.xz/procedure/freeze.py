from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
r=Path(__file__).parent;f=r/'frozen';f.mkdir();images={}
base=r.parent/'compiler-instruction-store-r424/frozen/candidate'
for role in ['reference','candidate']:
    target=f/role;shutil.copytree(base,target)
    if role=='candidate':shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',target/'Lokad.Lython.dll')
    images[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in target.iterdir() if p.is_file()}
assert images['reference']['Lokad.Lython.dll']=='9d26d408ac591aba042f92106167a7cc1df8148b6fc26554f65fa667af5cb5f0'
assert all(images['candidate'][n]==h for n,h in images['reference'].items() if n!='Lokad.Lython.dll')
paths=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()
paths+=['Directory.Build.props','Directory.Packages.props','NuGet.Config','global.json',
        'tests/Lokad.Lython.Tests/DirectStringJoinTests.cs','tests/Lokad.Lython.PublicApi.Tests/StringReplaceCallTests.cs',
        'tests/Lokad.Lython.PublicApi.Tests/TerminalTextOwnershipTests.cs']
sources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}
assert len(paths)==593
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz') as a:
    for p in paths:a.add(p,arcname=p)
    a.add(r/'checks',arcname='checks')
selection=json.loads((r/'selection.json').read_text(encoding='utf-8'))
identity=dict(buildSourceCommit=selection['baseCommit'],sourceSnapshotCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    prototype=True,images=images,sources=sources,
    contracts='Thirteen terminal text builders transfer existing admitted capacity; no exact final array/copy/temporary lease. Metadata admission, capacity funding, actual callbacks and joined cleanup preserved. JSON reusable snapshots unchanged; no new memory policy/infrastructure or public API.')
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
checks=[dict(file=p.name,**E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib) for p in (r/'checks').glob('*.trx')]
assert sorted(int(x['passed']) for x in checks)==[87,87,2547,2547] and all(x['failed']=='0' for x in checks)
(r/'focused-checks.json').write_text(json.dumps(dict(checks=checks,productionNonincrementalReleaseBuild=True,
    finalTestOnlyBuildsNoDependencies=True,frameworks=['net11.0','net10.0'],fullQualificationPending=True,
    originalConditions='Initial four exact-copy-charge assertions; second two old replace-overlap thresholds and one new test using Run with asynchronous-only host. Preserved original source/logs/TRX; metadata charge, larger real output and RunAsync fixtures corrected without relaxing budget/refusal/cleanup.'),indent=2)+'\n',encoding='utf-8',newline='\n')
print(dict(core={role:v['Lokad.Lython.dll'] for role,v in images.items()},sourceInputs=len(paths),checks=[(x['file'],x['passed']) for x in checks]))
