from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
# Retire only the older eee working replica; current 9d baseline/new 810 stay.
archive='benchmarks/results/2026-11-16-compiler-instruction-store/source-checks-and-procedure.tar.xz'
raw=Path(archive).read_bytes();assert subprocess.check_output(['git','show',head+':'+archive])==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as a:core=a.extractfile('frozen/reference/Lokad.Lython.dll').read()
sha=hashlib.sha256(core).hexdigest();assert sha=='eee74a1030fc154f3de9e35843fac8b178834ea339ea2f45b282935da0fb55f4'
s=(r.parent/'finally-prefix-r423/inspect-vm-generated.py').read_text(encoding='utf-8')
s=s.replace('format-operation-b814-20261115/candidate','finally-prefix-b819-20261116/candidate')
s=s.replace('0393331afcdd9bffcb3dc1b2e1764316df152a20749ec08cec0c51f6e9a1b12f',sha)
(r/'inspect-vm-generated.py').write_text(s,encoding='utf-8',newline='\n')
p=subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'inspect-vm-generated.py')],capture_output=True,timeout=45)
assert p.returncode==0,p.stderr
v=json.loads((r/'historical-aliases.json').read_text(encoding='utf-8'));assert v['sha256']==sha and v['bytes']==len(core)
v['custody']=dict(commit=head,archive=archive,archiveSHA256=hashlib.sha256(raw).hexdigest(),member='frozen/reference/Lokad.Lython.dll')
(r/'historical-aliases.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
groups=[v]
# Existing retirement validation accepts any exact inode group. These are
# redundant working JSONs, already preserved in their committed raw archives.
for remote,canonical in [('finally-prefix-b819-20261116','2026-11-16-finally-prefix'),
                         ('compiler-store-b820-20261116','2026-11-16-compiler-instruction-store'),
                         ('compiler-cpython-b821-20261116','2026-11-16-compiler-cpython-checkpoint')]:
    name='benchmarks/results/'+canonical+'/observations.tgz';data=Path(name).read_bytes()
    assert subprocess.check_output(['git','show',head+':'+name])==data
    with tarfile.open(fileobj=io.BytesIO(data)) as a:body=a.extractfile('confirmation/confirmation.json').read()
    groups.append(dict(sha256=hashlib.sha256(body).hexdigest(),bytes=len(body),links=1,
        paths=[remote+'/confirmation/confirmation.json'],custody=dict(commit=head,archive=name,archiveSHA256=hashlib.sha256(data).hexdigest(),member='confirmation/confirmation.json')))
(r/'retirement-groups.json').write_text(json.dumps(groups,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(r.parent/'compiler-instruction-store-r424/launch-vm.py').read_text(encoding='utf-8')
s=s.replace("r.parent/'finally-prefix-r423/delivery/", "r.parent/'compiler-instruction-store-r424/delivery/")
s=s.replace("'e6500781'", "'a2d20928'").replace('==591','==590')
s=s.replace("old=r.parent/'finally-prefix-r423/quiet'", "old=r.parent/'compiler-instruction-store-r424/quiet'")
s=s.replace('compiler-store-b820-20261116','consume-text-b822-20261116',1)
s=s.replace("unit='lython-b820-compiler-store-20261116'", "unit='lython-b822-consume-text-20261116'")
s=s.replace("sourceRevision='R424 uncommitted'", "sourceRevision='R426 uncommitted'")
s=s.replace(' versus committede6500781/frozeneee74a10; full43787325151active at staging',
            ' versus committ a2d20928/frozen9d26d408; full43789371043GREEN')
s=s.replace('One compiler block instruction store replaces duplicate normalized/forwarded arrays and wrappers. Complete manifest/generated normalizer compile, generated fresh, unchanged invoice warm control; no runtime ABI, unsafe API or policy change.',
            'Thirteen terminal text builders consume admitted backing instead of a final copy/temporary lease; reusable JSON snapshots unchanged. Complete text normalization/report warm, report fresh and unchanged JSON control. No new memory policy, infrastructure or public API.')
s=s.replace("referenceQualificationRun='43787325151',referenceFullQualificationPendingAtStaging=True", "referenceQualificationRun='43789371043',referenceFullQualificationPendingAtStaging=False")
a=s.index('jobs=');b=s.index('\nfor n in',a)
s=s[:a]+"jobs=[['scripts.text-normalization.large','warm'],['scripts.report-render.format-method.large','warm'],['scripts.report-render.format-method.large','compile-run'],['scripts.json-summary-helpers.large','warm']]"+s[b:]
s=s.replace(".replace('finally-prefix-b819-20261116','compiler-store-b820-20261116')", ".replace('compiler-store-b820-20261116','consume-text-b822-20261116')")
s=s.replace(".replace('lython-b819-finally-prefix-20261116',unit)", ".replace('lython-b820-compiler-store-20261116',unit)")
s=s.replace(".replace('B819','B820')", ".replace('B820','B822')")
s=s.replace("source='/home/lokad/lython-bench-checks/finally-prefix-b819-20261116'", "source='/home/lokad/lython-bench-checks/compiler-store-b820-20261116'")
s=s.replace("proof=json.loads((r/'historical-aliases.json').read_text(encoding='utf-8'))\nassert subprocess.check_output(['git','show',proof['custody']['commit']+':'+proof['custody']['archive']])==Path(proof['custody']['archive']).read_bytes()",
'''groups=json.loads((r/'retirement-groups.json').read_text(encoding='utf-8'))
for proof in groups:
    assert subprocess.check_output(['git','show',proof['custody']['commit']+':'+proof['custody']['archive']])==Path(proof['custody']['archive']).read_bytes()''')
s=s.replace('retireGroups=[proof]', 'retireGroups=groups')
s=s.replace("code=code.replace('lython-b819-fixtures','lython-b820-fixtures')", "code=code.replace('lython-b820-fixtures','lython-b822-fixtures')")
s=s.replace('committ a2d20928','committeda2d20928')
assert "retireGroups=groups" in s and "old=r.parent/'compiler-instruction-store-r424/quiet'" in s
ast.parse(s);(r/'launch-vm.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(oldCore=sha,coreAliases=v['paths'],redundantArchivedJsonBytes=sum(x['bytes'] for x in groups[1:]),groups=len(groups))))
