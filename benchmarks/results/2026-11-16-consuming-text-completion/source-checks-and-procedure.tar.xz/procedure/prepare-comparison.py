from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).parent
base=json.loads((r.parent/'compiler-instruction-store-r424/catalog.json').read_text(encoding='utf-8'))
report=json.loads((r.parent/'compiler-checkpoint-r425/checkpoint/representative.json').read_text(encoding='utf-8'))
base['cases']=[next(c for c in report['cases'] if c['id']=='scripts.report-render.format-method.large')]+[
    next(c for c in base['cases'] if c['id']==n) for n in ['scripts.csv-invoice.large','scripts.json-summary-helpers.large']]
for c in base['cases']:
    for n,k in [('sourceSha256','source'),('fixtureSha256','fixtureJson'),('expectedOutputSha256','expectedOutput')]:assert hashlib.sha256(c[k].encode()).hexdigest()==c[n]
(r/'catalog.json').write_text(json.dumps(base,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
d=r/'allocation-short';d.mkdir()
shutil.copyfile(r.parent/'regex-boundaries-r422/allocation-short/Allocation.csproj',d/'Allocation.csproj')
source=(r.parent/'regex-boundaries-r422/allocation-short/Program.cs').read_text(encoding='utf-8')
source=source.replace('        void Run()','        long peakExecutionMemoryBytes = 0;\n        void Run()')
needle='''                var files = check.Invoke(host, null);'''
assert needle in source
source=source.replace(needle,'''                peakExecutionMemoryBytes = Math.Max(peakExecutionMemoryBytes, result.PeakExecutionMemoryBytes);
'''+needle)
source=source.replace('allocatedBytesPerInvocation = batches, sharedBudgetBaselineRestored',
                      'allocatedBytesPerInvocation = batches, peakExecutionMemoryBytes, sharedBudgetBaselineRestored')
(d/'Program.cs').write_text(source,encoding='utf-8',newline='\n')
(d/'catalog.json').write_bytes((r/'catalog.json').read_bytes())
s=(r.parent/'finally-prefix-r423/measure-allocation.py').read_text(encoding='utf-8')
s=s.replace("changePercent=100*(b/a-1)", "changePercent=100*(b/a-1), referencePeakExecutionBytes=x['peakExecutionMemoryBytes'], candidatePeakExecutionBytes=next(v for v in data['candidate']['rows']if v['id']==x['id'])['peakExecutionMemoryBytes']")
s=s.replace('Earlier baseline screen did not compare file hashes and remains separate.', 'Includes conservative governor execution peaks, not physical heap/RSS.')
(r/'measure-allocation.py').write_text(s,encoding='utf-8',newline='\n')
print('Existing complete report/invoice/JSON catalog and short allocation driver prepared, including conservative execution peaks.')
