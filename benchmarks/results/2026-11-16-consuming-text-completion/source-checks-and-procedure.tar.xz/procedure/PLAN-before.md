# Lokad.Lython 0.11.0

Updated 2026-11-16 UTC. Git-ignored; never force-add. Publication/tagging postponed.
Deliver coherent simplification and substantial complete-script improvements,
including newly generated scripts compiled and run once. Another isolated experiment
does not complete that objective. Current contracts belong in `docs/`; experimental
conditions, rejected designs and raw evidence live in [EXPERIMENTS](benchmarks/EXPERIMENTS.md).

## Actual delivery status

| State | Source and evidence |
| --- | --- |
| Committed and fully qualified | **e6500781 / eee74a10**, native work before finally. [Full43787325151](benchmarks/results/2026-11-16-finally-prefix/delivery/README.md) GREEN: Windows/Ubuntu actual.NET11/10 each4,777internal/17,912public ordinary, original13/406stress and installed Release consumers.16summaries/591inputs verified. Receipt committed/pushed3b250555; terminal cached, never requery. |
| Committed, focused qualification complete | **a2d20928 / 9d26d408**, one compiler instruction store.151internal/1,011public eachactual11/10;590committed inputs verified. [Source pair](benchmarks/results/2026-11-16-compiler-instruction-store/README.md). Full43789371043active; ordinary/stress/package outcome still pending. No active runtime prototype. |
| Latest external baseline | **R425/B821**, a2d20928 versusCPython3.13.16. [Manifest/report phases](benchmarks/results/2026-11-16-compiler-cpython-checkpoint/README.md): four jobs136.664s, all image/golden/quiet/budget/join/archive gates. Manifest compile1.22–1.28×/fresh1.085–1.092×; method report warm1.59–1.65×/f-string1.18–1.20×. Manifest control4.89%, report IQR≤4.50%; diagnostic, not causal source gain. Evidence committed/pushed3b250555. |
| Earlier representative phases | [B816](benchmarks/results/2026-11-16-patch-cpython-checkpoint/README.md) atc023042d/0393331a: patch warm0.817–0.825×/fresh0.797–0.820×, invoice warm1.11–1.15×CPython. Report compilation/fresh at58eeea6f, other text/JSON/search/CSV phases retain their named older revisions in [BENCHMARKS](docs/BENCHMARKS.md), not today's HEAD. |
| Independent adapter prototype | [R409](benchmarks/results/2026-11-15-regex-range-prototype/README.md): immutable development0.5 and normal released0.4 each pass361public regex checks per actual11/10. Core contract, adapter semantics and backend performance are separate. Normal pin unchanged. |

Warm includes mediated RAM I/O, complete goldens and prior-result cleanup; excludes
compilation/startup, reset/protocol and final cache teardown. Compilation includes
compiled-owner disposal; fresh includes compilation and one execution. Separate
medians are not additive. Wider CPU includes reset/protocol. Startup, pending-I/O,
contention, heap/RSS and embedding-tail costs remain unmeasured.

## Immediate delivery

R423full receipt and R425baseline evidence/guide committed/pushed3b250555. No
repeat of completed checks or unchanged producer qualification; terminals cached.

1. Finish R424full43789371043: Windows/Ubuntu actual11/10, original stress and
   installed Release consumers; verify all16summaries and590committed source inputs.
   Keep development independent of CI; use focused Release checks for new changes.
2. Select the next complete runtime redesign from demonstrated remaining costs.
   Method-report warm still has a material gap; captured-helper/search evidence is
   older and diagnostic. Existing R385/R420 call captures overlap useful work and do
   not isolate a dominant removable ABI stage. Do not repeat an unchanged capture,
   revive a slower controller, or add another format-only special case. A new source
   gate must name an entire representation/transport/dispatch route to remove, the
   actual complete workload and a bounded acceptance/measurement decision. If no
   such replacement is supported, record the precise uncertainty and investigate a
   different useful workload; no speculative implementation or claim of irreducibility.

R423replaces whole-function finally exclusion with the earliest physical cleanup
frontier. Returns/abrupt exits/tuple completion/faults transfer exact PC/live values
to the existing funded frame. Nested cleanup, exceptions, aliases, cursor disposal,
true suspension, cancellation/refusal and joined refunds stay. Frame admission can
follow prefix effects; no transactional rollback/tiny-threshold promise. Complete
protected invoice: allocation−2.91%, warm elapsed4.8–6.2%lower with CPU support;
fresh inconclusive and adverse/moving controls up to3.5%remain accepted debt.

R424deletes BasicBlockBuilder/ExecutableBasicBlock and normalized/shortened arrays.
Single-use block lists reach final linearization; code/target/span/region/slot/call
metadata agree on four complete sources. Compilation allocation3.35–4.74%lower;
generated-normalizer fresh3.88%lower. Generated compile elapsed1.3–3.8%lower with
CPU support; manifest/fresh inconclusive including adverse timings. The generated
case is a diagnostic. Favorable unchanged invoice timing is not a source gain.
Retained for deletion/allocation with that debt; no substantial CPU claim.

## Substantial redesign roadmap

| Area / hypothesis | Work/storage to eliminate and workloads | Acceptance and stopping criteria |
| --- | --- | --- |
| **A1. Complete calls, frames and operand transport.** A remaining transition may be costly. | Remove an entire argument/activation/retirement representation in captured text, protected search, invoice or report helpers. Start from existing final slots, direct binding/receivers, prepared metadata, deferred contexts and shared completed kernels. | Preserve zero-allocation native entry where applicable, live defaults, identity/closures, caller/exception state, evaluation/errors, real suspension/generators, managed stack and funded cleanup. Durable storage before callbacks start. R403controller/R411tail borrowing measured slower and were deleted. No wrapper, relocated state or another arena without a changed design/evidence. No next prototype selected yet. |
| **A2. Record/collection construction and scalar transport.** Remaining row intermediates may matter. | CSV already adopts funded private rows into shared-key dictionaries; final long-field payloads and iterative JSON construction are delivered. Current source gate finds no duplicate row/value pipeline to replace. | Historical bulk CSV6–8%opportunity is integrated, not automatically promoted again. Preserve duplicate/custom/short/wide rows, mutation/aliases, exact overflow and replacement overlap. A new design needs a changed storage argument and useful complete script. Universal scalar slots widen reference-only rows. Stop current gate; remain open to changed evidence. |
| **A3. Bulk text/conversions.** Another full pipeline may remain. | Casing, final-output sinks, reusable layouts and one runtime method-format operation are delivered. A selected change must remove a real remaining representation across useful scripts. | Preserve Unicode expansion/context, formats/hooks, current tokens, true suspension and escaped aliases. No continuing series of format special cases. Require allocation and warm/fresh timing with unchanged controls; stop with retain/refine/remove and debt explicit. |
| **A4. Frontend construction.** Repeated facts/representations may matter for newly generated scripts. | R413prepared stores and R424single instruction store remove concrete duplication. Parsing, lexical validity, abstract/name analysis and lazy annotation flow have distinct outputs. | Preserve diagnostics/spans, binding/nonlocal/class-cell facts, lazy scopes and callback inspection. Mixed R412phase samples do not isolate a dominant removable pass. Select another frontend redesign only with a concrete compile-heavy script, useful phase evidence and an entire displaced stage; no general traversal/index framework. |

For every selected redesign record: hypothesis, eliminated work/storage, affected
complete scripts, semantic gates, removed implementation and bounded before/after
controls. Temporary performance setbacks may serve a justified redesign; name its
completion milestone and decide the remaining regression debt. Delete displaced code
and mechanism-only tests; preserve independent semantic/side-effect/cleanup coverage.

## Independent regex deliverable

Core owns Python-specific native UTF-8 subjects/names, byte captures, scalar positions,
original-subject windows, effective flags, explicit owners and current tokens through
frontend/runtime/imports. Native fnmatch/glob and cooperating-provider in-flight
cancellation/joined cleanup are delivered; core has no Utf8Regex dependency.
Missing producer APIs defer only affected final adapter qualification.

- Build on R409development producer/adapter-local bridges. Detailed text projection,
  per-advance registration/closure transport and program disposal are separately
  measured. Keep inline/effective-flag controls from717f0747; Verbose parsing and
  reported flags are distinct. No silent dialect fallback or semantic weakening.
- Normal adapter0.4 remains. Checked2026-11-16: NuGet still0.4; local immutable0.5
  assets equal R409, PythonRe source differs only in README. No unchanged retest.
  Candidate dcfe880a/acceptance c5e02a27 precisely lacks native UTF-8 group-name
  enumeration, preparation with current token and per-match result-stage allowance.
  Cursor/advance tokens, working allowance, receipts and disposal exist. Keep bridges
  rather than impose hidden no-reentry/nonthrowing-refund host restrictions.
- Qualify actual released immutable assets when capabilities change: semantics,
  errors/flags/windows, real in-flight cancellation, refusal/unwind, retained users,
  budget reuse and one affected performance pair. Contract tests, adapter semantics
  and actual backend performance stay separate. Development remains independent.

## Completed milestones and evidence limits

Shared compiler-fact/callback correction61237f58 and native helper returns8f07764a
are fully qualified; returns establish19–20%less allocation, original elapsed gains
remain diagnostic. Direct UTF8 formatting/storage establishes8.67%less allocation;
[controlled confirmation](benchmarks/results/2026-11-02-formatting-confirmation/README.md)
supports5–8%lower report elapsed/CPU; original adverse15.125ms remains unexplained.
No repeated qualification is pending for these changes.

R395–398tuple transport, R405arithmetic, R408casing, R413prepared stores, R416final
sinks, R418layouts, R419shared executor and R422known Unicode scalar boundaries are
fully qualified. Their source-pair allocation/CPU distinctions, moving controls,
earlier-denial/retention tradeoffs and accepted historical debts remain in history.
Separate source pairs cannot be added. R422uses known endpoints without a map/cache
or new owner/backend; allocation flat+16B and original adverse controls remain.
[Roadmap review](benchmarks/results/2026-11-15-runtime-roadmap-review/README.md) preserves
earlier regression debt; later results do not establish recovery.

## Iteration and lasting contracts

Timeouts, unstable unchanged controls and inconclusive results establish uncertainty,
not a failed design or permanent ban. Permit bounded confirmation/refinement and
measurement correction when justified; retain adverse results and failed conditions.
Size runs for usable observations on the existing quiet VM. Percentages inform
decisions rather than veto them. Separate deletion, allocation and measured CPU.
Focused Release semantics/cancellation/ownership during iteration; batch full actual
11/10Windows/Ubuntu, original stress and installed Release consumers at meaningful
retained checkpoints. No repeated unchanged qualification merely to show activity.

[AGENTS](AGENTS.md) binds fully managed safety and validated managed stack admission;
host capabilities/contained paths; checked bounds/bounded I/O. Host token governs
time: no fuel/quotas/watchdogs. Shared admission funds capacity/replacement peaks,
results/aliases/caches and pending users. First refusal is terminal, cleanup awaited;
no hidden allowance, retries, tracing, weak reclamation, forced GC or abandoned work.
Long streams use bounded host-driven commands. Freeze copies/full hashes; force
builds after preserved-timestamp restoration. UTF-8 text. Persist/verify VM evidence
under lease before RAM teardown; join users before refund. Retire only exact committed
archived replicas with fresh ownership/path/hash/all-alias proof; preserve current
images/toolchains and254/252MiB floors. Cache terminal results; only core is packaged.
