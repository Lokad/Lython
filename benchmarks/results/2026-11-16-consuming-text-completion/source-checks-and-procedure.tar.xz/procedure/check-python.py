from pathlib import Path
import datetime,json,re,subprocess,tempfile,textwrap
r=Path(__file__).parent
text=Path('tests/Lokad.Lython.PublicApi.Tests/TerminalTextOwnershipTests.cs').read_text(encoding='utf-8')
source=textwrap.dedent(text.split('private const string Source = """\n',1)[1].split('        """;',1)[0])
source=source.replace('return original, changed, joined,', 'result = original, changed, joined,')
with tempfile.TemporaryDirectory(prefix='lython-terminal-text-python-') as d:
    Path(d,'input.txt').write_text('ready',encoding='utf-8')
    s=source+"\nexpected = ('Aβ\\tß\\n'*8, 'ω   ss\\n'*8, '|'.join(['ω   ss\\n'*8,'00:ff',\"b'\\\\x00\\\\xff'\",'B\\tß\\n'*8]), '-00012')\nassert result == expected, (result, expected)\nprint('matched all returned values')\n"
    p=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',s],cwd=d,capture_output=True,text=True,encoding='utf-8',timeout=30)
    assert p.returncode==0,p.stderr
(r/'cpython-semantics.json').write_text(json.dumps(dict(version='CPython3.13.2',dateUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    matched=True,source=source,output=p.stdout,semantics='Unicode replace/expandtabs/casefold/translate/join, byte hex/repr and sign-aware zfill; independently expected returned aliases.'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(p.stdout.strip())
