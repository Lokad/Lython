from pathlib import Path
import hashlib,json,shutil,subprocess

r=Path(__file__).parent
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');(r/'PLAN-before.md').write_text(s,encoding='utf-8',newline='\n')
needle='2. Select the next complete runtime redesign from demonstrated remaining costs.'
assert needle in s
a=s.index(needle);b=s.index('\nR423replaces',a)
s=s[:a]+'''2. **R426selected: consume completed text builders (A3).** Source identifies13
   terminal call sites which copy completed UTF-8 storage and allocate a temporary
   reservation before immediately releasing the builder. Use the existing consuming
   finalizer for join/replace/translation/casefold/padding/tabs/hex/bytes representation,
   method formatting, HTML and match expansion. Remove that final-copy/preflight/
   transaction stage from all13, with no new builder, cache, admission policy or API.
   JSON iterencode is a genuine reusable-buffer snapshot consumer and keeps its
   existing path; its presence is not dormant compatibility scaffolding.

   Hypothesis: fewer final arrays/copies/temporary leases improve complete report
   and invoice construction; current R420storage samples include useful work and
   do not establish an isolated removable CPU share. Use complete method-report
   warm/fresh, invoice warm and unchanged JSON helper control; a short local
   allocation/peak-accounting comparison precedes one bounded quiet source pair.
   Do not call this a general interpreter gain or predict a percentage.

   Gates: Python text/Unicode/error behavior; stable escaped aliases; actual async
   formatter/host callbacks and joined cancellation; terminal refused admission;
   retained backing capacity/metadata, result projection and budget reuse. Consume
   only after all native users finish; failure leaves input funded until cleanup.
   Returned text retains full builder capacity (including unused tail) rather than
   an exact copy. Conservative retention/earlier denial are explicit tradeoffs;
   final-copy overlap disappears, not its pre-existing major-storage preflight.
   Keep shared allowance resize/refund semantics unchanged: no credit cache, lease
   batching, per-object tracking or delayed refunds. The external integration brief
   requires allowance reuse when explicit ownership ends.

   Stop with retain/refine/remove after correctness and one controlled comparison,
   preserving adverse controls. Broader A1/A2/A4questions remain; no new controller,
   arena or format-only special case. Continue independent of current R424CI.
''' +s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
files=['Runtime/LythonRuntime.BytesMembers.cs','Runtime/LythonRuntime.CsvObjects.cs',
       'Runtime/LythonRuntime.Difflib.Html.cs','Runtime/LythonRuntime.StringMembers.Formatting.cs',
       'Runtime/LythonRuntime.RegexReplacement.cs','Runtime/LythonRuntime.StringMembers.AffixFormat.cs',
       'Runtime/PyBytes.cs','Runtime/Text/PyString.cs','Runtime/Text/PyStringOps.cs','Runtime/Text/PyStringOps.Fold.cs']
(r/'original').mkdir();changes=[]
for n in files:
    p=Path('src/Lokad.Lython')/n;t=p.read_text(encoding='utf-8')
    backup=r/'original'/n;backup.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,backup)
    count=t.count('builder.ToPyString()')+t.count('result.ToPyString()')+t.count('output.ToPyString()')
    assert count>0
    t=t.replace('builder.ToPyString()','builder.ToPyStringAndRelease()').replace('result.ToPyString()','result.ToPyStringAndRelease()').replace('output.ToPyString()','output.ToPyStringAndRelease()')
    # IPyStringLike conversion is unrelated to builder storage.
    p.write_text(t,encoding='utf-8',newline='\n');changes.append(dict(path=str(p),terminalCopiesRemoved=count))
assert sum(c['terminalCopiesRemoved'] for c in changes)==13
(r/'selection.json').write_text(json.dumps(dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    baselineCore='9d26d408ac591aba042f92106167a7cc1df8148b6fc26554f65fa667af5cb5f0',
    changes=changes,contract='Use existing consuming finalizer for terminal construction. Keep actual reusable JSON snapshots, exact budget resize/refund semantics, original capacity ownership and metadata admission. No new memory infrastructure or public API.'),indent=2)+'\n',encoding='utf-8',newline='\n')
print('PLAN selected R426; thirteen terminal copies/temporary reservations removed across ten existing paths.')
