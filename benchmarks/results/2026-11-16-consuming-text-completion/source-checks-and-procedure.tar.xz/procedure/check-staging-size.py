from pathlib import Path
import json
r=Path(__file__).parent
groups=json.loads((r/'retirement-groups.json').read_text(encoding='utf-8'))
v=groups[0]
core=(r/'frozen/candidate/Lokad.Lython.dll').stat().st_size
catalog=(r/'catalog.json').stat().st_size
result=dict(freeAtInspection=v['freeBytes'],recoverable=sum(x['bytes'] for x in groups),newCore=core,catalog=catalog,
    provisionalAfter=v['freeBytes']+sum(x['bytes'] for x in groups)-core-catalog-30_000,
    unchangedStageFloor=254*1024*1024)
p=r/'initial-staging-projection.json'
assert not p.exists()
p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(result)
