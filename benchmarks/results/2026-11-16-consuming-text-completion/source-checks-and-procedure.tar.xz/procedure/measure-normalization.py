from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess,tempfile,time
r=Path(__file__).parent;d=r/'normalization-allocation';identity=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));sdk='C:/Users/JoannesVermorel/.dotnet11';env=dict(os.environ);env['DOTNET_ROOT']=sdk;data={};images={};start=time.monotonic()
with tempfile.TemporaryDirectory(prefix='lython-format-allocation-')as directory:
 env['TEMP']=directory;env['TMP']=directory
 for role in ['reference','candidate']:
  image=d/role;shutil.copytree(r/'frozen'/role,image)
  for n,h in identity['images'][role].items():assert hashlib.sha256((image/n).read_bytes()).hexdigest()==h,n
  for p in(d/'bin/Release/net11.0').glob('ValidatedAllocation.*'):shutil.copyfile(p,image/p.name)
  images[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in image.iterdir()if p.is_file()}
  output=d/(role+'.json');assert not output.exists()
  with(d/(role+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run([sdk+'/dotnet.exe',str(image/'ValidatedAllocation.dll'),str(image),str(d/'catalog.json'),str(output)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
  assert p.returncode==0,(d/(role+'.log')).read_text(encoding='utf-8')[-1500:];data[role]=json.loads(output.read_text(encoding='utf-8'));print(role,'complete',flush=True)
 assert not list(Path(directory).iterdir())
rows=[]
for x in data['reference']['rows']:
 a=statistics.median(x['allocatedBytesPerInvocation']);b=statistics.median(next(v for v in data['candidate']['rows']if v['id']==x['id'])['allocatedBytesPerInvocation']);rows.append(dict(case=x['id'],referenceBytes=a,candidateBytes=b,changePercent=100*(b/a-1), referencePeakExecutionBytes=x['peakExecutionMemoryBytes'], candidatePeakExecutionBytes=next(v for v in data['candidate']['rows']if v['id']==x['id'])['peakExecutionMemoryBytes']))
(d/'image-hashes.json').write_text(json.dumps(images,indent=2)+'\n',encoding='utf-8',newline='\n');(r/'normalization-allocation-summary.json').write_text(json.dumps(dict(rows=rows,complete=True,elapsedSeconds=time.monotonic()-start,allOutputAndFileGoldensPassed=True,budgetBaselineAndCleanupPassed=True,CPUorElapsedClaim=False,boundary='Local whole warm jobs with reset/mediated I/O/full stdout and file hashing/result cleanup; compilation/startup excluded. Natural-GC whole-process counters. Includes conservative governor execution peaks, not physical heap/RSS.'),indent=2)+'\n',encoding='utf-8',newline='\n');print(rows)
