from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
r=Path(__file__).parent;base=r.parent;f=r/'frozen';f.mkdir();v=json.loads((base/'frozen/identity.json').read_text(encoding='utf-8'))
assert hashlib.sha256(Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll').read_bytes()).hexdigest()==v['images']['candidate']['Lokad.Lython.dll']
paths=list(v['sources'])+['tests/Lokad.Lython.Tests/StringJoinAccountingTests.cs','tests/Lokad.Lython.Tests/StringJoinCleanupTests.cs','tests/Lokad.Lython.Tests/RegexExpansionOwnershipTests.cs','tests/Lokad.Lython.PublicApi.Tests/JsonSeparatorOwnershipTests.cs']
assert len(set(paths))==597
v.update(sourceSnapshotCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),prototype=False,testOnlyCorrections=True,sources={n:hashlib.sha256(Path(n).read_bytes()).hexdigest()for n in paths})
(f/'identity.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz')as a:
 for n in paths:a.add(n,arcname=n)
 a.add(r/'checks',arcname='checks')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
checks=[dict(file=p.name,**E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib)for p in (r/'checks').glob('*.trx')]
assert sorted(int(x['passed'])for x in checks)==[8,8,13,13,100,100,2555,2555] and all(x['failed']=='0'for x in checks)
out=Path('benchmarks/results/2026-11-16-consuming-text-completion/qualification-corrections');out.mkdir()
for n in ['identity.json','sources-and-checks.tar.xz']:shutil.copyfile(f/n,out/n)
(out/'checks.json').write_text(json.dumps(dict(testOnly=True,unchangedCoreSHA256=v['images']['candidate']['Lokad.Lython.dll'],checks=checks,fullQualificationPending=True),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'original-failure-and-correction.tar.xz','w:xz')as a:
 for n in ['ci-terminal.json','ci-logs.zip','failure-excerpts.json','source-proof.json','delivery-candidate.json']:a.add(base/'delivery'/n,arcname='original-delivery/'+n)
 for p in r.iterdir():
  if p.is_file():a.add(p,arcname='correction/'+p.name)
 a.add(base/'check-corrections.ps1',arcname='correction/check-corrections.ps1')
(out/'README.md').write_text('''# Test-only qualification corrections

Initial full CI **43797131423 / 116fe6e0** failed on both platforms at .NET11:
six internal failures, 4,771 passes. Ubuntu public: 17,914 passes. Windows public:
17,913 passes and one process-allocation assertion failure. .NET10, stress and
installed package stages were not reached. Full original logs are retained.

Three tests enforced the removed final-copy/exact-charge architecture. They now
check funded retained capacity, actual metadata/output refusal with live operands,
first terminal attribution and complete refunds. Removed private-helper reflection
and growth-specific assertions; primitive replacement-overlap coverage remains.

The Windows JSON separator test observed 168,440 process-allocated bytes against
a 128 KiB bound. It now warms and compares the same small/large constructor paths,
testing size-dependent copying against the unchanged 128 KiB bound. This avoids
charging fixed startup work to separator size; no conclusion about the original
extra allocation's source is inferred. Nonparallel GC collection remains.

Focused Release: corrected classes 13 internal / 8 public, broadened affected set
100 internal / 2,555 public, each actual .NET11/10. All pass. Production core stays
**810dafdd**; only four tests changed. Original timing/source images remain immutable.
597 production/build/test inputs frozen for the new delivery; no retiming needed.
Full cross-platform/stress/package qualification remains pending. No memory bound,
timeout, runtime policy or containment contract was relaxed.
''',encoding='utf-8',newline='\n')
s=(base/'start-delivery.py').read_text(encoding='utf-8').replace("d=r/'delivery'","d=r/'delivery-corrections'").replace("r/'frozen/","r/'qualification-corrections/frozen/").replace('==593','==597').replace('changedTestInputs=3','changedTestInputs=7').replace('593frozen','597frozen')
(base/'start-corrected-delivery.py').write_text(s,encoding='utf-8',newline='\n')
print('597 inputs, four test-only corrections and original failed CI archived; core unchanged.')
