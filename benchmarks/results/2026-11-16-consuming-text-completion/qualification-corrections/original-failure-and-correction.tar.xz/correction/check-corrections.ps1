$ErrorActionPreference='Stop'
$env:DOTNET_ROOT='C:/Users/JoannesVermorel/.dotnet11'
$env:DOTNET_ROOT_X64=$env:DOTNET_ROOT
$env:PATH=$env:DOTNET_ROOT+';'+$env:PATH
$taskRoot=Join-Path $PSScriptRoot 'qualification-corrections'
$internalFilter='Category!=Stress&(FullyQualifiedName~GovernedOutput|FullyQualifiedName~ByteBuilder|FullyQualifiedName~PyString|FullyQualifiedName~DirectStringJoin|FullyQualifiedName~FormatStorage|FullyQualifiedName~FormatProtocolBoundary|FullyQualifiedName~RuntimeStorage|FullyQualifiedName~DynamicFormattedOwnership|FullyQualifiedName~StringJoinAccounting|FullyQualifiedName~StringJoinCleanup|FullyQualifiedName~RegexExpansionOwnership)'
$publicFilter='Category!=Stress&(FullyQualifiedName~Bytes|FullyQualifiedName~String|FullyQualifiedName~Format|FullyQualifiedName~Difflib|FullyQualifiedName~TerminalText|FullyQualifiedName~RegexRewrite|FullyQualifiedName~RegexAdapterSemantics|FullyQualifiedName~RegexProviderContract|FullyQualifiedName~Unicode|FullyQualifiedName~JsonSeparatorOwnership)'
foreach ($taskFramework in @('net11.0','net10.0')) {
    foreach ($taskAssembly in @('internal','public')) {
        $taskProject=if($taskAssembly -eq 'internal') {'tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj'} else {'tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj'}
        $taskFilter=if($taskAssembly -eq 'internal') {$internalFilter} else {$publicFilter}
        $taskName=$taskAssembly+$taskFramework.Replace('net','').Replace('.0','')
        & "$env:DOTNET_ROOT/dotnet.exe" test $taskProject -c Release -f $taskFramework --no-build --no-restore --filter $taskFilter --logger "trx;LogFileName=r426-$taskName.trx" --results-directory "$taskRoot/checks" *> "$taskRoot/$taskName.log"
        if($LASTEXITCODE -ne 0) { Get-Content -LiteralPath "$taskRoot/$taskName.log" -Encoding utf8 -Tail 55; exit $LASTEXITCODE }
        Get-Content -LiteralPath "$taskRoot/$taskName.log" -Encoding utf8 -Tail 2
    }
}

