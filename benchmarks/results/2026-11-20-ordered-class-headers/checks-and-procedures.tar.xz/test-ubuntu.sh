set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/ordered-class-headers
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=../../agent-notes/review-20261031/ordered-class-headers
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Class|FullyQualifiedName~Dataclass|FullyQualifiedName~TypeParameter|FullyQualifiedName~Annotation|FullyQualifiedName~CompileCancellation|FullyQualifiedName~CompilationAccounting|FullyQualifiedName~Import)&Category!=Stress' 2>&1 | tee "$lab/ubuntu-public.log"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Class|FullyQualifiedName~StaticFact|FullyQualifiedName~Lowering|FullyQualifiedName~StatementSyntaxTraversal)&Category!=Stress' 2>&1 | tee "$lab/ubuntu-whitebox.log"
