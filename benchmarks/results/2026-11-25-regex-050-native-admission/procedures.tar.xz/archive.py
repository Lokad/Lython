from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
out=lab.parents[3]/'benchmarks/results/2026-11-25-regex-050-native-admission'
data=json.loads((lab/'verification.json').read_text(encoding='utf-8'))
assert data['producerSource'].startswith('61228b20f') and data['lythonSource'].startswith('d28266d7b')
assert [c['passed'] for c in data['checks']]==[159,159]
assert hashlib.sha256((lab/'adapter-bridge.patch').read_bytes()).hexdigest().upper()==data['bridgePatchSHA256']
out.mkdir(exist_ok=True)
shutil.copyfile(lab/'verification.json',out/'verification.json')
names=['adapter-bridge.patch','verify.py','archive.py','test-ubuntu.sh','windows-restore.log','ubuntu-restore.log',
    'windows-net11-initial.log','ubuntu-net10-initial.log','windows-net11.log','ubuntu-net10.log']
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name in names:archive.add(lab/name,arcname=name,recursive=False)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert all(archive.extractfile(name).read()==(lab/name).read_bytes() for name in names)
