from pathlib import Path
import copy
import hashlib
import json
import subprocess

lab=Path(__file__).resolve().parent
donor=lab.parent/'prepared-mutation-calls'
cases_from=lab.parent/'compiled-definition-keys'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
cases=load(cases_from/'catalog.json')
ordinary='scripts.annotated-rule-closures'
nested=ordinary+'.nested-factories'
observed=ordinary+'.observed'
invoice='scripts.csv-invoice.large'
first='scripts.annotated-rule-closure.first-use'
original={case['id']:case for case in cases['cases']}
original[first]=next(case for case in load(lab.parent/'grouped-definition-admission-r607/catalog.json')['cases'] if case['id']==first)
cases['cases']=[original[ordinary],original[invoice]]
python=Path('C:/Python313/python.exe')
for key in (ordinary,nested,observed,first):
    case=copy.deepcopy(original[key])
    case['id']=key+'.postponed'
    case['source']='from __future__ import annotations\n'+case['source']
    data=case['source'].encode('utf8')
    case.update(sourceUtf8Bytes=len(data),sourceSha256=hashlib.sha256(data).hexdigest())
    result=subprocess.run([python,'-I','-X','utf8','-'],input=data,stdout=subprocess.PIPE,check=True).stdout.replace(b'\r\n',b'\n')
    assert result.decode('utf8')==case['expectedOutput'],case['id']
    cases['cases'].append(case)
(lab/'catalog.json').write_text(json.dumps(cases,indent=2,ensure_ascii=False)+'\n',encoding='utf8',newline='\n')

code=(donor/'freeze-and-verify.py').read_text(encoding='utf8')
code=code.replace("previous=lab.parent/'factory-cpython-b1151'","previous=lab.parent/'prepared-mutation-calls'")
code=code.replace("trial=repo/'.git/agent-worktrees/prepared-mutation-calls'","trial=repo/'.git/agent-worktrees/prepared-postponed-text'")
code=code.replace("ref=git('rev-parse','0d74b5b18')","ref=git('rev-parse','e025a7f1c')")
code=code.replace("manifest=load(previous/'identity.json')\nassert not git('diff','--name-only',manifest['sourceRevision'],ref,'--',",
    "manifest=load(previous/'quiet/identity.json')\nprior_source=load(previous/'frozen-identity.json')['candidateCommit']\nassert not git('diff','--name-only',prior_source,ref,'--','src','tests','Directory.Build.props','Directory.Packages.props','global.json',")
assert "prior_source=load" in code and "== 6" in code and "if name==core and role=='candidate':" in code
(lab/'freeze-and-verify.py').write_text(code,encoding='utf8',newline='\n')
