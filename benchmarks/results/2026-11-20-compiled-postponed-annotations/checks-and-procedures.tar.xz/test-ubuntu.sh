set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/prepared-postponed-text
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=../../agent-notes/review-20261031/prepared-postponed-text
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 2>&1 | tee "$lab/ubuntu-probe-build.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Annotation|FullyQualifiedName~TypeParameter|FullyQualifiedName~CompilationAccounting|FullyQualifiedName~CompilerCancellation|FullyQualifiedName~Unicode|FullyQualifiedName~FunctionDefault|FullyQualifiedName~Import)&Category!=Stress' 2>&1 | tee "$lab/ubuntu-public.log"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~StaticFact|FullyQualifiedName~Annotation|FullyQualifiedName~PyString|FullyQualifiedName~CompileCancellation|FullyQualifiedName~Borrowed)&Category!=Stress' 2>&1 | tee "$lab/ubuntu-whitebox.log"
