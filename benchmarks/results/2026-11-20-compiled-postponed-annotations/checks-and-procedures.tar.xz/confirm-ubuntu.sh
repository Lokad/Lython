set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/prepared-postponed-text
export DOTNET_ROOT="$HOME/.dotnet"
shim=$(mktemp -d -t lython-postponed-python.XXXXXXXX)
trap 'unlink "$shim/python"; rmdir "$shim"' EXIT
ln -s "$HOME/.local/bin/python3.13" "$shim/python"
export PATH="$shim:$DOTNET_ROOT:$PATH"
python --version
lab=../../agent-notes/review-20261031/prepared-postponed-text
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --no-build --filter '(FullyQualifiedName~Annotation|FullyQualifiedName~TypeParameter|FullyQualifiedName~CompilationAccounting|FullyQualifiedName~CompilerCancellation|FullyQualifiedName~Unicode|FullyQualifiedName~FunctionDefault|FullyQualifiedName~Import)&Category!=Stress' 2>&1 | tee "$lab/ubuntu-public-confirmation.log"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~StaticFact|FullyQualifiedName~Annotation|FullyQualifiedName~PyString|FullyQualifiedName~CompileCancellation|FullyQualifiedName~Borrowed)&Category!=Stress' 2>&1 | tee "$lab/ubuntu-whitebox.log"
