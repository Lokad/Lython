from pathlib import Path
import json, subprocess
r=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
code='''from pathlib import Path
import fcntl,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 rows=subprocess.check_output(['du','-x','-B1','--max-depth=1',str(base)],text=True).splitlines()
 rows=sorted([(int(row.split('\\t')[0]),row.split('\\t',1)[1]) for row in rows],reverse=True)[:18]
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,largestOwnedDirectories=rows)))
'''
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True)
assert done.returncode==0,done.stderr
(r/'vm-storage-inventory.json').write_text(done.stdout,encoding='utf-8')
print(done.stdout)
