# R41 source/allocation gate

Current1971487a production, frozeneb6052d0 precommit SourceLink3604f935; existing
worker/host/normal optional0.4 frozen identically. One bounded existing EventPipe
GC-allocation-tick capture, no collect/dump/rundown/root tracing, no runtime change.
Two maintained complete scripts: regex extraction and JSON helper control. Verify
twice, warm128, settle2s, capture256 checked invocations.120s outer owned process
bound, cooperative collector stop, complete goldens/funding/Closed/joins/private
fixture cleanup required. All raw threads/unknowns/lost/adverse evidence retained.
Allocation ticks are statistical type attribution, not exact type counts, CPU,
live heap or proof that a particular call path dominates. Includes full request
reset/I/O/checks/prior-result cleanup; compile/warmup/final teardown excluded.

Source already has receiver-separated string/dict no-argument operations and
selected native methods. ReMatchMembers still creates capturing sync/async delegates
and BoundCallable, whose receiver is then attached separately. Quantify remaining
wrapper/delegate/binding work before selecting a shared method convention. A
selected redesign must remove overlapping direct-marker selection/dispatch for
migrated families; no extra narrow regex shortcut, caller arena or public option.
Preserve receiver snapshots, descriptors, metadata/hash/identity, defaults/keywords,
argument/error/admission order, native proofs, real suspension/current tokens,
managed stack, first refusal, aliases and awaited cleanup. If no material phase is
demonstrated, record missing proof and move boundary; no automatic capture campaign.
