from pathlib import Path
import hashlib, json, os, re, shutil, subprocess
r=Path(__file__).parent
identity=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={name:sha(Path(name)) for name in identity['productionSources']}
changed=[name for name in sources if sources[name]!=identity['productionSources'][name]]
assert {Path(name).as_posix() for name in changed}=={'src/Lokad.Lython/Runtime/LythonRuntime.ReceiverMethods.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs'}, changed
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
filters={
 'Lokad.Lython.Tests':'Category!=Stress&(FullyQualifiedName~MemberCacheAlias|FullyQualifiedName~BoundedStartsWithExecution|FullyQualifiedName~CountedReplaceExecution|FullyQualifiedName~GeneralBoundMethod|FullyQualifiedName~NativeReturn|FullyQualifiedName~DirectString|FullyQualifiedName~DirectDictionary|FullyQualifiedName~InstructionFailureRouting|FullyQualifiedName~CallArgumentEvaluation|FullyQualifiedName~RegexScalarCursorCancellation)',
 'Lokad.Lython.PublicApi.Tests':'Category!=Stress&(FullyQualifiedName~ReceiverMethodSemantics|FullyQualifiedName~RegexMatchIndex|FullyQualifiedName~RegexCaptureMaterialization|FullyQualifiedName~MethodExposure|FullyQualifiedName~DirectStringSplit|FullyQualifiedName~StringReplaceCall|FullyQualifiedName~StringPredicateCall|FullyQualifiedName~NativeCallback|FullyQualifiedName~OrdinaryMethod|FullyQualifiedName~PrefixCall|FullyQualifiedName~CsvWriterowCall|FullyQualifiedName~FileWriteCall|FullyQualifiedName~DictionaryGetCall|FullyQualifiedName~SetDefaultCall|FullyQualifiedName~ListAppendCall|FullyQualifiedName~StringStripCall|FullyQualifiedName~StringUpperCall|FullyQualifiedName~StringLowerCall)'}
checks={};cores={}
for target in ['net11.0','net10.0']:
    with (r/('refined-build-'+target+'.log')).open('w',encoding='utf-8') as log:
        done=subprocess.run([env['DOTNET_HOST_PATH'],'build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f',target,'--no-incremental','--nologo','-v','quiet'],env=env,stdout=log,stderr=subprocess.STDOUT)
    assert done.returncode==0,target
    cores[target]=sha(Path('src/Lokad.Lython/bin/Release',target,'Lokad.Lython.dll'))
    for project,selection in filters.items():
        name='refined-'+project+'-'+target+'.log'
        with (r/name).open('w',encoding='utf-8') as log:
            done=subprocess.run([env['DOTNET_HOST_PATH'],'test',f'tests/{project}/{project}.csproj','-c','Release','-f',target,'--no-dependencies','--filter',selection,'--nologo','-v','quiet'],env=env,stdout=log,stderr=subprocess.STDOUT)
        text=(r/name).read_text(encoding='utf-8-sig');summaries=re.findall(r'Passed!.*',text)
        checks[name]=dict(exitCode=done.returncode,selection=selection,summaries=summaries)
        assert done.returncode==0 and summaries,text[-4000:]
        print(target,project,summaries[-1],flush=True)
    assert cores[target]==sha(Path('src/Lokad.Lython/bin/Release',target,'Lokad.Lython.dll'))
shutil.copytree(r/'images/candidate',r/'images/refined')
shutil.copy2('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'images/refined/Lokad.Lython.dll')
receipt=dict(checks=checks,coreSHA256=cores,productionSources=sources,originalPrototype=identity['candidate'],
    change='Delete one-caller method resolver; select existing no-argument operation without the five new string-name checks. No new specialization/option/dispatch family.',fullDeliveryPending=True)
(r/'refined-focused.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Refined source/images frozen; original B393 source/images/evidence unchanged.',flush=True)
