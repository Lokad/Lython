from pathlib import Path
p = Path('D:/code/Lython/src/Lokad.Lython/Runtime/LythonRuntime.RegexObjects.cs')
s = p.read_text(encoding='utf-8')
a = s.index('        public static bool TryGetMember(ReMatchObject')
b = s.index('        internal static object GetSubscript(', a)
s = s[:a] + '''        private static readonly ReceiverMethod GroupMethod = new(LythonCallableSignature.Create("bound method"),
            static (receiver, arguments, span, context) => GroupCoreAsync((ReMatchObject)receiver, arguments, context, span, false).GetAwaiter().GetResult(),
            static (receiver, arguments, span, context) => GroupCoreAsync((ReMatchObject)receiver, arguments, context, span, true));
        private static readonly ReceiverMethod GetItemMethod = new(MatchGetItemSignature,
            static (receiver, arguments, span, context) => GetSubscript((ReMatchObject)receiver, arguments.Span[0]!, span, context),
            static (receiver, arguments, span, context) => GetSubscriptAsync((ReMatchObject)receiver, arguments.Span[0]!, span, context));
        private static readonly ReceiverMethod GroupsMethod = new(MatchGroupsSignature,
            static (receiver, arguments, span, context) => Groups((ReMatchObject)receiver, arguments.Length == 1 ? arguments.Span[0]! : PyNone.Instance, context, span));
        private static readonly ReceiverMethod GroupDictMethod = new(MatchGroupDictSignature,
            static (receiver, arguments, span, context) => GroupDictionary((ReMatchObject)receiver, arguments.Length == 1 ? arguments.Span[0]! : PyNone.Instance, context, span));
        private static readonly ReceiverMethod ExpandMethod = new(MatchExpandSignature,
            static (receiver, arguments, span, context) =>
            {
                if (!PyStringOps.TryAsString(arguments.Span[0], out var template))
                    throw new LythonRuntimeException("TypeError", "match.expand(template) expects one string argument.", span);
                return ExpandReplacementTemplate((ReMatchObject)receiver, template, context, span);
            });
        private static readonly ReceiverMethod StartMethod = new(MatchStartSignature,
            static (receiver, arguments, span, context) => GetBoundsCoreAsync((ReMatchObject)receiver, arguments, context, span, false).GetAwaiter().GetResult().Start,
            static async (receiver, arguments, span, context) => (await GetBoundsCoreAsync((ReMatchObject)receiver, arguments, context, span, true).ConfigureAwait(false)).Start);
        private static readonly ReceiverMethod EndMethod = new(MatchEndSignature,
            static (receiver, arguments, span, context) => GetBoundsCoreAsync((ReMatchObject)receiver, arguments, context, span, false).GetAwaiter().GetResult().End,
            static async (receiver, arguments, span, context) => (await GetBoundsCoreAsync((ReMatchObject)receiver, arguments, context, span, true).ConfigureAwait(false)).End);
        private static readonly ReceiverMethod SpanMethod = new(MatchSpanSignature,
            static (receiver, arguments, span, context) => BoundsTuple(GetBoundsCoreAsync((ReMatchObject)receiver, arguments, context, span, false).GetAwaiter().GetResult(), context, span),
            static async (receiver, arguments, span, context) => BoundsTuple(await GetBoundsCoreAsync((ReMatchObject)receiver, arguments, context, span, true).ConfigureAwait(false), context, span));

        internal static ReceiverMethod? GetMethod(string name) => name switch
        {
            "group" => GroupMethod,
            "__getitem__" => GetItemMethod,
            "groups" => GroupsMethod,
            "groupdict" => GroupDictMethod,
            "expand" => ExpandMethod,
            "start" => StartMethod,
            "end" => EndMethod,
            "span" => SpanMethod,
            _ => null,
        };

        public static bool TryGetMember(ReMatchObject match, string name, ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
        {
            if (GetMethod(name) is { } method) { value = method.Bind(match); return true; }
            value = name switch
            {
                "__module__" => LythonRuntime.ExceptionTypeValue.SharedModuleLabel("re"),
                "re" => match.Pattern,
                "string" => match.String,
                "pos" => new BigInteger(match.Pos),
                "endpos" => new BigInteger(match.EndPos),
                "lastindex" => LastIndex(match),
                "lastgroup" => LastGroup(match),
                "regs" => Registers(match, context, span),
                _ => MissingMemberValue.Instance,
            };
            return !ReferenceEquals(value, MissingMemberValue.Instance);
        }

        private static object Registers(ReMatchObject match, ExecutionContext context, LythonSourceSpan span)
            => CreateTuple(match.CaptureSlotCount, i =>
                CreateTuple(2, j => new BigInteger(j == 0 ? match.Captures[i].Start : match.Captures[i].End), context, span), context, span);

        private static object Groups(ReMatchObject match, object defaultValue, ExecutionContext context, LythonSourceSpan span)
            => CreateTuple(match.CaptureSlotCount - 1,
                i => ResolveIndexedGroup(match, i + 1, span, context, defaultValue), context, span);

        private static object GroupDictionary(ReMatchObject match, object defaultValue, ExecutionContext context, LythonSourceSpan span)
        {
            var dict = new PyDict(match.NamedGroups.Count, context.MemoryGovernor, span);
            foreach (var entry in match.NamedGroups)
                dict.SetItem(entry.Key, ResolveIndexedGroup(match, entry.Value, span, context, defaultValue));
            return dict;
        }

        private static object BoundsTuple(RegexGroupBounds bounds, ExecutionContext context, LythonSourceSpan span)
            => CreateTuple(2, i => i == 0 ? bounds.Start : bounds.End, context, span);

''' + s[b:]
s = s.replace('GroupCoreAsync(ReMatchObject match, object[] arguments', 'GroupCoreAsync(ReMatchObject match, ReadOnlyMemory<object?> arguments')
s = s.replace('GetBoundsCoreAsync(ReMatchObject match, object[] arguments', 'GetBoundsCoreAsync(ReMatchObject match, ReadOnlyMemory<object?> arguments')
# Remaining accesses are only in those two methods.
a = s.index('        private static async ValueTask<object> GroupCoreAsync')
b = s.index('        private static async ValueTask<object> CoerceGroupKeyAsync', a)
part = s[a:b].replace('arguments[0]', 'arguments.Span[0]!').replace('arguments[i]', 'arguments.Span[i]!')
s = s[:a] + part + s[b:]
p.write_text(s, encoding='utf-8', newline='\n')
print('Regex methods share receiver-free implementations; property resolution no longer captures the match.')
