from pathlib import Path
import collections,datetime,json
root=Path(__file__).parent/'allocation';rows=[]
for label in ['regex','json']:
    folder=root/label;record=json.loads((folder/'record.json').read_text(encoding='utf-8'))
    begin=datetime.datetime.fromisoformat(record['captureBeginUtc']);end=datetime.datetime.fromisoformat(record['captureEndUtc'])
    ticks=[json.loads(line) for line in (folder/'allocation-ticks.jsonl').read_text(encoding='utf-8').splitlines()]
    in_phase=[e for e in ticks if begin<=datetime.datetime.fromisoformat(e['utc'].replace('Z','+00:00'))<=end]
    threads=collections.Counter(e['threadId'] for e in in_phase);dominant=threads.most_common(1)[0][0]
    def group(events):
        types=collections.defaultdict(lambda:dict(ticks=0,sampledBytes=0,sizes=collections.Counter()))
        for e in events:
            row=types[e['type']];row['ticks']+=1;row['sampledBytes']+=e['bytesSinceTick'];row['sizes'][e['objectBytes']]+=1
        total=sum(v['sampledBytes'] for v in types.values())
        return [dict(type=name,ticks=value['ticks'],sampledBytes=value['sampledBytes'],sampledPercent=100*value['sampledBytes']/total,sizes=value['sizes'].most_common()) for name,value in sorted(types.items(),key=lambda kv:kv[1]['sampledBytes'],reverse=True)]
    row=dict(case=record['case'],eventsLost=record['collector']['eventsLost'],allEvents=len(ticks),eventsInPhase=len(in_phase),allocationTicksByThread=threads.most_common(),dominantAllocationThread=dominant,typesAllThreads=group(in_phase),typesDominantThread=group(e for e in in_phase if e['threadId']==dominant))
    rows.append(row)
    print(label,'in phase',len(in_phase),'thread ticks',threads.most_common(),flush=True)
    for r in row['typesAllThreads'][:16]:print(round(r['sampledPercent'],2),r['ticks'],r['type'],r['sizes'][:3],flush=True)
(root/'assessment.json').write_text(json.dumps(dict(rows=rows,limitation='Allocation ticks sample bytes since prior event and attribute them to the threshold-crossing object. Type shares are statistical diagnostics, not exact counts or CPU costs. Includes worker reset/transport/validation/cleanup within marked complete requests. Dominant allocation thread is not proven CPU-dominant.'),indent=2)+'\n',encoding='utf-8')
