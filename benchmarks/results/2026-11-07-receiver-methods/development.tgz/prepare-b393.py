from pathlib import Path
import ast, hashlib, json, shutil, subprocess, tarfile
home=Path(__file__).parent
r=home/'b393'; r.mkdir(exist_ok=True)
assert not any(r.iterdir()), 'Do not overwrite an already prepared or launched comparison.'
old=home.parent/'regex-scalar-cursor-r40/b392'
old_remote='/home/lokad/lython-bench-checks/regex-scalar-cursor-b392-20261107'
remote='/home/lokad/lython-bench-checks/receiver-methods-b393-20261107'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
local=json.loads((home/'diagnostic-identity.json').read_text(encoding='utf-8'))
candidate=home/'images/candidate/Lokad.Lython.dll'
reference=home/'images/before/Lokad.Lython.dll'
assert sha(candidate)==local['candidate'] and sha(reference)==local['before']
prior_aux=json.loads((old/'identity.json').read_text(encoding='utf-8'))['auxiliaryFiles']
aux={name:sha(home/'images/before'/name) for name in prior_aux}
for name,digest in aux.items():
    assert sha(home/'images/candidate'/name)==digest
identity=dict(sourceRevision='1971487a plus R41 shared receiver methods; frozen'+sha(candidate),
    referenceSourceRevision='R40 committed1971487a; frozen'+sha(reference),
    purpose='R41 complete regex extraction with JSON/text/CSV controls; two baseline/two current',
    qualification='Focused276internal/1279public plus10 final regressions on actual.NET11; independent Python outputs, suspended/refused immediate/exposed ownership pass. Actual.NET10 and full delivery pending.',
    coreSHA256=dict(candidate=sha(candidate),control=sha(candidate),reference=sha(reference),**{'reference-control':sha(reference)}),
    auxiliaryFiles=aux,productionSources=local['productionSources'],
    localDiagnostic='Regex allocation -29.47% both APIs, controls essentially flat, admitted peaks identical. Adverse/contradictory desktop elapsed retained, not performance qualification.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copy2(home/'comparison-catalog.json',r/'representative.json')
p=Path('PLAN.md'); plan=p.read_text(encoding='utf-8')
plan=plan.replace('No retained runtime prototype yet.', 'R41 uncommitted prototypebfc2e427 under focused/local qualification; no delivery claim.')
plan=plan.replace('Bound allocation comparison and quiet complete regex extraction plus JSON/text/', 'Local complete jobs establish allocation−29.47%sync/async with essentially flat\n  controls and identical admitted peaks. Contradictory/adverse desktop elapsed\n  (sync regex+31–81%) is retained, not a CPU claim. Quiet B393 comparison pending.\n  Bound allocation comparison and quiet complete regex extraction plus JSON/text/')
plan=plan.replace('No active CI, local test, allocation capture or VM work. R41 baseline source/images\nare frozen before the selected coherent receiver-method prototype.', 'No active CI or local measurement. R41 source/images frozenbfc2e427; focused11\nchecks276internal/1279public plus10final regressions pass. B393 four warm complete\nregex/JSON/text/CSV jobs is the next owned comparison:210s+30s stop+40s margin;\nobserve only after280s. No automatic restart or early service query.')
p.write_text(plan,encoding='utf-8',newline='\n'); shutil.copy2(p,r/'pre-measurement-plan.md')
jobs=[('scripts.regex-capture-summary.large','warm'),('scripts.json-summary-helpers.large','warm'),('scripts.text-summary-helpers.large','warm'),('scripts.csv-summary-functions.large','warm')]
s=(old/'collect.py').read_text(encoding='utf-8').replace(old_remote,remote)
a=s.index('jobs='); b=s.index('\nenv =',a)
s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n'+s[b:]
s=s.replace("purpose='R35 static/dynamic complete report formatting, static fresh, text/CSV controls; two baseline/two current'", "purpose='R41 complete regex extraction and JSON/text/CSV controls; two baseline/two current'")
(r/'collect.py').write_text(s,encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh']:
    s=(old/name).read_text(encoding='utf-8').replace(old_remote,remote).replace("len(r['jobs'])==5", "len(r['jobs'])==4").replace('jobs=5','jobs=4')
    if name=='archive-owned.py':
        s=s.replace("'archive-owned.py']", "'archive-owned.py','receiver-method-source.cs','receiver-method-tests.cs']")
    (r/name).write_text(s,encoding='utf-8',newline='\n')
contract='''R41 separates immutable builtin method implementations/signatures from evaluated receivers. Immediate calls borrow existing operands; first-class values keep normal metadata/binding. Deletes ten opaque Direct* markers, their invocation chain, migrated capturing factories and ten orphaned guard helpers. Keeps measured no-argument/native-helper routes, real dynamic/presence wrappers, managed stack, cancellation, terminal refusal, explicit shared ownership and awaited users. Baseline R40 source1971487a/eb6052d0; candidate frozenbfc2e427 on identical normal optional0.4/worker7cf37ca5/adapter27211dbe/host in both roles and local diagnostics. Initial setup gate caught that local frozen worker/adapter differed from the preceding B392 VM images; explicitly install and hash-check those two auxiliary files identically in both new roles, never mutate prior snapshots. Focused actual11 correctness/cancellation/refusal/alias/reuse pass; actual10/full delivery pending. Local precise regex allocation approximately-29.47% both APIs, controls flat, admitted peaks identical. Desktop clocks conflict including sync regex+31–81%; preserve and do not infer CPU. Four warm complete scripts: regex extraction, JSON/text/CSV helper controls. Quiet AzureF4as_v7/Ubuntu24.04.4/.NET11RC3, normal GC/tiering; two baseline/two current independent processes,5s warmup/role/job,7rotated150ms rounds. Timed public runs include mediated RAM file I/O, guest parsing/loops/methods/aggregation, full output/file checks and prior-result cleanup. Compilation/startup/staging/reset/final cached teardown excluded. Existing wire/backend/fixture/protocol and Ready/core/aux/golden/budget/quiet/Closed/join/archive gates unchanged.210s owner+30s stop+40s margin; observe after280s, no restart on observation timeout. Source deletion/allocation/elapsed are separate conclusions; all adverse/variable data and failed local setups remain. Core architecture independent of producer publication. Full platform/stress/installed consumer qualification batched at retained delivery. Publication postponed; whole-script performance objective remains active.'''
(r/'contract.md').write_text(contract+'\n',encoding='utf-8',newline='\n')
(r/'setup-contract.json').write_text(json.dumps(dict(referenceTemplate=old_remote+'/candidate',roles=['candidate','reference','control','reference-control'],ownerSeconds=210,stopSeconds=30,observeAfterSeconds=280,jobs=jobs),indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'source.patch').write_bytes(subprocess.check_output(['git','-c','core.autocrlf=false','diff','--','src','tests']))
shutil.copy2('src/Lokad.Lython/Runtime/LythonRuntime.ReceiverMethods.cs',r/'receiver-method-source.cs')
shutil.copy2('tests/Lokad.Lython.PublicApi.Tests/ReceiverMethodSemanticsTests.cs',r/'receiver-method-tests.cs')
for name in ['collect.py','archive-owned.py']: ast.parse((r/name).read_text(encoding='utf-8'))
with tarfile.open(r/'payload.tgz','w:gz') as t:
    for name in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh','contract.md','pre-measurement-plan.md','setup-contract.json','source.patch','receiver-method-source.cs','receiver-method-tests.cs']: t.add(r/name,arcname=name)
    t.add(candidate,arcname='current-core.dll')
    for name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Utf8Regex.dll']:
        t.add(home/'images/before'/name,arcname='current-'+name)
s=(old/'launch.py').read_text(encoding='utf-8').replace('regex-scalar-cursor-b392-20261107','receiver-methods-b393-20261107').replace('lython-b392-regex-scalar-cursor-20261107','lython-b393-receiver-methods-20261107').replace('regex-scalar-cursor-b392-launch.py','receiver-methods-b393-launch.py')
s=s.replace("reference=base/'delivery-comparison-b388-20261107/candidate'", "reference=base/'regex-scalar-cursor-b392-20261107/candidate'")
s=s.replace(" (root/'reference/Lokad.Lython.dll').unlink()\n (root/'baseline-core.dll').replace(root/'reference/Lokad.Lython.dll')\n", '')
s=s.replace(" identity=json.loads((root/'identity.json').read_text())", " for name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Utf8Regex.dll']:\n  for role in ['candidate','reference']:\n   (root/role/name).unlink()\n   os.link(root/('current-'+name),root/role/name)\n identity=json.loads((root/'identity.json').read_text())")
s=s.replace('assert len(jobs)==5 ', 'assert len(jobs)==4 ').replace("len(r['jobs'])==5", "len(r['jobs'])==4").replace('allFiveJobsValidated','allFourJobsValidated')
assert 'baseline-core.dll' not in s
ast.parse(s); (r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(home.parent/'regex-scalar-cursor-r40/retrieve-b392.py').read_text(encoding='utf-8')
s=s.replace("parent/'b392'", "parent/'b393'").replace('regex-scalar-cursor-b392-20261107','receiver-methods-b393-20261107').replace('lython-b392-regex-scalar-cursor-20261107','lython-b393-receiver-methods-20261107').replace("['jobs']==5", "['jobs']==4")
(home/'retrieve-b393.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared four owned complete-script jobs; baseline hard-links verified R40, only current core uploaded. No collection started.')
