from pathlib import Path
r=Path(__file__).parent
s=(r/'summarize-b393.py').read_text(encoding='utf-8').replace('b393','b394').replace("'comparison-summary.json'","'refined-comparison-summary.json'")
(r/'summarize-b394.py').write_text(s,encoding='utf-8',newline='\n')
exec(compile(s,str(r/'summarize-b394.py'),'exec'),{'__file__':str(r/'summarize-b394.py')})
