from pathlib import Path
import hashlib, json, shutil
r=Path(__file__).parent
root=Path('D:/code/Lython')
identity=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
for name,digest in identity['productionSources'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
original=r/'initial-source'; original.mkdir()
methods=root/'src/Lokad.Lython/Runtime/LythonRuntime.ReceiverMethods.cs'
loader=root/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs'
for p in [methods,loader]: shutil.copy2(p,original/p.name)
p=root/'PLAN.md'; plan=p.read_text(encoding='utf-8')
a=plan.index('- Local complete jobs establish') if '- Local complete jobs establish' in plan else plan.index('- Bound allocation comparison')
plan=plan[:a]+'''- B393 terminal/archived:4jobs114.27s, all gates, no users/fixtures. Regex
  elapsed−7.56–9.19%; CSV+2.05–3.41%, JSON+0.60–4.64%/variable, text−2.84
  to+1.49% inconclusive. All original data retained; do not infer isolated CPU.
- Selected bounded refinement before retention: new ResolveReceiverMethod has one
  caller and adds a dispatch call; it also checks five string method names before
  reaching the already-shared no-argument path. Inline its selection at the existing
  loader and choose the existing no-argument opcode first. Delete that extra resolver,
  retain definitions/borrowed calls/binder unchanged. Source proves redundant work;
  it does not prove this causes the observed CSV/JSON debt. One affected comparison
  with unchanged controls decides further retention/debt; no unchanged retiming.
''' + plan[a:]
plan=plan.replace('B393 four warm complete\nregex/JSON/text/CSV jobs is the next owned comparison:210s+30s stop+40s margin;\nobserve only after280s. No automatic restart or early service query.', 'B393 is terminal/archived6c834129; never query it again. Refined selection source\nwork starts after ended users; the next owned comparison is not launched yet.')
p.write_text(plan,encoding='utf-8',newline='\n')
s=methods.read_text(encoding='utf-8')
a=s.index('    private static ReceiverMethod? ResolveReceiverMethod(')
b=s.index('    private static object InvokeReceiverMethod(',a)
resolver=s[a:b]
switch=resolver[resolver.index('receiver switch'):].rstrip().removesuffix(';')
s=s[:a]+s[b:]; methods.write_text(s,encoding='utf-8',newline='\n')
s=loader.read_text(encoding='utf-8')
a=s.index('            object? operation = ResolveReceiverMethod(receiver, name);')
b=s.index('            if (operation is null) return false;',a)
replacement='''            object? operation = instruction.OpCode == ExecutableOpCode.LoadCallReceiver
                ? receiver switch
                {
                    PyDict => DictMembers.GetNoArgumentsOperation(name),
                    PyString => StringMembers.GetNoArgumentsOperation(name),
                    _ => null,
                }
                : ''' + switch + ';\n'
# Match the indentation of the surrounding instruction handler.
lines=replacement.splitlines()
at=next(i for i,line in enumerate(lines) if ': receiver switch' in line)
for i in range(at+1,len(lines)): lines[i]='        '+lines[i]
s=s[:a]+'\n'.join(lines)+'\n'+s[b:]
loader.write_text(s,encoding='utf-8',newline='\n')
print('Preserved original prototype; deleted one-caller resolver and redundant no-argument selection.')
