from pathlib import Path
import re

root = Path('D:/code/Lython')
def edit(path, transform):
    p = root / path
    old = p.read_text(encoding='utf-8')
    new = transform(old)
    assert new != old, path
    p.write_text(new, encoding='utf-8', newline='\n')
def replace(s, old, new):
    assert s.count(old) == 1, (old[:100], s.count(old))
    return s.replace(old, new)
def arm(s, name, next_name, replacement):
    a = s.index('"' + name + '" =>')
    b = s.index('"' + next_name + '" =>', a)
    indent = s[s.rfind('\n', 0, a) + 1:a]
    return s[:a] + replacement + '\n' + indent + s[b:]

base = 'src/Lokad.Lython/Runtime/'
def bound(s):
    s = replace(s, 'private sealed class BoundCallable : DelegateBoundArgumentsCallable', 'private sealed class BoundCallable : BoundArgumentsCallable')
    old = '''            : base(signature, PythonCallableKind.Method, implementation, asyncImplementation)
        { }'''
    new = '''            : base(signature, PythonCallableKind.Method)
        {
            _implementation = implementation;
            _asyncImplementation = asyncImplementation;
        }

        private readonly Func<object[], LythonSourceSpan, ExecutionContext, object>? _implementation;
        private readonly Func<object[], LythonSourceSpan, ExecutionContext, ValueTask<object>>? _asyncImplementation;
        private readonly ReceiverMethod? _receiverMethod;

        private BoundCallable(object receiver, ReceiverMethod method)
            : base(method.Signature, PythonCallableKind.Method)
        {
            _receiver = receiver;
            _receiverMethod = method;
        }

        internal static BoundCallable Create(object receiver, ReceiverMethod method) => new(receiver, method);

        protected override object InvokeBound(object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => _receiverMethod is null ? _implementation!(arguments, span, context)
                : _receiverMethod.Invoke(_receiver!, arguments, span, context);

        protected override ValueTask<object> InvokeBoundAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => _receiverMethod is not null ? _receiverMethod.InvokeAsync(_receiver!, arguments, span, context)
                : _asyncImplementation is null ? new(InvokeBound(arguments, span, context))
                : _asyncImplementation(arguments, span, context);'''
    s = replace(s, old, new)
    return replace(s, ': base(signature, PythonCallableKind.Method, static (_, _, _) => throw new InvalidOperationException("Presence-bound callable invoked without presence."), null)', ': base(signature, PythonCallableKind.Method)')
edit(base+'LythonRuntime.Calls.cs', bound)

def markers(s):
    a = s.index('    // Internal operand only:')
    b = s.index('    private static object LoadLocal', a)
    return s[:a] + s[b:]
edit(base+'LythonRuntime.Executable.Binding.cs', markers)
def loader(s):
    a = s.index('            if (instruction.OpCode != ExecutableOpCode.LoadCallReceiver) return false;')
    b = s.index('            if (operation is null) return false;', a)
    return s[:a] + '''            var receiver = execution.Stack[instruction.InputStart];
            object? operation = ResolveReceiverMethod(receiver, name);
            if (operation is null && instruction.OpCode == ExecutableOpCode.LoadCallReceiver)
                operation = receiver switch
                {
                    PyDict => DictMembers.GetNoArgumentsOperation(name),
                    PyString => StringMembers.GetNoArgumentsOperation(name),
                    _ => null,
                };
''' + s[b:]
edit(base+'LythonRuntime.Executable.Interpreter.cs', loader)
def frontend(s):
    a = s.index('                    "get" or "setdefault" =>')
    b = s.index('                    "keys" or "values" or "items"', a)
    s = s[:a] + s[b:]
    s = replace(s, '                    "startswith" or "endswith" => call.Arguments.Count is >= 1 and <= 3,\n', '')
    return s
edit('src/Lokad.Lython/Frontend/ExecutableScript.Expressions.cs', frontend)
def invoke(s):
    s = replace(s, 'var dictionary = call.HasReceiver && ReferenceEquals(target, DirectDictionaryGet)', 'var dictionary = call.HasReceiver && call.IsPositionalOnly && call.ArgumentCount is 1 or 2 &&\n                ReferenceEquals(target, ReceiverMethods.DictionaryGet)')
    a = s.index('                if (call.HasReceiver && ReferenceEquals(target, DirectListAppend))')
    b = s.index('                else if (call.HasReceiver && _execution.Stack[start] is PyString', a)
    s = s[:a] + '''                if (call.HasReceiver && target is ReceiverMethod method && call.IsPositionalOnly && method.AcceptsPositional(call.ArgumentCount))
                {
                    var receiver = _execution.Stack[start];
                    var arguments = _execution.Stack.Slice(start + call.ArgumentOffset, call.ArgumentCount);
                    if (asynchronous) return CompleteCallValue(InvokeReceiverMethodAsync(method, receiver, arguments, call.CallSpan, this), start);
                    result = InvokeReceiverMethod(method, receiver, arguments, call.CallSpan, this);
                }
''' + s[b:]
    a = s.index('                else if (call.HasReceiver && ReferenceEquals(target, DirectStringJoin))')
    b = s.index('                else if (target is PyFunctionBase function)', a)
    s = s[:a] + s[b:]
    # Invalid positional shapes and keyword calls use the existing binder. They
    # are rare and may materialize a wrapper; do not duplicate binding/errors.
    return replace(s, '            using var storage = ReserveExecutableCallArguments(call, this);', '''            if (target is ReceiverMethod method)
                target = method.Bind(_execution.Stack[start]);
            using var storage = ReserveExecutableCallArguments(call, this);''')
edit(base+'LythonRuntime.Executable.Calls.Invoke.cs', invoke)

def members(s):
    s = re.sub(r'        private static readonly LythonCallableSignature ListAppendSignature = LythonCallableSignature.Create\(\n.*?positionalOnlyCount: 1\);\n', '', s, count=1, flags=re.S)
    s = re.sub(r'        private static readonly LythonCallableSignature Dict(?:Get|SetDefault)Signature = LythonCallableSignature.Create\(\n.*?positionalOnlyCount: 2\);\n', '', s, count=2, flags=re.S)
    s = replace(s, '"append" => BoundCallable.Create((arguments, span, context) => Append(list, arguments[0], span, context), ListAppendSignature),', '"append" => ReceiverMethods.ListAppend.Bind(list),')
    s = arm(s, 'get', 'keys', '"get" => ReceiverMethods.DictionaryGet.Bind(dict),')
    # Only the first (exact dict) setdefault; subclass member providers remain.
    return arm(s, 'setdefault', '__iter__', '"setdefault" => ReceiverMethods.DictionarySetDefault.Bind(dict),')
edit(base+'LythonRuntime.Members.cs', members)
def string_basic(s):
    for name in ('StrReplaceSignature','StrStartsWithSignature','StrEndsWithSignature'):
        s = re.sub(r'            private static readonly LythonCallableSignature '+name+r' = .*?;\n', '', s, count=1)
    return arm(s, 'replace', 'lower', '''"replace" => ReceiverMethods.StringReplace.Bind(text),
                    "startswith" => ReceiverMethods.StringStartsWith.Bind(text),
                    "endswith" => ReceiverMethods.StringEndsWith.Bind(text),''')
edit(base+'LythonRuntime.StringMembers.Basic.cs', string_basic)
def segmentation(s):
    s = re.sub(r'            private static readonly LythonCallableSignature StrSplitSignature = .*?;\n', '', s, count=1)
    return arm(s, 'split', 'rsplit', '"split" => ReceiverMethods.StringSplit.Bind(text),')
edit(base+'LythonRuntime.StringMembers.Segmentation.cs', segmentation)
def advanced(s):
    s = re.sub(r'            private static readonly LythonCallableSignature StrJoinSignature = .*?;\n', '', s, count=1)
    return arm(s, 'join', 'center', '"join" => ReceiverMethods.StringJoin.Bind(text),')
edit(base+'LythonRuntime.StringMembers.Advanced.cs', advanced)
edit(base+'LythonRuntime.HandleMembers.cs', lambda s: replace(s, '"write" => BoundCallable.Create((arguments, span, _) => Write(handle, arguments[0], span), "file.write", ["text"]),', '"write" => ReceiverMethods.TextWrite.Bind(handle),'))
edit(base+'LythonRuntime.BinaryFileHandle.Members.cs', lambda s: replace(s, '                if (name == "closed")', '                if (name == "write") { value = ReceiverMethods.BinaryWrite.Bind(this); return true; }\n                if (name == "closed")'))
def csv(s):
    s = re.sub(r'        private static readonly LythonCallableSignature RowSignature = .*?;\n', '', s, count=1)
    return arm(s, 'writerow', 'writerows', '"writerow" => ReceiverMethods.CsvWriterow.Bind(writer),')
edit(base+'LythonRuntime.CsvWriter.cs', csv)
print('Migrated ordinary receiver methods; regex migration next.')
