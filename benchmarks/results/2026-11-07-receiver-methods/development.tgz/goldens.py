from pathlib import Path
import json, re, subprocess, textwrap
r = Path(__file__).parent
p = Path('tests/Lokad.Lython.PublicApi.Tests/ReceiverMethodSemanticsTests.cs')
sources = [textwrap.dedent(x) for x in re.findall(r'"""(.*?)"""', p.read_text(encoding='utf-8'), re.S)[:2]]
rows = []
for source in sources:
    done = subprocess.run(['C:/Python313/python.exe', '-I', '-B', '-c', source], capture_output=True, text=True, encoding='utf-8')
    rows.append(dict(source=source, exit=done.returncode, stdout=done.stdout, stderr=done.stderr))
(r/'python-goldens.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
assert all(row['exit'] == 0 for row in rows), rows
for row in rows: print(row['stdout'])
