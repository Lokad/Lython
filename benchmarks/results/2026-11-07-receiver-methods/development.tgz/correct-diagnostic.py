from pathlib import Path
import json, os, shutil, subprocess
r = Path(__file__).parent.resolve()
tool = r/'tool'
shutil.copy2(tool/'Program.cs', tool/'Program.without-provider.cs.txt')
old = r/'warm-sync'
assert old.resolve().parent == r and not old.is_symlink()
old.rename(r/'setup-without-provider')
s = (r.parent/'regex-scalar-cursor-r40/tool/Program.cs').read_text(encoding='utf-8')
s = s.replace('cases.Length != 6', 'cases.Length != 4').replace('Require four Unicode scaling cases and ASCII/forward controls.', 'Require regex, JSON, text and CSV complete scripts.')
s = s.replace('var warmups = 4;', 'var warmups = 32;').replace('var batch = 1;', 'var batch = 4;')
s = s.replace('R40 scalar projection diagnostic', 'R41 shared receiver method diagnostic')
(tool/'Program.cs').write_text(s, encoding='utf-8', newline='\n')
(r/'original-setup-conditions.json').write_text(json.dumps(dict(
    catalogFailure='CSV id incorrectly used summary-helpers instead of summary-functions. StopIteration before driver creation/measurement; original failed condition retained.',
    providerFailure='R35 driver used parameterless engine; the first regex baseline compilation explicitly refused missing provider. Constructor cleanup ran; no observations. Original source/stderr/witness retained in setup-without-provider and Program.without-provider.cs.txt.',
    correction='Reuse the completed R40 provider-aware driver; only case count/warmup/batch/purpose change. No runtime/source/image/catalog/workload or acceptance relaxation.'), indent=2)+'\n', encoding='utf-8', newline='\n')
env = os.environ.copy(); env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe'; env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
with (r/'build-diagnostic-corrected.log').open('w', encoding='utf-8') as log:
    built = subprocess.run([env['DOTNET_HOST_PATH'], 'build', str(tool/'complete-jobs.csproj'), '-c', 'Release', '--nologo', '--tl:off', '-o', str(tool/'out')], env=env, stdout=log, stderr=subprocess.STDOUT)
assert built.returncode == 0
import hashlib
p=r/'diagnostic-identity.json'; identity=json.loads(p.read_text(encoding='utf-8'))
identity['correctedToolSHA256']=hashlib.sha256((tool/'out/complete-jobs.dll').read_bytes()).hexdigest()
p.write_text(json.dumps(identity, indent=2)+'\n', encoding='utf-8', newline='\n')
print('Provider-aware existing driver prepared; failed setup preserved; production/images unchanged.')
