from pathlib import Path
import re
root = Path('D:/code/Lython')
p = root/'src/Lokad.Lython/Runtime/LythonRuntime.Calls.cs'
s = p.read_text(encoding='utf-8')
# Each named method now has no remaining caller. Retain native-body helpers and
# file-write producers still used by JSON, CSV and stream implementations.
for name in ('InvokeListAppend', 'InvokeCsvWriterow', 'InvokeCsvWriterowAsync',
             'InvokeStringAffixFromOperands', 'InvokeStringAffixFromOperandsAsync',
             'InvokeStringJoin', 'InvokeStringJoinAsync', 'InvokeStringSplitAsync',
             'InvokeDictionarySetDefault', 'InvokeDictionaryGetAsync'):
    matches = list(re.finditer(r'^    private static [^\n]+\b'+name+r'\(', s, re.M))
    assert len(matches) == 1, name
    a = matches[0].start()
    # Retire the immediately associated explanatory comment too.
    while a > 0:
        line = s.rfind('\n', 0, a-1)+1
        if not s[line:a].lstrip().startswith('//'): break
        a = line
    start = s.index('{', matches[0].end())
    depth, b = 1, start+1
    while depth:
        if s[b] == '{': depth += 1
        elif s[b] == '}': depth -= 1
        b += 1
    assert s[b:b+2] == '\n\n', name
    s = s[:a] + s[b+2:]
p.write_text(s, encoding='utf-8', newline='\n')
p = root/'src/Lokad.Lython/Runtime/LythonRuntime.BinaryFileHandle.Members.cs'
s = p.read_text(encoding='utf-8').replace('"write" or "writelines" => (1, 1)', '"writelines" => (1, 1)')
s = s.replace('                    case "write": return Write(args[0], span);\n', '')
p.write_text(s, encoding='utf-8', newline='\n')
print('Retired ten orphaned guarded dispatch helpers and binary-write switch route.')
