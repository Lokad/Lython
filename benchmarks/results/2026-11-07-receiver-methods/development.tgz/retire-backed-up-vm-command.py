from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks'); assert base.resolve()==base
proof={'commit': '1971487a1a086d7dfab7e858c752ab1274132cb8', 'archive': 'benchmarks/results/2026-11-07-regex-scalar-cursor/development.tgz', 'archiveSHA256': '024fabbe7a3bbe57de6236670ce88d42171b0480fe3ab420a540a8060df2c989', 'member': 'baseline/net11.0/Lokad.Lython.dll', 'bytes': 5627392, 'fileSHA256': 'c21c0c4b3537c731d76fe5f96afb0c8f13f2c99a8335e09902c2f4c29a1e7fea'}
specs=[('annotation-demand-b389-20261107','candidate/Lokad.Lython.dll'),
       ('csv-cost-b391-20261107','candidate/Lokad.Lython.dll'),
       ('regex-scalar-cursor-b392-20261107','reference/Lokad.Lython.dll')]
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 checks=[]
 for folder,name in specs:
  parent=base/folder; path=parent/name
  assert path.resolve()==path and path.is_relative_to(base)
  for part in [parent,path.parent,path]: assert not stat.S_ISLNK(part.lstat().st_mode)
  info=path.stat(); assert stat.S_ISREG(info.st_mode) and info.st_nlink==1
  assert info.st_size==proof['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==proof['fileSHA256']
  receipt=json.loads((parent/'archive-receipt.json').read_text())
  assert receipt['complete'] and receipt['allWorkersJoined']
  assert (parent/'exit-code.txt').read_text().strip()=='0'
  checks.append(dict(path=str(path),inode=info.st_ino,links=info.st_nlink,bytes=info.st_size,backup=proof))
 before=shutil.disk_usage(base).free
 # All three exact files were validated before the first unlink. No directory,
 # fixture, archive, source, current image or shared hard link is removed.
 for row in checks: Path(row['path']).unlink()
 result=dict(files=checks,freeBefore=before,freeAfter=shutil.disk_usage(base).free,ownersEnded=True,archiveBackupAlreadyCommitted=True)
 (base/'receiver-methods-b393-20261107/retired-duplicate-cores.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result))
