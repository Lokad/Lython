from pathlib import Path
import hashlib, json, shutil, subprocess

root = Path('D:/code/Lython')
work = root / '.git/agent-notes/review-20261031/builtin-methods-r41'
before = work / 'images/before'
before.mkdir(parents=True, exist_ok=False)
frozen = root / '.git/agent-notes/review-20261031/regex-scalar-cursor-r40/images/candidate'
shutil.copytree(frozen, before, dirs_exist_ok=True)
(work / 'source-before.zip').write_bytes(subprocess.check_output(['git', 'archive', '--format=zip', 'HEAD'], cwd=root))
hashes = {str(p.relative_to(before)): hashlib.sha256(p.read_bytes()).hexdigest() for p in before.rglob('*') if p.is_file()}
(work / 'before-hashes.json').write_text(json.dumps(hashes, indent=2) + '\n', encoding='utf-8')
p = root / 'PLAN.md'
s = p.read_text(encoding='utf-8')
s = s.replace('No active runtime prototype; R41 allocation attribution is the next owned diagnostic.', 'R41 allocation gate completed; receiver-method migration selected below. No retained runtime prototype yet.')
a = s.index('**Active R41 source/allocation gate')
b = s.index('\n| Further boundary', a)
s = s[:a] + '''**Active R41 — shared receiver-method implementation (selected, not qualified):**

- Completed bounded EventPipe capture on1971487a/frozeneb6052d0:256checked jobs
  each, zero lost ticks, all owner/golden/stop/join gates. Regex5248ticks: wrapper
  7.27%, sync delegate9.00%, async delegate8.01%; JSON6242ticks has negligible
  callable share. Statistical type attribution, not exact type counts or CPU proof.
  Existing str/dict no-argument operations are already shared; do not rediscover them.
- Hypothesis: separate immutable builtin implementation/signature from receiver;
  immediate executable calls borrow existing operands, exposed methods retain the
  ordinary wrapper/metadata/binder. Remove per-match capturing delegates and
  wrappers, plus ordinary positional argument repackaging for the migrated methods.
- Concrete migration/deletion: all ReMatch methods and the existing list.append,
  dict.get/setdefault, file.write, csv.writerow, str.join/split/replace/affix methods.
  Replace all ten opaque Direct* sentinels and their duplicated invocation chain
  with the same receiver-method convention; replace migrated member-factory
  closures with shared definitions. Preserve real dynamic/presence wrappers and
  the measured no-argument/native-return operations; do not build a new call arena.
  Retire helpers made orphaned by this migration. Keep actual native-body guards.
- Completion milestone: no old migrated factory/marker path survives; receiver
  snapshots, descriptors/rebinding, method metadata/hash, invalid counts/keywords,
  omitted defaults, argument/error/admission order, native proofs, genuine async
  protocols/current token, managed stack, first refusal, funded operands and
  awaited cleanup pass focused checks. No public API/policy or regex dialect change.
- Bound allocation comparison and quiet complete regex extraction plus JSON/text/
  CSV controls decide retention/refinement. Keep all adverse results. Separate
  architecture, allocation, and demonstrated elapsed/CPU; no predicted speedup.
  Batch full delivery with pendingR40 at a coherent boundary, then resume roadmap.
''' + s[b:]
s = s.replace('No active CI, local test or VM work. R41 uses one bounded local allocation capture\n(256checked regex/JSON jobs each), not a new runtime prototype or elapsed comparison.', 'No active CI, local test, allocation capture or VM work. R41 baseline source/images\nare frozen before the selected coherent receiver-method prototype.')
s = s.replace('No active prototype. Resume R41 source/design gate;', 'Resume R41 selected migration;')
p.write_text(s, encoding='utf-8', newline='\n')
print('R41 selected; baseline source/images frozen; PLAN updated.')
