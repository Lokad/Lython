from pathlib import Path
import hashlib, json, os, shutil, subprocess
r = Path(__file__).parent
root = Path('D:/code/Lython')
env = os.environ.copy()
env['DOTNET_ROOT'] = 'C:/Users/JoannesVermorel/.dotnet11'
env['DOTNET_HOST_PATH'] = env['DOTNET_ROOT'] + '/dotnet.exe'
env['PATH'] = env['DOTNET_ROOT'] + os.pathsep + 'C:/Python313' + os.pathsep + env['PATH']
with (r/'build-frozen.log').open('w', encoding='utf-8') as log:
    built = subprocess.run([env['DOTNET_HOST_PATH'], 'build', 'src/Lokad.Lython/Lokad.Lython.csproj', '-c', 'Release', '-f', 'net11.0', '--no-incremental', '--nologo', '-v', 'quiet'], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
assert built.returncode == 0, (r/'build-frozen.log').read_text(encoding='utf-8')[-3000:]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before = r/'images/before'
candidate = r/'images/candidate'
if not candidate.exists():
    shutil.copytree(before, candidate)
core = root/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
shutil.copy2(core, candidate/core.name)
assert sha(before/core.name) == 'eb6052d0992e1e7eb236b72d6d39cac59279a67ef2c8047604f047447a55692c'
catalog = json.loads((r.parent/'annotation-demand-r38/catalog.json').read_text(encoding='utf-8'))
ids = ['scripts.regex-capture-summary.large', 'scripts.json-summary-helpers.large', 'scripts.text-summary-helpers.large', 'scripts.csv-summary-functions.large']
catalog['cases'] = [next(c for c in catalog['cases'] if c['id'] == name) for name in ids]
(r/'comparison-catalog.json').write_text(json.dumps(catalog, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
tool = r/'tool'
tool.mkdir()
old = r.parent/'canonical-formatted-instructions-r35/tool'
shutil.copy2(old/'complete-jobs.csproj', tool/'complete-jobs.csproj')
s = (old/'Program.cs').read_text(encoding='utf-8')
s = s.replace('Require static/dynamic report, text and CSV cases.', 'Require regex, JSON, text and CSV complete scripts.').replace('var batch = 16;', 'var batch = 4;')
s = s.replace('R35 direct formatted instruction diagnostic', 'R41 shared receiver method diagnostic')
(tool/'Program.cs').write_text(s, encoding='utf-8', newline='\n')
with (r/'build-diagnostic.log').open('w', encoding='utf-8') as log:
    built = subprocess.run([env['DOTNET_HOST_PATH'], 'build', str(tool/'complete-jobs.csproj'), '-c', 'Release', '--nologo', '--tl:off', '-o', str(tool/'out')], env=env, stdout=log, stderr=subprocess.STDOUT)
assert built.returncode == 0, (r/'build-diagnostic.log').read_text(encoding='utf-8')[-3000:]
files = list((root/'src/Lokad.Lython').rglob('*.cs'))
files = [p for p in files if 'obj' not in p.parts and 'bin' not in p.parts]
identity = dict(baselineSource='1971487a', before=sha(before/core.name), candidate=sha(candidate/core.name),
    auxiliary={p.name:sha(p) for p in before.iterdir() if p.is_file() and p.name != core.name},
    productionSources={str(p.relative_to(root)):sha(p) for p in files}, toolSHA256=sha(tool/'out/complete-jobs.dll'),
    catalogSHA256=sha(r/'comparison-catalog.json'),
    boundary='Complete public Run/awaited RunAsync, fixture reset/mediated I/O/full goldens/prior-result disposal. Compilation separate; startup excluded. Precise process allocation; desktop clocks diagnostic, shared CoreLib/process GC. Normal GC/tiering.')
(r/'diagnostic-identity.json').write_text(json.dumps(identity, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(dict(before=identity['before'], candidate=identity['candidate'], cases=ids)))
