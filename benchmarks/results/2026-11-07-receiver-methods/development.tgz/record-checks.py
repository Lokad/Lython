from pathlib import Path
import hashlib, json, re
r=Path(__file__).parent
logs=['internal-focused11.log','public-focused11.log','test-final-regressions.log',
      'internal-focused10.log','public-focused10.log','final-internal-net11.0.log','final-internal-net10.0.log']
checks={}
for name in logs:
    text=(r/name).read_text(encoding='utf-8-sig')
    passed=re.findall(r'Passed!.*',text)
    assert passed and not re.search(r'Failed:\s+[1-9]',text),name
    checks[name]=dict(summaries=passed,sha256=hashlib.sha256((r/name).read_bytes()).hexdigest())
cores={t:hashlib.sha256(Path('src/Lokad.Lython/bin/Release',t,'Lokad.Lython.dll').read_bytes()).hexdigest() for t in ['net11.0','net10.0']}
identity=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
assert cores['net11.0']==identity['candidate']
assert cores['net10.0']=='f848abe1bb37ffc03ed218582b9dba69f9bd1b44b19c87cc6fafa210a6a2187b'
sources={name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in identity['productionSources']}
assert sources==identity['productionSources'],'Frozen production changed.'
receipt=dict(checks=checks,coreSHA256=cores,
    qualification='Focused actual.NET11/10 only; ordinary full platform/Stress/installed consumers pending. Logs overlap; never sum counts. Earlier explicit.NET11 selection included selected Stress cases; .NET10 filter explicitly excludes Stress.',
    independentPython='python-goldens.json: CPython3.13.2 -I -B; outputs checked against fixed assertions.',
    retiredArchitectureTests='Four obsolete absence-of-LoadCallReceiver assertions removed; member read/call distinction checks existing LoadCallMember. Independent public semantics/cancellation/refusal/cleanup remain.',
    productionMatchesFrozenComparison=True)
(r/'focused.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(coreSHA256=cores,checks=len(checks),productionMatchesFrozenComparison=True)))
p=r/'original-setup-conditions.json'; conditions=json.loads(p.read_text(encoding='utf-8'))
conditions['vmPreparationGate']='Initial B393 preparation stopped before deployment: local frozen worker7cf37ca5/adapter27211dbe differ from preceding VMb94/51c. Install local worker+adapter identically in both new roles; no prior snapshot changed. Released producer hashes remain identical0.4. Remote setup reverified every core/auxiliary, left8441856free bytes, then launched once.'
conditions['regressionFixture']='Initial invalid-call test was statically diagnosed, not run. Move known-invalid regex calls behind an untyped function parameter; independent CPython output unchanged. Original failed log retained; no runtime correction for this fixture.'
conditions['initialCompile']='Two corrected compile errors: local method name shadowing; nullable operand annotation. No compiled prototype/observations existed before correction.'
p.write_text(json.dumps(conditions,indent=2)+'\n',encoding='utf-8',newline='\n')
