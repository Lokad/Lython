from pathlib import Path
import hashlib,json
r=Path(__file__).parent;old=r.parent/'native-single-pass-r26';r.mkdir(exist_ok=True)
catalog=json.loads((r.parent/'annotation-demand-r38/catalog.json').read_text(encoding='utf-8'))
ids=['scripts.regex-capture-summary.large','scripts.json-summary-helpers.large'];catalog['cases']=[next(c for c in catalog['cases'] if c['id']==name) for name in ids]
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
core=r.parent/'regex-scalar-cursor-r40/images/candidate/Lokad.Lython.dll';digest=hashlib.sha256(core.read_bytes()).hexdigest();assert digest=='eb6052d0992e1e7eb236b72d6d39cac59279a67ef2c8047604f047447a55692c'
s=(old/'profile-current-allocation.py').read_text(encoding='utf-8-sig')
s=s.replace("out=home/'r27-type-allocation'","out=home/'allocation'").replace("home/'b374/retrieved/cpython-worker.py'","home.parent/'canonical-formatted-instructions-r35/b387/retrieved/cpython-worker.py'")
s=s.replace("home/'allocation/catalog.json'","home/'catalog.json'").replace("home/'allocation/candidate/Lokad.Lython.Benchmarks.dll'","home.parent/'regex-scalar-cursor-r40/images/candidate/Lokad.Lython.Benchmarks.dll'")
s=s.replace("[('text','scripts.text-summary-helpers.large'),('report','scripts.report-render.large')]","[('regex','scripts.regex-capture-summary.large'),('json','scripts.json-summary-helpers.large')]")
s=s.replace("json.loads((home/'focused-refined.json').read_text(encoding='utf-8'))['coreSHA256']['net11.0']",repr(digest))
s=s.replace('captureInvocations=1024','captureInvocations=256').replace("request('batch',256)","request('batch',128)").replace("request('batch',1024)","request('batch',256)")
s=s.replace('same frozen R26 source; no VM timing comparison','current1971487a production/frozeneb6052d0, normal optional0.4; no VM timing comparison').replace('Both bounded current-source allocation profiles complete; no runtime changes.','Both R41 allocation profiles complete; no runtime prototype or timing claim.')
compile(s,'allocation','exec');(r/'profile-allocation.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'analyze-current-allocation.py').read_text(encoding='utf-8-sig').replace("'r27-type-allocation'","'allocation'").replace("['text','report']","['regex','json']")
(r/'analyze-allocation.py').write_text(s,encoding='utf-8',newline='\n')
(r/'source-contract.md').write_text('''# R41 source/allocation gate

Current1971487a production, frozeneb6052d0 precommit SourceLink3604f935; existing
worker/host/normal optional0.4 frozen identically. One bounded existing EventPipe
GC-allocation-tick capture, no collect/dump/rundown/root tracing, no runtime change.
Two maintained complete scripts: regex extraction and JSON helper control. Verify
twice, warm128, settle2s, capture256 checked invocations.120s outer owned process
bound, cooperative collector stop, complete goldens/funding/Closed/joins/private
fixture cleanup required. All raw threads/unknowns/lost/adverse evidence retained.
Allocation ticks are statistical type attribution, not exact type counts, CPU,
live heap or proof that a particular call path dominates. Includes full request
reset/I/O/checks/prior-result cleanup; compile/warmup/final teardown excluded.

Source already has receiver-separated string/dict no-argument operations and
selected native methods. ReMatchMembers still creates capturing sync/async delegates
and BoundCallable, whose receiver is then attached separately. Quantify remaining
wrapper/delegate/binding work before selecting a shared method convention. A
selected redesign must remove overlapping direct-marker selection/dispatch for
migrated families; no extra narrow regex shortcut, caller arena or public option.
Preserve receiver snapshots, descriptors, metadata/hash/identity, defaults/keywords,
argument/error/admission order, native proofs, real suspension/current tokens,
managed stack, first refusal, aliases and awaited cleanup. If no material phase is
demonstrated, record missing proof and move boundary; no automatic capture campaign.
''',encoding='utf-8',newline='\n')
p=Path('PLAN.md');text=p.read_text(encoding='utf-8');text=text.replace('**Next R41 source/design gate — receiver-bound builtin methods:**','**Active R41 source/allocation gate — receiver-bound builtin methods:**')
text=text.replace('No active prototype, tests or collection remain.','No active runtime prototype; R41 allocation attribution is the next owned diagnostic.')
text=text.replace('No active CI, local test or VM work.','No active CI, local test or VM work. R41 uses one bounded local allocation capture\n(256checked regex/JSON jobs each), not a new runtime prototype or elapsed comparison.')
p.write_text(text,encoding='utf-8',newline='\n')
print('R41 bounded current regex/JSON allocation gate prepared; no production change.')
