from pathlib import Path
import json, statistics
r=Path(__file__).parent
rows=[]
for api in ['sync','async']:
    data=json.loads((r/('warm-'+api)/'measurements.json').read_text(encoding='utf-8'))
    for item in data['observations']:
        roles={}
        for label in ['before','candidate','before-control']:
            samples=[s for s in item['samples'] if s['image']==label]
            roles[label]={k:statistics.median(s[k]/s['jobs'] for s in samples) for k in ['allocatedBytes','elapsedMilliseconds','executionMilliseconds','cpuMilliseconds']}
        change=lambda k:[100*(roles['candidate'][k]/roles[label][k]-1) for label in ['before','before-control']]
        row=dict(api=api,case=item['caseId'],roles=roles,allocationChangePercent=change('allocatedBytes'),
            desktopElapsedChangePercent=change('elapsedMilliseconds'),admittedPeaks=item['admittedPeaks'])
        rows.append(row)
        print(api,item['caseId'], 'allocation %',*[round(v,3) for v in row['allocationChangePercent']],
            'desktop elapsed %',*[round(v,3) for v in row['desktopElapsedChangePercent']], 'peaks',json.dumps(item['admittedPeaks']))
(r/'local-summary.json').write_text(json.dumps(dict(performanceQualified=False,rows=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
