from pathlib import Path
r=Path(__file__).parent
s=(r.parent/'regex-scalar-cursor-r40/summarize-b392.py').read_text(encoding='utf-8').replace('b392','b393')
(r/'summarize-b393.py').write_text(s,encoding='utf-8',newline='\n')
exec(compile(s,str(r/'summarize-b393.py'),'exec'),{'__file__':str(r/'summarize-b393.py')})
