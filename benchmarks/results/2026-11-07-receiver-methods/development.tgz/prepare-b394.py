from pathlib import Path
import ast, hashlib, json, shutil, subprocess, tarfile
home=Path(__file__).parent;r=home/'b394';r.mkdir()
old=home/'b393';old_remote='/home/lokad/lython-bench-checks/receiver-methods-b393-20261107';remote='/home/lokad/lython-bench-checks/receiver-methods-b394-20261107'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=json.loads((home/'refined-focused.json').read_text(encoding='utf-8'))
candidate=home/'images/refined/Lokad.Lython.dll';assert sha(candidate)==checks['coreSHA256']['net11.0']
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='1971487a plus refined R41 receiver selection; frozen'+sha(candidate),
    purpose='R41 bounded selection refinement; identical four complete scripts/controls to original B393',
    qualification=checks,productionSources=checks['productionSources'],originalComparison='B393 preserved, including adverse CSV/JSON and desktop observations.')
identity['coreSHA256'].update(candidate=sha(candidate),control=sha(candidate))
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copy2(old/'representative.json',r/'representative.json')
for name in ['collect.py','archive-owned.py','run.sh']:
    (r/name).write_text((old/name).read_text(encoding='utf-8').replace(old_remote,remote),encoding='utf-8',newline='\n')
contract='''Bounded refinement of B393: remove the one-caller resolver and redundant string-name checks before the already-shared no-argument path. Same receiver-method definitions, borrowed operands, binder/metadata, real async hooks, managed stack, current cancellation, first refusal and shared ownership.121internal/506public per actual.NET11/10 focused checks pass. Source proves removed dispatch work; it does not attribute the original CSV/JSON regression to that work. Original source/images,29.47% allocation reduction, adverse desktop and B393 control debt remain immutable. Same four complete regex/JSON/text/CSV scripts; normal optional0.4, worker7cf37ca5/adapter27211dbe, .NET11RC3/normalGC/tiering/quietVM. Two old R40/two refined processes,5s warmup/role/job,7rotated150ms rounds. Timed public runs include mediated RAM file I/O, full guest aggregation/checks and prior-result cleanup; compile/startup/staging/reset/final cached teardown excluded. Require every Ready/core/aux/golden/budget/quiet/Closed/join/archive gate.210s owner+30s stop+40s margin; observe after280s. One refined source comparison decides retention/debt, no unchanged repeat selected. Full platform/Stress/installed consumer delivery pending; producer publication independent and NuGet publication postponed. Three exact old c21c0c4b core copies were retired only after single-link/path/user/hash checks against committed R40 development.tgz backup1971487a; all original source/evidence survives.'''
(r/'contract.md').write_text(contract+'\n',encoding='utf-8',newline='\n')
setup=json.loads((old/'setup-contract.json').read_text(encoding='utf-8'));setup['referenceTemplate']=old_remote+'/reference'
(r/'setup-contract.json').write_text(json.dumps(setup,indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s=s.replace('the next owned comparison is not launched yet.', 'B394 is the next owned comparison:210s+30s stop+40s margin, observe after280s;\nno restart on observation timeout. Refined121internal/506public per actual11/10 pass.\nThree exact single-link oldc21cores retired with committed backup1971487a verified;\n18MB free after retirement. No source/evidence/archive or current core was removed.')
p.write_text(s,encoding='utf-8',newline='\n');shutil.copy2(p,r/'pre-measurement-plan.md')
(r/'source.patch').write_bytes(subprocess.check_output(['git','-c','core.autocrlf=false','diff','--','src','tests']))
shutil.copy2('src/Lokad.Lython/Runtime/LythonRuntime.ReceiverMethods.cs',r/'receiver-method-source.cs')
shutil.copy2('tests/Lokad.Lython.PublicApi.Tests/ReceiverMethodSemanticsTests.cs',r/'receiver-method-tests.cs')
for name in ['collect.py','archive-owned.py']:ast.parse((r/name).read_text(encoding='utf-8'))
with tarfile.open(r/'payload.tgz','w:gz') as t:
    for name in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh','contract.md','pre-measurement-plan.md','setup-contract.json','source.patch','receiver-method-source.cs','receiver-method-tests.cs']:t.add(r/name,arcname=name)
    t.add(candidate,arcname='current-core.dll')
s=(old/'launch.py').read_text(encoding='utf-8').replace('receiver-methods-b393-20261107','receiver-methods-b394-20261107').replace('lython-b393-receiver-methods-20261107','lython-b394-receiver-methods-20261107').replace('receiver-methods-b393-launch.py','receiver-methods-b394-launch.py')
s=s.replace("reference=base/'regex-scalar-cursor-b392-20261107/candidate'", "reference=base/'receiver-methods-b393-20261107/reference'")
start=s.index(" for name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Utf8Regex.dll']:")
end=s.index(" identity=json.loads((root/'identity.json').read_text())",start)
s=s[:start]+s[end:]
ast.parse(s);(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(home/'retrieve-b393.py').read_text(encoding='utf-8').replace("parent/'b393'", "parent/'b394'").replace('receiver-methods-b393-20261107','receiver-methods-b394-20261107').replace('lython-b393-receiver-methods-20261107','lython-b394-receiver-methods-20261107')
s=s.replace("b=json.loads((root/'observe-not-before.json').read_text())", "assert not (root/'terminal-status.json').exists(), 'Do not requery a recorded terminal run.'\nb=json.loads((root/'observe-not-before.json').read_text())")
(home/'retrieve-b394.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared one refined source comparison; original B393 unchanged; auxiliary images reused exactly.')
