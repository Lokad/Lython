from pathlib import Path
import hashlib, json, subprocess, tarfile
r=Path(__file__).parent
archive=Path('benchmarks/results/2026-11-07-regex-scalar-cursor/development.tgz')
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
committed=subprocess.check_output(['git','show',revision+':'+archive.as_posix()])
assert committed==archive.read_bytes(), 'Backup must already be committed, with unchanged exact bytes.'
member='baseline/net11.0/Lokad.Lython.dll'
with tarfile.open(archive) as t: data=t.extractfile(member).read()
digest=hashlib.sha256(data).hexdigest()
assert digest=='c21c0c4b3537c731d76fe5f96afb0c8f13f2c99a8335e09902c2f4c29a1e7fea'
proof=dict(commit=revision,archive=archive.as_posix(),archiveSHA256=hashlib.sha256(committed).hexdigest(),member=member,bytes=len(data),fileSHA256=digest)
script='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks'); assert base.resolve()==base
proof=PROOF
specs=[('annotation-demand-b389-20261107','candidate/Lokad.Lython.dll'),
       ('csv-cost-b391-20261107','candidate/Lokad.Lython.dll'),
       ('regex-scalar-cursor-b392-20261107','reference/Lokad.Lython.dll')]
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 checks=[]
 for folder,name in specs:
  parent=base/folder; path=parent/name
  assert path.resolve()==path and path.is_relative_to(base)
  for part in [parent,path.parent,path]: assert not stat.S_ISLNK(part.lstat().st_mode)
  info=path.stat(); assert stat.S_ISREG(info.st_mode) and info.st_nlink==1
  assert info.st_size==proof['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==proof['fileSHA256']
  receipt=json.loads((parent/'archive-receipt.json').read_text())
  assert receipt['complete'] and receipt['allWorkersJoined']
  assert (parent/'exit-code.txt').read_text().strip()=='0'
  checks.append(dict(path=str(path),inode=info.st_ino,links=info.st_nlink,bytes=info.st_size,backup=proof))
 before=shutil.disk_usage(base).free
 # All three exact files were validated before the first unlink. No directory,
 # fixture, archive, source, current image or shared hard link is removed.
 for row in checks: Path(row['path']).unlink()
 result=dict(files=checks,freeBefore=before,freeAfter=shutil.disk_usage(base).free,ownersEnded=True,archiveBackupAlreadyCommitted=True)
 (base/'receiver-methods-b393-20261107/retired-duplicate-cores.json').write_text(json.dumps(result,indent=2)+'\\n')
 print(json.dumps(result))
'''.replace('PROOF',repr(proof))
(r/'retire-backed-up-vm-command.py').write_text(script,encoding='utf-8',newline='\n')
compile(script,'retire','exec')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(r/'vm-retirement.stdout').write_text(done.stdout,encoding='utf-8');(r/'vm-retirement.stderr').write_text(done.stderr,encoding='utf-8')
assert done.returncode==0,done.stderr
result=json.loads(done.stdout);assert result['freeAfter']>12*1024*1024
(r/'vm-retirement.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(files=len(result['files']),freeBefore=result['freeBefore'],freeAfter=result['freeAfter'],backupCommit=revision)))
