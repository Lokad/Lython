from pathlib import Path
r=Path(__file__).parent
s=(r/'measure.py').read_text(encoding='utf-8')
assert s.count("r/('warm-'+api)")==1 and s.count("r/'images/candidate/Lokad.Lython.Benchmarks.dll'")==1
s=s.replace("r/('warm-'+api)","r/('refined-warm-'+api)").replace("r/'images/candidate/Lokad.Lython.Benchmarks.dll'","r/'images/refined/Lokad.Lython.Benchmarks.dll'")
(r/'refined-measure-command.py').write_text(s,encoding='utf-8',newline='\n')
exec(compile(s,str(r/'refined-measure-command.py'),'exec'),{'__file__':str(r/'refined-measure-command.py')})
s=(r/'summarize-local.py').read_text(encoding='utf-8').replace("r/('warm-'+api)","r/('refined-warm-'+api)").replace("r/'local-summary.json'","r/'refined-local-summary.json'")
exec(compile(s,str(r/'refined-summarize-command.py'),'exec'),{'__file__':str(r/'refined-summarize-command.py')})
