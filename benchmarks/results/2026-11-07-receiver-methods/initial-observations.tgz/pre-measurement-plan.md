# Lokad.Lython 0.11.0

Updated2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Another isolated experiment/checkpoint does not complete that objective.

## Actual delivery status

- **Fully qualified through b0889a46:** terminal GREEN42351006316, Windows/Ubuntu
  Release, ordinary actual.NET11/10, original Stress both targets and installed
  package consumers. Includes shared compiler-fact correction, direct UTF8/storage,
  native helper returns, R20/R25 records, R29 calls, R30–R32 shared facts/layouts,
  R33 current-token hashing, R35 direct formatted instructions, R36 builtin-root
  identity and R38 demand-bound annotation flow. Original scales/timeouts remain.
  Receipt committed under annotation-demand. Earlier terminal receipts remain
  historical; no repeated queries or qualification for unchanged production.
- **R40 retained/committed1971487a, focused/VM-qualified:** existing regex scalar
  cursor seeks backwards or from origin, replacing nearby lookbehind's growing
  prefix rescans. No provider/API/adapter/memory-layer change.853internal/1,224public
  per actual target, one active rewind cancellation/owner test each, four independent
  Python cases/both APIs and six supervised scaling/control jobs pass. Baseline/
  candidate source/images and every condition preserved. Full platform/Stress/
  installed-consumer qualification is batched at the next coherent delivery boundary;
  R36/R38 receipt excludes R40. R41 allocation gate completed; receiver-method migration selected below. R41 uncommitted prototypebfc2e427 under focused/local qualification; no delivery claim.
- **Independent producer compatibility:** immutabledev48/sourcef6b2175e passed
  85internal/488public per actual target on R30 consumer. Normal adapter remains
  nonpackable/pinned0.4; core decoupled. Not current-HEAD or final producer safety/
  CPU/release certification. Missing capabilities defer affected final qualification.
- **History separate:** benchmarks/EXPERIMENTS.md and immutable results retain
  source pairs, original failed setups/semantic assertions, adverse observations and
  withdrawals. R28 windows/mask withdrawn; slower call-arena/control lessons stay.
  No dormant production routes or rejected runtime options retained for experiments.

## Established measurements / regression debt

| Milestone | Established outcome | Limitation / decision |
| --- | --- | --- |
| Shared compiler facts | Shared inferred-value traversal fixes exponential work; fully qualified | Preserve callback correction; no warm CPU claim. |
| Native helper returns | Allocation−19.92/−19.31%; fully qualified | Earlier elapsed gains diagnostic, not transferable to HEAD. |
| Direct UTF8 formatting/storage | Allocation−8.67%; controlled B102 elapsed/CPU−5–8% supports retain | Original adverse15.125ms unexplained/preserved. |
| R20/R25 records | Shared keys/independent values; completed CSV arrays transfer. R25 allocation−7.31/−6.55%, native warm−7.72–8.04% | Selectively revisits old6–8% bulk rejection through coherent transfer. Coarse CPU/text controls mixed. |
| R29 calls | Synthetic native-helper completion phase removed; text warm−4.25–7.61%sync/−7.63–8.64%async vsR26 | Allocation flat; report/CSV uncertainty and older debt remain. |
| R30–R32 facts/layouts | Repeated class/parameter analysis/storage removed | Compilation storage grows; old moving text/CSV controls and adverse pairings remain debt. |
| R35 formatting | Dynamic complete report warm allocation~−15.35%, quiet elapsed−10.09–13.19% | Static warm favorable, fresh/text variable; CSV+0.13–2.36% accepted possible debt. Original B386/refinement preserved. |
| R38 annotation demand | Compile allocation−4.38–8.94%; report compile−6.51–8.02%, text−8.25–9.13%, config fresh−0.54–2.42% | Required full regex flow preserved after initial3failures; regex+304B/+0.117%, elapsed up to+1.66% accepted overhead. Warm text variable. Fully qualified. |
| R40 scalar cursor | Same0.4 backend: Unicode1,024warm−31.28–34.50%,4,096−65.54–68.53%,8,192−78.99–79.47%; allocation essentially flat/peaks identical | Growing-input diagnostic, not broad regex/isolated CPU/CPython claim. ASCII−0.16 to+6.31%/4.78%current spread, forward−3.38 to+2.96% variable; possible ASCII debt accepted. Full batch pending. |

**Representative CPython snapshot:** B388/exact42101cd5/frozen6ab7367f, before
R36/R38/R40, all15jobs311.96s/all gates. Primary docs/BENCHMARKS.md labels that
source accurately; B380 remains immutable. Warm CSV1.20x,text1.67–1.75x,JSON
1.02–1.04x,report1.40–1.42x,config1.26x CPython; compile45–75us separate.
Most cases variable: text4.87%warm role spread, report6.18%IQR, CSV5.20%fresh
spread. Includes mediated RAM I/O, complete checks and prior-result cleanup; fresh
adds compile/program disposal. Excludes startup/staging/reset/final cached teardown.
No median subtraction, per-change CPU attribution or algebraic debt repayment.
Startup, genuine pending I/O, heap/RSS and embedding tails remain unmeasured.
Refresh at a material retained checkpoint, not after every small commit.

## Priority 1 — next coherent execution/storage redesign

Use complete CSV/text/JSON/report/config/file scripts, including newly compiled
once/run-once scripts inside a warm host. Source/cost evidence before mutation;
name displaced work/storage and its removal milestone. Preserve clock boundaries.

**Closed gates:** R37 census finds native call slices already borrowed; deleting
adjacent leaf loads alone retains storage and needs snapshot/error-span metadata.
No new argument transport selected. R39/B391 ordinary CSV:1,127guest samples/
5.68CPU seconds,58unknown; BeginPendingCall550inclusive/32self includes useful
helper execution. Work-state26/18,binding22/18,resume11/11 do not establish dominant
removable frame construction. CSV parsing/record work competes. No general frame
arena/rewrite or repeated aggregate profile selected. R34 report formatting routing
was partly addressed by R35. All raw/unknown/adverse/failed conditions stay linked.

**Active R41 — shared receiver-method implementation (selected, not qualified):**

- Completed bounded EventPipe capture on1971487a/frozeneb6052d0:256checked jobs
  each, zero lost ticks, all owner/golden/stop/join gates. Regex5248ticks: wrapper
  7.27%, sync delegate9.00%, async delegate8.01%; JSON6242ticks has negligible
  callable share. Statistical type attribution, not exact type counts or CPU proof.
  Existing str/dict no-argument operations are already shared; do not rediscover them.
- Hypothesis: separate immutable builtin implementation/signature from receiver;
  immediate executable calls borrow existing operands, exposed methods retain the
  ordinary wrapper/metadata/binder. Remove per-match capturing delegates and
  wrappers, plus ordinary positional argument repackaging for the migrated methods.
- Concrete migration/deletion: all ReMatch methods and the existing list.append,
  dict.get/setdefault, file.write, csv.writerow, str.join/split/replace/affix methods.
  Replace all ten opaque Direct* sentinels and their duplicated invocation chain
  with the same receiver-method convention; replace migrated member-factory
  closures with shared definitions. Preserve real dynamic/presence wrappers and
  the measured no-argument/native-return operations; do not build a new call arena.
  Retire helpers made orphaned by this migration. Keep actual native-body guards.
- Completion milestone: no old migrated factory/marker path survives; receiver
  snapshots, descriptors/rebinding, method metadata/hash, invalid counts/keywords,
  omitted defaults, argument/error/admission order, native proofs, genuine async
  protocols/current token, managed stack, first refusal, funded operands and
  awaited cleanup pass focused checks. No public API/policy or regex dialect change.
- Local complete jobs establish allocation−29.47%sync/async with essentially flat
  controls and identical admitted peaks. Contradictory/adverse desktop elapsed
  (sync regex+31–81%) is retained, not a CPU claim. Quiet B393 comparison pending.
  Bound allocation comparison and quiet complete regex extraction plus JSON/text/
  CSV controls decide retention/refinement. Keep all adverse results. Separate
  architecture, allocation, and demonstrated elapsed/CPU; no predicted speedup.
  Batch full delivery with pendingR40 at a coherent boundary, then resume roadmap.

| Further boundary | Evidence/design obligation | Acceptance / displaced work |
| --- | --- | --- |
| Complete calls/frames | R39 aggregate/inclusive totals alone are insufficient. Build on current direct operands/layouts/final backing/deferred contexts | Remove a real binding/context/continuation phase; helpers/constructors/closures/suspension, spans/stack/borrows preserved. |
| Scoped scalar transport | Boxed counters with reads/publication/retirement; small-add~3% alone does not justify universal tags | Exact promotion, identity/aliases/hash/projection, checked arithmetic and substantial-storage admission. |
| Per-record construction | Shared keys, completed CSV values and direct matching prefixes already exist; completed JSON is synchronous | Remove an actual extra capacity/copy phase; headers/duplicates/hooks/order/reentry/aliases/retained capacity and overlap preserved. |
| Text/storage | Bulk casing/split, file windows and direct output already exist; do not revive general windows from allocation shares | Final representation changes must preserve Unicode/context/scalars/hash/index/identity, ownership and current cancellation. |
| Frontend/setup | Shared lexical/class/parameter facts and R38 demand pruning are delivered; fixed builtins/signatures shared | Remove an actual duplicate walk/retained representation. Preserve diagnostics, shared-graph correction and fresh per-run isolation. Compile measured separately. |

**Completion of a redesign:** displaced old work/storage removed; focused Python,
cancellation/first-refusal/alias/cleanup checks; bounded precise allocation and
quiet before/after with unchanged controls. Separate simplification, allocation and
demonstrated elapsed/CPU effects. Temporary setbacks need a completion milestone
and explicit regression-debt decision. Batch full Windows/Ubuntu/actual11/10/
original Stress/installed consumers at a coherent boundary, including pending R40.
Then continue the roadmap; publication remains postponed.

## Experimental policy

Timeouts, unstable unchanged controls and inconclusive data establish uncertainty,
not permanent design rejection. Permit bounded evidence-driven confirmation,
refinement or measurement correction; never repeat until favorable. Size runs for
the quiet VM and preserve every adverse/original failed condition, with verified
source/image provenance. Percentages inform retention, not automatic vetoes of
useful simplification. No broad CPU/parity/compound claim from variable data.
Record completed qualification once. No arbitrary one-attempt/permanently-closed rule.

## Priority 2 — independent regex architecture

R40 is retained1971487a: existing cursor seeks bidirectionally from the nearer known
boundary; constant nearby lookbehind avoids repeated prefixes. All leases/owners/
validation and current cancellation remain; no provider release or API needed.
Focused/VM/active-scan outcomes above; full delivery batched later. No unchanged
retiming selected, no general linear matching guarantee. Evidence under
benchmarks/results/2026-11-07-regex-scalar-cursor/.

Continue Lython-owned Python/nativeUTF8 semantics: byte ranges/scalar positions,
original windows, captures/replacements/errors/cache ownership and actual current-
token work. Build on U04/R23. Development producers and adapter-local bridges
support contract/semantic work; publication defers only affected final qualification.

Missing producer capabilities remain precise: DetailedData has no independent
Prepare working owner; native names lack enumeration; cursors mix creation/current
token authority. Exactdev48 adds no documented API removing these limits. Keep
conservative preflight/local conversion/qualified CTS bridge where needed; qualify
final released immutable inputs and managed safety separately. No silent promotion,
sibling edits, dialect fallback, regex quota or abandoned background matching.

## Constraints / current resources

AGENTS.md is authoritative. Fully managed/memory-safe; no unsafe/Unsafe/pointers/
PInvoke/native probing. Preserve managed stack/recursion, current cancellation,
host-mediated contained paths, cycles, shared coarse admission/preflights/overlap,
retained aliases and awaited actual users. First memory refusal is terminal. No
tracing/weak reclamation/forced GC/fuel/quotas/caps/hidden default allowance.
Bounded host-driven streaming; XML depth constraint remains.

No overlapping local builds/tests. Preserve original Stress scales/timeouts and
GC nonparallel collections. Terminal CI42351006316,42347124351 and earlier receipts
are cached/committed: never query them again. No active CI or local measurement. R41 source/images frozenbfc2e427; focused11
checks276internal/1279public plus10final regressions pass. B393 four warm complete
regex/JSON/text/CSV jobs is the next owned comparison:210s+30s stop+40s margin;
observe only after280s. No automatic restart or early service query.

Quiet VM lokad@20.166.121.73,key~/.ssh/id_lython-bench.pem. B385–B392 terminal/
archived; no more service queries. B390 failed before worker creation; original
condition archived before the single B391 setup correction. B392 all5jobs143.75s,
observed after its210+30+40s bound; all users joined/fixtures removed/archive verified.
Persistent inputs/evidence, archive/verify raw RAM traces under lease before removal,
record owner+stop+margin before observing, never restart on observation timeout.
Disk nearly full: retire only exact redundant expanded files with independent
committed backup, matching hashes, ended users and file/directory link validation.
Resume R41 selected migration; publication/tagging postponed.
