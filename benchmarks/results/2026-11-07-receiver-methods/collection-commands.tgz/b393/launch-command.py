from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'receiver-methods-b393-20261107'
reference=base/'regex-scalar-cursor-b392-20261107/candidate'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(2100145+1)
 assert len(payload)==2100145 and hashlib.sha256(payload).hexdigest()=='48c979224f7d7e307b07ba2bfb16b41e912d30c78f031ded1fcfaea36c184575'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+2*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 shutil.copytree(reference,root/'reference',symlinks=True,copy_function=os.link)
 (root/'cpython-worker.py').symlink_to(base/'prepared-call-layout-b384-20261107/cpython-worker.py')
 shutil.copytree(reference,root/'candidate',symlinks=True,copy_function=os.link)
 (root/'candidate/Lokad.Lython.dll').unlink()
 (root/'current-core.dll').replace(root/'candidate/Lokad.Lython.dll')
 for name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Utf8Regex.dll']:
  for role in ['candidate','reference']:
   (root/role/name).unlink()
   os.link(root/('current-'+name),root/role/name)
 identity=json.loads((root/'identity.json').read_text())
 for role in ['candidate','reference']:
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
  for name,digest in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 assert 'assert len(jobs)==4 ' in (root/'collect.py').read_text()
 assert "len(r['jobs'])==4" in (root/'archive-owned.py').read_text()
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndEveryAuxiliaryVerifiedInBothRoles=True,
  allFourJobsValidated=True,ownerSeconds=210,stopSeconds=30,marginSeconds=40)
 assert setup['freeBytes']>2*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b393-receiver-methods-20261107','--property=User=lokad',
 '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=210','--property=TimeoutStopSec=30',
 '--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
