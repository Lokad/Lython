from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name("borrow-forwarded-integers-20261124")
comparison = lab / "comparison"
quiet = comparison / "quiet"
quiet.mkdir(parents=True, exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
save = lambda p, v: p.write_text(json.dumps(v, indent=2) + "\n", encoding="utf-8", newline="\n")
donor_identity = read(donor / "comparison/quiet/identity.json")
core = "Lokad.Lython.dll"
current = lab / "windows/bin/Lokad.Lython/release_net11.0" / core
reference_core = lab.with_name("shared-callable-iterator-type-20261124") / "windows/bin/Lokad.Lython/release_net11.0" / core
assert sha(reference_core) == "2f526d087a46b8af3cc1f879d562471df4b4f111b350cedd2545c9e844a4fbe0"
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
assert head.startswith("b807a4eda")
assert not subprocess.check_output(["git", "diff", "3abb51e6e", head, "--", "src", "tests"], cwd=repo)
donor_image = donor / "candidate"
donor_files = donor_identity["imageFiles"]["candidate"]
assert {p.name: sha(p) for p in donor_image.iterdir()} == donor_files
assert sha(current) not in (sha(reference_core), donor_files[core])
cores = {"reference": reference_core, "candidate": current}
images = {role: donor_files | {core: sha(path)} for role, path in cores.items()}
for role, manifest in images.items():
    image = lab / role
    image.mkdir(exist_ok=True)
    for name in manifest:
        shutil.copyfile(cores[role] if name == core else donor_image / name, image / name)
    assert len(manifest) == 32 and {p.name: sha(p) for p in image.iterdir()} == manifest

rule_cases = ["scripts.rule-default-closures", "scripts.annotated-rule-closures", "scripts.captured-rule-closures"]
report = "diagnostic.text-summary.nonlocal-computed-width.large"
jobs = [[case, mode] for case in rule_cases for mode in ("warm", "compile-run")] + [[report, "warm"]]
expected_ids = set(rule_cases) | {report}
expected = quiet / "representative.json"
fixture = read(donor / "comparison/quiet/representative.json")
fixture["cases"] = [row for row in fixture["cases"] if row["id"] in expected_ids]
assert {row["id"] for row in fixture["cases"]} == expected_ids
save(expected, fixture)
save(quiet / "jobs.json", {"warm": jobs})

patch = lab / "candidate.patch"
patch.write_bytes(subprocess.check_output(["git", "diff", "--binary", "--", "src", "tests"], cwd=repo))
assert b"ExecutableDefinitionKind" in patch.read_bytes()
identity = dict(sourceRevision=head, comparisonRevision=head, sourcePatchSHA256=sha(patch),
    purpose="Share one prepared descriptor and dispatch for lambda and statement definitions",
    imageFiles=images, expectedCPythonSHA256=donor_identity["expectedCPythonSHA256"],
    cpythonWorkerSHA256=donor_identity["cpythonWorkerSHA256"],
    coreSHA256={role + suffix: files[core] for role, files in images.items() for suffix in ("", "-control")},
    catalogs={name: {"sha256": sha(quiet / name)} for name in ("representative.json", "jobs.json")})
save(quiet / "identity.json", identity)

collector = (donor / "comparison/quiet/collect.py").read_text(encoding="utf-8").replace("b1631-fixtures", "b1635-fixtures")
collector = collector.replace("len(jobs) == 6", "len(jobs) == 7")
compile(collector, "collect.py", "exec")
(quiet / "collect.py").write_text(collector, encoding="utf-8", newline="\n")
shutil.copyfile(donor / "comparison/quiet/run.sh", quiet / "run.sh")
assert b"\r" not in (quiet / "run.sh").read_bytes()
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
python = Path("C:/Python313/python.exe")
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
worker = lab.with_name("json-file-drain-20261124") / "comparison/cpython-worker.py"
assert sha(worker) == identity["cpythonWorkerSHA256"]
for role in images:
    output = comparison / (role + "-verify.json")
    subprocess.run([dotnet, lab / role / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
                    "--catalog", expected, "--dotnet", dotnet, "--python", python,
                    "--python-worker", worker, "--out", output], env=env, cwd=repo, check=True, timeout=60)
    proof = read(output)
    assert proof["state"] == "Completed" and proof["caseCount"] == len(expected_ids)
    assert proof["catalogSha256"] == sha(expected) and proof["launched"]["library"]["sha256"] == images[role][core]

payload = quiet / "payload.tar.gz"
with tarfile.open(payload, "w:gz", compresslevel=3) as archive:
    for name in ("identity.json", "jobs.json", "representative.json", "collect.py", "run.sh"):
        archive.add(quiet / name, arcname=name, recursive=False)
    for role in images:
        archive.add(lab / role / core, arcname=role + "-core.dll", recursive=False)
save(quiet / "upload.json", dict(root="shared-prepared-definitions-b1635-20261124",
     reference="borrow-forwarded-integers-b1631-20261124", payloadSHA256=sha(payload), payloadBytes=payload.stat().st_size))
save(lab / "verified-raw-replicas.json", [])

launch = (donor / "quiet.py").read_text(encoding="utf-8")
launch = launch.replace("lython-b1631-borrow-forwarded-integers-", "lython-b1635-shared-prepared-definitions-").replace("b1631-", "b1635-")
oldsha = read(lab.with_name("shared-function-defaults-20261124") / "comparison/quiet/terminal-status.json")["receipt"]["archiveSHA256"] if False else "a53e332b673550adccd934c6d4d536c703ac159f053bd27619774312058960e8"
newsha = read(donor / "comparison/quiet/terminal-status.json")["receipt"]["archiveSHA256"]
assert oldsha in launch
launch = launch.replace(oldsha, newsha).replace("RuntimeMaxSec=270", "RuntimeMaxSec=310").replace("seconds=202", "seconds=235")
launch = launch.replace("'collect.py','candidate-core.dll'", "'collect.py','candidate-core.dll','reference-core.dll'")
launch = launch.replace("name=='Lokad.Lython.dll' and role=='candidate'", "name=='Lokad.Lython.dll'")
compile(launch, "quiet.py", "exec")
(lab / "quiet.py").write_text(launch, encoding="utf-8", newline="\n")
print("Sealed both 32-file images and verified four CPython goldens.")
