from pathlib import Path
import hashlib, json, os, shutil, subprocess, textwrap

lab = Path(__file__).resolve().parent
sdk = Path.home() / ".dotnet11"
sources = {
    "class default versus captured enclosing parameter": """
        def make(label):
            class Example:
                label = 'class'
                f = lambda self, retained=label: (retained, label)
            return Example
        print(make('outer')().f())
    """,
    "annotation lambda follows current capture": """
        def make(seed):
            def helper(value: (lambda: seed)) -> int: return value
            seed += 1
            return helper.__annotations__['value']
        reader = make(3)
        print(reader())
    """,
    "definition effects and shared defaults": """
        def make():
            shared = []
            def mark(label):
                print(label)
                return shared
            def target(value=mark('default'), *, opt=mark('keyword')) -> mark('annotation'):
                return value is opt
            other = lambda v=mark('lambda'): v
            print(target(), other() is shared, target.__annotations__['return'] is shared)
        make()
    """,
    "generator lambda and its retained default": """
        shared = []
        factory = lambda value=shared: (yield value)
        first = factory()
        second = factory()
        print(next(first) is shared, next(second) is shared)
        try:
            first.send(19)
        except StopIteration as error:
            print(error.value)
        second.close()
    """,
    "second factory member fails before publishing tuple": """
        def make(seed):
            def apply(value, offset=seed%7, *, use=True): return value+offset if use else value
            alternative = lambda value, offset=5//seed: value-offset
            return apply, alternative
        left, right = 'left', 'right'
        try:
            left, right = make(0)
        except ZeroDivisionError:
            print(left, right)
        left,right=make(9223372036854775809)
        print(left(10),right(10))
    """,
}
sources = {name: textwrap.dedent(source).strip() + "\n" for name, source in sources.items()}
input_json = json.dumps(list(sources.values()), ensure_ascii=False)
(lab / "oracle-input.json").write_text(json.dumps(sources, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
donor = lab.with_name("borrow-forwarded-integers-20261124")
manifest = json.loads((lab / "comparison/quiet/identity.json").read_text(encoding="utf-8"))["imageFiles"]
for role in ("reference", "candidate"):
    probe = lab / ("probe-" + role)
    shutil.copytree(donor / ("probe-" + role), probe, dirs_exist_ok=True)
    shutil.copyfile(lab / role / "Lokad.Lython.dll", probe / "Lokad.Lython.dll")
    assert hashlib.sha256((probe / "Lokad.Lython.dll").read_bytes()).hexdigest() == manifest[role]["Lokad.Lython.dll"]
    for mode in ("sync", "async"):
        args = [sdk / "dotnet.exe", probe / "LythonProbe.dll", "--batch-json", "--compare-python", "--python", "C:/Python313/python.exe"]
        if mode == "async": args.append("--async")
        result = subprocess.run(args, env=env, input=input_json, encoding="utf-8", capture_output=True, timeout=45)
        raw = result.stdout
        (lab / f"oracle-{role}-{mode}.jsonl").write_text(raw, encoding="utf-8")
        print(role, mode, result.returncode, result.stderr.strip())
        for (name, _), row in zip(sources.items(), raw.splitlines(), strict=True):
            report = json.loads(row)
            if report["Matches"]: print(" ", name, "match")
            else: print(" ", name, "mismatch", report["Lython"], report["CPython"])

