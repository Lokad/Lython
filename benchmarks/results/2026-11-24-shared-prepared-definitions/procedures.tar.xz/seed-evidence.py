from pathlib import Path
import hashlib, json, shutil, statistics, subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
out = repo / "benchmarks/results/2026-11-24-shared-prepared-definitions"
quiet = lab / "comparison/quiet"
read = lambda file: json.loads(file.read_text(encoding="utf-8-sig"))
identity = read(quiet / "identity.json")
patch = subprocess.check_output(["git", "diff", "--binary", "--", "src", "tests"], cwd=repo)
assert patch == (lab / "candidate.patch").read_bytes()
assert hashlib.sha256(patch).hexdigest() == identity["sourcePatchSHA256"]
counts = {}
images = identity["imageFiles"]
compiled = {role: read(lab / f"{role}-compiler-owner.json") for role in images}
for role in images:
    verified = read(lab / "comparison" / f"{role}-verify.json")
    assert verified["state"] == "Completed" and verified["caseCount"] == 4
    assert compiled[role]["coreSHA256"] == images[role]["Lokad.Lython.dll"]
    for mode in ("sync", "async"):
        rows = [json.loads(line) for line in (lab / f"oracle-{role}-{mode}.jsonl").read_text(encoding="utf-8").splitlines()]
        assert len(rows) == 5 and all(row["Matches"] for row in rows)
    counts[role] = {"workloadGoldens":4,"cpythonSync":5,"cpythonAsync":5}
compile_summary = []
for reference, candidate in zip(compiled["reference"]["rows"], compiled["candidate"]["rows"], strict=True):
    assert reference["id"] == candidate["id"]
    compile_summary.append(dict(case=reference["id"],
        compileAllocationBytes=[statistics.median(implementation["allocatedBytes"]) for implementation in (reference,candidate)],
        retainedAdmission=[implementation["retainedAdmission"] for implementation in (reference,candidate)]))
(out / "compiler-ownership.json").write_text(json.dumps(compile_summary,indent=2)+"\n",encoding="utf-8",newline="\n")
for path in [quiet / "identity.json", lab / "allocation-summary.json", lab / "staging-custody.json"]:
    shutil.copyfile(path, out / path.name)
(lab / "focused-checks.json").write_text(json.dumps(dict(
    platformSuites={platform:{"net11.0":{"whiteBox":1087,"publicApi":2709},"net10.0":{"publicApi":128}}
        for platform in ("Windows","Ubuntu")}, images=counts),indent=2)+"\n",encoding="utf-8",newline="\n")
