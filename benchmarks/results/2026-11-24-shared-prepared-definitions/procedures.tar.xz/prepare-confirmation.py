from pathlib import Path
import hashlib, json, shutil, tarfile

lab = Path(__file__).resolve().parent
first = lab / "comparison/quiet"
retry = lab / "confirmation"
quiet = retry / "comparison/quiet"
quiet.mkdir(parents=True, exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
save = lambda p, v: p.write_text(json.dumps(v, indent=2) + "\n", encoding="utf-8", newline="\n")
identity = read(first / "identity.json")
for role, files in identity["imageFiles"].items():
    assert {path.name: sha(path) for path in (lab / role).iterdir()} == files
shutil.copyfile(first / "representative.json", quiet / "representative.json")
shutil.copyfile(first / "run.sh", quiet / "run.sh")
assert sha(quiet / "representative.json") == identity["catalogs"]["representative.json"]["sha256"]
jobs = [
    ["scripts.captured-rule-closures", "compile-run"],
    ["diagnostic.text-summary.nonlocal-computed-width.large", "warm"],
    ["scripts.annotated-rule-closures", "compile-run"],
]
save(quiet / "jobs.json", {"warm": jobs})
identity["catalogs"]["jobs.json"]["sha256"] = sha(quiet / "jobs.json")
identity["purpose"] = "Confirm the two adverse B1635 result lanes using the same images and catalog"
save(quiet / "identity.json", identity)
collector = (first / "collect.py").read_text(encoding="utf-8").replace("len(jobs) == 7", "len(jobs) == 3").replace("b1635-fixtures", "b1636-fixtures")
(quiet / "collect.py").write_text(collector, encoding="utf-8", newline="\n")
payload = quiet / "payload.tar.gz"
with tarfile.open(payload, "w:gz", compresslevel=3) as archive:
    for name in ("identity.json", "jobs.json", "representative.json", "collect.py", "run.sh"):
        archive.add(quiet / name, arcname=name, recursive=False)
save(quiet / "upload.json", dict(root="shared-prepared-definitions-b1636-20261124",
    reference="shared-prepared-definitions-b1635-20261124", payloadSHA256=sha(payload), payloadBytes=payload.stat().st_size))
save(retry / "verified-raw-replicas.json", [])
launch = (lab / "quiet.py").read_text(encoding="utf-8")
prior_receipt = read(first / "terminal-status.json")["receipt"]
assert prior_receipt["complete"] and sha(first / "observations.tar.xz") == prior_receipt["archiveSHA256"]
launch = launch.replace("6367342c7bd6e21d8aa7d2972822a4cd017a3afd3607d47660eea144daec1ece", prior_receipt["archiveSHA256"])
launch = launch.replace("b1635-", "b1636-").replace("RuntimeMaxSec=310", "RuntimeMaxSec=175").replace("seconds=235","seconds=113")
launch = launch.replace(",'candidate-core.dll','reference-core.dll'","")
old = """   if name=='Lokad.Lython.dll':
    (root/(role+'-core.dll')).rename(image/name)
   else:
    os.link(reference/'candidate'/name,image/name)"""
assert old in launch
launch = launch.replace(old, "   os.link(reference/role/name,image/name)")
compile(launch, "quiet.py", "exec")
(retry / "quiet.py").write_text(launch, encoding="utf-8", newline="\n")
print("Verified identical images, catalog and completed donor archive.")
