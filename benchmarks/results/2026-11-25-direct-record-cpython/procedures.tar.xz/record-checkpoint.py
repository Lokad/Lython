from pathlib import Path
import json

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
data=json.loads((lab / "external/summary.json").read_text(encoding="utf-8"))
assert data["source"].startswith("7120ee55e") and data["timedBatches"]==308

def ratio(case, lane):
    row=next(r for r in data["rows"] if r["case"]==case and r["lane"]==lane)
    return "–".join(f"{p:.3f}" for p in row["ratio"]) + "×"

shipment="diagnostic.shipment-routing-callbacks"
ordinary="diagnostic.generated-ordinary-definitions"
text=f"""The latest external checkpoint uses retained source `7120ee55e` and stock
CPython 3.13.16. The 11 phases separate compilation, warm execution and
compile-to-result. Shipment is {ratio(shipment, "warm")} warm sync and
{ratio(shipment, "warm-async")} warm async. File-fed map is
{ratio("diagnostic.shipment-file-fed-map", "warm-async")} warm async. Ordinary definitions are
{ratio(ordinary, "warm")} warm and {ratio(ordinary, "compile-run")} through result. Defaulted rules
are {ratio("scripts.rule-default-closures", "compile-run")} through result.
[External comparison](benchmarks/results/2026-11-25-direct-record-cpython/README.md) ·
[Earlier checkpoint](benchmarks/results/2026-11-25-retained-workspace-cpython/README.md).
"""
p=repo/"PLAN.md"
source=p.read_text(encoding="utf-8")
a=source.index("The latest external checkpoint")
b=source.index("\n## Whole-script priorities",a)
source=source[:a]+text+source[b:]
a=source.index("1. **Refresh the representative CPython checkpoint.")
b=source.index("2. **Remove complete",a)
source=source[:a]+source[b:]
for heading in ("Remove complete function construction","Consolidate executable operand","Identify one remaining storage"):
    marker="".join(line for line in source.splitlines() if f"**{heading}" in line)
    assert marker.startswith(("2.","3.","4.")),marker
    source=source.replace(marker,str(int(marker[0])-1)+marker[1:],1)
a=source.index("\nThe latest external checkpoint")
source=source[:a]+"""
Direct CSV admission allocates 4.37–13.93% less across four workloads.
File-fed map async CPU falls 1.70–5.13% and 5.30–8.38% in the two blocks.
Quoted invoice CPU and the unchanged text control remain uncertain.
[Paired evidence](benchmarks/results/2026-11-25-csv-direct-record-admission/README.md).
"""+source[a:]
p.write_text(source,encoding="utf-8",newline="\n")

p=repo/"benchmarks/EXPERIMENTS.md"
source=p.read_text(encoding="utf-8")
anchor="[B1719 direct CSV storage admission]"
assert source.count(anchor)==1
record="""[B1720 current CPython checkpoint](results/2026-11-25-direct-record-cpython/README.md)
measures retained `7120ee55e` against stock CPython 3.13.16. Eleven phases and
308 verified batches separate warm execution, compilation and time to result.
The older B1713 observations remain available at their own revision.

"""
p.write_text(source.replace(anchor,record+anchor),encoding="utf-8",newline="\n")
