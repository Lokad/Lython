from pathlib import Path
import json,re

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=repo/"benchmarks/results/2026-11-25-direct-record-cpython"
data=json.loads((out/"summary.json").read_text(encoding="utf-8"))
source=data["source"][:9]
assert source=="7120ee55e" and data["timedBatches"]==308
short={
    "diagnostic.shipment-file-fed-map":"File-fed CSV quantity map",
    "diagnostic.text-summary.nonlocal-computed-width.large":"Short Unicode word-count report with a nonlocal helper",
    "diagnostic.generated-ordinary-definitions":"Generated ordinary definitions",
    "diagnostic.shipment-routing-callbacks":"Shipment callback report",
    "scripts.json-lines-shipment.default-options.large":"JSON Lines export with default options",
    "scripts.csv-invoice.method-policy.quoted-control":"Quote-heavy CSV policy invoice",
    "scripts.rule-default-closures":"Generated rules with defaults",
}
table_rows={}
rows=[]
for row in data["rows"]:
    label=short[row["case"]]
    lane=row["lane"]
    if lane=="warm-async":
        label+= ", Lython `RunAsync`"
    if lane=="compile":
        label+=", 8,641 B of source"
    phase={"warm":"Warm sync","warm-async":"Warm async","compile-run":"Compile-to-result","compile":"Compilation only"}[lane]
    def value(key,precision=5,suffix=" ms"):
        return "–".join(f"{x:.{precision}f}" for x in row[key])+suffix
    times=(value("lythonMs"),value("cpythonMs"),value("ratio",3,"×"))
    spread=max(row["lythonControlPercent"],row["cpythonControlPercent"])
    status=f"Diagnostic. Worker spread up to {spread:.2f}%. [B1720]." if spread>=3 else "Diagnostic. [B1720]."
    table_rows[label,phase]=(times,status)
    rows.append("| "+" | ".join((label,phase,*times,value("widerCpuRatio",3,"×"),f"{row['lythonControlPercent']:.2f}% / {row['cpythonControlPercent']:.2f}%"))+" |")
lines="\n".join(rows)
(out/"README.md").write_text(f"""# B1720 CSV admission checkpoint against CPython

The frozen image matches the production source of `{source}`, including
direct completed-row and dictionary-shell admission. The Azure F4as_v7
running Ubuntu 24.04.4
measured .NET 11 RC3 and stock CPython 3.13.16 on November 25, 2026 UTC.
All 32 measured image files and seven complete output/file goldens
were verified. Both quiet checks and all 308 timed batches passed.

Each phase warms two processes per engine for five full-request seconds
apiece. Each process contributes seven rotated batches targeting 0.46
request seconds. Ratios divide Lython by CPython and span the four
pairings of worker medians. Async rows use Lython's `RunAsync` and
the same Python script and file API on CPython.

Warm and compile-to-result elapsed include mediated RAM-backed I/O when
applicable, result/file verification and cleanup. Lython uses its efficient
ranged-read and append host with an explicitly supplied shared, unbounded
memory allowance. CPython uses native I/O. Compilation includes disposal
of preceding compiled owners in each batch.
Fixture reset and framing are included in the wider CPU clock. Startup and
final process teardown are outside these measurements.

| Workload | Phase | Lython | CPython | Elapsed ratio | Wider CPU ratio | Elapsed worker spread Lython / CPython |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
{lines}

This checkpoint measures the retained source. Separate paired Lython
runs record the CSV allocation savings and the adverse text-control result.
The external rows are diagnostic. Cross-checkpoint ratios do not attribute
speed changes to the CSV admission patch.

[Delivery checks](https://github.com/Lokad/Lython/actions/runs/45604807176) ·
[Identity](identity.json) · [Timings](summary.json) · [Observations](observations.tar.xz) ·
[Terminal receipt](terminal-status.json) · [Procedures](procedures.tar.xz) ·
[Paired CSV evidence](../2026-11-25-csv-direct-record-admission/README.md) ·
[Previous checkpoint](../2026-11-25-retained-workspace-cpython/README.md).
""",encoding="utf-8",newline="\n")

doc=repo/"docs/BENCHMARKS.md"
s=doc.read_text(encoding="utf-8")
updated=set()
def substitute(m):
    columns=m.group(0)[2:-2].split(" | ")
    if len(columns)!=6: return m.group(0)
    label,second=columns[:2]
    if second in ("Compile-to-result","Compilation only"): phase=second
    else: phase="Warm async" if "RunAsync" in label else "Warm sync"
    key=label,phase
    if key not in table_rows or key in updated: return m.group(0)
    updated.add(key)
    (lt,pt,ratio),status=table_rows[key]
    return "| "+" | ".join((label,second,lt,pt,ratio,status))+" |"
s=re.sub(r"^\| [^\n]+ \|$",substitute,s,flags=re.M)

assert len(updated)==len(table_rows)==11
anchor = "B1720 measures a source-equivalent build of\nqualified `75af75769` on November 25, 2026 UTC."
# The introduction and historical links outside the table still refer to B1713.
anchor = anchor.replace("B1720", "B1713")
assert s.count(anchor)==1
s=s.replace(anchor, "B1720 measures the source of\n`7120ee55e` on November 25, 2026 UTC. B1713 measures older `75af75769`\nthe same day.")
s=s.replace("[B1713] · [B1705]", "[B1720] · [B1713] · [B1705]",1)
anchor="[B1713]: ../benchmarks/results/2026-11-25-retained-workspace-cpython/README.md"
assert s.count(anchor)==1
s=s.replace(anchor, "[B1720]: ../benchmarks/results/2026-11-25-direct-record-cpython/README.md\n"+anchor)
doc.write_text(s,encoding="utf-8",newline="\n")
