from pathlib import Path
import subprocess
import sys

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.with_name("retained-workspace-cpython-20261125")
source = subprocess.check_output(["git", "rev-parse", sys.argv[1]], cwd=repo, text=True).strip()
text = (prior / "prepare.py").read_text(encoding="utf-8")

def replace(before, after):
    global text
    assert before in text, before
    text = text.replace(before, after)

replace('"iteration-native-storage-prepared-20261125"', '"csv-direct-record-admission-20261125"')
replace('"retained-csv-cpython-20261125"', '"retained-workspace-cpython-20261125"')
replace('source=git("rev-parse","75af75769").decode().strip()', f'source="{source}"')
replace('measured=git("rev-parse","7d24cfe9a").decode().strip()\n'
        'assert git("diff","--name-only",source,measured,"--","src","tests")==b""',
        'measured=source')
replace('location="retained-workspace-cpython-b1713-20261125"', 'location="direct-record-cpython-b1720-20261125"')
a = text.index('cases={c["id"]:c for c in catalog["cases"]}')
b = text.index('save(quiet/"representative.json"', a)
text = text[:a] + 'jobs=read(previous/"external/jobs.json")\nassert len(jobs)==11 and len(catalog["cases"])==7\n' + text[b:]
replace('"B1708b"', '"B1719"')
replace('"B1708b nonincremental Release core. Source-equivalent delivery checkpoint."',
        '"B1719 nonincremental Release core, verified against the delivered source patch."')
replace('replace("b1705-fixtures","b1713-fixtures")', 'replace("b1713-fixtures","b1720-fixtures")')
a = text.index('collect=collect.replace(')
b = text.index('for name,source_text', a)
text = text[:a] + '''collect=collect.replace("Qualified retained runtime after shared CSV pulls and native callback workspace borrowing",
      "Retained CSV record admission checkpoint against CPython")
summary=(previous/"external/summarize.py").read_text(encoding="utf-8")
''' + text[b:]
a = text.index('launch=(previous/"quiet.py")')
b = text.index('anchor="assert donor', a)
text = text[:a] + '''launch=(previous/"quiet.py").read_text(encoding="utf-8").replace(
    "lython-b1713-retained-workspace-cpython","lython-b1720-direct-record-cpython").replace("b1713","b1720")
''' + text[b:]
replace('archiver=(previous/"archive.py").read_text(encoding="utf-8").replace("2026-11-25-retained-csv-cpython","2026-11-25-retained-workspace-cpython").replace(\n'
        '    \'summary["timedBatches"] == 280 and len(summary["rows"]) == 10\',\'summary["timedBatches"] == 308 and len(summary["rows"]) == 11\').replace("Archived 280","Archived 308")',
        'archiver=(previous/"archive.py").read_text(encoding="utf-8").replace("2026-11-25-retained-workspace-cpython","2026-11-25-direct-record-cpython")')
compile(text, "prepare.py", "exec")
(lab / "prepare.py").write_text(text, encoding="utf-8", newline="\n")
