from pathlib import Path
import json
import sys

lab = Path(__file__).resolve().parent
previous = lab.with_name("retained-workspace-cpython-20261125")
template = (previous / "write-docs.py").read_text(encoding="utf-8")
template = template[:template.index('p=repo/"PLAN.md"')]

def edit(old, new):
    global template
    assert old in template, old
    template = template.replace(old, new, 1)

edit('out=repo/"benchmarks/results/2026-11-25-retained-workspace-cpython"', 'out=repo/"benchmarks/results/2026-11-25-direct-record-cpython"')
edit('source=="75af75769"', 'source=="7120ee55e"')
template = template.replace('B1713', 'B1720')
edit("Qualified runtime against CPython", "CSV admission checkpoint against CPython")
edit("""The frozen `7d24cfe9a` image is source-equivalent to the qualified
`{source}` runtime, including shared CSV source progression and native
callback workspace borrowing. The Azure F4as_v7 running Ubuntu 24.04.4""",
     """The frozen image matches the production source of `{source}`, including
direct completed-row and dictionary-shell admission. The Azure F4as_v7
running Ubuntu 24.04.4""")
edit("ranged-read and append host with shared memory admission active. CPython\nuses native I/O. Compilation-only includes disposal of compiled owners.", 
     "ranged-read and append host with an explicitly supplied shared, unbounded\nmemory allowance. CPython uses native I/O. Compilation includes disposal\nof preceding compiled owners in each batch.")
edit("""These results describe the measured revision. The dictionary prototypes
were measured separately. Earlier CPython observations remain available
without combining ratios across machine collections.""",
     """This checkpoint measures the retained source. Separate paired Lython
runs record the CSV allocation savings and the adverse text-control result.
The external rows are diagnostic. Cross-checkpoint ratios do not attribute
speed changes to the CSV admission patch.""")
edit("45574754646", "45604807176")
edit("[Previous checkpoint](../2026-11-25-retained-csv-cpython/README.md).",
     "[Paired CSV evidence](../2026-11-25-csv-direct-record-admission/README.md) ·\n[Previous checkpoint](../2026-11-25-retained-workspace-cpython/README.md).")

template = template[:template.index("missing=set(table_rows)-updated")] + """
assert len(updated)==len(table_rows)==11
anchor = "B1720 measures a source-equivalent build of\\nqualified `75af75769` on November 25, 2026 UTC."
# The introduction and historical links outside the table still refer to B1713.
anchor = anchor.replace("B1720", "B1713")
assert s.count(anchor)==1
s=s.replace(anchor, "B1720 measures the source of\\n`7120ee55e` on November 25, 2026 UTC. B1713 measures older `75af75769`\\nthe same day.")
s=s.replace("[B1713] · [B1705]", "[B1720] · [B1713] · [B1705]",1)
anchor="[B1713]: ../benchmarks/results/2026-11-25-retained-workspace-cpython/README.md"
assert s.count(anchor)==1
s=s.replace(anchor, "[B1720]: ../benchmarks/results/2026-11-25-direct-record-cpython/README.md\\n"+anchor)
doc.write_text(s,encoding="utf-8",newline="\\n")
"""
compile(template, "write-docs.py", "exec")
(lab / "write-docs.py").write_text(template, encoding="utf-8", newline="\n")
if len(sys.argv) > 1:
    subprocess = __import__("subprocess")
    subprocess.run([sys.executable, "-X", "utf8", lab / "write-docs.py"], check=True)
