from pathlib import Path
import hashlib, json, shutil, tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'external'
out=repo/'benchmarks/results/2026-11-25-arithmetic-call-cpython'
read=lambda path:json.loads(path.read_text(encoding='utf-8'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
terminal=read(quiet/'terminal-status.json')
summary=read(quiet/'summary.json')
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
receipt=terminal['receipt']
assert sha(quiet/'observations.tar.xz')==receipt['archiveSHA256']
assert all(receipt[key] for key in ('complete','allWorkersJoined','guestFixturesRemoved',
    'quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert summary['source']==identity['sourceRevision'] and summary['timedBatches']==112
assert len(summary['rows'])==4 and {f.name:sha(f) for f in (lab/'candidate').iterdir()}==identity['imageFiles']['candidate']
shape=read(lab/'shipment-shape.json')
assert shape['coreSHA256']==identity['coreSHA256']['candidate']
methods={m['name']:m for m in shape['rows'][0]['methods']}
assert methods['choose']['directReturn'] and methods['tally']['opcodeCounts']['ApplyOperation']==6
out.mkdir(exist_ok=True)
shutil.copyfile(lab/'shipment-shape.json',out/'shipment-shape.json')
for name in ('summary.json','identity.json','terminal-status.json','observations.tar.xz'):
    shutil.copyfile(quiet/name,out/name)
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for name in ('prepare.py','quiet.py','finish.py','prepare.log','launch-console.log','retrieve.log',
                 'external/collect.py','external/summarize.py','external/run.sh',
                 'external/candidate-verify.json','external/storage-custody.json','external/upload.json',
                 'inspection/Program.cs','inspection/ArithmeticCallInspection.csproj','inspection.log'):
        bundle.add(lab/name,arcname=name,recursive=False)

    for failure in sorted((lab/'failed-first').iterdir()):
        assert failure.is_file()
        bundle.add(failure,arcname='failed-first/'+failure.name,recursive=False)
