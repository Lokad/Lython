set -eu
root=/home/lokad/lython-bench-checks/shared-metadata-cpython-b1030-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
