from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).resolve().parent
donor=lab.parent/'function-record-keys-r601'
prior=lab.parent/'definition-and-split-cpython-r596'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen=donor/'frozen/candidate'
manifest=load(donor/'frozen-identity.json')
files=manifest['images']['candidate']
assert len(files)==32 and {name:sha(frozen/name) for name in files}==files
record=load(Path('benchmarks/results/2026-11-19-function-record-keys/summary.json'))
assert record['retained'] and record['cores']['candidate']==files['Lokad.Lython.dll']
retained=record['retainedCommit']
assert retained.startswith('2409f0596')
assert not subprocess.check_output(['git','diff','--name-only',manifest['candidateCommit'],retained,'--','src','tests'])
catalog=lab/'representative.json'
data=load(prior/'representative.json')
for folder,name in [('prepared-format-selectors-r598','scripts.report-render.format-selectors.large'),
                    ('retained-cpython-r576','scripts.csv-invoice.large')]:
    filename='catalog.json' if folder.endswith('r598') else 'representative.json'
    data['cases'].append(next(row for row in load(lab.parent/folder/filename)['cases'] if row['id']==name))
catalog.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
assert len({case['id'] for case in data['cases']})==5
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog,
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',Path.cwd()/'benchmarks/cpython-worker.py',
        '--out',lab/'verify.json'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=75)
verified=load(lab/'verify.json')
assert verified['state']=='Completed' and verified['catalogSha256']==sha(catalog)
print('Verified the retained runtime, complete worker image and five external cases.')