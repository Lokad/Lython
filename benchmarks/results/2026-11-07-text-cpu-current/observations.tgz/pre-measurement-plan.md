# Lokad.Lython 0.11.0

Updated2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
An isolated experiment, qualification or source gate does not complete it.

## Delivery status

| Work | Actual state |
| --- | --- |
| Core through R58/e66b8f72 | FULLY QUALIFIED: CI42404834827 Windows/Ubuntu Release actual11/10, original Stress and installed consumers. Cached receipt8937cf00; never query again. |
| HEADf519e54b before R62 | Evidence/public decoded-text interoperability; qualified production unchanged. R57 product admission/cancellation/start correctness and R58 dense graph replacement preserved. |
| R62 demand-driven validation | Retained source,559internal/1492public per actual11/10;716exact diagnostic comparisons; B418 controlled comparison/archive complete. Committed/pushed70267889; full delivery pending below. |
| R59 immutable dev54 adapter |86internal/514public per actual11/10 with existing development bridge. Normal optional0.4pin/core unchanged; final released adapter/safety/performance qualification remains separate. |
| R60 storage windows | Both variants WITHDRAWN; exact qualified production restored, forced builds and focused checks completed. No active representation prototype or architecture-only tests. Independent public regressions preserved. |

R62 eliminates unnecessary whole-script generator/type/future validation and
unchanged scope-set allocation; existing distinct rules/order remain. Controlled
compile elapsed−2.94–5.88%, fresh config−1.32–1.45%; compile allocation−3.15–4.07%.
Warm text−0.51/−0.42% is a control, not a runtime speedup. Quantized worker CPU,
adverse/unstable desktop clocks and initial staging failure remain in
[evidence](benchmarks/results/2026-11-07-syntax-validation/README.md).
No unchanged full qualification or old service/status queries.

## Completed work / measurement boundaries

- Shared compiler-fact correction, direct UTF-8 formatting/storage and native
  helper returns are delivered/qualified. Returns allocation−19.92/−19.31%; prior
  elapsed improvements remain diagnostic. Formatting allocation−8.67%; controlled
  B102 elapsed/CPU−5–8% supports retention. Original15.125ms adverse point remains
  unexplained/preserved; no further format correction is currently justified.
- Bulk CSV has been selectively reconsidered: R20/R25 shared keys/value transfer
  supersede the rigidly rejected constructor. Allocation−7.31/−6.55%, native warm
  −7.72–8.04%, controls mixed. No automatic promotion of the old implementation.
- Native returns/borrowed operands/final slots/deferred contexts/reused workspaces,
  shared bindings, UTF-8 integer parsing/wildcards, R55 lexical-prepass removal,
  R57 correct product funding and R58 graph consolidation remain. Do not rediscover
  these, direct UTF-8 casing/lower-split/final formatting, or native scalar sum.
- R54/R60 general text-window representations are withdrawn, with allocation wins
  but access/ownership complexity and adverse complete-script controls preserved.
  R61 finds zero escaped tokens in current JSON/report/config; existing native
  container loops/shared keys/direct slots rule out that proposed copy campaign.
  Slower call-arena/call-control designs remain lessons, not permanent design bans.

Keep details behind [history](benchmarks/EXPERIMENTS.md), current
[performance guide](docs/BENCHMARKS.md) and immutable results; do not repeat them
in active tasks. Primary CPython snapshot B409/55e510ff, CPython3.13.16, is complete
and labeled by revision/date/machine. Compile, warm and compile-to-result are
separate; mediated RAM I/O/full validation/prior-result cleanup included, startup/
staging/reset/transport/final teardown excluded. Startup, pending-I/O latency,
RSS and embedding tails remain unmeasured. Refresh at the next substantial
retained runtime checkpoint; do not relabel historical measurements as HEAD.

## Next deliverable — material whole-script runtime redesign

While R62 full delivery runs, use current source and existing captures to select
one complete phase to remove. R52 report927samples locates JSON/format/dispatch;
binding13self/rent3/frame3 do not prove dominant call packaging. R56 config551
samples shows substantial host open/path work, not a justified lazy-builtin
subsystem; retain capability/path checks and document CPython host asymmetry.

R63 bounded current text attribution is justified: text still has a material
CPython gap and its older CPU evidence predates operand/call changes. Reuse the
existing checked collector for one complete text-summary/helpers job, source/core
identity, normal semantic goldens and owned cleanup. Inspect source/capture first;
one short current capture if old evidence cannot resolve the boundary. No broad
profiling sweep or new benchmark framework. Declare time/storage/stop margin and
archive under the lease. Stop investigation after identifying a material removable
phase, or documenting insufficient attribution and selecting another boundary.
That stopping condition ends this investigation, not the performance objective.

For the selected redesign, before code record hypothesis, eliminated work/storage,
affected complete scripts, semantic/token/admission gates, displaced implementation
to delete and completion/debt decision. Permit temporary setbacks within an explicit
completion milestone; do not accumulate parallel old/new routes or special cases.

| Candidate boundary | Acceptance / displacement |
| --- | --- |
| Complete call/frame construction | CSV/text/report helpers; eliminate an actual remaining phase after existing borrowed/native paths. Preserve defaults/keywords/variadics/closures/recursion/evaluation order/errors/suspension and caller funding through cleanup. Delete displaced binding/frame machinery; previous slower arena/control designs are controls, not templates. |
| Operand / boxed-value dispatch | Counters, updates and helper results; remove repeated transport/dispatch if newly demonstrated material. Preserve public BigInteger, CLR ingress round trips, identity, exact promotion, protocols, cancellation and aliases. No universal tagged-value project based on boxing alone. |
| Per-record construction | CSV/JSON/report; shared keys/value transfer/direct record slots already exist. Select a real remaining capacity/copy phase, preserve hooks/order/reentry/mutation/overlap and delete replaced construction code. |
| Remaining text conversion | Text/report; preserve Unicode expansion/context, precision/formatting, hashes and native storage. Select whole conversion/storage phase, not speculative per-access tuning or hidden interning. |
| Repeated frontend analysis | R55/R58/R62 remove actual repeated work; lexical/validity scopes differ and must not be mechanically merged. Binding/parsing remain material historical targets; preserve diagnostics/order/dead scopes/annotations/imports/generators and remove displaced passes/facts. No compiler rewrite justified by LoweredScript2.6–3.0% alone. |

Each retained redesign gets focused correctness/ownership/cancellation checks and
one bounded before/after complete-script comparison with unchanged controls.
Report simplification, allocation, controlled elapsed and CPU separately; keep
adverse observations and unresolved regression debt explicit. Reconfirm/refine or
correct measurement when evidence warrants it. Timeouts/unstable unchanged controls
establish uncertainty, not a failed design. No blanket one-attempt/no-retiming/
permanent-closure rules; percentages inform decisions, not automatic vetoes.

## Independent regex deliverable

Core owns Python/native UTF-8, byte ranges/scalar positions/original windows,
flags/captures/replacements/errors, explicit cache ownership and current tokens.
No Utf8Regex runtime dependency; optional adapter remains nonpackable0.4.0.
Completed contract/semantic work stands independently of producer publication.
Development producers and adapter-local bridges are acceptable; do not move them
into core or confuse compatibility tests with backend performance.

R59 immutable0.5.0-dev.54/553acbdf compatibility is completed, with
[precise evidence](benchmarks/results/2026-11-07-regex-dev54/README.md).
Outstanding producer gaps: DetailedData has no distinct preparation/working-owner
input; UTF-8 name lookup lacks native enumeration; cursor creation retains its
token despite current-move overloads. Existing conservative bridges remain.
Qualify a supported immutable released package and managed-safety policy separately.
These gaps defer only affected final adapter qualification; no core stopping rule,
sibling edits, silent dialect fallback, regex quota or abandoned background work.

## Validation / lasting constraints

Focused Release with explicit Category!=Stress during iteration; matching probe
build before dependent tests. Actual11 normally, actual10 at coherent checkpoints.
No overlapping local builds/tests/measurements. After preserved-timestamp restore,
force a nonincremental build. Batch full Windows/Ubuntu, both targets, original
Stress and installed core consumers at retained milestones; continue during CI,
status checks at least5minutes apart, cache terminal results. No assertion/timeout
relaxation. Only core Release pack via tools/pack.ps1; publication postponed.

AGENTS.md governs fully managed memory safety, managed stack admission, host
capabilities, cooperative cancellation, shared allowance/preflights/replacement
overlap/retained aliases, terminal first refusal and awaited deterministic cleanup.
No unsafe/Unsafe/PInvoke/native probes, fuel/quotas/caps/hidden allowance, tracing,
weak reclamation or forced GC. XML depth remains; bounded streams use host batches.
Later compiler passes can finish before the next token check. Explicit UTF-8 text.

VM lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. B385–B418 terminal,
archived/locally verified; never query old services. No active VM worker/mount.
Records/workers persistent, separate owned RAM guest fixtures; verify archives
under lease and locally, join all users/unmount. Keep256MiB staging headroom;
owned hard links avoid redundant core copies. Preserve original setup failures.
Docs describe current implementation; plans/history/receipts stay outside docs.

R63/B419 selected: one current complete-text6sCPU capture after6guest-second
warmup/2ssettle;199Hz/FP, PerfMap3 and five exact JIT listings diagnostic only.
120sowner+30sstop+30smargin; observe180s.256MiB staging headroom, original
thread/maps/unknowns/goldens/quiet/join/ownedfixtures/archive gates. Determine
one materially removable phase, not a predicted speedup or objective completion.
