from pathlib import Path
import fcntl,hashlib,json,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'compiler-graph-b415-20261107'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 archive=root/'observations.tgz';assert hashlib.sha256(archive.read_bytes()).hexdigest()=='907f8751ffe5f76aa1d2152d3a8bd95f925e2001fa109185fc4ce02dad20624b'
 rows=[]
 with tarfile.open(archive) as t:
  for name in ['baseline-core.dll','current-core.dll']:
   target=root/name;assert target.resolve().parent==root and target.is_file() and not target.is_symlink()
   data=target.read_bytes();assert t.extractfile(name).read()==data
   rows.append(dict(path=str(target),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),archiveAndMemberVerified=True))
 for row in rows:Path(row['path']).unlink()
 print(json.dumps(dict(immutableArchiveRetained=True,localArchiveAlreadyVerified=True,removedRedundantExtractedCopies=rows)))
