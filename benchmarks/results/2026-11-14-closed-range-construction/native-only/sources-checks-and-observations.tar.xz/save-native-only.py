from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;stage=r/'native-only';out=Path('benchmarks/results/2026-11-14-closed-range-construction/native-only');out.mkdir()
identity=json.loads((stage/'candidate-identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in identity['sources'].items())
status=json.loads((stage/'b742/terminal-status.json').read_text(encoding='utf-8'));assert status['exitCode']=='0'and status['receipt']['complete']and not status['remainingWorkers']and not status['remainingTrace'];assert hashlib.sha256((stage/'b742/observations.tgz').read_bytes()).hexdigest()==status['receipt']['archiveSHA256']
for n in ['candidate-identity.json','focused-checks.json','python-controls.json','allocation-summary.json','prospective.json']:shutil.copyfile(stage/n,out/n)
shutil.copyfile(stage/'b742/summary.json',out/'timing-summary.json')
decision=dict(retain=True,coreSHA256=identity['coreSHA256']['candidate'],changedProductionInputs=identity['changedProductionInputs'],removed='Whole-helper native-to-ordinary promotion and argument packaging for exact range construction; discard global range singleton and entire ordinary-call specialization.',bounds='Native prefix only; existing per-execution mutable constructor metadata and generic index/keyword/star protocols retained. No new owner/array/value representation/controller/configuration. All582source/aux identities and current cancellation/admission preserved.',result='Complete100kcounter−31.85..−33.19percentwarm with CPU support, allocation−57.2349percent. No final-source fresh/CSV/JSON external/neutrality claim.',debt='Shorthelperelapsed+0.59..+7.86percent/candidate4.75percentprocessspread, CPU−1.47..+6.44percent. Observedelapsed−1.14..+1.91percent/CPU−2.20..+1.20. Accept uncertainty/adversecontrol debt for bounded whole-loop milestone; earlier R359debt still release decision. No automatic unchanged retiming or causal B741/B742 attribution.',focused='176finalsourcechecks actual11/10,70isolatedPythoncontrols,16workergoldens. Prior536metadata/refusal checks reused because constructors unchanged and ordinaryrouter restoredexactbaseline. Originalnet10sixcase mismatch/forcedsevenfix retained.',fullQualification='Pending coherent platform/stress/installedRelease consumer delivery at committed frozen source.',publicationHeld=True)
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'sources-checks-and-observations.tar.xz','w:xz')as t:
    for p in sorted(stage.rglob('*')):
        if p.is_file()and not{'candidate','reference'}&set(p.relative_to(stage).parts):t.add(p,arcname=p.relative_to(stage).as_posix())
    for n in ['freeze-native-only.py','prepare-native-only-confirmation.py','confirm-native-only.py','save-native-only.py']:t.add(r/n,arcname=n)
    for n in ['tests/Lokad.Lython.PublicApi.Tests/RangeHelperExecutionTests.cs','tests/Lokad.Lython.Tests/NativeSequenceAdmissionTests.cs']:t.add(n,arcname=n)
p=Path('benchmarks/results/2026-11-14-closed-range-construction/README.md');p.write_text(p.read_text(encoding='utf-8')+'''
## Retained completion: native-prefix construction only

Retain frozen `ca1e2331`, four production inputs. Remove the entire ordinary-call
specialization and restore that router's exact baseline bytes. Per-execution range
metadata and the single span-based factory remain. This removes a whole-helper
promotion without scalar state in ordinary frames or another routing framework.
176 final-source focused checks on actual .NET 11/10, 70 isolated Python controls
and all 16 worker goldens pass. Previous metadata/refusal coverage applies to the
unchanged constructor ownership; the ordinary router is restored to qualified code.
No public API or supported Python behavior changes.

B742 completes three jobs in 105.342 seconds with all gates and no remaining
users/fixtures. Same normal settings/boundaries. Raw SHA256
`f67d6b4e241bf644b715e364abc7f4502bd2eca8f1b513c61858267c30468c25`.

| Final source / warm | Elapsed change | Wider CPU change |
| --- | ---: | ---: |
| Inside-range 100,000-add counter | −33.19..−31.85% | −32.78..−31.84% |
| Short/zero helpers | +0.59..+7.86% | −1.47..+6.44% |
| Helpers exposing every intermediate | −1.14..+1.91% | −2.20..+1.20% |

Counter is 2.770–2.805 ms versus 4.115–4.147 ms. Final allocation diagnostic
(one fresh process per role) is 7,518,746 to 3,215,402 B/run (−57.23%); CSV allocation
is identical at 3,034,384 B/run. Initial four-process allocation evidence agrees.
Short-helper candidate spread 4.75% / reference 2.08% makes magnitude uncertain;
preserve its adverse direction. Accept that uncertainty/debt for this bounded
whole-loop improvement, alongside earlier R359 debt; final 0.11 debt remains an
explicit release decision. No final-source fresh/CSV/JSON elapsed, universal gain,
new CPython ratio or causal B741/B742 attribution. Initial seven-job results stay
visible but do not qualify the corrected source. The inherited retrieval console
says B741; actual unit/root/source/core/archive identities are B742 and verified.

The original source-pair metadata also inherited an older 959c precommit label.
Final identity corrects it: actual base eb882d01, qualified comparison 98acaa5b,
precommit e9cf1c39. Source/core/auxiliary hashes were correct throughout; original
metadata is preserved. Full source/platform/stress/installed-consumer delivery
follows at the committed final source. Publication stays held; the wider
representative-script performance objective and independent regex track continue.

[Decision/debt](native-only/decision.json), [identity](native-only/candidate-identity.json),
[timing](native-only/timing-summary.json), [allocation](native-only/allocation-summary.json),
[checks](native-only/focused-checks.json),
[all final sources/binary/raw/tools](native-only/sources-checks-and-observations.tar.xz).
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf-8')+'''
R361 [retained native-only completion](results/2026-11-14-closed-range-construction/README.md)
ca1e restores ordinary-call routing exactly and retains per-execution constructors.
Four changed inputs, 176 final focused checks/70 Python controls/16 goldens pass.
B742 three jobs/105.342 s/all gates: whole counter warm−31.8–33.2%/CPU support,
allocation−57.23%; shorthelperelapsed+0.6–7.9% with variable controls and mixed CPU,
observed mixed. Accept explicit remaining debt/uncertainty for this bounded loop
milestone; no universal/finalfresh/CSV/JSON/CPython improvement claim or causal
cross-collection attribution. Initial/adverse/metadata failures preserved, no dormant
router/singleton. Full delivery follows; broader objective and regex work active.
''',encoding='utf-8',newline='\n');print('R361native-only retained with explicit control debt; final immutable evidence saved.',flush=True)
