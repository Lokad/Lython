from pathlib import Path
import ast,json,subprocess
r=Path(__file__).parent;out=r/'native-only';p=out/'candidate-identity.json';d=json.loads(p.read_text(encoding='utf-8'))
d['inheritedPrecommitLabel']=d.pop('headBeforeCommit')
d.update(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),productionBaseCommit='eb882d013456a02fe506378468e043be054f0681',labelCorrection='Inherited959c precommit label belonged to R360. Actual R361baseeb882d and qualified comparison98acaa5b are explicit; all frozen source/core/aux hashes were correct. Original snapshots preserved.')
p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(r/'confirm-owned-constructor.py').read_text(encoding='utf-8').replace("stage=r/'owned-constructor';out=stage/'b741'","stage=r/'native-only';out=stage/'b742'")
s=s.replace('R361owned-constructor/frozen','R361native-only/frozen').replace('Bounded confirmation after restoring per-execution mutable range metadata; same span factory/native construction boundary. Initial B740/all adverse controls retained. Complete counter and short/observed controls; no final-source inference from initial timings.','Bounded completion: per-execution range metadata and native-prefix construction only. Ordinary call router restored exactly; remove added generic call-type probe. Preserve B740/B741/adverse controls. Complete counter/short/observed source pairs; no initial/final cross-collection attribution.')
s=s.replace('owned-range-b741-20261114','native-range-complete-b742-20261114').replace('lython-b741-owned-range-20261114','lython-b742-native-range-complete-20261114').replace("/initial/sources-checks-and-observations.tar.xz","/owned-constructor/sources-checks-and-observations.tar.xz").replace("'b740/observations.tgz'","'b741/observations.tgz'").replace("startswith('98df40e9')","startswith('738a12da')").replace("remote='native-range-b740-20261114/observations.tgz'","remote='owned-range-b741-20261114/observations.tgz'")
anchor="c=dict(root=root,sourceRoot="
insert='''extra=[]
for name,member,remote in [('benchmarks/results/2026-11-14-closed-range-construction/initial/sources-checks-and-observations.tar.xz','b740/retrieved/confirmation/confirmation.json','native-range-b740-20261114/confirmation/confirmation.json'),('benchmarks/results/2026-11-14-closed-range-construction/owned-constructor/sources-checks-and-observations.tar.xz','b741/retrieved/confirmation/confirmation.json','owned-range-b741-20261114/confirmation/confirmation.json')]:
 data=subprocess.check_output(['git','show',head+':'+name]);assert hashlib.sha256(data).hexdigest()==sha(name)
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:xz')as t:content=t.extractfile(member).read()
 extra.append(dict(commit=head,canonicalArchive=name,archiveSHA256=hashlib.sha256(data).hexdigest(),member=member,bytes=len(content),sha256=hashlib.sha256(content).hexdigest(),remote=remote))
'''
assert s.count(anchor)==1;s=s.replace(anchor,insert+anchor).replace('duplicates=[duplicate]','duplicates=[duplicate]+extra')
s=s.replace('b741-proved-superseded-working-copy-retirement-20261114','b742-proved-superseded-working-copy-retirement-20261114').replace('lython-b741-fixtures','lython-b742-fixtures').replace('R361three-job owned-range confirmation','R361three-job native-only range confirmation')
s=s.replace('Only complete initial98dfcorealiases and committed duplicate B740raw. PreserveA4/finalcandidate/catalog/aux/toolchains/floors.','Only complete superseded738acorealiases and canonically committed B740/B741 raw-result duplicates. PreserveA4/finalcandidate/catalog/aux/toolchains/floors.')
ast.parse(s);p=r/'confirm-native-only.py';p.write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(p)],check=True)
