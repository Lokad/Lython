from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess,tarfile,xml.etree.ElementTree as ET
r=Path(__file__).parent;out=r/'owned-constructor';old=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources={n:sha(n)for n in old['sources']};assert [n for n,h in sources.items()if h!=old['sources'][n]]==['src/Lokad.Lython/Runtime/LythonRuntime.ExecutionContext.Builtins.cs']
assert 'SharedRange'not in Path('src/Lokad.Lython/Runtime/LythonRuntime.ExecutionContext.Builtins.cs').read_text(encoding='utf-8')
env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+os.environ.get('PATH','');sdk=env['DOTNET_ROOT']+'/dotnet.exe';rows=[]
for framework in ['net11.0','net10.0']:
    for project,selection in [('Lokad.Lython.PublicApi.Tests','ResultsAndOwnershipMatchBothApis'),('Lokad.Lython.Tests','RefusedRangeConstructionPrecedesLoopEffects')]:
        name='r361-final-'+project+'-'+framework+'.trx';log=out/(project+'-'+framework+'.log')
        with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'test','tests/'+project+'/'+project+'.csproj','-c','Release','-f',framework,'--no-restore','--filter','FullyQualifiedName~'+selection,'--logger','trx;LogFileName='+name,'-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
        assert done.returncode==0,log.read_text(encoding='utf-8')[-3000:]
        trx=Path('tests')/project/'TestResults'/name;counts=ET.parse(trx).find('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters').attrib;shutil.copyfile(trx,out/name);rows.append(dict(framework=framework,project=project,counters=counts));print(framework,project,counts['passed'],'final checks pass',flush=True)
(out/'final-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
with(out/'freeze-build.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1','-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0 and all(sha(n)==h for n,h in sources.items())
for role in ['reference','candidate']:shutil.copytree(r/'reference',out/role)
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',out/'candidate/Lokad.Lython.dll');shutil.copyfile(out/'candidate/Lokad.Lython.dll',out/'candidate-core.dll')
identity=dict(old,sources=sources,coreSHA256={role:sha(out/role/'Lokad.Lython.dll')for role in ['reference','candidate']},refinement='Range constructor remains execution-owned, preserving hierarchy/descriptor/NewSlot owners. Only actual private BuiltinCallable range constructors take closed evaluated-span route; guest-named functions and aliases behave normally. No static range singleton or earlier-token/state cache.',qualified=False)
(out/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'candidate-sources.tar.xz','w:xz')as t:
    for n in sources:t.add(n,arcname=n)
for n in ['allocation-reference-catalog.json','allocation-candidate-catalog.json']:shutil.copyfile(r/n,out/n)
shutil.copyfile(r/'b740/catalog.json',out/'catalog.json')
s=(r/'verify-worker.py').read_text(encoding='utf-8').replace("r.parent/'utf8-byte-ownership-r334","r.parent.parent/'utf8-byte-ownership-r334").replace('range(7)','range(8)');ast.parse(s);(out/'verify-worker.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'measure-allocation.py').read_text(encoding='utf-8').replace("[('reference',0),('candidate',0),('candidate',1),('reference',1)]","[('reference',0),('candidate',0)]");ast.parse(s);(out/'measure-allocation.py').write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(out/'verify-worker.py')],check=True,env=env)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(out/'measure-allocation.py')],check=True,env=env)
snippets=json.loads((r/'python-control-sources.json').read_text(encoding='utf-8'));snippets.append("def range(count):return (count+10,)\ndef make():return range(3)\nprint(make())")
assert len(snippets)==35
(out/'python-control-sources.json').write_text(json.dumps(snippets,indent=2)+'\n',encoding='utf-8',newline='\n');controls=[];probe=Path('tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll').resolve();assert sha(probe.parent/'Lokad.Lython.dll')==identity['coreSHA256']['candidate']
for asynchronous in [False,True]:
    done=subprocess.run([sdk,str(probe),'--batch-json','--compare-python','--python','C:/Python313/python.exe']+(['--async']if asynchronous else[]),input=json.dumps(snippets).encode(),capture_output=True,env=env,timeout=40);(out/('python-controls-'+str(asynchronous)+'.jsonl')).write_bytes(done.stdout);(out/('python-controls-'+str(asynchronous)+'.stderr')).write_bytes(done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode('utf-8');controls.append(dict(asynchronous=asynchronous,cases=35,matched=True));print(asynchronous,'35 independent Python controls pass',flush=True)
(out/'python-controls.json').write_text(json.dumps(dict(complete=True,coreSHA256=identity['coreSHA256']['candidate'],controls=controls,python='Isolated CPython3.13.2'),indent=2)+'\n',encoding='utf-8',newline='\n');print('R361owned-constructor source frozen',identity['coreSHA256'],flush=True)
