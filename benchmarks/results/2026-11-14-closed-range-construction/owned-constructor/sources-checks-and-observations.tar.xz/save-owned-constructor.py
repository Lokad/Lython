from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;stage=r/'owned-constructor';out=Path('benchmarks/results/2026-11-14-closed-range-construction/owned-constructor');out.mkdir()
status=json.loads((stage/'b741/terminal-status.json').read_text(encoding='utf-8'));assert status['exitCode']=='0'and status['receipt']['complete']and not status['remainingWorkers']and not status['remainingTrace'];assert hashlib.sha256((stage/'b741/observations.tgz').read_bytes()).hexdigest()==status['receipt']['archiveSHA256']
for n in ['candidate-identity.json','focused-checks.json','final-checks.json','python-controls.json','allocation-summary.json','prospective.json','test-input-correction.json']:shutil.copyfile(stage/n,out/n)
shutil.copyfile(stage/'b741/summary.json',out/'timing-summary.json')
with tarfile.open(out/'sources-checks-and-observations.tar.xz','w:xz')as t:
    for p in sorted(stage.rglob('*')):
        if p.is_file()and not{'candidate','reference'}&set(p.relative_to(stage).parts):t.add(p,arcname=p.relative_to(stage).as_posix())
    for n in ['freeze-owned-constructor.py','check-metadata.py','check-test-input.py','confirm-owned-constructor.py','save-owned-constructor.py']:t.add(r/n,arcname=n)
p=Path('benchmarks/results/2026-11-14-closed-range-construction/README.md');p.write_text(p.read_text(encoding='utf-8')+'''
## Execution-owned constructor comparison

Frozen `738a12da` restores per-execution constructor state. 536 additional focused
actual .NET 11/10 checks and 70 isolated Python controls pass, including builtin
metadata/isolation, aliasing, real I/O, cancellation and terminal refusal. One new
named-range test appeared in net11's seven-case list but incremental net10 listed
six: force rebuilding actual net10 runs all seven successfully. Original logs/TRX
remain; the stale-input cause is not independently established. All 16 frozen-worker
goldens pass. One separate allocation process per role still shows counter
−57.23% (7,518,842 to 3,215,498 B/run), CSV exactly flat in this diagnostic.

B741's three-job confirmation finishes in 105.678 seconds with all gates; no users
or fixtures remain. Same normal settings and boundaries as B740. Raw SHA256
`30035a844759e3bfa28ad0c69e486a9fd4b38162e210fd8477c183f2ee71d742`.

| Complete script / warm | Elapsed change | Wider CPU change |
| --- | ---: | ---: |
| Inside-range counter | −31.14..−29.70% | −31.03..−29.72% |
| Short/zero helpers | +5.16..+8.53% | +6.17..+8.51% |
| Helpers exposing every intermediate | +0.51..+1.95% | +2.75..+4.01% |

The short-helper adverse direction remains despite the counter win. Source places
range classification before every ordinary function call; the short control makes
8,192 such helper calls. This identifies unnecessary work, not a proven causal
CPU share. The selected completion removes that ordinary-router addition entirely,
restoring its baseline bytes. Only native-prefix range construction causes the
whole-body promotion cliff; ordinary execution already uses the same range factory
through existing binding. No extra general-call probe or new selection mechanism.
Final source/checks/comparison and retention remain separate from these timings.

[Identity](owned-constructor/candidate-identity.json), [timing](owned-constructor/timing-summary.json),
[allocation](owned-constructor/allocation-summary.json), [checks](owned-constructor/focused-checks.json),
[test-input correction](owned-constructor/test-input-correction.json),
[sources/binary/raw/conditions](owned-constructor/sources-checks-and-observations.tar.xz).
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf-8')+'''
R361 [owned-constructor B741](results/2026-11-14-closed-range-construction/README.md)
at738a/A4 preserves metadata ownership and counter−30–31%/allocation−57.23%, but
shorthelpers+5.2–8.5% and observed+0.5–1.9% remain adverse. Three jobs/105.678 s/all
gates; 536 focused checks/70 Python controls and corrected seven-case net10 input
pass. Preserve every original result. Remove ordinary range routing entirely:
only native-prefix construction needs this capability, so restore the exact
ordinary-router baseline. No new abstraction/owner/flag. Source/checks/final
comparison remain independent; no causal attribution from mere routing placement.
''',encoding='utf-8',newline='\n');print('Owned constructor source/negative helper controls preserved; native-only completion separate.',flush=True)
