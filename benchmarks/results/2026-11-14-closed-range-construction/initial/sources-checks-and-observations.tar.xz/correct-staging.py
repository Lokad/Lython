from pathlib import Path
import ast,base64,datetime,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).parent/'b740';assert not(r/'observe-not-before.json').exists()
diagnosis=json.loads((r/'staging-diagnosis.json').read_text(encoding='utf-8'));assert diagnosis['freshIdleLease']and not diagnosis['rootExists']and not diagnosis['fixtureMounts']
assert not diagnosis['groups'][1]['paths']and diagnosis['groups'][0]['paths']
for n in ['config.json','launch.log','launch-command.py','launch-attempt.json']:
    shutil.copyfile(r/n,r/('first-'+n))
c=json.loads((r/'config.json').read_text(encoding='utf-8'));head=c['proofs'][0]['commit']
name='benchmarks/results/2026-11-14-owned-csv-field-ranges/initial/sources-checks-and-failed-observations.tar.xz'
blob=subprocess.check_output(['git','show',head+':'+name]);assert hashlib.sha256(blob).hexdigest()==hashlib.sha256(Path(name).read_bytes()).hexdigest()
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:xz')as t:body=t.extractfile('candidate-core.dll').read()
proof=dict(commit=head,canonicalArchive=name,archiveSHA256=hashlib.sha256(blob).hexdigest(),member='candidate-core.dll',bytes=len(body),sha256=hashlib.sha256(body).hexdigest());assert proof['sha256'].startswith('510a3f86');proof['coreSHA256']=proof['sha256'];c['proofs'][1]=proof
(r/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(r/'first-launch-command.py').read_text(encoding='utf-8');start=s.index('c=');end=s.index('\nbase=',start);s=s[:start]+'c='+repr(c)+s[end:];ast.parse(s);(r/'launch-command.py').write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r.parent/'diagnose-staging.py')],check=True)
d=json.loads((r/'staging-diagnosis.json').read_text(encoding='utf-8'));assert not d['rootExists']and all(g['paths']for g in d['groups'])
(r/'staging-correction.json').write_text(json.dumps(dict(initial='Already retired6c35 working image; staging refused before any deletion/mount/root/worker. Original command/log/config preserved.',correction='Use separately archived withdrawn510a CSV working image alongside withdrawn b868. No source/data/settings/bound changes; no timed owner existed. Current A4, new candidate and auxiliaries/catalog/toolchain/floors preserved.',newProof=proof),indent=2)+'\n',encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(s.encode()).decode()+"\"))'"
(r/'corrected-launch-attempt.json').write_text(json.dumps(dict(attemptedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),neverAutomaticallyRelaunch=True))+'\n',encoding='utf-8')
done=subprocess.run(ssh+[command],input=(r/'payload.tgz').read_bytes(),capture_output=True,timeout=60);(r/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc);(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=300)).isoformat(),ownerSeconds=360),indent=2)+'\n',encoding='utf-8',newline='\n')
print(done.stdout.decode(),flush=True);print('Earliest observation',(now+datetime.timedelta(seconds=300)).isoformat(),flush=True)
