from pathlib import Path
import ast,base64,datetime,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).parent/'b740';assert not(r/'observe-not-before.json').exists()
c=json.loads((r/'config.json').read_text(encoding='utf-8'));head=c['proofs'][0]['commit'];c['proofs']=c['proofs'][:1];c['duplicates']=[]
names=[
('benchmarks/results/2026-11-14-frame-primitive-storage/initial/sources-checks-and-observations.tar.xz','b738/observations.tgz','frame-profile-b738-20261114/observations.tgz'),
('benchmarks/results/2026-11-14-frame-primitive-storage/handoff/sources-checks-and-observations.tar.xz','b739/observations.tgz','primitive-handoff-b739-20261114/observations.tgz'),
('benchmarks/results/2026-11-14-native-primitive-storage/initial/sources-checks-and-observations.tar.xz','b734/observations.tgz','primitive-storage-b734-20261114/observations.tgz'),
('benchmarks/results/2026-11-14-native-primitive-storage/refined/sources-checks-and-observations.tar.xz','b735/observations.tgz','primitive-publication-b735-20261114/observations.tgz'),
('benchmarks/results/2026-11-14-primitive-cpython-checkpoint/observations.tar.xz','observations.tgz','primitive-cpython-b736-20261114/observations.tgz'),
('benchmarks/results/2026-11-14-numeric-loop-boundary/tools-catalogs-and-observations.tar.xz','b730/observations.tgz','loop-stage-b730-20261114/observations.tgz')]
for n in ['perf.data','perf.map.gz','perf-stacks.txt.gz','primitive-instruction.asm']:
    names.append(('benchmarks/results/2026-11-14-frame-primitive-storage/initial/sources-checks-and-observations.tar.xz','b738/retrieved/profiles/csv-while/'+n,'frame-profile-b738-20261114/profiles/csv-while/'+n))
archives={}
for name,member,remote in names:
    if name not in archives:
        blob=subprocess.check_output(['git','show',head+':'+name]);assert hashlib.sha256(blob).hexdigest()==hashlib.sha256(Path(name).read_bytes()).hexdigest();archives[name]=blob
    blob=archives[name]
    with tarfile.open(fileobj=io.BytesIO(blob),mode='r:xz')as t:body=t.extractfile(member).read()
    c['duplicates'].append(dict(commit=head,canonicalArchive=name,archiveSHA256=hashlib.sha256(blob).hexdigest(),member=member,bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),remote=remote))
code=(r/'first-launch-command.py').read_text(encoding='utf-8');start=code.index('c=');end=code.index('\nbase=',start);code=code[:start]+'c='+repr(c)+code[end:]
old=" before=shutil.disk_usage(base).free\n assert before+sum(p['bytes']for p in c['proofs'])>254*1024*1024+c['unpackedBytes']+32768\n for p in aliases:p.unlink()"
new=""" duplicate_paths=[];duplicate_proofs=[];already_absent=[]
 for item in c['duplicates']:
  p=base/item['remote']
  if not p.exists():already_absent.append(item['remote']);continue
  info=p.lstat();assert p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(info.st_mode)and info.st_uid==os.getuid()and info.st_nlink==1
  assert info.st_size==item['bytes']and sha(p)==item['sha256'];duplicate_paths.append(p);duplicate_proofs.append(item)
 before=shutil.disk_usage(base).free
 assert before+sum(p['bytes']for p in c['proofs'])+sum(p['bytes']for p in duplicate_proofs)>254*1024*1024+c['unpackedBytes']+131072,(before,sum(p['bytes']for p in duplicate_proofs),already_absent)
 aliases.extend(duplicate_paths)
 for p in aliases:p.unlink()"""
assert old in code;code=code.replace(old,new).replace('proofs=groups,retiredOnly=','proofs=groups,duplicateProofs=duplicate_proofs,alreadyAbsentDuplicates=already_absent,retiredOnly=');ast.parse(code)
(r/'funded-config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n');(r/'funded-launch-command.py').write_text(code,encoding='utf-8',newline='\n')
(r/'funded-launch-attempt.json').write_text(json.dumps(dict(attemptedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),reason='Earlier6c35and510a working images already retired; both preflights failed before mutation/owner. Retire b868 plus only present byte-proven committed raw/trace duplicates; retain catalogs/aux/toolchain/A4 and254/252MiBfloors.',neverAutomaticallyRelaunch=True))+'\n',encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],input=(r/'payload.tgz').read_bytes(),capture_output=True,timeout=60);(r/'funded-launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc);(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=300)).isoformat(),ownerSeconds=360),indent=2)+'\n',encoding='utf-8',newline='\n')
print(done.stdout.decode(),flush=True);print('Earliest observation',(now+datetime.timedelta(seconds=300)).isoformat(),flush=True)
