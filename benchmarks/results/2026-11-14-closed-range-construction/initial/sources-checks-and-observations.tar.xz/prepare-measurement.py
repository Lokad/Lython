from pathlib import Path
import ast,base64,datetime,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'frame-primitive-transport-r360/handoff/b739';out=r/'b740';out.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(sha(p)==v for p,v in source['sources'].items())
assert json.loads((r/'allocation-summary.json').read_text(encoding='utf-8'))['complete'] and json.loads((r/'python-controls.json').read_text(encoding='utf-8'))['complete']
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'))
outside=next(c for c in json.loads((r.parent/'loop-boundary-r356/retrieved/representative.json').read_text(encoding='utf-8'))['cases']if c['id']=='diagnostic.loop-range.outside.large')
assert not any(c['id']==outside['id']for c in catalog['cases']);catalog['cases'].append(outside)
(out/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8',newline='\n')
identity=dict(json.loads((old/'identity.json').read_text(encoding='utf-8')))
identity.update(sourceRevision='R361/frozen'+source['coreSHA256']['candidate'][:8]+' vs fully qualified98acaa5b/frozena4bfbfd8',purpose='Closed range construction shares factory/final operands; avoids native-to-ordinary promotion. Independent two-line matrix guard included. Counterwarm/fresh and outside-range diagnostic; CSV/JSON/short/observed controls. No CPython or arbitrary frame-unboxing claim.',coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},fullSourceIdentitySHA256=sha(r/'candidate-identity.json'),catalogSHA256=sha(out/'catalog.json'))
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
assert all(source['auxiliaryFiles'][role][n]==v for role in ['reference','candidate']for n,v in identity['auxiliaryFiles'].items())
jobs=[['diagnostic.loop-range.inside.large','warm'],['diagnostic.loop-range.inside.large','compile-run'],['diagnostic.loop-range.outside.large','warm'],['diagnostic.csv-check-digits.while.large','warm'],['scripts.json-summary-helpers.large','warm'],['diagnostic.loop-helper.short-zero.large','warm'],['diagnostic.loop-helper.observed.large','warm']]
root='/home/lokad/lython-bench-checks/native-range-b740-20261114';unit='lython-b740-native-range-20261114'
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(old/name).read_text(encoding='utf-8').replace('primitive-handoff-b739-20261114','native-range-b740-20261114').replace('lython-b739-primitive-handoff-20261114',unit).replace('B739','B740')
    if name=='collect.py':
        start=s.index('jobs=');end=s.index('\nenv =',start);s=s[:start]+'jobs='+repr(jobs)+'\nassert len(jobs)==7 and all(case in cases for case,lane in jobs)\n'+s[end:]
    elif name=='archive-owned.py':s=s.replace("len(raw['jobs'])==6","len(raw['jobs'])==7").replace('jobs=6','jobs=7')
    elif name=='retrieve.py':s=s.replace("['jobs']==6","['jobs']==7").replace('B740 two-job','B740 seven-job')
    elif name=='summarize.py':s=s.replace("len(raw['jobs'])==6","len(raw['jobs'])==7").replace('jobs=6','jobs=7')
    if name.endswith('.py'):ast.parse(s)
    (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
    for n in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/n,arcname=n)
    t.add(r/'candidate-core.dll',arcname='candidate-core.dll');t.add(out/'catalog.json',arcname='representative.json')
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();proofs=[]
for name,expected in [('benchmarks/results/2026-11-14-frame-primitive-storage/handoff/sources-checks-and-observations.tar.xz','b8687b28'),('benchmarks/results/2026-11-14-native-primitive-storage/initial/sources-checks-and-observations.tar.xz','6c35b043')]:
    p=Path(name);blob=subprocess.check_output(['git','show',head+':'+name]);assert hashlib.sha256(blob).hexdigest()==sha(p)
    with tarfile.open(fileobj=io.BytesIO(blob),mode='r:xz')as t:body=t.extractfile('candidate-core.dll').read()
    proof=dict(commit=head,canonicalArchive=name,archiveSHA256=sha(p),member='candidate-core.dll',bytes=len(body),sha256=hashlib.sha256(body).hexdigest());assert proof['sha256'].startswith(expected);proof['coreSHA256']=proof['sha256'];proofs.append(proof)
config=dict(root=root,sourceRoot='/home/lokad/lython-bench-checks/primitive-publication-b735-20261114',unit=unit,identity=identity,proofs=proofs,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=sha(out/'payload.tgz'),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
code=(old/'launch-command.py').read_text(encoding='utf-8');start=code.index('c=');end=code.index('\nbase=',start);code=code[:start]+'c='+repr(config)+code[end:]
start=code.index(" proof=c['proof'];");end=code.index(" assert shutil.disk_usage(base).free>254",start)
code=code[:start]+''' aliases=[];groups=[]
 for proof in c['proofs']:
  group=[]
  for p in base.rglob('*.dll'):
   if p.name not in {'Lokad.Lython.dll','candidate-core.dll','current-core.dll','reference-core.dll'}:continue
   info=p.lstat()
   if info.st_size!=proof['bytes']or sha(p)!=proof['coreSHA256']:continue
   assert p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(info.st_mode)and info.st_uid==os.getuid();group.append(p)
  assert group and len({(p.stat().st_dev,p.stat().st_ino)for p in group})==1
  assert all(p.stat().st_nlink==len(group)for p in group)
  groups.append(dict(proof=proof,aliases=[str(p)for p in group]));aliases.extend(group)
 assert len(set(aliases))==len(aliases)
 before=shutil.disk_usage(base).free
 assert before+sum(p['bytes']for p in c['proofs'])>254*1024*1024+c['unpackedBytes']+32768
 for p in aliases:p.unlink()
 receipt=dict(proofs=groups,retiredOnly=[str(p)for p in aliases],allPathsUidsHashesAndCompleteAliasesProvedBeforeMutation=True,freshIdleLease=True,beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free)
 (base/'b740-proved-superseded-working-copy-retirement-20261114.json').write_text(json.dumps(receipt,indent=2)+'\\n')
'''+code[end:]
code=code.replace('lython-b739-fixtures','lython-b740-fixtures').replace('R360six-job primitive-handoff comparison launched under360second owner','R361seven-job range comparison launched under360second owner')
ast.parse(code);(out/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
(out/'prospective.json').write_text(json.dumps(dict(purpose=identity['purpose'],jobs=jobs,bound='One360sowner/300sstartguard;fourfreshprocesses/job,5sfull-requestwarmups,five0.5srotatingbatches,normalGC/tiering. Complete clocks/goldens/balances and independent controls; no backend/CPython/startup/tailclaim.',retirement='Only complete6c35/b868supersededcorealiases, all canonically committed. CurrentqualifiedA4/newcandidate/aux/catalog/toolchain and254/252MiBfloors preserved.',decision='Resolve substantial whole-loop benefit versus unaffected/control debt. No allocation-only CPU claim, no automatic unchanged rerun; retain/refine/withdraw with evidence. Full delivery at coherent retention checkpoint.',publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'launch-attempt.json').write_text(json.dumps(dict(attemptedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),neverAutomaticallyRelaunch=True))+'\n',encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],input=(out/'payload.tgz').read_bytes(),capture_output=True,timeout=60);(out/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc);(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=300)).isoformat(),ownerSeconds=360),indent=2)+'\n',encoding='utf-8',newline='\n')
print(done.stdout.decode(),flush=True);print('Earliest observation',(now+datetime.timedelta(seconds=300)).isoformat(),flush=True)
