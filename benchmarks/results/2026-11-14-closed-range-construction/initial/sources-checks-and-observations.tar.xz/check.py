from pathlib import Path
import json,os,subprocess,shutil,xml.etree.ElementTree as ET
r=Path(__file__).parent;env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+os.environ.get('PATH','');sdk=env['DOTNET_ROOT']+'/dotnet.exe';rows=[]
for framework in ['net11.0','net10.0']:
    log=r/('probe-build-'+framework+'.log')
    with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f',framework,'--no-restore','--no-incremental','--disable-build-servers','-m:1','-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    assert done.returncode==0,log.read_text(encoding='utf-8')[-3000:]
    for project,selection in [('Lokad.Lython.Tests','CheckedRangeIterationTests|FullyQualifiedName~NativeSequenceAdmissionTests|FullyQualifiedName~IntegerBinaryAdmissionTests|FullyQualifiedName~NativeClosureSequenceTests'),('Lokad.Lython.PublicApi.Tests','RangeHelperExecutionTests|FullyQualifiedName~Range|FullyQualifiedName~ForHelperExecutionTests|FullyQualifiedName~ExactIntegerOperatorTests|FullyQualifiedName~FrameIntegerLifetimeTests|FullyQualifiedName~IntegerPublicationTests|FullyQualifiedName~NativeTruthLifetimeTests|FullyQualifiedName~LoopLocalValueTests')]:
        name='r361-'+project+'-'+framework+'.trx';log=r/(project+'-'+framework+'.log')
        with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'test','tests/'+project+'/'+project+'.csproj','-c','Release','-f',framework,'--no-restore','--filter','(Category!=Stress)&(FullyQualifiedName~'+selection+')','--logger','trx;LogFileName='+name,'-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
        trx=Path('tests')/project/'TestResults'/name
        counts=ET.parse(trx).find('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters').attrib if trx.exists()else None
        if trx.exists():shutil.copyfile(trx,r/name)
        rows.append(dict(framework=framework,project=project,exitCode=done.returncode,counters=counts));(r/'focused-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
        assert done.returncode==0,log.read_text(encoding='utf-8')[-5000:]
        print(framework,project,counts['passed'],'focused checks pass',flush=True)
