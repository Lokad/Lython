from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess,tarfile,xml.etree.ElementTree as ET
r=Path(__file__).parent;prior=r.parent/'frame-primitive-transport-r360';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();gate=json.loads((r/'source-gate.json').read_text(encoding='utf-8'))
env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+os.environ.get('PATH','');sdk=env['DOTNET_ROOT']+'/dotnet.exe'
extra=[]
for framework in ['net11.0','net10.0']:
    name='r361-refusal-'+framework+'.trx';log=r/('refusal-'+framework+'.log')
    with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',framework,'--no-restore','--filter','FullyQualifiedName~RefusedRangeConstructionPrecedesLoopEffects','--logger','trx;LogFileName='+name,'-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    assert done.returncode==0,log.read_text(encoding='utf-8')[-3000:]
    trx=Path('tests/Lokad.Lython.Tests/TestResults')/name;counts=ET.parse(trx).find('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters').attrib;shutil.copyfile(trx,r/name);extra.append(dict(framework=framework,counters=counts));print(framework,counts['passed'],'additional refusal checks pass',flush=True)
(r/'refusal-checks.json').write_text(json.dumps(extra,indent=2)+'\n',encoding='utf-8',newline='\n')
sources={n:sha(n)for n in gate['baselineSources']}
with(r/'freeze-build.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1','-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0 and all(sha(n)==h for n,h in sources.items())
# Keep the freshly rebuilt development baseline separately; comparison reuses the
# qualified A4 image. The shared native-prefix file also includes the independent
# two-line matrix correction, explicitly included in this source pair.
shutil.copyfile(r/'reference-core.dll',r/'development-reference-core.dll')
shutil.copyfile(prior/'reference/Lokad.Lython.dll',r/'reference/Lokad.Lython.dll')
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll');shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
old=json.loads((prior/'candidate-identity.json').read_text(encoding='utf-8'));identity=dict(gate,sources=sources,productionFiles=len(sources),coreSHA256={role:sha(r/role/'Lokad.Lython.dll')for role in ['reference','candidate']},auxiliaryFiles={role:{p.name:sha(p)for p in(r/role).iterdir()if p.is_file()and p.name!='Lokad.Lython.dll'}for role in ['reference','candidate']},comparisonReference='Fully qualified98acaa5b/frozena4bfbfd8; the independent matrix guard is included with this five-file prototype. Development baselineeb882d01/frozenb6c0a0e7 separately preserved.',qualified=False)
assert identity['auxiliaryFiles']['reference']==identity['auxiliaryFiles']['candidate']
assert identity['coreSHA256']['reference']==old['coreSHA256']['reference']
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
    for n in sources:t.add(n,arcname=n)
for n in ['catalog.json','allocation-reference-catalog.json','allocation-candidate-catalog.json','measure-allocation.py','verify-worker.py']:shutil.copyfile(prior/n,r/n)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'verify-worker.py')],check=True,env=env)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'measure-allocation.py')],check=True,env=env)
snippets=json.loads((prior/'python-control-sources.json').read_text(encoding='utf-8'))
import re
body=Path('tests/Lokad.Lython.PublicApi.Tests/RangeHelperExecutionTests.cs').read_text(encoding='utf-8');block=body.split('public static TheoryData')[1].split('    [Theory]')[0]
for a,b in re.findall(r'\{ ("(?:[^"\\]|\\.)*"), ("(?:[^"\\]|\\.)*") \}',block):snippets.append(json.loads(a))
for args,error in [('', 'TypeError'),('1,2,3,4','TypeError'),('1,2,0','ValueError'),('stop=3','TypeError'),('1.5','TypeError')]:
    snippets.append(f"def make():return range({args})\ntry:\n make()\nexcept {error}:print('caught')")
assert len(snippets)==34
(r/'python-control-sources.json').write_text(json.dumps(snippets,indent=2)+'\n',encoding='utf-8',newline='\n');rows=[]
probe=Path('tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll').resolve();assert sha(probe.parent/'Lokad.Lython.dll')==identity['coreSHA256']['candidate']
for asynchronous in [False,True]:
    done=subprocess.run([sdk,str(probe),'--batch-json','--compare-python','--python','C:/Python313/python.exe']+(['--async']if asynchronous else[]),input=json.dumps(snippets).encode(),capture_output=True,env=env,timeout=40)
    (r/('python-controls-'+str(asynchronous)+'.jsonl')).write_bytes(done.stdout);(r/('python-controls-'+str(asynchronous)+'.stderr')).write_bytes(done.stderr)
    assert done.returncode==0,(done.stdout+done.stderr).decode('utf-8');rows.append(dict(asynchronous=asynchronous,cases=len(snippets),matched=True));print(asynchronous,len(snippets),'independent Python controls match',flush=True)
(r/'python-controls.json').write_text(json.dumps(dict(complete=True,coreSHA256=identity['coreSHA256']['candidate'],python='Isolated CPython3.13.2',controls=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
print('R361complete prototype frozen',identity['coreSHA256'],flush=True)
