from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prior=r.parent/'frame-primitive-transport-r360'
proof=json.loads((prior/'withdrawn/source-proof.json').read_text(encoding='utf-8'))
base={n:v['restoredSHA256']for n,v in proof['sources'].items()}
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head.startswith('eb882d01')
for role in ['reference','candidate']:shutil.copytree(prior/'reference',r/role,dirs_exist_ok=True)
baseline=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll')
shutil.copyfile(baseline,r/'reference/Lokad.Lython.dll');shutil.copyfile(baseline,r/'reference-core.dll')
with tarfile.open(r.parent/'primitive-storage-r359/complete/candidate-sources.tar.xz')as t:
    raw={m.name:t.extractfile(m).read()for m in t.getmembers()if m.isfile()}
n='src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs'
raw[n]=subprocess.check_output(['git','show',head+':'+n])
assert all(hashlib.sha256(b).hexdigest()==base[n]for n,b in raw.items())
with tarfile.open(r/'reference-sources.tar.xz','w:xz')as t:
    for n,b in raw.items():
        info=tarfile.TarInfo(n);info.size=len(b)
        import io
        t.addfile(info,io.BytesIO(b))
changed=[n for n,h in base.items()if sha(n)!=h];assert len(changed)==5
identity=json.loads((prior/'candidate-identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision=head,referenceCoreSHA256=sha(baseline),baselineSources=base,changedProductionInputs=changed,referenceBuiltAfterForcedRestore=True,referenceLog='../frame-primitive-transport-r360/withdrawn/build-net11.0.log',purpose='R361closed range construction over existing operand span; no ordinary frame promotion for exact bounds. Preserve one range factory/protocol path, shared immutable callable identity, existing native loop/private numeric working storage, managed frame admission and current owners. No new dispatch/value/owner framework.',eliminate='Binder argument packaging and whole native-to-ordinary activation/transfer for exact range construction; per-run range wrapper. Do not extend to unrelated builtins.',acceptance='BothAPIs:normal/reboundaliases,arity/keyword/star errors,negative/hugebounds/zerostep/bool/customindex,evaluation/errororder,realIO,cancellation,firstterminalrefusalbeforebody,retainedranges/results,budgetreuse. Exactvalues only; generic protocol calls unchanged.',measurement='Existing complete100k inside/outside-range counters; short/observed helper controls plus CSV/JSON, compile separate. Fourfreshprocesscontrols,normalGC/tiering,allocationseparate. Oneboundedsourcepair aftersemantics; retain/debt/refine/withdraw fromevidence, noforecast.',publicationHeld=True,qualified=False)
(r/'source-gate.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
print('R361baseline core/source/auxiliary images frozen; 5-file prototype before build.',identity['referenceCoreSHA256'],flush=True)
