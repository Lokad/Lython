from pathlib import Path
import base64,json,subprocess
r=Path(__file__).parent/'b740';c=json.loads((r/'config.json').read_text(encoding='utf-8'))
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
c=CONFIG
base=Path('/home/lokad/lython-bench-checks');lease=(base/'comparison-vm.lock').open('a');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
groups=[]
for proof in c['proofs']:
 paths=[]
 for p in base.rglob('*.dll'):
  if p.name not in {'Lokad.Lython.dll','candidate-core.dll','current-core.dll','reference-core.dll'}or p.stat().st_size!=proof['bytes']:continue
  if hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256']:paths.append(dict(path=str(p),inode=p.stat().st_ino,links=p.stat().st_nlink,uid=p.stat().st_uid))
 groups.append(dict(proof=proof,paths=paths))
print(json.dumps(dict(freshIdleLease=True,rootExists=Path(c['root']).exists(),fixtureMounts=[str(p)for p in base.glob('*/guest-fixtures')if os.path.ismount(p)],groups=groups,freeBytes=shutil.disk_usage(base).free)))
'''.replace('CONFIG',repr(c))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],capture_output=True,timeout=45);(r/'staging-diagnosis.json').write_bytes(done.stdout);assert done.returncode==0,done.stderr.decode();print(done.stdout.decode(),flush=True)
