import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / 'comparison' / 'quiet'
root = Path.cwd()
result = root / 'benchmarks' / 'results' / '2026-11-26-ready-shipment-rows'
identity = json.loads((quiet / 'identity.json').read_text(encoding='utf-8'))
patch = subprocess.check_output(['git', 'diff', '--binary', '--', 'src'])
assert patch == (lab / 'candidate.patch').read_bytes()
assert hashlib.sha256(patch).hexdigest() == identity['sourcePatchSHA256']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip() == identity['sourceRevision']
terminal = json.loads((quiet / 'terminal-status.json').read_text(encoding='utf-8'))
assert hashlib.sha256((quiet / 'observations.tar.xz').read_bytes()).hexdigest() == terminal['receipt']['archiveSHA256']
test_patch = lab / 'focused-tests.patch'
test_patch.write_bytes(subprocess.check_output(['git', 'diff', '--binary', '--', 'tests']))
result.mkdir(exist_ok=True)
for name in ('summary.json', 'allocation-summary.json'):
    shutil.copyfile(lab / name, result / name)
for name in ('identity.json', 'terminal-status.json', 'observations.tar.xz'):
    shutil.copyfile(quiet / name, result / name)

local_files = (
    'candidate.patch', 'focused-tests.patch', 'prepare.py', 'prepare-quiet.py',
    'quiet.py', 'summarize.py', 'archive.py', 'candidate-verify.json', 'reference-verify.json',
    'candidate-allocation.json', 'reference-allocation.json', 'frozen-build.log',
    'public-win.log', 'white-win.log', 'test-ubuntu.sh',
    'Lokad.Lython.PublicApi.Tests-ubuntu10.log', 'Lokad.Lython.Tests-ubuntu10.log',
)
quiet_files = ('launch.log', 'collect.py', 'run.sh', 'jobs.json', 'representative.json', 'cpython-worker.py')
template_files = ('prepare.py', 'quiet.py', 'comparison/quiet/collect.py', 'comparison/quiet/run.sh')
with tarfile.open(result / 'procedures.tar.xz', 'w:xz') as archive:
    for name in local_files:
        archive.add(lab / name, arcname=name)
    for name in quiet_files:
        archive.add(quiet / name, arcname='quiet/' + name)
    for name in template_files:
        archive.add(lab.parent / 'json-magnitude-utf8-20261126' / name, arcname='template/' + name)
with tarfile.open(result / 'procedures.tar.xz') as archive:
    assert archive.extractfile('candidate.patch').read() == patch
    assert len(archive.getmembers()) == len(local_files) + len(quiet_files) + len(template_files)