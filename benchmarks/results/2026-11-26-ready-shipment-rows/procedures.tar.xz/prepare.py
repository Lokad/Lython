from pathlib import Path

# Adapt the existing two-image build, verification and allocation procedure.
lab = Path(__file__).resolve().parent
template = lab.parent/'json-magnitude-utf8-20261126'/'prepare.py'
source = template.read_text(encoding='utf-8')
substitutions = {
    "baseline = lab.parent/'short-path-cpython-20261126'": "baseline = lab.parent/'json-magnitude-utf8-20261126'",
    "prior = lab.parent/'json-integer-r46'": "prior = lab.parent/'direct-zip-starmap-20261126'/'comparison/quiet'",
    "assert revision.startswith('0a0e32c16')": "assert revision.startswith('7ce34e1fa')",
    "== ['src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs']":
        "== ['src/Lokad.Lython/Runtime/PyCoreIterators.cs','src/Lokad.Lython/Runtime/PyItertools.Transforms.cs']",
    "assert before['sourceRevision']==revision and len(reference)==32":
        "assert git('diff','--binary',before['sourceRevision'],revision,'--','src') == (baseline/'candidate.patch').read_bytes()\n"
        "assert len(reference)==32",
    "catalog=read(prior/'catalog.json')\ncatalog['cases']=[case for case in catalog['cases'] if case['id'].startswith('scripts.json-summary-helpers.')]\nassert len(catalog['cases'])==3":
        "catalog=read(prior/'representative.json')\nassert len(catalog['cases'])==4",
    "checked['caseCount']==3": "checked['caseCount']==4",
    "f'{role}-refined-allocation.json'": "f'{role}-allocation.json'",
}
for old,new in substitutions.items():
    assert source.count(old)==1,old
    source=source.replace(old,new)
exec(compile(source,str(template),'exec'),{'__file__':str(lab/'prepare.py')})
