from pathlib import Path
from hashlib import sha256
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
local = lab/'local'
donor = lab.with_name('post-csv-json-cpython-20261127')
prior_collector = lab.with_name('converted-dictionary-update-20261126')/'comparison/quiet/collect.py'
out = lab/'comparison/quiet'
out.mkdir(parents=True)
read = lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p:sha256(p.read_bytes()).hexdigest()
write = lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
dump = lambda p,v:write(p,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
identity=read(local/'identity.json')
donor_image=read(donor/'comparison/quiet/identity.json')
donor_status=read(donor/'comparison/quiet/terminal-status.json')
donor_archive=donor_status['receipt']['archiveSHA256']
assert donor_archive==sha(donor/'comparison/quiet/observations.tar.xz')
core='Lokad.Lython.dll'
files=donor_image['imageFiles']['candidate']
assert identity['imageFiles']['reference']==files and len(files)==32
assert [k for k,v in files.items() if v!=identity['imageFiles']['candidate'][k]]==[core]
for role, manifest in identity['imageFiles'].items():
    checked=read(local/f'{role}-verify.json')
    assert checked['state']=='Completed' and checked['caseCount']==5
    assert checked['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert checked['launched']['library']['sha256']==manifest[core]
    assert {p.name:sha(p) for p in (local/role).iterdir()}==manifest
(out/'candidate').mkdir()
shutil.copyfile(local/'candidate'/core,out/'candidate'/core)
for name in ('representative.json','cpython-worker.py','run.sh'):
    shutil.copyfile(local/name,out/name)
assert sha(out/'representative.json')==identity['catalogs']['representative.json']['sha256']
assert b'\r' not in (out/'run.sh').read_bytes()
assert sha(out/'cpython-worker.py')==identity['cpythonWorkerSHA256']
jobs=read(local/'jobs.json')['warm']
dump(out/'jobs.json',{'warm':[jobs[1],jobs[0],jobs[4]]})
identity['catalogs']['jobs.json']['sha256']=sha(out/'jobs.json')
identity.update(donorArchiveSHA256=donor_archive,localArchiveSHA256=sha(local/'observations.tar.xz'),
                expectedCPythonSHA256=donor_image['expectedCPythonSHA256'])
dump(out/'identity.json',identity)
collector=prior_collector.read_text(encoding='utf8')
assert 'len(jobs) == 6' in collector and 'lython-b1763-fixtures' in collector
collector=collector.replace('len(jobs) == 6','len(jobs) == 3').replace('lython-b1763-fixtures','lython-b1846-fixtures')
collector=collector.replace('accumulate 7 seconds','accumulate 5 seconds')
collector=collector.replace("        catalog = root / 'representative.json'", "        assert shutil.disk_usage(root).free>=3*1024*1024\n        catalog = root / 'representative.json'")
compile(collector,'collect.py','exec')
write(out/'collect.py',collector)
summary=(lab/'summarize.py').read_text(encoding='utf8').replace("lab / 'local'","lab / 'comparison/quiet'")
summary=summary.replace("receipt['warmJobs'] == 5","receipt['warmJobs'] == 3").replace("len(raw['jobs']) == 5","len(raw['jobs']) == 3")
summary=summary.replace("assert receipt['quietBeforeAndAfter'] is None","assert receipt['quietBeforeAndAfter']").replace('timedBatches=140, quietQualified=False','timedBatches=84, quietQualified=True')
write(lab/'summarize-quiet.py',summary)
root='ready-dictreader-row-b1846-20261127'
names=['identity.json','representative.json','jobs.json','cpython-worker.py','run.sh','collect.py',f'candidate/{core}']
payload=out/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names:archive.add(out/name,arcname=name)
staged={name:dict(length=(out/name).stat().st_size,sha256=sha(out/name)) for name in names}
dump(out/'upload.json',dict(root=root,donor=read(donor/'comparison/quiet/upload.json')['root'],donorFiles=files,
     donorArchive=donor_archive,payloadSHA256=sha(payload),files=staged,
     expandedBytes=sum(x['length'] for x in staged.values()),minimumAfterStageBytes=6*1024*1024))
recipe=(donor/'quiet-vm.py').read_text(encoding='utf8').replace('lython-b1844-current-cpython-20261127','lython-b1846-ready-dictreader-row-20261127')
recipe=recipe.replace('--property=RuntimeMaxSec=380','--property=RuntimeMaxSec=200')
start=recipe.index(" files=image['imageFiles']['candidate']")
end=recipe.index(' assert sha(python)',start)
recipe=recipe[:start]+''' assert image['donorArchiveSHA256']==cfg['donorArchive']
 for role,files in image['imageFiles'].items():
  target=root/role
  target.mkdir(exist_ok=True)
  assert len(files)==32
  for name,digest in files.items():
   if (target/name).exists():
    assert role=='candidate' and name=='Lokad.Lython.dll' and sha(target/name)==digest
    continue
   assert cfg['donorFiles'][name]==digest
   os.link(origin/name,target/name)
  assert {p.name:sha(p) for p in target.iterdir()}==files
'''+recipe[end:]
start=recipe.index(" verification=root/'remote-verify.json'")
end=recipe.index(' after=shutil.disk_usage',start)
recipe=recipe[:start]+''' for role,files in image['imageFiles'].items():
  verification=root/f'{role}-remote-verify.json'
  subprocess.run([dotnet,root/role/'Lokad.Lython.Benchmarks.dll','--compare','verify',
   '--catalog',root/'representative.json','--dotnet',dotnet,'--python',python,
   '--python-worker',root/'cpython-worker.py','--out',verification],
   env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent)),check=True,timeout=35)
  proof=json.loads(verification.read_text())
  assert proof['state']=='Completed' and proof['caseCount']==5
  assert proof['catalogSha256']==image['catalogs']['representative.json']['sha256']
  assert proof['launched']['library']['sha256']==files['Lokad.Lython.dll']
  assert proof['launched']['adapter']['sha256']==files['Lokad.Lython.Benchmarks.dll']
'''+recipe[end:]
recipe=recipe.replace("'remote-verify.json','stage-custody.json'","'reference-remote-verify.json','candidate-remote-verify.json','stage-custody.json'")
compile(recipe,'quiet-vm.py','exec')
write(lab/'quiet-vm.py',recipe)
