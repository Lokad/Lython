from hashlib import sha256
from pathlib import Path
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
r = lab/'local'
cp = lab.with_name('post-csv-json-cpython-20261127')/'comparison/quiet/representative.json'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
write = lambda p,data: p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
hash_file = lambda p:sha256(p.read_bytes()).hexdigest()
control = next(case for case in read(cp)['cases'] if case['id']=='diagnostic.nested-json-document')
for name in ('identity.json','reference-verify.json','candidate-verify.json','representative.json','jobs.json'):
    shutil.copyfile(r/name,lab/f'four-case-{name}')
case_catalog = read(r/'representative.json')
assert len(case_catalog['cases']) == 4
case_catalog['cases'].append(control)
write(r/'representative.json',case_catalog)
jobs = read(r/'jobs.json')
jobs['warm'].append([control['id'],'warm'])
write(r/'jobs.json',jobs)
identity = read(r/'identity.json')
identity['purpose'] = 'Measure the ready DictReader row prefix on four CSV workloads with nested JSON as an unaffected control.'
identity['catalogs']={n:{'sha256':hash_file(r/n)} for n in ('representative.json','jobs.json')}
write(r/'identity.json',identity)
collector = r/'collect.py'
source = collector.read_text(encoding='utf-8')
assert source.count('len(jobs) == 4')==1
source=source.replace('len(jobs) == 4','len(jobs) == 5')
compile(source,'collect.py','exec')
collector.write_text(source,encoding='utf-8',newline='\n')
summary = lab/'summarize.py'
summary.write_text(summary.read_text(encoding='utf-8').replace("receipt['warmJobs'] == 4","receipt['warmJobs'] == 5").replace("len(raw['jobs']) == 4","len(raw['jobs']) == 5").replace('timedBatches=112','timedBatches=140'),encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and {p.name:hash_file(p) for p in (r/role).iterdir()}==files
    report=r/f'{role}-verify.json'
    subprocess.run([dotnet,r/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',r/'representative.json','--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',r/'cpython-worker.py','--out',report],env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=60)
    validated=read(report)
    assert validated['state']=='Completed' and validated['caseCount']==5
    assert validated['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert validated['launched']['adapter']['sha256']==files['Lokad.Lython.Benchmarks.dll']
    assert validated['launched']['library']['sha256']==files['Lokad.Lython.dll']
