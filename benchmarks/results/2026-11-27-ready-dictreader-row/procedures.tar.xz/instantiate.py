from pathlib import Path
from hashlib import sha256
import json
import shutil
import subprocess

lab = Path(__file__).resolve().parent
previous = lab.with_name('iterable-csv-records-20261127')
checkpoint = lab.with_name('post-csv-json-cpython-20261127')/'comparison/quiet'
profile = lab.with_name('post-cpython-shipment-cpu-20261127')/'comparison/quiet'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
paths = [checkpoint/'representative.json', profile/'catalog.json', previous/'representative.json']
base = read(paths[0])
available = {row['id']: row for path in paths for row in read(path)['cases']}
map_case = 'diagnostic.shipment-file-fed-map'
list_case = 'diagnostic.csv-summary-list-input'
quote_case = 'scripts.csv-invoice.method-policy.quoted-control'
wide_case = 'diagnostic.shipment-starmap-wide-lists'
base['cases'] = [available[key] for key in (map_case, list_case, quote_case, wide_case)]
(lab/'representative.json').write_text(json.dumps(base,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')

recipe = (previous/'prepare.py').read_text(encoding='utf-8')
recipe = recipe.replace("lab.with_name('inline-whole-regex-match-20261127')/'local'", "lab.with_name('post-csv-json-cpython-20261127')/'comparison/quiet'")
recipe = recipe.replace("assert head.startswith('6bed7e6c0')", "assert head.startswith('8f13c8209')\nassert not subprocess.check_output(['git','diff','a1b3a3325',head,'--','src','tests'],cwd=repo)")
recipe = recipe.replace("assert pin['sourceRevision'].startswith('3cb9a1240')", "assert pin['sourceRevision'].startswith('a1b3a3325')")
recipe = recipe.replace("file_fed='scripts.csv-summary-functions.large'", f"file_fed={map_case!r}")
recipe = recipe.replace("iterator_input='diagnostic.csv-summary-iterator-input'", f"wide={wide_case!r}")
recipe = recipe.replace('{file_fed,list_input,iterator_input,quoted}', '{file_fed,list_input,wide,quoted}')
recipe = recipe.replace("[quoted,'warm'],[iterator_input,'warm-async']", "[quoted,'warm-async'],[wide,'warm-async']")
recipe = recipe.replace("'rev-parse','6bed7e6c0'", "'rev-parse','a1b3a3325'")
recipe = recipe.replace("lython-iterable-csv-records-fixture-", "lython-ready-dictreader-row-fixture-")
recipe = recipe.replace('Use existing direct DictReader row admission for list and iterator input. Buffered and quoted inputs are controls.', 'Complete ready DictReader records without the general row state machine. Wide shipment and the quoted invoice are independent controls.')
assert 'a1b3a3325' in recipe and 'wide' in recipe and 'iterator_input' not in recipe
path = lab/'prepare.py'
path.write_text(recipe,encoding='utf-8',newline='\n')
for name in ('stage.sh', 'summarize.py'):
    shutil.copyfile(previous/name,lab/name)
assert b'\r' not in (lab/'stage.sh').read_bytes()
