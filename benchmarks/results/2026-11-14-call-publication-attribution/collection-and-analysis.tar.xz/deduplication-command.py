from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess,tarfile
proof=[{'commit': '4beb9ecf96769af57f937d72fba33363b57bac35', 'canonicalArchive': 'benchmarks/results/2026-11-14-protected-helper-activation/observations.tgz', 'remoteRoot': 'protected-activation-b756-20261114', 'archiveSHA256': '3c8368cd0ffd3db0082b9a3148ac4bf2f7a78aeead981ccf525d5c0f2404022b', 'member': 'confirmation/confirmation.json', 'bytes': 664536, 'sha256': '2459aa42b7113a1abbec7dc99b5af5f8956cc45ea3a9c82f6735cd57749e5d48'}, {'commit': '4beb9ecf96769af57f937d72fba33363b57bac35', 'canonicalArchive': 'benchmarks/results/2026-11-14-builtin-scalar-publication/observations.tgz', 'remoteRoot': 'scalar-results-b759-20261114', 'archiveSHA256': '20160450963b2396dcbfabbb98c962f8caeb6bd4f86a2f25e50e3068b96b84ed', 'member': 'confirmation/confirmation.json', 'bytes': 593360, 'sha256': '9216d3626200191e534a944089996c62bfdb147f04d624400bbd2f6601fe3aba'}]
required=23300
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(p.is_mount()for p in base.glob('*/guest-fixtures'))
 paths=[];observations=[]
 for item in proof:
  root=base/item['remoteRoot'];p=root/item['member'];archive=root/'observations.tgz'
  assert root.resolve()==root and p.resolve()==p and archive.resolve()==archive and p.is_relative_to(base)
  s=p.lstat();assert stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1 and s.st_size==item['bytes']
  assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
  assert hashlib.sha256(archive.read_bytes()).hexdigest()==item['archiveSHA256']
  with tarfile.open(archive)as a:assert hashlib.sha256(a.extractfile(item['member']).read()).hexdigest()==item['sha256']
  assert(root/'exit-code.txt').read_text().strip()=='0'and json.loads((root/'archive-receipt.json').read_text())['complete']
  paths.append(p);observations.append(dict(path=str(p),uid=s.st_uid,inode=s.st_ino,links=s.st_nlink,bytes=s.st_size,archiveStillPresent=str(archive)))
 before=shutil.disk_usage(base).free
 assert before+sum(item['bytes']for item in proof)>254*1024*1024+required+32768
 for p in paths:p.unlink()
 receipt=dict(committedProof=proof,metadata=observations,allPathsMetadataAndRawArchiveHashesVerifiedBeforeMutation=True,idleLease=True,retiredOnlyDuplicateJson=[str(p)for p in paths],beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,compressedRawArchivesAndLocalGitEvidenceRetained=True,currentImagesCatalogsToolchainsAndFloorsUnchanged=True)
 (base/'b760-proved-archived-json-deduplication.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt),flush=True)
