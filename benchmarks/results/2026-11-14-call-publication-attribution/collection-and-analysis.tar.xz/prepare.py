from pathlib import Path
import ast,hashlib,json,subprocess,tarfile

r=Path(__file__).parent;old=r.parent/'fulfillment-stage-r354';source=r.parent/'scalar-results-r370'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
frozen=json.loads((source/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(sha(n)==h for n,h in frozen['sources'].items())
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
remote='/home/lokad/lython-bench-checks/call-publication-b760-20261114';unit='lython-b760-call-publication-20261114'
assessment=dict(head=head,core=frozen['coreSHA256']['candidate'],sourceFindings=['Small native calls already copy evaluated arguments directly into final fixed private storage; wider calls share the admitted full locals array. No CallArgumentValue array or second local/operand backing on that path.','Ordinary/native entry already shares selected call binding and exact continuation. Copy avoidance by borrowing more caller slots would require lifetime/layout changes; no missing global arena justifies repeating slower R364/R268.','Normal DictReader transfers the funded field array into shared-key dictionary storage; no intermediate guest list or queued-row batch remains.','Split/case paths already write final UTF8 fragments/adopt final backing. No removed per-character/per-token conversion may be claimed again.'],question='Current complete invoice remains materially call/dispatch/collection mixed, and R370 invoice CPU is adverse despite lower allocation. One current-image whole-script sample should choose a real remaining stage; not a causal source-pair or forecast.',scope='One5s199Hz cpu-clock/fp invoice capture after8guest-seconds warmup; same-process native-body disassembly/PerfMap diagnostics only; complete script/worker/adapter/catalog unchanged. All thread CPU and unknown/ambiguous samples retained.',stopping='One usable attribution with source inspection: select a complete stage and displaced code, or explicitly decline a new call rewrite and move to collection/text/frontend. No another micro-optimization or unchanged timing campaign.',sourcePaths={n:frozen['sources'][n]for n in ['src/Lokad.Lython/Runtime/PyExecutableFunction.cs','src/Lokad.Lython/Runtime/PyFunctionBinding.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.Invoke.cs','src/Lokad.Lython/Runtime/LythonRuntime.CsvObjects.cs','src/Lokad.Lython/Runtime/LythonRuntime.CsvModule.cs','src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs','src/Lokad.Lython/Runtime/Text/PyStringOps.Helpers.cs']})
(r/'source-assessment.json').write_text(json.dumps(assessment,indent=2)+'\n',encoding='utf-8',newline='\n')
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision=head+'/frozen'+assessment['core'][:8],coreSHA256=frozen['coreSHA256'],catalogSHA256=sha(source/'catalog.json'),fullSourceIdentitySHA256=sha(source/'candidate-identity.json'),purpose=assessment['question'],diagnosticOnly=True,scriptCaptureWallSeconds=5,warmGuestSeconds=8,disassemblyCollectedInTheSameProcessAsSamples=True)
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['ops-profile.py','collect.py','run.sh','retrieve.py']:
    code=(old/name).read_text(encoding='utf-8').replace('fulfillment-stage-b726-20261114','call-publication-b760-20261114').replace('lython-b726-fulfillment-stage-20261114',unit).replace('B726','B760')
    code=code.replace("[('fulfillment','scripts.csv-fulfillment.large','warm')]","[('invoice','scripts.csv-invoice.large','warm')]").replace("['fulfillment']","['invoice']")
    code=code.replace('Committedf5817a15/frozen9cfb7d5b; R354 complete fulfillment stage attribution','Committed'+head+'/frozen'+assessment['core']+'; R371 complete invoice publication attribution')
    if name.endswith('.py'):ast.parse(code)
    (r/name).write_text(code,encoding='utf-8',newline='\n')
(r/'prospective.json').write_text(json.dumps(assessment,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'payload.tgz','w:gz')as t:
    for name in ['identity.json','prospective.json','ops-profile.py','collect.py','run.sh']:t.add(r/name,arcname=name)
with tarfile.open(r/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root=remote,sourceRoot='/home/lokad/lython-bench-checks/scalar-results-b759-20261114',unit=unit,identity=identity,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=sha(r/'payload.tgz'),unpackedBytes=unpacked)
code=(old/'launch-command.py').read_text(encoding='utf-8');a=code.index('config=');end=code.index('\nbase=',a);code=code[:a]+'config='+repr(config)+code[end:]
code=code.replace("assert digest(root/'catalog.json')==config['identity']['catalogSHA256']","assert digest(source/'representative.json')==config['identity']['catalogSHA256']\n os.link(source/'representative.json',root/'catalog.json')")
code=code.replace('lython-b726-fixtures','lython-b760-fixtures').replace('uploadedCatalog=True,noRetirement=True','uploadedCatalog=False,priorRawDeduplication="b760-proved-archived-json-deduplication.json"')
ast.parse(code);(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(prepared=True,productionUnchanged=True,unpackedBytes=unpacked,core=assessment['core'])),flush=True)
