; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       xor      eax, eax
       mov      qword ptr [rbp-0xB8], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0xB0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x70], zmm8
       vmovdqa  xmmword ptr [rbp-0x30], xmm8
       mov      qword ptr [rbp-0x20], rax
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
 
G_M000_IG02:                ;; offset=0x0047
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x58], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x58], 0
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0062
       mov      rdi, 0x7E4ED9A66F18
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA8], rax
       mov      rdi, gword ptr [rbp-0xA8]
       mov      rsi, 0x7E4ED46583C0
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG04:                ;; offset=0x009C
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG05
       mov      rdi, 0x7E4ED9BC6E20
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.LythonRunOptions:.ctor():this]
       mov      rax, gword ptr [rbp-0xA0]
       mov      gword ptr [rbp-0x18], rax
 
G_M000_IG05:                ;; offset=0x00D9
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_MemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x68], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x68], 0
       jne      SHORT G_M000_IG06
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x20]
       mov      gword ptr [rbp-0x90], rax
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x90], 0
       jne      SHORT G_M000_IG06
       vxorps   xmm0, xmm0, xmm0
       vmovups  xmmword ptr [rbp-0x48], xmm0
       mov      rdi, 0x7E4ED9B06988
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x98], rax
       mov      rsi, qword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x98]
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
       mov      rax, gword ptr [rbp-0x98]
       mov      gword ptr [rbp-0x70], rax
 
G_M000_IG06:                ;; offset=0x015B
       mov      rax, gword ptr [rbp-0x70]
       mov      gword ptr [rbp-0x28], rax
       mov      rdi, gword ptr [rbp-0x28]
       mov      r11, 0x7E4ED7C52098
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x30], rax
 
G_M000_IG07:                ;; offset=0x0178
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_ResultMemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, gword ptr [rbp-0x78]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x78], 0
       jne      SHORT G_M000_IG08
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rbp-0x80], rax
 
G_M000_IG08:                ;; offset=0x019F
       mov      rdi, gword ptr [rbp-0x80]
       mov      r11, 0x7E4ED7C520A0
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x38], rax
 
G_M000_IG09:                ;; offset=0x01B4
       mov      rdi, gword ptr [rbp-0x18]
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdx, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:WithMemoryOwners(Lokad.Lython.ILythonMemoryBudget,Lokad.Lython.ILythonMemoryBudget):Lokad.Lython.LythonRunOptions:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdx, gword ptr [rbp-0xB0]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rax, gword ptr [rbp-0x20]
       mov      rdi, gword ptr [rax+0x10]
       mov      rax, gword ptr [rbp-0x20]
       call     [rax+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, gword ptr [rbp-0xB8]
       mov      rsi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonExecutionResult:OwnMemoryScope(Lokad.Lython.ILythonMemoryScope):Lokad.Lython.LythonExecutionResult:this]
       mov      gword ptr [rbp-0x50], rax
 
G_M000_IG10:                ;; offset=0x0207
       call     G_M000_IG15
       nop      
 
G_M000_IG11:                ;; offset=0x020D
       mov      rax, gword ptr [rbp-0x50]
 
G_M000_IG12:                ;; offset=0x0211
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x021A
       push     rax
 
G_M000_IG14:                ;; offset=0x021B
       mov      gword ptr [rbp-0x88], rdi
       mov      rdi, gword ptr [rbp-0x38]
       mov      r11, 0x7E4ED7C520A8
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG15:                ;; offset=0x0239
       push     rax
 
G_M000_IG16:                ;; offset=0x023A
       cmp      gword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG17
       mov      rdi, gword ptr [rbp-0x30]
       mov      r11, 0x7E4ED7C520B0
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG17:                ;; offset=0x0252
       nop      
 
G_M000_IG18:                ;; offset=0x0253
       add      rsp, 8
       ret      
 
; Total bytes of code 600

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x5B0
       lea      rbp, [rsp+0x5B0]
       xor      eax, eax
       mov      qword ptr [rbp-0x5A8], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa32 xmmword ptr [rbp-0x5A0], xmm8
       vmovdqa32 xmmword ptr [rbp-0x590], xmm8
       mov      rax, -0x540
 
G_M000_IG132:                ;; offset=0x0036
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG132
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      bword ptr [rbp-0x38], rsi
 
G_M000_IG02:                ;; offset=0x005A
       mov      dword ptr [rbp-0x3D4], 0x3E8
       mov      rax, 0x7E46F9801A60
       mov      rsi, gword ptr [rax]
       mov      rdi, bword ptr [rbp-0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG122
 
G_M000_IG03:                ;; offset=0x007F
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rcx+0x40]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG127
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x40], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x1A8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3E0], rax
       mov      rsi, gword ptr [rbp-0x3E0]
       mov      rdi, gword ptr [rbp-0x1A8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x64], eax
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -3
       mov      dword ptr [rbp-0x5AC], eax
       cmp      dword ptr [rbp-0x5AC], 3
       ja       SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x010E
       mov      eax, dword ptr [rbp-0x5AC]
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG05:                ;; offset=0x012A
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -25
       mov      dword ptr [rbp-0x5B0], eax
       cmp      dword ptr [rbp-0x5B0], 43
       ja       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x013F
       mov      eax, dword ptr [rbp-0x5B0]
       lea      rcx, [reloc @RWD16]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG07:                ;; offset=0x015B
       mov      rdi, 0x7E4EDA73F348
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG120
 
G_M000_IG08:                ;; offset=0x016F
       mov      rdi, 0x7E4EDA73F34C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3E4], eax
       mov      esi, dword ptr [rbp-0x3E4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG125
 
G_M000_IG09:                ;; offset=0x01A9
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x3E8], eax
       mov      esi, dword ptr [rbp-0x3E8]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1AC], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x1AC]
       jg       SHORT G_M000_IG10
       mov      rdi, 0x7E4EDA73F350
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x1B8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1BC], eax
       mov      rax, bword ptr [rbp-0x1B8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x1BC], eax
       jae      G_M000_IG127
       mov      rax, bword ptr [rbp-0x1B8]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x1BC]
       xor      rdx, rdx
       mov      gword ptr [rax+8*rcx], rdx
 
G_M000_IG10:                ;; offset=0x025F
       mov      rdi, 0x7E4EDA73F354
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3EC], eax
       mov      esi, dword ptr [rbp-0x3EC]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG125
 
G_M000_IG11:                ;; offset=0x0299
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Collections.Generic.IReadOnlyList`1[System.Object]:this]
       mov      gword ptr [rbp-0x3B0], rax
       mov      rax, gword ptr [rbp-0x3B0]
       mov      gword ptr [rbp-0x3B8], rax
       mov      rdi, gword ptr [rbp-0x3B8]
       mov      rsi, 0x7E4EDA73F358
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3B8]
       mov      gword ptr [rbp-0x3F8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      dword ptr [rbp-0x3FC], eax
       mov      rdi, gword ptr [rbp-0x3F8]
       mov      esi, dword ptr [rbp-0x3FC]
       mov      r11, 0x7E4ED7C52630
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x408], rax
       mov      rdx, gword ptr [rbp-0x408]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG12:                ;; offset=0x0336
       mov      rdi, 0x7E4EDA73F460
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x3A4], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x410], rax
       mov      rdx, gword ptr [rbp-0x410]
       mov      esi, dword ptr [rbp-0x3A4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ReadLocal(int,Lokad.Lython.LythonSourceSpan):System.Object:this]
       mov      gword ptr [rbp-0x418], rax
       mov      rdx, gword ptr [rbp-0x418]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG13:                ;; offset=0x039E
       mov      rdi, 0x7E4EDA73F464
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x398], rax
       mov      rax, gword ptr [rbp-0x398]
       mov      gword ptr [rbp-0x3C0], rax
       mov      rdi, gword ptr [rbp-0x3C0]
       mov      rsi, 0x7E4EDA73F468
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3C0]
       mov      gword ptr [rbp-0x420], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x424], eax
       mov      rdi, gword ptr [rbp-0x420]
       mov      esi, dword ptr [rbp-0x424]
       mov      r11, 0x7E4ED7C52628
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x3A0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x430], rax
       mov      rsi, gword ptr [rbp-0x430]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0x3A0]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x438], rax
       mov      rdx, gword ptr [rbp-0x438]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG14:                ;; offset=0x0475
       mov      rax, bword ptr [rbp-0x30]
       mov      r8, gword ptr [rax+0x18]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       mov      rax, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rax+0x10]
       mov      rax, bword ptr [rbp-0x30]
       mov      edx, dword ptr [rax+0x40]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rax+0x44]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG15
       mov      rdi, 0x7E4EDA73F570
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       add      dword ptr [rax+0x40], 2
       jmp      G_M000_IG121
 
G_M000_IG15:                ;; offset=0x04C1
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x43C], eax
       mov      esi, dword ptr [rbp-0x43C]
       lea      rdx, [rbp-0x48]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG17
       mov      rdi, gword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       jne      SHORT G_M000_IG18
 
G_M000_IG16:                ;; offset=0x0500
       mov      rdi, 0x7E4EDA73F574
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:                ;; offset=0x050F
       mov      rdi, 0x7E4EDA73F578
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG18:                ;; offset=0x0523
       mov      rdi, 0x7E4EDA73F57C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG19:                ;; offset=0x0549
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x440], eax
       mov      esi, dword ptr [rbp-0x440]
       lea      rdx, [rbp-0x58]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG21
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_CanStoreThroughOwner():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x0581
       mov      rdi, 0x7E4EDA73F580
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG21:                ;; offset=0x0590
       mov      rdi, 0x7E4EDA73F584
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG22:                ;; offset=0x05A4
       mov      rdi, 0x7E4EDA73F588
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      gword ptr [rbp-0x60], rax
       mov      rdi, gword ptr [rbp-0x58]
       mov      rsi, gword ptr [rbp-0x60]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG23:                ;; offset=0x05DA
       mov      rdi, 0x7E4EDA73F58C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x360], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x364], eax
       mov      rax, bword ptr [rbp-0x360]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x364], eax
       jae      G_M000_IG127
       mov      rax, bword ptr [rbp-0x360]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x364]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x370], rax
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x370]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG121
 
G_M000_IG24:                ;; offset=0x0661
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x444], eax
       mov      esi, dword ptr [rbp-0x444]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x380], rax
       mov      rax, gword ptr [rbp-0x380]
       mov      gword ptr [rbp-0x3C8], rax
       mov      rdi, gword ptr [rbp-0x3C8]
       mov      rsi, 0x7E4EDA73F590
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3C8]
       mov      gword ptr [rbp-0x450], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x454], eax
       mov      rdi, gword ptr [rbp-0x450]
       mov      esi, dword ptr [rbp-0x454]
       mov      r11, 0x7E4ED7C52620
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x78], rax
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x7E4EDA29CCC8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG26
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x7E4EDA61CEE8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG25
       xor      rax, rax
       mov      gword ptr [rbp-0x388], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x073B
       mov      rdi, 0x7E4EDA73F698
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+DictMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x388], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x075D
       mov      rdi, 0x7E4EDA73F69C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+StringMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x388], rax
 
G_M000_IG27:                ;; offset=0x077D
       mov      rax, gword ptr [rbp-0x388]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       jne      SHORT G_M000_IG28
       mov      rdi, 0x7E4EDA73F6A0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG28:                ;; offset=0x07A3
       mov      rdi, 0x7E4EDA73F6A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x38C], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x458], eax
       mov      edx, dword ptr [rbp-0x458]
       mov      esi, dword ptr [rbp-0x38C]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x390], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x45C], eax
       mov      edx, dword ptr [rbp-0x45C]
       mov      esi, dword ptr [rbp-0x390]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG29:                ;; offset=0x082F
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG30
       mov      rdi, 0x7E4EDA73F6A8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG30:                ;; offset=0x0855
       mov      rdi, 0x7E4EDA73F6AC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG121
 
G_M000_IG31:                ;; offset=0x0869
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x460], eax
       mov      esi, dword ptr [rbp-0x460]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x258], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x464], eax
       mov      esi, dword ptr [rbp-0x464]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x88], rax
       mov      rsi, gword ptr [rbp-0x258]
       mov      rdi, 0x7E4EDA61CEE8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG33
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG34
       mov      rsi, gword ptr [rbp-0x88]
       mov      rdi, 0x7E4EDA29CCC8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x98], rax
       cmp      gword ptr [rbp-0x98], 0
       jne      SHORT G_M000_IG35
 
G_M000_IG32:                ;; offset=0x0921
       mov      rdi, 0x7E4EDA73F6B0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG33:                ;; offset=0x0930
       mov      rdi, 0x7E4EDA73F6B4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG34:                ;; offset=0x0944
       mov      rdi, 0x7E4EDA73F6B8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG33
 
G_M000_IG35:                ;; offset=0x0955
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       test     eax, eax
       jl       G_M000_IG38
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasSharedRecordKeys():bool:this]
       test     eax, eax
       je       G_M000_IG37
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x260], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x470], rax
       mov      rsi, gword ptr [rbp-0x470]
       mov      rdi, gword ptr [rbp-0x260]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:GetLookupCaches(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntime+ExecutableLookupCache[]:this]
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG127
       mov      edx, eax
       imul     rdx, rdx, 24
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x268], rcx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x270], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x478], rax
       mov      r8, gword ptr [rbp-0x478]
       lea      r9, [rbp-0xA8]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdx, bword ptr [rbp-0x268]
       mov      rcx, gword ptr [rbp-0x270]
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryReadRecordValue(Lokad.Lython.Runtime.Text.PyString,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG36
       mov      rdi, 0x7E4EDA73F6BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0xA8]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG36:                ;; offset=0x0A65
       mov      rdi, 0x7E4EDA73F6C0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x0A76
       mov      rdi, 0x7E4EDA73F6C4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG38:                ;; offset=0x0A85
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG39
       mov      rdi, 0x7E4EDA73F6C8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG39:                ;; offset=0x0AAC
       mov      rdi, 0x7E4EDA73F6CC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x480], rax
       mov      rdx, gword ptr [rbp-0x480]
       mov      rax, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rax+0x18]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdi, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x488], rax
       mov      rdx, gword ptr [rbp-0x488]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG40:                ;; offset=0x0B10
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x48C], eax
       mov      esi, dword ptr [rbp-0x48C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       test     eax, eax
       je       G_M000_IG43
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7E4EDA299378
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG42
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7E4ED8EA6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG41
       mov      rdi, 0x7E4EDA73F6D0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7E4ED8E735C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1E4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG41:                ;; offset=0x0BBA
       mov      rdi, 0x7E4EDA73F6D4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG42:                ;; offset=0x0BC9
       xor      eax, eax
       mov      dword ptr [rbp-0x1E4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x0BD3
       mov      rdi, 0x7E4EDA73F6D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1E4], eax
 
G_M000_IG44:                ;; offset=0x0BFD
       cmp      dword ptr [rbp-0x1E4], 0
       je       SHORT G_M000_IG45
       mov      rdi, 0x7E4EDA73F6DC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG45:                ;; offset=0x0C1A
       mov      rdi, 0x7E4EDA73F6E0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       mov      dword ptr [rbp-0x1E8], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x498], rax
       mov      rcx, gword ptr [rbp-0x498]
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rbp-0x1F0]
       mov      edi, dword ptr [rbp-0x1E8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateExecutableUnary(int,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x4A0], rax
       mov      rdx, gword ptr [rbp-0x4A0]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG46:                ;; offset=0x0C9B
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       jne      SHORT G_M000_IG48
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       cmp      eax, 3
       jne      SHORT G_M000_IG47
       mov      rdi, 0x7E4EDA73F6E4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG47:                ;; offset=0x0CCD
       mov      rdi, 0x7E4EDA73F6E8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG48:                ;; offset=0x0CDC
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerOperation(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG51
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4A4], eax
       mov      esi, dword ptr [rbp-0x4A4]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x4A8], eax
       mov      esi, dword ptr [rbp-0x4A8]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xC0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xC4], eax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG52
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x244], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x250], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4B0], rax
       mov      r8, gword ptr [rbp-0x4B0]
       lea      r9, [rbp-0xD0]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x250]
       mov      edi, dword ptr [rbp-0x244]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG50
       mov      rdi, 0x7E4EDA73F6EC
       call     CORINFO_HELP_COUNTPROFILE32
       movzx    rdi, byte  ptr [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(bool):System.Object]
       mov      gword ptr [rbp-0x4B8], rax
       mov      rdx, gword ptr [rbp-0x4B8]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
 
G_M000_IG49:                ;; offset=0x0E09
       jmp      G_M000_IG121
 
G_M000_IG50:                ;; offset=0x0E0E
       mov      rdi, 0x7E4EDA73F6F0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG52
 
G_M000_IG51:                ;; offset=0x0E1F
       mov      rdi, 0x7E4EDA73F6F4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG121
 
G_M000_IG52:                ;; offset=0x0E33
       cmp      dword ptr [rbp-0xC4], 0
       jne      SHORT G_M000_IG53
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1F4], eax
       jmp      SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0E4E
       mov      rdi, 0x7E4EDA73F6F8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       mov      dword ptr [rbp-0x1F4], eax
 
G_M000_IG54:                ;; offset=0x0E75
       mov      edi, dword ptr [rbp-0x1F4]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeBinary(int,System.Object,System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG55
       mov      rdi, 0x7E4EDA73F6FC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG55:                ;; offset=0x0EA7
       cmp      dword ptr [rbp-0xC4], 0
       je       G_M000_IG64
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7E4EDA299378
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG57
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7E4ED8EA6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG63
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7E4ED8E735C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       G_M000_IG62
 
G_M000_IG56:                ;; offset=0x0F10
       mov      rdi, 0x7E4EDA73F700
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG57:                ;; offset=0x0F1F
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7E4EDA299378
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG61
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7E4ED8EA6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG60
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7E4ED8E735C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x0F73
       mov      rdi, 0x7E4EDA73F704
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG59:                ;; offset=0x0F87
       mov      rdi, 0x7E4EDA73F708
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG64
 
G_M000_IG60:                ;; offset=0x0F98
       mov      rdi, 0x7E4EDA73F70C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG64
 
G_M000_IG61:                ;; offset=0x0FA9
       mov      rdi, 0x7E4EDA73F710
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG64
 
G_M000_IG62:                ;; offset=0x0FBA
       mov      rdi, 0x7E4EDA73F714
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG58
 
G_M000_IG63:                ;; offset=0x0FCB
       mov      rdi, 0x7E4EDA73F718
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG57
 
G_M000_IG64:                ;; offset=0x0FDF
       mov      rax, bword ptr [rbp-0x30]
       mov      bword ptr [rbp-0x200], rax
       mov      rax, bword ptr [rbp-0x40]
       mov      bword ptr [rbp-0x208], rax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG65
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x234], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x240], rax
       mov      rax, bword ptr [rbp-0x200]
       mov      bword ptr [rbp-0x220], rax
       mov      rax, bword ptr [rbp-0x208]
       mov      bword ptr [rbp-0x228], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4C0], rax
       mov      r8, gword ptr [rbp-0x4C0]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x240]
       mov      edi, dword ptr [rbp-0x234]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x230], rax
       jmp      G_M000_IG66
 
G_M000_IG65:                ;; offset=0x1082
       mov      rdi, 0x7E4EDA73F71C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      dword ptr [rbp-0x20C], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x218], rax
       mov      rax, bword ptr [rbp-0x200]
       mov      bword ptr [rbp-0x220], rax
       mov      rax, bword ptr [rbp-0x208]
       mov      bword ptr [rbp-0x228], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4C8], rax
       mov      r8, gword ptr [rbp-0x4C8]
       mov      rsi, gword ptr [rbp-0xC0]
       mov      edx, dword ptr [rbp-0x20C]
       mov      rcx, gword ptr [rbp-0x218]
       mov      rdi, gword ptr [rbp-0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateAugmentedBuiltin(System.Object,System.Object,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x230], rax
 
G_M000_IG66:                ;; offset=0x110C
       mov      rdi, 0x7E4EDA73F720
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x220]
       mov      rsi, bword ptr [rbp-0x228]
       mov      rdx, gword ptr [rbp-0x230]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG67:                ;; offset=0x113B
       lea      rdx, [rbp-0xD8]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerComparison(byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG69
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4CC], eax
       mov      esi, dword ptr [rbp-0x4CC]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xE0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x4D0], eax
       mov      esi, dword ptr [rbp-0x4D0]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xE8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1CC], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4D8], rax
       mov      r8, gword ptr [rbp-0x4D8]
       lea      r9, [rbp-0xD8]
       mov      rsi, gword ptr [rbp-0xE0]
       mov      rdx, gword ptr [rbp-0xE8]
       mov      rcx, gword ptr [rbp-0x1D8]
       mov      edi, dword ptr [rbp-0x1CC]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG68
       mov      rdi, 0x7E4EDA73F724
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG68:                ;; offset=0x1224
       mov      rdi, 0x7E4EDA73F728
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG69:                ;; offset=0x1233
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x4DC], eax
       mov      esi, dword ptr [rbp-0x4DC]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4E8], rax
       mov      rsi, gword ptr [rbp-0x4E8]
       mov      rdi, gword ptr [rbp-0x1C8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       movzx    rax, byte  ptr [rbp-0xD8]
       test     eax, eax
       jne      SHORT G_M000_IG70
       mov      rdi, 0x7E4EDA73F72C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG122
 
G_M000_IG70:                ;; offset=0x12B9
       mov      rdi, 0x7E4EDA73F730
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG121
 
G_M000_IG71:                ;; offset=0x12CD
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4EC], eax
       mov      esi, dword ptr [rbp-0x4EC]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xF0], rax
       mov      rdi, gword ptr [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG72
       mov      rdi, 0x7E4EDA73F734
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG72:                ;; offset=0x131B
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4F8], rax
       mov      rdx, gword ptr [rbp-0x4F8]
       mov      rsi, gword ptr [rbp-0x1E0]
       mov      rdi, gword ptr [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG73
       mov      rdi, 0x7E4EDA73F738
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG122
 
G_M000_IG73:                ;; offset=0x138D
       mov      rdi, 0x7E4EDA73F73C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG121
 
G_M000_IG74:                ;; offset=0x13A1
       mov      rdi, 0x7E4EDA73F740
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG122
 
G_M000_IG75:                ;; offset=0x13C6
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG76
       mov      rdi, 0x7E4EDA73F744
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x44]
       lea      esi, [rax-0x01]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG76:                ;; offset=0x13F7
       mov      rdi, 0x7E4EDA73F748
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG122
 
G_M000_IG77:                ;; offset=0x141C
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4FC], eax
       mov      esi, dword ptr [rbp-0x4FC]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xF8], rax
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E4EDA729D50
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG78
       mov      rdi, 0x7E4EDA73F74C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0xF8]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG78:                ;; offset=0x148A
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E4EDA621D10
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG80
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E4EDA29D778
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG85
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E4EDA7056F0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG84
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E4EDA371118
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG83
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E4EDA29CCC8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG82
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E4EDA61CEE8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG81
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E4EDA6D0640
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG86
 
G_M000_IG79:                ;; offset=0x155E
       mov      rdi, 0x7E4EDA73F750
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG80:                ;; offset=0x156D
       mov      dword ptr [rbp-0xFC], 1
       jmp      SHORT G_M000_IG87
 
G_M000_IG81:                ;; offset=0x1579
       mov      rdi, 0x7E4EDA73F754
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG82:                ;; offset=0x158A
       mov      rdi, 0x7E4EDA73F758
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG83:                ;; offset=0x159B
       mov      rdi, 0x7E4EDA73F75C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG84:                ;; offset=0x15AC
       mov      rdi, 0x7E4EDA73F760
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG85:                ;; offset=0x15BD
       mov      rdi, 0x7E4EDA73F764
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG86:                ;; offset=0x15CE
       mov      rdi, 0x7E4EDA73F768
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0xFC], eax
 
G_M000_IG87:                ;; offset=0x15E5
       cmp      dword ptr [rbp-0xFC], 0
       je       SHORT G_M000_IG88
       mov      rdi, 0x7E4EDA73F76C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x508], rax
       mov      rsi, gword ptr [rbp-0x508]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0xF8]
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      gword ptr [rbp-0x510], rax
       mov      rdx, gword ptr [rbp-0x510]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG88:                ;; offset=0x164B
       mov      rdi, 0x7E4EDA73F770
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG89:                ;; offset=0x165F
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x278], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x27C], eax
       mov      rax, bword ptr [rbp-0x278]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x27C], eax
       jae      G_M000_IG127
       mov      rax, bword ptr [rbp-0x278]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x27C]
       mov      rax, gword ptr [rax+8*rcx]
       mov      gword ptr [rbp-0x108], rax
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x60]
       call     [System.Span`1[long]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      G_M000_IG94
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7E4EDA61EF48
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x110], rax
       cmp      gword ptr [rbp-0x110], 0
       je       G_M000_IG92
       lea      rsi, [rbp-0x118]
       lea      rdx, [rbp-0x120]
       mov      rdi, gword ptr [rbp-0x110]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextInteger(byref,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG91
       movzx    rax, byte  ptr [rbp-0x118]
       test     eax, eax
       jne      SHORT G_M000_IG93
       mov      rdi, 0x7E4EDA73F774
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x514], eax
       mov      esi, dword ptr [rbp-0x514]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
 
G_M000_IG90:                ;; offset=0x1769
       jmp      G_M000_IG122
 
G_M000_IG91:                ;; offset=0x176E
       mov      rdi, 0x7E4EDA73F778
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG94
 
G_M000_IG92:                ;; offset=0x177F
       mov      rdi, 0x7E4EDA73F77C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG94
 
G_M000_IG93:                ;; offset=0x1790
       mov      rdi, 0x7E4EDA73F780
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, qword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:PublishInteger(byref,long):this]
       jmp      G_M000_IG121
 
G_M000_IG94:                ;; offset=0x17B9
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7E4EDA729D50
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x138], rax
       cmp      gword ptr [rbp-0x138], 0
       jne      G_M000_IG100
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7E4EDA61EF48
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x520], rax
       mov      rdi, gword ptr [rbp-0x520]
       lea      rsi, [rbp-0x140]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNext(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG97
       call     [Lokad.Lython.Runtime.PyIterationResult:get_End():Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2C0], rax
       mov      qword ptr [rbp-0x2B8], rdx
 
G_M000_IG95:                ;; offset=0x1831
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2C0]
       vmovdqu32 xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG96:                ;; offset=0x183F
       jmp      SHORT G_M000_IG102
 
G_M000_IG97:                ;; offset=0x1841
       mov      rdi, 0x7E4EDA73F784
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x140]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2B0], rax
       mov      qword ptr [rbp-0x2A8], rdx
 
G_M000_IG98:                ;; offset=0x186B
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2B0]
       vmovdqu32 xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG99:                ;; offset=0x1879
       jmp      SHORT G_M000_IG102
 
G_M000_IG100:                ;; offset=0x187B
       mov      rdi, 0x7E4EDA73F788
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x138]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      gword ptr [rbp-0x290], rax
       mov      qword ptr [rbp-0x288], rdx
 
G_M000_IG101:                ;; offset=0x18A7
       vmovdqu32 xmm0, xmmword ptr [rbp-0x290]
       vmovdqu32 xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG102:                ;; offset=0x18B5
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2A0]
       vmovdqu32 xmmword ptr [rbp-0x130], xmm0
 
G_M000_IG103:                ;; offset=0x18C3
       lea      rdi, [rbp-0x130]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_HasValue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG104
       mov      rdi, 0x7E4EDA73F78C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x524], eax
       mov      esi, dword ptr [rbp-0x524]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG122
 
G_M000_IG104:                ;; offset=0x1919
       mov      rdi, 0x7E4EDA73F790
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x130]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x530], rax
       mov      rdx, gword ptr [rbp-0x530]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG105:                ;; offset=0x1956
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x2C4], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x534], eax
       mov      edx, dword ptr [rbp-0x534]
       mov      esi, dword ptr [rbp-0x2C4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:MaterializeRange(int,int):this]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG106
       mov      rdi, 0x7E4EDA73F794
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG125
 
G_M000_IG106:                ;; offset=0x19B2
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       je       G_M000_IG107
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x2D8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x2DC], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x538], eax
       mov      ecx, dword ptr [rbp-0x538]
       mov      rdi, bword ptr [rbp-0x2D8]
       mov      edx, dword ptr [rbp-0x2DC]
       mov      rsi, 0x7E4ED9DEB4D0
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x2F0], rax
       mov      qword ptr [rbp-0x2E8], rdx
       mov      rsi, bword ptr [rbp-0x2F0]
       mov      rdx, qword ptr [rbp-0x2E8]
       mov      rdi, 0x7E4ED9DEB4D0
       call     [System.Span`1[System.__Canon]:op_Implicit(System.Span`1[System.__Canon]):System.ReadOnlySpan`1[System.__Canon]]
       mov      bword ptr [rbp-0x300], rax
       mov      qword ptr [rbp-0x2F8], rdx
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x308], rax
       mov      rdi, 0x7E4EDA29D778
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x310], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x540], rax
       mov      r8, gword ptr [rbp-0x540]
       mov      rax, bword ptr [rbp-0x30]
       mov      r9, gword ptr [rax+0x18]
       mov      rsi, bword ptr [rbp-0x300]
       mov      rdx, qword ptr [rbp-0x2F8]
       mov      rcx, gword ptr [rbp-0x308]
       mov      rdi, gword ptr [rbp-0x310]
       call     [Lokad.Lython.Runtime.PyTuple:.ctor(System.ReadOnlySpan`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):this]
       mov      rax, gword ptr [rbp-0x310]
       mov      gword ptr [rbp-0x2D0], rax
       jmp      SHORT G_M000_IG108
 
G_M000_IG107:                ;; offset=0x1AD5
       mov      rdi, 0x7E4EDA73F798
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, 0x7E46F9801958
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x2D0], rax
 
G_M000_IG108:                ;; offset=0x1AF8
       mov      rdi, 0x7E4EDA73F79C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x2D0]
       mov      gword ptr [rbp-0x148], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x544], eax
       mov      esi, dword ptr [rbp-0x544]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x148]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG109:                ;; offset=0x1B4F
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyList:EstimateCapacityBytes(int):long]
       mov      qword ptr [rbp-0x150], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x318], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x550], rax
       mov      rdx, gword ptr [rbp-0x550]
       mov      rsi, qword ptr [rbp-0x150]
       mov      rdi, gword ptr [rbp-0x318]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReserveTemporary(long,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:this]
       mov      gword ptr [rbp-0x158], rax
 
G_M000_IG110:                ;; offset=0x1BB4
       mov      rdi, 0x7E4EDA73F7A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x320], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x558], rax
       mov      rsi, gword ptr [rbp-0x558]
       mov      rdi, gword ptr [rbp-0x320]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x324], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x55C], eax
       mov      edx, dword ptr [rbp-0x55C]
       mov      esi, dword ptr [rbp-0x324]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:MaterializeRange(int,int):this]
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x330], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x334], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x560], eax
       mov      ecx, dword ptr [rbp-0x560]
       mov      rdi, bword ptr [rbp-0x330]
       mov      edx, dword ptr [rbp-0x334]
       mov      rsi, 0x7E4ED9DEB4D0
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x348], rax
       mov      qword ptr [rbp-0x340], rdx
 
G_M000_IG111:                ;; offset=0x1C95
       vmovdqu  xmm0, xmmword ptr [rbp-0x348]
       vmovdqu32 xmmword ptr [rbp-0x170], xmm0
 
G_M000_IG112:                ;; offset=0x1CA4
       lea      rdi, [rbp-0x170]
       mov      rsi, 0x7E4ED9DEB4D0
       call     [System.Span`1[System.__Canon]:ToArray():System.__Canon[]:this]
       mov      gword ptr [rbp-0x160], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x564], eax
       mov      esi, dword ptr [rbp-0x564]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, gword ptr [rbp-0x158]
       mov      rsi, qword ptr [rbp-0x150]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Commit(long):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x350], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x570], rax
       mov      rdx, gword ptr [rbp-0x570]
       mov      rsi, gword ptr [rbp-0x350]
       mov      rdi, gword ptr [rbp-0x160]
       call     [Lokad.Lython.Runtime.PyList:FromTransferredArray(System.Object[],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x578], rax
       mov      rdx, gword ptr [rbp-0x578]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       nop      
 
G_M000_IG113:                ;; offset=0x1D58
       call     G_M000_IG128
       jmp      G_M000_IG121
 
G_M000_IG114:                ;; offset=0x1D62
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG117
       mov      rdi, 0x7E4EDA73F8B4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG115:                ;; offset=0x1D83
       xor      eax, eax
 
G_M000_IG116:                ;; offset=0x1D85
       add      rsp, 0x5B0
       pop      rbp
       ret      
 
G_M000_IG117:                ;; offset=0x1D8E
       mov      rdi, 0x7E4EDA73F8B8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG121
 
G_M000_IG118:                ;; offset=0x1DA2
       mov      rdi, 0x7E4EDA73F8BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x354], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x358], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x584], eax
       mov      esi, dword ptr [rbp-0x584]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x590], rax
       mov      rcx, gword ptr [rbp-0x590]
       mov      esi, dword ptr [rbp-0x354]
       mov      edx, dword ptr [rbp-0x358]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG119:                ;; offset=0x1E1E
       mov      rdi, 0x7E4EDA73F8C0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x594], eax
       mov      esi, dword ptr [rbp-0x594]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x598], eax
       mov      esi, dword ptr [rbp-0x598]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG121
 
G_M000_IG120:                ;; offset=0x1E74
       lea      rdi, [rbp-0x198]
       mov      esi, 26
       mov      edx, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
       lea      rdi, [rbp-0x198]
       mov      rsi, 0x7E4ED465BB70
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendLiteral(System.String):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x59C], eax
       mov      esi, dword ptr [rbp-0x59C]
       lea      rdi, [rbp-0x198]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rdi, 0x7E4ED9587A68
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x378], rax
       lea      rdi, [rbp-0x198]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      gword ptr [rbp-0x5A8], rax
       mov      rsi, gword ptr [rbp-0x5A8]
       mov      rdi, gword ptr [rbp-0x378]
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0x378]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG121:                ;; offset=0x1F10
       mov      rdi, 0x7E4EDA73F8C4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       inc      dword ptr [rax+0x40]
 
G_M000_IG122:                ;; offset=0x1F26
       mov      eax, dword ptr [rbp-0x3D4]
       dec      eax
       mov      dword ptr [rbp-0x3D4], eax
       cmp      dword ptr [rbp-0x3D4], 0
       jg       SHORT G_M000_IG124
 
G_M000_IG123:                ;; offset=0x1F3D
       lea      rdi, [rbp-0x3D4]
       mov      esi, 0x9AF
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG124:                ;; offset=0x1F50
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x40]
       mov      dword ptr [rbp-0x19C], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x19C]
       jg       G_M000_IG03
       mov      rdi, 0x7E4EDA73F8C8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG125:                ;; offset=0x1F8B
       mov      eax, 1
 
G_M000_IG126:                ;; offset=0x1F90
       add      rsp, 0x5B0
       pop      rbp
       ret      
 
G_M000_IG127:                ;; offset=0x1F99
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG128:                ;; offset=0x1F9F
       push     rax
 
G_M000_IG129:                ;; offset=0x1FA0
       cmp      gword ptr [rbp-0x158], 0
       je       SHORT G_M000_IG130
       mov      rdi, 0x7E4EDA73F7A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rbp-0x3D0], rax
       mov      rdi, gword ptr [rbp-0x3D0]
       mov      rsi, 0x7E4EDA73F7A8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3D0]
       mov      gword ptr [rbp-0x580], rax
       mov      rdi, gword ptr [rbp-0x580]
       mov      r11, 0x7E4ED7C52618
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG130:                ;; offset=0x1FFF
       mov      rdi, 0x7E4EDA73F8B0
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG131:                ;; offset=0x200F
       add      rsp, 8
       ret      
 
RWD00  	dd	0000023Fh ; case G_M000_IG11
       	dd	000002DCh ; case G_M000_IG12
       	dd	0000041Bh ; case G_M000_IG14
       	dd	00000344h ; case G_M000_IG13
RWD16  	dd	00000607h ; case G_M000_IG24
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00000580h ; case G_M000_IG23
       	dd	000004EFh ; case G_M000_IG19
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001D48h ; case G_M000_IG118
       	dd	00001DC4h ; case G_M000_IG119
       	dd	00001AF5h ; case G_M000_IG109
       	dd	000018FCh ; case G_M000_IG105
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	000013C2h ; case G_M000_IG77
       	dd	00001605h ; case G_M000_IG89
       	dd	000007D5h ; case G_M000_IG29
       	dd	0000080Fh ; case G_M000_IG31
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00000C41h ; case G_M000_IG46
       	dd	00000C41h ; case G_M000_IG46
       	dd	00000AB6h ; case G_M000_IG40
       	dd	00001347h ; case G_M000_IG74
       	dd	00001273h ; case G_M000_IG71
       	dd	000010E1h ; case G_M000_IG67
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	0000014Fh ; case G_M000_IG09
       	dd	00000115h ; case G_M000_IG08
       	dd	00000115h ; case G_M000_IG08
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	0000136Ch ; case G_M000_IG75
       	dd	00001D08h ; case G_M000_IG114
       	dd	00001D08h ; case G_M000_IG114
       	dd	00001D08h ; case G_M000_IG114
       	dd	00001D08h ; case G_M000_IG114
       	dd	00001D08h ; case G_M000_IG114

; Total bytes of code 8212

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x5B0
       lea      rbp, [rsp+0x5B0]
       xor      eax, eax
       mov      qword ptr [rbp-0x5A8], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa32 xmmword ptr [rbp-0x5A0], xmm8
       vmovdqa32 xmmword ptr [rbp-0x590], xmm8
       mov      rax, -0x540
 
G_M000_IG132:                ;; offset=0x0036
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG132
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      bword ptr [rbp-0x38], rsi
 
G_M000_IG02:                ;; offset=0x005A
       mov      dword ptr [rbp-0x3D4], 0x3E8
       mov      rax, 0x7E46F9801A60
       mov      rsi, gword ptr [rax]
       mov      rdi, bword ptr [rbp-0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG122
 
G_M000_IG03:                ;; offset=0x007F
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rcx+0x40]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG127
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x40], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x1A8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3E0], rax
       mov      rsi, gword ptr [rbp-0x3E0]
       mov      rdi, gword ptr [rbp-0x1A8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x64], eax
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -3
       mov      dword ptr [rbp-0x5AC], eax
       cmp      dword ptr [rbp-0x5AC], 3
       ja       SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x010E
       mov      eax, dword ptr [rbp-0x5AC]
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG05:                ;; offset=0x012A
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -25
       mov      dword ptr [rbp-0x5B0], eax
       cmp      dword ptr [rbp-0x5B0], 43
       ja       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x013F
       mov      eax, dword ptr [rbp-0x5B0]
       lea      rcx, [reloc @RWD16]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG07:                ;; offset=0x015B
       mov      rdi, 0x7E4EDA73F348
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG120
 
G_M000_IG08:                ;; offset=0x016F
       mov      rdi, 0x7E4EDA73F34C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3E4], eax
       mov      esi, dword ptr [rbp-0x3E4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG125
 
G_M000_IG09:                ;; offset=0x01A9
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x3E8], eax
       mov      esi, dword ptr [rbp-0x3E8]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1AC], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x1AC]
       jg       SHORT G_M000_IG10
       mov      rdi, 0x7E4EDA73F350
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x1B8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1BC], eax
       mov      rax, bword ptr [rbp-0x1B8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x1BC], eax
       jae      G_M000_IG127
       mov      rax, bword ptr [rbp-0x1B8]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x1BC]
       xor      rdx, rdx
       mov      gword ptr [rax+8*rcx], rdx
 
G_M000_IG10:                ;; offset=0x025F
       mov      rdi, 0x7E4EDA73F354
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3EC], eax
       mov      esi, dword ptr [rbp-0x3EC]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG125
 
G_M000_IG11:                ;; offset=0x0299
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Collections.Generic.IReadOnlyList`1[System.Object]:this]
       mov      gword ptr [rbp-0x3B0], rax
       mov      rax, gword ptr [rbp-0x3B0]
       mov      gword ptr [rbp-0x3B8], rax
       mov      rdi, gword ptr [rbp-0x3B8]
       mov      rsi, 0x7E4EDA73F358
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3B8]
       mov      gword ptr [rbp-0x3F8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      dword ptr [rbp-0x3FC], eax
       mov      rdi, gword ptr [rbp-0x3F8]
       mov      esi, dword ptr [rbp-0x3FC]
       mov      r11, 0x7E4ED7C52BF8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x408], rax
       mov      rdx, gword ptr [rbp-0x408]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG12:                ;; offset=0x0336
       mov      rdi, 0x7E4EDA73F460
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x3A4], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x410], rax
       mov      rdx, gword ptr [rbp-0x410]
       mov      esi, dword ptr [rbp-0x3A4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ReadLocal(int,Lokad.Lython.LythonSourceSpan):System.Object:this]
       mov      gword ptr [rbp-0x418], rax
       mov      rdx, gword ptr [rbp-0x418]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG13:                ;; offset=0x039E
       mov      rdi, 0x7E4EDA73F464
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x398], rax
       mov      rax, gword ptr [rbp-0x398]
       mov      gword ptr [rbp-0x3C0], rax
       mov      rdi, gword ptr [rbp-0x3C0]
       mov      rsi, 0x7E4EDA73F468
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3C0]
       mov      gword ptr [rbp-0x420], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x424], eax
       mov      rdi, gword ptr [rbp-0x420]
       mov      esi, dword ptr [rbp-0x424]
       mov      r11, 0x7E4ED7C52BF0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x3A0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x430], rax
       mov      rsi, gword ptr [rbp-0x430]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0x3A0]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x438], rax
       mov      rdx, gword ptr [rbp-0x438]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG14:                ;; offset=0x0475
       mov      rax, bword ptr [rbp-0x30]
       mov      r8, gword ptr [rax+0x18]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       mov      rax, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rax+0x10]
       mov      rax, bword ptr [rbp-0x30]
       mov      edx, dword ptr [rax+0x40]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rax+0x44]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG15
       mov      rdi, 0x7E4EDA73F570
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       add      dword ptr [rax+0x40], 2
       jmp      G_M000_IG121
 
G_M000_IG15:                ;; offset=0x04C1
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x43C], eax
       mov      esi, dword ptr [rbp-0x43C]
       lea      rdx, [rbp-0x48]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG17
       mov      rdi, gword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       jne      SHORT G_M000_IG18
 
G_M000_IG16:                ;; offset=0x0500
       mov      rdi, 0x7E4EDA73F574
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:                ;; offset=0x050F
       mov      rdi, 0x7E4EDA73F578
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG18:                ;; offset=0x0523
       mov      rdi, 0x7E4EDA73F57C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG19:                ;; offset=0x0549
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x440], eax
       mov      esi, dword ptr [rbp-0x440]
       lea      rdx, [rbp-0x58]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG21
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_CanStoreThroughOwner():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x0581
       mov      rdi, 0x7E4EDA73F580
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG21:                ;; offset=0x0590
       mov      rdi, 0x7E4EDA73F584
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG22:                ;; offset=0x05A4
       mov      rdi, 0x7E4EDA73F588
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      gword ptr [rbp-0x60], rax
       mov      rdi, gword ptr [rbp-0x58]
       mov      rsi, gword ptr [rbp-0x60]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG23:                ;; offset=0x05DA
       mov      rdi, 0x7E4EDA73F58C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x360], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x364], eax
       mov      rax, bword ptr [rbp-0x360]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x364], eax
       jae      G_M000_IG127
       mov      rax, bword ptr [rbp-0x360]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x364]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x370], rax
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x370]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG121
 
G_M000_IG24:                ;; offset=0x0661
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x444], eax
       mov      esi, dword ptr [rbp-0x444]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x380], rax
       mov      rax, gword ptr [rbp-0x380]
       mov      gword ptr [rbp-0x3C8], rax
       mov      rdi, gword ptr [rbp-0x3C8]
       mov      rsi, 0x7E4EDA73F590
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3C8]
       mov      gword ptr [rbp-0x450], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x454], eax
       mov      rdi, gword ptr [rbp-0x450]
       mov      esi, dword ptr [rbp-0x454]
       mov      r11, 0x7E4ED7C52BE8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x78], rax
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x7E4EDA29CCC8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG26
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x7E4EDA61CEE8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG25
       xor      rax, rax
       mov      gword ptr [rbp-0x388], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x073B
       mov      rdi, 0x7E4EDA73F698
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+DictMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x388], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x075D
       mov      rdi, 0x7E4EDA73F69C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+StringMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x388], rax
 
G_M000_IG27:                ;; offset=0x077D
       mov      rax, gword ptr [rbp-0x388]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       jne      SHORT G_M000_IG28
       mov      rdi, 0x7E4EDA73F6A0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG28:                ;; offset=0x07A3
       mov      rdi, 0x7E4EDA73F6A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x38C], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x458], eax
       mov      edx, dword ptr [rbp-0x458]
       mov      esi, dword ptr [rbp-0x38C]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x390], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x45C], eax
       mov      edx, dword ptr [rbp-0x45C]
       mov      esi, dword ptr [rbp-0x390]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG29:                ;; offset=0x082F
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG30
       mov      rdi, 0x7E4EDA73F6A8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG30:                ;; offset=0x0855
       mov      rdi, 0x7E4EDA73F6AC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG121
 
G_M000_IG31:                ;; offset=0x0869
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x460], eax
       mov      esi, dword ptr [rbp-0x460]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x258], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x464], eax
       mov      esi, dword ptr [rbp-0x464]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x88], rax
       mov      rsi, gword ptr [rbp-0x258]
       mov      rdi, 0x7E4EDA61CEE8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG33
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG34
       mov      rsi, gword ptr [rbp-0x88]
       mov      rdi, 0x7E4EDA29CCC8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x98], rax
       cmp      gword ptr [rbp-0x98], 0
       jne      SHORT G_M000_IG35
 
G_M000_IG32:                ;; offset=0x0921
       mov      rdi, 0x7E4EDA73F6B0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG33:                ;; offset=0x0930
       mov      rdi, 0x7E4EDA73F6B4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG34:                ;; offset=0x0944
       mov      rdi, 0x7E4EDA73F6B8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG33
 
G_M000_IG35:                ;; offset=0x0955
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       test     eax, eax
       jl       G_M000_IG38
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasSharedRecordKeys():bool:this]
       test     eax, eax
       je       G_M000_IG37
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x260], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x470], rax
       mov      rsi, gword ptr [rbp-0x470]
       mov      rdi, gword ptr [rbp-0x260]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:GetLookupCaches(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntime+ExecutableLookupCache[]:this]
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG127
       mov      edx, eax
       imul     rdx, rdx, 24
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x268], rcx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x270], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x478], rax
       mov      r8, gword ptr [rbp-0x478]
       lea      r9, [rbp-0xA8]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdx, bword ptr [rbp-0x268]
       mov      rcx, gword ptr [rbp-0x270]
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryReadRecordValue(Lokad.Lython.Runtime.Text.PyString,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG36
       mov      rdi, 0x7E4EDA73F6BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0xA8]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG36:                ;; offset=0x0A65
       mov      rdi, 0x7E4EDA73F6C0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x0A76
       mov      rdi, 0x7E4EDA73F6C4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG38:                ;; offset=0x0A85
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG39
       mov      rdi, 0x7E4EDA73F6C8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG39:                ;; offset=0x0AAC
       mov      rdi, 0x7E4EDA73F6CC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x480], rax
       mov      rdx, gword ptr [rbp-0x480]
       mov      rax, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rax+0x18]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdi, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x488], rax
       mov      rdx, gword ptr [rbp-0x488]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG40:                ;; offset=0x0B10
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x48C], eax
       mov      esi, dword ptr [rbp-0x48C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       test     eax, eax
       je       G_M000_IG43
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7E4EDA299378
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG42
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7E4ED8EA6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG41
       mov      rdi, 0x7E4EDA73F6D0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7E4ED8E735C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1E4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG41:                ;; offset=0x0BBA
       mov      rdi, 0x7E4EDA73F6D4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG42:                ;; offset=0x0BC9
       xor      eax, eax
       mov      dword ptr [rbp-0x1E4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x0BD3
       mov      rdi, 0x7E4EDA73F6D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1E4], eax
 
G_M000_IG44:                ;; offset=0x0BFD
       cmp      dword ptr [rbp-0x1E4], 0
       je       SHORT G_M000_IG45
       mov      rdi, 0x7E4EDA73F6DC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG45:                ;; offset=0x0C1A
       mov      rdi, 0x7E4EDA73F6E0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       mov      dword ptr [rbp-0x1E8], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x498], rax
       mov      rcx, gword ptr [rbp-0x498]
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rbp-0x1F0]
       mov      edi, dword ptr [rbp-0x1E8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateExecutableUnary(int,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x4A0], rax
       mov      rdx, gword ptr [rbp-0x4A0]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG46:                ;; offset=0x0C9B
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       jne      SHORT G_M000_IG48
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       cmp      eax, 3
       jne      SHORT G_M000_IG47
       mov      rdi, 0x7E4EDA73F6E4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG47:                ;; offset=0x0CCD
       mov      rdi, 0x7E4EDA73F6E8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG48:                ;; offset=0x0CDC
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerOperation(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG51
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4A4], eax
       mov      esi, dword ptr [rbp-0x4A4]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x4A8], eax
       mov      esi, dword ptr [rbp-0x4A8]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xC0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xC4], eax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG52
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x244], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x250], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4B0], rax
       mov      r8, gword ptr [rbp-0x4B0]
       lea      r9, [rbp-0xD0]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x250]
       mov      edi, dword ptr [rbp-0x244]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG50
       mov      rdi, 0x7E4EDA73F6EC
       call     CORINFO_HELP_COUNTPROFILE32
       movzx    rdi, byte  ptr [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(bool):System.Object]
       mov      gword ptr [rbp-0x4B8], rax
       mov      rdx, gword ptr [rbp-0x4B8]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
 
G_M000_IG49:                ;; offset=0x0E09
       jmp      G_M000_IG121
 
G_M000_IG50:                ;; offset=0x0E0E
       mov      rdi, 0x7E4EDA73F6F0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG52
 
G_M000_IG51:                ;; offset=0x0E1F
       mov      rdi, 0x7E4EDA73F6F4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG121
 
G_M000_IG52:                ;; offset=0x0E33
       cmp      dword ptr [rbp-0xC4], 0
       jne      SHORT G_M000_IG53
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1F4], eax
       jmp      SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0E4E
       mov      rdi, 0x7E4EDA73F6F8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       mov      dword ptr [rbp-0x1F4], eax
 
G_M000_IG54:                ;; offset=0x0E75
       mov      edi, dword ptr [rbp-0x1F4]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeBinary(int,System.Object,System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG55
       mov      rdi, 0x7E4EDA73F6FC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG55:                ;; offset=0x0EA7
       cmp      dword ptr [rbp-0xC4], 0
       je       G_M000_IG64
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7E4EDA299378
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG57
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7E4ED8EA6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG63
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7E4ED8E735C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       G_M000_IG62
 
G_M000_IG56:                ;; offset=0x0F10
       mov      rdi, 0x7E4EDA73F700
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG57:                ;; offset=0x0F1F
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7E4EDA299378
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG61
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7E4ED8EA6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG60
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7E4ED8E735C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x0F73
       mov      rdi, 0x7E4EDA73F704
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG59:                ;; offset=0x0F87
       mov      rdi, 0x7E4EDA73F708
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG64
 
G_M000_IG60:                ;; offset=0x0F98
       mov      rdi, 0x7E4EDA73F70C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG64
 
G_M000_IG61:                ;; offset=0x0FA9
       mov      rdi, 0x7E4EDA73F710
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG64
 
G_M000_IG62:                ;; offset=0x0FBA
       mov      rdi, 0x7E4EDA73F714
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG58
 
G_M000_IG63:                ;; offset=0x0FCB
       mov      rdi, 0x7E4EDA73F718
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG57
 
G_M000_IG64:                ;; offset=0x0FDF
       mov      rax, bword ptr [rbp-0x30]
       mov      bword ptr [rbp-0x200], rax
       mov      rax, bword ptr [rbp-0x40]
       mov      bword ptr [rbp-0x208], rax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG65
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x234], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x240], rax
       mov      rax, bword ptr [rbp-0x200]
       mov      bword ptr [rbp-0x220], rax
       mov      rax, bword ptr [rbp-0x208]
       mov      bword ptr [rbp-0x228], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4C0], rax
       mov      r8, gword ptr [rbp-0x4C0]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x240]
       mov      edi, dword ptr [rbp-0x234]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x230], rax
       jmp      G_M000_IG66
 
G_M000_IG65:                ;; offset=0x1082
       mov      rdi, 0x7E4EDA73F71C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      dword ptr [rbp-0x20C], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x218], rax
       mov      rax, bword ptr [rbp-0x200]
       mov      bword ptr [rbp-0x220], rax
       mov      rax, bword ptr [rbp-0x208]
       mov      bword ptr [rbp-0x228], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4C8], rax
       mov      r8, gword ptr [rbp-0x4C8]
       mov      rsi, gword ptr [rbp-0xC0]
       mov      edx, dword ptr [rbp-0x20C]
       mov      rcx, gword ptr [rbp-0x218]
       mov      rdi, gword ptr [rbp-0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateAugmentedBuiltin(System.Object,System.Object,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x230], rax
 
G_M000_IG66:                ;; offset=0x110C
       mov      rdi, 0x7E4EDA73F720
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x220]
       mov      rsi, bword ptr [rbp-0x228]
       mov      rdx, gword ptr [rbp-0x230]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG67:                ;; offset=0x113B
       lea      rdx, [rbp-0xD8]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerComparison(byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG69
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4CC], eax
       mov      esi, dword ptr [rbp-0x4CC]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xE0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x4D0], eax
       mov      esi, dword ptr [rbp-0x4D0]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xE8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1CC], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4D8], rax
       mov      r8, gword ptr [rbp-0x4D8]
       lea      r9, [rbp-0xD8]
       mov      rsi, gword ptr [rbp-0xE0]
       mov      rdx, gword ptr [rbp-0xE8]
       mov      rcx, gword ptr [rbp-0x1D8]
       mov      edi, dword ptr [rbp-0x1CC]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG68
       mov      rdi, 0x7E4EDA73F724
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG68:                ;; offset=0x1224
       mov      rdi, 0x7E4EDA73F728
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG69:                ;; offset=0x1233
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x4DC], eax
       mov      esi, dword ptr [rbp-0x4DC]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4E8], rax
       mov      rsi, gword ptr [rbp-0x4E8]
       mov      rdi, gword ptr [rbp-0x1C8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       movzx    rax, byte  ptr [rbp-0xD8]
       test     eax, eax
       jne      SHORT G_M000_IG70
       mov      rdi, 0x7E4EDA73F72C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG122
 
G_M000_IG70:                ;; offset=0x12B9
       mov      rdi, 0x7E4EDA73F730
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG121
 
G_M000_IG71:                ;; offset=0x12CD
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4EC], eax
       mov      esi, dword ptr [rbp-0x4EC]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xF0], rax
       mov      rdi, gword ptr [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG72
       mov      rdi, 0x7E4EDA73F734
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG72:                ;; offset=0x131B
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4F8], rax
       mov      rdx, gword ptr [rbp-0x4F8]
       mov      rsi, gword ptr [rbp-0x1E0]
       mov      rdi, gword ptr [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG73
       mov      rdi, 0x7E4EDA73F738
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG122
 
G_M000_IG73:                ;; offset=0x138D
       mov      rdi, 0x7E4EDA73F73C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG121
 
G_M000_IG74:                ;; offset=0x13A1
       mov      rdi, 0x7E4EDA73F740
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG122
 
G_M000_IG75:                ;; offset=0x13C6
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG76
       mov      rdi, 0x7E4EDA73F744
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x44]
       lea      esi, [rax-0x01]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG76:                ;; offset=0x13F7
       mov      rdi, 0x7E4EDA73F748
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG122
 
G_M000_IG77:                ;; offset=0x141C
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4FC], eax
       mov      esi, dword ptr [rbp-0x4FC]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xF8], rax
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E4EDA729D50
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG78
       mov      rdi, 0x7E4EDA73F74C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0xF8]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG78:                ;; offset=0x148A
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E4EDA621D10
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG80
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E4EDA29D778
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG85
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E4EDA7056F0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG84
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E4EDA371118
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG83
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E4EDA29CCC8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG82
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E4EDA61CEE8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG81
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E4EDA6D0640
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG86
 
G_M000_IG79:                ;; offset=0x155E
       mov      rdi, 0x7E4EDA73F750
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG80:                ;; offset=0x156D
       mov      dword ptr [rbp-0xFC], 1
       jmp      SHORT G_M000_IG87
 
G_M000_IG81:                ;; offset=0x1579
       mov      rdi, 0x7E4EDA73F754
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG82:                ;; offset=0x158A
       mov      rdi, 0x7E4EDA73F758
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG83:                ;; offset=0x159B
       mov      rdi, 0x7E4EDA73F75C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG84:                ;; offset=0x15AC
       mov      rdi, 0x7E4EDA73F760
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG85:                ;; offset=0x15BD
       mov      rdi, 0x7E4EDA73F764
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG86:                ;; offset=0x15CE
       mov      rdi, 0x7E4EDA73F768
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0xFC], eax
 
G_M000_IG87:                ;; offset=0x15E5
       cmp      dword ptr [rbp-0xFC], 0
       je       SHORT G_M000_IG88
       mov      rdi, 0x7E4EDA73F76C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x508], rax
       mov      rsi, gword ptr [rbp-0x508]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0xF8]
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      gword ptr [rbp-0x510], rax
       mov      rdx, gword ptr [rbp-0x510]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG88:                ;; offset=0x164B
       mov      rdi, 0x7E4EDA73F770
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG89:                ;; offset=0x165F
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x278], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x27C], eax
       mov      rax, bword ptr [rbp-0x278]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x27C], eax
       jae      G_M000_IG127
       mov      rax, bword ptr [rbp-0x278]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x27C]
       mov      rax, gword ptr [rax+8*rcx]
       mov      gword ptr [rbp-0x108], rax
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x60]
       call     [System.Span`1[long]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      G_M000_IG94
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7E4EDA61EF48
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x110], rax
       cmp      gword ptr [rbp-0x110], 0
       je       G_M000_IG92
       lea      rsi, [rbp-0x118]
       lea      rdx, [rbp-0x120]
       mov      rdi, gword ptr [rbp-0x110]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextInteger(byref,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG91
       movzx    rax, byte  ptr [rbp-0x118]
       test     eax, eax
       jne      SHORT G_M000_IG93
       mov      rdi, 0x7E4EDA73F774
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x514], eax
       mov      esi, dword ptr [rbp-0x514]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
 
G_M000_IG90:                ;; offset=0x1769
       jmp      G_M000_IG122
 
G_M000_IG91:                ;; offset=0x176E
       mov      rdi, 0x7E4EDA73F778
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG94
 
G_M000_IG92:                ;; offset=0x177F
       mov      rdi, 0x7E4EDA73F77C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG94
 
G_M000_IG93:                ;; offset=0x1790
       mov      rdi, 0x7E4EDA73F780
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, qword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:PublishInteger(byref,long):this]
       jmp      G_M000_IG121
 
G_M000_IG94:                ;; offset=0x17B9
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7E4EDA729D50
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x138], rax
       cmp      gword ptr [rbp-0x138], 0
       jne      G_M000_IG100
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7E4EDA61EF48
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x520], rax
       mov      rdi, gword ptr [rbp-0x520]
       lea      rsi, [rbp-0x140]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNext(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG97
       call     [Lokad.Lython.Runtime.PyIterationResult:get_End():Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2C0], rax
       mov      qword ptr [rbp-0x2B8], rdx
 
G_M000_IG95:                ;; offset=0x1831
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2C0]
       vmovdqu32 xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG96:                ;; offset=0x183F
       jmp      SHORT G_M000_IG102
 
G_M000_IG97:                ;; offset=0x1841
       mov      rdi, 0x7E4EDA73F784
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x140]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2B0], rax
       mov      qword ptr [rbp-0x2A8], rdx
 
G_M000_IG98:                ;; offset=0x186B
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2B0]
       vmovdqu32 xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG99:                ;; offset=0x1879
       jmp      SHORT G_M000_IG102
 
G_M000_IG100:                ;; offset=0x187B
       mov      rdi, 0x7E4EDA73F788
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x138]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      gword ptr [rbp-0x290], rax
       mov      qword ptr [rbp-0x288], rdx
 
G_M000_IG101:                ;; offset=0x18A7
       vmovdqu32 xmm0, xmmword ptr [rbp-0x290]
       vmovdqu32 xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG102:                ;; offset=0x18B5
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2A0]
       vmovdqu32 xmmword ptr [rbp-0x130], xmm0
 
G_M000_IG103:                ;; offset=0x18C3
       lea      rdi, [rbp-0x130]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_HasValue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG104
       mov      rdi, 0x7E4EDA73F78C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x524], eax
       mov      esi, dword ptr [rbp-0x524]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG122
 
G_M000_IG104:                ;; offset=0x1919
       mov      rdi, 0x7E4EDA73F790
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x130]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x530], rax
       mov      rdx, gword ptr [rbp-0x530]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG105:                ;; offset=0x1956
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x2C4], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x534], eax
       mov      edx, dword ptr [rbp-0x534]
       mov      esi, dword ptr [rbp-0x2C4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:MaterializeRange(int,int):this]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG106
       mov      rdi, 0x7E4EDA73F794
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG125
 
G_M000_IG106:                ;; offset=0x19B2
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       je       G_M000_IG107
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x2D8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x2DC], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x538], eax
       mov      ecx, dword ptr [rbp-0x538]
       mov      rdi, bword ptr [rbp-0x2D8]
       mov      edx, dword ptr [rbp-0x2DC]
       mov      rsi, 0x7E4ED9DEB4D0
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x2F0], rax
       mov      qword ptr [rbp-0x2E8], rdx
       mov      rsi, bword ptr [rbp-0x2F0]
       mov      rdx, qword ptr [rbp-0x2E8]
       mov      rdi, 0x7E4ED9DEB4D0
       call     [System.Span`1[System.__Canon]:op_Implicit(System.Span`1[System.__Canon]):System.ReadOnlySpan`1[System.__Canon]]
       mov      bword ptr [rbp-0x300], rax
       mov      qword ptr [rbp-0x2F8], rdx
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x308], rax
       mov      rdi, 0x7E4EDA29D778
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x310], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x540], rax
       mov      r8, gword ptr [rbp-0x540]
       mov      rax, bword ptr [rbp-0x30]
       mov      r9, gword ptr [rax+0x18]
       mov      rsi, bword ptr [rbp-0x300]
       mov      rdx, qword ptr [rbp-0x2F8]
       mov      rcx, gword ptr [rbp-0x308]
       mov      rdi, gword ptr [rbp-0x310]
       call     [Lokad.Lython.Runtime.PyTuple:.ctor(System.ReadOnlySpan`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):this]
       mov      rax, gword ptr [rbp-0x310]
       mov      gword ptr [rbp-0x2D0], rax
       jmp      SHORT G_M000_IG108
 
G_M000_IG107:                ;; offset=0x1AD5
       mov      rdi, 0x7E4EDA73F798
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, 0x7E46F9801958
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x2D0], rax
 
G_M000_IG108:                ;; offset=0x1AF8
       mov      rdi, 0x7E4EDA73F79C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x2D0]
       mov      gword ptr [rbp-0x148], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x544], eax
       mov      esi, dword ptr [rbp-0x544]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x148]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG109:                ;; offset=0x1B4F
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyList:EstimateCapacityBytes(int):long]
       mov      qword ptr [rbp-0x150], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x318], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x550], rax
       mov      rdx, gword ptr [rbp-0x550]
       mov      rsi, qword ptr [rbp-0x150]
       mov      rdi, gword ptr [rbp-0x318]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReserveTemporary(long,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:this]
       mov      gword ptr [rbp-0x158], rax
 
G_M000_IG110:                ;; offset=0x1BB4
       mov      rdi, 0x7E4EDA73F7A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x320], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x558], rax
       mov      rsi, gword ptr [rbp-0x558]
       mov      rdi, gword ptr [rbp-0x320]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x324], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x55C], eax
       mov      edx, dword ptr [rbp-0x55C]
       mov      esi, dword ptr [rbp-0x324]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:MaterializeRange(int,int):this]
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x330], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x334], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x560], eax
       mov      ecx, dword ptr [rbp-0x560]
       mov      rdi, bword ptr [rbp-0x330]
       mov      edx, dword ptr [rbp-0x334]
       mov      rsi, 0x7E4ED9DEB4D0
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x348], rax
       mov      qword ptr [rbp-0x340], rdx
 
G_M000_IG111:                ;; offset=0x1C95
       vmovdqu  xmm0, xmmword ptr [rbp-0x348]
       vmovdqu32 xmmword ptr [rbp-0x170], xmm0
 
G_M000_IG112:                ;; offset=0x1CA4
       lea      rdi, [rbp-0x170]
       mov      rsi, 0x7E4ED9DEB4D0
       call     [System.Span`1[System.__Canon]:ToArray():System.__Canon[]:this]
       mov      gword ptr [rbp-0x160], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x564], eax
       mov      esi, dword ptr [rbp-0x564]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, gword ptr [rbp-0x158]
       mov      rsi, qword ptr [rbp-0x150]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Commit(long):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x350], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x570], rax
       mov      rdx, gword ptr [rbp-0x570]
       mov      rsi, gword ptr [rbp-0x350]
       mov      rdi, gword ptr [rbp-0x160]
       call     [Lokad.Lython.Runtime.PyList:FromTransferredArray(System.Object[],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x578], rax
       mov      rdx, gword ptr [rbp-0x578]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       nop      
 
G_M000_IG113:                ;; offset=0x1D58
       call     G_M000_IG128
       jmp      G_M000_IG121
 
G_M000_IG114:                ;; offset=0x1D62
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG117
       mov      rdi, 0x7E4EDA73F8B4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG115:                ;; offset=0x1D83
       xor      eax, eax
 
G_M000_IG116:                ;; offset=0x1D85
       add      rsp, 0x5B0
       pop      rbp
       ret      
 
G_M000_IG117:                ;; offset=0x1D8E
       mov      rdi, 0x7E4EDA73F8B8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG121
 
G_M000_IG118:                ;; offset=0x1DA2
       mov      rdi, 0x7E4EDA73F8BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x354], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x358], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x584], eax
       mov      esi, dword ptr [rbp-0x584]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x590], rax
       mov      rcx, gword ptr [rbp-0x590]
       mov      esi, dword ptr [rbp-0x354]
       mov      edx, dword ptr [rbp-0x358]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG121
 
G_M000_IG119:                ;; offset=0x1E1E
       mov      rdi, 0x7E4EDA73F8C0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x594], eax
       mov      esi, dword ptr [rbp-0x594]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x598], eax
       mov      esi, dword ptr [rbp-0x598]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG121
 
G_M000_IG120:                ;; offset=0x1E74
       lea      rdi, [rbp-0x198]
       mov      esi, 26
       mov      edx, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
       lea      rdi, [rbp-0x198]
       mov      rsi, 0x7E4ED465BB70
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendLiteral(System.String):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x59C], eax
       mov      esi, dword ptr [rbp-0x59C]
       lea      rdi, [rbp-0x198]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rdi, 0x7E4ED9587A68
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x378], rax
       lea      rdi, [rbp-0x198]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      gword ptr [rbp-0x5A8], rax
       mov      rsi, gword ptr [rbp-0x5A8]
       mov      rdi, gword ptr [rbp-0x378]
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0x378]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG121:                ;; offset=0x1F10
       mov      rdi, 0x7E4EDA73F8C4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       inc      dword ptr [rax+0x40]
 
G_M000_IG122:                ;; offset=0x1F26
       mov      eax, dword ptr [rbp-0x3D4]
       dec      eax
       mov      dword ptr [rbp-0x3D4], eax
       cmp      dword ptr [rbp-0x3D4], 0
       jg       SHORT G_M000_IG124
 
G_M000_IG123:                ;; offset=0x1F3D
       lea      rdi, [rbp-0x3D4]
       mov      esi, 0x9AF
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG124:                ;; offset=0x1F50
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x40]
       mov      dword ptr [rbp-0x19C], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x19C]
       jg       G_M000_IG03
       mov      rdi, 0x7E4EDA73F8C8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG125:                ;; offset=0x1F8B
       mov      eax, 1
 
G_M000_IG126:                ;; offset=0x1F90
       add      rsp, 0x5B0
       pop      rbp
       ret      
 
G_M000_IG127:                ;; offset=0x1F99
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG128:                ;; offset=0x1F9F
       push     rax
 
G_M000_IG129:                ;; offset=0x1FA0
       cmp      gword ptr [rbp-0x158], 0
       je       SHORT G_M000_IG130
       mov      rdi, 0x7E4EDA73F7A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rbp-0x3D0], rax
       mov      rdi, gword ptr [rbp-0x3D0]
       mov      rsi, 0x7E4EDA73F7A8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3D0]
       mov      gword ptr [rbp-0x580], rax
       mov      rdi, gword ptr [rbp-0x580]
       mov      r11, 0x7E4ED7C52BE0
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG130:                ;; offset=0x1FFF
       mov      rdi, 0x7E4EDA73F8B0
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG131:                ;; offset=0x200F
       add      rsp, 8
       ret      
 
RWD00  	dd	0000023Fh ; case G_M000_IG11
       	dd	000002DCh ; case G_M000_IG12
       	dd	0000041Bh ; case G_M000_IG14
       	dd	00000344h ; case G_M000_IG13
RWD16  	dd	00000607h ; case G_M000_IG24
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00000580h ; case G_M000_IG23
       	dd	000004EFh ; case G_M000_IG19
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001D48h ; case G_M000_IG118
       	dd	00001DC4h ; case G_M000_IG119
       	dd	00001AF5h ; case G_M000_IG109
       	dd	000018FCh ; case G_M000_IG105
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	000013C2h ; case G_M000_IG77
       	dd	00001605h ; case G_M000_IG89
       	dd	000007D5h ; case G_M000_IG29
       	dd	0000080Fh ; case G_M000_IG31
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00000C41h ; case G_M000_IG46
       	dd	00000C41h ; case G_M000_IG46
       	dd	00000AB6h ; case G_M000_IG40
       	dd	00001347h ; case G_M000_IG74
       	dd	00001273h ; case G_M000_IG71
       	dd	000010E1h ; case G_M000_IG67
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	0000014Fh ; case G_M000_IG09
       	dd	00000115h ; case G_M000_IG08
       	dd	00000115h ; case G_M000_IG08
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	00001E1Ah ; case G_M000_IG120
       	dd	0000136Ch ; case G_M000_IG75
       	dd	00001D08h ; case G_M000_IG114
       	dd	00001D08h ; case G_M000_IG114
       	dd	00001D08h ; case G_M000_IG114
       	dd	00001D08h ; case G_M000_IG114
       	dd	00001D08h ; case G_M000_IG114

; Total bytes of code 8212

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 169696
; 96 inlinees with PGO data; 221 single block inlinees; 15 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 744
       lea      rbp, [rsp+0x310]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa32 xmmword ptr [rbp-0x310], xmm8
       mov      rax, -720
 
G_M000_IG349:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG349
       mov      qword ptr [rbp-0x30], rax
       mov      rbx, rdi
       mov      r15, rsi
 
G_M000_IG02:                ;; offset=0x0051
       mov      rdi, 0x7E46F9801A60
       mov      rsi, gword ptr [rdi]
       mov      rdi, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      edi, dword ptr [rbx+0x40]
       mov      rax, gword ptr [rbx+0x08]
       mov      rax, gword ptr [rax+0x50]
       cmp      edi, dword ptr [rax+0x08]
       jge      G_M000_IG160
       jmp      SHORT G_M000_IG07
 
G_M000_IG03:                ;; offset=0x007C
       not      r14d
       jmp      G_M000_IG37
 
G_M000_IG04:                ;; offset=0x0084
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       je       G_M000_IG169
 
G_M000_IG05:                ;; offset=0x0098
       inc      dword ptr [rbx+0x40]
 
G_M000_IG06:                ;; offset=0x009B
       mov      esi, dword ptr [rbx+0x40]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       cmp      esi, dword ptr [rdi+0x08]
       jge      G_M000_IG160
 
G_M000_IG07:                ;; offset=0x00AF
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rbx+0x40]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       shl      rax, 5
       lea      r14, bword ptr [rdi+rax+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rax, gword ptr [r14]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG320
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG183
 
G_M000_IG08:                ;; offset=0x00FE
       mov      edi, dword ptr [r14+0x1C]
       lea      r13d, [rdi-0x03]
       cmp      r13d, 3
       jbe      G_M000_IG45
 
G_M000_IG09:                ;; offset=0x0110
       add      edi, -25
       cmp      edi, 43
       ja       G_M000_IG321
 
G_M000_IG10:                ;; offset=0x011C
       mov      edi, edi
       lea      rsi, [reloc @RWD00]
       mov      esi, dword ptr [rsi+4*rdi]
       lea      rax, G_M000_IG02
       add      rsi, rax
       jmp      rsi
 
G_M000_IG11:                ;; offset=0x0134
       cmp      dword ptr [r14+0x1C], 48
       je       G_M000_IG273
 
G_M000_IG12:                ;; offset=0x013F
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerOperation(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG05
       jmp      G_M000_IG274
 
G_M000_IG13:                ;; offset=0x0158
       lea      rdi, bword ptr [rbx+0x60]
       cmp      r13d, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      esi, r13d
       mov      rsi, qword ptr [rdi+8*rsi]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
       lea      rdi, [rbp-0x128]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rdi, 0x7E4EDA299378
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       lea      rdi, bword ptr [r12+0x08]
       mov      rsi, gword ptr [rbp-0x128]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edi, dword ptr [rbp-0x120]
       mov      dword ptr [r12+0x10], edi
       lea      rdi, bword ptr [rbx+0x50]
       cmp      r13d, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      esi, r13d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG164
 
G_M000_IG14:                ;; offset=0x01DC
       mov      rsi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rsi+0x10]
       mov      rsi, 0x7E4ED8E727A0
       cmp      qword ptr [rdi], rsi
       jne      G_M000_IG226
       mov      esi, r13d
       not      esi
       cmp      dword ptr [rdi+0x08], esi
       jbe      G_M000_IG323
       mov      rdi, gword ptr [rdi+8*rsi+0x10]
 
G_M000_IG15:                ;; offset=0x020A
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r12, rax
       jmp      G_M000_IG165
 
G_M000_IG16:                ;; offset=0x0218
       lea      rdi, bword ptr [rbx+0x60]
       cmp      r13d, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      esi, r13d
       mov      rsi, qword ptr [rdi+8*rsi]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x138], xmm0
       lea      rdi, [rbp-0x138]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rdi, 0x7E4EDA299378
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x288], rax
       lea      rdi, bword ptr [rax+0x08]
       mov      rsi, gword ptr [rbp-0x138]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edi, dword ptr [rbp-0x130]
       mov      rax, gword ptr [rbp-0x288]
       mov      dword ptr [rax+0x10], edi
       lea      rdi, bword ptr [rbx+0x50]
       cmp      r13d, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      esi, r13d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      gword ptr [rbp-0x280], rax
       mov      rsi, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x280]
       jmp      G_M000_IG167
 
G_M000_IG17:                ;; offset=0x02B2
       mov      rsi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rsi+0x10]
       mov      rsi, 0x7E4ED8E727A0
       cmp      qword ptr [rdi], rsi
       jne      G_M000_IG228
       mov      esi, r13d
       not      esi
       cmp      dword ptr [rdi+0x08], esi
       jbe      G_M000_IG323
       mov      rdi, gword ptr [rdi+8*rsi+0x10]
 
G_M000_IG18:                ;; offset=0x02E0
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r13, rax
       jmp      G_M000_IG168
 
G_M000_IG19:                ;; offset=0x02EE
       mov      rdi, 0x7E4EDA61CEE8
       cmp      qword ptr [r12], rdi
       jne      G_M000_IG169
 
G_M000_IG20:                ;; offset=0x0302
       cmp      gword ptr [r12+0x28], 0
       je       G_M000_IG230
       cmp      dword ptr [r12+0x50], 0
       jne      G_M000_IG169
 
G_M000_IG21:                ;; offset=0x031A
       test     r13, r13
       je       G_M000_IG169
 
G_M000_IG22:                ;; offset=0x0323
       mov      rdi, 0x7E4EDA29CCC8
       cmp      qword ptr [r13], rdi
       jne      G_M000_IG169
 
G_M000_IG23:                ;; offset=0x0337
       cmp      dword ptr [r14+0x1C], 44
       jne      G_M000_IG231
       mov      edi, dword ptr [r14+0x08]
 
G_M000_IG24:                ;; offset=0x0346
       test     edi, edi
       jl       G_M000_IG246
       cmp      gword ptr [r12+0x20], 0
       je       G_M000_IG246
       mov      rax, gword ptr [rbx]
       mov      gword ptr [rbp-0x1B0], rax
       mov      rcx, gword ptr [r14]
       mov      gword ptr [rbp-0x290], rcx
       mov      rdx, gword ptr [rax+0x78]
       test     rdx, rdx
       je       G_M000_IG233
 
G_M000_IG25:                ;; offset=0x037B
       cmp      dword ptr [r14+0x1C], 44
       jne      G_M000_IG242
       mov      edi, dword ptr [r14+0x08]
 
G_M000_IG26:                ;; offset=0x038A
       cmp      edi, dword ptr [rdx+0x08]
       jae      G_M000_IG341
       mov      edi, edi
       lea      rdi, [rdi+2*rdi]
       lea      rax, bword ptr [rdx+8*rdi+0x10]
       mov      bword ptr [rbp-0x1B8], rax
       mov      rcx, gword ptr [rbx+0x18]
       mov      gword ptr [rbp-0x1C0], rcx
       mov      rdx, gword ptr [r14]
       mov      gword ptr [rbp-0x2C0], rdx
       mov      rdi, gword ptr [rcx+0xA0]
       mov      rsi, gword ptr [rdi+0x88]
       mov      rsi, gword ptr [rsi+0x20]
       test     rsi, rsi
       jne      G_M000_IG244
       mov      rcx, gword ptr [rbp-0x1C0]
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG245
 
G_M000_IG27:                ;; offset=0x03EC
       mov      r8, gword ptr [r12+0x20]
       mov      gword ptr [rbp-0x2C8], r8
       test     r8, r8
       je       G_M000_IG246
       mov      rax, bword ptr [rbp-0x1B8]
       cmp      gword ptr [rax], r8
       jne      G_M000_IG248
 
G_M000_IG28:                ;; offset=0x0411
       cmp      gword ptr [rax+0x08], r13
       jne      G_M000_IG247
       mov      r9d, dword ptr [rax+0x10]
 
G_M000_IG29:                ;; offset=0x041F
       cmp      gword ptr [r12+0x20], 0
       je       SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x0427
       mov      rdi, gword ptr [r12+0x30]
       cmp      dword ptr [rdi+0x08], r9d
       jbe      G_M000_IG249
       cmp      r9d, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      eax, r9d
       cmp      gword ptr [rdi+8*rax+0x10], 0
       je       G_M000_IG249
 
G_M000_IG31:                ;; offset=0x044F
       mov      rdi, gword ptr [r12+0x30]
       mov      rax, rdi
       cmp      r9d, dword ptr [rax+0x08]
       jae      G_M000_IG341
       mov      edi, r9d
       mov      rax, gword ptr [rax+8*rdi+0x10]
 
G_M000_IG32:                ;; offset=0x0469
       mov      gword ptr [rbp-0x1A0], rax
       test     rax, rax
       je       G_M000_IG246
       mov      rax, gword ptr [rbp-0x1A0]
       mov      r12d, dword ptr [r14+0x18]
       test     r12d, r12d
       jl       G_M000_IG252
 
G_M000_IG33:                ;; offset=0x048D
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x0496
       mov      rcx, 0xFFFFFFFFFE7FF
       bt       rcx, rdi
       jae      G_M000_IG250
 
G_M000_IG35:                ;; offset=0x04AA
       mov      r12d, dword ptr [r14+0x14]
 
G_M000_IG36:                ;; offset=0x04AE
       mov      r14d, dword ptr [r14+0x18]
       test     r14d, r14d
       jl       G_M000_IG03
 
G_M000_IG37:                ;; offset=0x04BB
       cmp      r14d, dword ptr [rbx+0x44]
       jl       G_M000_IG251
 
G_M000_IG38:                ;; offset=0x04C5
       lea      rdi, bword ptr [rbx+0x50]
       cmp      r12d, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      esi, r12d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbx+0x44], r14d
       jmp      G_M000_IG05
 
G_M000_IG39:                ;; offset=0x04EE
       mov      r13d, dword ptr [r14+0x10]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r12d, eax
       cmp      byte  ptr [rbx+0x48], 0
       je       SHORT G_M000_IG43
 
G_M000_IG40:                ;; offset=0x0504
       mov      edi, r13d
       mov      eax, edi
       lea      edi, [rax+r12]
       cmp      edi, r13d
       jle      SHORT G_M000_IG43
 
G_M000_IG41:                ;; offset=0x0512
       lea      rdi, bword ptr [rbx+0x50]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      rdi, gword ptr [rdi+8*rax]
       mov      rsi, 0x7E46F9803130
       cmp      rdi, gword ptr [rsi]
       je       SHORT G_M000_IG44
 
G_M000_IG42:                ;; offset=0x0535
       inc      eax
       mov      rdi, rax
       lea      esi, [r12+r13]
       cmp      esi, edi
       mov      rax, rdi
       jg       SHORT G_M000_IG41
 
G_M000_IG43:                ;; offset=0x0545
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG160
       jmp      G_M000_IG301
 
G_M000_IG44:                ;; offset=0x055E
       lea      rdi, bword ptr [rbx+0x60]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      qword ptr [rbp-0x198], rax
       mov      rsi, qword ptr [rdi+8*rax]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x168], xmm0
       lea      rdi, [rbp-0x168]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rdi, 0x7E4EDA299378
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      gword ptr [rbp-0x2D8], rsi
       lea      rdi, bword ptr [rsi+0x08]
       mov      rsi, gword ptr [rbp-0x168]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edi, dword ptr [rbp-0x160]
       mov      rsi, gword ptr [rbp-0x2D8]
       mov      dword ptr [rsi+0x10], edi
       lea      rdi, bword ptr [rbx+0x50]
       mov      rax, qword ptr [rbp-0x198]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      qword ptr [rbp-0x198], rax
       lea      rdi, bword ptr [rdi+8*rax]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, qword ptr [rbp-0x198]
       jmp      G_M000_IG42
 
G_M000_IG45:                ;; offset=0x05FE
       mov      edi, r13d
       lea      rax, [reloc @RWD176]
       mov      eax, dword ptr [rax+4*rdi]
       lea      rcx, G_M000_IG02
       add      rax, rcx
       jmp      rax
 
G_M000_IG46:                ;; offset=0x0617
       mov      rdi, gword ptr [rbx+0x08]
       mov      r13, gword ptr [rdi+0x18]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rdi, 0x7E4ED8F4BEC0
       cmp      qword ptr [r13], rdi
       jne      G_M000_IG193
       cmp      dword ptr [r13+0x08], eax
       jbe      G_M000_IG323
       mov      edi, eax
       mov      r12, gword ptr [r13+8*rdi+0x10]
 
G_M000_IG47:                ;; offset=0x064D
       mov      r13, gword ptr [r14]
       mov      gword ptr [rbp-0x1F8], r13
       mov      rax, gword ptr [rbx+0x18]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rcx, rax
       mov      r13, gword ptr [rbp-0x1F8]
 
G_M000_IG48:                ;; offset=0x066C
       mov      rsi, gword ptr [rcx+0x10]
       mov      rdi, rsi
       test     rdi, rdi
       je       SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x0678
       mov      rdx, 0x7E4EDA295310
       cmp      qword ptr [rdi], rdx
       jne      G_M000_IG195
 
G_M000_IG50:                ;; offset=0x068B
       test     rdi, rdi
       jne      G_M000_IG194
       mov      gword ptr [rbp-0x200], rcx
       movzx    rdi, byte  ptr [rcx+0x102]
       test     edi, edi
       je       G_M000_IG76
       mov      rsi, rcx
       test     rsi, rsi
       je       G_M000_IG76
 
G_M000_IG51:                ;; offset=0x06B7
       test     edi, edi
       je       G_M000_IG196
       mov      rdx, rcx
 
G_M000_IG52:                ;; offset=0x06C2
       cmp      byte  ptr [rdx], dl
       xor      edi, edi
       mov      dword ptr [rbp-0xD8], edi
 
G_M000_IG53:                ;; offset=0x06CC
       mov      dword ptr [rbp-0xE0], edi
       mov      gword ptr [rbp-0x208], rdx
       mov      rdi, gword ptr [rdx+0x108]
       mov      r8, gword ptr [rdi+0x28]
       mov      rdi, 0x7E4EDA18EDC8
       cmp      qword ptr [r8], rdi
       jne      G_M000_IG200
       mov      gword ptr [rbp-0x210], r8
       test     r12, r12
       je       G_M000_IG333
       cmp      gword ptr [r8+0x08], 0
       je       G_M000_IG74
 
G_M000_IG54:                ;; offset=0x0712
       mov      r9, gword ptr [r8+0x18]
       mov      gword ptr [rbp-0x220], r9
       mov      rdi, 0x7E4ED8F484D8
       cmp      qword ptr [r9], rdi
       jne      G_M000_IG198
       lea      rdi, bword ptr [r12+0x0C]
       mov      bword ptr [rbp-0xF0], rdi
       mov      edi, 0x15051505
       mov      esi, 0x15051505
       mov      r11, bword ptr [rbp-0xF0]
       mov      r10d, dword ptr [r12+0x08]
       cmp      r10d, 2
       jle      SHORT G_M000_IG56
 
G_M000_IG55:                ;; offset=0x0758
       add      r10d, -4
       mov      r13d, edi
       rol      r13d, 5
       add      edi, r13d
       xor      edi, dword ptr [r11]
       mov      r13d, esi
       rol      r13d, 5
       add      esi, r13d
       xor      esi, dword ptr [r11+0x04]
       add      r11, 8
       cmp      r10d, 2
       jg       SHORT G_M000_IG55
 
G_M000_IG56:                ;; offset=0x0781
       test     r10d, r10d
       jg       G_M000_IG197
 
G_M000_IG57:                ;; offset=0x078A
       imul     r13d, esi, 0x5D588B65
       add      r13d, edi
       xor      rdi, rdi
       mov      bword ptr [rbp-0xF0], rdi
 
G_M000_IG58:                ;; offset=0x079D
       mov      r8, gword ptr [rbp-0x210]
       mov      rsi, gword ptr [r8+0x08]
       mov      edi, r13d
       imul     rdi, qword ptr [r8+0x30]
       shr      rdi, 32
       inc      rdi
       mov      r10d, dword ptr [rsi+0x08]
       imul     rdi, r10
       shr      rdi, 32
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG341
       mov      edi, edi
       lea      rsi, bword ptr [rsi+4*rdi+0x10]
       mov      esi, dword ptr [rsi]
       mov      r8, gword ptr [r8+0x10]
       mov      gword ptr [rbp-0x228], r8
       xor      r10d, r10d
       mov      dword ptr [rbp-0xE4], r10d
       dec      esi
       mov      r11d, dword ptr [r8+0x08]
       mov      dword ptr [rbp-0x190], r11d
       cmp      r11d, esi
       jbe      G_M000_IG73
 
G_M000_IG59:                ;; offset=0x0800
       mov      esi, esi
       lea      rsi, [rsi+2*rsi]
       lea      rdi, bword ptr [r8+8*rsi+0x10]
       mov      bword ptr [rbp-0x218], rdi
       cmp      dword ptr [rdi+0x08], r13d
       je       SHORT G_M000_IG63
 
G_M000_IG60:                ;; offset=0x0818
       mov      esi, dword ptr [rdi+0x0C]
       mov      r10d, dword ptr [rbp-0xE4]
       inc      r10d
       mov      r11d, dword ptr [rbp-0x190]
       cmp      r11d, r10d
       jb       G_M000_IG334
 
G_M000_IG61:                ;; offset=0x0835
       cmp      r11d, esi
       mov      dword ptr [rbp-0xE4], r10d
       mov      r8, gword ptr [rbp-0x228]
       ja       SHORT G_M000_IG59
 
G_M000_IG62:                ;; offset=0x0848
       mov      r13, gword ptr [rbp-0x1F8]
       jmp      G_M000_IG74
 
G_M000_IG63:                ;; offset=0x0854
       mov      rsi, gword ptr [rdi]
       mov      r9, 0x7E4ED8F484D8
       mov      rcx, gword ptr [rbp-0x220]
       cmp      qword ptr [rcx], r9
       jne      G_M000_IG199
       mov      rcx, gword ptr [rbp-0x220]
       cmp      rsi, r12
       je       G_M000_IG72
 
G_M000_IG64:                ;; offset=0x0881
       test     rsi, rsi
       je       G_M000_IG71
 
G_M000_IG65:                ;; offset=0x088A
       mov      r9d, dword ptr [rsi+0x08]
       cmp      r9d, dword ptr [r12+0x08]
       jne      G_M000_IG71
 
G_M000_IG66:                ;; offset=0x0899
       add      rsi, 12
       mov      bword ptr [rbp-0x230], rsi
       add      r9d, r9d
       mov      edx, r9d
       lea      rsi, bword ptr [r12+0x0C]
       mov      rdi, bword ptr [rbp-0x230]
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       mov      rcx, gword ptr [rbp-0x220]
 
G_M000_IG67:                ;; offset=0x08C3
       test     eax, eax
       mov      r9, rcx
       mov      rdi, bword ptr [rbp-0x218]
       je       G_M000_IG60
       add      rdi, 16
       mov      edi, dword ptr [rdi]
       mov      dword ptr [rbp-0xD8], edi
       mov      r13, gword ptr [rbp-0x1F8]
 
G_M000_IG68:                ;; offset=0x08E8
       mov      rdx, gword ptr [rbp-0x208]
       mov      rdi, gword ptr [rdx+0x110]
       mov      esi, dword ptr [rbp-0xD8]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, gword ptr [rdi+8*rsi+0x10]
       test     rdi, rdi
       jne      G_M000_IG174
 
G_M000_IG69:                ;; offset=0x0913
       mov      r8, rdi
 
G_M000_IG70:                ;; offset=0x0916
       test     r8, r8
       je       SHORT G_M000_IG75
       mov      r13, r8
       mov      rax, r13
       jmp      G_M000_IG97
 
G_M000_IG71:                ;; offset=0x0926
       xor      esi, esi
       mov      eax, esi
       jmp      SHORT G_M000_IG67
 
G_M000_IG72:                ;; offset=0x092C
       mov      esi, 1
       mov      eax, esi
       jmp      SHORT G_M000_IG67
 
G_M000_IG73:                ;; offset=0x0935
       mov      r13, gword ptr [rbp-0x1F8]
 
G_M000_IG74:                ;; offset=0x093C
       xor      edi, edi
       mov      dword ptr [rbp-0xD8], edi
 
G_M000_IG75:                ;; offset=0x0944
       mov      rdx, gword ptr [rbp-0x208]
       cmp      gword ptr [rdx+0x118], 0
       jne      G_M000_IG201
       mov      rcx, gword ptr [rbp-0x200]
 
G_M000_IG76:                ;; offset=0x0960
       mov      rdx, gword ptr [rcx+0x08]
       test     rdx, rdx
       je       G_M000_IG203
 
G_M000_IG77:                ;; offset=0x096D
       mov      rcx, rdx
       mov      gword ptr [rbp-0x238], rcx
       cmp      byte  ptr [rcx], cl
       test     r12, r12
       je       G_M000_IG333
       cmp      gword ptr [rcx+0x08], 0
       je       G_M000_IG86
 
G_M000_IG78:                ;; offset=0x098D
       mov      rdx, gword ptr [rcx+0x18]
       mov      gword ptr [rbp-0x248], rdx
       mov      rdi, 0x7E4ED8F484D8
       cmp      qword ptr [rdx], rdi
       jne      G_M000_IG205
       lea      rdi, bword ptr [r12+0x0C]
       mov      bword ptr [rbp-0x100], rdi
       mov      edi, 0x15051505
       mov      esi, 0x15051505
       mov      r11, bword ptr [rbp-0x100]
       mov      r8d, dword ptr [r12+0x08]
       cmp      r8d, 2
       jle      SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x09D3
       add      r8d, -4
       mov      r9d, edi
       rol      r9d, 5
       add      edi, r9d
       xor      edi, dword ptr [r11]
       mov      r9d, esi
       rol      r9d, 5
       add      esi, r9d
       xor      esi, dword ptr [r11+0x04]
       add      r11, 8
       cmp      r8d, 2
       jg       SHORT G_M000_IG79
 
G_M000_IG80:                ;; offset=0x09FC
       test     r8d, r8d
       jg       G_M000_IG204
 
G_M000_IG81:                ;; offset=0x0A05
       imul     r8d, esi, 0x5D588B65
       add      r8d, edi
       xor      rdi, rdi
       mov      bword ptr [rbp-0x100], rdi
 
G_M000_IG82:                ;; offset=0x0A18
       mov      dword ptr [rbp-0xF4], r8d
       mov      rcx, gword ptr [rbp-0x238]
       mov      rsi, gword ptr [rcx+0x08]
       mov      edi, r8d
       imul     rdi, qword ptr [rcx+0x30]
       shr      rdi, 32
       inc      rdi
       mov      r9d, dword ptr [rsi+0x08]
       mov      r10d, r9d
       imul     rdi, r10
       shr      rdi, 32
       cmp      edi, r9d
       jae      G_M000_IG341
       mov      edi, edi
       lea      rsi, bword ptr [rsi+4*rdi+0x10]
       mov      esi, dword ptr [rsi]
       mov      rcx, gword ptr [rcx+0x10]
       mov      gword ptr [rbp-0x250], rcx
       xor      r9d, r9d
       mov      dword ptr [rbp-0xF8], r9d
       dec      esi
       mov      r10d, dword ptr [rcx+0x08]
       mov      dword ptr [rbp-0x188], r10d
       cmp      r10d, esi
       jbe      SHORT G_M000_IG86
 
G_M000_IG83:                ;; offset=0x0A81
       mov      esi, esi
       lea      rsi, [rsi+2*rsi]
       lea      r11, bword ptr [rcx+8*rsi+0x10]
       mov      bword ptr [rbp-0x240], r11
       cmp      dword ptr [r11+0x10], r8d
       je       G_M000_IG176
 
G_M000_IG84:                ;; offset=0x0A9D
       mov      esi, dword ptr [r11+0x14]
       mov      r9d, dword ptr [rbp-0xF8]
       inc      r9d
       mov      r10d, dword ptr [rbp-0x188]
       cmp      r10d, r9d
       jb       G_M000_IG334
 
G_M000_IG85:                ;; offset=0x0ABB
       cmp      r10d, esi
       mov      dword ptr [rbp-0xF8], r9d
       mov      rcx, gword ptr [rbp-0x250]
       mov      r8d, dword ptr [rbp-0xF4]
       ja       SHORT G_M000_IG83
 
G_M000_IG86:                ;; offset=0x0AD5
       mov      rax, gword ptr [rbp-0x1E8]
       mov      rdi, gword ptr [rax+0xA0]
       mov      rax, gword ptr [rdi+0xF0]
       mov      gword ptr [rbp-0x260], rax
       cmp      byte  ptr [rax], al
       cmp      gword ptr [rax+0x08], 0
       je       G_M000_IG95
 
G_M000_IG87:                ;; offset=0x0AFE
       mov      rcx, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x270], rcx
       mov      rdi, 0x7E4ED8F484D8
       cmp      qword ptr [rcx], rdi
       jne      G_M000_IG208
       lea      rdi, bword ptr [r12+0x0C]
       mov      bword ptr [rbp-0x110], rdi
       mov      edi, 0x15051505
       mov      esi, 0x15051505
       mov      r11, bword ptr [rbp-0x110]
       mov      edx, dword ptr [r12+0x08]
       cmp      edx, 2
       jle      SHORT G_M000_IG89
 
G_M000_IG88:                ;; offset=0x0B43
       add      edx, -4
       mov      r8d, edi
       rol      r8d, 5
       add      edi, r8d
       xor      edi, dword ptr [r11]
       mov      r8d, esi
       rol      r8d, 5
       add      esi, r8d
       xor      esi, dword ptr [r11+0x04]
       add      r11, 8
       cmp      edx, 2
       jg       SHORT G_M000_IG88
 
G_M000_IG89:                ;; offset=0x0B6A
       test     edx, edx
       jg       G_M000_IG207
 
G_M000_IG90:                ;; offset=0x0B72
       imul     edx, esi, 0x5D588B65
       add      edx, edi
       xor      rdi, rdi
       mov      bword ptr [rbp-0x110], rdi
 
G_M000_IG91:                ;; offset=0x0B83
       mov      r8d, edx
       mov      dword ptr [rbp-0x104], r8d
       mov      rax, gword ptr [rbp-0x260]
       mov      rdx, gword ptr [rax+0x08]
       mov      esi, r8d
       imul     rsi, qword ptr [rax+0x30]
       shr      rsi, 32
       inc      rsi
       mov      edi, dword ptr [rdx+0x08]
       mov      r9d, edi
       imul     rsi, r9
       shr      rsi, 32
       cmp      esi, edi
       jae      G_M000_IG341
       mov      esi, esi
       lea      rdx, bword ptr [rdx+4*rsi+0x10]
       mov      edx, dword ptr [rdx]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x278], rax
       xor      r9d, r9d
       mov      dword ptr [rbp-0x108], r9d
       dec      edx
       mov      r10d, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x18C], r10d
       cmp      r10d, edx
       jbe      SHORT G_M000_IG95
 
G_M000_IG92:                ;; offset=0x0BED
       mov      edx, edx
       lea      rdx, [rdx+2*rdx]
       lea      r11, bword ptr [rax+8*rdx+0x10]
       mov      bword ptr [rbp-0x268], r11
       cmp      dword ptr [r11+0x10], r8d
       je       G_M000_IG104
 
G_M000_IG93:                ;; offset=0x0C09
       mov      edx, dword ptr [r11+0x14]
       mov      r9d, dword ptr [rbp-0x108]
       inc      r9d
       mov      r10d, dword ptr [rbp-0x18C]
       cmp      r10d, r9d
       jb       G_M000_IG334
 
G_M000_IG94:                ;; offset=0x0C27
       cmp      r10d, edx
       mov      dword ptr [rbp-0x108], r9d
       mov      rax, gword ptr [rbp-0x278]
       mov      r8d, dword ptr [rbp-0x104]
       ja       SHORT G_M000_IG92
 
G_M000_IG95:                ;; offset=0x0C41
       xor      rax, rax
       xor      edi, edi
 
G_M000_IG96:                ;; offset=0x0C45
       test     edi, edi
       je       G_M000_IG335
 
G_M000_IG97:                ;; offset=0x0C4D
       mov      gword ptr [rbp-0x1F0], rax
       mov      r12, rax
       cmp      dword ptr [r14+0x18], 0
       jl       G_M000_IG112
 
G_M000_IG98:                ;; offset=0x0C62
       mov      rax, gword ptr [rbp-0x1F0]
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG100
 
G_M000_IG99:                ;; offset=0x0C72
       mov      rcx, 0xFFFFFFFFFE7FF
       bt       rcx, rdi
       jae      G_M000_IG210
 
G_M000_IG100:                ;; offset=0x0C86
       mov      r12d, dword ptr [r14+0x14]
 
G_M000_IG101:                ;; offset=0x0C8A
       mov      r14d, dword ptr [r14+0x18]
       test     r14d, r14d
       jl       G_M000_IG111
 
G_M000_IG102:                ;; offset=0x0C97
       cmp      r14d, dword ptr [rbx+0x44]
       jl       G_M000_IG211
 
G_M000_IG103:                ;; offset=0x0CA1
       lea      rdi, bword ptr [rbx+0x50]
       cmp      r12d, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      esi, r12d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbx+0x44], r14d
       jmp      G_M000_IG05
 
G_M000_IG104:                ;; offset=0x0CCA
       mov      rsi, gword ptr [r11]
       mov      rdx, 0x7E4ED8F484D8
       cmp      qword ptr [rcx], rdx
       jne      G_M000_IG209
       mov      rcx, gword ptr [rbp-0x270]
       cmp      rsi, r12
       je       SHORT G_M000_IG110
 
G_M000_IG105:                ;; offset=0x0CEC
       test     rsi, rsi
       je       SHORT G_M000_IG109
 
G_M000_IG106:                ;; offset=0x0CF1
       mov      edx, dword ptr [rsi+0x08]
       cmp      edx, dword ptr [r12+0x08]
       jne      SHORT G_M000_IG109
 
G_M000_IG107:                ;; offset=0x0CFB
       lea      rdi, bword ptr [rsi+0x0C]
       add      edx, edx
       lea      rsi, bword ptr [r12+0x0C]
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       mov      rcx, gword ptr [rbp-0x270]
 
G_M000_IG108:                ;; offset=0x0D13
       test     eax, eax
       mov      r11, bword ptr [rbp-0x268]
       je       G_M000_IG93
       add      r11, 8
       mov      rdi, gword ptr [r11]
       mov      rax, rdi
       mov      edi, 1
       jmp      G_M000_IG96
 
G_M000_IG109:                ;; offset=0x0D36
       xor      edi, edi
       mov      eax, edi
       jmp      SHORT G_M000_IG108
 
G_M000_IG110:                ;; offset=0x0D3C
       mov      edi, 1
       mov      eax, edi
       jmp      SHORT G_M000_IG108
 
G_M000_IG111:                ;; offset=0x0D45
       not      r14d
       jmp      G_M000_IG102
 
G_M000_IG112:                ;; offset=0x0D4D
       mov      esi, dword ptr [r14+0x18]
       mov      r13d, esi
       not      r13d
       mov      esi, r13d
       mov      eax, dword ptr [rbx+0x44]
       cmp      esi, eax
       jge      SHORT G_M000_IG116
 
G_M000_IG113:                ;; offset=0x0D61
       dec      eax
       mov      rsi, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rsi+0xA0]
       cmp      eax, ecx
       jle      G_M000_IG212
 
G_M000_IG114:                ;; offset=0x0D75
       mov      eax, ecx
       cmp      eax, r13d
       jge      G_M000_IG213
 
G_M000_IG115:                ;; offset=0x0D80
       mov      dword ptr [rbx+0x44], r13d
 
G_M000_IG116:                ;; offset=0x0D84
       lea      r13, bword ptr [rbx+0x50]
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG118
 
G_M000_IG117:                ;; offset=0x0D91
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG215
 
G_M000_IG118:                ;; offset=0x0DA5
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG119:                ;; offset=0x0DA9
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [r13]
       mov      eax, eax
       xor      rcx, rcx
       mov      gword ptr [rdi+8*rax], rcx
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG121
 
G_M000_IG120:                ;; offset=0x0DC8
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG216
 
G_M000_IG121:                ;; offset=0x0DDC
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG122:                ;; offset=0x0DE0
       mov      dword ptr [rbx+0x44], eax
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rbx+0x40]
       inc      eax
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       shl      rax, 5
       lea      r13, bword ptr [rdi+rax+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r13]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG336
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG217
 
G_M000_IG123:                ;; offset=0x0E35
       lea      rdi, bword ptr [rbx+0x50]
       mov      esi, dword ptr [r13+0x1C]
       cmp      esi, 4
       je       SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x0E42
       cmp      esi, 27
       jne      G_M000_IG337
 
G_M000_IG125:                ;; offset=0x0E4B
       mov      esi, dword ptr [r13+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG126:                ;; offset=0x0E67
       inc      dword ptr [rbx+0x40]
       jmp      G_M000_IG05
 
G_M000_IG127:                ;; offset=0x0E6F
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 4
       je       SHORT G_M000_IG129
 
G_M000_IG128:                ;; offset=0x0E78
       cmp      edi, 27
       jne      G_M000_IG329
 
G_M000_IG129:                ;; offset=0x0E81
       mov      r12d, dword ptr [r14+0x08]
       mov      r13, gword ptr [r14]
       lea      rdi, bword ptr [rbx+0x50]
       cmp      r12d, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      esi, r12d
       mov      rax, gword ptr [rdi+8*rsi]
       mov      rdi, 0x7E46F9803130
       cmp      rax, gword ptr [rdi]
       je       G_M000_IG137
 
G_M000_IG130:                ;; offset=0x0EB3
       test     rax, rax
       je       G_M000_IG330
       mov      gword ptr [rbp-0x1D8], rax
       mov      r12, rax
       cmp      dword ptr [r14+0x18], 0
       jl       G_M000_IG139
 
G_M000_IG131:                ;; offset=0x0ED1
       mov      rax, gword ptr [rbp-0x1D8]
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG133
 
G_M000_IG132:                ;; offset=0x0EE1
       mov      rcx, 0xFFFFFFFFFE7FF
       bt       rcx, rdi
       jae      G_M000_IG185
 
G_M000_IG133:                ;; offset=0x0EF5
       mov      r12d, dword ptr [r14+0x14]
 
G_M000_IG134:                ;; offset=0x0EF9
       mov      r14d, dword ptr [r14+0x18]
       test     r14d, r14d
       jl       G_M000_IG138
 
G_M000_IG135:                ;; offset=0x0F06
       cmp      r14d, dword ptr [rbx+0x44]
       jl       G_M000_IG186
 
G_M000_IG136:                ;; offset=0x0F10
       lea      rdi, bword ptr [rbx+0x50]
       cmp      r12d, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      esi, r12d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbx+0x44], r14d
       jmp      G_M000_IG05
 
G_M000_IG137:                ;; offset=0x0F39
       lea      rdi, bword ptr [rbx+0x60]
       cmp      r12d, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      esi, r12d
       mov      rsi, qword ptr [rdi+8*rsi]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
       lea      rdi, [rbp-0xC8]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rdi, 0x7E4EDA299378
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1E0], rax
       lea      rdi, bword ptr [rax+0x08]
       mov      rsi, gword ptr [rbp-0xC8]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edi, dword ptr [rbp-0xC0]
       mov      rax, gword ptr [rbp-0x1E0]
       mov      dword ptr [rax+0x10], edi
       lea      rdi, bword ptr [rbx+0x50]
       cmp      r12d, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      esi, r12d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rsi, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x1D8]
       jmp      G_M000_IG130
 
G_M000_IG138:                ;; offset=0x0FD3
       not      r14d
       jmp      G_M000_IG135
 
G_M000_IG139:                ;; offset=0x0FDB
       mov      esi, dword ptr [r14+0x18]
       mov      r13d, esi
       not      r13d
       mov      esi, r13d
       mov      eax, dword ptr [rbx+0x44]
       cmp      esi, eax
       jge      SHORT G_M000_IG143
 
G_M000_IG140:                ;; offset=0x0FEF
       dec      eax
       mov      rsi, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rsi+0xA0]
       cmp      eax, ecx
       jle      G_M000_IG187
 
G_M000_IG141:                ;; offset=0x1003
       mov      eax, ecx
       cmp      eax, r13d
       jge      G_M000_IG188
 
G_M000_IG142:                ;; offset=0x100E
       mov      dword ptr [rbx+0x44], r13d
 
G_M000_IG143:                ;; offset=0x1012
       lea      r13, bword ptr [rbx+0x50]
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG145
 
G_M000_IG144:                ;; offset=0x101F
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG190
 
G_M000_IG145:                ;; offset=0x1033
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG146:                ;; offset=0x1037
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [r13]
       mov      eax, eax
       xor      rcx, rcx
       mov      gword ptr [rdi+8*rax], rcx
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG148
 
G_M000_IG147:                ;; offset=0x1056
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG191
 
G_M000_IG148:                ;; offset=0x106A
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG149:                ;; offset=0x106E
       mov      dword ptr [rbx+0x44], eax
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rbx+0x40]
       inc      eax
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       shl      rax, 5
       lea      r13, bword ptr [rdi+rax+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r13]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG331
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG192
 
G_M000_IG150:                ;; offset=0x10C3
       lea      rdi, bword ptr [rbx+0x50]
       mov      esi, dword ptr [r13+0x1C]
       cmp      esi, 4
       je       SHORT G_M000_IG152
 
G_M000_IG151:                ;; offset=0x10D0
       cmp      esi, 27
       jne      G_M000_IG332
 
G_M000_IG152:                ;; offset=0x10D9
       mov      esi, dword ptr [r13+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG126
 
G_M000_IG153:                ;; offset=0x10FA
       mov      r13d, dword ptr [r14+0x10]
       test     r13d, r13d
       jl       G_M000_IG172
 
G_M000_IG154:                ;; offset=0x1107
       lea      rdi, bword ptr [rbx+0x50]
       cmp      r13d, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      esi, r13d
       mov      r12, gword ptr [rdi+8*rsi]
       mov      rdi, 0x7E46F9803130
       cmp      r12, gword ptr [rdi]
       je       G_M000_IG171
 
G_M000_IG155:                ;; offset=0x1132
       test     r12, r12
       je       G_M000_IG325
 
G_M000_IG156:                ;; offset=0x113B
       mov      rdi, r15
       mov      rsi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x9C]
       jl       SHORT G_M000_IG158
 
G_M000_IG157:                ;; offset=0x1156
       lea      rsi, bword ptr [rbx+0x50]
       mov      edi, dword ptr [r14+0x10]
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG341
       mov      rsi, bword ptr [rsi]
       xor      rax, rax
       mov      gword ptr [rsi+8*rdi], rax
 
G_M000_IG158:                ;; offset=0x1170
       mov      rsi, gword ptr [rbx+0x08]
       mov      r14d, dword ptr [rsi+0x9C]
       mov      r15d, dword ptr [rbx+0x44]
       dec      r15d
       mov      rsi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rsi+0xA0]
       cmp      r15d, esi
       cmovg    r15d, esi
       cmp      r15d, r14d
       jge      G_M000_IG327
 
G_M000_IG159:                ;; offset=0x119C
       mov      dword ptr [rbx+0x44], r14d
 
G_M000_IG160:                ;; offset=0x11A0
       mov      eax, 1
 
G_M000_IG161:                ;; offset=0x11A5
       vzeroupper 
       add      rsp, 744
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG162:                ;; offset=0x11BA
       mov      r13d, dword ptr [r14+0x10]
       test     r13d, r13d
       jl       G_M000_IG14
 
G_M000_IG163:                ;; offset=0x11C7
       lea      rdi, bword ptr [rbx+0x50]
       cmp      r13d, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      esi, r13d
       mov      r12, gword ptr [rdi+8*rsi]
       mov      rdi, 0x7E46F9803130
       cmp      r12, gword ptr [rdi]
       je       G_M000_IG13
 
G_M000_IG164:                ;; offset=0x11F2
       test     r12, r12
       je       G_M000_IG227
 
G_M000_IG165:                ;; offset=0x11FB
       mov      r13d, dword ptr [r14+0x0C]
       test     r13d, r13d
       jl       G_M000_IG17
 
G_M000_IG166:                ;; offset=0x1208
       lea      rdi, bword ptr [rbx+0x50]
       cmp      r13d, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      esi, r13d
       mov      rax, gword ptr [rdi+8*rsi]
       mov      rdi, 0x7E46F9803130
       cmp      rax, gword ptr [rdi]
       je       G_M000_IG16
 
G_M000_IG167:                ;; offset=0x1233
       test     rax, rax
       je       G_M000_IG229
       mov      r13, rax
 
G_M000_IG168:                ;; offset=0x123F
       test     r12, r12
       jne      G_M000_IG19
 
G_M000_IG169:                ;; offset=0x1248
       xor      eax, eax
 
G_M000_IG170:                ;; offset=0x124A
       vzeroupper 
       add      rsp, 744
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG171:                ;; offset=0x125F
       lea      rdi, bword ptr [rbx+0x60]
       cmp      r13d, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      esi, r13d
       mov      rsi, qword ptr [rdi+8*rsi]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xB8], xmm0
       lea      rdi, [rbp-0xB8]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rdi, 0x7E4EDA299378
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       lea      rdi, bword ptr [r12+0x08]
       mov      rsi, gword ptr [rbp-0xB8]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edi, dword ptr [rbp-0xB0]
       mov      dword ptr [r12+0x10], edi
       lea      rdi, bword ptr [rbx+0x50]
       cmp      r13d, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      esi, r13d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG155
 
G_M000_IG172:                ;; offset=0x12E3
       mov      rsi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rsi+0x10]
       mov      rsi, 0x7E4ED8E727A0
       cmp      qword ptr [rdi], rsi
       jne      G_M000_IG324
       mov      esi, r13d
       not      esi
       cmp      dword ptr [rdi+0x08], esi
       jbe      G_M000_IG323
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, gword ptr [rdi+8*rsi+0x10]
 
G_M000_IG173:                ;; offset=0x131A
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r12, rax
       jmp      G_M000_IG156
 
G_M000_IG174:                ;; offset=0x1328
       mov      rsi, 0x7E4EDA5EE8F0
       cmp      qword ptr [rdi], rsi
       jne      G_M000_IG69
 
G_M000_IG175:                ;; offset=0x133B
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      r8, rax
       jmp      G_M000_IG70
 
G_M000_IG176:                ;; offset=0x1349
       mov      rsi, gword ptr [r11]
       mov      rdi, 0x7E4ED8F484D8
       cmp      qword ptr [rdx], rdi
       jne      G_M000_IG206
       mov      rdx, gword ptr [rbp-0x248]
       cmp      rsi, r12
       je       SHORT G_M000_IG182
 
G_M000_IG177:                ;; offset=0x136B
       test     rsi, rsi
       je       SHORT G_M000_IG181
 
G_M000_IG178:                ;; offset=0x1370
       mov      edi, dword ptr [rsi+0x08]
       cmp      edi, dword ptr [r12+0x08]
       jne      SHORT G_M000_IG181
 
G_M000_IG179:                ;; offset=0x137A
       add      rsi, 12
       mov      bword ptr [rbp-0x258], rsi
       add      edi, edi
       mov      edx, edi
       lea      rsi, bword ptr [r12+0x0C]
       mov      rdi, bword ptr [rbp-0x258]
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       mov      rdx, gword ptr [rbp-0x248]
 
G_M000_IG180:                ;; offset=0x13A2
       test     eax, eax
       mov      r11, bword ptr [rbp-0x240]
       je       G_M000_IG84
       add      r11, 8
       mov      r13, gword ptr [r11]
       mov      rax, r13
       jmp      G_M000_IG97
 
G_M000_IG181:                ;; offset=0x13C0
       xor      edi, edi
       mov      eax, edi
       jmp      SHORT G_M000_IG180
 
G_M000_IG182:                ;; offset=0x13C6
       mov      edi, 1
       mov      eax, edi
       jmp      SHORT G_M000_IG180
 
G_M000_IG183:                ;; offset=0x13CF
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG08
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG08
 
G_M000_IG184:                ;; offset=0x13E7
       mov      rdi, gword ptr [rbx+0x08]
       mov      r13, gword ptr [rdi+0x10]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      esi, eax
       mov      rdi, r13
       mov      r11, 0x7E4ED7C52F70
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG05
 
G_M000_IG185:                ;; offset=0x1427
       mov      gword ptr [rbp-0x1D8], rax
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r12d, eax
       mov      rax, gword ptr [rbp-0x1D8]
       jmp      G_M000_IG134
 
G_M000_IG186:                ;; offset=0x1446
       mov      gword ptr [rbp-0x1D8], rax
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, gword ptr [rbp-0x1D8]
       jmp      G_M000_IG136
 
G_M000_IG187:                ;; offset=0x1465
       mov      ecx, eax
       jmp      G_M000_IG141
 
G_M000_IG188:                ;; offset=0x146C
       lea      rsi, bword ptr [rbx+0x50]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG341
       mov      rsi, bword ptr [rsi]
       mov      dword ptr [rbp-0xCC], eax
       mov      edi, eax
       mov      rsi, gword ptr [rsi+8*rdi]
       mov      rdi, 0x7E4EDA6185C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG189
       lea      rdi, bword ptr [rbx+0x50]
       mov      ecx, dword ptr [rbp-0xCC]
       cmp      ecx, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      dword ptr [rbp-0xCC], ecx
       mov      edx, ecx
       xor      rsi, rsi
       mov      gword ptr [rdi+8*rdx], rsi
       mov      rdi, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
 
G_M000_IG189:                ;; offset=0x14CD
       mov      ecx, dword ptr [rbp-0xCC]
       dec      ecx
       cmp      ecx, r13d
       mov      eax, ecx
       jge      SHORT G_M000_IG188
       jmp      G_M000_IG142
 
G_M000_IG190:                ;; offset=0x14E1
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG146
 
G_M000_IG191:                ;; offset=0x14EF
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG149
 
G_M000_IG192:                ;; offset=0x14FD
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG150
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG150
 
G_M000_IG193:                ;; offset=0x1515
       mov      rdi, r13
       mov      esi, eax
       mov      r11, 0x7E4ED7C52F68
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r12, rax
       jmp      G_M000_IG47
 
G_M000_IG194:                ;; offset=0x152F
       mov      rsi, gword ptr [rcx+0x10]
       mov      rdi, 0x7E4EDA295310
       call     CORINFO_HELP_CHKCASTCLASS
       mov      rcx, rax
       jmp      G_M000_IG48
 
G_M000_IG195:                ;; offset=0x154A
       mov      rdi, rdx
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG196:                ;; offset=0x1553
       xor      rdx, rdx
       jmp      G_M000_IG52
 
G_M000_IG197:                ;; offset=0x155A
       mov      r10d, esi
       rol      r10d, 5
       add      r10d, esi
       mov      esi, r10d
       xor      esi, dword ptr [r11]
       jmp      G_M000_IG57
 
G_M000_IG198:                ;; offset=0x156F
       mov      rdi, r9
       mov      rsi, r12
       mov      r11, 0x7E4ED7C52FA8
       call     [r11]System.Collections.Generic.IEqualityComparer`1[System.__Canon]:GetHashCode(System.__Canon):int:this
       mov      r13d, eax
       mov      r9, gword ptr [rbp-0x220]
       jmp      G_M000_IG58
 
G_M000_IG199:                ;; offset=0x1591
       mov      rcx, gword ptr [rbp-0x220]
       mov      rdi, rcx
       mov      rdx, r12
       mov      r11, 0x7E4ED7C52FB0
       call     [r11]System.Collections.Generic.IEqualityComparer`1[System.__Canon]:Equals(System.__Canon,System.__Canon):bool:this
       mov      rcx, gword ptr [rbp-0x220]
       jmp      G_M000_IG67
 
G_M000_IG200:                ;; offset=0x15B7
       lea      rdx, [rbp-0xD8]
       mov      rdi, r8
       mov      rsi, r12
       mov      r11, 0x7E4ED7C52F90
       call     [r11]System.Collections.Generic.IReadOnlyDictionary`2[System.__Canon,int]:TryGetValue(System.__Canon,byref):bool:this
       test     eax, eax
       je       G_M000_IG75
       jmp      G_M000_IG68
 
G_M000_IG201:                ;; offset=0x15DE
       mov      gword ptr [rbp-0x208], rdx
       mov      rdi, gword ptr [rdx+0x108]
       mov      rdi, gword ptr [rdi+0x40]
       lea      rdx, [rbp-0xE0]
       mov      rsi, r12
       mov      r11, 0x7E4ED7C52F98
       call     [r11]System.Collections.Generic.IReadOnlyDictionary`2[System.__Canon,int]:TryGetValue(System.__Canon,byref):bool:this
       test     eax, eax
       je       SHORT G_M000_IG202
       mov      rdi, gword ptr [rbp-0x208]
       mov      rdi, gword ptr [rdi+0x118]
       mov      esi, dword ptr [rbp-0xE0]
       mov      r11, 0x7E4ED7C52FA0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       test     rax, rax
       mov      rcx, gword ptr [rbp-0x200]
       je       G_M000_IG76
       mov      r13, rax
       mov      rax, r13
       jmp      G_M000_IG97
 
G_M000_IG202:                ;; offset=0x1652
       mov      rcx, gword ptr [rbp-0x200]
       jmp      G_M000_IG76
 
G_M000_IG203:                ;; offset=0x165E
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.ExecutionFrame:InitializeVariables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rdx, rax
       jmp      G_M000_IG77
 
G_M000_IG204:                ;; offset=0x166F
       mov      r8d, esi
       rol      r8d, 5
       add      r8d, esi
       mov      esi, r8d
       xor      esi, dword ptr [r11]
       jmp      G_M000_IG81
 
G_M000_IG205:                ;; offset=0x1684
       mov      rdi, rdx
       mov      rsi, r12
       mov      r11, 0x7E4ED7C52FB8
       call     [r11]System.Collections.Generic.IEqualityComparer`1[System.__Canon]:GetHashCode(System.__Canon):int:this
       mov      r8d, eax
       mov      rdx, gword ptr [rbp-0x248]
       jmp      G_M000_IG82
 
G_M000_IG206:                ;; offset=0x16A6
       mov      rdx, gword ptr [rbp-0x248]
       mov      rdi, rdx
       mov      rdx, r12
       mov      r11, 0x7E4ED7C52FC0
       call     [r11]System.Collections.Generic.IEqualityComparer`1[System.__Canon]:Equals(System.__Canon,System.__Canon):bool:this
       mov      rdx, gword ptr [rbp-0x248]
       jmp      G_M000_IG180
 
G_M000_IG207:                ;; offset=0x16CC
       mov      edx, esi
       rol      edx, 5
       add      edx, esi
       mov      esi, edx
       xor      esi, dword ptr [r11]
       jmp      G_M000_IG90
 
G_M000_IG208:                ;; offset=0x16DD
       mov      rdi, rcx
       mov      rsi, r12
       mov      r11, 0x7E4ED7C52FC8
       call     [r11]System.Collections.Generic.IEqualityComparer`1[System.__Canon]:GetHashCode(System.__Canon):int:this
       mov      edx, eax
       mov      rcx, gword ptr [rbp-0x270]
       jmp      G_M000_IG91
 
G_M000_IG209:                ;; offset=0x16FE
       mov      rcx, gword ptr [rbp-0x270]
       mov      rdi, rcx
       mov      rdx, r12
       mov      r11, 0x7E4ED7C52FD0
       call     [r11]System.Collections.Generic.IEqualityComparer`1[System.__Canon]:Equals(System.__Canon,System.__Canon):bool:this
       mov      rcx, gword ptr [rbp-0x270]
       jmp      G_M000_IG108
 
G_M000_IG210:                ;; offset=0x1724
       mov      gword ptr [rbp-0x1F0], rax
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r12d, eax
       mov      rax, gword ptr [rbp-0x1F0]
       jmp      G_M000_IG101
 
G_M000_IG211:                ;; offset=0x1743
       mov      gword ptr [rbp-0x1F0], rax
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, gword ptr [rbp-0x1F0]
       jmp      G_M000_IG103
 
G_M000_IG212:                ;; offset=0x1762
       mov      ecx, eax
       jmp      G_M000_IG114
 
G_M000_IG213:                ;; offset=0x1769
       lea      rsi, bword ptr [rbx+0x50]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG341
       mov      rsi, bword ptr [rsi]
       mov      dword ptr [rbp-0x114], eax
       mov      edi, eax
       mov      rsi, gword ptr [rsi+8*rdi]
       mov      rdi, 0x7E4EDA6185C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG214
       lea      rdi, bword ptr [rbx+0x50]
       mov      ecx, dword ptr [rbp-0x114]
       cmp      ecx, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      dword ptr [rbp-0x114], ecx
       mov      edx, ecx
       xor      rsi, rsi
       mov      gword ptr [rdi+8*rdx], rsi
       mov      rdi, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
 
G_M000_IG214:                ;; offset=0x17CA
       mov      ecx, dword ptr [rbp-0x114]
       dec      ecx
       cmp      ecx, r13d
       mov      eax, ecx
       jge      SHORT G_M000_IG213
       jmp      G_M000_IG115
 
G_M000_IG215:                ;; offset=0x17DE
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG119
 
G_M000_IG216:                ;; offset=0x17EC
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG122
 
G_M000_IG217:                ;; offset=0x17FA
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG123
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG123
 
G_M000_IG218:                ;; offset=0x1812
       mov      rdi, gword ptr [rbx+0x08]
       mov      rsi, gword ptr [rbx+0x10]
       mov      edx, dword ptr [rbx+0x40]
       mov      ecx, dword ptr [rbx+0x44]
       mov      r8, gword ptr [rbx+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG219
       add      dword ptr [rbx+0x40], 2
       jmp      G_M000_IG05
 
G_M000_IG219:                ;; offset=0x1837
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      esi, eax
       lea      rdx, [rbp-0x30]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG169
       mov      rdi, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       test     rax, rax
       je       G_M000_IG169
       mov      rdi, rbx
       mov      rsi, r14
       mov      rdx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG05
 
G_M000_IG220:                ;; offset=0x1880
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      esi, eax
       lea      rdx, [rbp-0x38]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG169
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_CanStoreThroughOwner():bool:this]
       test     eax, eax
       je       G_M000_IG169
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rsi, rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG05
 
G_M000_IG221:                ;; offset=0x18D4
       lea      r13, bword ptr [rbx+0x50]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [r13]
       mov      esi, eax
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      bword ptr [rbp-0x310], rdi
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x310]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG05
 
G_M000_IG222:                ;; offset=0x191C
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      rdi, gword ptr [rbx+0x08]
       mov      r12, gword ptr [rdi+0x18]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      esi, eax
       mov      rdi, r12
       mov      r11, 0x7E4ED7C52F60
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r12, rax
       mov      rsi, r13
       mov      rdi, 0x7E4EDA29CCC8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG224
       mov      rsi, r13
       mov      rdi, 0x7E4EDA61CEE8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG223
       xor      r12, r12
       jmp      SHORT G_M000_IG225
 
G_M000_IG223:                ;; offset=0x1987
       mov      rdi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+DictMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      r12, rax
       jmp      SHORT G_M000_IG225
 
G_M000_IG224:                ;; offset=0x1995
       mov      rdi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+StringMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      r12, rax
 
G_M000_IG225:                ;; offset=0x19A1
       test     r12, r12
       je       G_M000_IG169
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x184], eax
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      edx, [rax+0x01]
       mov      esi, dword ptr [rbp-0x184]
       mov      rdi, rbx
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      r13d, [rax+0x01]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      esi, r13d
       mov      rdi, rbx
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG05
 
G_M000_IG226:                ;; offset=0x1A03
       mov      esi, r13d
       not      esi
       mov      r11, 0x7E4ED7C52FE0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG15
 
G_M000_IG227:                ;; offset=0x1A1D
       mov      rdi, gword ptr [rbx+0x08]
       cmp      r13d, dword ptr [rdi+0x9C]
       jl       G_M000_IG338
       mov      rdi, 0x7E4ED9587A68
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7E4ED460EE38
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG228:                ;; offset=0x1A5C
       mov      esi, r13d
       not      esi
       mov      r11, 0x7E4ED7C52FF0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG18
 
G_M000_IG229:                ;; offset=0x1A76
       mov      rdi, gword ptr [rbx+0x08]
       cmp      r13d, dword ptr [rdi+0x9C]
       jl       G_M000_IG339
       mov      rdi, 0x7E4ED9587A68
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7E4ED460EE38
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG230:                ;; offset=0x1AB5
       mov      rdi, gword ptr [r12+0x08]
       mov      r11, 0x7E4ED7C52FF8
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       jne      G_M000_IG169
       jmp      G_M000_IG21
 
G_M000_IG231:                ;; offset=0x1AD4
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 24
       je       SHORT G_M000_IG232
       cmp      edi, 25
       jne      G_M000_IG340
 
G_M000_IG232:                ;; offset=0x1AE6
       mov      edi, dword ptr [r14+0x0C]
       jmp      G_M000_IG24
 
G_M000_IG233:                ;; offset=0x1AEF
       mov      rdi, gword ptr [rax+0x68]
       movsxd   rdi, dword ptr [rdi+0x94]
       imul     rdx, rdi, 64
       jo       G_M000_IG342
       add      rdx, 32
       jo       G_M000_IG342
       mov      qword ptr [rbp-0x140], rdx
       mov      rdi, gword ptr [rax+0x10]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rsi, gword ptr [rdi+0x88]
       mov      gword ptr [rbp-0x2B0], rsi
       cmp      byte  ptr [rsi], sil
       mov      rdi, 0x7E4ED9F48AF8
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x2B8], rax
       mov      rdi, rax
       mov      rsi, gword ptr [rbp-0x2B0]
       mov      rdx, qword ptr [rbp-0x140]
       mov      rcx, gword ptr [rbp-0x290]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:.ctor(Lokad.Lython.Runtime.MemoryGovernor,long,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x2B8]
       mov      gword ptr [rbp-0x298], rax
 
G_M000_IG234:                ;; offset=0x1B73
       mov      rcx, gword ptr [rbp-0x1B0]
       mov      rdi, gword ptr [rcx+0x10]
       mov      rdi, gword ptr [rdi+0xA0]
       cmp      byte  ptr [rdi], dil
       xor      edx, edx
       mov      gword ptr [rbp-0x148], rdx
       mov      rdx, gword ptr [rdi+0x88]
       mov      rdx, gword ptr [rdx+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG236
 
G_M000_IG235:                ;; offset=0x1BA1
       mov      rdi, rdx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG236:                ;; offset=0x1BAA
       mov      rdi, gword ptr [rdi+0x178]
       mov      gword ptr [rbp-0x148], rdi
       lea      rdi, [rbp-0x148]
       call     [System.Threading.CancellationToken:get_IsCancellationRequested():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG238
 
G_M000_IG237:                ;; offset=0x1BC9
       mov      rdi, gword ptr [rbp-0x290]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
 
G_M000_IG238:                ;; offset=0x1BD6
       mov      rax, gword ptr [rbp-0x1B0]
       mov      rcx, gword ptr [rax+0x78]
       test     rcx, rcx
       je       SHORT G_M000_IG240
 
G_M000_IG239:                ;; offset=0x1BE6
       mov      gword ptr [rbp-0x2A8], rcx
       jmp      SHORT G_M000_IG241
 
G_M000_IG240:                ;; offset=0x1BEF
       mov      rsi, gword ptr [rax+0x68]
       movsxd   rsi, dword ptr [rsi+0x94]
       mov      rdi, 0x7E4EDA6EF570
       call     CORINFO_HELP_NEWARR_1_VC
       mov      gword ptr [rbp-0x2A0], rax
       mov      rdi, gword ptr [rbp-0x2B8]
       mov      rsi, qword ptr [rbp-0x140]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Commit(long):this]
       mov      rdi, gword ptr [rbp-0x1B0]
       lea      rdi, bword ptr [rdi+0x78]
       mov      rsi, gword ptr [rbp-0x2A0]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x2A0]
       mov      rdx, rax
       mov      gword ptr [rbp-0x2A8], rdx
 
G_M000_IG241:                ;; offset=0x1C4C
       mov      rdi, gword ptr [rbp-0x2B8]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Dispose():this]
       mov      rdx, gword ptr [rbp-0x2A8]
       jmp      G_M000_IG25
 
G_M000_IG242:                ;; offset=0x1C65
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 24
       je       SHORT G_M000_IG243
       cmp      edi, 25
       jne      G_M000_IG340
 
G_M000_IG243:                ;; offset=0x1C77
       mov      edi, dword ptr [r14+0x0C]
       jmp      G_M000_IG26
 
G_M000_IG244:                ;; offset=0x1C80
       mov      rdi, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG245:                ;; offset=0x1C89
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG27
       mov      rdi, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       mov      rcx, gword ptr [rbp-0x1C0]
       mov      rdx, gword ptr [rbp-0x2C0]
       jmp      G_M000_IG27
 
G_M000_IG246:                ;; offset=0x1CAF
       mov      rdi, r12
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       jne      G_M000_IG169
       jmp      G_M000_IG268
 
G_M000_IG247:                ;; offset=0x1CC5
 
G_M000_IG248:                ;; offset=0x1CC5
       mov      rdi, r13
       mov      rsi, rdx
       mov      rdx, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime:ComputeStructuralHashCode(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):int]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyDict:MixNativeHash(int):uint]
       mov      edx, eax
       mov      rsi, r13
       mov      rdi, r12
       mov      rcx, gword ptr [rbp-0x1C0]
       mov      r8, gword ptr [rbp-0x2C0]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeIndex(System.Object,uint,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int:this]
       mov      dword ptr [rbp-0x14C], eax
       test     eax, eax
       jl       SHORT G_M000_IG246
       mov      rdi, bword ptr [rbp-0x1B8]
       mov      rsi, gword ptr [rbp-0x2C8]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, bword ptr [rbp-0x1B8]
       lea      rdi, bword ptr [rax+0x08]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, bword ptr [rbp-0x1B8]
       mov      eax, dword ptr [rbp-0x14C]
       mov      dword ptr [rdi+0x10], eax
       mov      r9d, eax
       jmp      G_M000_IG29
 
G_M000_IG249:                ;; offset=0x1D40
       xor      rax, rax
       jmp      G_M000_IG32
 
G_M000_IG250:                ;; offset=0x1D47
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r12d, eax
       mov      rax, gword ptr [rbp-0x1A0]
       jmp      G_M000_IG36
 
G_M000_IG251:                ;; offset=0x1D5F
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, gword ptr [rbp-0x1A0]
       jmp      G_M000_IG38
 
G_M000_IG252:                ;; offset=0x1D77
       mov      esi, r12d
       not      esi
       mov      edi, esi
       cmp      edi, dword ptr [rbx+0x44]
       jge      SHORT G_M000_IG254
 
G_M000_IG253:                ;; offset=0x1D83
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, gword ptr [rbp-0x1A0]
 
G_M000_IG254:                ;; offset=0x1D93
       lea      r13, bword ptr [rbx+0x50]
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG256
 
G_M000_IG255:                ;; offset=0x1DA0
       mov      rcx, 0xFFFFFFFFFE7FF
       bt       rcx, rdi
       jae      SHORT G_M000_IG257
 
G_M000_IG256:                ;; offset=0x1DB0
       mov      edi, dword ptr [r14+0x14]
       jmp      SHORT G_M000_IG258
 
G_M000_IG257:                ;; offset=0x1DB6
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       mov      rax, gword ptr [rbp-0x1A0]
 
G_M000_IG258:                ;; offset=0x1DC8
       cmp      edi, dword ptr [r13+0x08]
       jae      G_M000_IG341
       mov      rcx, bword ptr [r13]
       mov      edi, edi
       xor      rdx, rdx
       mov      gword ptr [rcx+8*rdi], rdx
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG260
 
G_M000_IG259:                ;; offset=0x1DE7
       mov      rcx, 0xFFFFFFFFFE7FF
       bt       rcx, rdi
       jae      SHORT G_M000_IG261
 
G_M000_IG260:                ;; offset=0x1DF7
       mov      edi, dword ptr [r14+0x14]
       jmp      SHORT G_M000_IG262
 
G_M000_IG261:                ;; offset=0x1DFD
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       mov      rax, gword ptr [rbp-0x1A0]
 
G_M000_IG262:                ;; offset=0x1E0F
       mov      dword ptr [rbx+0x44], edi
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      ecx, dword ptr [rbx+0x40]
       inc      ecx
       cmp      ecx, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       shl      rcx, 5
       lea      r14, bword ptr [rdi+rcx+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rcx, gword ptr [r14]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rdx, gword ptr [rdi+0x88]
       mov      rdx, gword ptr [rdx+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG264
 
G_M000_IG263:                ;; offset=0x1E4F
       mov      rdi, rdx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG264:                ;; offset=0x1E58
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       je       SHORT G_M000_IG266
 
G_M000_IG265:                ;; offset=0x1E64
       cmp      dword ptr [rdi+0x20], 0
       je       SHORT G_M000_IG266
       jmp      SHORT G_M000_IG267
 
G_M000_IG266:                ;; offset=0x1E6C
       lea      r13, bword ptr [rbx+0x50]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [r13]
       mov      esi, eax
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, gword ptr [rbp-0x1A0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG126
 
G_M000_IG267:                ;; offset=0x1E9E
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      SHORT G_M000_IG266
 
G_M000_IG268:                ;; offset=0x1EA9
       mov      rdx, gword ptr [r14]
       mov      rcx, gword ptr [rbx+0x18]
       mov      rdi, r12
       mov      rsi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG05
 
G_M000_IG269:                ;; offset=0x1ED0
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       cmp      dword ptr [r14+0x08], 0
       je       G_M000_IG271
       mov      rsi, r13
       mov      rdi, 0x7E4EDA299378
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG270
       mov      rsi, r13
       mov      rdi, 0x7E4ED8EA6558
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG270
       mov      rsi, r13
       mov      rdi, 0x7E4ED8E735C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       sete     r12b
       movzx    r12, r12b
       jmp      SHORT G_M000_IG272
 
G_M000_IG270:                ;; offset=0x1F3A
       mov      edi, dword ptr [r14+0x08]
       mov      r12, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r14]
       mov      gword ptr [rbp-0x2D0], rax
       call     [Lokad.Lython.Runtime.LythonRuntime:MapExecutableUnary(int):int]
       mov      edi, eax
       mov      rsi, r13
       mov      rdx, r12
       mov      rcx, gword ptr [rbp-0x2D0]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateUnaryOperator(int,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG05
 
G_M000_IG271:                ;; offset=0x1F7B
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       sete     r12b
       movzx    r12, r12b
 
G_M000_IG272:                ;; offset=0x1F8E
       test     r12d, r12d
       jne      G_M000_IG169
       jmp      SHORT G_M000_IG270
 
G_M000_IG273:                ;; offset=0x1F99
       cmp      dword ptr [r14+0x08], 3
       je       G_M000_IG169
       jmp      G_M000_IG12
 
G_M000_IG274:                ;; offset=0x1FA9
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      esi, dword ptr [r14+0x0C]
       mov      rdi, rbx
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r12, rax
       cmp      dword ptr [r14+0x1C], 48
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x3C], eax
       test     eax, eax
       jne      SHORT G_M000_IG278
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      edi, eax
       mov      r8, gword ptr [r14]
       mov      rcx, gword ptr [rbx+0x18]
       lea      r9, [rbp-0x48]
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG277
       movzx    rdi, byte  ptr [rbp-0x48]
       test     edi, edi
       jne      SHORT G_M000_IG275
       mov      rdi, 0x7E46F9803118
       mov      rdx, gword ptr [rdi]
       jmp      SHORT G_M000_IG276
 
G_M000_IG275:                ;; offset=0x2020
       mov      rdx, 0x7E46F9803110
       mov      rdx, gword ptr [rdx]
 
G_M000_IG276:                ;; offset=0x202D
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG05
 
G_M000_IG277:                ;; offset=0x203E
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       jmp      SHORT G_M000_IG279
 
G_M000_IG278:                ;; offset=0x2049
       mov      edi, dword ptr [r14+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
 
G_M000_IG279:                ;; offset=0x2053
       mov      edi, eax
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeBinary(int,System.Object,System.Object):bool]
       test     eax, eax
       je       G_M000_IG169
       cmp      dword ptr [rbp-0x3C], 0
       je       G_M000_IG281
       mov      rsi, r13
       mov      rdi, 0x7E4EDA299378
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG280
       mov      rsi, r13
       mov      rdi, 0x7E4ED8EA6558
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG280
       mov      rsi, r13
       mov      rdi, 0x7E4ED8E735C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       G_M000_IG169
 
G_M000_IG280:                ;; offset=0x20BC
       mov      rsi, r12
       mov      rdi, 0x7E4EDA299378
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG282
       mov      rsi, r12
       mov      rdi, 0x7E4ED8EA6558
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG282
       mov      rsi, r12
       mov      rdi, 0x7E4ED8E735C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       G_M000_IG169
       jmp      SHORT G_M000_IG282
 
G_M000_IG281:                ;; offset=0x2107
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      edi, eax
       mov      rcx, gword ptr [rbx+0x18]
       mov      r8, gword ptr [r14]
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       jmp      SHORT G_M000_IG283
 
G_M000_IG282:                ;; offset=0x2127
       mov      edx, dword ptr [r14+0x08]
       mov      rcx, gword ptr [rbx+0x18]
       mov      r8, gword ptr [r14]
       mov      rdi, r13
       mov      rsi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateAugmentedBuiltin(System.Object,System.Object,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
 
G_M000_IG283:                ;; offset=0x213E
       mov      rdi, rbx
       mov      rsi, r14
       mov      rdx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG05
 
G_M000_IG284:                ;; offset=0x2152
       lea      rdx, [rbp-0x50]
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerComparison(byref,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG285
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      esi, dword ptr [r14+0x0C]
       mov      rdi, rbx
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r12, rax
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      edi, eax
       mov      r8, gword ptr [r14]
       mov      rcx, gword ptr [rbx+0x18]
       lea      r9, [rbp-0x50]
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG169
 
G_M000_IG285:                ;; offset=0x21B7
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      esi, eax
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, gword ptr [rbx+0x18]
       mov      r13, gword ptr [r14]
       mov      rdi, gword ptr [rdi+0xA0]
       cmp      byte  ptr [rdi], dil
       xor      eax, eax
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rdi+0x88]
       mov      rax, gword ptr [rax+0x20]
       test     rax, rax
       je       SHORT G_M000_IG286
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG286:                ;; offset=0x21FE
       mov      rdi, gword ptr [rdi+0x178]
       mov      gword ptr [rbp-0x158], rdi
       lea      rdi, [rbp-0x158]
       call     [System.Threading.CancellationToken:get_IsCancellationRequested():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG287
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
 
G_M000_IG287:                ;; offset=0x2226
       cmp      byte  ptr [rbp-0x50], 0
       jne      G_M000_IG05
 
G_M000_IG288:                ;; offset=0x2230
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [rbx+0x40], eax
       jmp      G_M000_IG06
 
G_M000_IG289:                ;; offset=0x2241
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG169
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rdx, gword ptr [r14]
       mov      rsi, gword ptr [rbx+0x18]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      G_M000_IG05
       jmp      SHORT G_M000_IG288
 
G_M000_IG290:                ;; offset=0x228A
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG288
       mov      esi, dword ptr [rbx+0x44]
       dec      esi
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      SHORT G_M000_IG288
 
G_M000_IG291:                ;; offset=0x22A7
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      rsi, r13
       mov      rdi, 0x7E4EDA729D50
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG292
       mov      rdi, rbx
       mov      rsi, r14
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG05
 
G_M000_IG292:                ;; offset=0x22E4
       mov      rsi, r13
       mov      rdi, 0x7E4EDA621D10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG293
       mov      rsi, r13
       mov      rdi, 0x7E4EDA29D778
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG293
       mov      rsi, r13
       mov      rdi, 0x7E4EDA7056F0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG293
       mov      rsi, r13
       mov      rdi, 0x7E4EDA371118
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG293
       mov      rsi, r13
       mov      rdi, 0x7E4EDA29CCC8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG293
       mov      rsi, r13
       mov      rdi, 0x7E4EDA61CEE8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG293
       mov      rsi, r13
       mov      rdi, 0x7E4EDA6D0640
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       G_M000_IG169
 
G_M000_IG293:                ;; offset=0x238D
       mov      rdx, gword ptr [rbx+0x18]
       mov      rsi, gword ptr [r14]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG05
 
G_M000_IG294:                ;; offset=0x23B1
       lea      rsi, bword ptr [rbx+0x50]
       mov      edi, dword ptr [r14+0x10]
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG341
       mov      rsi, bword ptr [rsi]
       mov      r13, gword ptr [rsi+8*rdi]
       cmp      dword ptr [rbx+0x68], 0
       je       SHORT G_M000_IG297
       mov      rsi, r13
       mov      rdi, 0x7E4EDA61EF48
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG297
       lea      rdx, [rbp-0x60]
       lea      rsi, [rbp-0x58]
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextInteger(byref,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG297
       cmp      byte  ptr [rbp-0x58], 0
       jne      SHORT G_M000_IG296
 
G_M000_IG295:                ;; offset=0x2401
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG288
 
G_M000_IG296:                ;; offset=0x2413
       mov      rdi, rbx
       mov      rsi, r14
       mov      rdx, qword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:PublishInteger(byref,long):this]
       jmp      G_M000_IG05
 
G_M000_IG297:                ;; offset=0x2428
       mov      rsi, r13
       mov      rdi, 0x7E4EDA729D50
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG299
       mov      rsi, r13
       mov      rdi, 0x7E4EDA61EF48
       call     CORINFO_HELP_CHKCASTCLASS
       mov      r13, rax
       cmp      byte  ptr [r13], r13b
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:CheckExecution():this]
       lea      rsi, [rbp-0x78]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextCore(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG298
       xor      r13, r13
       xor      r12d, r12d
       jmp      SHORT G_M000_IG300
 
G_M000_IG298:                ;; offset=0x247A
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
       mov      r13, rax
       mov      r12d, edx
       jmp      SHORT G_M000_IG300
 
G_M000_IG299:                ;; offset=0x248C
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      r13, rax
       mov      r12d, edx
 
G_M000_IG300:                ;; offset=0x249B
       mov      gword ptr [rbp-0x70], r13
       mov      byte  ptr [rbp-0x68], r12b
       cmp      byte  ptr [rbp-0x68], 0
       je       G_M000_IG295
       lea      rdi, [rbp-0x70]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG05
 
G_M000_IG301:                ;; offset=0x24CB
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       je       G_M000_IG304
       lea      r13, bword ptr [rbx+0x50]
       mov      r12d, dword ptr [r14+0x10]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x16C], eax
       mov      edi, r12d
       mov      ecx, eax
       add      rdi, rcx
       mov      ecx, dword ptr [r13+0x08]
       cmp      rdi, rcx
       jbe      SHORT G_M000_IG303
 
G_M000_IG302:                ;; offset=0x2504
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG303:                ;; offset=0x250B
       mov      rdi, bword ptr [r13]
       mov      ecx, r12d
       lea      r13, bword ptr [rdi+8*rcx]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      r12, gword ptr [rdi+0x88]
       mov      rdi, 0x7E4EDA29D778
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1C8], rax
       mov      r8, gword ptr [r14]
       mov      rsi, r13
       mov      edx, dword ptr [rbp-0x16C]
       mov      r9, gword ptr [rbx+0x18]
       mov      rdi, rax
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.PyTuple:.ctor(System.ReadOnlySpan`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):this]
       mov      r13, gword ptr [rbp-0x1C8]
       jmp      SHORT G_M000_IG305
 
G_M000_IG304:                ;; offset=0x2563
       mov      rsi, 0x7E46F9801958
       mov      r13, gword ptr [rsi]
 
G_M000_IG305:                ;; offset=0x2570
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, rbx
       mov      rsi, r14
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG05
 
G_M000_IG306:                ;; offset=0x2591
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       movsxd   rdi, eax
       imul     r13, rdi, 80
       jo       G_M000_IG342
       add      r13, 64
       jo       G_M000_IG342
       mov      rdi, gword ptr [rbx+0x18]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      r12, gword ptr [rdi+0x88]
       mov      rax, gword ptr [r14]
       mov      gword ptr [rbp-0x2E0], rax
       cmp      byte  ptr [r12], r12b
       mov      rdi, 0x7E4ED9F48AF8
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x2E8], rax
       mov      rdi, rax
       mov      rsi, r12
       mov      rdx, r13
       mov      rcx, gword ptr [rbp-0x2E0]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:.ctor(Lokad.Lython.Runtime.MemoryGovernor,long,Lokad.Lython.LythonSourceSpan):this]
       mov      r12, gword ptr [rbp-0x2E8]
       mov      gword ptr [rbp-0x1A8], r12
 
G_M000_IG307:                ;; offset=0x260B
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r14]
       mov      gword ptr [rbp-0x2F0], rax
       mov      rdi, gword ptr [rdi+0xA0]
       cmp      byte  ptr [rdi], dil
       xor      ecx, ecx
       mov      gword ptr [rbp-0x178], rcx
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       je       SHORT G_M000_IG308
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG308:                ;; offset=0x2645
       mov      rdi, gword ptr [rdi+0x178]
       mov      gword ptr [rbp-0x178], rdi
       lea      rdi, [rbp-0x178]
       call     [System.Threading.CancellationToken:get_IsCancellationRequested():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG309
       mov      rdi, gword ptr [rbp-0x2F0]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
 
G_M000_IG309:                ;; offset=0x2671
       mov      eax, dword ptr [r14+0x10]
       mov      dword ptr [rbp-0x180], eax
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      edx, eax
       mov      esi, dword ptr [rbp-0x180]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:MaterializeRange(int,int):this]
       lea      rax, bword ptr [rbx+0x50]
       mov      bword ptr [rbp-0x1D0], rax
       mov      ecx, dword ptr [r14+0x10]
       mov      dword ptr [rbp-0xA4], ecx
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x17C], eax
       mov      esi, dword ptr [rbp-0xA4]
       mov      edi, esi
       mov      ecx, eax
       add      rdi, rcx
       mov      rcx, bword ptr [rbp-0x1D0]
       mov      edx, dword ptr [rcx+0x08]
       cmp      rdi, rdx
       jbe      SHORT G_M000_IG310
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG310:                ;; offset=0x26DC
       mov      rdi, bword ptr [rcx]
       mov      esi, esi
       lea      rcx, bword ptr [rdi+8*rsi]
       mov      bword ptr [rbp-0x308], rcx
       test     eax, eax
       jne      SHORT G_M000_IG311
       mov      rax, 0x7E46F9800F88
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x2F8], rax
       jmp      SHORT G_M000_IG312
 
G_M000_IG311:                ;; offset=0x2706
       movsxd   rsi, eax
       mov      rdi, 0x7E4ED8E727A0
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      gword ptr [rbp-0x300], rax
       lea      rdi, bword ptr [rax+0x10]
       mov      edx, dword ptr [rbp-0x17C]
       shl      rdx, 3
       mov      rsi, bword ptr [rbp-0x308]
       call     [System.Buffer:BulkMoveWithWriteBarrier(byref,byref,nuint)]
       mov      rax, gword ptr [rbp-0x300]
       mov      gword ptr [rbp-0x2F8], rax
 
G_M000_IG312:                ;; offset=0x2748
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, r12
       mov      rsi, r13
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Commit(long):this]
       mov      rsi, gword ptr [rbx+0x18]
       mov      rsi, gword ptr [rsi+0xA0]
       mov      rsi, gword ptr [rsi+0x88]
       mov      rdx, gword ptr [r14]
       mov      rdi, gword ptr [rbp-0x2F8]
       call     [Lokad.Lython.Runtime.PyList:FromTransferredArray(System.Object[],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       nop      
 
G_M000_IG313:                ;; offset=0x2793
       mov      rdi, r12
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Dispose():this]
       jmp      G_M000_IG05
 
G_M000_IG314:                ;; offset=0x27A1
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG05
       jmp      G_M000_IG169
 
G_M000_IG315:                ;; offset=0x27BA
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      r13d, [rax+0x01]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r12d, eax
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rcx, rax
       mov      esi, r13d
       mov      edx, r12d
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG05
 
G_M000_IG316:                ;; offset=0x27F9
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      esi, eax
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG05
 
G_M000_IG317:                ;; offset=0x2821
       mov      rsi, bword ptr [rbp-0x88]
       mov      eax, edi
       lea      rsi, bword ptr [rsi+2*rax]
       mov      eax, dword ptr [rbp-0x80]
       sub      eax, edi
       cmp      eax, 26
       jb       SHORT G_M000_IG318
       vmovups  ymm0, ymmword ptr [reloc @RWD192]
       vmovups  ymmword ptr [rsi], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD224]
       vmovups  xmmword ptr [rsi+0x20], xmm0
       mov      dword ptr [rsi+0x30], 0x20003A
       mov      edi, dword ptr [rbp-0x90]
       add      edi, 26
       mov      dword ptr [rbp-0x90], edi
       jmp      SHORT G_M000_IG319
 
G_M000_IG318:                ;; offset=0x2869
       lea      rdi, [rbp-0xA0]
       mov      rsi, 0x7E4ED465BB70
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
 
G_M000_IG319:                ;; offset=0x2880
       mov      esi, dword ptr [r14+0x1C]
       lea      rdi, [rbp-0xA0]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rdi, 0x7E4ED9587A68
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       lea      rdi, [rbp-0xA0]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rsi, rax
       mov      rdi, r14
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG320:                ;; offset=0x28C5
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG321:                ;; offset=0x28CE
       lea      rdi, [rbp-0xA0]
       mov      esi, 26
       mov      edx, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
       mov      edi, dword ptr [rbp-0x90]
       cmp      edi, dword ptr [rbp-0x80]
       jbe      G_M000_IG317
       jmp      G_M000_IG302
 
G_M000_IG322:                ;; offset=0x28F9
       mov      rsi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rsi+0x9C]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG160
 
G_M000_IG323:                ;; offset=0x2911
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG324:                ;; offset=0x2918
       mov      esi, r13d
       not      esi
       mov      r11, 0x7E4ED7C52F80
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG173
 
G_M000_IG325:                ;; offset=0x2932
       mov      rdi, gword ptr [rbx+0x08]
       cmp      r13d, dword ptr [rdi+0x9C]
       jge      SHORT G_M000_IG326
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      esi, r13d
       mov      r11, 0x7E4ED7C52F78
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r13, rax
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x40]
       xor      edx, edx
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rsi, rax
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG326:                ;; offset=0x2980
       mov      rdi, 0x7E4ED9587A68
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7E4ED460EE38
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG327:                ;; offset=0x29AE
       lea      rsi, bword ptr [rbx+0x50]
       cmp      r15d, dword ptr [rsi+0x08]
       jae      G_M000_IG341
       mov      rsi, bword ptr [rsi]
       mov      edi, r15d
       mov      rsi, gword ptr [rsi+8*rdi]
       mov      rdi, 0x7E4EDA6185C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG328
       lea      rdi, bword ptr [rbx+0x50]
       cmp      r15d, dword ptr [rdi+0x08]
       jae      G_M000_IG341
       mov      rdi, bword ptr [rdi]
       mov      ecx, r15d
       xor      rdx, rdx
       mov      gword ptr [rdi+8*rcx], rdx
       mov      rdi, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
 
G_M000_IG328:                ;; offset=0x2A01
       dec      r15d
       cmp      r15d, r14d
       jge      SHORT G_M000_IG327
       jmp      G_M000_IG159
 
G_M000_IG329:                ;; offset=0x2A0E
       mov      rdi, r14
       mov      rsi, 0x7E4ED46577D8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG330:                ;; offset=0x2A2A
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      esi, r12d
       mov      r11, 0x7E4ED7C52F88
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       mov      rsi, r13
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG331:                ;; offset=0x2A57
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG332:                ;; offset=0x2A60
       mov      rdi, r13
       mov      rsi, 0x7E4ED46577D8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG333:                ;; offset=0x2A7C
       mov      edi, 4
       call     [System.ThrowHelper:ThrowArgumentNullException(int)]
       int3     
 
G_M000_IG334:                ;; offset=0x2A88
       call     [System.ThrowHelper:ThrowInvalidOperationException_ConcurrentOperationsNotSupported()]
       int3     
 
G_M000_IG335:                ;; offset=0x2A8F
       mov      rdi, r12
       mov      rsi, r13
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG336:                ;; offset=0x2AA4
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG337:                ;; offset=0x2AAD
       mov      rdi, r13
       mov      rsi, 0x7E4ED46577D8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG338:                ;; offset=0x2AC9
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      esi, r13d
       mov      r11, 0x7E4ED7C52FD8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r15, rax
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x40]
       xor      edx, edx
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rsi, rax
       mov      rdi, r15
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG339:                ;; offset=0x2B0A
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      esi, r13d
       mov      r11, 0x7E4ED7C52FE8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r15, rax
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x40]
       mov      edx, 1
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rsi, rax
       mov      rdi, r15
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG340:                ;; offset=0x2B4E
       mov      rdi, r14
       mov      rsi, 0x7E4ED465A178
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG341:                ;; offset=0x2B6A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG342:                ;; offset=0x2B70
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG343:                ;; offset=0x2B76
       push     rax
 
G_M000_IG344:                ;; offset=0x2B77
       mov      rdi, gword ptr [rbp-0x1A8]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Dispose():this]
       nop      
 
G_M000_IG345:                ;; offset=0x2B85
       vzeroupper 
       add      rsp, 8
       ret      
 
G_M000_IG346:                ;; offset=0x2B8D
       push     rax
 
G_M000_IG347:                ;; offset=0x2B8E
       mov      rdi, gword ptr [rbp-0x298]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Dispose():this]
       nop      
 
G_M000_IG348:                ;; offset=0x2B9C
       vzeroupper 
       add      rsp, 8
       ret      
 
RWD00  	dd	000018CBh ; case G_M000_IG222
       	dd	0000287Dh ; case G_M000_IG321
       	dd	00001883h ; case G_M000_IG221
       	dd	0000182Fh ; case G_M000_IG220
       	dd	0000287Dh ; case G_M000_IG321
       	dd	0000287Dh ; case G_M000_IG321
       	dd	00002769h ; case G_M000_IG315
       	dd	000027A8h ; case G_M000_IG316
       	dd	00002540h ; case G_M000_IG306
       	dd	0000049Dh ; case G_M000_IG39
       	dd	0000287Dh ; case G_M000_IG321
       	dd	0000287Dh ; case G_M000_IG321
       	dd	0000287Dh ; case G_M000_IG321
       	dd	0000287Dh ; case G_M000_IG321
       	dd	0000287Dh ; case G_M000_IG321
       	dd	0000287Dh ; case G_M000_IG321
       	dd	00002256h ; case G_M000_IG291
       	dd	00002360h ; case G_M000_IG294
       	dd	00000033h ; case G_M000_IG04
       	dd	00001169h ; case G_M000_IG162
       	dd	0000287Dh ; case G_M000_IG321
       	dd	0000287Dh ; case G_M000_IG321
       	dd	000000E3h ; case G_M000_IG11
       	dd	000000E3h ; case G_M000_IG11
       	dd	00001E7Fh ; case G_M000_IG269
       	dd	000021DFh ; case G_M000_IG288
       	dd	000021F0h ; case G_M000_IG289
       	dd	00002101h ; case G_M000_IG284
       	dd	0000287Dh ; case G_M000_IG321
       	dd	0000287Dh ; case G_M000_IG321
       	dd	0000287Dh ; case G_M000_IG321
       	dd	0000287Dh ; case G_M000_IG321
       	dd	0000287Dh ; case G_M000_IG321
       	dd	000010A9h ; case G_M000_IG153
       	dd	000028A8h ; case G_M000_IG322
       	dd	000028A8h ; case G_M000_IG322
       	dd	0000287Dh ; case G_M000_IG321
       	dd	0000287Dh ; case G_M000_IG321
       	dd	00002239h ; case G_M000_IG290
       	dd	00002750h ; case G_M000_IG314
       	dd	00002750h ; case G_M000_IG314
       	dd	00002750h ; case G_M000_IG314
       	dd	00002750h ; case G_M000_IG314
       	dd	00002750h ; case G_M000_IG314
RWD176 	dd	00001396h ; case G_M000_IG184
       	dd	00000E1Eh ; case G_M000_IG127
       	dd	000017C1h ; case G_M000_IG218
       	dd	000005C6h ; case G_M000_IG46
RWD192 	dq	00780065006E0055h, 0074006300650070h, 0069002000640065h, 006E0069006C006Eh
RWD224 	dq	0070006F00200065h, 00650064006F0063h

; Total bytes of code 11172

; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 272
       lea      rbp, [rsp+0x110]
       xor      eax, eax
       mov      qword ptr [rbp-0x108], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0x100], zmm8
       vmovdqu32 zmmword ptr [rbp-0xC0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x80], zmm8
       vmovdqu  ymmword ptr [rbp-0x40], ymm8
       mov      qword ptr [rbp-0x20], rax
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
 
G_M000_IG02:                ;; offset=0x0048
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x58], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x58], 0
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0063
       mov      rdi, 0x7E4ED9A66F18
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA8], rax
       mov      rdi, gword ptr [rbp-0xA8]
       mov      rsi, 0x7E4ED46583C0
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG04:                ;; offset=0x009D
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG05
       mov      rdi, 0x7E4EDAAC6498
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, 0x7E4ED9BC6E20
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.LythonRunOptions:.ctor():this]
       mov      rax, gword ptr [rbp-0xA0]
       mov      gword ptr [rbp-0x18], rax
 
G_M000_IG05:                ;; offset=0x00E9
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_MemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x68], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x68], 0
       jne      SHORT G_M000_IG06
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x20]
       mov      gword ptr [rbp-0x90], rax
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x90], 0
       jne      G_M000_IG10
       mov      rdi, 0x7E4EDAAC649C
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovups  xmmword ptr [rbp-0x48], xmm0
       mov      rdi, 0x7E4ED9B06988
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x98], rax
       mov      rsi, qword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x98]
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
       mov      rax, gword ptr [rbp-0x98]
       mov      gword ptr [rbp-0x70], rax
 
G_M000_IG06:                ;; offset=0x017E
       mov      rax, gword ptr [rbp-0x70]
       mov      gword ptr [rbp-0x28], rax
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdi, gword ptr [rbp-0xB0]
       mov      rsi, 0x7E4EDAAC64A0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xB0]
       mov      gword ptr [rbp-0xD8], rax
       mov      rdi, gword ptr [rbp-0xD8]
       mov      r11, 0x7E4ED7C53A40
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x30], rax
 
G_M000_IG07:                ;; offset=0x01CD
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_ResultMemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, gword ptr [rbp-0x78]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x78], 0
       jne      SHORT G_M000_IG08
       mov      rdi, 0x7E4EDAAC65A8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rbp-0x80], rax
 
G_M000_IG08:                ;; offset=0x0203
       mov      rax, gword ptr [rbp-0x80]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, gword ptr [rbp-0xB8]
       mov      rsi, 0x7E4EDAAC65B0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rbp-0xE0], rax
       mov      rdi, gword ptr [rbp-0xE0]
       mov      r11, 0x7E4ED7C53A48
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x38], rax
 
G_M000_IG09:                ;; offset=0x024A
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rbp-0xC0], rax
       mov      rdi, gword ptr [rbp-0xC0]
       mov      rsi, 0x7E4EDAAC66B8
       call     CORINFO_HELP_DELEGATEPROFILE32
       mov      rax, gword ptr [rbp-0xC0]
       mov      gword ptr [rbp-0xE8], rax
       mov      rdi, gword ptr [rbp-0x18]
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdx, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:WithMemoryOwners(Lokad.Lython.ILythonMemoryBudget,Lokad.Lython.ILythonMemoryBudget):Lokad.Lython.LythonRunOptions:this]
       mov      gword ptr [rbp-0xF0], rax
       mov      rax, gword ptr [rbp-0xE8]
       mov      rdx, gword ptr [rbp-0xF0]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rdi, gword ptr [rax+0x10]
       mov      rax, gword ptr [rbp-0xE8]
       call     [rax+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      gword ptr [rbp-0xF8], rax
       mov      rdi, gword ptr [rbp-0xF8]
       mov      rsi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonExecutionResult:OwnMemoryScope(Lokad.Lython.ILythonMemoryScope):Lokad.Lython.LythonExecutionResult:this]
       mov      gword ptr [rbp-0x50], rax
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x02D4
       mov      rdi, 0x7E4EDAAC68C8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG06
 
G_M000_IG11:                ;; offset=0x02E8
       call     G_M000_IG16
       nop      
 
G_M000_IG12:                ;; offset=0x02EE
       mov      rdi, 0x7E4EDAAC69DC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x50]
 
G_M000_IG13:                ;; offset=0x0301
       add      rsp, 272
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x030A
       push     rax
 
G_M000_IG15:                ;; offset=0x030B
       mov      gword ptr [rbp-0x88], rdi
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rbp-0xC8], rax
       mov      rdi, gword ptr [rbp-0xC8]
       mov      rsi, 0x7E4EDAAC67C0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xC8]
       mov      gword ptr [rbp-0x100], rax
       mov      rdi, gword ptr [rbp-0x100]
       mov      r11, 0x7E4ED7C53A50
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG16:                ;; offset=0x035B
       push     rax
 
G_M000_IG17:                ;; offset=0x035C
       cmp      gword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG18
       mov      rdi, 0x7E4EDAAC68CC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rbp-0xD0], rax
       mov      rdi, gword ptr [rbp-0xD0]
       mov      rsi, 0x7E4EDAAC68D0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rbp-0x108], rax
       mov      rdi, gword ptr [rbp-0x108]
       mov      r11, 0x7E4ED7C53A58
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG18:                ;; offset=0x03B5
       mov      rdi, 0x7E4EDAAC69D8
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG19:                ;; offset=0x03C5
       add      rsp, 8
       ret      
 
; Total bytes of code 970

; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 134
; 16 inlinees with PGO data; 70 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 232
       lea      rbp, [rsp+0x110]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0xB0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x80], zmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      r15, rsi
       mov      rbx, rdx
 
G_M000_IG02:                ;; offset=0x003B
       mov      r14, gword ptr [rdi+0x08]
       test     r14, r14
       je       G_M000_IG66
       test     rbx, rbx
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x004D
       mov      rax, 0x7E4ED9BC6E20
       mov      qword ptr [rbp-0xB0], rax
       lea      rbx, [rbp-0xB0]
 
G_M000_IG04:                ;; offset=0x0065
       mov      r13, gword ptr [rbx+0x38]
       test     r13, r13
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x006E
       mov      r13, gword ptr [rdi+0x20]
       test     r13, r13
       je       G_M000_IG67
 
G_M000_IG06:                ;; offset=0x007B
       mov      rdi, 0x7E4ED9B06988
       cmp      qword ptr [r13], rdi
       jne      G_M000_IG68
       mov      r12, gword ptr [r13+0x10]
       mov      rdi, gword ptr [r12+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      gword ptr [rbp-0xC8], rdi
       xor      edi, edi
       mov      dword ptr [rbp-0x2C], edi
 
G_M000_IG07:                ;; offset=0x00A8
       mov      rdi, gword ptr [rbp-0xC8]
       call     [System.Threading.Monitor:Enter(System.Object)]
       mov      dword ptr [rbp-0x2C], 1
       cmp      byte  ptr [r12+0x38], 0
       jne      G_M000_IG10
       mov      rdi, 0x7E4ED9B06D88
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xD0], rax
       mov      rsi, gword ptr [r12+0x08]
       lea      rdi, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xD0]
       lea      rdi, bword ptr [rax+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [r12+0x18]
       mov      gword ptr [rbp-0x108], rax
       mov      rcx, gword ptr [rbp-0xD0]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbp-0x108]
       test     rsi, rsi
       je       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x012A
       lea      rdi, bword ptr [rsi+0x28]
       mov      rsi, gword ptr [rbp-0xD0]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG09:                ;; offset=0x013A
       lea      rdi, bword ptr [r12+0x18]
       mov      rsi, gword ptr [rbp-0xD0]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x014D
       mov      rdi, r12
       call     [System.ThrowHelper:ThrowObjectDisposedException(System.Object)]
       int3     
 
G_M000_IG11:                ;; offset=0x0157
       mov      rdi, gword ptr [rbp-0xC8]
       call     [System.Threading.Monitor:Exit(System.Object)]
       mov      r12, gword ptr [rbp-0xD0]
 
G_M000_IG12:                ;; offset=0x016B
       mov      gword ptr [rbp-0xB8], r12
 
G_M000_IG13:                ;; offset=0x0172
       mov      rdi, gword ptr [rbx+0x40]
       test     rdi, rdi
       cmove    rdi, r13
       mov      rax, 0x7E4ED9B06988
       cmp      qword ptr [rdi], rax
       jne      G_M000_IG62
       mov      r13, gword ptr [rdi+0x10]
       mov      rdi, gword ptr [r13+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      gword ptr [rbp-0xD8], rdi
       xor      edi, edi
       mov      dword ptr [rbp-0x30], edi
 
G_M000_IG14:                ;; offset=0x01A8
       mov      rdi, gword ptr [rbp-0xD8]
       call     [System.Threading.Monitor:Enter(System.Object)]
       mov      dword ptr [rbp-0x30], 1
       cmp      byte  ptr [r13+0x38], 0
       jne      G_M000_IG17
       mov      rdi, 0x7E4ED9B06D88
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xE0], rax
       mov      rsi, gword ptr [r13+0x08]
       lea      rdi, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xE0]
       lea      rdi, bword ptr [rax+0x10]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [r13+0x18]
       mov      gword ptr [rbp-0x100], rax
       mov      rcx, gword ptr [rbp-0xE0]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbp-0x100]
       test     rsi, rsi
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0227
       lea      rdi, bword ptr [rsi+0x28]
       mov      rsi, gword ptr [rbp-0xE0]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG16:                ;; offset=0x0237
       lea      rdi, bword ptr [r13+0x18]
       mov      rsi, gword ptr [rbp-0xE0]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0249
       mov      rdi, r13
       call     [System.ThrowHelper:ThrowObjectDisposedException(System.Object)]
       int3     
 
G_M000_IG18:                ;; offset=0x0253
       mov      rdi, gword ptr [rbp-0xD8]
       call     [System.Threading.Monitor:Exit(System.Object)]
       mov      r13, gword ptr [rbp-0xE0]
 
G_M000_IG19:                ;; offset=0x0267
       mov      gword ptr [rbp-0xC0], r13
 
G_M000_IG20:                ;; offset=0x026E
       mov      rax, gword ptr [rbx+0x60]
       mov      gword ptr [rbp-0xF8], rax
       mov      rdi, 0x7E4ED9BC6E20
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xE8], rax
       mov      rsi, gword ptr [rbx+0x08]
       lea      rdi, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x10]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x20]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x20]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x60]
       mov      rsi, gword ptr [rbp-0xF8]
       call     CORINFO_HELP_ASSIGN_REF
       movzx    rdi, byte  ptr [rbx+0x58]
       mov      rax, gword ptr [rbp-0xE8]
       mov      byte  ptr [rax+0x58], dil
       mov      rsi, gword ptr [rbx+0x28]
       lea      rdi, bword ptr [rax+0x28]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x30]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x30]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, qword ptr [rbx+0x68]
       mov      rax, gword ptr [rbp-0xE8]
       mov      qword ptr [rax+0x68], rdi
       mov      rsi, gword ptr [rbx+0x38]
       lea      rdi, bword ptr [rax+0x38]
 
G_M000_IG21:                ;; offset=0x0337
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x40]
       mov      rbx, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rbx+0x40]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [rbx+0x48]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [rbx+0x50]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, 0x7E4ED9E7A130
       cmp      qword ptr [r14+0x18], rdi
       jne      G_M000_IG61
       mov      r14, gword ptr [r14+0x10]
       mov      rdi, r14
       call     [Lokad.Lython.LythonEngine+<>c__DisplayClass8_0:<CompileCore>g__CreatePreExecutionFailure|1():Lokad.Lython.LythonExecutionResult:this]
       mov      r13, rax
       test     r13, r13
       jne      G_M000_IG57
       mov      rdi, 0x7E4EDA186328
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rsi, gword ptr [r14+0x10]
       mov      r12, gword ptr [r14+0x18]
       lea      rdi, bword ptr [r13+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r13+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      r14, gword ptr [r14+0x20]
       test     r14, r14
       je       G_M000_IG58
       mov      rdi, 0x7E4EDA5EBAC8
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
 
G_M000_IG22:                ;; offset=0x03E3
       lea      rdi, bword ptr [r12+0x08]
       mov      rsi, r15
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x10]
       mov      rsi, rbx
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x18]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x20]
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, 0x7E4EDA5EBB48
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       lea      rdi, bword ptr [r15+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, 0x7E4EDA5F0BA0
       mov      qword ptr [r15+0x18], rdi
       mov      rdi, 0x7E46F9803120
       mov      rbx, gword ptr [rdi]
       mov      rdi, 0x7E4F571013F0
       mov      rax, 0x7E4F578CC810
       call     rax
       cmp      dword ptr [rax], 4
       jle      G_M000_IG59
       mov      rdi, gword ptr [rax+0x08]
       mov      rax, bword ptr [rdi+0x20]
       test     rax, rax
       je       G_M000_IG59
 
G_M000_IG23:                ;; offset=0x0480
       mov      rax, gword ptr [rax+0x10]
       test     rax, rax
       jne      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0489
       call     [System.Threading.Thread:InitializeCurrentThread():System.Threading.Thread]
 
G_M000_IG25:                ;; offset=0x048F
       mov      r14, gword ptr [rax+0x08]
       test     r14, r14
       jne      G_M000_IG60
       mov      rdi, 0x7E46F9801160
       mov      r14, gword ptr [rdi]
 
G_M000_IG26:                ;; offset=0x04A9
       mov      rdi, 0x7E4EDA5EBED8
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rdi, 0x7E4ED7C44828
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       lea      rdi, bword ptr [r13+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r13+0x20]
       mov      rsi, r15
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r13+0x08]
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, gword ptr [rbx+0x08]
       mov      gword ptr [rbp-0xF0], rdi
       xor      edi, edi
       mov      dword ptr [rbp-0x34], edi
 
G_M000_IG27:                ;; offset=0x04FE
       mov      rdi, gword ptr [rbp-0xF0]
       call     [System.Threading.Monitor:Enter(System.Object)]
       mov      dword ptr [rbp-0x34], 1
       cmp      byte  ptr [rbx+0x20], 0
       jne      G_M000_IG45
       mov      r15, gword ptr [rbx+0x10]
       mov      r14, gword ptr [r15+0x08]
       test     r14, r14
       je       G_M000_IG51
       cmp      byte  ptr [r15], r15b
       cmp      gword ptr [r14+0x08], r15
       jne      G_M000_IG46
       cmp      gword ptr [r14+0x10], r14
       jne      G_M000_IG47
       xor      rdi, rdi
       mov      gword ptr [r15+0x08], rdi
 
G_M000_IG28:                ;; offset=0x054A
       xor      rdi, rdi
       mov      gword ptr [r14+0x08], rdi
 
G_M000_IG29:                ;; offset=0x0550
       mov      gword ptr [r14+0x10], rdi
 
G_M000_IG30:                ;; offset=0x0554
       mov      gword ptr [r14+0x18], rdi
       dec      dword ptr [r15+0x18]
       inc      dword ptr [r15+0x1C]
       mov      rdi, gword ptr [r14+0x20]
       xor      rsi, rsi
       mov      gword ptr [rdi+0x20], rsi
       lea      rdi, bword ptr [rdi+0x18]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rbx, gword ptr [rbx+0x08]
       test     rbx, rbx
       je       G_M000_IG48
       mov      rdi, rbx
       call     System.Threading.ObjectHeader:GetLockHandleIfExists(System.Object):nint
       test     rax, rax
       je       G_M000_IG40
 
G_M000_IG31:                ;; offset=0x0594
       mov      r15, gword ptr [rax]
 
G_M000_IG32:                ;; offset=0x0597
       cmp      byte  ptr [r15], r15b
 
G_M000_IG33:                ;; offset=0x059A
       mov      rbx, gword ptr [r15+0x08]
       test     rbx, rbx
       jne      G_M000_IG41
 
G_M000_IG34:                ;; offset=0x05A7
       mov      rdi, 0x7E4ED9EA94A8
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       lea      rdi, bword ptr [r14+0x08]
       mov      rsi, r15
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [r15+0x08]
       test     rsi, rsi
       jne      SHORT G_M000_IG43
 
G_M000_IG35:                ;; offset=0x05CE
       mov      rdi, rsi
       test     rdi, rdi
       je       SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x05D6
       mov      rax, 0x7E4ED9E93BC0
       cmp      qword ptr [rdi], rax
       jne      G_M000_IG49
 
G_M000_IG37:                ;; offset=0x05E9
       mov      rsi, rdi
 
G_M000_IG38:                ;; offset=0x05EC
       lea      rdi, bword ptr [r14+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r15+0x08]
       test     rdi, rdi
       je       G_M000_IG50
       mov      rsi, r14
       mov      rdx, rbx
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       cmp      rax, rbx
       jne      SHORT G_M000_IG33
       mov      rdi, r14
 
G_M000_IG39:                ;; offset=0x0615
       call     [System.Threading.Condition:SignalAll():this]
       jmp      G_M000_IG55
 
G_M000_IG40:                ;; offset=0x0620
       mov      rdi, rbx
       call     [System.Threading.ObjectHeader:<GetLockObject>g__GetLockObjectFallback|11_0(System.Object):System.Threading.Lock]
       mov      r15, rax
       jmp      G_M000_IG32
 
G_M000_IG41:                ;; offset=0x0631
       mov      rdi, 0x7E4ED9EA94A8
       cmp      qword ptr [rbx], rdi
       jne      G_M000_IG34
 
G_M000_IG42:                ;; offset=0x0644
       mov      rdi, rbx
       jmp      SHORT G_M000_IG39
 
G_M000_IG43:                ;; offset=0x0649
       mov      rdi, 0x7E4ED9EA94A8
       cmp      qword ptr [rsi], rdi
       jne      G_M000_IG35
 
G_M000_IG44:                ;; offset=0x065C
       mov      rsi, gword ptr [rsi+0x10]
       jmp      SHORT G_M000_IG38
 
G_M000_IG45:                ;; offset=0x0662
       mov      rdi, rbx
       call     [System.ThrowHelper:ThrowObjectDisposedException(System.Object)]
       int3     
 
G_M000_IG46:                ;; offset=0x066C
       mov      rdi, 0x7E4ED9587A68
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       call     [System.SR:get_ExternalLinkedListNode():System.String]
       mov      rsi, rax
       mov      rdi, r13
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, r13
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG47:                ;; offset=0x0699
       mov      rdi, gword ptr [r14+0x10]
       lea      rdi, bword ptr [rdi+0x18]
       mov      rsi, gword ptr [r14+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, gword ptr [r14+0x18]
       lea      rdi, bword ptr [rdi+0x10]
       mov      rsi, gword ptr [r14+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [r14+0x10]
       lea      rdi, bword ptr [r15+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG28
 
G_M000_IG48:                ;; offset=0x06CD
       mov      rdi, 0x7E4ED46007E8
       call     [System.ArgumentNullException:Throw(System.String)]
       int3     
 
G_M000_IG49:                ;; offset=0x06DE
       mov      rdi, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG50:                ;; offset=0x06E7
       call     [System.ThrowHelper:ThrowNullReferenceException()]
       int3     
 
G_M000_IG51:                ;; offset=0x06EE
       mov      rdi, 0x7E4EDA3776E0
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rdi, r15
       mov      rsi, rbx
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.ExecutionThreads+Worker:.ctor(Lokad.Lython.Runtime.ExecutionThreads,Lokad.Lython.Runtime.ExecutionThreads+WorkItem):this]
       call     [System.Threading.ExecutionContext:IsFlowSuppressed():bool]
       test     eax, eax
       je       SHORT G_M000_IG52
       mov      rdi, gword ptr [r15+0x10]
       cmp      byte  ptr [rdi], dil
       mov      esi, 1
       call     [System.Threading.Thread:Start(bool):this]
       jmp      SHORT G_M000_IG55
 
G_M000_IG52:                ;; offset=0x072D
       call     [System.Threading.ExecutionContext:SuppressFlow():System.Threading.AsyncFlowControl]
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG53:                ;; offset=0x0737
       mov      rdi, gword ptr [r15+0x10]
       cmp      byte  ptr [rdi], dil
       mov      esi, 1
       call     [System.Threading.Thread:Start(bool):this]
       nop      
 
G_M000_IG54:                ;; offset=0x074A
       lea      rdi, [rbp-0x40]
       call     [System.Threading.AsyncFlowControl:Undo():this]
       nop      
 
G_M000_IG55:                ;; offset=0x0755
       mov      rdi, gword ptr [rbp-0xF0]
       call     [System.Threading.Monitor:Exit(System.Object)]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.ExecutionThreads+SynchronousWorkItem:Wait():Lokad.Lython.LythonExecutionResult:this]
       mov      r15, rax
 
G_M000_IG56:                ;; offset=0x076E
       lea      rdi, bword ptr [r15+0x28]
       mov      rsi, gword ptr [rbp-0xC0]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      SHORT G_M000_IG63
 
G_M000_IG57:                ;; offset=0x0780
       mov      r15, r13
       jmp      SHORT G_M000_IG56
 
G_M000_IG58:                ;; offset=0x0785
       mov      rdi, 0x7E4ED9587A68
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rdi, r15
       mov      rsi, 0x7E4ED460EE38
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG59:                ;; offset=0x07B3
       mov      edi, 4
       call     CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED
       jmp      G_M000_IG23
 
G_M000_IG60:                ;; offset=0x07C2
       xor      rdi, rdi
       cmp      byte  ptr [r14+0x18], 0
       cmovne   r14, rdi
       jmp      G_M000_IG26
 
G_M000_IG61:                ;; offset=0x07D2
       mov      rsi, r15
       mov      rdx, rbx
       mov      rdi, gword ptr [r14+0x10]
       call     [r14+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      r15, rax
       jmp      SHORT G_M000_IG56
 
G_M000_IG62:                ;; offset=0x07E5
       mov      r11, 0x7E4ED7C54E28
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      r13, rax
       jmp      G_M000_IG19
 
G_M000_IG63:                ;; offset=0x07FA
       cmp      gword ptr [rbp-0xB8], 0
       je       SHORT G_M000_IG64
       mov      rdi, 0x7E4ED9B06D88
       mov      rax, gword ptr [rbp-0xB8]
       cmp      qword ptr [rax], rdi
       jne      G_M000_IG69
       mov      rdi, rax
       call     [Lokad.Lython.LythonMemoryBudget+Scope:Dispose():this]
 
G_M000_IG64:                ;; offset=0x0827
       mov      rax, r15
 
G_M000_IG65:                ;; offset=0x082A
       add      rsp, 232
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG66:                ;; offset=0x083C
       mov      rdi, 0x7E4ED9A66F18
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7E4ED46583C0
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG67:                ;; offset=0x086A
       mov      rdi, 0x7E4ED9B06988
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       xor      esi, esi
       xor      edx, edx
       mov      rdi, r13
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
       jmp      G_M000_IG06
 
G_M000_IG68:                ;; offset=0x088E
       mov      rdi, r13
       mov      r11, 0x7E4ED7C54E20
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      r12, rax
       jmp      G_M000_IG12
 
G_M000_IG69:                ;; offset=0x08A6
       mov      rdi, rax
       mov      r11, 0x7E4ED7C54E38
       call     [r11]System.IDisposable:Dispose():this
       jmp      G_M000_IG64
 
G_M000_IG70:                ;; offset=0x08BB
       push     rax
 
G_M000_IG71:                ;; offset=0x08BC
       lea      rdi, [rbp-0x40]
       call     [System.Threading.AsyncFlowControl:Undo():this]
       nop      
 
G_M000_IG72:                ;; offset=0x08C7
       add      rsp, 8
       ret      
 
G_M000_IG73:                ;; offset=0x08CC
       push     rax
 
G_M000_IG74:                ;; offset=0x08CD
       cmp      dword ptr [rbp-0x34], 0
       je       SHORT G_M000_IG75
       mov      rdi, gword ptr [rbp-0xF0]
       call     [System.Threading.Monitor:Exit(System.Object)]
 
G_M000_IG75:                ;; offset=0x08E0
       nop      
 
G_M000_IG76:                ;; offset=0x08E1
       add      rsp, 8
       ret      
 
G_M000_IG77:                ;; offset=0x08E6
       push     rax
 
G_M000_IG78:                ;; offset=0x08E7
       mov      rdi, gword ptr [rbp-0xC0]
       mov      r11, 0x7E4ED7C54E30
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG79:                ;; offset=0x0901
       push     rax
 
G_M000_IG80:                ;; offset=0x0902
       cmp      dword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG81
       mov      rdi, gword ptr [rbp-0xD8]
       call     [System.Threading.Monitor:Exit(System.Object)]
 
G_M000_IG81:                ;; offset=0x0915
       nop      
 
G_M000_IG82:                ;; offset=0x0916
       add      rsp, 8
       ret      
 
G_M000_IG83:                ;; offset=0x091B
       push     rax
 
G_M000_IG84:                ;; offset=0x091C
       cmp      gword ptr [rbp-0xB8], 0
       je       SHORT G_M000_IG86
       mov      rdi, 0x7E4ED9B06D88
       mov      rax, gword ptr [rbp-0xB8]
       cmp      qword ptr [rax], rdi
       jne      SHORT G_M000_IG85
       mov      rdi, rax
       call     [Lokad.Lython.LythonMemoryBudget+Scope:Dispose():this]
       jmp      SHORT G_M000_IG86
 
G_M000_IG85:                ;; offset=0x0947
       mov      rdi, rax
       mov      r11, 0x7E4ED7C54E38
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG86:                ;; offset=0x0957
       nop      
 
G_M000_IG87:                ;; offset=0x0958
       add      rsp, 8
       ret      
 
G_M000_IG88:                ;; offset=0x095D
       push     rax
 
G_M000_IG89:                ;; offset=0x095E
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG90
       mov      rdi, gword ptr [rbp-0xC8]
       call     [System.Threading.Monitor:Exit(System.Object)]
 
G_M000_IG90:                ;; offset=0x0971
       nop      
 
G_M000_IG91:                ;; offset=0x0972
       add      rsp, 8
       ret      
 
; Total bytes of code 2423

