from pathlib import Path
import hashlib,json,subprocess,tarfile

r=Path(__file__).resolve().parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
code='''from pathlib import Path
import datetime,fcntl,hashlib,json,shutil,subprocess,tarfile
r=Path('/home/lokad/lython-bench-checks/native-proof-b600-20261112');ram=r/'guest-fixtures'
with (r.parent/'comparison-vm.lock').open('a')as f:
 fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
 service=subprocess.check_output(['systemctl','show','lython-b600-native-proof-20261112.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],text=True)
 assert 'MainPID=0'in service and'ActiveState=active'not in service
 assert (r/'exit-code.txt').read_text().strip()=='1'
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 raw=json.loads((r/'confirmation/confirmation.json').read_text());assert not raw['complete']and len(raw['jobs'])==11 and all(j['workersJoinedAndFixturesRemoved']for j in raw['jobs'])
 assert ram.is_mount()and not list(ram.iterdir())
 assert not(r/'partial-recovery.json').exists()
 (r/'failure-journal.log').write_text(subprocess.check_output(['journalctl','-u','lython-b600-native-proof-20261112.service','--no-pager'],text=True))
 (r/'failed-service.txt').write_text(service)
 env=dict(__import__('os').environ);env['DOTNET_ROOT']='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148'
 late=subprocess.run([env['DOTNET_ROOT']+'/dotnet',str(r/'candidate/Lokad.Lython.Benchmarks.dll'),'--compare','check-machine','--out',str(r/'machine-after-failure-late.json')],env=env,capture_output=True,text=True)
 recovery={'complete':False,'plannedJobs':12,'completedJobs':11,'cause':'Collector retained295s cutoff after supervisor/matrix expanded to390s/12jobs; compiler job and original final gate missing. Source and initial failures unchanged.','service':service,'allWorkersJoined':True,'ramEmptyBeforeUnmount':True,'lateGateReturnCode':late.returncode,'lateGateUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'lateGateIsNotOriginalFinalQualification':True,'performanceQualified':False}
 (r/'partial-state-before-cleanup.json').write_text(json.dumps(recovery,indent=2)+'\\n')
 files={p.relative_to(r).as_posix():p for p in sorted(r.rglob('*'))if p.is_file()and not{'candidate','reference','guest-fixtures'}&set(p.relative_to(r).parts)and p.name!='observations-partial.tgz'}
 manifest={n:hashlib.sha256(p.read_bytes()).hexdigest()for n,p in files.items()}
 (r/'partial-archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\\n')
 with tarfile.open(r/'observations-partial.tgz','w:gz',dereference=True)as a:
  for n,p in files.items():a.add(p,arcname=n)
  a.add(r/'partial-archive-manifest.json',arcname='partial-archive-manifest.json')
 with tarfile.open(r/'observations-partial.tgz')as a:
  for n,h in manifest.items():assert hashlib.sha256(a.extractfile(n).read()).hexdigest()==h,n
 assert shutil.disk_usage(r).free>240*1024*1024
 subprocess.run(['sudo','-n','umount',str(ram)],check=True);assert not ram.is_mount()and not list(ram.iterdir());ram.rmdir()
 recovery.update(guestFixturesRemoved=True,archivedAndVerifiedUnderLease=True,archiveSHA256=hashlib.sha256((r/'observations-partial.tgz').read_bytes()).hexdigest(),freeBytesAfterArchive=shutil.disk_usage(r).free)
 (r/'partial-recovery.json').write_text(json.dumps(recovery,indent=2)+'\\n');print(json.dumps(recovery))
'''
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True)
(r/'recovery.stdout').write_text(p.stdout,encoding='utf-8');(r/'recovery.stderr').write_text(p.stderr,encoding='utf-8');assert p.returncode==0,p.stderr
recovery=json.loads(p.stdout);print(json.dumps(recovery),flush=True)
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for n in ['observations-partial.tgz','partial-recovery.json']:
    p=subprocess.run(scp+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/native-proof-b600-20261112/'+n,str(r/n)],capture_output=True,text=True,encoding='utf-8');assert p.returncode==0,p.stderr
assert hashlib.sha256((r/'observations-partial.tgz').read_bytes()).hexdigest()==recovery['archiveSHA256']
out=r/'retrieved';assert not out.exists();out.mkdir()
with tarfile.open(r/'observations-partial.tgz')as a:
    manifest=json.loads(a.extractfile('partial-archive-manifest.json').read())
    for n,h in manifest.items():assert hashlib.sha256(a.extractfile(n).read()).hexdigest()==h,n
    a.extractall(out,filter='data')
(r/'terminal-status.json').write_text(json.dumps(recovery,indent=2)+'\n',encoding='utf-8')
print('Partial11jobs preserved and independently verified. Terminal failure cached; no users/RAM remain. No complete-campaign qualification claim.')
