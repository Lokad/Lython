from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile,xml.etree.ElementTree as ET

r=Path(__file__).resolve().parent;repo=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not(r/'diagnostic-identity.json').exists()
checks={}
for name in ['checkpoint-internal11','checkpoint-public11','checkpoint-internal10','checkpoint-public10']:
    tree=ET.parse(r/'tests'/(name+'.trx'));c=next(x for x in tree.iter()if x.tag.endswith('Counters'))
    assert c.attrib['failed']=='0'and c.attrib['notExecuted']=='0',name
    checks[name]=c.attrib
before=json.loads((r/'before.json').read_text(encoding='utf-8'))
focused=json.loads((r/'focused-source-identity.json').read_text(encoding='utf-8'))
for n,h in focused.items():assert sha(repo/n)==h,n
changed=sorted(n for n,h in focused.items()if h!=before['sourceHashes'].get(n))
assert changed==['src/Lokad.Lython/Frontend/ExecutableNativeBody.cs','src/Lokad.Lython/Frontend/ExecutableScript.NativeReturns.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs'],changed
assert sha(r/'images/before/Lokad.Lython.dll')==before['baselineCoreSHA256']
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'images/candidate/Lokad.Lython.dll')
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net10.0/Lokad.Lython.dll',r/'candidate-net10.dll')
meta=dict(beforeRevision=before['head'],beforeQualification=before['qualification'],hypothesis=before['hypothesis'],controls=before['controls'],sourceHashes=focused,changedProductionFiles=changed,images={role:{p.name:sha(p)for p in(r/'images'/role).iterdir()if p.is_file()}for role in ['before','candidate']},net10SHA256=sha(r/'candidate-net10.dll'),focusedChecks=checks,measurement='Existing complete-jobs worker/protocol, fixed common worker/adapter, separate core images sharing CLR/GC. 256warmups,5rotated rounds x16complete jobs; six unchanged scripts both APIs and separate compile. Desktop elapsed diagnostic only; allocation/source simplification distinct from CPU.')
(r/'diagnostic-identity.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')
for role,source in [('before',before['sourceHashes']),('candidate',focused)]:
    with tarfile.open(r/('sources-'+role+'.tar.xz'),'w:xz')as a:
        for n,h in source.items():
            p=r/'originals'/n if role=='before'else repo/n;assert sha(p)==h,n;a.add(p,arcname=n)
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env['DOTNET_ROOT']=str(dotnet.parent);env['PATH']=str(dotnet.parent)+';C:/Python313;'+env['PATH']
driver=r.parent/'iteration-returns-r225/tool/bin/Release/net11.0/complete-jobs.dll'
for phase in ['warm-sync','warm-async','compile']:
    folder=r/phase;assert not(folder/'measurements.json').exists()
    command=[str(dotnet),str(driver),str(r/'images/before/Lokad.Lython.Benchmarks.dll'),str(r/'images/candidate/Lokad.Lython.Benchmarks.dll'),str(r/'catalog.json'),str(folder/'hash-witness.json'),'forward','compile'if phase=='compile'else'warm','async'if phase=='warm-async'else'sync']
    with(folder/'measurements.json').open('wb')as stdout,(folder/'stderr.log').open('wb')as stderr:p=subprocess.run(command,stdout=stdout,stderr=stderr,env=env,timeout=240)
    assert p.returncode==0,(phase,(folder/'stderr.log').read_text(encoding='utf-8'))
    data=json.loads((folder/'measurements.json').read_text(encoding='utf-8-sig'));assert data['allGoldensPassed']and data['allBalancesZero']and data['ownedFixturesRemoved']
    print(phase,'complete; full goldens/balances/cleanup pass.',flush=True)
