from pathlib import Path
import hashlib,json,shutil,tarfile

r=Path(__file__).resolve().parent;q=r/'b600'
out=Path('benchmarks/results/2026-11-12-native-proof/first-form');assert not out.exists();out.mkdir(parents=True)
meta=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
recovery=json.loads((q/'partial-recovery.json').read_text(encoding='utf-8'));assert not recovery['complete']and recovery['completedJobs']==11 and recovery['guestFixturesRemoved']and recovery['archivedAndVerifiedUnderLease']
assert hashlib.sha256((q/'observations-partial.tgz').read_bytes()).hexdigest()==recovery['archiveSHA256']
with tarfile.open(q/'observations-partial.tgz')as a:
    manifest=json.loads(a.extractfile('partial-archive-manifest.json').read())
    for n,h in manifest.items():assert hashlib.sha256(a.extractfile(n).read()).hexdigest()==h,n
    assert hashlib.sha256(a.extractfile('current-core.dll').read()).hexdigest()==meta['images']['candidate']['Lokad.Lython.dll']
    raw=json.loads(a.extractfile('confirmation/confirmation.json').read());assert not raw['complete']and len(raw['jobs'])==11
    for job in raw['jobs']:
        assert job['workersJoinedAndFixturesRemoved']
        for role,identity in job['identities'].items():
            expected=meta['images']['before'if role.startswith('reference')else'candidate']['Lokad.Lython.dll']
            assert next(v['sha256']for v in identity['libraries']if Path(v['path']).name=='Lokad.Lython.dll').lower()==expected.lower()
for n in ['before.json','diagnostic-identity.json','focused-source-identity.json','sources-before.tar.xz','sources-candidate.tar.xz','source-assessment.md']:shutil.copyfile(r/n,out/n)
for n in ['identity.json','source-identity.json','observations-partial.tgz','partial-recovery.json','terminal-status.json','summary-partial.json','inventory.json','config.json','observe-not-before.json','launch.log']:shutil.copyfile(q/n,out/n)
for phase in ['warm-sync','warm-async','compile']:shutil.copytree(r/phase,out/phase)
with tarfile.open(out/'focused-checks.tar.xz','w:xz')as a:
    for subdir in ['initial-checked','tests']:
        for p in sorted((r/subdir).rglob('*')):
            if p.is_file():a.add(p,arcname=p.relative_to(r).as_posix())
    for p in sorted(r.glob('*.log')):a.add(p,arcname=p.name)
with tarfile.open(out/'preparation.tar.xz','w:xz')as a:
    for p in [*r.glob('*.py'),r/'guard.txt',r/'PLAN-before-prototype.md',*q.glob('*.py'),q/'run.sh']:
        a.add(p,arcname=p.relative_to(r).as_posix())
with tarfile.open(out/'net10-candidate.tar.xz','w:xz')as a:a.add(r/'candidate-net10.dll',arcname='Lokad.Lython.dll')
(out/'README.md').write_text('''# Linear native proof — first form, not retained

2026-11-12. Three production files replace recursive native proof with a linear
pass over the existing postorder nodes. Compilation validates consumption once;
runtime uses bounded transient index/shape scratch. Actual evaluator, call ABI,
binding, owners, stack admission and dynamic protocols remain. **No retention or
CPU improvement claim.** Qualified reference is `2ec9d67f` / frozen `c9829194`.

Initial form passes **1,646 internal/5,836 public checks per actual .NET 11/10**.
The only subsequent source change adds cancellation/refusal checks at natural
64-node boundaries; that exact form passes **1,646 internal/333 public per target**.
Original source/checks survive, including the first compile signature error.
All six unchanged scripts through both APIs and separate compilation pass complete
stdout/files/allowance/cleanup diagnostics. Allocation is flat, not a new reduction.

Desktop elapsed is mixed: searchRun−11.21..−7.41%, but JSONAsync+26.38..+27.34%
with0.76%control, CSVAsync+5.49..+7.68%with2.08%control, ordinarycompile+7.05..+7.10%
with0.06%control. These are diagnostic; all observations and unstable controls remain.

## Incomplete quiet comparison

B600 planned12jobs with390s supervisor, but the copied collector still had the
old295s cutoff for10jobs. It stopped after **11 completed warm jobs**, before
ordinary compilation and the original final quiet gate. Source did not time out
or fail a semantic check. `complete:false` remains unchanged in the raw record.
The old archive/retrieval receipt code also retained10-job assumptions; these are
preserved as failed preparation, not rewritten into a successful campaign.

Saved partial observations do not support retention:

| Complete script/API | Elapsed change, all four process pairs | Wider CPU change |
| --- | ---: | ---: |
| Captured text / Run | +5.17..+9.37% | +5.06..+9.41% |
| Captured text / RunAsync | +4.80..+9.21% | +0.92..+6.10% |
| Ordinary text / Run | +1.52..+4.05% | +0.30..+4.10% |
| Helper search / Run | +1.16..+2.13% | −0.65..+8.11% |
| JSON-lines / RunAsync | −1.02..+0.61% | −2.33..+6.25% |

Other cases and every control/IQR remain in [partial summary](summary-partial.json).
SearchAsync/CSV controls are unstable; report is mixed. These are not confidence
intervals or complete-campaign qualification. The desktop JSONAsync adversity is
not reproduced in partial data, with no cause/recovery claim.

All workers were already joined. Recovery acquired the lease, preserved the
failure journal and raw data, independently verified every archive entry, then
unmounted the empty owned fixture. No user/RAM remains. A delayed quiet snapshot
is explicitly **not the missing original final gate**. [Recovery](partial-recovery.json).
The runtime source and all failed collector/receipt assumptions remain unchanged.

Next bounded source refinement assesses removing the newly introduced per-node
input/shape packing loops. Keep linear proof and compiler validation; use actual
node operands and local shape values without a second runtime metadata traversal.
Preserve all branches, formatting reads, live inputs, current token, first refusal,
reentry and stack safety. No unchanged11-job replay is selected. A new form must
pass focused checks and complete-script diagnostics before a correctly sized
bounded comparison. This is evidence-guided refinement, not a failed-design label
or permanent veto caused by the collector error.

[Identity](diagnostic-identity.json), [source assessment](source-assessment.md),
[before](sources-before.tar.xz), [candidate](sources-candidate.tar.xz),
[focused checks](focused-checks.tar.xz), [raw partial observations/core](observations-partial.tgz),
[net10 candidate](net10-candidate.tar.xz), [exact preparation/failure](preparation.tar.xz).
Reference core remains in the earlier committed CPython archive. Exact loaded
images match all11jobs. No full prototype platform/package qualification or
publication. [Archive identities](archive-identity.json).
''',encoding='utf-8')
(out/'archive-identity.json').write_text(json.dumps({p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(out.rglob('*'))if p.is_file()and p.name!='archive-identity.json'},indent=2)+'\n',encoding='utf-8')
root=out.parent
(root/'README.md').write_text('''# Native proof redesign

The [first form](first-form/README.md) passes broad semantics/ownership checks but
has adverse partial CPU observations and an incomplete collector gate. It is not
retained. Original source/binaries, desktop adversity, collector failure and joined
recovery survive. One bounded source refinement is selected; no gain is claimed.
Current qualified runtime remains `2ec9d67f`; publication stays postponed.
''',encoding='utf-8')
h=Path('benchmarks/EXPERIMENTS.md');text=h.read_text(encoding='utf-8');at=text.index('[Current retained-source CPU captures]')
text=text[:at]+'''[Linear native proof first form](results/2026-11-12-native-proof/first-form/README.md)
passes initial14964focused checks and refined checkpoint3958checks across actual
targets, plus complete six-script bothAPI/separatecompile goldens and balances.
Allocation flat; desktop elapsed mixed/adverse. B600stops after11warmjobs because
the collector retained an old295s cutoff despite the expanded390s/12job matrix.
Compilation and original final gate are missing; no complete qualification claim.
Partial capturedRun elapsed+5.17..+9.37%/CPU+5.06..+9.41%, searchRunelapsed+1.16..+2.13%
do not support retention. All failure/source/raw evidence is archived, users joined,
empty RAM unmounted; late quiet gate explicitly separate. One source refinement
assesses removing new per-node packing, not unchanged retiming or permanent closure.

'''+text[at:];h.write_text(text,encoding='utf-8')
p=Path('PLAN.md');text=p.read_text(encoding='utf-8')
text=text.replace('B600launched with livePID3569610 at2026-11-12T00:19:41Z; observe only after\n   2026-11-12T00:27:11.652260Z. Do not restart on an observation timeout.','B600terminal failed after11warmjobs: copied collector retained295s cutoff\n   despite390s/12job supervisor/matrix. Ordinarycompile and original final quiet\n   gate are missing; no complete-campaign qualification. Partial capturedRun\n   elapsed+5.17..+9.37%/CPU+5.06..+9.41%, searchRunelapsed+1.16..+2.13% do not support\n   retention. Full original evidence/collector failure archived, all users joined,\n   empty RAM unmounted; late quiet check is not the missing gate.\n   [First form](benchmarks/results/2026-11-12-native-proof/first-form/README.md).\n   **Next bounded refinement:** remove new per-node input/shape packing loops.\n   Use actual operands and local enum values while keeping linear proof and\n   compiler consumption validation; no new argument representation or frame.\n   Preserve all semantics/current-token/ownership gates. Focused checks and one\n   whole-script diagnostic before new-source confirmation. Correct collector,\n   receipt and retrieval job/bound assumptions together. Do not replay11unchanged\n   warmjobs or label the design failed because its measurement gate is incomplete.')
a=text.index('cached: never requery. B576–B599terminal/cached.');b=text.index('New staging requires',a)
text=text[:a]+'''cached: never requery. B576–B600terminal/cached; B600failed with11partial warm
jobs, archived recovery and no remaining VM users/RAM. Its fresh proof retired
all predecessor75a14core aliases and B599raw/catalog duplicates against committed
canonical archives. Those paths are off limits; c982reference and first prototype
images remain protected until the next proven selection.
'''+text[b:]
p.write_text(text,encoding='utf-8')
print('First form/source/binaries/all adverse and failed conditions archived; PLAN records bounded refinement, no gain or completion claim.')
