from pathlib import Path
import hashlib,json,shutil,subprocess

r=Path(__file__).resolve().parent;old=r.parent/'native-inputs-r251'
meta=json.loads((old/'diagnostic-identity.json').read_text(encoding='utf-8'));sources=meta['sourceHashes']
assert not(r/'originals').exists()
for n,h in sources.items():
    p=Path(n);assert hashlib.sha256(p.read_bytes()).hexdigest()==h,n
    target=r/'originals'/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
for role in ['before','candidate']:shutil.copytree(old/'images/candidate',r/'images'/role)
shutil.copyfile(old/'candidate-net10.dll',r/'before-net10.dll')
for phase in ['warm-sync','warm-async','compile']:
    (r/phase).mkdir();shutil.copyfile(old/phase/'hash-witness.json',r/phase/'hash-witness.json')
shutil.copyfile(old/'catalog.json',r/'catalog.json');shutil.copyfile('PLAN.md',r/'PLAN-before-prototype.md')
before={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sourceHashes':sources,'baselineCoreSHA256':meta['images']['candidate']['Lokad.Lython.dll'],'qualification':'Exact production2ec9d67f, full43119174279GREEN Windows/Ubuntu actual11/10 originalstress and installedconsumers. Source unchanged in7ed6f831.','hypothesis':'Replace recursive native-body proof with one linear pass over existing postorder nodes, transient enum shapes bounded by existing expression depth. Delete recursive guard dispatch; no guest operand ABI, owner, cache or new engine. Compilation validates operand order once.','controls':'Six complete scripts both APIs and separate compile, focused semantics/current cancellation/first refusal/retained aliases/reentry. Conditional all-branch proof, formatting pure reads, mutable defaults/cells and builtin identity remain. Current B599source-backed profiles are not removable-cost estimates or speed forecasts.'}
(r/'before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
print('Exact qualified current source/core preserved before bounded native proof prototype.')
