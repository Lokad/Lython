from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile

r=Path(__file__).resolve().parent;q=r/'b600';q.mkdir();old=r.parent/'native-inputs-r251/b597'
sha=lambda b:hashlib.sha256(b).hexdigest()
meta=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
for n,h in meta['sourceHashes'].items():assert sha(Path(n).read_bytes())==h,n
for phase in ['warm-sync','warm-async','compile']:
    j=json.loads((r/phase/'measurements.json').read_text(encoding='utf-8-sig'))
    assert j['allGoldensPassed']and j['allBalancesZero']and j['ownedFixturesRemoved']
name='native-proof-b600-20261112';unit='lython-b600-native-proof-20261112'
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='R254 linear whole-native-body shape proof versus fully qualified2ec9d67f. Existing nodes/argument ABI/owners/evaluator retained; recursive guard dispatch removed, postorder validated during compilation; bounded enum scratch and natural-index current-token checks. Initial14964focused actual11/10 pass; checkpoint refinement3958affected checks pass. Six unchanged complete scripts both APIs/separatecompile pass full goldens/balances/cleanup. Allocation flat. Desktop elapsed diagnostic, including adverse JSONAsync+26.38..+27.34% with0.76%control and ordinarycompile+7.05..+7.10% with0.06%control, remains preserved. No current-source CPU claim before this one bounded group.',coreSHA256={k:meta['images']['before'if k.startswith('reference')else'candidate']['Lokad.Lython.dll']for k in ['reference','reference-control','candidate','candidate-control']},catalogSHA256=sha((r/'catalog.json').read_bytes()))
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(q/'source-identity.json').write_text(json.dumps({'beforeRevision':'2ec9d67f','baselineQualification':'43119174279Windows/Ubuntu actual11/10stress/packageGREENcached; unchanged production7ed6f831','sourceSHA256':meta['sourceHashes'],'changedProductionFiles':meta['changedProductionFiles'],'candidateQualification':'Initial14964checks, refined3958focused actual11/10 checks; full bothAPI six-script and separate compilation diagnostics pass. No full prototype delivery.','prototypeUncommitted':True,'baselineSelection':'Fully qualified2ec9d67f now selected reference. Predecessor8f8628a4 core eligible for all-alias retirement only against exact committed archive proof; all original measurements and source remain preserved.'},indent=2)+'\n',encoding='utf-8')
shutil.copyfile(r/'catalog.json',q/'representative.json');shutil.copyfile(r/'images/candidate/Lokad.Lython.dll',q/'current-core.dll')
for filename in ['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py','summarize.py','remote-launch.py']:
    s=(old/filename).read_text(encoding='utf-8').replace('native-inputs-b597-20261112',name).replace('lython-b597-native-inputs-20261112',unit).replace('native-inputs-b597-launch.py','native-proof-b600-launch.py').replace('lython-b597-fixtures','lython-b600-fixtures').replace('B597','B600')
    if filename=='remote-launch.py':
        s=s.replace("source=base/'dictionary-checkpoint-b590-20261111/candidate'","source=base/'native-inputs-b597-20261112/candidate'")
        s=s.replace("base/'dictionary-checkpoint-b590-20261111/candidate/Lokad.Lython.dll'","source/'Lokad.Lython.dll'")
        s=s.replace('RuntimeMaxSec=330','RuntimeMaxSec=390').replace('jobs=10,ownerSeconds=330','jobs=12,ownerSeconds=390')
    if filename=='collect.py':
        s=s.replace("['scripts.report-render.large', 'warm-async']]","['scripts.report-render.large', 'warm-async'], ['scripts.json-summary-helpers.large', 'warm-async'], ['scripts.text-summary-helpers.large', 'compile']]")
        s=s.replace('assert len(jobs)==10','assert len(jobs)==12')
        a=s.index("purpose='");b=s.index("',\n                  warmupSeconds",a)
        s=s[:a]+"purpose='R254 linear native shape proof versus qualified2ec9d67f. Complete captured/ordinary/search/CSV both APIs, JSON both APIs, reportAsync and ordinarycompile. Original adverse JSONAsync and compile desktop results retained. Fixed worker/adapter; RAM I/O/fullvalidation/prior-resultcleanup included. No CPython comparison or allocation-as-CPU inference"+s[b:]
    if filename=='archive-owned.py':s=s.replace("len(raw['jobs'])==10","len(raw['jobs'])==12")
    if filename=='launch.py':s=s.replace('seconds=390','seconds=450').replace('ownerSeconds=330','ownerSeconds=390')
    (q/filename).write_text(s,encoding='utf-8',newline='\n')
    if filename.endswith('.py')and filename!='remote-launch.py':ast.parse(s)
with tarfile.open(q/'payload.tgz','w:gz')as a:
    for n in ['current-core.dll','representative.json','source-identity.json','identity.json','collect.py','archive-owned.py','run.sh']:a.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz')as a:expanded=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())
retire=[]
for remote,canonical,entry,kind in [
    ('native-inputs-b597-20261112/reference/Lokad.Lython.dll','benchmarks/results/2026-11-11-dictionary-cpython-checkpoint/observations.tgz','current-core.dll','all-aliases'),
    ('current-runtime-b599-20261112/observations.tgz','benchmarks/results/2026-11-12-current-runtime-costs/observations.tgz',None,'exact'),
    ('current-runtime-b599-20261112/catalog.json','benchmarks/results/2026-11-12-current-runtime-costs/observations.tgz','catalog.json','exact')]:
    p=Path(canonical);b=p.read_bytes();assert b==subprocess.check_output(['git','show','HEAD:'+p.as_posix()])
    if entry:
        with tarfile.open(p)as a:data=a.extractfile(entry).read()
    else:data=b
    assert sha(data)not in identity['coreSHA256'].values()
    spec=dict(kind=kind,knownPath=remote,bytes=len(data),sha256=sha(data),canonicalStorage=canonical,reason='New selected reference is fully qualified2ec9d67f. Predecessor8f862 core or terminal profile duplicate evidence eligible only with exact committed canonical bytes and fresh idle/path/UID/inode/all-hardlink proofs. Current selected reference and new candidate protected.')
    if entry:spec.update(canonicalEntry=entry,canonicalArchiveSHA256=sha(b))
    retire.append(spec)
config=dict(root='/home/lokad/lython-bench-checks/'+name,unit=unit,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),requiredFreeBytes=252*1024*1024+expanded+65536,retire=retire,identity=identity)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
ast.parse((q/'remote-launch.py').read_text(encoding='utf-8').replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
assert "len(raw['jobs'])==12"in(q/'archive-owned.py').read_text(encoding='utf-8')
assert 'seconds=450'in(q/'launch.py').read_text(encoding='utf-8')
assert 'RuntimeMaxSec=390'in(q/'remote-launch.py').read_text(encoding='utf-8')
print('Prepared12short jobs,390sowner/450sobservation. Explicitly includes adverse JSONAsync and ordinarycompile; new qualified reference selected, exact predecessor archive proof verified locally. Fresh VM inventory required.')
