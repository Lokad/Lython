from pathlib import Path
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs')
t=p.read_text(encoding='utf-8')
old='''    private static bool GuardNativeBody(ExecutableCodeObject code, ExecutableNativeBody body,
        in NativeInputs arguments, ExecutionContext context)
        => (body.ClosureInputCount == 0 || arguments.Cells?.Count == body.ClosureInputCount) && (body.Root < 0 || GuardNativeReturn(body.Root + code.FirstTemporarySlot, code, body.Values, arguments, context, out _));

'''
assert t.count(old)==1;t=t.replace(old,'')
a=t.index('    private static bool GuardNativeReturn(');b=t.index('    private static bool TryReadNativeFormattedValue(',a)
t=t[:a]+Path(__file__).with_name('guard.txt').read_text(encoding='utf-8')+t[b:]
assert 'GuardNativeReturn('not in t and 'GuardNativeFormattedValue('not in t
p.write_text(t,encoding='utf-8')
print('Recursive native proof removed; prototype reuses validated existing postorder nodes.')
