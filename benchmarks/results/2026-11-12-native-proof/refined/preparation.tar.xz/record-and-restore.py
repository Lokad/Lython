from pathlib import Path
import hashlib,json,shutil,tarfile

r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython')
meta=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
before=json.loads((r/'before.json').read_text(encoding='utf-8'))
for n,h in meta['sourceHashes'].items():assert hashlib.sha256((repo/n).read_bytes()).hexdigest()==h,n
out=repo/'benchmarks/results/2026-11-12-native-proof/refined';assert not out.exists();out.mkdir()
for n in ['before.json','diagnostic-identity.json','focused-source-identity.json','sources-before.tar.xz','sources-candidate.tar.xz']:shutil.copyfile(r/n,out/n)
for phase in ['warm-sync','warm-async','compile']:
    j=json.loads((r/phase/'measurements.json').read_text(encoding='utf-8-sig'))
    assert j['allGoldensPassed']and j['allBalancesZero']and j['ownedFixturesRemoved']
    shutil.copytree(r/phase,out/phase)
with tarfile.open(out/'focused-checks.tar.xz','w:xz')as a:
    for p in sorted((r/'tests').rglob('*')):
        if p.is_file():a.add(p,arcname=p.relative_to(r).as_posix())
    for p in sorted(r.glob('*.log')):a.add(p,arcname=p.name)
with tarfile.open(out/'preparation.tar.xz','w:xz')as a:
    for p in [*r.glob('*.py'),r.parent/'prepare-refinement.py',r/'PLAN-before-refinement.md',r/'PLAN-before-condense.md']:a.add(p,arcname=p.name)
with tarfile.open(out/'candidate-images.tar.xz','w:xz')as a:
    for tfm,p in [('net11.0',r/'images/candidate/Lokad.Lython.dll'),('net10.0',r/'candidate-net10.dll')]:
        expected=meta['images']['candidate']['Lokad.Lython.dll']if tfm=='net11.0'else meta['net10SHA256']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==expected
        a.add(p,arcname=tfm+'/Lokad.Lython.dll')
decision={'disposition':'Withdraw both linear native proof forms; restore exact fully qualified2ec9d67f production.','reason':'No per-invocation allocation reduction. Replacing recursion adds compiler order validation/capacity metadata and runtime shape-stack machinery. First form partial quiet data is adverse; refined desktop capturedRun+7.90..+9.45% with1.44%control and capturedAsync+3.08..+3.56% with0.47%control do not justify retaining complexity or an additional VM campaign. This is not a fixed-percent veto or timeout-as-design-failure.','sourceGate':'Refinement removes both per-node vectors/runtime CopyInputs and packing loop. 1646internal/333public per actual target pass; all six complete scripts bothAPIs and separatecompile goldens/balances/cleanup pass.','measurementLimits':'Desktop elapsed diagnostic, no general CPU conclusion. First-form B600 incomplete:11warmjobs, no original final gate or compile job. All adverse/source/failed conditions preserved. No final refined quiet comparison or full prototype platform qualification claimed.','laterWork':'Retain lessons about guard cost; do not immediately repeat the same linear shape-stack design. Continue source-backed whole-script roadmap, selecting work/storage actually removed. Future justified designs remain open.'}
(out.parent/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
(out/'README.md').write_text('''# Linear native proof refinement — withdrawn

2026-11-12. Same qualified reference `2ec9d67f` / frozen `c9829194` as the first
form. The refinement removes the per-node CopyInputs runtime call, index/shape
packing vectors and loops. It reads actual operands into local enum shapes;
compiler postorder validation and the bounded runtime shape stack remain.

**1,646 internal/333 public focused checks pass per actual .NET 11/10**. All six
unchanged scripts through both APIs and separate compilation pass complete stdout,
files, balances and joined cleanup. Allocation is flat. No public API/ownership/
cancellation or stack policy change is selected.

Desktop capturedRun elapsed **+7.90..+9.45%**, unchanged control1.44%; capturedAsync
**+3.08..+3.56%**, control0.47%. Search/report/other controls are variable. Search
compile+31.90..+40.95% with6.42%control is also preserved; the unchanged compiler
implementation does not establish a cause. All raw phases and allocation results
remain separate from CPU conclusions. No quiet refinement comparison is claimed.

Withdraw this form and the initial linear proof. There is no per-call allocation
benefit, while compiler validation/capacity facts and runtime shape-stack machinery
add complexity. Available adverse evidence does not justify retaining that tradeoff
or another VM collection. A timeout or fixed threshold does not decide it: the
first form's collector failure remains an incomplete measurement, not a failed
design label. [Explicit decision](../decision.json). Future materially different,
source-backed designs remain open; this is not a permanent native-proof veto.

The exact qualified source is restored, removing CopyInputs, GuardStackCapacity,
the new order validator and shape-stack evaluator. Existing recursive guard and
format helpers remain. Restoration requires nonincremental builds before no-build
checks; its focused results will be recorded separately. No repeat full unchanged-
source delivery cycle or publication is started.

[Identity](diagnostic-identity.json), [before](sources-before.tar.xz),
[candidate](sources-candidate.tar.xz), [candidate images](candidate-images.tar.xz),
[checks](focused-checks.tar.xz), [preparation](preparation.tar.xz),
[archive identity](archive-identity.json). Earlier first-form adversity, incomplete
quiet data, original collector/receipt mistakes and joined recovery remain intact.
''',encoding='utf-8')
(out.parent/'README.md').write_text('''# Native proof redesign — withdrawn

Both [first form](first-form/README.md) and [refinement](refined/README.md) preserve
semantic/ownership checks but do not justify retaining their additional compiler
and runtime machinery. [Decision](decision.json). Exact qualified `2ec9d67f` source
is restored; no linear-proof scaffolding remains. Neither form establishes a CPU
gain. All source/binaries, adverse diagnostics, incomplete B600 observations and
collector failure/recovery are preserved. No permanent design veto or publication.
''',encoding='utf-8')
(out/'archive-identity.json').write_text(json.dumps({p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(out.rglob('*'))if p.is_file()and p.name!='archive-identity.json'},indent=2)+'\n',encoding='utf-8')
for n in meta['changedProductionFiles']:
    original=r/'originals'/n;assert hashlib.sha256(original.read_bytes()).hexdigest()==before['sourceHashes'][n],n
    shutil.copyfile(original,repo/n)
for n,h in before['sourceHashes'].items():assert hashlib.sha256((repo/n).read_bytes()).hexdigest()==h,n
(r/'restoration-source-proof.json').write_text(json.dumps({'sourceMatchesQualified2ec9d67f':True,'files':len(before['sourceHashes']),'removed':['Runtime linear shape proof and transient packing/pop helpers.','Compiler postorder validator and CopyInputs.','GuardStackCapacity and new MaximumDepth metadata.'],'requiresNonincrementalBuild':True},indent=2)+'\n',encoding='utf-8')
print('Both forms archived and withdrawn; exact qualified source restored. Nonincremental rebuild required before checks.')
