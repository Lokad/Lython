# Lokad.Lython 0.11.0

Updated 2026-11-12. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial whole-script improvements,
including compile-to-result. Another isolated experiment does not finish it.

## Delivery status

| State | Evidence / limitations |
| --- | --- |
| Committed and fully qualified `2ec9d67f` | Retained R250/R251 native word storage and borrowed call inputs, regressions and runtime documentation. **43119174279 terminal GREEN**, Windows/Ubuntu actual .NET 11/10, original stress and installed Release consumers. [Exact-source delivery](benchmarks/results/2026-11-12-native-inputs/delivery/README.md). No repeat qualification of unchanged production. |
| Current CPython checkpoint complete | B598, exact frozen `2ec9d67f` source/core with precommit assembly metadata; stock CPython 3.13.16. Eighteen jobs/487.070s, all gates/joins/RAM/archive pass. Compile, warm and compile-to-result separate; mediated RAM I/O, full validation and prior-result cleanup included, startup excluded. [Current guide](docs/BENCHMARKS.md), [raw/source evidence](benchmarks/results/2026-11-12-native-inputs-cpython-checkpoint/README.md). |
| Development regex input qualified | Immutable dev73/eae880c8, unchanged adapter-local Validate bridge: 86 internal/532 public per actual target, exact loaded package and 29 normal-file isolation proofs pass. First incomplete observation and terminal resumed checks retained. Normal adapter remains 0.4; no core dependency or sibling edits. [Evidence](benchmarks/results/2026-11-12-regex-development-73/README.md). Final capability gaps below remain. |
| Active runtime prototype | R254 linear native proof over existing postorder nodes. Three production files in the worktree are the tested first form, uncommitted and unselected. Evidence is committed in1d01c28e; no retention/performance claim. Qualified2ec9d67f remains the source/core reference. Initial14964focused checks pass; cancellation-checkpoint form3958affected checks pass, each across actual11/10. All six unchanged scripts both APIs and separatecompile pass full goldens/balances/cleanup. Allocation flat; desktop CPU remains unqualified. |

Completed milestones (reuse existing evidence/qualification):

- Shared compiler facts correct repeated/exponential analysis and nonlocal
  diagnostics; shared scope/binding facts ship. No CPU claim.
- Direct UTF-8 formatting/storage: allocation −8.67%; controlled elapsed/CPU
  5–8% lower. Original adverse 15.125ms remains unexplained and preserved.
- Original native helper returns: allocation −19.92% Run / −19.31% RunAsync;
  original elapsed changes are diagnostic. Fully qualified. Real double-refund
  during throwing cleanup/reentry corrected; do not repeat unchanged checks.
- Invocation setup/worker reuse, ordinary direct calls/receiver entry, lexical
  writes, returned iteration, bulk UTF-8/JSON, CSV capacity/adoption/shared keys,
  private totals, shared compiled workspace and captured native sequences ship.
  Former bulk CSV 6–8% work was reassessed/revised into current construction.
- R245 dictionary integer storage removes intermediate boxes; text allocation
  −14.90..−16.13%, CSV−3.13%, JSON-lines−4.20%, compile flat. Additional8B/key
  conservatively admitted; exposed integer identity/copies preserved. Fully
  qualified8f8628a4/458be840. Its reportAsync wider CPU+1.91..+6.38% is accepted
  historical debt, with a different reference from R250/R251.
- R250/R251 keep the ordinary ABI and cased iterator, avoid duplicate short-word
  objects in private histogram segments and share canonical UTF8 key lookup.
  Real insertion/observable binding materializes funded immutable strings.
  R251 deletes captured packing/clearing, the second16-slot buffer, appended-cell
  indexes and combined-capacity convention; one non-owning readonly input view
  borrows actual parameters and definition-owned live cells. The real binder's
  necessary parameter buffer remains. No new ledger/cache/controller/result ABI.
  Combined allocation−20.43..−22.44% for complete text; eager allowance unchanged.
  B597 capturedRun elapsed−8.74..−4.66%, ordinaryRun−9.68..−8.54% and ordinaryAsync
  −12.48..−9.49%, supporting CPU. CapturedAsync CPU remains uncertain. Additional
  reportAsync widerCPU0..+6.25% versus8f862 is accepted uncertainty; elapsed overlaps
  zero. Do not equate/compound earlier report debt or claim allocation implies CPU.
  [Source pair](benchmarks/results/2026-11-12-native-inputs/README.md).

Current warm Lython/CPython: captured text1.74×, ordinary0.99–1.06×variable,
CSV1.08–1.09×, JSON-lines0.85–0.89×variable, report1.26–1.31×variable, keyword-default
search1.52–1.60×variable. Compilation near CPython; captured compile0.83–0.84×.
Search compile-to-result1.51–1.55×variable. Older config/literal-search/CSV-summary/
manifest/patch rows remain revision-labelled. Synchronous external rows do not
settle async source-pair debt. RSS, pending-I/O/embedding tail latency and large-
file throughput remain unqualified; no single-change attribution across checkpoints.

## Next — coherent runtime redesign from current costs

1. Current-source CPU gate completed in B599: captured text1162leaves/5.85guest
   CPU seconds; keyword-default search895/4.53. Histogram/preparation remain
   material in text; dispatch/native proof/real binding in search. Labels overlap,
   not removable shares. All37raw payloads SHA-verified, joins/RAM/archive pass;
   terminal/cached. [Evidence](benchmarks/results/2026-11-12-current-runtime-costs/README.md).
   No further unchanged captures selected.
   **Next bounded prototype:** replace recursive native whole-body proof with a
   linear pass over its existing postorder nodes. Validate operand consumption
   during compilation. Existing expression-depth16 bounds transient enum-shape
   scratch; no guest-value arena, cache, per-call owner or new execution route.
   Delete recursive GuardNativeReturn/GuardNativeFormattedValue dispatch, retain
   actual pure formatting reads and re-read live values during execution. Preserve
   all-branch proof, closure store ordering, dynamic defaults/builtin identity,
   missing arguments, Python protocol fallback, current cancellation/first refusal,
   reentry and stack safety. Complete helper search and captured/ordinary text
   are affected; CSV/JSON/report controls and separate compile. Stop source gate
   after focused semantic/ownership/cancellation checks and one complete-script
   diagnostic; refine only on concrete evidence before bounded quiet confirmation.
   A faster proof is a hypothesis, not a claim that its full samples disappear.
   Frozen source gate passes. Initial build signature mismatch corrected before
   checks; original log preserved. Source/core/forms and all desktop results are
   retained. Adverse JSONAsync elapsed+26.38..+27.34% with0.76%unchanged control,
   CSVAsync+5.49..+7.68% with2.08%control, ordinarycompile+7.05..+7.10%with0.06%
   control require explicit assessment; allocation remains flat. SearchRun improves
   diagnostically, not a CPU claim. B600prepared12short jobs includes those warm
   paths and ordinarycompile;390sowner/450sobservation. One bounded quiet source
   pair, no new framework or repeated external baseline. B600terminal failed after11warmjobs: copied collector retained295s cutoff
   despite390s/12job supervisor/matrix. Ordinarycompile and original final quiet
   gate are missing; no complete-campaign qualification. Partial capturedRun
   elapsed+5.17..+9.37%/CPU+5.06..+9.41%, searchRunelapsed+1.16..+2.13% do not support
   retention. Full original evidence/collector failure archived, all users joined,
   empty RAM unmounted; late quiet check is not the missing gate.
   [First form](benchmarks/results/2026-11-12-native-proof/first-form/README.md).
   **Next bounded refinement:** remove new per-node input/shape packing loops.
   Use actual operands and local enum values while keeping linear proof and
   compiler consumption validation; no new argument representation or frame.
   Preserve all semantics/current-token/ownership gates. Focused checks and one
   whole-script diagnostic before new-source confirmation. Correct collector,
   receipt and retrieval job/bound assumptions together. Do not replay11unchanged
   warmjobs or label the design failed because its measurement gate is incomplete.
   Qualified2ec9d67f now selected comparison reference; predecessor8f862 core may
   retire only after canonical committed archive and fresh all-alias proof. All
   predecessor evidence preserved; current2ec and new candidate stay protected.

2. Implement the selected coherent milestone below. State hypothesis, complete
   affected/control scripts, removed implementation, semantic acceptance and a
   bounded before/after comparison. Preserve ordinary/async semantic paths and
   real suspension/reentry. Temporary setbacks require a completion milestone
   and an explicit regression-debt disposition; continue the roadmap afterward.
3. Focused actual11 correctness/cancellation/ownership while iterating; actual10
   affected checks before freeze. Compare complete scripts through both APIs,
   separate compile. Batch full platform/stress/installed-package checks at the
   next coherent retained-source delivery; refresh external baseline when material.

| Candidate / hypothesis | Work to eliminate / affected scripts | Acceptance / displaced implementation |
| --- | --- | --- |
| Complete calls, frames and operand transport | Find actual duplicate preparation or transport in captured text/search and report. R241 already shares backing, context already is the frame, borrowed prefix already defers context creation. | Live defaults, receiver/descriptors/keywords/expansion, closures, protocol suspension/reentry, Python errors/order and funded aliases. Choose one existing representation, delete the displaced storage/dispatch stage; no revived measured-slower arenas/controllers or partial banks without a complete demonstrated convention. |
| Per-record/text construction | Current preparation/probing/value construction is real work; find removable rescanning/materialization/format transport in text/report/CSV. | Admission before first effects, Unicode expansion/sigma, formatting/protocol hooks, key order/header mutation, reentry and retained values. Remove actual scanner/conversion/backing, not a stage already absent. No new two-word vector or worst-case streaming allowance. |
| Scoped scalar/storage work | R245 removes container intermediates; establish remaining dominant allocation/CPU before generalizing. | Exact promotion, bool/int semantics, stable identity/aliases/projection/ownership. No universal tagged stack based solely on boxing. Name displaced representation and decide remaining regression debt. |
| Frontend consolidation | Compilation near CPython cannot explain captured warm gap. Merge only an actual repeated analysis. | Diagnostics/spans, annotations/generators/imports, cancellation and compilation ownership. Reuse facts, remove displaced traversal/tree; measure compile-to-result. No speculative heavyweight JIT. |

Source facts already checked: native nodes72B/instruction copy32B in actual Unix
code; shared frame/local backing already exists. Raw UTF8 read windows and CSV
caller-owned storage already avoid decoding; these text scripts have no strip().
Multipart formatting already writes primitives into one builder without field
strings; .NET11 grouped integers already use UTF8 TryFormat, .NET10 char bridge
intentional. Keyword-default PyString names prepared once per definition; no
per-call name conversion. Fixed binder buffer performs real binding; overwriting
caller operands before failed proof needs a new fallback/ownership convention.
Do not force a rewrite of an absent duplicate stage.

## Evidence and experimental decisions

Historical source pairs, adverse results, rejected designs and original failed
conditions live in [EXPERIMENTS](benchmarks/EXPERIMENTS.md), immutable results and
prior ignored plans under `.git/agent-notes/review-20261031/`. Keep docs current.
R247 native-loop stack-scope hoist and all R249 general return/iteration transport
forms are withdrawn; qualified baseline restored and regression coverage retained.
R244 known-call maps likewise withdrawn. No surviving production prototype.
Call arenas/controllers measured slower: retain those lessons, not permanent bans.

Initial R250 async-search/CSV adversity survives separately; B596 paired profile
and structural IL comparison do not identify a JIT cause. B597 combined source
does not reproduce it, without a recovery attribution. Original desktop CSV and
ordinaryAsync adversity also survives. No more unchanged B596 captures/retiming.

Bounded confirmation/refinement/measurement correction is allowed when justified.
Timeout, unstable unchanged controls and inconclusive observations establish
uncertainty, not failed design/permanent closure. Percentages inform decisions,
not automatic vetoes. Distinguish architectural simplification, physical allocation,
reserved allowance and demonstrated CPU. Size quiet runs for usable observations;
retain original failures and adverse data. Before publication explicitly resolve
or accept remaining material report/CSV/compile uncertainty at a coherent checkpoint.

## Independent regex track

Core Python/native-UTF8 contract, byte/scalar coordinates, original windows,
effective flags, current tokens, explicit owners and cache semantics delivered.
Optional nonpackable adapter0.4; immutable dev73 development qualification above
reuses the validated bridge and isolates pins/assets/outputs. No final pin promotion.

Only affected final adapter qualification awaits these exact producer capabilities:

- Independent single-match working/result owners.
- Native UTF8 group-name enumeration; native lookup already exists.
- Token-independent cursor creation with cancellable preparation; per-move
  cancellation alone does not prove interruption during preparation.

Four relevant producer API files remain byte-identical dev68→73. No additional
core plumbing/bridge rewrite justified. Adapter-local temporary conversions and
cursor cancellation bridge support independent development; remove displaced
conversions/DetailedData when real capabilities arrive. No publication polling.
Contract tests, semantic validation and actual backend CPU/safety/SizeOf are
separate claims. Missing published APIs never stop core work.

## Lasting contracts and delivery

Fully managed/safe: no unsafe/Unsafe/pointers/PInvoke/native probing. Preserve
managed stack admission, host capabilities, cancellation, cycle/XML-depth checks,
checked representation bounds and bounded I/O. No fuel/quotas/independent caps/
hidden allowance, tracing/root inventories/weak reclamation/forcedGC/retries or
abandoned users. Borrowed allowance funds capacity/overlap/results/aliases/caches/
pending borrows until awaited cleanup. First refusal fails command with original
structured origin despite suppression/finally return; guest MemoryError catchable.
Long streams use bounded host commands. Preserve LythonPathRequest/Cwd/component
resolution and old destination on refused copy.

Never relax assertions/timeouts. GC/deadline fixtures use existing nonparallel
collections. Restored-source builds must be nonincremental before no-build/freeze.
43119174279GREEN,43087005596GREEN,43081976930failed and older terminal CI are
cached: never requery. B576–B600terminal/cached; B600failed with11partial warm
jobs, archived recovery and no remaining VM users/RAM. Its fresh proof retired
all predecessor75a14core aliases and B599raw/catalog duplicates against committed
canonical archives. Those paths are off limits; c982reference and first prototype
images remain protected until the next proven selection.
New staging requires fresh lease/identity/disk/UID/inode/all-alias proof; never
reference retired duplicates. Selected reference is now fully qualified2ec9d; the predecessor8f862 core is
eligible only for explicitly proven all-alias retirement. Current2ec9d and prototype
cores stay protected. Verify committed canonical archives before
retiring duplicate evidence. No redundant full qualification. Publication held.
