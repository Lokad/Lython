from pathlib import Path
import hashlib,json,shutil

r=Path(__file__).resolve().parent;q=r/'refined';assert not q.exists();q.mkdir()
meta=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
for n,h in meta['sourceHashes'].items():assert hashlib.sha256(Path(n).read_bytes()).hexdigest()==h,n
shutil.copytree(r/'originals',q/'originals')
for role in ['before','candidate']:shutil.copytree(r/'images/before',q/'images'/role)
for name in ['before-net10.dll','catalog.json']:shutil.copyfile(r/name,q/name)
for phase in ['warm-sync','warm-async','compile']:
    (q/phase).mkdir();shutil.copyfile(r/phase/'hash-witness.json',q/phase/'hash-witness.json')
before=json.loads((r/'before.json').read_text(encoding='utf-8'))
before['hypothesis']='Refine linear native proof by removing per-node index/shape packing and runtime CopyInputs dispatch. Direct node operands populate local enum shapes; compiler-only postorder validation remains. Existing node array, evaluator, argument ABI, owners, conservative branch proof, current cancellation and first refusal unchanged.'
before['priorForm']='1d01c28e immutable first form, adverse partial B600. Both forms compare against fully qualified2ec9d67f/c9829194, not against the slower prototype. No isolated CPU claim yet.'
(q/'before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
for name in ['run-checkpoint.py','freeze-and-measure.py','summarize.py']:
    s=(r/name).read_text(encoding='utf-8').replace("r.parent/'iteration-returns-r225/", "r.parent.parent/'iteration-returns-r225/")
    (q/name).write_text(s,encoding='utf-8')
shutil.copyfile('PLAN.md',q/'PLAN-before-refinement.md')
print('Preserved first form; refined baseline remains exact fully qualified2ec9d67f.')
