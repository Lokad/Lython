using Lokad.Lython.Runtime;

namespace Lokad.Lython.Frontend;

// A closed native body prepares operation structure once. Ordinary code keeps
// its own physical operands and source spans; only eligible helpers own nodes.
// Inputs use the existing operand domains: negative constant indexes, the local
// prefix, then operation indexes offset by that prefix. Consumed local/constant
// leaves need no Read node; real roots and mutable name reads retain metadata.
internal enum NativeReturnOperation
{
    Read,
    Binary, Augmented,
    Subscript,
    BuiltinUnary,
    StringMethod, BytesMethod, BooleanMethod, ListMethod,
    Split, Replace, StartsWith, EndsWith,
    CasedSplit,
    ConvertFormat, FormatValue,
    Conditional, None, EmptySequence, StoreClosure,
}

internal readonly record struct NativeReturnValue(NativeReturnOperation Operation, ExecutableInstruction Instruction, int First, int Second,
    LythonRuntime.ReceiverMethod? Method = null, int Third = -1, LythonSourceSpan? ReturnSpan = null, LythonSourceSpan? MemberSpan = null)
{
    // Preparation validates the same postorder used by evaluation. Direct
    // constants/parameters consume no proof result; operation nodes do.
    internal int CopyInputs(Span<int> inputs, IReadOnlyList<ExecutableCallSite> sites)
    {
        if (Operation is NativeReturnOperation.Read or NativeReturnOperation.None or NativeReturnOperation.EmptySequence)
            return 0;
        inputs[0] = First;
        if (Operation == NativeReturnOperation.Conditional)
        { inputs[1] = Second; inputs[2] = Third; return 3; }
        if (Operation is NativeReturnOperation.Binary or NativeReturnOperation.Augmented
            or NativeReturnOperation.Subscript or NativeReturnOperation.StoreClosure)
        { inputs[1] = Second; return 2; }
        if (Operation is NativeReturnOperation.BuiltinUnary or NativeReturnOperation.Split
            or NativeReturnOperation.Replace or NativeReturnOperation.StartsWith or NativeReturnOperation.EndsWith)
        {
            var site = sites[Instruction.CallSiteIndex];
            for (var i = 0; i < site.ArgumentCount; i++) inputs[i + 1] = site.NativeArgumentSource(i);
            return site.ArgumentCount + 1;
        }
        return 1;
    }
}

internal sealed record ExecutableNativeBody(NativeReturnValue[] Values, int Root, int ClosureInputCount = 0,
    int GuardStackCapacity = 0)
{
    internal const int MaximumDepth = 16;
    internal static readonly ExecutableNativeBody ReturnNone = new([], -1);
}
