from pathlib import Path
import hashlib,json,os,re,subprocess

r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython')
before=json.loads((r/'before.json').read_text(encoding='utf-8'))
for n,h in before['sourceHashes'].items():assert hashlib.sha256((repo/n).read_bytes()).hexdigest()==h,n
for name in ['restored-internal-build.log','restored-public-build.log']:
    assert 'Build succeeded.'in(r/name).read_text(encoding='utf-8')
dotnet='C:/Users/JoannesVermorel/.dotnet11/dotnet.exe';env=os.environ.copy();env['DOTNET_ROOT']=str(Path(dotnet).parent);env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH']
checks={}
for tfm in ['net11.0','net10.0']:
    for project,selection in [('Lokad.Lython.Tests','Category!=Stress&(FullyQualifiedName~NativeClosureSequence|FullyQualifiedName~NativeReturn|FullyQualifiedName~DictionaryCountingLoopAdmission)'),('Lokad.Lython.PublicApi.Tests','Category!=Stress&(FullyQualifiedName~NativeReturnFunction|FullyQualifiedName~NativeConditionalHelper|FullyQualifiedName~NativeClosureLifetime|FullyQualifiedName~FormattedHelperReturn|FullyQualifiedName~CooperativeCancellation)')]:
        label='restored-'+project+'-'+tfm;log=r/(label+'.log');assert not log.exists()
        with log.open('w',encoding='utf-8')as f:p=subprocess.run([dotnet,'test','tests/'+project,'-c','Release','-f',tfm,'--no-build','--no-restore','--filter',selection,'--logger','trx;LogFileName='+label+'.trx','--results-directory',str(r/'restored-tests')],cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
        text=log.read_text(encoding='utf-8');assert p.returncode==0,(label,text[-6000:])
        count=int(re.search(r'Passed:\s+(\d+)',text)[1]);checks[label]=count;print(label,count,'pass',flush=True)
for n,h in before['sourceHashes'].items():assert hashlib.sha256((repo/n).read_bytes()).hexdigest()==h,n
(r/'restoration-checks.json').write_text(json.dumps({'exactQualifiedSource':'2ec9d67f','sourceFiles':len(before['sourceHashes']),'freshNonincrementalBuilds':True,'checks':checks,'fullyQualifiedDeliveryReused':'43119174279 terminalGREEN Windows/Ubuntu actual11/10 originalstress and installedconsumers; no repeat of unchanged production'},indent=2)+'\n',encoding='utf-8')
