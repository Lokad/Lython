import json
import subprocess
import sys
from pathlib import Path

lab = Path(__file__).resolve().parent
previous = lab.parent / 'retained-annotations-r700'
cases = json.loads((lab.parent / 'postfix-statement-r699/catalog.json').read_text(encoding='utf-8-sig'))
rules = json.loads((previous / 'catalog.json').read_text(encoding='utf-8-sig'))
case, = (row for row in rules['cases'] if row['id'] == 'scripts.rule-default-closures')
cases['cases'].append(case)
assert [case['id'] for case in cases['cases']] == [
    'scripts.config-generated-guards.medium', 'scripts.config-manifest.small',
    'scripts.csv-invoice.large', 'scripts.rule-default-closures',
]
assert cases['catalogVersion'] == rules['catalogVersion'] == 1
(lab / 'catalog.json').write_text(json.dumps(cases, indent=2, ensure_ascii=False) + '\n',
                                  encoding='utf-8', newline='\n')

script = (previous / 'freeze-and-verify.py').read_text(encoding='utf-8')
script = script.replace('retained-annotations-r700', 'opened-file-acquisition-r702')
script = script.replace("git('rev-parse','a472eb2a4')", "git('rev-parse','e7cb313d1')")
script = script.replace('if name==core and role=="candidate":\n            origin=lab/role/',
                        'if name==core:\n            origin=lab/role/')
assert 'if name==core:' in script
destination = lab / 'freeze-and-verify.py'
destination.write_text(script, encoding='utf-8', newline='\n')
subprocess.run([sys.executable, '-X', 'utf8', destination], check=True)
