import json
import subprocess
import sys
from pathlib import Path

lab = Path(__file__).resolve().parent
prior = lab.parent / 'retained-annotations-r700'
stage = (prior / 'stage-quiet.py').read_text(encoding='utf-8')
stage = stage.replace('retained-annotations-b1131', 'opened-file-acquisition-b1133')
stage = stage.replace('lython-b1131-retained-annotations', 'lython-b1133-opened-file-acquisition')
stage = stage.replace('lython-b1131-fixtures', 'lython-b1133-fixtures')
stage = stage.replace('R700 funded annotation values with dictionary publication on observation',
                      'R702 completed file acquisition without a forwarding await')
stage = stage.replace('Retained annotation values source pair', 'Opened file acquisition source pair')
stage = stage.replace('    if role == "candidate":\n        shutil.copyfile', '    shutil.copyfile')
stage = stage.replace('         "candidate/" + core]', '         "reference/" + core, "candidate/" + core]')
stage = stage.replace('assert source_files[core] == images["reference"][core]',
                      'assert sha(quiet / "reference" / core) == images["reference"][core]')
start = stage.index('        jobs = [')
end = stage.index('\n', start)
catalog = json.loads((lab / 'catalog.json').read_text(encoding='utf-8'))
jobs = [(case['id'], 'warm') for case in catalog['cases']]
stage = stage[:start] + '        jobs = ' + repr(jobs) + stage[end:]
assert '"reference/" + core, "candidate/" + core' in stage
assert 'lython-b1133-opened-file-acquisition' in stage
assert 'assert sha(quiet / "reference" / core)' in stage

proof = (prior / 'prove-quiet-space.py').read_text(encoding='utf-8')
start = proof.index('pairs = ')
end = proof.index('\n', start)
pairs = [('retained-annotations-r700/quiet', '2026-11-19-retained-annotation-values', 'candidate', 'measured-core.dll.gz'),
         ('borrowed-lexical-child-lean-r683/quiet', '2026-11-19-borrowed-return-transport', 'candidate', 'measured-core.dll.gz')]
proof = proof[:start] + 'pairs = ' + repr(pairs) + proof[end:]
for name, contents in [('prove-quiet-space.py', proof), ('stage-quiet.py', stage)]:
    (lab / name).write_text(contents, encoding='utf-8', newline='\n')
    subprocess.run([sys.executable, '-X', 'utf8', lab / name], check=True)
