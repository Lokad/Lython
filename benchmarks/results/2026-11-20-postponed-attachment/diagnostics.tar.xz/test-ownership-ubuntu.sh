set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=$1
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$lab/linux" --no-build --filter '(FullyQualifiedName~CompilerCancellation|FullyQualifiedName~GovernedMemoryContractTests)&Category!=Stress' > "$lab/ownership-ubuntu.log" 2>&1
tail -n 6 "$lab/ownership-ubuntu.log"
