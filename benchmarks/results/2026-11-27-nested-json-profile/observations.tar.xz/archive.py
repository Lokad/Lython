from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import json
import tarfile


root = Path(__file__).resolve().parent
repo = root.parents[5]
out = repo / 'benchmarks/results/2026-11-27-nested-json-profile'
out.mkdir(exist_ok=True)
roles = ('document-sync', 'document-async', 'lines-async')
summary = json.loads((root / 'run-summary.json').read_bytes())
identity = json.loads((root / 'identity.json').read_bytes())
assert summary['allProcessesJoined'] and summary['sourceRevision'] == identity['sourceRevision']
assert summary['catalogSha'] == identity['catalogs']['representative.json']['sha256']
for name in ('attribution.json', 'identity.json', 'run-summary.json'):
    copyfile(root / name, out / name)
files = [root / name for name in ('analyze.py', 'archive.py', 'collect.py', 'collection.log', 'run.sh')]
verified_batches = 0
for role in roles:
    slot = json.loads((root / role / 'record.json').read_bytes())
    assert slot['allProcessesJoined'] and slot['batches']
    assert slot['coreSha'] == identity['imageFiles']['candidate']['Lokad.Lython.dll']
    assert slot['nettraceSha'] == sha256((root / role / 'run.nettrace').read_bytes()).hexdigest()
    verified_batches += len(slot['batches'])
    files.extend(root / role / name for name in
                 ('capture.log', 'record.json', 'run.nettrace', 'run.speedscope.json', 'worker.stderr'))
assert verified_batches == summary['totalVerifiedBatches']
archive = out / 'observations.tar.xz'
with tarfile.open(archive, 'w:xz') as bundle:
    for path in files:
        bundle.add(path, arcname=path.relative_to(root))
with tarfile.open(archive) as bundle:
    assert all(bundle.extractfile(path.relative_to(root).as_posix()).read() == path.read_bytes() for path in files)
(out / 'archive-receipt.json').write_text(json.dumps(dict(
    archiveSHA256=sha256(archive.read_bytes()).hexdigest(),
    archivedAndVerified=True, fileCount=len(files)), indent=2) + '\n', encoding='utf-8', newline='\n')
