#!/bin/bash
set -euo pipefail
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
export DOTNET_ROOT="$HOME/.dotnet"
flock -n "$root/../../../comparison-vm.lock" timeout --signal=TERM 128s taskset -c 27 python3 "$root/collect.py"
