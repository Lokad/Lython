from collections import Counter
from pathlib import Path
import json


ROOT = Path(__file__).resolve().parent
WAIT = ('WaitSubsystem+ThreadWaitInfo.Wait', 'LowLevelThreadBlocker.TimedWait', 'PollGCWorker',
        'SynchronousWorkItem.Wait')
REGIONS = {
    'JSON construction': ('ContinueJsonConstruction', 'ReadJsonContainerAsync'),
    'record creation': ('PushJsonContainer', 'RecordKeys.CreateRecord', 'PyDict..ctor'),
    'key lookup': ('ReadJsonObjectKey', 'MatchDelimitedName', 'RecordKeys.FindName'),
    'string decode': ('ReadJsonString', 'WriteEscapedJsonString'),
    'UTF-8 copying or borrowing': ('PyString.CopyOrBorrowUtf8Range', 'PyString.CopyFromUtf8'),
    'scalar decode': ('TryReadJsonScalar', 'TryMatchJsonNumber', 'ConvertJsonNumber'),
    'JSON output': ('JsonEncodeIterator', 'EmitTraversal'),
    'text file handling': ('TextFileHandle', 'ChunkedTextFileReadState'),
    'subscript': ('TryReadRecordValue', 'EvaluateSubscript', 'ExecuteGetItem'),
    'reservation': ('MemoryGovernor.Reserve',),
}


def analyze(role):
    raw = json.loads((ROOT / role / 'run.speedscope.json').read_bytes())
    frames = [item['name'].split('(', 1)[0].split('!', 1)[-1] for item in raw['shared']['frames']]
    total = 0.0
    nearest = Counter()
    inclusive = Counter()
    reserved_by = Counter()
    for profile in raw['profiles']:
        assert profile['unit'] == 'milliseconds' and profile['type'] == 'evented'
        stack = []
        previous = profile['startValue']
        for event in profile['events']:
            elapsed = event['at'] - previous
            active = [frame for frame in stack if frame.startswith('Lokad.Lython.Runtime.')]
            if elapsed > 0 and active and not any(mark in frame for frame in stack for mark in WAIT):
                total += elapsed
                nearest[active[-1]] += elapsed
                for name, markers in REGIONS.items():
                    if any(mark in frame for frame in active for mark in markers):
                        inclusive[name] += elapsed
                reserve = next((index for index, frame in enumerate(active) if 'MemoryGovernor.Reserve' in frame), None)
                if reserve:
                    reserved_by[active[reserve - 1]] += elapsed
            if event['type'] == 'O':
                stack.append(frames[event['frame']])
            else:
                assert stack.pop() == frames[event['frame']]
            previous = event['at']
        assert not stack
    return dict(role=role, activeRuntimeThreadMilliseconds=total, inclusiveMilliseconds=inclusive,
                nearestMethods=nearest.most_common(45), reserveCallers=reserved_by.most_common(25))


identity = json.loads((ROOT / 'identity.json').read_bytes())
rows = [analyze(role) for role, _, _ in identity['profiles']]
(ROOT / 'attribution.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8', newline='\n')
for row in rows:
    total = row['activeRuntimeThreadMilliseconds']
    print(row['role'], round(total))
    for name, elapsed in sorted(row['inclusiveMilliseconds'].items(), key=lambda item: -item[1]):
        print(f'  {100 * elapsed / total:.1f}% {name}')
    for key in ('nearestMethods', 'reserveCallers'):
        for name, elapsed in row[key][:10]:
            print(f'  {100 * elapsed / total:.1f}% {name}')
