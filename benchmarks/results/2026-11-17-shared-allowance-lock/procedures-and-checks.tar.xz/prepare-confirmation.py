from pathlib import Path
import ast,json,tarfile
r=Path(__file__).parent;old=r/'quiet';parent=r/'confirm';parent.mkdir(exist_ok=False);q=parent/'quiet';q.mkdir()
prior=json.loads((old/'config.json').read_text(encoding='utf-8'));receipt=json.loads((old/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['jobs']==5 and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']
remote='/home/lokad/lython-bench-checks/allowance-lock-confirm-b907-20261117'
identity=dict(prior['identity']);identity['purpose']='One bounded unchanged-image JSON warm confirmation plus positional-call control. First candidate JSONprocesses differ7.84% with tight internal samples; preserve all adverse observations. Same four-case catalog,6secondwarmups/5rounds and actual32file images. No source change or promotion.'
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a);jobs=[['scripts.json-summary-helpers.large','warm'],['calls.positional.large','warm']]
s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==2 and all(case in cases for case,lane in jobs)\n'+s[b:];s=s.replace("< 210, 'Reserve60seconds","< 100, 'Reserve60seconds");(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==5","len(raw['jobs'])==2").replace('jobs=5','jobs=2');(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace(prior['root'],remote),encoding='utf-8',newline='\n')
names=['identity.json','collect.py','archive-owned.py','run.sh']
with tarfile.open(q/'payload.tgz','w:gz')as archive:
 for name in names:archive.add(q/name,arcname=name)
import hashlib
c=dict(root=remote,unit='lython-b907-allowance-lock-confirm-20261117',source=prior['root'],sourceRole='reference',sourceFiles=identity['imageFiles']['reference'],sourceCatalogSHA256=prior['catalogSHA256'],catalogSHA256=prior['catalogSHA256'],identity=identity,retireGroups=[],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/name).stat().st_size for name in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
needle=" for n,h in c['sourceFiles'].items():assert sha(source/c['sourceRole']/n)==h,n";assert needle in s
s=s.replace(needle," for role,files in c['identity']['imageFiles'].items():\n  for n,h in files.items():assert sha(source/role/n)==h,(role,n)")
needle="if not p.exists():os.link(source/c['sourceRole']/n,p)";assert needle in s;s=s.replace(needle,"if not p.exists():os.link(source/role/n,p)")
needle=" # New payload catalog was verified with both actual images.";assert needle in s;s=s.replace(needle," os.link(source/'representative.json',root/'representative.json')\n # Same verified four-case catalog and32-file images; no binary payload.")
s=s.replace('lython-b906-fixtures','lython-b907-fixtures').replace('RuntimeMaxSec=300','RuntimeMaxSec=180');(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'launch.py').read_text(encoding='utf-8').replace('seconds=230','seconds=110').replace('before230seconds','before110seconds').replace('Five-job typed-lock comparison','Two-job unchanged-image confirmation');(parent/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'retrieve.py').read_text(encoding='utf-8').replace("['jobs']==5","['jobs']==2").replace('B906','B907');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==5","len(raw['jobs'])==2").replace("r/'reference-allocation.json'","r.parent/'reference-allocation.json'").replace("r/'candidate-allocation.json'","r.parent/'candidate-allocation.json'")
(parent/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+list(parent.glob('*.py')):ast.parse(p.read_text(encoding='utf-8'))
print('Bounded unchanged-image confirmation prepared; both roles/catalog hardlink verified originals. No retirement, source change or new qualification.')
