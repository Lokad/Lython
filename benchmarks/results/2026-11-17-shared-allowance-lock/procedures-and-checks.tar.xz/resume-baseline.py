from pathlib import Path
import json,subprocess
r=Path(__file__).parent;work=Path('D:/code/Lython/.git/agent-worktrees/shared-allowance-lock-r488');name='src/Lokad.Lython/Public/LythonMemoryBudget.cs';file=work/name
original=subprocess.check_output(['git','show','HEAD:'+name],cwd=work).decode('utf-8').replace('\r\n','\n')
assert file.read_text(encoding='utf-8')==original
assert not subprocess.check_output(['git','diff','--',name],cwd=work).strip()
# Restore canonical checkout line endings after proving no source change remains.
subprocess.run(['git','restore','--worktree','--source=HEAD','--',name],cwd=work,check=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=work,text=True).strip()
subprocess.run(['git','switch','--detach','add2c00a'],cwd=work,check=True)
current=file.read_text(encoding='utf-8');assert current.count('internal readonly object Gate = new();')==1
file.write_text(current.replace('internal readonly object Gate = new();','internal readonly System.Threading.Lock Gate = new();'),encoding='utf-8',newline='\n')
(r/'candidate-source.json').write_text(json.dumps(dict(base='add2c00a',change='One private allowance gate type: System.Threading.Lock; no accounting/lifetime changes',timingHeldUntilBaselineQualification=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Isolated prototype rebased onadd2; original logs preserved. Force nonincremental build/check next.')
