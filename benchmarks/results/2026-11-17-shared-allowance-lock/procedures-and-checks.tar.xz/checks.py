from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).parent;work=Path('D:/code/Lython/.git/agent-worktrees/shared-allowance-lock-r488')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
commands=[('build',[str(dotnet),'build','Lokad.Lython.slnx','-c','Release','--no-incremental'])]
for framework in ['net11.0','net10.0']:
 for name,project,classes in [('internal','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj',['MemoryGovernorInvariantTests','MemoryGovernorDenialAccountingTests','ReentrantAdmissionOwnershipTests','TemporaryReservationOwnershipTests','BatchedSharedAdmissionTests','CallablePacketOwnershipTests','BoundMethodInvocationBoundaryTests']),('public','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj',['GovernedMemoryContractTests','AdmissionFailureCommandTests','MemoryOwnershipTests','AsyncInvocationOwnershipTests','SharedBudgetIntegrationTests','RepresentativeProtocolCancellationTests'])]:
  filt='('+'|'.join('FullyQualifiedName~'+c for c in classes)+')&Category!=Stress'
  commands.append((name+'-'+framework,[str(dotnet),'test',project,'-c','Release','-f',framework,'--no-build','--filter',filt,'--logger','console;verbosity=minimal']))
records=[]
for name,command in commands:
 start=time.monotonic()
 with(r/(name+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run(command,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT)
 record=dict(name=name,command=command,exitCode=p.returncode,seconds=time.monotonic()-start);records.append(record)
 (r/'checks.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n')
 output=(r/(name+'.log')).read_text(encoding='utf-8');print(name,output.splitlines()[-1],flush=True);assert p.returncode==0,output[-6500:]
