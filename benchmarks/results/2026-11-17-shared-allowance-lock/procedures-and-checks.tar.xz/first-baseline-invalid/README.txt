First focused typed-lock prototype on00adcc8a. Separate packet baseline later failed full CI; these are not corrected-baseline qualifications. Keep original logs.
