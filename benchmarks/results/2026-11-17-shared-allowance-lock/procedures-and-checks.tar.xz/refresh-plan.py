from pathlib import Path
Path('D:/code/Lython/PLAN.md').write_text('''# Lokad.Lython 0.11.0

Updated 2026-11-17 UTC. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including compile-once/run-once inside a warm host. Another isolated experiment
does not finish the objective. Current contracts: docs/. History: benchmarks/EXPERIMENTS.md.

## Actual delivery status

| State | Milestone and measurement limits |
| --- | --- |
| Committed / fully qualified | Shared compiler-fact/callback correction61237f58; native helper returns8f07764a. Allocation−19–20%; original elapsed improvements remain diagnostic. No unchanged qualification outstanding. |
| Committed / fully qualified | Direct UTF-8 formatting/storage: allocation−8.67%; controlled report elapsed/CPU5–8%lower supports retention. No further correction selected; original adverse15.125ms remains preserved/unexplained. New evidence can reopen the decision. |
| Completed / evidence retained | Prepared calls/direct operands, executable generators, shared builtin metadata/reused async workers, UTF-8 backing/casing, sequence constructionR460, receiver pipelineccf20ba3, floating transportdc480d38, generator-sum lifetimeabcbd9fd, unary result transportd8611c85, bulk UTF-8 widthsdbdf8262. Details and qualified sources in history. |
| Latest fully qualified runtime | R489/add2c00a/frozendfc4c83c. GREEN44103214418: Windows/Ubuntu actual11/10 each4830internal/18013public ordinary,14/406originalstress, installed Release consumers.16summaries/2382inputs/585production verified; terminal/logs cached. Later8454833a is measurement evidence only. |
| Active private prototype | R488 changes only the default allowance gate to System.Threading.Lock onadd2. Actual11/10each52internal/76public; four actual frozen goldens and owner-reuse diagnostics pass. Allocation/accounted peaks identical. B906first191.31s is inconclusive; bounded unchanged-image JSON/control confirmation running. No promotion. |
| Independent regex | Core Python/native UTF-8 contract delivered; immutabledev105 focused qualification complete. Normal optional/non-packable adapter0.4.0. Missing producer capabilities postpone only affected final adapter qualification. |

[Current full delivery](benchmarks/results/2026-11-17-call-packet-lifetimes/delivery/README.md).
The f2cb4008 cleared-prefix and00adcc8a universal-retention attempts failed and are
superseded; [both failures and final correction](benchmarks/results/2026-11-17-call-packet-lifetimes/README.md)
preserve original sources/logs/adversity. R469/R470/R473/R474/R479/R481/R485
prototypes were withdrawn; no dormant alternatives remain in production.

## Now: decide R488, then continue the substantial roadmap

R484's986samples/60unknown include66Monitor enter/exit leaves,57 under Reserve.
This identifies a real default-allowance synchronization cost, not a predicted
speedup. Replace compiler Monitor entry/exit with managed scoped locking only;
no accounting policy/cache/credit layer. Preserve shared executions, concurrency,
reentry, exact admission/refunds, owner cleanup, cancellation and terminal refusal.

First controlled pair: JSONwarm−3.35..+5.38%,candidate processes differ7.84% with
tight internal samples. FreshJSON−0.27..+1.78%; CSV/text nearflat; call control
−1.52..−0.40%. Allocation/peaks exactlyflat. Keep every adverse observation.
B907 confirmation repeats only JSONwarm/control with the same32file images,
four-case catalog,6swarmup/5rounds. One bounded confirmation is justified by the
process discrepancy; decide retain/withdraw/named remaining uncertainty afterward.
No fixed-percentage veto or promotion by API fashion. No further unchanged broad
campaign. New evidence or a different design can justify later work.

After that decision, refresh affected complete JSON-lines versus stockCPython3.13.16
at the coherent checkpoint: separate compile/warm/fresh; identify source/version/
date/machine and mediated I/O, goldens and prior-result cleanup. Use existing workers,
not a new framework. Phase medians are not additive; startup remains unmeasured.

## Next substantial redesign deliverables

| Milestone / scripts | Hypothesis, displaced work and acceptance |
| --- | --- |
| R490 numerical JSON attribution → coherent numeric/collection redesign | Floating JSON remains≈2×CPython at its named checkpoint. Reuse relevant existing evidence first; if insufficient, one5second existing-workload capture distinguishes parsing, construction, arithmetic/operand transport and admission. Stop with a selected complete stage to remove or a named uncertainty; no broad audit/capture campaign. Name displaced implementation and controlled whole-script pair before coding. Preserve exact floats/integers/Unicode, hooks, aliases, first refusal and joined cancellation. |
| Complete call/frame/operand transport: helper-heavy search/reports | Common helpers already borrow/defer frames and fused locals carry slots. R485 still built entries per read and widened ABI without substantial benefit. Remove a whole remaining binding/transport stage, including displaced code; preserve defaults/keywords/cells/identity/effect/error order and genuine suspension without replay. Name scripts/control and bounded comparison before prototype; no renamed arenas/controllers/windows. |
| Per-record construction: CSV/JSON aggregates/manifests | Earlier6–8%CSV work is integrated as aggregate admission/shared keys/final rows; R482 confirms funded-row adoption. JSON shares cross-load layouts/default options and uses iterative construction. Revised storage must displace real construction without duplicate caches. Preserve duplicate/short/wide rows, callbacks, retained aliases, replacement overlap and terminal refusal. |
| Scalar/text publication: normalization/numeric reports | R483 removes width walking; R471/R477 remove boxing boundaries. Mutable slots need canonical aliases through withdrawal/mutation and displace direct-array adoption; immutable tuple borrowing is insufficient. Name actual conversions/storage removed and preserve Unicode/arithmetic/hooks/ownership. No universal tagged-value or identity ledger from allocation estimates alone. |
| Frontend/setup: generated configuration/helper scripts | Facts/prepared metadata are already shared; compilation is not the dominant measured gap. Prove repeated analysis/retention, remove displaced passes/representation and preserve spans/classes/cells/lazy annotations plus admitted/cancellable compile-to-result. Heavyweight JIT remains lower confidence. |

Source corrections prevent duplicate designs: spans are shared references;
ExecutableSlot already holds one managed reference +one long for integer/double
bits/immutable tuple offset. Ordinary JSON integers/floats already use container/
execution headroom with no per-number reservation; only large values/hooks need
extra storage. Text reads already share immutable UTF-8 windows. Structural guard
context is ThreadStatic and throttled. R484's nearest instruction-prefix147 has
zero visible helper activations; helper activation inclusive52 is not an exclusive
construction share. R469bulk scanning regressed JSONfresh; R456managed native
blocks increased compilation≈33×/numericwarm5–8%. Preserve these lessons.

Every redesign records hypothesis, complete scripts, work/storage eliminated,
semantic/cancellation/ownership acceptance, bounded before/after controls and a
retention/regression-debt decision. Temporary setbacks need an explicit completion
milestone. No isolated experiment closes the performance objective.

## Measurement uncertainty and experimental policy

CPython is primary; named source never automatically means HEAD. R483text:
warm1.75–1.81×,fresh1.66–1.67×,compile0.94–0.96× (CPythoncontrols3.40%). R477CSV:
warm0.89–0.92×,fresh0.92–0.95×,compile1.25–1.27×. R475floatingJSON: warm1.95–2.00×,
fresh1.83–1.88×. [Guide/boundaries](docs/BENCHMARKS.md) and [history](benchmarks/EXPERIMENTS.md)
retain original measurements, R471integer/R460tuple-peak/asyncCSV debts and withdrawn
prototype regressions. R489's small adverse/uncertain JSON/fresh observations stay
explicit; its required retained-prefix charge is not a CPU gain.

Timeouts, unstable controls and inconclusive observations mean uncertainty, not
failed designs. Allow bounded justified confirmation/refinement/measurement repair;
preserve original failed/adverse conditions. Distinguish architecture, allocation
and demonstrated CPU improvements. Percentages inform decisions, never automatically
veto useful coherent changes. Do not repeat unchanged qualification.

## Independent regex track

Continue the core-owned Python UTF-8 contract: original-subject byte/scalar windows,
flags/names/captures/effective frontend analysis, explicit owners and current tokens
through actual provider/import/helper work. No core backend types or dialect fallback.
Development producers/adapter bridges support development; distinguish contract
tests, semantic validation and actual backend performance.

Read-only sibling0bd59e18 retires backend shortcuts/overlays, not missing facade
capabilities: UTF-8 group-name enumeration; creation/preparation token lifetime
independent of retained cursors; separately funded per-match staging. Keep detached
later-pull bridge; effective flags do not replace initial Verbose parsing. No pin
change/unchanged requalification for unrelated source changes. Qualify a changed
immutable final package for semantics/windows/errors/flags, in-flight interruption/
unwind, aliases/reuse/dependencies and one affected pair. Only that affected final
adapter qualification waits on publication.

## Delivery and lasting constraints

Focused Release regressions during development; batch full Windows/Ubuntu actual
11/10, original stress and installed explicit Release consumers at meaningful
retained boundaries. Cache terminal/logs; live CI observations≥240s apart. Never
requery terminal44103214418,44080812207,44050323147,44041981387,44022750002,
44072440304 or failed44067803913/44091209377/44098253722.

[AGENTS](AGENTS.md)/[RUNTIME](docs/RUNTIME.md): fully managed/memory-safe; no unsafe,
Unsafe APIs, pointers, PInvoke or native probing. Preserve managed stack admission,
host capabilities, cancellation, borrowed shared admission, replacement overlap,
retained aliases/caches/pending users and awaited cleanup. First refusal terminal.
No fuel/quotas/hidden caps/allowances/tracing/weak reclamation/forced GC/abandoned
work. Bounded host-driven streaming remains. Ordinary caller scratch clears/refunds;
fresh major bound prefixes retain their execution/result owner; minor headroom stays.

Freeze complete copied images after nonincremental builds; verify actual catalog
workers before staging. Join/SHA-archive RAM before unmount. Retire only exact
committed replicas with fresh lease/path/UID/hash/link/all-alias proof; preserve
qualified images/toolchains/canonicals and254/252MiB floors. VM:lokad@20.166.121.73,
~/.ssh/id_lython-bench.pem. Only core Release packages via pack.ps1→artifacts/nuget/;
adapter non-packable. Publication/tagging held.
''',encoding='utf-8',newline='\n')
