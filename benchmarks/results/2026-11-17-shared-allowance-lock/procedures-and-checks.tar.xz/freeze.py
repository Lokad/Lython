from pathlib import Path
import copy,gzip,hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;notes=r.parent;root=Path('D:/code/Lython');work=root/'.git/agent-worktrees/shared-allowance-lock-r488';reference=notes/'copied-call-lifetimes-r489';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip().startswith('add2c00a')
status=subprocess.check_output(['git','status','--porcelain'],cwd=work,text=True).strip();assert status=='M src/Lokad.Lython/Public/LythonMemoryBudget.cs',status
catalog=json.loads((reference/'catalog.json').read_text(encoding='utf-8'));available={c['id']:c for c in catalog['cases']}
for path in [notes/'unary-slot-results-r477/catalog.json',notes/'utf8-width-r483/refined/catalog.json',notes/'borrowed-binding-r485/catalog.json']:
 for c in json.loads(path.read_text(encoding='utf-8'))['cases']:available[c['id']]=c
selected=['scripts.json-summary-helpers.large','scripts.csv-numeric-quality.large','scripts.text-normalization.large','calls.positional.large']
catalog['cases']=[copy.deepcopy(available[name])for name in selected];(r/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8',newline='\n')
prior=json.loads((reference/'frozen/identity.json').read_text(encoding='utf-8'));files=prior['imageFiles']['candidate'];frozen=r/'frozen';frozen.mkdir(exist_ok=False)
for role in ['reference','candidate']:
 image=frozen/role;image.mkdir()
 for name,h in files.items():assert sha(reference/'frozen/candidate'/name)==h;shutil.copyfile(reference/'frozen/candidate'/name,image/name)
 for p in(reference/'frozen/candidate').glob('ValidatedAllocation.*'):shutil.copyfile(p,image/p.name)
 if role=='candidate':shutil.copyfile(work/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',image/'Lokad.Lython.dll')
images={role:{name:sha(frozen/role/name)for name in files}for role in ['reference','candidate']};assert[n for n in files if images['reference'][n]!=images['candidate'][n]]==['Lokad.Lython.dll']
inputs={name:sha(work/name)for name in prior['sourceInputs']};assert len(inputs)==2382
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as archive:
 for name in inputs:archive.add(work/name,arcname=name)
with tarfile.open(reference/'candidate-sources.tar.xz')as archive:
 changed=[name for name in inputs if name.startswith('src/Lokad.Lython/')and(work/name).read_text(encoding='utf-8-sig')!=archive.extractfile(name).read().decode('utf-8-sig').replace('\r\n','\n')]
assert changed==['src/Lokad.Lython/Public/LythonMemoryBudget.cs'],changed
patch=subprocess.check_output(['git','diff','--',changed[0]],cwd=work);(r/'prototype.patch.gz').write_bytes(gzip.compress(patch,mtime=0))
identity=dict(referenceSource='Committedadd2c00a/frozendfc4c83c; final44103214418 qualification pending at preparation',candidateSource='PrivateR488 one gate type onadd2c00a; unchanged exact accounting/lifetimes; no prototype promotion',imageFiles=images,sourceInputs=inputs,productionFiles=585,changedProductionFiles=changed,catalogSHA256=sha(r/'catalog.json'),normalAdapterPin='0.4.0',publicationHeld=True)
(frozen/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
for role in ['reference','candidate']:
 image=frozen/role
 for label,command in [('preflight',[str(dotnet),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'catalog.json'),'--dotnet',str(dotnet),'--python','C:/Python313/python.exe','--python-worker',str(root/'benchmarks/cpython-worker.py'),'--out',str(r/(role+'-preflight.json'))]),('allocation',[str(dotnet),str(image/'ValidatedAllocation.dll'),str(image),str(r/'catalog.json'),str(r/(role+'-allocation.json'))])]:
  with(r/(role+'-'+label+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
  assert p.returncode==0,(r/(role+'-'+label+'.log')).read_text(encoding='utf-8');print(role,label,'pass',flush=True)
print('One-file typed-lock prototype frozen with complete32file images/585production/2382inputs; candidate',images['candidate']['Lokad.Lython.dll'],flush=True)
