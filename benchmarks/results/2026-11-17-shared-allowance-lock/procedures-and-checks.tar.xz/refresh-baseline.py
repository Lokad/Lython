from pathlib import Path
import json,shutil,subprocess
r=Path(__file__).parent;work=Path('D:/code/Lython/.git/agent-worktrees/shared-allowance-lock-r488')
name='src/Lokad.Lython/Public/LythonMemoryBudget.cs';file=work/name
assert subprocess.check_output(['git','status','--porcelain'],cwd=work,text=True).strip()=='M '+name
original=subprocess.check_output(['git','show','HEAD:'+name],cwd=work).decode('utf-8')
assert file.read_text(encoding='utf-8')==original.replace('internal readonly object Gate = new();','internal readonly System.Threading.Lock Gate = new();')
dest=r/'first-baseline-invalid';dest.mkdir(exist_ok=False)
for name0 in ['checks.json','build.log','internal-net11.0.log','internal-net10.0.log','public-net11.0.log','public-net10.0.log']:shutil.copyfile(r/name0,dest/name0)
(dest/'README.txt').write_text('First focused typed-lock prototype on00adcc8a. Separate packet baseline later failed full CI; these are not corrected-baseline qualifications. Keep original logs.\n',encoding='utf-8')
file.write_text(original,encoding='utf-8',newline='\n')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=work,text=True).strip()
subprocess.run(['git','switch','--detach','add2c00a'],cwd=work,check=True)
current=file.read_text(encoding='utf-8');assert current.count('internal readonly object Gate = new();')==1
file.write_text(current.replace('internal readonly object Gate = new();','internal readonly System.Threading.Lock Gate = new();'),encoding='utf-8',newline='\n')
(r/'candidate-source.json').write_text(json.dumps(dict(base='add2c00a',change='One private allowance gate type: System.Threading.Lock; no accounting/lifetime changes',timingHeldUntilBaselineQualification=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Isolated typed-lock prototype moved onto correctedadd2; old invalid-baseline logs preserved. Force nonincremental build next.')
