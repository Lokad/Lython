from pathlib import Path
import ast,gzip,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).parent;root=Path('D:/code/Lython');old=r.parent/'copied-call-lifetimes-r489'
qualification=json.loads((old/'delivery/qualification.json').read_text(encoding='utf-8'))
assert qualification['run']==44103214418 and qualification['conclusion']=='success'and qualification['allMeaningfulStepsPassed']
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));prior=json.loads((old/'quiet/config.json').read_text(encoding='utf-8'))
core_canonical='benchmarks/results/2026-11-17-call-packet-lifetimes/reference-core.dll.gz'
core_blob=subprocess.check_output(['git','show','HEAD:'+core_canonical],cwd=root);assert core_blob==(root/core_canonical).read_bytes();core=gzip.decompress(core_blob)
catalog_canonical='benchmarks/results/2026-11-17-utf8-widths/refined/observations.tgz'
catalog_blob=subprocess.check_output(['git','show','HEAD:'+catalog_canonical],cwd=root);assert catalog_blob==(root/catalog_canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(catalog_blob))as archive:oldcatalog=archive.extractfile('representative.json').read()
core_sha=hashlib.sha256(core).hexdigest();catalog_sha=hashlib.sha256(oldcatalog).hexdigest()
assert core_sha not in [v['Lokad.Lython.dll']for v in f['imageFiles'].values()]
subjects=[dict(kind='superseded-core',sha256=core_sha,bytes=len(core),canonical=core_canonical,canonicalSHA256=hashlib.sha256(core_blob).hexdigest(),member='gzip-payload'),dict(kind='completed-catalog',path='utf8-widths-b899-20261117/representative.json',sha256=catalog_sha,bytes=len(oldcatalog),canonical=catalog_canonical,canonicalSHA256=hashlib.sha256(catalog_blob).hexdigest(),member='representative.json')]
code="""from pathlib import Path
import fcntl,hashlib,json,os,stat,subprocess
b=Path('/home/lokad/lython-bench-checks');subjects=SUBJECTS
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 own={str(os.getpid()),str(os.getppid())};assert all(line.split(maxsplit=1)[0]in own for line in workers.splitlines()),workers
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 proofs=[]
 for item in subjects:
  if 'path'in item:p=b/item['path']
  else:
   matching=[p for p in b.glob('*/*/Lokad.Lython.dll')if p.stat().st_size==item['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']];assert matching;p=matching[0]
  m=p.lstat();assert p.resolve()==p and p.is_relative_to(b)and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and m.st_size==item['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
  aliases=[]
  for base,dirs,names in os.walk(b):
   for name in names:
    target=Path(base)/name;v=target.lstat()
    if(v.st_dev,v.st_ino)==(m.st_dev,m.st_ino):aliases.append(str(target.relative_to(b)))
  assert len(aliases)==m.st_nlink
  proofs.append(item|dict(paths=aliases,links=m.st_nlink,committedBlobVerified=True))
 print(json.dumps(proofs))
""".replace('SUBJECTS',repr(subjects))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr;groups=json.loads(p.stdout)
q=r/'quiet';q.mkdir(exist_ok=False)
(q/'retirement-proofs.json').write_text(json.dumps(groups,indent=2)+'\n',encoding='utf-8',newline='\n')
remote='/home/lokad/lython-bench-checks/shared-allowance-lock-b906-20261117'
identity=dict(sourceRevision='Fully qualifiedadd2c00a/frozendfc4c83c versus private one-file typed-lockR488',purpose='Replace existing private default-allowance Monitor gate with managed System.Threading.Lock; no new accounting/policy. Preserve exact reservations/refunds, concurrency/reentry/cleanup. Complete JSON warm/fresh, CSV/text and arithmetic-call control; no predicted speedup.',coreSHA256={role:f['imageFiles']['candidate'if role.startswith('candidate')else'reference']['Lokad.Lython.dll']for role in ['reference','reference-control','candidate','candidate-control']},imageFiles=f['imageFiles'],auxiliaryFiles={n:h for n,h in f['imageFiles']['reference'].items()if n!='Lokad.Lython.dll'},sourceInputsArchiveSHA256=hashlib.sha256((r/'candidate-sources.tar.xz').read_bytes()).hexdigest(),productionFiles=585,catalogSHA256=f['catalogSHA256'],normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'quiet/collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a)
jobs=[['scripts.json-summary-helpers.large','warm'],['scripts.json-summary-helpers.large','compile-run'],['scripts.csv-numeric-quality.large','warm'],['scripts.text-normalization.large','warm'],['calls.positional.large','warm']]
s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n'+s[b:]
assert "< 130, 'Reserve50seconds"in s;s=s.replace("< 130, 'Reserve50seconds","< 210, 'Reserve60seconds")
(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'quiet/archive-owned.py').read_text(encoding='utf-8');assert "len(raw['jobs'])==3"in s;s=s.replace("len(raw['jobs'])==3","len(raw['jobs'])==5").replace('jobs=3','jobs=5');(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
(q/'run.sh').write_text((old/'quiet/run.sh').read_text(encoding='utf-8').replace(prior['root'],remote),encoding='utf-8',newline='\n')
(q/'candidate').mkdir();shutil.copyfile(r/'frozen/candidate/Lokad.Lython.dll',q/'candidate/Lokad.Lython.dll');shutil.copyfile(r/'catalog.json',q/'representative.json')
names=['collect.py','archive-owned.py','run.sh','identity.json','representative.json','candidate/Lokad.Lython.dll']
with tarfile.open(q/'payload.tgz','w:gz')as archive:
 for name in names:archive.add(q/name,arcname=name)
c=dict(root=remote,unit='lython-b906-shared-allowance-lock-20261117',source=prior['root'],sourceRole='candidate',sourceFiles=f['imageFiles']['reference'],sourceCatalogSHA256=prior['catalogSHA256'],catalogSHA256=f['catalogSHA256'],identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/name).stat().st_size for name in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace('lython-b905-fixtures','lython-b906-fixtures').replace('RuntimeMaxSec=180','RuntimeMaxSec=300');(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'launch.py').read_text(encoding='utf-8').replace('seconds=140','seconds=230').replace('before140seconds','before230seconds').replace('Three-job copied-call ownership','Five-job typed-lock comparison');(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'quiet/retrieve.py').read_text(encoding='utf-8').replace("['jobs']==3","['jobs']==5").replace('B903','B906');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==3","len(raw['jobs'])==5");(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
print('Five-job source pair prepared; fully qualifieddfc preserved. Only supersededa95 and completed backed catalog eligible for fresh revalidation at launch.')
