; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TryCompleteNativeReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 17 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 120
       xor      eax, eax
       mov      qword ptr [rsp+0x28], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x30], ymm4
       vmovdqu  ymmword ptr [rsp+0x50], ymm4
       mov      qword ptr [rsp+0x70], rax
       mov      rbx, rcx
       mov      rsi, bword ptr [rsp+0xE0]
 
G_M000_IG02:                ;; offset=0x0033
       mov      rdi, bword ptr [r8]
       mov      ebp, dword ptr [r8+0x08]
       xor      ecx, ecx
       mov      qword ptr [rsi], rcx
       mov      qword ptr [rsi+0x08], rcx
       mov      r14, gword ptr [rdx+0x18]
       mov      r15, gword ptr [rbx+0x40]
       cmp      byte  ptr [r15+0xF5], 0
       je       G_M000_IG09
 
G_M000_IG03:                ;; offset=0x0059
       cmp      byte  ptr [rsp+0xD8], 0
       je       SHORT G_M000_IG05
       test     r9, r9
       setne    dl
       movzx    rdx, dl
       add      edx, ebp
       cmp      edx, dword ptr [r15+0xD8]
       jne      G_M000_IG10
       test     r9, r9
       jne      SHORT G_M000_IG04
       mov      bword ptr [rsp+0x38], rdi
       mov      dword ptr [rsp+0x40], ebp
       lea      rdx, [rsp+0x38]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      G_M000_IG14
 
G_M000_IG04:                ;; offset=0x00A2
       mov      gword ptr [rsp+0x60], r9
       mov      bword ptr [rsp+0x68], rdi
       mov      dword ptr [rsp+0x70], ebp
       lea      rdx, [rsp+0x60]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+BoundIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+BoundIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      G_M000_IG14
 
G_M000_IG05:                ;; offset=0x00C9
       test     r9, r9
       jne      G_M000_IG10
       xor      ecx, ecx
       mov      qword ptr [rsi], rcx
       mov      qword ptr [rsi+0x08], rcx
       cmp      byte  ptr [rdx+0x34], 0
       je       SHORT G_M000_IG07
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       mov      rdx, gword ptr [rbx+0x40]
       cmp      ecx, dword ptr [rdx+0xD8]
       jne      SHORT G_M000_IG07
       mov      rcx, rbx
       mov      edx, ebp
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG07
       mov      r15, gword ptr [rsp+0xD0]
       mov      r15, gword ptr [r15+0xA0]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG06
       mov      rcx, r15
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG06:                ;; offset=0x0132
       mov      gword ptr [rsp+0x48], rbx
       mov      bword ptr [rsp+0x50], rdi
       mov      dword ptr [rsp+0x58], ebp
       lea      rdx, [rsp+0x48]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x0156
       xor      eax, eax
 
G_M000_IG08:                ;; offset=0x0158
       jmp      SHORT G_M000_IG14
 
G_M000_IG09:                ;; offset=0x015A
       cmp      byte  ptr [rsp+0xD8], 0
       je       SHORT G_M000_IG10
       test     r9, r9
       jne      SHORT G_M000_IG10
       cmp      ebp, 1
       jne      SHORT G_M000_IG10
       mov      rdx, gword ptr [r15+0x58]
       test     rdx, rdx
       jne      SHORT G_M000_IG12
 
G_M000_IG10:                ;; offset=0x0177
       xor      eax, eax
 
G_M000_IG11:                ;; offset=0x0179
       add      rsp, 120
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       ret      
 
G_M000_IG12:                ;; offset=0x0186
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rsp+0x28], xmm0
 
G_M000_IG13:                ;; offset=0x0190
       mov      bword ptr [rsp+0x20], rsi
       lea      r8, [rsp+0x28]
       mov      rcx, rbx
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan,byref):bool:this]
 
G_M000_IG14:                ;; offset=0x01A6
       movzx    rax, al
 
G_M000_IG15:                ;; offset=0x01A9
       add      rsp, 120
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       ret      
 
; Total bytes of code 438

