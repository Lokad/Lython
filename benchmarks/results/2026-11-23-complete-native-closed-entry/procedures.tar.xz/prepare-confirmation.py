from pathlib import Path

lab = Path(__file__).resolve().parent
prior = lab.parent / "supplied-scalar-return-20261123"

def install(name, source_name, substitutions):
    text = (prior / source_name).read_text(encoding="utf-8")
    for before, after in substitutions:
        assert before in text, before
        text = text.replace(before, after)
    compile(text, name, "exec")
    (lab / name).write_text(text, encoding="utf-8", newline="\n")

install("confirm.py", "confirm.py", [
    ("supplied-scalar-control-b1505-20261123", "complete-native-closed-control-b1508-20261123"),
    ("lython-b1505-supplied-scalar-control-20261123", "lython-b1508-complete-native-closed-control-20261123"),
    ("supplied-scalar-return-b1504-20261123", "complete-native-closed-entry-b1507-20261123"),
    ("eager-isolated-definition-b1502-20261123", "supplied-scalar-return-b1504-20261123"),
    ('"scripts.annotated-rule-closures.nested-factories.postponed"', '"calls.positional.wide-native-buffer"'),
    ('"scripts.ordinary-fully-supplied-helper"', '"scripts.annotated-rule-closures.nested-factories"'),
    ('[[name, "warm"] for name in selected]', '[[name, "warm"] for name in selected[:2]] + [[selected[2], "compile-run"]]'),
    ("len(jobs) == 6", "len(jobs) == 8"),
    ("started < 307", "started < 405"),
])
install("summarize-confirmation.py", "summarize-confirmation.py", [])
