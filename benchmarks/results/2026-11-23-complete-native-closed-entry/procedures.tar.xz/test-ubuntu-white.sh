set -e
export DOTNET_ROOT=/home/vermorel/.dotnet
export DOTNET_ROOT_X64=$DOTNET_ROOT
export DOTNET_NOLOGO=1
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/complete-native-closed-entry-20261123
filter='FullyQualifiedName~Executable|FullyQualifiedName~FunctionBinding|FullyQualifiedName~MemoryGovernor|FullyQualifiedName~NativeIntegerChain|FullyQualifiedName~ComposedNativeCall|FullyQualifiedName~NativeTupleReturn|FullyQualifiedName~SimpleFunctionExecutionBoundary'
$DOTNET_ROOT/dotnet test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$lab/ubuntu-extended-white.log" 2>&1 || { tail -26 "$lab/ubuntu-extended-white.log"; exit 1; }
tail -8 "$lab/ubuntu-extended-white.log"
