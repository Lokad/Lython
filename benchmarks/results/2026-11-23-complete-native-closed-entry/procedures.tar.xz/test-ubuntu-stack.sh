set -e
export DOTNET_ROOT=/home/vermorel/.dotnet
export DOTNET_ROOT_X64=$DOTNET_ROOT
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/complete-native-closed-entry-20261123
$DOTNET_ROOT/dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --no-build --filter 'FullyQualifiedName~StackGuardScenario|FullyQualifiedName~ExecutionThreadContext' > "$lab/ubuntu-stack.log" 2>&1 || { tail -28 "$lab/ubuntu-stack.log"; exit 1; }
tail -8 "$lab/ubuntu-stack.log"
