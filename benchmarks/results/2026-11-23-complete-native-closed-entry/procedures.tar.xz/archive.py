from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / "comparison/quiet"
repeat = lab / "confirmation"
dest = repo / "benchmarks/results/2026-11-23-complete-native-closed-entry"
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
identity = read(lab / "comparison/identity.json")
terminal = read(quiet / "terminal-status.json")
receipt = terminal["receipt"]
assert not terminal["live"] and terminal["exitCode"] == "0" and not terminal["fixtures"]
assert all(receipt[name] for name in ("complete", "archivedAndVerifiedUnderLease", "allWorkersJoined",
                                      "guestFixturesRemoved", "quietBeforeAndAfter"))
assert sha((quiet / "observations.tar.xz").read_bytes()) == receipt["archiveSHA256"]
assert read(quiet / "summary.json")["timedBatches"] == 224
repeated = read(repeat / "terminal-status.json")
repeat_receipt = repeated["receipt"]
assert not repeated["live"] and repeated["exitCode"] == "0" and not repeated["fixtures"]
assert all(repeat_receipt[name] for name in ("complete", "archivedAndVerifiedUnderLease", "allWorkersJoined",
                                             "guestFixturesRemoved", "quietBeforeAndAfter"))
assert sha((repeat / "observations.tar.xz").read_bytes()) == repeat_receipt["archiveSHA256"]
assert read(repeat / "summary.json")["timedBatches"] == 84
for row in read(lab / "allocation-summary-six.json"):
    assert row["peakAdmission"][0] == row["peakAdmission"][1]
    assert row["allocatedBytes"][0] == row["allocatedBytes"][1]
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, encoding="utf-8").strip()
paths = subprocess.check_output(["git", "diff", "--name-only", identity["sourceRevision"], identity["candidate"],
                                 "--", "src", "tests"], cwd=repo, encoding="utf-8").splitlines()
assert len(paths) == 8
source_diff = subprocess.check_output(["git", "diff", "--name-only", head, identity["candidate"], "--", *paths], cwd=repo)
identity["retainedRevision"] = None if source_diff else head
patch = subprocess.check_output(["git", "diff", "--binary", identity["sourceRevision"], identity["candidate"],
                                 "--", *paths], cwd=repo)
(lab / "comparison.patch").write_bytes(patch)
identity["comparisonPatchSHA256"] = sha(patch)
dest.mkdir(exist_ok=False)
for role, files in identity["imageFiles"].items():
    assert len(files) == 32 and all(sha((lab / role / name).read_bytes()) == digest for name, digest in files.items())
    core = lab / role / "Lokad.Lython.dll"
    image = dest / "candidate-core.dll.gz" if role == "candidate" else dest.parent / "2026-11-23-supplied-scalar-return/candidate-core.dll.gz"
    if role == "candidate":
        image.write_bytes(gzip.compress(core.read_bytes(), mtime=0))
    assert sha(gzip.decompress(image.read_bytes())) == files[core.name]
(dest / "identity.json").write_text(json.dumps(identity, indent=2) + "\n", encoding="utf-8", newline="\n")
for name in ("observations.tar.xz", "summary.json", "terminal-status.json"):
    shutil.copyfile(quiet / name, dest / name)
    shutil.copyfile(repeat / name, dest / ("repeat-" + name))
for name in ("allocation-summary-six.json", "jit-entry-summary.json"):
    shutil.copyfile(lab / name, dest / name)
with tarfile.open(dest / "procedures.tar.xz", "w:xz") as archive:
    for name in (
        "prepare.py", "prepare-timing.py", "stage.py", "quiet.py", "inspect-entry.py", "inspect-entry.log",
        "archive.py", "comparison.patch", "summarize.py", "allocations.py", "allocations.log",
        "windows-frozen.log", "windows-Lokad.Lython.PublicApi.Tests.log", "windows-Lokad.Lython.Tests.log",
        "windows-initial-white.log", "windows-stack.log", "ubuntu-Lokad.Lython.PublicApi.Tests.log",
        "ubuntu-extended-white.log", "ubuntu-stack.log", "test-ubuntu.sh", "test-ubuntu-white.sh", "test-ubuntu-stack.sh",
        "stage.log", "retrieval.log", "comparison/reference-verify.json", "comparison/candidate-verify.json",
        "comparison/quiet/observe-not-before", "prepare-confirmation.py", "confirm.py", "summarize-confirmation.py",
        "confirmation-launch.log", "confirmation-retrieval.log", "confirmation/observe-not-before",
        "confirmation/reference-verify.json", "confirmation/candidate-verify.json"):
        archive.add(lab / name, arcname=name)
    for pattern in ("*.asm", "*-only.json", "*-jit-alloc.json", "*-allocation-six.json"):
        for path in sorted(lab.glob(pattern)):
            archive.add(path, arcname=path.name)
print(dest, identity["retainedRevision"] or "private")
