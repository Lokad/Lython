set -e
export DOTNET_ROOT=/home/vermorel/.dotnet
export DOTNET_ROOT_X64=$DOTNET_ROOT
export DOTNET_NOLOGO=1
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/complete-native-closed-entry-20261123
public='FullyQualifiedName~NativeIntegerChain|FullyQualifiedName~OrdinalFunctionTransport|FullyQualifiedName~FunctionDefaultMetadata|FullyQualifiedName~NativeTuple|FullyQualifiedName~StackSafety|FullyQualifiedName~MemoryAdmission|FullyQualifiedName~Cancellation|FullyQualifiedName~Close'
white='FullyQualifiedName~Executable|FullyQualifiedName~FunctionBinding|FullyQualifiedName~MemoryGovernor'
for p in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
  if [ "$p" = Lokad.Lython.Tests ]; then filter=$white; else filter=$public; fi
  log="$lab/ubuntu-$p.log"
  $DOTNET_ROOT/dotnet test "tests/$p/$p.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1 || { tail -25 "$log"; exit 1; }
  tail -8 "$log"
done
