from pathlib import Path
import gzip
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
template = lab.parent / "supplied-scalar-return-20261123"
old = lab.parent / "direct-computed-definition-20261123"
tracked = "benchmarks/results/2026-11-23-direct-computed-definition/"
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
sha = lambda data: hashlib.sha256(data).hexdigest()
def pushed(name):
    return subprocess.check_output(["git", "show", "origin/master:" + tracked + name], cwd=repo)

proof = json.loads(pushed("identity.json"))
terminal = json.loads(pushed("terminal-status.json"))
digest = terminal["receipt"]["archiveSHA256"]
assert terminal["receipt"]["complete"] and terminal["receipt"]["allWorkersJoined"]
assert terminal["receipt"]["archivedAndVerifiedUnderLease"] and sha(pushed("observations.tar.xz")) == digest
files = proof["imageFiles"]["candidate"]
assert len(files) == 32 and all(sha((old / "candidate" / name).read_bytes()) == value for name, value in files.items())
core = gzip.decompress(pushed("candidate-core.dll.gz"))
assert sha(core) == files["Lokad.Lython.dll"]
retire = dict(sha=sha(core), size=len(core), archive=digest)

def install(name, replacements):
    source = (template / name).read_text(encoding="utf-8")
    for old, new in replacements:
        assert old in source, (name, old)
        source = source.replace(old, new)
    compile(source, name, "exec")
    (lab / name).write_text(source, encoding="utf-8", newline="\n")

install("stage.py", [
    ("supplied-scalar-return-b1504-20261123", "complete-native-closed-entry-b1507-20261123"),
    ("eager-isolated-definition-b1502-20261123", "supplied-scalar-return-b1504-20261123"),
    ("'lython-b1504-fixtures'", "'lython-b1507-fixtures'"),
    ("len(jobs) == 6", "len(jobs) == 8"),
    ("started < 307", "started < 405"),
])
install("quiet.py", [
    ("lython-b1504-supplied-scalar-return-20261123", "lython-b1507-complete-native-closed-entry-20261123"),
    (".+b1504-", ".+b1507-"),
    ("lython-b1504-stage-", "lython-b1507-stage-"),
    ("  assert free >= minimum,", """
  if free < minimum:
   proof=RETIREMENT_PROOF
   prior=base/'direct-computed-definition-b1500-20261123'
   replica=prior/'candidate/Lokad.Lython.dll'
   info=replica.lstat()
   assert replica.resolve()==replica and stat.S_ISREG(info.st_mode)
   assert info.st_uid==os.getuid() and info.st_nlink==1 and info.st_size==proof['size']
   assert digest(replica)==proof['sha'] and digest(prior/'observations.tar.xz')==proof['archive']
   assert not (prior/'guest-fixtures').exists()
   replica.unlink()
   free=shutil.disk_usage(base).free
   print(json.dumps(dict(retiredWorkingReplica=str(replica),sha256=proof['sha'],freeAfterRetirement=free)),flush=True)
  assert free >= minimum,""".replace("RETIREMENT_PROOF", repr(retire))),
    ("RuntimeMaxSec=350", "RuntimeMaxSec=450"),
    ("seconds=298", "seconds=395"),
])
install("summarize.py", [("== 6","== 8"), ("==6","==8"), ("timedBatches=168", "timedBatches=224")])
