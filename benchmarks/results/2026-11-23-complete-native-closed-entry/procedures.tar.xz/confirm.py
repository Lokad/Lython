from pathlib import Path
import datetime
import hashlib
import io
import json
import os
import shlex
import shutil
import subprocess
import sys
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
initial = lab / "comparison/quiet"
out = lab / "confirmation"
out.mkdir(exist_ok=True)
base = "/home/lokad/lython-bench-checks"
root = base + "/complete-native-closed-control-b1508-20261123"
previous = "complete-native-closed-entry-b1507-20261123"
unit = "lython-b1508-complete-native-closed-control-20261123"
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc)
ssh_options = ["-i", str(Path.home() / ".ssh/id_lython-bench.pem"), "-o", "BatchMode=yes", "-o", "ConnectTimeout=15"]
host = "lokad@20.166.121.73"
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe", *ssh_options, host]
scp = ["C:/Windows/System32/OpenSSH/scp.exe", *ssh_options]


def run_remote(code, data=None):
    compile(code, "remote", "exec")
    process = subprocess.run(ssh + ["python3 -c " + shlex.quote(code)], input=data,
                             capture_output=True, timeout=25)
    print(process.stdout.decode(), end="")
    if process.stderr:
        print(process.stderr.decode(), end="", file=sys.stderr)
    process.check_returncode()
    return process.stdout


def write(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")


if sys.argv[1] == "launch":
    terminal = read(initial / "terminal-status.json")
    expected_archive = terminal["receipt"]["archiveSHA256"]
    assert terminal["exitCode"] == "0" and terminal["receipt"]["complete"] and sha(initial / "observations.tar.xz") == expected_archive
    identity = read(lab / "comparison/identity.json")
    catalog = read(lab / "comparison/representative.json")
    selected = ["calls.positional.wide-native-buffer",
                "scripts.csv-invoice.method-policy.quoted-control",
                "scripts.annotated-rule-closures.nested-factories"]
    catalog["cases"] = [next(row for row in catalog["cases"] if row["id"] == name) for name in selected]
    write("representative.json", catalog)
    write("jobs.json", {"warm": [[name, "warm"] for name in selected[:2]] + [[selected[2], "compile-run"]]})
    identity["catalogs"] = {name: {"sha256": sha(out / name)} for name in ("representative.json", "jobs.json")}
    write("identity.json", identity)
    dotnet = Path.home() / ".dotnet11/dotnet.exe"
    env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
    protocol = repo / "benchmarks/cpython-worker.py"
    assert sha(protocol) == identity["cpythonWorkerSHA256"]
    for role, files in identity["imageFiles"].items():
        local = lab / role
        assert len(files) == 32 and all(sha(local / name) == digest for name, digest in files.items())
        receipt = out / (role + "-verify.json")
        subprocess.run([dotnet, local / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
                        "--catalog", out / "representative.json", "--dotnet", dotnet,
                        "--python", "C:/Python313/python.exe", "--python-worker", protocol,
                        "--out", receipt], env=env, timeout=90, check=True)
        proof = read(receipt)
        assert proof["state"] == "Completed" and proof["caseCount"] == len(selected)
        assert proof["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]
        assert all(sha(local / name) == digest for name, digest in files.items())
    collection = (initial / "collect.py").read_text(encoding="utf-8")
    for old, new in (
        ("'candidate':root/'candidate'", f"'candidate':root.parent/{previous!r}/'candidate'"),
        ("len(jobs) == 8", "len(jobs) == 3"),
        ("started < 405", "started < 185"),
    ):
        assert old in collection, old
        collection = collection.replace(old, new)
    compile(collection, "collect", "exec")
    (out / "collect.py").write_text(collection, encoding="utf-8", newline="\n")
    assert b"\r" not in (initial / "run.sh").read_bytes()
    shutil.copyfile(initial / "run.sh", out / "run.sh")
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode="w:gz") as package:
        for name in ("representative.json", "identity.json", "collect.py", "run.sh", "jobs.json"):
            package.add(out / name, arcname=name, recursive=False)
    data = buffer.getvalue()
    digest = hashlib.sha256(data).hexdigest()
    (out / "payload.tar.gz").write_bytes(data)
    code = f"""
from pathlib import Path
import fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
root=Path({root!r})
prior=root.parent/{previous!r}
previous_reference=root.parent/'supplied-scalar-return-b1504-20261123'/'candidate'
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
data=sys.stdin.buffer.read()
assert hashlib.sha256(data).hexdigest()=={digest!r}
with (root.parent/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert shutil.disk_usage(root.parent).free>=120*1024*1024
 assert digest(prior/'observations.tar.xz')=={expected_archive!r}
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(data)) as package:
  assert set(package.getnames())=={{'representative.json','identity.json','collect.py','run.sh','jobs.json'}}
  package.extractall(root,filter='data')
 identity=json.loads((root/'identity.json').read_text())
 for role,image in [('reference',previous_reference),('candidate',prior/'candidate')]:
  assert all(digest(image/name)==expected for name,expected in identity['imageFiles'][role].items())
 assert digest(prior/'cpython-worker.py')==identity['cpythonWorkerSHA256']
 os.link(prior/'cpython-worker.py',root/'cpython-worker.py')
subprocess.run(['sudo','-n','systemd-run','--unit={unit}','--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=205','--property=TimeoutStopSec=20','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
"""
    run_remote(code, data)
    (out / "observe-not-before").write_text((now() + datetime.timedelta(seconds=159)).isoformat(), encoding="utf-8")
else:
    assert sys.argv[1] == "retrieve"
    assert now() >= datetime.datetime.fromisoformat((out / "observe-not-before").read_text(encoding="utf-8"))
    code = f"""
from pathlib import Path
import fcntl,json,subprocess
root=Path({root!r})
service=subprocess.run(['systemctl','show','{unit}.service','--property=ActiveState,Result,ExecMainStatus,MainPID'],capture_output=True,text=True).stdout
if 'ActiveState=active' in service: print(json.dumps(dict(live=True,service=service)))
else:
 with (root.parent/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  read=lambda filename: (root/filename).read_text().strip() if (root/filename).exists() else None
  print(json.dumps(dict(live=False,service=service,exitCode=read('exit-code.txt'),
  receipt=json.loads(read('archive-receipt.json') or 'null'),fixtures=(root/'guest-fixtures').exists(),
  journal=subprocess.run(['journalctl','-u','{unit}.service','-n','25','--no-pager'],capture_output=True,text=True).stdout)))
"""
    result = json.loads(run_remote(code))
    write("status-" + now().strftime("%H%M%S") + ".json", result)
    if not result["live"] and result["receipt"] is not None:
        archive = out / "observations.tar.xz"
        subprocess.run(scp + [host + ":" + root + "/observations.tar.xz", archive], check=True, timeout=35)
        assert sha(archive) == result["receipt"]["archiveSHA256"]
        write("terminal-status.json", result)
        assert result["exitCode"] == "0" and result["receipt"]["complete"] and not result["fixtures"]
