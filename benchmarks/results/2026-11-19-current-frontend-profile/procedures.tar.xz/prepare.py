import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
prior = lab.parent / 'retained-rule-regex-profile-r628'
donor = lab.parent / 'trim-policy-scan-r634'
read = lambda p: p.read_text(encoding='utf-8-sig')
load = lambda p: json.loads(read(p))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(name, body):
    if name.endswith('.py'):
        ast.parse(body)
    (lab/name).write_text(body, encoding='utf-8', newline='\n')

def save(name, value):
    write(name, json.dumps(value, ensure_ascii=False, indent=2)+'\n')

old = load(prior/'config.json')
stage = load(donor/'quiet/config.json')
frozen = donor/'frozen/candidate'
files = stage['identity']['imageFiles']['candidate']
assert len(files) == 32 and {name:sha(frozen/name) for name in files} == files
assert not subprocess.check_output(['git','diff','--name-only','12fabffb1','ac175cc27','--','src'])
retained = load(Path('benchmarks/results/2026-11-19-trim-policy-scan/summary.json'))
assert retained['retainedCommit'] == '12fabffb1' and retained['cores']['candidate'] == files['Lokad.Lython.dll']
jobs = [('manifest','scripts.config-manifest.small','compile'),
        ('validator','scripts.config-generated-guards.medium','compile'),
        ('annotated','scripts.annotated-rule-closures','compile')]
labels = [label for label,_,_ in jobs]
catalog = load(lab.parent/'prepared-compiler-bindings-r627/catalog.json')
catalog['cases'] = [next(case for case in catalog['cases'] if case['id']==name) for _,name,_ in jobs]
save('catalog.json', catalog)
identity = dict(sourceRevision='12fabffb1', purpose='R637 retained frontend phase attribution with corrected batching',
    coreSHA256=dict(candidate=files['Lokad.Lython.dll']), imageFiles=dict(candidate=files),
    catalogSHA256=sha(lab/'catalog.json'), diagnosticOnly=True, publicationHeld=True)
save('identity.json', identity)
root='/home/lokad/lython-bench-checks/frontend-profile-confirmation-b1067-20261119'
unit='lython-b1067-frontend-profile-confirmation-20261119'
floor=174*1024*1024
reserve=675*1024
profile=read(prior/'ops-profile.py').replace(old['root'],root)
a=profile.index("[('rules',")
b=profile.index(')]',a)+2
profile=profile[:a]+repr(jobs)+profile[b:]
profile=profile.replace('count = 64 if name.startswith("regex-") else 256','count = 128 if name == "validator" else 512')
profile=profile.replace('time.monotonic()+5','time.monotonic()+3')
profile=profile.replace('total_capture_seconds > 50','total_capture_seconds > 18')
profile=profile.replace('Current original text warm runtime and host attribution','Current frontend compilation CPU attribution')
write('ops-profile.py',profile)
collect=read(prior/'collect.py').replace(old['root'],root)
collect=collect.replace(repr(['rules','annotated','captured','mutable','regex-groups','regex-spans','regex-mixed']),repr(labels))
collect=collect.replace('207618048',str(floor)).replace('len(records)==7','len(records)==3')
collect=collect.replace('R628/B1059 f80035c13 rule and Unicode capture attribution','R637/B1067 12fabffb1 frontend phase attribution')
write('collect.py',collect)
write('run.sh',read(prior/'run.sh').replace(old['root'],root))
write('launch.py',read(prior/'launch.py').replace('Current rule and Unicode capture attribution','Current frontend phase attribution').replace('177','94'))
write('retrieve.py',read(prior/'retrieve.py'))

names=['identity.json','catalog.json','ops-profile.py','collect.py','run.sh']
payload=lab/'payload.tgz'
with tarfile.open(payload,'w:gz') as stream:
    for name in names:
        stream.add(lab/name,arcname=name)
size=sum((lab/name).stat().st_size for name in names)
space_proof=load(lab/'quiet-space.json')
space=space_proof['freeBytes']
retire_groups=[]
for proof in space_proof['replicas']:
    if space>floor+size+reserve+65536:
        break
    assert proof['committedBlobVerified'] and proof['sha256']==proof['canonicalSHA256']
    assert proof['links']==1 and len(proof['paths'])==1
    retire_groups.append(proof)
    space+=proof['bytes']
assert space>floor+size+reserve+65536,(space,floor,size,reserve)
config=dict(root=root,unit=unit,source=stage['root'],sourceFiles=files,sourceCatalogSHA256=stage['catalogSHA256'],
    catalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=retire_groups,payloadBytes=payload.stat().st_size,
    payloadSHA256=sha(payload),unpackedBytes=size)
save('config.json',config)
launcher=read(prior/'remote-launch.py')
a,b=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=(launcher[:a]+'c='+repr(config)+launcher[b:]).replace('lython-b1059-fixtures','lython-b1067-fixtures')
launcher=launcher.replace('207618048',str(floor)).replace('+2097152,',f'+{reserve},').replace('RuntimeMaxSec=275','RuntimeMaxSec=155')
write('remote-launch.py',launcher)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'catalog.json',
        '--dotnet',dotnet,'--python',Path('C:/Python313/python.exe'),'--python-worker',Path.cwd()/'benchmarks/cpython-worker.py',
        '--out',lab/'verify.json'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90,check=True)
result=load(lab/'verify.json')
assert result['state']=='Completed' and result['catalogSha256']==identity['catalogSHA256']
assert {name:sha(frozen/name) for name in files}==files
print('Verified all 32 retained image files and three CPython goldens.')
