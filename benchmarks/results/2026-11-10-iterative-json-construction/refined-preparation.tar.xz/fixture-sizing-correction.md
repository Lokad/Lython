Original refined public11 run:1001pass, new3deepI/O-chain scenario timed out25s,
childCPU1.45s. Log preserved. Delayed host intentionally waits25ms per operation,
so repeated I/O at every deep hook plus three deep failures exceeds the small
fixture's purpose. Keep25s deadline and original safety asserts. Corrected fixture
has one real suspended hook, one default-depth rejection on its continuation,
then three real JSON callback recoveries. No production code changes; remaining
original stress coverage unchanged. Resume only corrected public11case, reuse
1001unchanged passing checks; internal11 and bothactual10 suites still needed.
