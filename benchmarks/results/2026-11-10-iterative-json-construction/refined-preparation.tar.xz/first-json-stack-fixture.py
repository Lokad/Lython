with open('/ready', 'r') as stream:
 stream.read()
import json
def decode(value):
    with open('/ready') as stream:
        stream.read()
    return json.loads('{"x":1}', object_hook=decode)
failures = 0
for _ in range(3):
    try: json.loads('{"x":1}', object_hook=decode)
    except (RuntimeError, RecursionError): failures += 1
    assert json.loads('{"ok":true}')['ok']
return failures