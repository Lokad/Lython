from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config={'payloadBytes': 1966709, 'payloadSHA256': '7a3e6ced23ad5d0e44c5b352510b4e928ac19c1d9ea5fad3a8fc687e557ed372', 'required': 270141279, 'copies': [{'path': 'iterative-json-b544-20261110/observations.tgz', 'bytes': 3882096, 'sha256': 'e6bd035cf12a11d6ff5581dbc7d6ef8edc94f4b881d409dd585a258c111cf30c', 'canonical': 'benchmarks\\results\\2026-11-10-iterative-json-construction\\original-observations.tgz'}, {'path': 'iterative-json-b544-20261110/source-checks.tar.xz', 'bytes': 59284, 'sha256': '4a96bff92bae7fbde3570317a15ba8e6273809d37c9d45a2147d7054ec9e907f', 'canonical': 'benchmarks\\results\\2026-11-10-iterative-json-construction\\original-observations.tgz:source-checks.tar.xz'}, {'path': 'iterative-json-b544-20261110/confirmation/confirmation.json', 'bytes': 546092, 'sha256': '3355dfa795dad01dc434186f77cb9c0419865969f55465c87b9ce71ce1c48a0b', 'canonical': 'benchmarks\\results\\2026-11-10-iterative-json-construction\\original-observations.tgz:confirmation/confirmation.json'}]}
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'iterative-json-b545-20261110';source=base/'prefix-code-b541-20261110/candidate';fixture=root/'guest-fixtures'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='ac6edb6fc361dba9195d973830a5ca02caac10b62cc6d041f134ce31ef9a10d3'
 protocol=base/'prepared-call-layout-b384-20261107/cpython-worker.py'
 assert hashlib.sha256(protocol.read_bytes()).hexdigest()=='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'
 before=shutil.disk_usage(base).free;retired=[];retiredA9=[]
 if before<=config['required']:
  reclaim=0
  for copy in config['copies']:
   path=base/copy['path'];s=path.lstat()
   assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
   assert s.st_size==copy['bytes']and hashlib.sha256(path.read_bytes()).hexdigest()==copy['sha256']
   reclaim+=s.st_blocks*512;retired.append(dict(copy,allocatedBytes=s.st_blocks*512,allAliases=[str(path)]))
  original=base/'iterative-json-b544-20261110/current-core.dll';old=original.lstat()
  assert stat.S_ISREG(old.st_mode)and old.st_uid==os.getuid()and hashlib.sha256(original.read_bytes()).hexdigest()=='a9d5620ff8db469894e7a77fe50bb701f5ab8a3cc679248ab97fdd2a2962a17f'
  matches=subprocess.check_output(['find',str(base),'-xdev','-samefile',str(original),'-type','f'],text=True).splitlines()
  assert len(matches)==old.st_nlink
  for name in matches:
   path=Path(name);st=path.lstat();assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()
   protected=(source/'Lokad.Lython.dll').stat();assert(st.st_dev,st.st_ino)!=(protected.st_dev,protected.st_ino)
  retiredA9=matches;reclaim+=old.st_blocks*512
  assert before+reclaim>config['required'],(before,reclaim,config['required'])
  for name in matches:Path(name).unlink()
  for copy in config['copies']:(base/copy['path']).unlink()
 assert shutil.disk_usage(base).free>config['required']
 recovery=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,requiredFreeBytes=config['required'],freshIdleLease=True,qualifiedac6Preserved=True,osFloorMiB=240,evidenceHeadroomMiB=12,files=retired,retiredOriginalA9Aliases=retiredA9,originalA9Canonical='benchmarks/results/2026-11-10-iterative-json-construction/original-observations.tgz:current-core.dll')
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 shutil.copyfile(protocol,root/'cpython-worker.py');os.link(source/'Lokad.Lython.dll',root/'baseline-core.dll')
 for role in ['reference','candidate']:
  shutil.copytree(source,root/role,copy_function=os.link)
  (root/role/'Lokad.Lython.dll').unlink();os.link(root/('baseline-core.dll'if role=='reference'else'current-core.dll'),root/role/'Lokad.Lython.dll')
 identity=json.loads((root/'identity.json').read_text())
 for role in ['reference','candidate']:
  for name,digest in {**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256'][role]}.items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest,(role,name)
 assert hashlib.sha256((root/'cpython-worker.py').read_bytes()).hexdigest()==identity['protocolSHA256']
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b545-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,jobs=6,ownerSeconds=240,stopSeconds=30,marginSeconds=30,workerUnchanged=True,osFloorMiB=240,evidenceHeadroomMiB=12)
 assert setup['freeBytes']>(240+12)*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b545-iterative-json-20261110','--property=User=lokad','--property=WorkingDirectory='+str(root),
  '--property=RuntimeMaxSec=240','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b545-iterative-json-20261110.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert 'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
