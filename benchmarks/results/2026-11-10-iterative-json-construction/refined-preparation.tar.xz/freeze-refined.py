from pathlib import Path
import hashlib,json,os,shutil,subprocess
h=Path(__file__).parent;t=h/'tree';d=h/'refined-diagnostic';d.mkdir()
p=t/'src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs';s=p.read_text(encoding='utf-8')
s=s.replace('''            // Strings and true/false/null cannot suspend. Keep the same scalar
            // admission and prefix rules without entering the async token helper.''','''            // Strings and true/false/null finish under decoder admission.
            // Preserve scalar storage/prefix rules without an async token helper.''')
p.write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['git','add','-N','tests/Lokad.Lython.Tests/JsonDecodeAdmissionTests.cs'],cwd=t,check=True)
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
with(d/'freeze11.log').open('w',encoding='utf-8')as out:
 done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-incremental'],cwd=t,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=120)
assert done.returncode==0,(d/'freeze11.log').read_text(encoding='utf-8')[-2000:]
for role in ['before','candidate']:shutil.copytree(h/'diagnostic/images/before',d/'images'/role)
shutil.copyfile(t/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',d/'images/candidate/Lokad.Lython.dll')
for name in ['five-catalog.json','hash-witness.json','python-goldens.json']:shutil.copyfile(h/'diagnostic'/name,d/('catalog.json'if name=='five-catalog.json'else name))
assert all(p.read_bytes()==(d/'images/candidate'/p.relative_to(d/'images/before')).read_bytes()for p in(d/'images/before').rglob('*')if p.is_file()and p.name!='Lokad.Lython.dll')
(d/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src','tests'],cwd=t,stderr=subprocess.DEVNULL))
source={p.relative_to(t).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in(t/'src/Lokad.Lython').rglob('*.cs')if'obj'not in p.parts}
assert len(source)==568
identity=dict(baseRevision='3da4c742; qualified1a83c64f/coreac6',status='Isolated R196 decoder-admission refinement, not promoted or fully qualified.',
 cores={role:hashlib.sha256((d/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},source=source,
 catalogSHA256=hashlib.sha256((d/'catalog.json').read_bytes()).hexdigest(),qualification='1002public/880internal eachactual11/10; net11 public reuses1001passing unchanged cases plus corrected1fixture. Original25stimeout/1.45CPU preserved. Originalstress deadlines unchanged. Nonincremental freeze after comment correction.',
 goldens='Copied unchanged original Python source/fixture goldens; no repeat execution.',originalVariant='a9d5620ff8db469894e7a77fe50bb701f5ab8a3cc679248ab97fdd2a2962a17f; sixjob B544 evidence/source/binary preserved.')
(d/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(h/'run-five.py').read_text(encoding='utf-8').replace("d=h/'diagnostic'","d=h/'refined-diagnostic'")
s=s.replace('Existing driver requires exactly5cases, original6case catalog rejected before guest work. Original stderr/empty output preserved under warm/.','Earlier original diagnostic required five cases; original six-case pre-guest rejection survives under ../diagnostic/warm/. This source uses the same five-case catalog, driver and golden bytes.')
(h/'run-five-refined.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(cores=identity['cores'],sources=len(source),status=identity['status']),indent=2),flush=True)
