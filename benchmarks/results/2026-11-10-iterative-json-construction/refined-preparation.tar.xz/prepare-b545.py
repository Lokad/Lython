from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
h=Path(__file__).parent;p=h/'b545';p.mkdir();d=h/'refined-diagnostic';repo=Path('D:/code/Lython')
source=json.loads((d/'identity.json').read_text(encoding='utf-8'))
assert len(source['source'])==568 and all(hashlib.sha256((h/'tree'/name).read_bytes()).hexdigest()==digest for name,digest in source['source'].items())
assert hashlib.sha256((d/'images/candidate/Lokad.Lython.dll').read_bytes()).hexdigest()==source['cores']['candidate']
old=h.parent/'receiver-native-entry-r192/b540'
collect=(old/'collect.py').read_text(encoding='utf-8').replace('receiver-native-b540-20261110','iterative-json-b545-20261110')
collect=collect.replace('import statistics, subprocess, tempfile, time','import statistics, subprocess, tempfile, time, signal')
collect=collect.replace("jobs=[['scripts.text-summary-helpers.class-callable.large', 'warm'], ['scripts.report-render.large', 'warm'], ['scripts.text-summary-helpers.large', 'warm']]",
 "jobs=[['scripts.report-render.large','warm'],['scripts.json-summary-helpers.large','warm'],['scripts.report-render.large','warm-async'],['scripts.json-summary-helpers.large','warm-async'],['scripts.report-render.large','compile'],['scripts.text-summary-helpers.large','warm']]")
collect=collect.replace('assert len(jobs)==3','assert len(jobs)==6').replace("time.monotonic()-started < 150, 'Reserve30 seconds for final owned work/cleanup.'", "time.monotonic()-started < 200, 'Reserve40seconds for final owned work/cleanup.'")
collect=collect.replace("purpose='R185 empty/unbound storage invariant vs retained R184; complete CSV and unchanged search/text controls, desktop search+9to19percent adversity retained'", "purpose='R196 iterative JSON construction vs qualified1a83c64f; report/JSON-lines bothAPIs, compilation and unchangedtextcontrol. All prior desktop adversity preserved.'")
needle="with (root.parent/'comparison-vm.lock').open('a') as lease:"
collect=collect.replace(needle,"def stop(*_):raise InterruptedError('Owned run stopped; join all users before cleanup.')\nsignal.signal(signal.SIGTERM,stop)\n\n"+needle)
assert 'b540'not in collect and 'len(jobs)==6'in collect
ast.parse(collect);(p/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
shutil.copyfile(d/'five-catalog.json',p/'representative.json');shutil.copyfile(d/'images/candidate/Lokad.Lython.dll',p/'current-core.dll')
base=json.loads((h.parent/'prefix-attribution-r193/b541/identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision='R196 decoder-admission refinement above3da4c742, measured678; qualified1a83c64f/ac6 reference; no source promotion.',
 coreSHA256={'reference':source['cores']['before'],'reference-control':source['cores']['before'],'candidate':source['cores']['candidate'],'candidate-control':source['cores']['candidate']},
 auxiliaryFiles=base['auxiliaryFiles'],catalogSHA256=hashlib.sha256((p/'representative.json').read_bytes()).hexdigest(),
 protocolSHA256='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1',performanceQualified=False)
(p/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
checks=[h/'pre-edit-plan.md',h/'milestone.md',h/'safe-checkpoint.json',h/'first-build.log',h/'check.py',h/'diagnose.py',h/'run-five.py',h/'summarize-existing.py']
checks.extend(x for name in ['checks','refined-checks','refined-completion-checks']for x in(h/name).iterdir()if x.is_file())
checks.extend(h/name for name in ['refinement.md','refine.py','freeze-refined.py','check-refined.py','check-refined-completion.py','fixture-sizing-correction.md','first-json-stack-fixture.py','line-count-correction.json','summarize-refined.py'])
checks.extend(x for x in d.rglob('*')if x.is_file()and'images'not in x.relative_to(d).parts)
checks.extend(h/'tree'/name for name in ['tests/Lokad.Lython.Tests/JsonDecodeAdmissionTests.cs','tests/Lokad.Lython.Tests/JsonLiteralDispatchBoundaryTests.cs','tests/Lokad.Lython.PublicApi.Tests/StackGuardScenarioTests.cs','tests/Lokad.Lython.WorkerFixture/StackGuardFixture.cs','src/Lokad.Lython/Runtime/LythonRuntime.Json.Construction.cs','src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs','tests/Lokad.Lython.PublicApi.Tests/JsonNestedConstructionLifetimeTests.cs'])
with tarfile.open(p/'source-checks.tar.xz','w:xz')as a:
 for path in sorted(set(checks)):a.add(path,arcname=path.relative_to(h).as_posix())
(p/'contract.md').write_text((h/'refinement.md').read_text(encoding='utf-8')+"""

B545 source decision: same six jobs/catalog, worker and stock runtime as B544.
Frozen678 refinement versus qualifiedac6. Focused1002public/880internal eachactual
11/10 pass. Netproduction+102lines (original111, earlier105estimate corrected).
All desktop warmth/compile adversity, repeated zero-clock summary mistake and
failed25sfixture are retained. The fixture was trimmed to one genuine suspended
hook/deep rejection plus three real recovery calls; original25msdelays/deadline
and failedsource survive. No hidden timeout relaxation or originalstress removal.

Sixjobs: report/JSON-lines warm through bothAPIs, report compilation, unchangedtext
warm control. Four independent roles,5swarmup/role,7rotated400msrounds; owner240s,
stop30s/margin30s. Same clock boundaries as B544: workerwarm includes RAMI/O,
checks/prior-resultcleanup, excludes reset/startup/compile; widerprocessCPU coarse.
Compiledphase includes construction/prior-scriptdisposal; never use Run-only zero.
No new CPythonrow or producerqualification. All gates/join/RAM/archive/SHA required.

Bounded refinement, no automatic percentage veto or indefinite retiming. Explicit
whole-script/code/ownership/debt decision before promotion. Main remains ac6.
""",encoding='utf-8',newline='\n')
archive='''from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path('/home/lokad/lython-bench-checks/iterative-json-b545-20261110')
raw=json.loads((r/'confirmation/confirmation.json').read_text());assert raw['complete']and len(raw['jobs'])==6 and all(j['workersJoinedAndFixturesRemoved']for j in raw['jobs'])
assert not(r/'guest-fixtures').exists()and subprocess.run(['pgrep','-af','[d]otnet.* --compare worker'],capture_output=True).returncode==1
assert all(json.loads((r/'confirmation'/name).read_text())['gate']['quiet']for name in ['machine-before.json','machine-after.json'])
with tarfile.open(r/'observations.tgz','w:gz',dereference=True)as a:
 for path in sorted(r.rglob('*')):
  if path.is_file()and path.name!='observations.tgz'and not any(n in path.relative_to(r).parts for n in ['candidate','reference']):a.add(path,arcname=path.relative_to(r).as_posix())
assert shutil.disk_usage(r).free>240*1024*1024
with tarfile.open(r/'observations.tgz')as a:assert json.loads(a.extractfile('confirmation/confirmation.json').read())['complete']
receipt=dict(complete=True,jobs=6,elapsedSeconds=raw['elapsedSeconds'],allWorkersJoined=True,guestFixturesRemoved=True,quietBeforeAndAfter=True,archivedAndVerifiedUnderLease=True,archiveSHA256=hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest(),freeBytesAfterArchive=shutil.disk_usage(r).free,performanceQualified=False)
(r/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n');print(json.dumps(receipt))
'''
ast.parse(archive);(p/'archive-owned.py').write_text(archive,encoding='utf-8',newline='\n')
run=(old/'run.sh').read_text(encoding='utf-8').replace('receiver-native-b540-20261110','iterative-json-b545-20261110').replace('lython-b540-receiver-native-20261110','lython-b545-iterative-json-20261110')
(p/'run.sh').write_text(run,encoding='utf-8',newline='\n')
with tarfile.open(p/'payload.tgz','w:gz')as a:
 for name in ['collect.py','identity.json','representative.json','current-core.dll','source-checks.tar.xz','contract.md','archive-owned.py','run.sh']:a.add(p/name,arcname=name)
canonical=repo/'benchmarks/results/2026-11-10-iterative-json-construction/original-observations.tgz'
receipt=json.loads((canonical.parent/'original-archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256(canonical.read_bytes()).hexdigest()==receipt['archiveSHA256']
subprocess.run(['git','ls-files','--error-unmatch',str(canonical.relative_to(repo))],cwd=repo,check=True,stdout=subprocess.DEVNULL)
copies=[dict(path='iterative-json-b544-20261110/observations.tgz',bytes=canonical.stat().st_size,sha256=receipt['archiveSHA256'],canonical=str(canonical.relative_to(repo)))]
with tarfile.open(canonical)as a:
 for name in ['source-checks.tar.xz','confirmation/confirmation.json']:
  m=a.getmember(name);copies.append(dict(path='iterative-json-b544-20261110/'+name,bytes=m.size,sha256=hashlib.sha256(a.extractfile(m).read()).hexdigest(),canonical=str(canonical.relative_to(repo))+':'+name))
 assert hashlib.sha256(a.extractfile('current-core.dll').read()).hexdigest()=='a9d5620ff8db469894e7a77fe50bb701f5ab8a3cc679248ab97fdd2a2962a17f'
(p/'exact-copies.json').write_text(json.dumps(copies,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(payloadBytes=(p/'payload.tgz').stat().st_size,exactCanonicalCopies=len(copies),candidateSHA256=source['cores']['candidate']),indent=2))
