from pathlib import Path
import hashlib,json,statistics
h=Path(__file__).parent;d=h/'refined-diagnostic';summary=[]
identity=json.loads((d/'five-identity.json').read_text(encoding='utf-8'))
for phase in ['confirmed-warm','confirmed-warm-async','confirmed-compile']:
 p=d/phase;raw=json.loads((p/'measurements.json').read_text(encoding='utf-8'))
 assert all(raw[n]for n in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified','normalGcAndTiering'])
 assert raw['catalogSHA256'].lower()==identity['catalogSHA256']
 rows=[]
 for case in raw['observations']:
  for role,files in case['identities'].items():assert files['Lokad.Lython.dll'].lower()==identity['cores']['candidate'if role=='candidate'else'before']
  roles={role:{key:statistics.median(s[field]/s['jobs']for s in case['samples']if s['image']==role)
   for key,field in [('runOnlyMs','executionMilliseconds'),('fullEnvelopeMs','elapsedMilliseconds'),('allocatedBytes','allocatedBytes')]}
   for role in ['before','before-control','candidate']}
  changes={control:{key:100*(roles['candidate'][key]/roles[control][key]-1)if roles[control][key]else None for key in roles[control]}for control in ['before','before-control']}
  rows.append(dict(case=case['caseId'],medians=roles,changesPercent=changes,
   unchangedControlSpreadPercent={key:100*(roles['before-control'][key]/roles['before'][key]-1)if roles['before'][key]else None for key in roles['before']}))
  metric='fullEnvelopeMs'if phase.endswith('compile')else'runOnlyMs'
  print(phase,case['caseId'],metric,*[round(changes[c][metric],2)for c in changes],flush=True)
 value=dict(phase=phase,rows=rows,allChecksPassed=True,performanceQualified=False,
  boundary='Warm Run-only includes mediated I/O/projection, excludes fixture reset/goldens/result disposal; full envelope adds them. Compilation uses full envelope and has no Run clock. Startup excluded. Desktop shared CoreLib/processGC/JIT, elapsed diagnostic only.')
 (p/'summary.json').write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n');summary.append(value)
(h/'refined-safe-checkpoint.json').write_text(json.dumps(dict(status='Active isolated R196 decoder-admission refinement, not promoted. No active local/VM users. Main3da4c742 runtime1a83c64f unchanged/qualified.',
 cores=identity['cores'],sourceExpected=568,focused={'net11.0':{'public':1002,'internal':880},'net10.0':{'public':1002,'internal':880}},
 diagnostics=summary,measurementCorrections=['Six-case catalog rejected before guest work by unchanged5-case driver; selected report/JSON-lines/config targets +CSV/text controls, original stderr preserved.',
 'All3refined phases completed. Copied runner retained old zero-Run compile-summary bug; raw data corrected offline without rerun. This repeated tool mistake is preserved, not a runtime failure.'],
 next='One bounded quiet confirmation against qualifiedac6 using existing common protocol, report/JSON-lines warm and warm-async, same source and all goldens. Four jobs, independent reference/candidate controls,5s warmup,7rotated400msrounds,180s owner/30s stop/30s margin. Explicit code/ownership/regression-debt decision before promotion; no fixedpercentage veto or speedup claim.'),indent=2)+'\n',encoding='utf-8',newline='\n')
source=json.loads((d/'identity.json').read_text(encoding='utf-8'))['source']
assert len(source)==568 and all(hashlib.sha256((h/'tree'/name).read_bytes()).hexdigest()==digest for name,digest in source.items())
assert hashlib.sha256((d/'images/candidate/Lokad.Lython.dll').read_bytes()).hexdigest()==identity['cores']['candidate']
print('Frozen source/image verified; complete raw diagnostics summarized without re-execution.',flush=True)
