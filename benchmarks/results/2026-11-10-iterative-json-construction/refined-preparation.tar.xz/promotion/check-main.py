from pathlib import Path
import os,subprocess
repo=Path('D:/code/Lython');h=repo/'.git/agent-notes/review-20261031/iterative-json-r196/promotion';env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH'];dotnet=env['DOTNET_ROOT']+'/dotnet.exe'
for framework in ['net11.0','net10.0']:
 for name,args in [
  ('build',['build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f',framework,'--no-incremental']),
  ('public',['test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',framework,'--filter','FullyQualifiedName~JsonNestedConstructionLifetime|FullyQualifiedName~JsonDecoderCallbacksRecoverAfterGenuineSuspension|FullyQualifiedName~JsonBoundaryContract|FullyQualifiedName~JsonReaderReentrancy|FullyQualifiedName~JsonRawIndexProtocol']),
  ('internal',['test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',framework,'--filter','FullyQualifiedName~JsonDecodeAdmission|FullyQualifiedName~JsonLiteralDispatchBoundary|FullyQualifiedName~JsonNumberTokenStorage'])]:
  log=h/(name+'-'+framework+'.log')
  with log.open('w',encoding='utf-8')as stdout:
   done=subprocess.run([dotnet,*args],cwd=repo,env=env,stdout=stdout,stderr=subprocess.STDOUT,timeout=180)
  print(name,framework,log.read_text(encoding='utf-8')[-500:],flush=True)
  assert done.returncode==0,(name,framework)
