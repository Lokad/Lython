from pathlib import Path
h=Path(__file__).parent;t=h/'tree';p=t/'src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs'
s=p.read_text(encoding='utf-8')
needle='            options = await options.PrepareAsync(context, span, asynchronous).ConfigureAwait(false);\n            try'
assert needle in s;s=s.replace(needle,needle.replace('\n            try','\n            context.EnterInterpreterFrame(span);\n            try'),1)
needle='            var startOriginal = document.GetByteIndexForRuneBoundary((int)idxRune);\n            try'
assert needle in s;s=s.replace(needle,needle.replace('\n            try','\n            context.EnterInterpreterFrame(span);\n            try'),1)
needle='                var decoded = await ReadJsonValueAsync(text, options, context, span, 0, asynchronous).ConfigureAwait(false);'
assert needle in s;s=s.replace(needle,needle+'\n                context.CheckExecution(span);\n                ExecutionState.EnsureInterpreterStack(span);',1)
needle='                var (value, endByte) = await ReadJsonValueExactAsync(document, options, context, span, startOriginal, asynchronous).ConfigureAwait(false);'
assert needle in s;s=s.replace(needle,needle+'\n                context.CheckExecution(span);\n                ExecutionState.EnsureInterpreterStack(span);',1)
for following in ['        // Reads exactly one value','        private ValueTask<(object Value, int End)> ReadJsonValueAsync']:
 end=s.index(following)
 before=s[:end];at=before.rfind('        }\n')
 before=before[:at]+'            finally { context.LeaveInterpreterFrame(); }\n'+before[at:]
 s=before+s[end:]
start=s.index('                context.EnterInterpreterFrame(span);',s.index('private ValueTask<(object Value, int End)> ReadJsonValueExactAsync'))
end=s.index('                finally { context.LeaveInterpreterFrame(); }',start)+len('                finally { context.LeaveInterpreterFrame(); }')
old=s[start:end];inner=old[old.index('                {\n')+len('                {\n'):old.rfind('                }\n')]
inner='\n'.join(line[4:]if line.startswith('    ')else line for line in inner.splitlines())
s=s[:start]+inner+s[end:]
start=s.index('            context.EnterInterpreterFrame(span);',s.index('private ValueTask<(object Value, int End)> ReadJsonNumberOrConstantAsync'))
end=s.index('\n        private static (PyString Value, int End) ReadJsonString',start)
s=s[:start]+'''            // The bounded decoder owns admission through completed/pending hooks.
            // Numbers retain Python's prefix grammar and token storage ownership.
            if (TryMatchJsonNumber(bytes.Span, position, context, span, out var numberEnd))
            {
                var converted = ConvertJsonNumberTextAsync(bytes, position, numberEnd, options, context, span, asynchronous);
                return converted.IsCompletedSuccessfully
                    ? new((converted.Result, numberEnd))
                    : CompleteJsonScalarAsync(converted, numberEnd);
            }
            throw CreateJsonExpectingError(input, position, JsonIncompleteExpectation.Value, span, context);
        }

        private static async ValueTask<(object Value, int End)> CompleteJsonScalarAsync(
            ValueTask<object> converted, int end)
            => (await converted.ConfigureAwait(false), end);
''' +s[end:]
s=s.replace('CompleteJsonScalarAsync(converted, constantEnd, null)','CompleteJsonScalarAsync(converted, constantEnd)')
needle='''            context.EnterInterpreterFrame(span);
            try { return ReadJsonString(input, (bool)options.Strict, position, context, span, expected, expectedPosition); }
            finally { context.LeaveInterpreterFrame(); }'''
assert needle in s;s=s.replace(needle,'''            return ReadJsonString(input, (bool)options.Strict, position, context, span, expected, expectedPosition);''',1)
s=s.replace('// Keys use the same decoder/frame policy as values, with no callback.','// Keys share the enclosing decoder admission, with no callback.')
assert s.count('context.EnterInterpreterFrame(span);')==2 and s.count('context.LeaveInterpreterFrame();')==2
assert 'numericFrame'not in s and 'var pending = false;'not in s
p.write_text(s,encoding='utf-8',newline='\n')
p=t/'src/Lokad.Lython/Runtime/LythonRuntime.Json.Construction.cs';s=p.read_text(encoding='utf-8')
s=s.replace('CompleteJsonScalarAsync(converted, end, null)','CompleteJsonScalarAsync(converted, end)')
needle='                    var decoded = await pending.ConfigureAwait(false);'
assert needle in s;s=s.replace(needle,needle+'''
                    // Resume on the current managed stack before descending into
                    // construction; the operation's existing admission stays live.
                    state.Context.CheckExecution(state.Span);
                    ExecutionState.EnsureInterpreterStack(state.Span);''',1)
p.write_text(s,encoding='utf-8',newline='\n')
p=t/'tests/Lokad.Lython.Tests/JsonLiteralDispatchBoundaryTests.cs';s=p.read_text(encoding='utf-8')
s=s.replace('["hook:3,0"]','["hook"]').replace('Events.Add($"hook:{context.State.CurrentInterpreterDepth},{context.State.CurrentRecursionDepth}");','Events.Add("hook");')
p.write_text(s,encoding='utf-8',newline='\n')
print('Operation admission replaces scalar/key/numeric frame ownership; current-stack checks retained on continuations.')
