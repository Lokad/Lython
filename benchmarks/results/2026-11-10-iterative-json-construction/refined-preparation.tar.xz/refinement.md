# R196 bounded decoder-admission refinement (before editing)

Original a9 and all six B544 jobs are preserved and SHAverified; source/binary
unchanged in diagnostic/images/candidate and original-source/. Report neutral,
JSON-lines sync+1.40..+2.51%, CPU+0.36..+1.83%; async JSON-lines reference spread
6.38% remains uncertain. Untouched compilation large desktop adversity does not
reproduce; no universal neutrality claim. Do not promote original a9 alone.

The iterative constructor removes recursive container descent, but inherited
per-string/per-key/per-number interpreter-frame admission remains. Move that
admission to each complete decoder entry, across its awaited users, and explicitly
check current managed stack after real callback suspension before resuming the
bounded loop. Retain every cancellation/terminal-refusal scan and allocation
preflight, the64container depth bound, actual Python callback/function guards,
managed512nesting policy and RuntimeHelpers.TryEnsureSufficientExecutionStack.

Delete leaf entry/leave try/finally pairs, numeric pending-frame transfer flag,
and nullable frame-owner cleanup in CompleteJsonScalarAsync. No new resource
policy/counter/option or fallback parser. Working/frame backing ownership is
unchanged and remains funded through callbacks. Native containers/constants and
object hooks gain one conservative operation admission; very near the existing
managed nesting boundary they may deny earlier. Python MaxRecursionDepth and
ordinary behavior remain unchanged. This tradeoff is explicit, not hidden.

Focused JSON/stack/cancellation/refusal/ownership checks on actual11/10, plus a
near-managed-boundary regression if existing coverage misses the new lifetime.
Fresh nonincremental freeze and same short complete scripts; no local overlap.
Only if source checks and results justify it, one bounded quiet confirmation of
this coherent refinement against qualifiedac6. Keep original adversity; require
explicit code/ownership/whole-script/debt decision, no percentage veto or endless
retiming. Full platform/Stress/package checks only at a retained delivery boundary.
