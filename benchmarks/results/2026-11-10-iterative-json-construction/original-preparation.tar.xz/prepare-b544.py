from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
h=Path(__file__).parent;p=h/'b544';p.mkdir();d=h/'diagnostic';repo=Path('D:/code/Lython')
source=json.loads((d/'identity.json').read_text(encoding='utf-8'))
assert len(source['source'])==568 and all(hashlib.sha256((h/'tree'/name).read_bytes()).hexdigest()==digest for name,digest in source['source'].items())
assert hashlib.sha256((d/'images/candidate/Lokad.Lython.dll').read_bytes()).hexdigest()==source['cores']['candidate']
old=h.parent/'receiver-native-entry-r192/b540'
collect=(old/'collect.py').read_text(encoding='utf-8').replace('receiver-native-b540-20261110','iterative-json-b544-20261110')
collect=collect.replace('import statistics, subprocess, tempfile, time','import statistics, subprocess, tempfile, time, signal')
collect=collect.replace("jobs=[['scripts.text-summary-helpers.class-callable.large', 'warm'], ['scripts.report-render.large', 'warm'], ['scripts.text-summary-helpers.large', 'warm']]",
 "jobs=[['scripts.report-render.large','warm'],['scripts.json-summary-helpers.large','warm'],['scripts.report-render.large','warm-async'],['scripts.json-summary-helpers.large','warm-async'],['scripts.report-render.large','compile'],['scripts.text-summary-helpers.large','warm']]")
collect=collect.replace('assert len(jobs)==3','assert len(jobs)==6').replace("time.monotonic()-started < 150, 'Reserve30 seconds for final owned work/cleanup.'", "time.monotonic()-started < 200, 'Reserve40seconds for final owned work/cleanup.'")
collect=collect.replace("purpose='R185 empty/unbound storage invariant vs retained R184; complete CSV and unchanged search/text controls, desktop search+9to19percent adversity retained'", "purpose='R196 iterative JSON construction vs qualified1a83c64f; report/JSON-lines bothAPIs, compilation and unchangedtextcontrol. All prior desktop adversity preserved.'")
needle="with (root.parent/'comparison-vm.lock').open('a') as lease:"
collect=collect.replace(needle,"def stop(*_):raise InterruptedError('Owned run stopped; join all users before cleanup.')\nsignal.signal(signal.SIGTERM,stop)\n\n"+needle)
assert 'b540'not in collect and 'len(jobs)==6'in collect
ast.parse(collect);(p/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
shutil.copyfile(d/'five-catalog.json',p/'representative.json');shutil.copyfile(d/'images/candidate/Lokad.Lython.dll',p/'current-core.dll')
base=json.loads((h.parent/'prefix-attribution-r193/b541/identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision='Isolated R196 above3da4c742; qualified1a83c64f/coreac6 reference; no source promotion.',
 coreSHA256={'reference':source['cores']['before'],'reference-control':source['cores']['before'],'candidate':source['cores']['candidate'],'candidate-control':source['cores']['candidate']},
 auxiliaryFiles=base['auxiliaryFiles'],catalogSHA256=hashlib.sha256((p/'representative.json').read_bytes()).hexdigest(),
 protocolSHA256='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1',performanceQualified=False)
(p/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
checks=[h/'pre-edit-plan.md',h/'milestone.md',h/'safe-checkpoint.json',h/'first-build.log',h/'check.py',h/'diagnose.py',h/'run-five.py',h/'summarize-existing.py']
checks.extend(x for x in(h/'checks').iterdir()if x.is_file())
checks.extend(x for x in d.rglob('*')if x.is_file()and'images'not in x.relative_to(d).parts)
checks.extend(h/'tree'/name for name in ['src/Lokad.Lython/Runtime/LythonRuntime.Json.Construction.cs','src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs','tests/Lokad.Lython.PublicApi.Tests/JsonNestedConstructionLifetimeTests.cs'])
with tarfile.open(p/'source-checks.tar.xz','w:xz')as a:
 for path in sorted(set(checks)):a.add(path,arcname=path.relative_to(h).as_posix())
(p/'contract.md').write_text('''# R196 bounded quiet source decision — B544

Frozen a9 prototype versus qualified1a83/ac6, source and 568-file manifest unchanged
since actual.NET11/10 focused checks. Same worker/adapter0.4/dependencies, complete
report/JSON-lines scripts and all stdout/file goldens. No producer qualification,
CPython row or source promotion. All original setup errors and desktop adversity
are in source-checks.tar.xz. Allocationflat is distinct from elapsed/CPU evidence.

Sixjobs: report/JSON-lines warm, both publicAPIs; report compilation; unchangedtext
warm control. Each has4independent source/control processes, ordinaryGC/tiering,
5s timewarmup/role,7rotated400msrounds. Existing protocol/calibration/worker only.
Owner240s, stop30s, observationmargin30s. Jobentry<200s leaves40s finalwork; no
restart because observation expires. All identities/goldens/balances/quiet/join/
RAMcleanup/archive/localSHA must pass or remain explicitly incomplete.

Warm clocks include mediatedRAMI/O, output checks and prior-result cleanup; fixture
reset is excluded. Compile includes construction/prior-script disposal. Startup,
staging and protocol excluded; external processCPU is wider and coarse. This is
not the short driver's Run-only boundary. Async filesystem I/O completion is not
an actual pending-I/O latency measurement; real callbacks are correctness-tested.

Decision: actual recursive-container transport disappears, but code/explicit-owner
complexity grows105productionlines. Retain only with an explicit whole-script/
regression-debt rationale. No fixedpercentage veto, allocation/CPU equivalence
claim or indefinite retiming. Uncertainty can justify bounded refinement when
specific evidence warrants it. Preserve all adverse controls and failed conditions.
Managed safety, scalar checks, firstrefusal, fundedaliases and joined users remain.
Publication postponed; independent regex work remains active.
''',encoding='utf-8',newline='\n')
archive='''from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path('/home/lokad/lython-bench-checks/iterative-json-b544-20261110')
raw=json.loads((r/'confirmation/confirmation.json').read_text());assert raw['complete']and len(raw['jobs'])==6 and all(j['workersJoinedAndFixturesRemoved']for j in raw['jobs'])
assert not(r/'guest-fixtures').exists()and subprocess.run(['pgrep','-af','[d]otnet.* --compare worker'],capture_output=True).returncode==1
assert all(json.loads((r/'confirmation'/name).read_text())['gate']['quiet']for name in ['machine-before.json','machine-after.json'])
with tarfile.open(r/'observations.tgz','w:gz',dereference=True)as a:
 for path in sorted(r.rglob('*')):
  if path.is_file()and path.name!='observations.tgz'and not any(n in path.relative_to(r).parts for n in ['candidate','reference']):a.add(path,arcname=path.relative_to(r).as_posix())
assert shutil.disk_usage(r).free>240*1024*1024
with tarfile.open(r/'observations.tgz')as a:assert json.loads(a.extractfile('confirmation/confirmation.json').read())['complete']
receipt=dict(complete=True,jobs=6,elapsedSeconds=raw['elapsedSeconds'],allWorkersJoined=True,guestFixturesRemoved=True,quietBeforeAndAfter=True,archivedAndVerifiedUnderLease=True,archiveSHA256=hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest(),freeBytesAfterArchive=shutil.disk_usage(r).free,performanceQualified=False)
(r/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n');print(json.dumps(receipt))
'''
ast.parse(archive);(p/'archive-owned.py').write_text(archive,encoding='utf-8',newline='\n')
run=(old/'run.sh').read_text(encoding='utf-8').replace('receiver-native-b540-20261110','iterative-json-b544-20261110').replace('lython-b540-receiver-native-20261110','lython-b544-iterative-json-20261110')
(p/'run.sh').write_text(run,encoding='utf-8',newline='\n')
with tarfile.open(p/'payload.tgz','w:gz')as a:
 for name in ['collect.py','identity.json','representative.json','current-core.dll','source-checks.tar.xz','contract.md','archive-owned.py','run.sh']:a.add(p/name,arcname=name)
canonical=repo/'benchmarks/results/2026-11-10-report-construction-attribution/observations-partial.tgz'
receipt=json.loads((canonical.parent/'partial-archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256(canonical.read_bytes()).hexdigest()==receipt['archiveSHA256']
subprocess.run(['git','ls-files','--error-unmatch',str(canonical.relative_to(repo))],cwd=repo,check=True,stdout=subprocess.DEVNULL)
copies=[dict(path='report-assessment-b543-20261110/observations-partial.tgz',bytes=canonical.stat().st_size,sha256=receipt['archiveSHA256'],canonical=str(canonical.relative_to(repo)))]
with tarfile.open(canonical)as a:
 for member in a.getmembers():
  if not member.isfile()or not member.name.startswith('profiles/')or member.size<32768:continue
  copies.append(dict(path='report-assessment-b543-20261110/'+member.name,bytes=member.size,sha256=hashlib.sha256(a.extractfile(member).read()).hexdigest(),canonical=str(canonical.relative_to(repo))+':'+member.name))
(p/'exact-copies.json').write_text(json.dumps(copies,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(payloadBytes=(p/'payload.tgz').stat().st_size,exactCanonicalCopies=len(copies),candidateSHA256=source['cores']['candidate']),indent=2))
