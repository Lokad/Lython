from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config={'payloadBytes': 1956709, 'payloadSHA256': '2ddf4956b456e138885fe2f81fe0b24b338cd144af1dc07a245583fd0fe5d628', 'required': 270111279, 'copies': [{'path': 'report-assessment-b543-20261110/observations-partial.tgz', 'bytes': 2356460, 'sha256': 'a0fbe5b14af35062769f52936315817a32d1a9fde7f2335942a6e128825454ae', 'canonical': 'benchmarks\\results\\2026-11-10-report-construction-attribution\\observations-partial.tgz'}, {'path': 'report-assessment-b543-20261110/profiles/report-compile/perf-leaves.txt', 'bytes': 55015, 'sha256': '1e2b13b6597a5dd9cd5c2672581365f107f7c3179ac612450d324c4c6b2d0f3b', 'canonical': 'benchmarks\\results\\2026-11-10-report-construction-attribution\\observations-partial.tgz:profiles/report-compile/perf-leaves.txt'}, {'path': 'report-assessment-b543-20261110/profiles/report-compile/perf-stacks.txt', 'bytes': 1370947, 'sha256': '179e57b38ad41ae07d697a3e9ed844290ad63a3239d6b67b26594cd1272f4023', 'canonical': 'benchmarks\\results\\2026-11-10-report-construction-attribution\\observations-partial.tgz:profiles/report-compile/perf-stacks.txt'}, {'path': 'report-assessment-b543-20261110/profiles/report-compile/perf.data', 'bytes': 511564, 'sha256': '54f04b89bfe358d33678a5f4e37c1ac251c9bc7d14117ef60027dd697c62af52', 'canonical': 'benchmarks\\results\\2026-11-10-report-construction-attribution\\observations-partial.tgz:profiles/report-compile/perf.data'}, {'path': 'report-assessment-b543-20261110/profiles/report-compile/perf.map', 'bytes': 1421312, 'sha256': 'a710b0cf33170d808b3e1015d57844cf91726e7215345c313836fa9a8038615e', 'canonical': 'benchmarks\\results\\2026-11-10-report-construction-attribution\\observations-partial.tgz:profiles/report-compile/perf.map'}, {'path': 'report-assessment-b543-20261110/profiles/report-warm/perf-leaves.txt', 'bytes': 56892, 'sha256': '6c0e00a5f36af0cae7a3817eeb1943c0f1e6926d7542bf0985d377581b1fd56c', 'canonical': 'benchmarks\\results\\2026-11-10-report-construction-attribution\\observations-partial.tgz:profiles/report-warm/perf-leaves.txt'}, {'path': 'report-assessment-b543-20261110/profiles/report-warm/perf-stacks.txt', 'bytes': 767924, 'sha256': 'e5a9f99df4d64c1c7ea1bfe6717771a37f0f2b6826f81e4aef8274547c7bb7d0', 'canonical': 'benchmarks\\results\\2026-11-10-report-construction-attribution\\observations-partial.tgz:profiles/report-warm/perf-stacks.txt'}, {'path': 'report-assessment-b543-20261110/profiles/report-warm/perf.data', 'bytes': 339560, 'sha256': '732851c33a28d26b1c4690ca75b2e87d11eac9e1ad478f7f4447b323dd72f0fe', 'canonical': 'benchmarks\\results\\2026-11-10-report-construction-attribution\\observations-partial.tgz:profiles/report-warm/perf.data'}, {'path': 'report-assessment-b543-20261110/profiles/report-warm/perf.map', 'bytes': 1381710, 'sha256': 'a69b8f0c5042adf25411706be20f5c2d39a4773503c9829113b58e74f62a58c7', 'canonical': 'benchmarks\\results\\2026-11-10-report-construction-attribution\\observations-partial.tgz:profiles/report-warm/perf.map'}]}
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'iterative-json-b544-20261110';source=base/'prefix-code-b541-20261110/candidate';fixture=root/'guest-fixtures'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='ac6edb6fc361dba9195d973830a5ca02caac10b62cc6d041f134ce31ef9a10d3'
 protocol=base/'prepared-call-layout-b384-20261107/cpython-worker.py'
 assert hashlib.sha256(protocol.read_bytes()).hexdigest()=='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'
 before=shutil.disk_usage(base).free;retired=[]
 if before<=config['required']:
  reclaim=0
  for copy in config['copies']:
   path=base/copy['path'];s=path.lstat()
   assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
   assert s.st_size==copy['bytes']and hashlib.sha256(path.read_bytes()).hexdigest()==copy['sha256']
   reclaim+=s.st_blocks*512;retired.append(dict(copy,allocatedBytes=s.st_blocks*512,allAliases=[str(path)]))
  assert before+reclaim>config['required'],(before,reclaim,config['required'])
  for copy in config['copies']:(base/copy['path']).unlink()
 assert shutil.disk_usage(base).free>config['required']
 recovery=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,requiredFreeBytes=config['required'],freshIdleLease=True,qualifiedac6Preserved=True,osFloorMiB=240,evidenceHeadroomMiB=12,files=retired)
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 shutil.copyfile(protocol,root/'cpython-worker.py');os.link(source/'Lokad.Lython.dll',root/'baseline-core.dll')
 for role in ['reference','candidate']:
  shutil.copytree(source,root/role,copy_function=os.link)
  (root/role/'Lokad.Lython.dll').unlink();os.link(root/('baseline-core.dll'if role=='reference'else'current-core.dll'),root/role/'Lokad.Lython.dll')
 identity=json.loads((root/'identity.json').read_text())
 for role in ['reference','candidate']:
  for name,digest in {**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256'][role]}.items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest,(role,name)
 assert hashlib.sha256((root/'cpython-worker.py').read_bytes()).hexdigest()==identity['protocolSHA256']
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b544-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,jobs=6,ownerSeconds=240,stopSeconds=30,marginSeconds=30,workerUnchanged=True,osFloorMiB=240,evidenceHeadroomMiB=12)
 assert setup['freeBytes']>(240+12)*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b544-iterative-json-20261110','--property=User=lokad','--property=WorkingDirectory='+str(root),
  '--property=RuntimeMaxSec=240','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b544-iterative-json-20261110.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert 'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
