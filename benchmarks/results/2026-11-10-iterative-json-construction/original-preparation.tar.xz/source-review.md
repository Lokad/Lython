# R196 bounded source review while fixed-source B544 runs

568production files still byte-match the frozen/tested a9 manifest. No edits,
rebuilds, local test/timing or duplicate qualification during this observation.

Container depth remains64; initial frame storage4 is only an optimization shape.
All scalar read/admission/managed interpreter-frame checks remain. The iterative
loop checks cancellation/first refusal before work; extra checks are not a policy
counter. Root/raw_decode and whitespace/error-coordinate helpers are preserved.

Deeper arrays reserve before allocation, fund old/replacement overlap, copy all
live frames, retire/clear old storage before its reservation shrinks. Private
frames never escape. Actual pending scalar/object hooks transfer the same working
reservation in the existing ValueTask continuation; finally clears frame refs and
refunds scratch after awaited callbacks finish, never result/container charges.
No guest trace, weak registration, retry, GC or independent allowance is added.
New deep callback checks and existing depth/error suites passed on both targets;
full delivery remains pending retention. Code/ownership complexity (+105lines)
still needs a whole-script/debt decision, not just this semantic source gate.

Separate next-source lead, not selected for implementation: native-return lowering
already supports nonappending constant FormatField/ConvertFormattedValue. Whole
f-string builders are different: effects interleave mutable dictionary inputs,
formats/errors and admitted builder growth. Existing hasEffects guards deliberately
stop later mutable storage reads. A native whole-builder shortcut cannot be
justified by missing opcodes alone; snapshots could reorder reads/errors and
admission reentry. Preserve current direct UTF8 formatter/deferred contexts rather
than add a speculative duplicate route. No new profile or prototype selected here.
