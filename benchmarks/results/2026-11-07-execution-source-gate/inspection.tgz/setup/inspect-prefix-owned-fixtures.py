from pathlib import Path
home=Path(__file__).parent
s=(home/'inspect-current-prefix-refined.py').read_text(encoding='utf-8')
s=s.replace("out=home/'r27-prefix-source-private-fixtures'","out=home/'r27-prefix-source-owned-fixtures'")
s=s.replace("fixtures=out/'fixtures';fixtures.mkdir();env['TMP']=str(fixtures.resolve());env['TEMP']=str(fixtures.resolve());before=set()", "fixtures=out/'fixtures';fixtures.mkdir();env['TMP']=str(fixtures.resolve());env['TEMP']=str(fixtures.resolve());before=set();owned=fixtures/'lython-comparison-files-r27';owned.mkdir()")
s=s.replace('],cwd=out,env=env,stdin=','],cwd=owned,env=env,stdin=')
before="assert not set(fixtures.glob('lython-comparison-files-*'))-before"
after="""assert owned.resolve().parent==fixtures.resolve() and owned.name=='lython-comparison-files-r27' and not owned.is_symlink()
import shutil
shutil.rmtree(owned)
assert not list(fixtures.iterdir())"""
assert before in s;s=s.replace(before,after)
compile(s,'owned-fixture-inspection','exec')
(home/'inspect-current-prefix-owned.py').write_text(s,encoding='utf-8')
exec(compile(s,str(home/'inspect-current-prefix-owned.py'),'exec'),{'__file__':str(home/'inspect-current-prefix-owned.py')})
