from pathlib import Path
home=Path(__file__).parent
s=(home/'inspect-current-prefix.py').read_text(encoding='utf-8')
s=s.replace("out=home/'r27-prefix-source'","out=home/'r27-prefix-source-private-fixtures'")
s=s.replace("fixtures=Path(tempfile.gettempdir());before=set(fixtures.glob('lython-comparison-files-*'))", "fixtures=out/'fixtures';fixtures.mkdir();env['TMP']=str(fixtures.resolve());env['TEMP']=str(fixtures.resolve());before=set()")
compile(s,'refined-prefix-inspection','exec')
(home/'inspect-current-prefix-refined.py').write_text(s,encoding='utf-8')
exec(compile(s,str(home/'inspect-current-prefix-refined.py'),'exec'),{'__file__':str(home/'inspect-current-prefix-refined.py')})
