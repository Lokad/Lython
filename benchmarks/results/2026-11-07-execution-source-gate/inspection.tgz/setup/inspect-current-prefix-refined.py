from pathlib import Path
import hashlib,importlib.util,io,json,os,subprocess,tempfile
home=Path(__file__).parent;out=home/'r27-prefix-source-private-fixtures';out.mkdir()
spec=importlib.util.spec_from_file_location('existing_protocol',home/'b374/retrieved/cpython-worker.py')
protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
catalog=home/'allocation/catalog.json';worker=home/'allocation/candidate/Lokad.Lython.Benchmarks.dll'
case=next(c for c in json.loads(catalog.read_text(encoding='utf-8'))['cases'] if c['id']=='scripts.text-summary-helpers.large')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
env['DOTNET_JitDisasm']='*ExecuteInstructionPrefix*'
env['DOTNET_JitStdOutFile']=str((out/'prefix-disassembly.txt').resolve())
requests=io.BytesIO()
for requestId,(operation,iterations) in enumerate([('verify',2),('batch',1000),('batch',1000),('batch',1000)],1):
    request={k:case[k] for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']}
    request.update(protocolVersion=2,requestId=requestId,operation=operation,caseId=case['id'],lane='warm',iterations=iterations)
    protocol.write_frame(requests,request)
protocol.write_frame(requests,dict(protocolVersion=2,requestId=5,operation='quit'))
fixtures=out/'fixtures';fixtures.mkdir();env['TMP']=str(fixtures.resolve());env['TEMP']=str(fixtures.resolve());before=set()
p=subprocess.Popen([env['DOTNET_ROOT']+'/dotnet.exe',str(worker.resolve()),'--compare','worker','--catalog',str(catalog.resolve())],cwd=out,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
try:
    stdout,stderr=p.communicate(requests.getvalue(),timeout=40)
except subprocess.TimeoutExpired:
    p.kill();stdout,stderr=p.communicate()
    (out/'failed-stdout.bin').write_bytes(stdout);(out/'failed-stderr.txt').write_bytes(stderr)
    raise
(out/'stdout.bin').write_bytes(stdout);(out/'stderr.txt').write_bytes(stderr)
assert p.returncode==0 and not stderr,(p.returncode,stderr)
stream=io.BytesIO(stdout);frames=[]
while stream.tell()<len(stdout):frames.append(protocol.read_frame(stream))
assert len(frames)==6 and frames[0]['status']=='Ready' and frames[-1]['status']=='Closed'
assert frames[1]['status']=='Equivalent' and all(f['status']=='Completed' and f['completedInvocations']==1000 for f in frames[2:5])
assert all(f['actualOutputSha256']==case['expectedOutputSha256'] and f['actualFilesSha256']==case['expectedFilesSha256'] for f in frames[1:5])
assert not set(fixtures.glob('lython-comparison-files-*'))-before
core=worker.parent/'Lokad.Lython.dll';identity=json.loads((home/'focused-refined.json').read_text(encoding='utf-8'))
assert hashlib.sha256(core.read_bytes()).hexdigest()==identity['coreSHA256']['net11.0']
receipt=dict(purpose='R27 existing instruction-prefix JIT/source inspection only; no elapsed or allocation comparison',runtime=frames[0],coreSHA256=hashlib.sha256(core.read_bytes()).hexdigest(),disassemblyBytes=(out/'prefix-disassembly.txt').stat().st_size,checkedTextJobs=3000,allGoldensPassed=True,allWorkersJoined=True,ownedFixturesRemoved=True,jitDisassemblyOnly=True,normalGcAndTiering=True,platform='Windows x64; source inspection is not Linux perf attribution')
(out/'frames.json').write_text(json.dumps(frames,indent=2)+'\n',encoding='utf-8')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='runtime'},indent=2),flush=True)
