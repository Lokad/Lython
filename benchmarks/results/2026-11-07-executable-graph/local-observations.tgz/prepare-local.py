from pathlib import Path
import hashlib, json, os, shutil
r=Path(__file__).parent
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
for role in ['before','candidate']:
    target=r/'images'/role
    shutil.copytree(r.parent/'product-admission-r57/images/candidate',target,copy_function=os.link)
    (target/'Lokad.Lython.dll').unlink()
    shutil.copyfile(r/('baseline-core.dll' if role=='before' else 'current-core.dll'),target/'Lokad.Lython.dll')
shutil.copyfile(r.parent/'module-bindings-r49/catalog.json',r/'catalog.json')
s=(r.parent/'admission-reentry-r53/measure.py').read_text(encoding='utf-8')
assert "[('warm','sync'),('warm','async')]" in s
s=s.replace("[('warm','sync'),('warm','async')]","[('compile','sync')]")
(r/'measure.py').write_text(s,encoding='utf-8')
print('Existing five-case compile/allocation diagnostic prepared; exact frozen source/cores checked.')
