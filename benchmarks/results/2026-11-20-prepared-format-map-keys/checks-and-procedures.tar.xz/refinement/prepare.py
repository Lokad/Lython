from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
initial = lab.parent
notes = initial.parent
repo = lab.parents[4]
trial = repo / ".git/agent-worktrees/private-format-map-keys"
donor = notes / "private-abstract-snapshots/refined"
template = initial / "quiet"
core = "Lokad.Lython.dll"


def emit(path, text):
    if path.suffix == ".py":
        compile(text, str(path), "exec")
    path.write_text(text, encoding="utf-8", newline="\n")


def read(path):
    return path.read_text(encoding="utf-8")


def load(path):
    return json.loads(read(path))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, body):
    emit(path, json.dumps(body, indent=2) + "\n")


def git(*args, cwd=repo):
    return subprocess.check_output(["git", *args], cwd=cwd)


def retirement(remote, evidence, archive_dir=""):
    dir_path = f"benchmarks/results/{evidence}/"
    archive = git("cat-file", "blob", "HEAD:" + dir_path + archive_dir + "observations.tgz")
    receipt = json.loads(git("cat-file", "blob", "HEAD:" + dir_path + archive_dir + "archive-receipt.json"))
    source = dir_path + "measured-core.dll.gz"
    binary = gzip.decompress(git("cat-file", "blob", "HEAD:" + source))
    assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["guestFixturesRemoved"]
    assert receipt["archivedAndVerifiedUnderLease"] or (receipt["verifiedInRecoveryLease"] and receipt["rawMatchesPersistentRecords"])
    assert receipt["archiveSHA256"] == sha(archive)
    return dict(archivePath=f"{remote}/observations.tgz", canonicalArchiveSHA256=sha(archive),
                paths=[f"{remote}/candidate/{core}"], bytes=len(binary), links=1, sha256=sha(binary),
                verifiedCanonicalGitImage=source)


assert not git("status", "--porcelain", cwd=trial).strip()
reference = git("rev-parse", "HEAD^^", cwd=trial).decode().strip()
candidate = git("rev-parse", "HEAD", cwd=trial).decode().strip()
assert reference.startswith("b21a7ac4a") and candidate.startswith("a82bbee1d")
old = load(template / "config.json")
old_receipt = load(template / "archive-receipt.json")
assert old_receipt["complete"] and old_receipt["archivedAndVerifiedUnderLease"]
assert old_receipt["archiveSHA256"] == sha((template / "observations.tgz").read_bytes())
assert old["identity"]["sourceRevision"].split(" versus ")[0] == reference
old_image = old["identity"]["imageFiles"]["reference"]
assert len(old_image) == 32
assert {name: sha((initial / "frozen/reference" / name).read_bytes()) for name in old_image} == old_image
protocol = repo / "benchmarks/cpython-worker.py"
assert sha(protocol.read_bytes()) == old["protocolSHA256"]

manifest = lab / "representative.json"
shutil.copyfile(initial / manifest.name, manifest)
catalog_hash = sha(manifest.read_bytes())
assert catalog_hash == old["catalogSHA256"]
jobs = [(row["id"], "warm") for row in load(manifest)["cases"]]
assert len(jobs) == 2

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ["PATH"])
images = {}
for role in ("reference", "candidate"):
    image = lab / "frozen" / role
    image.mkdir(parents=True)
    for name in old_image:
        origin = trial / "src/Lokad.Lython/bin/Release/net11.0" / core if role == "candidate" and name == core else initial / "frozen/reference" / name
        shutil.copyfile(origin, image / name)
    hashes = {name: sha((image / name).read_bytes()) for name in old_image}
    verification = lab / f"{role}-verify.json"
    if role == "reference":
        shutil.copyfile(initial / verification.name, verification)
    else:
        subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", manifest,
                        "--dotnet", dotnet, "--python", "C:/Python313/python.exe", "--python-worker", protocol,
                        "--out", verification], env=env, check=True, timeout=100)
    result = load(verification)
    assert result["state"] == "Completed" and result["catalogSha256"] == catalog_hash
    for extra in (notes / "private-json-property-layout/frozen/candidate").glob("ValidatedAllocation.*"):
        shutil.copyfile(extra, image / extra.name)
    allocation = lab / f"{role}-allocation.json"
    if role == "reference":
        shutil.copyfile(initial / allocation.name, allocation)
    else:
        subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, manifest, allocation],
                       env=env, check=True, timeout=120)
    assert all(row["sharedBudgetBaselineRestored"] for row in load(allocation)["rows"])
    assert {name: sha((image / name).read_bytes()) for name in old_image} == hashes
    images[role] = hashes
assert images["reference"] == old_image
assert [name for name in old_image if images["candidate"][name] != old_image[name]] == [core]

location = "/home/lokad/lython-bench-checks/format-map-keys-b1237-20261120"
unit = "lython-b1237-format-map-keys-20261120"
q = lab / "quiet"
q.mkdir()
identity = dict(sourceRevision=reference + " versus " + candidate,
                purpose="Prepare UTF-8 top-level mapping selectors and reuse the bracket lookup path",
                imageFiles=images, catalogSHA256=catalog_hash, normalAdapterPin="0.4.0",
                coreSHA256={role + suffix: files[core] for role, files in images.items() for suffix in ("", "-control")})
save(q / "identity.json", identity)
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    content = read(template / name).replace(old["root"], location).replace(old["unit"], unit)
    if name == "collect.py":
        start = content.index("\njobs = ")
        end = content.index("\nassert len(jobs)", start)
        content = content[:start] + "\njobs = " + repr(jobs) + content[end:]
        content = content.replace("len(jobs)==3", "len(jobs)==2")
        content = content.replace("if job_index >= 2:", "if job_index == 0:")
        content = content.replace("accumulate 12 seconds", "accumulate 15 seconds").replace("warmupSeconds=12", "warmupSeconds=15")
        content = content.replace("min(warmed)<12", "min(warmed)<15").replace("warmed[i]>=12", "warmed[i]>=15")
    if name in ("archive-owned.py", "retrieve.py"):
        content = content.replace("==3", "==2").replace("jobs=3,", "jobs=2,")
    emit(q / name, content)
assert b"\r" not in (q / "run.sh").read_bytes()
(q / "candidate").mkdir()
shutil.copyfile(lab / "frozen/candidate" / core, q / "candidate" / core)
shutil.copyfile(manifest, q / "representative.json")
parts = ("identity.json", "representative.json", "collect.py", "archive-owned.py", "run.sh", "candidate/" + core)
with tarfile.open(q / "payload.tgz", "w:gz") as archive:
    for name in parts:
        archive.add(q / name, arcname=name)
retirements = [retirement("executable-class-suites-b1194-20261120", "2026-11-20-executable-class-suites")]
config = dict(root=location, unit=unit, source=old["root"], sourceRole="reference", sourceFiles=old_image,
              sourceCatalogSHA256=old["catalogSHA256"], protocolSHA256=old["protocolSHA256"], catalogSHA256=catalog_hash,
              identity=identity, retireGroups=retirements, donorArchiveSHA256=old_receipt["archiveSHA256"],
              payloadBytes=(q / "payload.tgz").stat().st_size, payloadSHA256=sha((q / "payload.tgz").read_bytes()),
              unpackedBytes=sum((q / name).stat().st_size for name in parts))
save(q / "config.json", config)
content = read(template / "remote-launch.py")
start = content.index("\nc=") + 1
end = content.index("\nb=Path(", start)
content = (content[:start] + "c=" + repr(config) + content[end:]).replace("lython-b1236-fixtures", "lython-b1237-fixtures")
assert "+64*1024*1024" in content
emit(q / "remote-launch.py", content)
emit(lab / "launch.py", read(initial / "launch.py").replace("seconds=245", "seconds=188").replace("245 seconds", "188 seconds"))
emit(lab / "summarize.py", read(initial / "summarize.py").replace("len(raw['jobs'])==3", "len(raw['jobs'])==2"))
print("Verified both frozen images and prepared two warm complete-script lanes.")
