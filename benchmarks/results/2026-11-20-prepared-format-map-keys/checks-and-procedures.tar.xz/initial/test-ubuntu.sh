set -eu
root=$PWD
lab=$root/.git/agent-notes/review-20261031/private-format-map-keys
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
cd "$root/.git/agent-worktrees/private-format-map-keys"
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 -p:RestoreLockedMode=true --no-incremental >"$lab/probe-ubuntu.log" 2>&1 || { tail -n 40 "$lab/probe-ubuntu.log"; exit 1; }
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    case "$suite" in
        Lokad.Lython.Tests) filter='FullyQualifiedName~Format|FullyQualifiedName~Dict|FullyQualifiedName~MemoryBudget|FullyQualifiedName~Cancellation';;
        *) filter='FullyQualifiedName~Format|FullyQualifiedName~StringMethodCompatibility|FullyQualifiedName~SharedMemory|FullyQualifiedName~Cancellation';;
    esac
    log="$lab/$suite-ubuntu.log"
    dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 -p:RestoreLockedMode=true --filter "Category!=Stress&($filter)" >"$log" 2>&1 || { tail -n 60 "$log"; exit 1; }
    tail -n 6 "$log"
done
