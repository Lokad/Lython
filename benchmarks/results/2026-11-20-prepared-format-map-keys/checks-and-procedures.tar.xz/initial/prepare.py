from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
notes = lab.parent
repo = lab.parents[3]
trial = repo / ".git/agent-worktrees/private-format-map-keys"
donor = notes / "private-abstract-snapshots/refined"
template = donor / "quiet"
core = "Lokad.Lython.dll"


def emit(path, text):
    if path.suffix == ".py":
        compile(text, str(path), "exec")
    path.write_text(text, encoding="utf-8", newline="\n")


def read(path):
    return path.read_text(encoding="utf-8")


def load(path):
    return json.loads(read(path))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, body):
    emit(path, json.dumps(body, indent=2) + "\n")


def git(*args, cwd=repo):
    return subprocess.check_output(["git", *args], cwd=cwd)


def retirement(remote, evidence, archive_dir=""):
    dir_path = f"benchmarks/results/{evidence}/"
    archive = git("cat-file", "blob", "HEAD:" + dir_path + archive_dir + "observations.tgz")
    receipt = json.loads(git("cat-file", "blob", "HEAD:" + dir_path + archive_dir + "archive-receipt.json"))
    source = dir_path + "measured-core.dll.gz"
    binary = gzip.decompress(git("cat-file", "blob", "HEAD:" + source))
    assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"] and receipt["archiveSHA256"] == sha(archive)
    return dict(archivePath=f"{remote}/observations.tgz", canonicalArchiveSHA256=sha(archive),
                paths=[f"{remote}/candidate/{core}"], bytes=len(binary), links=1, sha256=sha(binary),
                verifiedCanonicalGitImage=source)


assert not git("status", "--porcelain", cwd=trial).strip()
reference = git("rev-parse", "HEAD^", cwd=trial).decode().strip()
candidate = git("rev-parse", "HEAD", cwd=trial).decode().strip()
assert reference.startswith("b21a7ac4a") and candidate.startswith("f2a38804c")
old = load(template / "config.json")
old_receipt = load(template / "archive-receipt.json")
assert old_receipt["complete"] and old_receipt["archivedAndVerifiedUnderLease"]
assert old_receipt["archiveSHA256"] == sha((template / "observations.tgz").read_bytes())
assert not git("diff", "--name-only", old["identity"]["sourceRevision"].split(" versus ")[1], reference, "--", "src", "tests").strip()
old_image = old["identity"]["imageFiles"]["candidate"]
assert len(old_image) == 32
assert {name: sha((donor / "frozen/candidate" / name).read_bytes()) for name in old_image} == old_image
protocol = repo / "benchmarks/cpython-worker.py"
assert sha(protocol.read_bytes()) == old["protocolSHA256"]

catalog = load(notes / "private-json-property-layout/representative.json")
control = catalog["cases"][0]
assert control["id"] == "scripts.report-render.named-format-selectors.large"
mapping = dict(control)
mapping["id"] = "scripts.report-render.format-map.large"
original = "| {row[name]:<20.12s} | {row[state]:^8s} | {row[amount]:>8,d} "
replacement = "| {name:<20.12s} | {state:^8s} | {amount:>8,d} "
source = mapping["source"]
assert source.count(original) == source.count(".format(row=record)") == 1
source = source.replace(original, replacement).replace(".format(row=record)", ".format_map(record)")
mapping.update(source=source, sourceUtf8Bytes=len(source.encode("utf-8")), sourceSha256=sha(source.encode("utf-8")))
catalog["cases"] = [mapping, control]
manifest = lab / "representative.json"
emit(manifest, json.dumps(catalog, ensure_ascii=False, separators=(",", ":")) + "\n")
catalog_hash = sha(manifest.read_bytes())
jobs = [(mapping["id"], "warm"), (control["id"], "warm"), (mapping["id"], "compile-run")]

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ["PATH"])
images = {}
for role in ("reference", "candidate"):
    image = lab / "frozen" / role
    image.mkdir(parents=True, exist_ok=True)
    for name in old_image:
        origin = trial / "src/Lokad.Lython/bin/Release/net11.0" / core if role == "candidate" and name == core else donor / "frozen/candidate" / name
        assert sha(origin.read_bytes()) == sha((image / name).read_bytes())
    hashes = {name: sha((image / name).read_bytes()) for name in old_image}
    verification = lab / f"{role}-verify.json"
    result = load(verification)
    assert result["state"] == "Completed" and result["catalogSha256"] == catalog_hash
    allocation = lab / f"{role}-allocation.json"
    assert all(row["sharedBudgetBaselineRestored"] for row in load(allocation)["rows"])
    assert {name: sha((image / name).read_bytes()) for name in old_image} == hashes
    images[role] = hashes
assert images["reference"] == old_image
assert [name for name in old_image if images["candidate"][name] != old_image[name]] == [core]

location = "/home/lokad/lython-bench-checks/format-map-keys-b1236-20261120"
unit = "lython-b1236-format-map-keys-20261120"
q = lab / "quiet"
q.mkdir(exist_ok=True)
identity = dict(sourceRevision=reference + " versus " + candidate,
                purpose="Prepare UTF-8 top-level mapping selectors and reuse the bracket lookup path",
                imageFiles=images, catalogSHA256=catalog_hash, normalAdapterPin="0.4.0",
                coreSHA256={role + suffix: files[core] for role, files in images.items() for suffix in ("", "-control")})
save(q / "identity.json", identity)
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    content = read(template / name).replace(old["root"], location).replace(old["unit"], unit)
    if name == "collect.py":
        start = content.index("\njobs = ")
        end = content.index("\nassert len(jobs)", start)
        content = content[:start] + "\njobs = " + repr(jobs) + content[end:]
        content = content.replace("len(jobs)==4", "len(jobs)==3")
    if name in ("archive-owned.py", "retrieve.py"):
        content = content.replace("==4", "==3").replace("jobs=4,", "jobs=3,")
    emit(q / name, content)
assert b"\r" not in (q / "run.sh").read_bytes()
(q / "candidate").mkdir(exist_ok=True)
shutil.copyfile(lab / "frozen/candidate" / core, q / "candidate" / core)
shutil.copyfile(manifest, q / "representative.json")
parts = ("identity.json", "representative.json", "collect.py", "archive-owned.py", "run.sh", "candidate/" + core)
with tarfile.open(q / "payload.tgz", "w:gz") as archive:
    for name in parts:
        archive.add(q / name, arcname=name)
retirements = [retirement("funded-function-construction-confirmation-b1089-20261119", "2026-11-19-funded-function-construction", "confirmation/"),
               retirement("final-block-targets-confirmation-b1088-20261119", "2026-11-19-final-block-targets", "confirmation/")]
config = dict(root=location, unit=unit, source=old["root"], sourceRole="candidate", sourceFiles=old_image,
              sourceCatalogSHA256=old["catalogSHA256"], protocolSHA256=old["protocolSHA256"], catalogSHA256=catalog_hash,
              identity=identity, retireGroups=retirements, donorArchiveSHA256=old_receipt["archiveSHA256"],
              payloadBytes=(q / "payload.tgz").stat().st_size, payloadSHA256=sha((q / "payload.tgz").read_bytes()),
              unpackedBytes=sum((q / name).stat().st_size for name in parts))
save(q / "config.json", config)
content = read(template / "remote-launch.py")
start = content.index("\nc=") + 1
end = content.index("\nb=Path(", start)
content = (content[:start] + "c=" + repr(config) + content[end:]).replace("lython-b1234-fixtures", "lython-b1236-fixtures")
assert "+64*1024*1024" in content
emit(q / "remote-launch.py", content)
emit(lab / "launch.py", read(donor / "launch.py").replace("seconds=325", "seconds=245")
     .replace("Abstract branch-join comparison", "Format mapping comparison").replace("325 seconds", "245 seconds"))
emit(lab / "summarize.py", read(donor / "summarize.py").replace("len(raw['jobs'])==4", "len(raw['jobs'])==3"))
print("Verified both frozen images and prepared three short complete-script lanes.")
