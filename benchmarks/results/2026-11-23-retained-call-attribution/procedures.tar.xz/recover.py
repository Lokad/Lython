from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
failed=lab/"initial"
failed.mkdir(exist_ok=False)
for name in ("terminal-status.json","observations.tar.xz","retrieval.log","stage.log","launch.log",
             "ops-profile.py","quiet.py","observe-not-before","verification.json"):
    shutil.copyfile(lab/name,failed/name)
state=json.loads((failed/"terminal-status.json").read_text(encoding="utf-8"))
assert state["exitCode"]=="1" and state["receipt"]["allWorkersJoined"]
assert state["receipt"]["archivedAndVerifiedUnderLease"] and not state["fixtures"]
assert "bounded warmup did not finish" in state["journal"]
digest=state["receipt"]["archiveSHA256"]
assert hashlib.sha256((failed/"observations.tar.xz").read_bytes()).hexdigest()==digest
with tarfile.open(failed/"observations.tar.xz") as archive:
    record=json.load(archive.extractfile("profiles/supplied-warm/record.json"))
observed=sum(row["elapsedTicks"]/row["clockFrequency"] for row in record["warmupBatches"])
assert len(record["warmupBatches"])==128 and 4<observed<8 and record["count"]==128
print(f"Initial supplied warmup accumulated {observed:.3f} guest seconds across 128 batches")

def edit(name,replacements):
    text=(lab/name).read_text(encoding="utf-8")
    for old,new in replacements:
        assert old in text,(name,old)
        text=text.replace(old,new)
    compile(text,name,"exec")
    (lab/name).write_text(text,encoding="utf-8",newline="\n")
edit("ops-profile.py",[("        count = 128", '        count = 256 if name == "supplied-warm" else 128')])
edit("quiet.py",[
    ('root="/home/lokad/lython-bench-checks/retained-call-attribution-b1512-20261123"',
     'root="/home/lokad/lython-bench-checks/retained-call-attribution-b1512-20261123-corrected"'),
    ('unit="lython-b1512-retained-call-attribution-20261123"',
     'unit="lython-b1512-retained-call-attribution-20261123-corrected"'),
    ("bundle=sys.stdin.buffer.read()",f"initial=root.parent/'retained-call-attribution-b1512-20261123'/'observations.tar.xz'\nassert hashlib.sha256(initial.read_bytes()).hexdigest()=={digest!r}\nbundle=sys.stdin.buffer.read()"),
])
