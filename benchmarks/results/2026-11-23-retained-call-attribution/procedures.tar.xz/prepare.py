from pathlib import Path
import hashlib
import json
import shutil

lab=Path(__file__).resolve().parent
donor=lab.parent/"retained-short-text-cpu-20261123"
source=lab.parent/"retained-call-cpython-20261123"
read=lambda path:json.loads(path.read_text(encoding="utf-8"))
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
identity=read(source/"identity.json")
terminal=read(source/"terminal-status.json")
receipt=terminal["receipt"]
assert terminal["exitCode"]=="0" and receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
assert digest(source/"observations.tar.xz")==receipt["archiveSHA256"]
catalog=read(source/"representative.json")
jobs=[
    ("supplied-warm","scripts.ordinary-fully-supplied-helper","warm"),
    ("short-first-use","diagnostic.text-summary.nonlocal-computed-width.large","compile-run"),
    ("quoted-warm","scripts.csv-invoice.method-policy.quoted-control","warm"),
]
catalog["cases"]=[next(row for row in catalog["cases"] if row["id"]==case) for _,case,_ in jobs]
(lab/"catalog.json").write_text(json.dumps(catalog,indent=2,ensure_ascii=False)+"\n",encoding="utf-8",newline="\n")
identity.update(purpose="B1512 attribute supplied calls, short Unicode first use and quoted invoice on retained source",
                goldens=digest(lab/"catalog.json"))
(lab/"identity.json").write_text(json.dumps(identity,indent=2)+"\n",encoding="utf-8",newline="\n")

def install(name,replacements):
    text=(donor/name).read_text(encoding="utf-8")
    for old,new in replacements:
        assert old in text,(name,old)
        text=text.replace(old,new)
    compile(text,name,"exec")
    (lab/name).write_text(text,encoding="utf-8",newline="\n")

install("ops-profile.py",[
    ("[('nonlocal-warm', 'diagnostic.text-summary.nonlocal-computed-width.large', 'warm'), ('mixed-width-warm', 'diagnostic.text-summary.borrowed-cased-words.mixed-width', 'warm'), ('nonlocal-compile-run', 'diagnostic.text-summary.nonlocal-computed-width.large', 'compile-run')]",repr(jobs)),
])
install("collect.py",[
    ("short-text-source-pair-b1487-20261123/candidate","retained-call-cpython-b1510-20261123/candidate"),
    ("128*1024*1024","(108+4)*1024*1024"),("b1488-fixtures","b1512-fixtures"),
])
install("quiet.py",[
    ("retained-short-text-cpu-b1488-20261123-confirmation","retained-call-attribution-b1512-20261123"),
    ("lython-b1488-retained-short-text-cpu-20261123-confirmation","lython-b1512-retained-call-attribution-20261123"),
    ('lab.parent/"short-text-source-pair-20261123/candidate"', 'lab.parent/"retained-call-cpython-20261123/candidate"'),
    ("128*1024*1024","(108+4)*1024*1024"),
    ("from pathlib import Path\nimport fcntl,hashlib,io,shutil,subprocess,sys,tarfile\nroot=Path({root!r})",
     "from pathlib import Path\nimport fcntl,hashlib,io,shutil,subprocess,sys,tarfile\nroot=Path({root!r})\n"
     "prior=root.parent/'retained-call-cpython-b1510-20261123'/'observations.tar.xz'\n"
     f"assert hashlib.sha256(prior.read_bytes()).hexdigest()=={receipt['archiveSHA256']!r}"),
    ("Staged immutable short and mixed-width text inputs","Staged verified retained call-profile inputs"),
])
install("analyze.py",[
    ("['nonlocal-warm', 'mixed-width-warm', 'nonlocal-compile-run']",repr([j[0] for j in jobs])),
    ("     'native instruction dispatch':", "     'result publication': ('CompleteResultConsumer','PublishInstructionResult','PublishSlot','ForgetResultInput'),\n     'native instruction dispatch':"),
    ("'BindFunctionArgumentsInto','EnterFunctionCall'", "'BindFunctionArgumentsInto','TryStartSuppliedIntegerReturn','EnterFunctionCall'"),
])
shutil.copyfile(donor/"run.sh",lab/"run.sh")
assert b"\r" not in (lab/"run.sh").read_bytes()
