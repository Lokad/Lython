from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
pair = lab / 'comparison'
identity = json.loads((pair / 'identity.json').read_bytes())
sdk = Path.home() / '.dotnet11'
probe = lab.parent / 'module-surface-storage-b1947-20261128/probe/bin/Release/net11.0/ModuleProbe.dll'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
digest = lambda path: sha256(path.read_bytes()).hexdigest()

for role, files in identity['imageFiles'].items():
    assert {path.name: digest(path) for path in (pair / role).iterdir()} == files
cases = ('config.json', 'file.json')
for name in cases:
    assert digest(pair / name) == identity['catalogs'][name]['sha256']
witness = digest(probe)
samples = {case: {'reference': [], 'candidate': []} for case in cases}
for iteration in range(7):
    roles = ('reference', 'candidate') if iteration % 2 == 0 else ('candidate', 'reference')
    for case in cases:
        for role in roles:
            core = pair / role / 'Lokad.Lython.dll'
            assert digest(core) == identity['imageFiles'][role][core.name] and digest(probe) == witness
            item = json.loads(subprocess.check_output([sdk / 'dotnet.exe', probe, core, '--allocate', pair / case],
                cwd=lab, env=env, timeout=15))
            assert item['after'] == 0
            samples[case][role].append(item)

rows = []
for case, roles in samples.items():
    row = {name: [median(sample[name] for sample in roles[role]) for role in ('reference', 'candidate')]
        for name in ('allocated', 'admitted', 'after', 'elapsedMilliseconds')}
    assert row['admitted'][0] == row['admitted'][1] and row['after'] == [0, 0]
    rows.append(dict(case=case, **row))
    print(case, row)
report = dict(probeSHA256=witness, callerThreadClrBytes=samples, summary=rows, verifiedCompilations=28)
(lab / 'cold-allocation.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
