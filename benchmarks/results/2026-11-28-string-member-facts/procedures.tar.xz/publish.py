from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
out = lab.parents[3] / 'benchmarks/results/2026-11-28-string-member-facts'
pair = lab / 'comparison'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()

identity = read(pair / 'identity.json')
assert identity['sourcePatchSHA256'] == digest(lab / 'candidate.patch')
for role, files in identity['imageFiles'].items():
    assert {path.name: digest(path) for path in (pair / role).iterdir()} == files
assert read(pair / 'summary.json')['verifiedTimedBatches'] == 84
receipt = read(pair / 'archive-receipt.json')
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert receipt['archiveSHA256'] == digest(pair / 'observations.tar.xz')
cold = read(lab / 'cold-allocation.json')
assert cold['verifiedCompilations'] == 28
assert (lab / 'reference-contracts.json').read_bytes() == (lab / 'candidate-contracts.json').read_bytes()
contract = read(lab / 'reference-contracts.json')
assert contract['queries'] == 57408 and len(contract['rows']) == 962 and len(contract['returns']) == 596
assert len(contract['diagnostics']) == 21
for target in ('windows-net10', 'windows-net11', 'ubuntu-net11'):
    for suite, count in (('public', 502), ('whitebox', 545)):
        log = lab / (f'{target}-combined-whitebox.log' if target == 'windows-net11' and suite == 'whitebox'
            else f'{target}-{suite}.log')
        assert f'Passed: {count:5d}' in log.read_text(encoding='utf-8')
        assert 'Failed:     0' in log.read_text(encoding='utf-8')

out.mkdir(exist_ok=True)
files = {name: pair / name for name in ('identity.json', 'summary.json', 'observations.tar.xz')}
files['cold-allocation.json'] = lab / 'cold-allocation.json'
for name, path in files.items():
    copy2(path, out / name)
    assert digest(out / name) == digest(path)

procedures = {path.name: path for path in lab.iterdir() if path.is_file()
    and path.suffix in ('.log', '.py', '.patch')}
procedures.update({name: pair / name for name in ('reference-verify.json', 'candidate-verify.json',
    'exit-code.txt', 'archive-receipt.json', 'config.json', 'file.json')})
procedures.update({f'probe/{name}': lab / 'probe' / name for name in ('ContractProbe.csproj', 'Program.cs')})
procedures.update({f'{role}-contracts.json': lab / f'{role}-contracts.json' for role in ('reference', 'candidate')})
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in procedures.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    for name, path in procedures.items():
        assert sha256(archive.extractfile(name).read()).hexdigest() == digest(path)
print('Verified both worker images, matched observations and compilation receipts.')
