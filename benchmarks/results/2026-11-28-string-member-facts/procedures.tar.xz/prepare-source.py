from pathlib import Path
import re

lab = Path(__file__).resolve().parent
frontend = lab.parents[3] / 'src/Lokad.Lython/Frontend'
call_path = frontend / 'StaticContracts.CallableMembers.cs'
return_path = frontend / 'StaticContracts.MemberReturns.cs'
text_path = frontend / 'StaticContracts.StringMembers.cs'
calls = call_path.read_text(encoding='utf-8')
returns = return_path.read_text(encoding='utf-8')
assert not text_path.exists()


def replace(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


collect_text = re.compile(r'            AddStringCallableContract\(contracts, "([^\"]+)", (.+)\);\n')
found = collect_text.findall(calls)
shapes = dict(re.findall(r'\("([^\"]+)", (StaticReturnShape\.\w+)\),', returns))
assert len(found) == 60 and len(shapes) == 43
assert set(shapes) - {name for name, _ in found} == {'format'}
assert not any(re.search(r'AbstractValueKind\.String(?:Type)?,\s*"', path.read_text(encoding='utf-8'))
    for path in frontend.glob('StaticContracts.*Returns.*.cs'))

rows = []
for name, call in found:
    match = re.fullmatch(r'(\d+, \d+, "[^\"]+")(.*)', call)
    assert match, name
    arity_and_message, parameters = match.groups()
    rows.append(f'            Add("{name}", {arity_and_message}, {shapes.get(name, "null")}{parameters});')

call_source = '''using Lokad.Lython.Runtime;

namespace Lokad.Lython.Frontend;

internal static partial class StaticContracts
{
    private static class StringMemberCatalog
    {
        internal static readonly Dictionary<string, (StaticCallableContract? Call, StaticReturnShape? Return)> ByName = Create();

        private static Dictionary<string, (StaticCallableContract? Call, StaticReturnShape? Return)> Create()
        {
            var entries = new Dictionary<string, (StaticCallableContract?, StaticReturnShape?)>(61, StringComparer.Ordinal);
''' + '\n'.join(rows) + '''
            entries.Add("format", (null, StaticReturnShape.String));
            return entries;

            void Add(string name, int minimum, ArgumentCountLimit maximum, string message, StaticReturnShape? returns, params string[] parameters)
            {
                var call = parameters.Length == 0
                    ? new StaticCallableContract(AbstractValueKind.String, name, minimum, maximum, "LA3147", message)
                    : new StaticCallableContract(AbstractValueKind.String, name, minimum, maximum, "LA3147", message, parameterNames: parameters);
                entries.Add(name, (call, returns));
            }
        }
    }

    private static bool TryGetStringCallableContract(AbstractValueKind kind, string name, out StaticCallableContract contract)
    {
        if (StringMemberCatalog.ByName.TryGetValue(name, out var member) && member.Call is { } call)
        {
            contract = kind == AbstractValueKind.StringType ? call with { ReceiverKind = kind } : call;
            return true;
        }

        contract = default;
        return false;
    }
}
'''

calls = replace(calls, '        var catalog = kind switch',
    '''        if (kind is AbstractValueKind.String or AbstractValueKind.StringType)
            return TryGetStringCallableContract(kind, memberName, out contract);

        var catalog = kind switch''')
calls = collect_text.sub('', calls)
assert calls.count('AddStringCallableContract(') == 1
start = calls.index('        static void AddStringCallableContract(')
end = calls.index('        static void AddListCallableContracts(', start)
calls = calls[:start] + calls[end:]
calls = calls.replace('AddStringCallableContracts(', 'AddBytesCallableContracts(').replace('stringsAndLists', 'bytesAndLists')

start = returns.index('    private static (string MemberName, StaticReturnShape ReturnShape)[] GetStringMemberReturnShapes()')
end = returns.index('    private static class MemberReturnCatalog', start)
returns = returns[:start] + returns[end:]
returns = replace(returns, '        => MemberReturnCatalog.ByMember.TryGetValue(new(receiverKind, memberName), out shape);',
    '''    {
        if (receiverKind is AbstractValueKind.String or AbstractValueKind.StringType)
        {
            if (StringMemberCatalog.ByName.TryGetValue(memberName, out var member) && member.Return is { } returns)
            {
                shape = returns;
                return true;
            }

            shape = default;
            return false;
        }

        return MemberReturnCatalog.ByMember.TryGetValue(new(receiverKind, memberName), out shape);
    }''')
returns = replace(returns, '''        var strings = GetStringMemberReturnShapes();
        var shapes = new Dictionary<StaticMemberContractKey, StaticReturnShape>(core.Length + extended.Length + strings.Length * 2);''',
    '''        var shapes = new Dictionary<StaticMemberContractKey, StaticReturnShape>(core.Length + extended.Length);''')
returns = replace(returns, '''        foreach (var (memberName, shape) in strings)
        {
            shapes.Add(new(AbstractValueKind.String, memberName), shape);
            shapes.Add(new(AbstractValueKind.StringType, memberName), shape);
        }
''', '')

for path, content in ((call_path, calls), (return_path, returns), (text_path, call_source)):
    path.write_text(content, encoding='utf-8', newline='\n')
print('Moved 60 callable and 43 return declarations into 61 string member entries.')
