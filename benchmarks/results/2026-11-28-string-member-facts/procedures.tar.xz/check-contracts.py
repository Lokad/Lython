from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
donor = lab.parent / 'numeric-callable-catalog-b1928-20261128/probe'
probe = lab / 'probe'
probe.mkdir(exist_ok=True)
for name in ('ContractProbe.csproj', 'packages.lock.json'):
    copy2(donor / name, probe / name)
source = (donor / 'Program.cs').read_text(encoding='utf-8')
source = source.replace('var kinds =', 'var returnLookup = contracts.GetMethod("TryGetMemberReturnShape", all)!;\nvar kinds =')
source = source.replace('    if (type.GetField("ByMember", all)', '''    if (type.Name == "StringMemberCatalog" && type.GetField("ByName", all)?.GetValue(null) is IDictionary names)
        foreach (var name in names.Keys) catalogKeys.Add((string)name);
    if (type.GetField("ByMember", all)''')
source = source.replace('var rows = new List<object>();', 'var rows = new List<object>();\nvar returns = new List<object>();')
source = source.replace('        queries++;', '''        queries++;
        object?[] returnArguments = [kind, member, null];
        if ((bool)returnLookup.Invoke(null, returnArguments)!)
            returns.Add(new { receiver = kind.ToString(), member, shape = returnArguments[2]!.ToString() });''')
source = source.replace('rows.Add(new { receiver = kind.ToString(), member, code',
    'rows.Add(new { receiver = kind.ToString(), member, declared = Read(contract, "ReceiverKind")?.ToString(), code')
source = source.replace('    "return (5).bit_length(0)",', '''    "return ' x '.strip('x', 'y')",
    "return str.strip(' x ', chars='x')",
    "return 'x'.startswith()",
    "return str.startswith('xyz', prefix='x')",
    "return '{value}'.format(value=5).count('5')",
    "return 'x'.split(maxsplit=1).append()",
    "return 'x'.find('a').bit_length(1)",
    "return 'x'.encode().decode()",
    "return 'x'.replace(old='x', new='a')",
    "return 'x'.__add__('y')",
    "return (5).bit_length(0)",''')
source = source.replace('members = catalogKeys.Count, rows, diagnostics', 'members = catalogKeys.Count, rows, returns, diagnostics')
(probe / 'Program.cs').write_text(source, encoding='utf-8', newline='\n')

sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
with (lab / 'probe-build.log').open('wb') as log:
    subprocess.run([dotnet, 'build', probe / 'ContractProbe.csproj', '-c', 'Release'], env=env,
        check=True, timeout=60, stdout=log, stderr=subprocess.STDOUT)
program = probe / 'bin/Release/net11.0/ContractProbe.dll'
pair = lab / 'comparison'
identity = json.loads((pair / 'identity.json').read_bytes())
outputs = []
for role, image in identity['imageFiles'].items():
    folder = pair / role
    assert {path.name: sha256(path.read_bytes()).hexdigest() for path in folder.iterdir()} == image
    output = lab / f'{role}-contracts.json'
    subprocess.run([dotnet, program, folder / 'Lokad.Lython.dll', output], env=env, check=True, timeout=20)
    outputs.append(output)
assert outputs[0].read_bytes() == outputs[1].read_bytes()
data = json.loads(outputs[0].read_bytes())
assert len(data['diagnostics']) == 21
assert any(row['member'] == 'format' and row['receiver'] == 'String' for row in data['returns'])
assert not any(row['member'] == 'format' and row['receiver'] == 'String' for row in data['rows'])
print(data['queries'], 'queries per surface', len(data['rows']), 'matching call results and',
    len(data['returns']), 'matching return results', len(data['diagnostics']), 'compiler cases')
