from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output, run
import json

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.parent / 'builtin-name-slots-b1964-20261128/comparison'
control = lab.parent / 'numeric-callable-catalog-b1928-20261128/comparison'
pair = lab / 'comparison'
core = 'Lokad.Lython.dll'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0' / core
new_source = 'src/Lokad.Lython/Frontend/StaticContracts.StringMembers.cs'
reference = 'ad1bfd7c7'
read = lambda path: json.loads(path.read_bytes())
digest = lambda data: sha256(data).hexdigest()
hash_file = lambda path: digest(path.read_bytes())
hashes = lambda directory: {path.name: hash_file(path) for path in directory.iterdir()}


def git(*args):
    return check_output(['git', *args], cwd=repo)


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


old = read(donor / 'identity.json')
reference = git('rev-parse', reference).decode().strip()
assert not git('diff', reference, 'HEAD', '--', 'src')
assert digest(git('diff', '--binary', old['referenceRevision'], reference, '--', 'src', 'tests')) == old['sourcePatchSHA256']
assert git('ls-files', '--others', '--exclude-standard', '--', 'src').decode().splitlines() == [new_source]
new_file = run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', new_source], cwd=repo, capture_output=True)
assert new_file.returncode == 1 and b'new file mode ' in new_file.stdout
patch = git('diff', '--binary', reference, '--', 'src') + new_file.stdout
assert patch.count(b'diff --git ') == 3
(lab / 'candidate.patch').write_bytes(patch)

frozen = old['imageFiles']['candidate']
assert len(frozen) == 32 and hashes(donor / 'candidate') == frozen
pair.mkdir()
for role in ('reference', 'candidate'):
    copytree(donor / 'candidate', pair / role)
copy2(build, pair / 'candidate' / core)
assert not (pair / 'candidate' / core).samefile(build)
images = {role: hashes(pair / role) for role in ('reference', 'candidate')}
assert images['reference'] == frozen
assert {name for name, checksum in images['candidate'].items() if frozen[name] != checksum} == {core}

jobs = [['scripts.config-edit.small', 'compile'], ['diagnostic.file-search-first-line', 'compile'],
    ['diagnostic.generated-guarded-report', 'compile']]
cases = {}
for directory in (donor, control):
    identity = read(directory / 'identity.json')
    catalog_path = directory / 'representative.json'
    assert hash_file(catalog_path) == identity['catalogs']['representative.json']['sha256']
    catalog = read(catalog_path)
    cases.update({case['id']: case for case in catalog['cases']})
catalog['cases'] = [cases[case] for case, _ in jobs]
save(pair / 'representative.json', catalog)
save(pair / 'jobs.json', {'warm': jobs})
for name in ('cpython-worker.py', 'collect.py', 'run.sh'):
    copy2(donor / name, pair / name)
assert hash_file(pair / 'cpython-worker.py') == old['cpythonWorkerSHA256']
assert b'\r' not in (pair / 'run.sh').read_bytes()

payloads = {'config.json': jobs[0][0], 'file.json': jobs[1][0]}
for name, case in payloads.items():
    save(pair / name, dict(catalog, cases=[cases[case]]))
save(pair / 'identity.json', dict(sourceRevision=reference, referenceRevision=reference,
    sourcePatchSHA256=digest(patch), imageFiles=images,
    coreSHA256={role + suffix: image[core] for role, image in images.items() for suffix in ('', '-control')},
    expectedCPythonSHA256=old['expectedCPythonSHA256'], cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    catalogs={name: {'sha256': hash_file(pair / name)} for name in ('representative.json', 'jobs.json', *payloads)},
    purpose='Consolidate frontend String and StringType callable/return metadata on one shared table.'))
copy2(donor.parent / 'summarize.py', lab / 'summarize.py')
print(reference, 'two verified copies with only the core DLL changed')
