using System.Numerics;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.Tests;

public sealed class LoopLocalAdmissionTests
{
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(2)]
    public void LocalWorkingStorageRefusesOrCancelsWithoutStrandingAllowance(int failure)
    {
        var budget = new LythonMemoryBudget(1024 * 1024);
        using (var owner = budget.CreateScope())
        using (var cancellation = new CancellationTokenSource())
        {
            var gate = new AdmissionHookMemoryBudget(owner);
            var context = new LythonRuntime.ExecutionContext(new MockLythonHost(),
                new() { MemoryBudget = gate, CancellationToken = cancellation.Token });
            var span = new LythonSourceSpan(0, 1, 1, 1);
            var frontend = LythonFrontend.Compile("""
                def fold(values):
                    total=0
                    for value in values:total+=value
                    return total
                """);
            Assert.DoesNotContain(frontend.Diagnostics, d => d.Severity == LythonDiagnosticSeverity.Error);
            var code = ExecutableScript.Compile(LoweredScript.Lower(frontend.Script!)).EntryPoint;
            LythonRuntime.ExecuteExecutableCodeObject(code, context);
            var function = Assert.IsType<PyExecutableFunction>(context.Variables["fold"]);
            var input = new PyTuple(new object[] { BigInteger.One, new BigInteger(2), new BigInteger(3) }, context.MemoryGovernor, span);
            var callFrontend = LythonFrontend.Compile("fold(values)");
            var call = Assert.Single(ExecutableScript.Compile(LoweredScript.Lower(callFrontend.Script!)).EntryPoint.CallSites);
            var bound = function.BindCallOperands([input], span, context, null, call);
            try
            {
                var baseline = budget.ReservedBytes;
                if (failure == 1) gate.AfterGrowth = _ => cancellation.Cancel();
                if (failure == 2) gate.RefuseGrowth = _ => true;
                if (failure == 0)
                {
                    Assert.True(function.TryStartBoundInvocation(bound, span, false, default,
                        out _, out var value, out var frame));
                    Assert.Null(frame);
                    Assert.Equal(new BigInteger(6), value);
                }
                else
                {
                    var error = Assert.Throws<LythonRuntimeException>(() => function.TryStartBoundInvocation(
                        bound, span, false, default, out _, out _, out _));
                    Assert.Equal(failure == 1 ? LythonFailureReason.Cancelled : LythonFailureReason.SharedMemoryAllowance,
                        error.Attribution?.Reason);
                    if (failure == 2) Assert.Same(context.MemoryGovernor.AdmissionFailure, error);
                }
                Assert.Equal(baseline, budget.ReservedBytes);
                Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
                Assert.Equal(0, context.State.CurrentInterpreterDepth);
                Assert.Equal(0, context.State.CurrentRecursionDepth);
            }
            finally
            {
                LythonRuntime.ReturnBoundArguments(bound, function.CodeObject.ValueStorageCapacity);
                context.State.CloseResources();
            }
        }
        Assert.Equal(0, budget.ReservedBytes);
    }
}
