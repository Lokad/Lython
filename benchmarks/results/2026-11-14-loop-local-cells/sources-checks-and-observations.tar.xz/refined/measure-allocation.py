from pathlib import Path
import hashlib,json,os,statistics,subprocess,time
r=Path(__file__).parent;identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));env=dict(os.environ);originalPath=next(v for k,v in env.items()if k.casefold()=='path');env={k:v for k,v in env.items()if k.casefold()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+originalPath;sdk=env['DOTNET_ROOT']+'/dotnet.exe'
fixture=r/'allocation-fixtures';fixture.mkdir();env['TEMP']=str(fixture.resolve());env['TMP']=str(fixture.resolve());start=time.monotonic()
records=[]
for role,index in [('reference',0),('candidate',0),('candidate',1),('reference',1)]:
 assert time.monotonic()-start<100
 folder=(r/role).resolve();assert hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
 out=r/(role+'-allocation-'+str(index)+'.json');assert not out.exists()
 log=r/(role+'-allocation-'+str(index)+'.log')
 with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,str(folder/'Allocation.dll'),str(folder),str((r/('allocation-'+role+'-catalog.json')).resolve()),str(out.resolve())],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=30)
 assert done.returncode==0,log.read_text(encoding='utf-8')[-2000:]
 d=json.loads(out.read_text(encoding='utf-8'));records.append(dict(role=role,index=index,data=d));print(role,index,[(v['id'],statistics.median(v['allocatedBytesPerInvocation']))for v in d['rows']],flush=True)
assert not list(fixture.iterdir());fixture.rmdir()
summary=[]
for case in records[0]['data']['rows']:
 values={role:[statistics.median(next(v for v in rec['data']['rows']if v['id']==case['id'])['allocatedBytesPerInvocation'])for rec in records if rec['role']==role]for role in ['reference','candidate']}
 summary.append(dict(case=case['id'],processMedians=values,allocatedByteChangePercent=sorted(100*(a/b-1)for a in values['candidate']for b in values['reference'])))
(r/'allocation-summary.json').write_text(json.dumps(dict(complete=True,identity=identity,elapsedSeconds=time.monotonic()-start,summary=summary,allGoldensAndBudgetBaselineChecksPassed=True,allWorkersJoinedAndFixturesRemoved=True,cpuOrElapsedImprovementNotMeasured=True, sourceAndScriptDifferIntentionally=False, roleCatalogSHA256={role:hashlib.sha256((r/('allocation-'+role+'-catalog.json')).read_bytes()).hexdigest()for role in['reference','candidate']}),indent=2)+'\n',encoding='utf-8',newline='\n')
print(summary)
