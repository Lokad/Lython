from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;refined=r/'refined';identity=json.loads((refined/'candidate-identity.json').read_text(encoding='utf-8'));baseline=json.loads((r.parent/'machine-integer-kernel-r357/nonthrowing/candidate-identity.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert all(sha(n)==v for n,v in identity['sources'].items());terminal=json.loads((refined/'b733/terminal-status.json').read_text(encoding='utf-8'));assert terminal['receipt']['complete']and terminal['receipt']['jobs']==8 and not terminal['remainingWorkers']and not terminal['remainingTrace']
with tarfile.open(refined/'prototype-snapshot-before-withdrawal.tar.xz','w:xz')as t:
 for n in identity['sources']:t.add(n,arcname=n)
 for n in ['tests/Lokad.Lython.PublicApi.Tests/LoopLocalValueTests.cs','tests/Lokad.Lython.Tests/LoopLocalAdmissionTests.cs']:t.add(n,arcname=n)
(refined/'production-before-withdrawal.patch').write_bytes(subprocess.check_output(['git','diff','--','src']))
reason=dict(status='Withdraw complete heap-cell local prototype; retain independent public behavior/bounded-working-set tests. No fixed percentage veto or claim that deferral cannot work.',candidate=identity['coreSHA256']['candidate'],baseline=identity['coreSHA256']['reference'],evidence='B733all8jobs304.959s/gates. Numeric elapsed−13.87..−11.01%/CPU−14.79..−10.95%, allocation−57.23%; CSVwhile warm−14.04..−10.64%/fresh−11.37..−9.69%, allocation−13.41%. But fulfillment+3.78..+6.00%/CPU+3.51..+7.33%, JSON+1.25..+2.19%/CPU+1.40..+4.15%, short-zero+39.94..+43.14%/CPU+39.35..+43.23%, observed+4.47..+9.65%/CPU+4.85..+12.17%. Text−2.03..+1.13%/CPU−4.00..+0.80%uncertain.',decision='Per-invocation heap cells/reservation and shared reader dispatch add material ordinary-helper overhead despite useful loop gains. Retire this mechanism rather than add cell pools, promotion thresholds, adaptive modes or another unchanged retiming. Data supports a cheaper coherent private value-transport design, not automatic promotion.',retire='DeferredLocalSlots heap-cell preparation/charges, per-call temporary cell reservation/initialization, cell-aware global reader changes and typed dispatch additions specific to prototype. Restore all581production inputs to qualified47df/cbb2. Delete white-box test that assumes this discarded native per-call cell reservation; its runtime refusal/cancellation guarantees remain covered by established arithmetic/native/async tests. Preserve public alias/type/error/locals/wide-helper/20kbounded execution cases.',next='R359bounded design/prototype: managed primitive working values alongside existing final object slots/direct calls, with stable materialization on observation/alias copies and exact promotion. Eliminate heap cells and per-call grants for small native working values; admit substantial frame storage/overlap through existing owner. Inspect local-read/promotion boundaries first; no universal guest-type rewrite or argument-copy backend.',publicationHeld=True,performanceObjectiveStillActive=True)
(refined/'withdrawal.json').write_text(json.dumps(reason,indent=2)+'\n',encoding='utf-8',newline='\n')
restore=[]
for n in identity['changedProductionInputs']:
 # The HEAD delivery commit changes documentation only from qualified47df.
 committed=subprocess.check_output(['git','show','HEAD:'+n])
 # Restore the exact frozen baseline bytes, including its original newlines.
 with tarfile.open(r.parent/'machine-integer-kernel-r357/nonthrowing/candidate-sources.tar.xz')as t:body=t.extractfile(n).read()
 assert hashlib.sha256(body).hexdigest()==baseline['sources'][n]
 assert committed.replace(b'\r\n',b'\n')==body.replace(b'\r\n',b'\n')
 Path(n).write_bytes(body);restore.append(n)
assert all(sha(n)==v for n,v in baseline['sources'].items())
test=Path('tests/Lokad.Lython.Tests/LoopLocalAdmissionTests.cs');shutil.copyfile(test,refined/'discarded-native-cell-admission-test.cs');test.unlink()
(refined/'restoration.json').write_text(json.dumps(dict(productionInputs=581,restored=restore,baseline='47df7e19/cbb254be',allFrozenInputHashesMatch=True,publicConformanceTestsRetained=True,forcedRebuildPending=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('R358runtime withdrawn; all581production bytes restored to qualified47df/cbb2. Independent public tests retained; forced rebuild/checks next.')
