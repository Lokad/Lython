from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,tempfile
r=Path(__file__).parent;prior=r.parent/'machine-integer-kernel-r357/nonthrowing';sha=lambda b:hashlib.sha256(b).hexdigest()
catalog=json.loads((prior/'catalog.json').read_text(encoding='utf-8'));old=json.loads((r.parent/'literal-checkpoint-r352/retrieved/representative.json').read_text(encoding='utf-8'));base=catalog['cases'][0]
validation=dict(next(c for c in old['cases']if c['id']=='scripts.csv-check-digits.for-text.large'))
original='def digit_sum(value):\n    total=0\n    for character in value:\n        total+=int(character)\n    return total'
replacement='def digit_sum(text):\n    value=int(text)\n    total=0\n    while value>0:\n        total+=value%10\n        value//=10\n    return total'
assert original in validation['source'];validation['source']=validation['source'].replace(original,replacement)
validation.update(id='diagnostic.csv-check-digits.while.large',sourceSha256=sha(validation['source'].encode()),sourceUtf8Bytes=len(validation['source'].encode()))
json_case=next(c for c in old['cases']if c['id']=='scripts.json-summary-helpers.large')
catalog['cases']=[base,validation,next(c for c in catalog['cases']if c['id']=='scripts.csv-fulfillment.large'),next(c for c in catalog['cases']if c['id']=='scripts.text-summary-helpers.nonlocal-counter.large'),json_case]
controls=[
 ('short-zero',4096,"def fold(values):\n    total=0\n    for value in values:total+=value\n    return total\nchecksum=0\nfor ordinal in range(4096):checksum+=fold(())+fold((1,))\nprint(checksum)\n"),
 ('observed',1024,"def fold(values):\n    total=0\n    observed=[]\n    for value in values:\n        total+=value\n        observed.append(total)\n    return total,observed\nchecksum=0\nfor ordinal in range(1024):\n    total,values=fold((1,2,3))\n    checksum+=total+sum(values)\nprint(checksum)\n")]
for name,size,source in controls:
 done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],capture_output=True,check=True);output=done.stdout.decode().replace('\r\n','\n')
 case=dict(base);fixture=json.dumps(dict(size=size,text='',inputFiles={},outputFiles={}),separators=(',',':'))
 case.update(id='diagnostic.loop-helper.'+name+'.large',category='loop-local-overhead-control',size=size,source=source,fixtureJson=fixture,expectedOutput=output,sourceUtf8Bytes=len(source.encode()),expectedOutputUtf8Bytes=len(output.encode()),sourceSha256=sha(source.encode()),fixtureSha256=sha(fixture.encode()),expectedOutputSha256=sha(output.encode()))
 catalog['cases'].append(case)
assert len(catalog['cases'])==7
(r/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8',newline='\n')
subset=dict(catalog);subset['cases']=[validation];(r/'allocation-csv-catalog.json').write_text(json.dumps(subset,indent=2)+'\n',encoding='utf-8',newline='\n')
spec=importlib.util.spec_from_file_location('protocol',r.parent/'utf8-byte-ownership-r334/b705/retrieved/cpython-worker.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['PATH']=os.environ.get('PATH','');env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
identity=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'));rows=[]
for role in ['CPython','reference','candidate']:
 for case in catalog['cases']:
  image=prior/'candidate'if role=='reference'else r/'diagnostic-candidate'
  command=['C:/Python313/python.exe','-I','-S','-X','utf8',str((r.parent/'utf8-byte-ownership-r334/b705/retrieved/cpython-worker.py').resolve()),'--catalog',str((r/'catalog.json').resolve())]if role=='CPython'else[env['DOTNET_ROOT']+'/dotnet.exe',str((image/'Lokad.Lython.Benchmarks.dll').resolve()),'--compare','worker','--catalog',str((r/'catalog.json').resolve())]
  with tempfile.TemporaryDirectory(prefix='lython-comparison-files-')as folder:
   p=subprocess.Popen(command,cwd=folder,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   try:
    ready=protocol.read_frame(p.stdout);assert ready and ready['status']=='Ready'
    if role!='CPython':assert next(v['sha256'].lower()for v in ready['libraries']if Path(v['path']).name=='Lokad.Lython.dll')==identity[role]
    request={k:case[k]for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']};request.update(protocolVersion=2,requestId=1,operation='verify',caseId=case['id'],lane='warm',iterations=2)
    protocol.write_frame(p.stdin,request);response=protocol.read_frame(p.stdout);assert response['status']=='Equivalent',response
    assert response['actualOutputSha256']==case['expectedOutputSha256']and response['actualFilesSha256']==case['expectedFilesSha256']
    protocol.write_frame(p.stdin,dict(protocolVersion=2,requestId=2,operation='quit'));assert protocol.read_frame(p.stdout)['status']=='Closed';assert p.wait(timeout=15)==0 and not p.stderr.read()
    rows.append(dict(role=role,case=case['id'],ready=ready,response=response));(r/'catalog-worker-verification.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
   finally:
    if p.poll()is None:p.kill();p.wait()
    p.stdin.close();p.stdout.close();p.stderr.close()
 print(role,'seven cases equivalent, all outputs/files/budgets verified.',flush=True)
for role,image in [('reference',prior/'candidate'),('candidate',r/'diagnostic-candidate')]:
 output=r/('csv-allocation-'+role+'.json');assert not output.exists()
 with(r/('csv-allocation-'+role+'.log')).open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',str((image/'Allocation.dll').resolve()),str(image.resolve()),str((r/'allocation-csv-catalog.json').resolve()),str(output.resolve())],stdout=f,stderr=subprocess.STDOUT,env=env,timeout=30)
 assert done.returncode==0,(r/('csv-allocation-'+role+'.log')).read_text(encoding='utf-8')[-1500:]
 print(role,json.loads(output.read_text(encoding='utf-8'))['rows'],flush=True)
