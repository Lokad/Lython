from pathlib import Path
import json,subprocess
r=Path(__file__).parent
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
b=Path('/home/lokad/lython-bench-checks').resolve()
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 paths=sorted((p for p in b.glob('*/observations.tgz')if p.is_file()),key=lambda p:p.stat().st_size,reverse=True)[:14]
 print(json.dumps(dict(freeBytes=shutil.disk_usage(b).free,idleLease=True,archives=[dict(path=p.relative_to(b).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in paths]),indent=2))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=30);assert p.returncode==0,p.stderr
(r/'vm-space-inspection.json').write_text(p.stdout,encoding='utf-8',newline='\n');print(p.stdout)
