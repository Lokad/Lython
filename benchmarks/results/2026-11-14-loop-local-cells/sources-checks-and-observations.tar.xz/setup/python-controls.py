from pathlib import Path
import hashlib,json,os,re,subprocess,textwrap
r=Path(__file__).parent;body=Path('tests/Lokad.Lython.PublicApi.Tests/LoopLocalValueTests.cs').read_text(encoding='utf-8')
snippets=[textwrap.dedent(s)+'\n'for s in re.findall(r'yield return \["""\n(.*?)\n\s*"""\];',body,re.S)];assert len(snippets)==9,len(snippets)
parameters=','.join('p'+str(i)for i in range(18));arguments=','.join(str(i)for i in range(18))
snippets.append(f"def fold(values,{parameters}):\n    total=0\n    for value in values:total+=value\n    return total,p17\nassert fold((1,2,3),{arguments})==(6,17)\nprint('ok')\n")
(r/'python-control-sources.json').write_text(json.dumps(snippets,indent=2)+'\n',encoding='utf-8',newline='\n')
env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['PATH']=os.environ.get('PATH','');env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';probe=Path('tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll').resolve();rows=[]
for asynchronous in [False,True]:
 done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',str(probe),'--batch-json','--compare-python','--python','C:/Python313/python.exe']+(['--async']if asynchronous else[]),input=json.dumps(snippets).encode(),capture_output=True,env=env,timeout=30)
 (r/('python-controls-'+str(asynchronous)+'.jsonl')).write_bytes(done.stdout);(r/('python-controls-'+str(asynchronous)+'.stderr')).write_bytes(done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode('utf-8');rows.append(dict(asynchronous=asynchronous,cases=10,matched=True,exitCode=0))
(r/'python-controls.json').write_text(json.dumps(dict(complete=True,python='Isolated stockCPython3.13.2',cases=rows,coreSHA256=hashlib.sha256((probe.parent/'Lokad.Lython.dll').read_bytes()).hexdigest(),sourceSHA256=hashlib.sha256((r/'python-control-sources.json').read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8',newline='\n')
print('20independent Python controls match both APIs: snapshots/aliases/promotion, lists/bools/floats/protocols, locals alias, unbound/zero loops, wide owned helper.')
