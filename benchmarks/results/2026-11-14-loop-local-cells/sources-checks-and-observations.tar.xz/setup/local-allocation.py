from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;reference=r.parent/'machine-integer-kernel-r357/nonthrowing';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();original=json.loads((reference/'candidate-identity.json').read_text(encoding='utf-8'));sources={n:sha(n)for n in original['sources']};changed=[n for n,v in sources.items()if v!=original['sources'][n]];assert len(changed)==10,changed
env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+os.environ.get('PATH','')
with(r/'diagnostic-build.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0 and sources=={n:sha(n)for n in sources}
image=r/'diagnostic-candidate';shutil.copytree(reference/'candidate',image);shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',image/'Lokad.Lython.dll')
catalog=json.loads((reference/'catalog.json').read_text(encoding='utf-8'));catalog['cases']=[c for c in catalog['cases']if c['id']=='diagnostic.loop-range.inside.large'];assert len(catalog['cases'])==1
(r/'diagnostic-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8',newline='\n')
identity=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),reference=original['coreSHA256']['candidate'],candidate=sha(image/'Lokad.Lython.dll'),sources=sources,changedProductionInputs=changed,diagnosticOnly=True,fullQualification='R35743593185490GREEN applies to baseline only; prototype excluded.')
(r/'diagnostic-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for role,folder in [('reference',reference/'candidate'),('candidate',image)]:
 target=r/('diagnostic-allocation-'+role+'.json')
 with(r/('diagnostic-allocation-'+role+'.log')).open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',str((folder/'Allocation.dll').resolve()),str(folder.resolve()),str((r/'diagnostic-catalog.json').resolve()),str(target.resolve())],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=30)
 assert done.returncode==0,(r/('diagnostic-allocation-'+role+'.log')).read_text(encoding='utf-8')[-1500:]
 print(role,json.loads(target.read_text(encoding='utf-8'))['rows'],flush=True)
