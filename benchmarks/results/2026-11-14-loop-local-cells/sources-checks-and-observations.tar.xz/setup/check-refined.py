from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent;out=r/'refined';out.mkdir(exist_ok=True);env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+os.environ.get('PATH','');sdk=env['DOTNET_ROOT']+'/dotnet.exe';records=[]
filters={
 'internal':'FullyQualifiedName~LoopLocalAdmissionTests|FullyQualifiedName~CapturedScalar|FullyQualifiedName~NativeIntegerChainTests|FullyQualifiedName~IntegerBinaryAdmissionTests|FullyQualifiedName~ExecutableAugmentedIntegerBoundaryTests',
 'public':'(Category!=Stress)&(FullyQualifiedName~Integer|FullyQualifiedName~NumericArithmetic|FullyQualifiedName~CounterArithmetic|FullyQualifiedName~ForHelperExecutionTests|FullyQualifiedName~WhileHelperExecutionTests|FullyQualifiedName~LargeHelperExecutionTests|FullyQualifiedName~OperatorProtocol|FullyQualifiedName~CapturedScalarExecutionTests|FullyQualifiedName~NativeTupleReturnTests|FullyQualifiedName~LoopLocalValueTests|FullyQualifiedName~UnboundLocalVariableTests)'}
for framework in ['net11.0','net10.0']:
 for label in ['internal','public']:
  project='Lokad.Lython.Tests'if label=='internal'else'Lokad.Lython.PublicApi.Tests'
  command=[sdk,'test','tests/'+project+'/'+project+'.csproj','-c','Release','-f',framework,'--no-restore','--filter',filters[label],'--logger','trx;LogFileName=r358-refined-'+label+framework+'.trx','-v','quiet']
  with(out/(label+'-'+framework+'.log')).open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
  records.append(dict(framework=framework,label=label,returncode=done.returncode));(out/'focused-checks.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n')
  assert done.returncode==0,(out/(label+'-'+framework+'.log')).read_text(encoding='utf-8')[-2000:]
  print(label,framework,'pass',flush=True)
