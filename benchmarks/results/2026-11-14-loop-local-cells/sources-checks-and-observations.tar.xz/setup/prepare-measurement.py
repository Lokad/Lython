from pathlib import Path
import ast,base64,datetime,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;stage=r/'refined';out=stage/'b733';out.mkdir(exist_ok=False);old=r.parent/'machine-integer-kernel-r357/nonthrowing/b732'
source=json.loads((stage/'candidate-identity.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert all(sha(p)==v for p,v in source['sources'].items())
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'));identity.update(sourceRevision='R358uncommitted/frozen97f5ecc1 vs fully qualified47df7e19/frozencbb254be',purpose='Deferred loop-local integer publication and primitive reads: complete counter/CSVwhile warm/fresh, fulfillment/text/JSON and short-zero/observed overhead controls. Identical source/data per runtime; CSVwhile variant is diagnostic. Allocation separate, no CPython/startup/tail claim.',coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},catalogSHA256=sha(stage/'catalog.json'),fullSourceIdentitySHA256=sha(stage/'candidate-identity.json'),publicationHeld=True)
assert all(source['auxiliaryFiles'][role][n]==v for role in ['reference','candidate']for n,v in identity['auxiliaryFiles'].items())
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['diagnostic.loop-range.inside.large','warm'],['diagnostic.csv-check-digits.while.large','warm'],['diagnostic.csv-check-digits.while.large','compile-run'],['scripts.csv-fulfillment.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.json-summary-helpers.large','warm'],['diagnostic.loop-helper.short-zero.large','warm'],['diagnostic.loop-helper.observed.large','warm']]
ids={c['id']for c in json.loads((stage/'catalog.json').read_text(encoding='utf-8'))['cases']};assert len(jobs)==8 and all(case in ids for case,lane in jobs)
root='/home/lokad/lython-bench-checks/loop-locals-b733-20261114';unit='lython-b733-loop-locals-20261114'
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(old/name).read_text(encoding='utf-8').replace('machine-kernel-b732-20261114','loop-locals-b733-20261114').replace('lython-b732-machine-kernel-20261114',unit).replace('B732','B733')
 if name=='collect.py':
  start=s.index('jobs=');end=s.index('\nenv =',start);s=s[:start]+'jobs='+repr(jobs)+"\nassert len(jobs)==8 and all(case in cases for case,lane in jobs)\n"+s[end:];s=s.replace('started < 240','started < 360');assert 'control_catalog'not in s
 elif name=='archive-owned.py':s=s.replace("len(raw['jobs'])==4","len(raw['jobs'])==8").replace('jobs=4','jobs=8')
 elif name=='retrieve.py':s=s.replace("['jobs']==4","['jobs']==8").replace("['elapsedSeconds']<300","['elapsedSeconds']<420")
 elif name=='summarize.py':s=s.replace("len(raw['jobs'])==4","len(raw['jobs'])==8").replace('jobs=4','jobs=8')
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for n in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/n,arcname=n)
 t.add(stage/'candidate-core.dll',arcname='candidate-core.dll');t.add(stage/'catalog.json',arcname='representative.json')
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
def canonical(path,member):
 p=Path(path);blob=subprocess.check_output(['git','show',head+':'+p.as_posix()]);assert hashlib.sha256(blob).hexdigest()==sha(p)
 with tarfile.open(fileobj=io.BytesIO(blob),mode='r:xz')as t:body=t.extractfile(member).read()
 return dict(commit=head,canonicalArchive=p.as_posix(),archiveSHA256=sha(p),member=member,bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
proof=canonical('benchmarks/results/2026-11-14-owned-native-tuple-returns/sources-checks-and-allocation.tar.xz','candidate-core.dll');assert proof['sha256'].startswith('9cfb7d5b');proof.update(coreSHA256=proof['sha256'],reason='Retire only superseded9cfb working-core hardlinks; all exact binary/source/evidence bytes retained canonically. Keep currentcbb2/new97f5, auxiliaries/catalogs/toolchains and254/252MiBfloors.')
duplicate=canonical('benchmarks/results/2026-11-08-inline-utf8/observations.tar.xz','final-comparison/observations.tgz');duplicate['remote']='inline-text-b436-20261108/observations.tgz';assert duplicate['sha256']=='e212d90052b63d5fd73db84df1ea550ccd8b3ed8ace5f733a2846414c34927c0'
config=dict(root=root,sourceRoot='/home/lokad/lython-bench-checks/machine-kernel-b732-20261114',unit=unit,identity=identity,proof=proof,duplicates=[duplicate],payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=sha(out/'payload.tgz'),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
code=(old/'launch-command.py').read_text(encoding='utf-8');start=code.index('c=');end=code.index('\nbase=',start);code=code[:start]+'c='+repr(config)+code[end:]
code=code.replace("source/'reference'","source/'candidate'").replace("source/'reference/Lokad.Lython.dll'","source/'candidate/Lokad.Lython.dll'")
code=code.replace("os.link(source/'representative.json',root/'representative.json');","")
code=code.replace('b732-proved-superseded-core-retirement-20261114','b733-proved-superseded-working-copy-retirement-20261114').replace('lython-b732-fixtures','lython-b733-fixtures').replace('RuntimeMaxSec=300','RuntimeMaxSec=420').replace('R357 final four-job source pair launched under300second owner','R358eight-job source pair launched under420second owner')
ast.parse(code);(out/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
prospective=dict(purpose=identity['purpose'],source=identity['sourceRevision'],jobs=jobs,bound='One420sowner/360sjob-startguard;5sfull-request warmup/12scaptured text;five0.5srotating batches/four fresh processes. Existing workers/protocol/normalGC/tiering. No automatic restart or qualification campaign.',retirement='Canonical Git/all-alias proof before removing only superseded9cfb working hardlinks and duplicate completed B436raw archive. Currentcbb2/new97f5 and all auxiliary/catalog/toolchain/floors preserved.',stopping='One usable source pair with all controls/failed/adverse conditions. Decide complete migration retention/regression debt, not a percentage veto. Full platform/package follows only retention; publication held.',initialAdversity='638CSVwhile allocation+4.47percent retained; refined primitive read path now−13.41percent allocation, counter−57.23percent. No CPU inferred.')
(out/'prospective.json').write_text(json.dumps(prospective,indent=2)+'\n',encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],input=(out/'payload.tgz').read_bytes(),capture_output=True,timeout=60);(out/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc);(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=360)).isoformat(),ownerSeconds=420),indent=2)+'\n',encoding='utf-8',newline='\n')
print(done.stdout.decode(),flush=True);print('Earliest observation',(now+datetime.timedelta(seconds=360)).isoformat(),flush=True)
