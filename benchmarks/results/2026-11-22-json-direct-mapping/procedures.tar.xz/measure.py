from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
notes = lab.parent
donor = notes / "json-ascii-emission-20261122"
reference = donor / "inline-frozen/candidate"
core = "Lokad.Lython.dll"
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ["PATH"])

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def save(path, contents):
    path.write_text(json.dumps(contents, indent=2) + "\n", encoding="utf-8", newline="\n")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

base = load(notes/"expanded-builtin-span/representative.json")
control = load(donor/"inline-catalog.json")["cases"][-1]
assert [case["id"] for case in base["cases"]] == ["scripts.json-lines-shipment.expanded-options.large",
    "scripts.json-lines-shipment.explicit-options.large","scripts.report-forwarding.expanded"]
assert control["id"] == "calls.positional.large"
base["cases"].append(control)
catalog = lab / "representative.json"
save(catalog, base)
protocol = repo / "benchmarks/cpython-worker.py"
source = load(donor / "inline-images.json")
previous = source["imageFiles"]["candidate"]
assert len(previous) == 32 and {name: sha(reference / name) for name in previous} == previous
trial = repo / ".git/agent-worktrees/json-direct-mapping-20261122"
revision = subprocess.check_output(["git", "-C", trial, "rev-parse", "HEAD"], text=True).strip()
parent = subprocess.check_output(["git", "-C", trial, "rev-parse", "HEAD^"], text=True).strip()
assert parent == source["candidate"]
assert not subprocess.check_output(["git", "-C", trial, "status", "--porcelain", "--untracked-files=no"])
candidate = lab / "windows-image-build/bin/Lokad.Lython/release_net11.0" / core
frozen = {}
for role in ("reference", "candidate"):
    image = lab / "frozen" / role
    image.mkdir(parents=True)
    for name in previous:
        source_file = candidate if name == core and role == "candidate" else reference / name
        shutil.copyfile(source_file, image / name)
    for extra in reference.glob("ValidatedAllocation.*"):
        shutil.copyfile(extra, image / extra.name)
    hashes = {name: sha(image / name) for name in previous}
    verified = lab / f"{role}-verification.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", catalog,
                    "--dotnet", dotnet, "--python", "C:/Python313/python.exe", "--python-worker", protocol,
                    "--out", verified], check=True, env=env, timeout=100)
    proof = load(verified)
    assert proof["state"] == "Completed" and proof["catalogSha256"] == sha(catalog)
    allocation = lab / f"{role}-allocation.json"
    subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, catalog, allocation],
                   check=True, env=env, timeout=100)
    assert all(row["sharedBudgetBaselineRestored"] for row in load(allocation)["rows"])
    assert {name: sha(image / name) for name in previous} == hashes
    frozen[role] = hashes
assert frozen["reference"] == previous
assert [name for name in previous if frozen["reference"][name] != frozen["candidate"][name]] == [core]
save(lab / "images.json", dict(imageFiles=frozen, reference=parent, candidate=revision, catalogSHA256=sha(catalog),
                               protocolSHA256=sha(protocol), sourcePatchSHA256=sha(lab / "source.patch")))
rows = []
left, right = [load(lab / f"{role}-allocation.json")["rows"] for role in ("reference", "candidate")]
for before, after in zip(left, right, strict=True):
    assert before["id"] == after["id"]
    a, b = [statistics.median(row["allocatedBytesPerInvocation"]) for row in (before, after)]
    p, q = [row["peakExecutionMemoryBytes"] for row in (before, after)]
    rows.append(dict(case=before["id"], allocatedBefore=a, allocatedAfter=b, allocationChange=100 * (b / a - 1),
                     admittedBefore=p, admittedAfter=q, budgetReturnedToBaseline=True))
save(lab / "allocation-summary.json", rows)
for row in rows:
    print(row, flush=True)
