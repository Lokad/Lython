from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
notes = lab.parent
prior = notes / "json-ascii-emission-20261122"
template = prior / "quiet"
out = lab / "quiet"
vm = "/home/lokad/lython-bench-checks"

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path, content):
    if path.suffix == ".py":
        compile(content, str(path), "exec")
    path.write_text(content, encoding="utf-8", newline="\n")

def digest(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    return digest(path.read_bytes())

def pushed(path):
    return subprocess.check_output(["git", "show", "origin/master:benchmarks/results/" + path], cwd=repo)

inventory = load(lab/"inventory.json")
catalog_inventory = load(lab/"catalog-inventory.json")
archives = {
    "mixed-factory-boundaries-b1374-20261122": "2026-11-22-mixed-factory-boundaries",
    "native-direct-integer-return-refined-b1372-20261122": "2026-11-22-native-direct-integer-return-refined",
    "direct-integer-return-cpython-b1373-20261122": "2026-11-22-direct-integer-return-cpython",
    "json-outer-frame-b1375-20261122": "2026-11-22-json-outer-frame",
}
assert set(inventory["archives"]) == {name + "/observations.tgz" for name in archives}
retire = [{name:inventory[name] for name in ("paths","links","bytes","sha256","archives")}]
for name, result in archives.items():
    raw = pushed(result + "/observations.tgz")
    receipt = json.loads(pushed(result + "/archive-receipt.json"))
    path = name+"/observations.tgz"
    assert digest(raw) == inventory["archives"][path] == receipt["archiveSHA256"]
    assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["archivedAndVerifiedUnderLease"]
    if name in ("mixed-factory-boundaries-b1374-20261122","direct-integer-return-cpython-b1373-20261122"):
        info = catalog_inventory[path]
        assert info["links"]==1 and info["bytes"]==len(raw) and info["sha256"]==digest(raw)
        retire.append(dict(info, paths=[path], archives={}))
canonical = gzip.decompress(pushed(archives["native-direct-integer-return-refined-b1372-20261122"]+"/candidate-core.dll.gz"))
assert digest(canonical) == inventory["sha256"] and len(canonical) == inventory["bytes"]

config = load(template/"config.json")
receipt = load(template/"archive-receipt.json")
assert all(receipt[n] for n in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
assert sha(template/"observations.tgz") == receipt["archiveSHA256"]
verified = load(lab/"images.json")
files = verified["imageFiles"]
core = "Lokad.Lython.dll"
assert files["reference"] == config["identity"]["imageFiles"]["candidate"]
assert files["reference"][core] == inventory["current"]
for role, expected in files.items():
    assert len(expected) == 32
    assert {name:sha(lab/"frozen"/role/name) for name in expected} == expected
    proof = load(lab/f"{role}-verification.json")
    assert proof["state"] == "Completed" and proof["caseCount"] == 4 and proof["catalogSha256"] == verified["catalogSHA256"]
assert verified["protocolSHA256"] == config["protocolSHA256"]

sources={
    "expansion.json": ("expanded-builtin-span-b1260-20261121/representative.json",
                       notes/"expanded-builtin-span/quiet/representative.json"),
    "positional.json": ("json-outer-frame-b1375-20261122/representative.json", template/"representative.json"),
}
dotnet=Path.home()/".dotnet11/dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent),
         PATH=str(dotnet.parent)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
catalogs={}
job_catalog={}
original = {case["id"]:case for case in load(lab/"representative.json")["cases"]}
for leaf,(path,local) in sources.items():
    assert sha(local)==catalog_inventory[path]["sha256"]
    for role in files:
        image=lab/"frozen"/role
        evidence=lab/f"{role}-{leaf}"
        subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",local,
            "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",evidence],
            env=env,check=True,timeout=85)
        proof=load(evidence)
        assert proof["state"]=="Completed" and proof["catalogSha256"]==sha(local)
    entries=load(local)["cases"]
    for case in entries:
        case_id=case["id"]
        if case_id not in original or (leaf=="positional.json" and case_id!="calls.positional.large"):continue
        assert case == original[case_id],case_id
        job_catalog[case_id]=leaf
    catalogs[leaf]=dict(path=vm+"/"+path,sha256=sha(local))
assert len(job_catalog)==len(original)==4

out.mkdir()
root=vm + "/json-direct-mapping-b1376-20261122"
unit="lython-b1376-json-direct-mapping-20261122"
identity=dict(sourceRevision=verified["reference"]+" versus "+verified["candidate"],
              purpose="Bind exact JSON keyword mappings directly in final option storage",
              imageFiles=files, normalAdapterPin="0.4.0", catalogs=catalogs,
              coreSHA256={role+suffix: hashes[core] for role,hashes in files.items() for suffix in ("","-control")})
write(out/"identity.json",json.dumps(identity,indent=2)+"\n")
jobs=[(i,"warm") for i in original]
for name in ("collect.py","archive-owned.py","run.sh","retrieve.py"):
    source=(template/name).read_text(encoding="utf-8").replace(config["root"],root).replace(config["unit"],unit)
    source=source.replace("B1375","B1376")
    if name=="collect.py":
        start,end=source.index("\njobs = "),source.index("\nassert len(jobs)")
        source=source[:start]+"\njob_catalog = "+repr(job_catalog)+"\njobs = "+repr(jobs)+source[end:]
        source=source.replace("catalog = root / 'representative.json'","catalog = root / 'expansion.json'")
        source=source.replace("assert len(jobs)==4 and all(case in cases for case,lane in jobs)",
                              "assert len(jobs)==4 and all(case in job_catalog for case,lane in jobs)")
        source=source.replace("catalog = root/'representative.json'","catalog = root/job_catalog[case_id]")
        source=source.replace("        manifest_hash=hashlib.sha256(catalog.read_bytes()).hexdigest()",
            "        manifest_hash=hashlib.sha256(catalog.read_bytes()).hexdigest()\n"
            "        assert manifest_hash==identity['catalogs'][catalog.name]['sha256']\n"
            "        cases={case['id']:case for case in json.loads(catalog.read_text())['cases']}")
    write(out/name,source)
assert b"\r" not in (out/"run.sh").read_bytes()
(out/"candidate").mkdir()
shutil.copyfile(lab/"frozen/candidate"/core,out/"candidate"/core)
parts=("identity.json","collect.py","archive-owned.py","run.sh","candidate/"+core)
payload=out/"payload.tgz"
with tarfile.open(payload,"w:gz") as archive:
    for name in parts:
        archive.add(out/name,arcname=name)
unpacked=sum((out/name).stat().st_size for name in parts)
assert inventory["free"]+sum(group["bytes"] for group in retire)>176160768+unpacked+640*1024
stage=dict(root=root,unit=unit,identity=identity,source=config["root"],sourceRole="candidate",
           sourceFiles=files["reference"],sourceCatalogSHA256=config["catalogSHA256"],
           donorArchiveSHA256=receipt["archiveSHA256"],protocolSource=config["root"]+"/cpython-worker.py",
           protocolSHA256=config["protocolSHA256"],payloadBytes=payload.stat().st_size,
           payloadSHA256=sha(payload),retireGroups=retire, catalogs=catalogs,unpackedBytes=unpacked)
write(out/"config.json",json.dumps(stage,indent=2)+"\n")
remote=(template/"remote-launch.py").read_text(encoding="utf-8")
start,end=remote.index("\nc=")+1,remote.index("\nb=Path(")
remote=remote[:start]+"c="+repr(stage)+remote[end:]
start,end=remote.index(" # The unchanged frozen catalog"),remote.index(" for n in ['collect.py'")
remote=remote[:start]+""" for leaf,witness in c['catalogs'].items():
  source_catalog=Path(witness['path'])
  assert source_catalog.resolve()==source_catalog and source_catalog.is_relative_to(b)
  assert sha(source_catalog)==witness['sha256']
  os.link(source_catalog,root/leaf)
  assert sha(root/leaf)==witness['sha256']
"""+remote[end:]
write(out/"remote-launch.py",remote.replace("lython-b1375-fixtures","lython-b1376-fixtures"))
write(lab/"launch.py",(prior/"launch-inline.py").read_text(encoding="utf-8")
      .replace("JSON outer frame comparison","Direct JSON keyword mapping comparison"))
write(lab/"summarize.py",(prior/"summarize-inline.py").read_text(encoding="utf-8"))
print("Staged four verified workloads by reusing two immutable catalogs and verified exact archive duplicates.")
