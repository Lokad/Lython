from pathlib import Path
import re
import textwrap

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
suite = repo / "tests/Lokad.Lython.PublicApi.Tests/JsonRecordShapeTests.cs"
source = suite.read_text(encoding="utf-8")
body = textwrap.dedent(re.search(r'const string copiedAndMutated = """\n(.*?)\n\s*""";', source, re.S).group(1))
expected = re.search(r'const string copiedAndMutatedResult = """(.*?)""";', source).group(1)
actual_source = "def guest():\n" + textwrap.indent(body, "    ") + "\nassert guest() == " + repr(expected) + "\nprint(guest())\n"
(lab / "cpython-regression.py").write_text(actual_source, encoding="utf-8", newline="\n")
