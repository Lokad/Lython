from pathlib import Path
import gzip, hashlib, io, json, os, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
base = lab.parent
repo = lab.parents[3]
quiet = lab / 'quiet'
donor = base / 'sparse-lexical-work-20261122'
template = base / 'current-compiler-csv-cpython-20261122'
previous = base / 'compiled-literal-defaults-keywords-20261122'
core = 'Lokad.Lython.dll'

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def hash_bytes(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    return hash_bytes(path.read_bytes())

def emit(path, content):
    if path.suffix == '.py': compile(content, str(path), 'exec')
    path.write_text(content, encoding='utf-8', newline='\n')

def save(path, obj, compact=False):
    emit(path, json.dumps(obj, ensure_ascii=False, indent=None if compact else 2,
                           separators=(',', ':') if compact else None) + '\n')

def rev(ref):
    return subprocess.check_output(['git','rev-parse',ref],cwd=repo,text=True).strip()

# Use the tested retained CSV source image or a new nonincremental combined image.
selected = load(lab/'input-identity.json')
production = rev(selected['production'])
measured = rev(selected['measured'])
assert production == rev('origin/master') == rev('HEAD')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
subprocess.run(['git','diff','--exit-code',production,measured,'--','src','tests','benchmarks/Lokad.Lython.Benchmarks'],cwd=repo,check=True)
assert sha(lab/'measured-core.dll') == selected['coreSHA256']
source_cfg = load(donor/'quiet/config.json')
source_receipt = load(donor/'quiet/archive-receipt.json')
assert source_receipt['complete'] and source_receipt['archivedAndVerifiedUnderLease']
assert sha(donor/'quiet/observations.tgz') == source_receipt['archiveSHA256']
source_files = source_cfg['identity']['imageFiles']['candidate']
source_image = donor/'frozen/candidate'
assert len(source_files) == 32 and {n:sha(source_image/n) for n in source_files} == source_files
protocol = repo/'benchmarks/cpython-worker.py'
assert sha(protocol)==source_cfg['protocolSHA256']
image = lab/'frozen'
image.mkdir()
for name in source_files:
    shutil.copyfile(lab/'measured-core.dll' if name==core else source_image/name,image/name)
files = {name:sha(image/name) for name in source_files}
assert files[core]==selected['coreSHA256'] and all(h==source_files[name] for name,h in files.items() if name!=core)

quiet.mkdir()
manifest = quiet/'representative.json'
catalog = load(base/'csv-compiled-unpack-20261122/representative.json')
quote = load(base/'csv-quoted-ranges-20261122/quiet/representative.json')
literal = load(previous/'representative.json')
meter='scripts.csv-meter-report.typed-ascii'
explicit='scripts.csv-meter-report.explicit-float'
invoice='scripts.csv-invoice.method-policy.quoted-control'
factory='scripts.annotated-rule-closures.literal-positional-dynamic-keyword'
candidates = {case['id']:case for case in catalog['cases']+quote['cases']+literal['cases']}
ids=[meter,explicit,invoice]+([factory] if selected['includeLiteralDefaults'] else [])
catalog['cases']=[candidates[name] for name in ids]
save(manifest,catalog,compact=True)
lanes=[(meter,'warm'),(explicit,'warm'),(invoice,'warm'),(meter,'compile'),(meter,'compile-run')]
if selected['includeLiteralDefaults']: lanes.extend(((factory,'warm'),(factory,'compile-run')))
assert set(name for name,_ in lanes)==set(ids)

sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
proof=lab/'verify.json'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',manifest,
    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',proof],
    cwd=repo,env=env,check=True,timeout=95)
check=load(proof)
assert check['state']=='Completed' and check['caseCount']==len(ids) and check['catalogSha256']==sha(manifest)
assert {name:sha(image/name) for name in files}==files

# The VM can discard these duplicate inputs only after their canonical evidence is verified.
retire=[]

def retired_copy(local, artifact_name, names):
    ref='origin/master:benchmarks/results/'+artifact_name+'/'
    frozen=lambda name: subprocess.check_output(['git','show',ref+name],cwd=repo)
    q=base/local/'quiet'
    cfg=load(q/'config.json'); receipt=load(q/'archive-receipt.json')
    archive=frozen('observations.tgz')
    assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease'] and hash_bytes(archive)==receipt['archiveSHA256']
    folder=Path(cfg['root']).name
    for name in names:
        if name=='representative.json':
            data=(q/name).read_bytes()
            assert hash_bytes(data)==cfg['catalogSHA256']
            with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as container:
                assert any(Path(member.name).name==name and member.isfile() and container.extractfile(member).read()==data for member in container.getmembers())
        else:
            assert name=='candidate/'+core
            data=gzip.decompress(frozen('candidate-core.dll.gz'))
            assert hash_bytes(data)==cfg['identity']['imageFiles']['candidate'][core]
        retire.append(dict(paths=[folder+'/'+name],bytes=len(data),links=1,sha256=hash_bytes(data),
                    archives={folder+'/observations.tgz':receipt['archiveSHA256']},optional=False))

retired_copy('compiled-literal-defaults-keywords-20261122','2026-11-22-compiled-literal-defaults-keywords',['candidate/'+core])
retired_copy('csv-direct-slots-shared-pull-20261122','2026-11-22-csv-direct-slots-shared-pull',['representative.json'])
retired_copy('csv-direct-slots-20261122','2026-11-22-csv-direct-slots',['representative.json'])
retired_copy('csv-unpublished-row-unpack-20261122','2026-11-22-csv-unpublished-row-unpack',['representative.json'])

identity=dict(sourceRevision=measured,productionEquivalent=production,imageSource=measured,
    purpose='Retained CSV fixed unpack checkpoint against stock CPython',imageFiles=dict(candidate=files),
    catalogSHA256=sha(manifest),cpythonWorkerSHA256=sha(protocol),auxiliaryFiles={n:h for n,h in files.items() if n!=core},
    coreSHA256={label:files[core] for label in ('candidate','candidate-control')})
save(quiet/'identity.json',identity)
root='/home/lokad/lython-bench-checks/retained-csv-cpython-b1327-20261122'
unit='lython-b1327-retained-csv-cpython-20261122'
old=load(template/'quiet/config.json')
for name in ('collect.py','archive-owned.py','run.sh','retrieve.py'):
    source=(template/'quiet'/name).read_text(encoding='utf-8').replace(old['root'],root).replace(old['unit'],unit).replace('B1316','B1327')
    if name=='collect.py':
        start=source.index('    for case_id,lane in '); end=source.index('        assert time.monotonic()',start)
        source=source[:start]+f'    for case_id,lane in {lanes!r}:\n'+source[end:]
        assert '-started<345' in source
        source=source.replace('-started<345','-started<460')
    if name=='archive-owned.py': source=source.replace("len(raw['jobs'])==6",f"len(raw['jobs'])=={len(lanes)}").replace('jobs=6,',f'jobs={len(lanes)},')
    if name=='retrieve.py': source=source.replace("['jobs']==6",f"['jobs']=={len(lanes)}")
    emit(quiet/name,source)
assert b'\r' not in (quiet/'run.sh').read_bytes()
(quiet/'candidate').mkdir()
shutil.copyfile(image/core,quiet/'candidate'/core)
parts=('identity.json','representative.json','collect.py','archive-owned.py','run.sh','candidate/'+core)
payload=quiet/'payload.tgz'
with tarfile.open(payload,'w:gz') as archive:
    for name in parts: archive.add(quiet/name,arcname=name)
config=dict(root=root,unit=unit,identity=identity,source=source_cfg['root'],sourceRole='candidate',
    sourceFiles=source_files,sourceCatalogSHA256=source_cfg['catalogSHA256'],donorArchiveSHA256=source_receipt['archiveSHA256'],
    catalogSHA256=identity['catalogSHA256'],retireGroups=retire,cpythonWorkerSHA256=identity['cpythonWorkerSHA256'],
    payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),unpackedBytes=sum((quiet/name).stat().st_size for name in parts))
save(quiet/'config.json',config)
remote=(template/'quiet/remote-launch.py').read_text(encoding='utf-8')
a,b=remote.index('\nc=')+1,remote.index('\nb=Path(')
remote=remote[:a]+'c='+repr(config)+remote[b:]
emit(quiet/'remote-launch.py',remote.replace('lython-b1316-fixtures','lython-b1327-fixtures').replace('RuntimeMaxSec=430','RuntimeMaxSec=510'))
launch=(template/'launch.py').read_text(encoding='utf-8')
wait='435' if selected['includeLiteralDefaults'] else '325'
emit(lab/'launch.py',launch.replace('B1316 compiler and CSV checkpoint against CPython','B1327 retained CSV checkpoint against CPython').replace('390',wait))
print(f'Prepared {len(lanes)} short lanes and checked {len(ids)} CPython goldens for {production}.')
