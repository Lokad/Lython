from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess

lab=Path('.git/agent-notes/review-20261031/prepared-yield-facts-r689')
base=lab.parent
class_binding=base/'shared-class-bindings-r687'
generator=base/'generator-workspace-r688'
trial='.git/agent-worktrees/prepared-yield-facts-r689'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,d:p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
git=lambda *args:subprocess.check_output(['git',*args])
ref=git('rev-parse','c577a7662').decode().strip()
candidate=git('-C',trial,'rev-parse','HEAD').decode().strip()
assert not git('-C',trial,'status','--porcelain')
assert not git('diff','--name-only','5e1cc5f5b',ref,'--','src','tests')
src=git('diff','--binary',ref,candidate,'--','src','tests')
assert src.count(b'diff --git ')==5
(lab/'source.patch').write_bytes(src)

comparisons=load(generator/'catalog.json')
cases=[dict(id=row['id'],source=row['source']) for row in comparisons['cases']
       if row['id']!='scripts.csv-invoice.large']
additional=load(class_binding/'compile-catalog.json')['cases']
cases.extend(case for case in additional if case['id'] in ('NestedClosuresAndGeneratorsEscape',
             'scripts.config-generated-guards.medium','scripts.config-manifest.small'))
assert len(cases)==7
write(lab/'compile-catalog.json',dict(cases=cases))

baseline=class_binding/'frozen/candidate'
manifest=load(class_binding/'frozen-identity.json')['images']['candidate']
assert len(manifest)==4 and {name:sha(baseline/name) for name in manifest}==manifest
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
core='Lokad.Lython.dll'
compiled=lab/'build/bin/Lokad.Lython/release_net11.0'/core
images={}
for role in ('reference','candidate'):
    frozen=lab/'compile-frozen'/role
    frozen.mkdir(parents=True,exist_ok=True)
    expected=manifest.copy()
    for name in expected:
        origin=compiled if role=='candidate' and name==core else baseline/name
        shutil.copyfile(origin,frozen/name)
        expected[name]=sha(origin)
    assert {name:sha(frozen/name) for name in expected}==expected
    with (lab/(role+'-compile-allocation.log')).open('wb') as log:
        subprocess.run([sdk/'dotnet.exe',frozen/'CompileAllocation.dll', lab/'compile-catalog.json',
                        lab/(role+'-compile-allocation.json')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    assert {name:sha(frozen/name) for name in expected}==expected
    images[role]=expected
assert images['reference'][core]!=images['candidate'][core]
write(lab/'compile-frozen-identity.json',dict(referenceCommit=ref,candidateCommit=candidate,
     catalogSHA256=sha(lab/'compile-catalog.json'), images=images))
for role in ('reference','candidate'):
    data=load(lab/(role+'-compile-allocation.json'))
    print(role, str(data)[:280])