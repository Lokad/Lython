from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

repo=Path.cwd()
lab=repo/'.git/agent-notes/review-20261031/prepared-yield-facts-r689'
donor=lab.parent/'generator-workspace-r688'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
src=donor/'frozen/reference'
frozen=lab/'verify-image'
frozen.mkdir(exist_ok=True)
core='Lokad.Lython.dll'
template=load(donor/'frozen-identity.json')['images']['reference']
assert len(template)==32 and {n:sha(src/n) for n in template}==template
expected=template|{core:load(lab/'compile-frozen-identity.json')['images']['candidate'][core]}
for name in expected:
    shutil.copyfile((lab/'compile-frozen/candidate' if name==core else src)/name, frozen/name)
assert {n:sha(frozen/n) for n in expected}==expected
catalog=lab/'verify-catalog.json'
shutil.copyfile(donor/'catalog.json',catalog)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'worker-verify.log').open('wb') as log:
    subprocess.run([dotnet,frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog,
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',repo/'benchmarks/cpython-worker.py',
        '--out',lab/'worker-verify.json'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
result=load(lab/'worker-verify.json')
assert result['state']=='Completed' and result['catalogSha256']==sha(catalog)
assert {n:sha(frozen/n) for n in expected}==expected
(lab/'verify-identity.json').write_text(json.dumps(expected,indent=2)+'\n',encoding='utf-8')
print('All five goldens passed on the exact 32-file candidate image.')