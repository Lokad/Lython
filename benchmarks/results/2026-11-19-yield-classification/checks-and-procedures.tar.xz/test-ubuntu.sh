export DOTNET_ROOT=~/.dotnet
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/prepared-yield-facts-r689
filter='(FullyQualifiedName~Generator|FullyQualifiedName~SyntaxValidity|FullyQualifiedName~PostponedAnnotation|FullyQualifiedName~PreparedFunction|FullyQualifiedName~ComprehensionLambda|FullyQualifiedName~CompilationCancellation)&Category!=Stress'
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
    log="$lab/$suite-ubuntu.log"
    ~/.dotnet/dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" >"$log" 2>&1
    result=$?
    tail -n 8 "$log"
    if test "$result" -ne 0; then exit "$result"; fi
done