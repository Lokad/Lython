set -eu
lab="$PWD/.git/agent-notes/review-20261031/synchronous-private-cursor-cleanup-20261125"
worktree="$PWD/.git/agent-worktrees/synchronous-private-cursor-cleanup-20261125"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
 log="$lab/ubuntu-net10-$suite.log"
 filter='(FullyQualifiedName~Iterable|FullyQualifiedName~Iteration|FullyQualifiedName~Iterator|FullyQualifiedName~Generator|FullyQualifiedName~Csv|FullyQualifiedName~Math|FullyQualifiedName~Typing|FullyQualifiedName~Functools|FullyQualifiedName~FnMatch|FullyQualifiedName~ElementTree|FullyQualifiedName~Subprocess|FullyQualifiedName~Comprehension|FullyQualifiedName~Pkgutil|FullyQualifiedName~Sorted|FullyQualifiedName~ListConstruction|FullyQualifiedName~NativeAnyAll|FullyQualifiedName~Aggregate|FullyQualifiedName~Cursor|FullyQualifiedName~Sum|FullyQualifiedName~Zip|FullyQualifiedName~ExecutableAsync)&Category!=Stress'
 if "$DOTNET_ROOT/dotnet" test "$worktree/tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
     tail -3 "$log"
 else
     tail -48 "$log"
     exit 1
 fi
done