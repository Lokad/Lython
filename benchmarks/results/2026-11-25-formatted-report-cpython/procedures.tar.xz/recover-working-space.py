from pathlib import Path
import hashlib
import json
import subprocess

lab=Path(__file__).resolve().parent
donor=lab.with_name("single-formatted-field-scan-confirmation-20261125")
q=donor/"comparison/quiet"
identity=json.loads((q/"identity.json").read_text(encoding="utf-8"))
receipt=json.loads((q/"terminal-status.json").read_text(encoding="utf-8"))
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not receipt["live"] and not receipt["fixtures"] and receipt["receipt"]["allWorkersJoined"]
assert digest(q/"observations.tar.xz")==receipt["receipt"]["archiveSHA256"]
permanent=lab.parents[3]/"benchmarks/results/2026-11-25-single-formatted-field-scan/confirmation/quiet-observations.tar.xz"
assert digest(permanent)==receipt["receipt"]["archiveSHA256"]
assert {p.name:digest(p) for p in (donor/"candidate").iterdir()}==identity["imageFiles"]["candidate"]
assert digest(donor/"bench/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll")==identity["coreSHA256"]["candidate"]
manifest=dict(root=json.loads((q/"upload.json").read_text(encoding="utf-8"))["root"],
              receipt=receipt["receipt"],image=identity["imageFiles"]["candidate"])
code="from pathlib import Path\nimport hashlib, json, fcntl, shutil, subprocess\nmanifest="+repr(manifest)+"\n"
code+="""
base=Path('/home/lokad/lython-bench-checks').resolve()
root=base/manifest['root']
assert root.resolve()==root and root.parent==base
unit='lython-b1726b-single-formatted-field-scan-20261125.service'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    status=subprocess.check_output(['systemctl','show',unit,'-p','ActiveState','-p','MainPID'],text=True)
    assert 'ActiveState=inactive' in status and 'MainPID=0' in status
    assert json.loads((root/'archive-receipt.json').read_text())==manifest['receipt']
    assert digest(root/'observations.tar.xz')==manifest['receipt']['archiveSHA256']
    assert not (root/'guest-fixtures').exists()
    image=root/'candidate'
    assert image.parent==root and image.resolve()==image
    assert {p.name:digest(p) for p in image.iterdir()}==manifest['image']
    core=image/'Lokad.Lython.dll'
    assert core.resolve()==core and core.is_file() and core.stat().st_nlink==1
    size=core.stat().st_size
    before=shutil.disk_usage(base).free
    if before < 8704 * 1024: core.unlink()
    else: size=0
    print(json.dumps(dict(remoteDuplicateBytes=size,preservedCoreSHA256=manifest['image'][core.name],
                          archiveSHA256=manifest['receipt']['archiveSHA256'],freeBefore=before,
                          freeAfter=shutil.disk_usage(base).free)))
"""
ssh=["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),
     "-o","BatchMode=yes","-o","ConnectTimeout=15","lokad@20.166.121.73","python3 -"]
result=subprocess.run(ssh,input=code,encoding="utf-8",capture_output=True,check=True,timeout=35)
(lab/"initial-image-custody.json").write_text(result.stdout,encoding="utf-8",newline="\n")
print(result.stdout)
