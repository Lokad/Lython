from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.with_name("single-formatted-field-scan-confirmation-20261125")
previous=lab.with_name("direct-record-cpython-20261125")
quiet=lab/"external"
quiet.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
digest=lambda data:hashlib.sha256(data).hexdigest()
sha=lambda p:digest(p.read_bytes())
def write(p,text):
    p.write_text(text,encoding="utf-8",newline="\n")
def save(p,value):
    write(p,json.dumps(value,ensure_ascii=False,indent=2)+"\n")
def git(*args):
    return subprocess.check_output(["git",*args],cwd=repo)

source=git("rev-parse","HEAD").decode().strip()
assert git("diff","--binary",source,"--","src")==b""
build_base=(lab/"pre-build-revision.txt").read_text(encoding="utf-8").strip()
patch=(lab/"pre-build-source.patch").read_bytes()
assert git("diff","--binary",build_base,source,"--","src")==patch
assert git("diff","--name-only",build_base,source,"--","benchmarks/cpython-worker.py","benchmarks/Lokad.Lython.Benchmarks")==b""
sealed=donor/"comparison/quiet"
baseline=read(sealed/"identity.json")
frozen=baseline["imageFiles"]["candidate"]
assert len(frozen)==32 and {p.name:sha(p) for p in (donor/"candidate").iterdir()}==frozen
new_core=lab/"bench/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll"
worker_core=lab/"bench/bin/Lokad.Lython.Benchmarks/release_net11.0/Lokad.Lython.dll"
assert sha(new_core)==sha(worker_core)
files=frozen|{new_core.name:sha(new_core)}
image=lab/"candidate"
image.mkdir(exist_ok=True)
for name in files: shutil.copyfile(new_core if name==new_core.name else donor/"candidate"/name,image/name)
assert {p.name:sha(p) for p in image.iterdir()}==files
terminal=read(sealed/"terminal-status.json")
assert terminal["receipt"]["complete"] and sha(sealed/"observations.tar.xz")==terminal["receipt"]["archiveSHA256"]
location="formatted-report-cpython-b1727-20261125"
reference=read(sealed/"upload.json")["root"]
old=read(previous/"external/identity.json")
assert old["expectedCPythonSHA256"]==baseline["expectedCPythonSHA256"]
assert old["auxiliaryFiles"]=={name:value for name,value in files.items() if name!="Lokad.Lython.dll"}
catalog=read(sealed/"representative.json")
ordinary="diagnostic.generated-ordinary-definitions"
cases=read(previous/"external/representative.json")["cases"]
catalog["cases"].append(next(row for row in cases if row["id"]==ordinary))
report="scripts.report-render.small"
large="scripts.report-render.large"
manifest="scripts.file-manifest.small"
jobs=[(report,"compile"),(ordinary,"warm"),(large,"warm"),(manifest,"compile"),(report,"compile-run"),(ordinary,"compile-run")]
assert len(catalog["cases"])==4
save(quiet/"representative.json",catalog)
save(quiet/"jobs.json",jobs)
core=files["Lokad.Lython.dll"]
identity=dict(sourceRevision=source,candidate=source,productionSource=source,imageFiles={"candidate":files},
              frozenImage="/home/lokad/lython-bench-checks/"+location+"/candidate",
              auxiliaryFiles=old["auxiliaryFiles"],coreSHA256={"candidate":core,"candidate-control":core},
              expectedCPythonSHA256=baseline["expectedCPythonSHA256"],cpythonWorkerSHA256=baseline["cpythonWorkerSHA256"],
              auxiliaryImageReference="B1726b",productionBuild="New Release core with the exact retained source changes.", sourceEquivalentBuild=source,
              sourcePatchSHA256=digest(patch),sourcePatchBase=build_base,
              catalogs={name:dict(sha256=sha(quiet/name)) for name in ("representative.json","jobs.json")})
save(quiet/"identity.json",identity)
protocol=repo/"benchmarks/cpython-worker.py"
assert sha(protocol)==identity["cpythonWorkerSHA256"]
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
evidence=quiet/"candidate-verify.json"
subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",quiet/"representative.json",
    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",evidence],
    cwd=repo,env=env,check=True,timeout=80)
report=read(evidence)
assert report["state"]=="Completed" and report["caseCount"]==4
assert report["launched"]["library"]["sha256"]==core and report["catalogSha256"]==identity["catalogs"]["representative.json"]["sha256"]
assert {p.name:sha(p)for p in image.iterdir()}==files

shutil.copyfile(previous/"external/run.sh",quiet/"run.sh")
assert b"\r" not in (quiet/"run.sh").read_bytes()
collect=(previous/"external/collect.py").read_text(encoding="utf-8").replace("b1720-fixtures","b1727-fixtures")
collect=collect.replace("Retained CSV record admission checkpoint against CPython","Retained formatted-field checkpoint against CPython")
collect=collect.replace("len(jobs) == 11","len(jobs) == 6").replace("started<440","started<310")
summary=(previous/"external/summarize.py").read_text(encoding="utf-8")
summary=summary.replace('len(raw["jobs"])==11 and receipt["warmJobs"]==11','len(raw["jobs"])==6 and receipt["warmJobs"]==6')
for name,source_text in (("collect.py",collect),("summarize.py",summary)):
    compile(source_text,name,"exec")
    write(quiet/name,source_text)
launch=(previous/"quiet.py").read_text(encoding="utf-8").replace(
    "lython-b1720-direct-record-cpython","lython-b1727-formatted-report-cpython").replace("b1720","b1727")
anchor="assert donor['archiveSHA256']=='"
i=launch.index(anchor)
j=launch.index("\n",i)
launch=launch[:i]+f"assert donor['archiveSHA256']=={terminal['receipt']['archiveSHA256']!r}"+launch[j:]
launch=launch.replace("seconds=390","seconds=272").replace("RuntimeMaxSec=490","RuntimeMaxSec=340")
launch=launch.replace("'collect.py'}","'collect.py','candidate-core.dll'}")
launch=launch.replace("  os.link(reference/'candidate'/name,image/name)",
    "  if name=='Lokad.Lython.dll': (root/'candidate-core.dll').rename(image/name)\n  else: os.link(reference/'candidate'/name,image/name)")
compile(launch,"quiet.py","exec")
write(lab/"quiet.py",launch)
archiver=(previous/"archive.py").read_text(encoding="utf-8").replace("2026-11-25-direct-record-cpython","2026-11-25-formatted-report-cpython")
archiver=archiver.replace("== 308 and len(summary", "== 168 and len(summary").replace('["rows"]) == 11','["rows"]) == 6')
archiver=archiver.replace('"prepare.py", "prepare-checkpoint.py", "quiet.py", "archive.py", "verified-raw-replicas.json",',
    '"prepare.py", "pre-build-revision.txt", "pre-build-source.patch", "bench-build.log", "quiet.py", "archive.py", "verified-raw-replicas.json",')
archiver=archiver.replace('"prepare-docs.py", "write-docs.py", "record-checkpoint.py", "retrieve.log",',
    '"recover-working-space.py", "initial-image-custody.json", "launch-console.log", "retrieve.log",')
archiver=archiver.replace("Archived 308 verified","Archived 168 verified")
write(lab/"archive.py",archiver)
payload=quiet/"payload.tar.gz"
with tarfile.open(payload,"w:gz",compresslevel=3) as bundle:
    for name in ("identity.json","jobs.json","representative.json","collect.py","run.sh"):
        bundle.add(quiet/name,arcname=name)
    bundle.add(new_core,arcname="candidate-core.dll")
save(quiet/"upload.json",dict(root=location,reference=reference,payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
save(lab/"verified-raw-replicas.json",[])
print("Six production phases and four independent CPython goldens verified.")
