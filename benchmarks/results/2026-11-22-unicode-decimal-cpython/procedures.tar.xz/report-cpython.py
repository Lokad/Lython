from pathlib import Path
import base64
import csv
import io
import hashlib
import json
import shutil
import statistics
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
evidence=lab/"cpython"
result=repo/"benchmarks/results/2026-11-22-unicode-decimal-cpython"
ref="[B1388]"

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def save(path, text):
    path.write_text(text,encoding="utf-8",newline="\n")

def save_data(path, data):
    save(path,json.dumps(data,indent=2)+"\n")

def extent(values, digits, unit):
    lo,hi=(f"{v:.{digits}f}" for v in values)
    return lo+unit if lo==hi else f"{lo}–{hi}{unit}"

receipt=load(evidence/"archive-receipt.json")
raw=load(evidence/"retrieved/confirmation/confirmation.json")
identity=load(evidence/"identity.json")
assert receipt["complete"] and receipt["jobs"]==5 and receipt["archivedAndVerifiedUnderLease"]
assert hashlib.sha256((evidence/"observations.tgz").read_bytes()).hexdigest()==receipt["archiveSHA256"]
assert raw["complete"] and len(raw["jobs"])==5
labels=("candidate","candidate-control","CPython","CPython-control")
rows=[]
for job in raw["jobs"]:
    assert job["workersJoinedAndFixturesRemoved"]
    assert set(job["identities"])==set(labels)
    lane,=job["lanes"]
    medians={}
    cpu_medians={}
    variation={}
    for label in labels:
        batch=[s for s in job["samples"] if s["engine"]==label]
        assert len(batch)==7
        elapsed=[1000*s["response"]["elapsedTicks"]/s["response"]["clockFrequency"]/s["response"]["completedInvocations"] for s in batch]
        medians[label]=statistics.median(elapsed)
        q=statistics.quantiles(elapsed,n=4,method="inclusive")
        variation[label]=100*(q[2]-q[0])/medians[label]
        cpu_medians[label]=statistics.median([1000*s["externalProcessCpuTicks"]/s["externalCpuFrequency"]/s["response"]["completedInvocations"] for s in batch])
    left=sorted(medians[n] for n in labels[:2])
    right=sorted(medians[n] for n in labels[2:])
    ratio=[left[0]/right[1],left[1]/right[0]]
    rows.append(dict(case=job["case"],lane=lane,lythonMs=left,cpythonMs=right,ratio=ratio,
                     lythonSpread=100*(left[1]/left[0]-1),cpythonSpread=100*(right[1]/right[0]-1),
                     iqrPercent=variation,processCpuMilliseconds=cpu_medians))
summary=dict(source=identity["sourceRevision"],relatedProduction=identity["deliveryRevision"],
    elapsedSeconds=raw["elapsedSeconds"],image=identity["imageFiles"],cpythonExecutableSHA256=identity["cpythonExecutableSHA256"],
    complete=True,timedBatches=28*len(rows),rows=rows)
result.mkdir(exist_ok=True)
save_data(result/"summary.json",summary)
for name in ("archive-receipt.json","observations.tgz","terminal-status.json"):
    shutil.copyfile(evidence/name,result/name)
names={
    "scripts.csv-meter-report.typed-unicode":"Typed Unicode CSV meter report",
    "scripts.csv-invoice.method-policy.quoted-control":"Quote-heavy CSV policy invoice",
    "diagnostic.text-summary.nonlocal-computed-width.large":"Unicode word-count report with a nonlocal helper",
}
boundaries={"warm":"Warm","compile":"Compilation only","compile-run":"Compile-to-result"}
counts = {
    "scripts.csv-meter-report.typed-unicode": 4096,
    "scripts.csv-invoice.method-policy.quoted-control": 4096,
    "diagnostic.text-summary.nonlocal-computed-width.large": 3072,
}
inputs = {}
for case in load(evidence/"representative.json")["cases"]:
    input_files=json.loads(case["fixtureJson"])["inputFiles"]
    payload = base64.b64decode(next(iter(input_files.values())),validate=True)
    count = counts[case["id"]]
    unit = "lines" if "text-summary" in case["id"] else "records"
    actual = sum(1 for _ in csv.reader(io.StringIO(payload.decode("utf-8"), newline="")))-1 if unit=="records" else len(payload.splitlines())
    assert actual == count, (case["id"], actual)
    inputs[case["id"]]=f"{count:,} {unit} / {len(payload):,} B"
table = [
    "| Complete script | Phase | Lython | CPython | Lython / CPython | Lython / CPython worker spread |",
    "| --- | --- | ---: | ---: | ---: | ---: |",
]
def measurement(row):
    digits=5 if row["lane"]=="compile" else 3
    return [extent(row["lythonMs"],digits," ms"),extent(row["cpythonMs"],digits," ms"),extent(row["ratio"],3,"×")]
for row in rows:
    fields=[names[row["case"]],boundaries[row["lane"]],*measurement(row),f"{row['lythonSpread']:.2f} / {row['cpythonSpread']:.2f}%"]
    table.append("| "+" | ".join(fields)+" |")
report=f"""# B1388 Unicode CSV and text against CPython

Measured November 22, 2026 UTC on the quiet Azure F4as_v7 with
Ubuntu 24.04.4 and .NET 11 RC3. The frozen Lython core is
`{summary['source'][:9]}`, the B1383 candidate with the retained
Unicode decimal change from `{summary['relatedProduction']}`. The fully
qualified `{identity['qualifiedRevision']}` additionally changes regex
objects and tests. These workloads use no regex. The external engine is
stock CPython 3.13.16. Each CSV input contains 4,096 records.
The text input contains 3,072 lines. This text script calls a helper
that updates a nonlocal width before returning words. It shares input
and expected report bytes with B1274 but uses a different script.
Each engine's output and files verify against the same catalog.
[Earlier map-based script](../2026-11-21-cpython-casing-checkpoint/README.md).

"""
report+="\n".join(table)+f"""

Ratios divide Lython elapsed by CPython elapsed. Above 1× means
Lython takes longer. Each range spans all pairings of two process
medians per engine. Each phase uses independent processes, normal
GC and tiering, eight seconds of warmup per worker and seven timed
batches per worker.

Warm execution includes mediated RAM-backed I/O for Lython, native
file I/O for CPython, output checks and prior-result disposal.
Compilation-only includes compiled-owner disposal. Time to result
includes compilation, one execution and their cleanup. Startup and
final teardown use separate boundaries. Process CPU in the raw
results includes worker reset and request handling.

All {summary['timedBatches']} timed batches verified in
{summary['elapsedSeconds']:.0f} seconds. The complete Lython image and the
CPython executable matched their recorded hashes. Both quiet gates
passed, all workers joined and the persistent archive verified under
the lease. These are diagnostics for the measured revision and machine.

[Phase summary](summary.json) · [Raw observations](observations.tgz) ·
[Verified inputs and procedures](procedures.tar.xz) ·
[Unicode decimal source pair](../2026-11-22-unicode-decimal-normalization/README.md).
"""
save(result/"README.md",report)
files=("prepare-cpython.py","launch-cpython.py","report-cpython.py","cpython/inventory.json",
       "cpython/verification.json","cpython/observe-not-before.json","cpython/representative.json")
with tarfile.open(result/"procedures.tar.xz","w:xz") as a:
    for n in files:a.add(lab/n,arcname=n)
with tarfile.open(result/"procedures.tar.xz") as a:assert set(a.getnames())==set(files)

def format_public(row):
    peak=max(row["lythonSpread"],row["cpythonSpread"])
    engine="Lython" if row["lythonSpread"]>=row["cpythonSpread"] else "CPython"
    status="Diagnostic."
    if row["ratio"][0]<=1<=row["ratio"][1]:status="Inconclusive. Spans parity."
    elif peak>=5:status="Uncertain magnitude."
    middle=inputs[row["case"]] if row["lane"]=="warm" else boundaries[row["lane"]]
    fields=[names[row["case"]],middle,*measurement(row),f"{status} {engine} worker spread {peak:.2f}%. {ref}."]
    return "| "+" | ".join(fields)+" |"
guide_path=repo/"docs/BENCHMARKS.md"
guide=guide_path.read_text(encoding="utf-8")
assert ref not in guide
for row in rows:
    if row["lane"]=="warm":
        if row["case"] in counts and "text-summary" in row["case"]:
            marker=next(line for line in guide.splitlines() if line.startswith("| Map-based text report |"))
            guide=guide.replace(marker,format_public(row)+"\n"+marker,1)
        else:
            marker=next(line for line in guide.splitlines() if line.startswith("| "+names[row["case"]]+" |"))
            guide=guide.replace(marker,format_public(row),1)
    else:
        marker=next(line for line in guide.splitlines() if line.startswith("| Mixed literal-default factory | Compilation"))
        guide=guide.replace(marker,format_public(row)+"\n"+marker,1)
offset=guide.index("| [B1378] |")
guide=guide[:offset]+f"| {ref} | `{summary['source'][:9]}` | 2026-11-22 UTC |\n"+guide[offset:]
offset=guide.index("[B1378]:")
guide=guide[:offset]+f"{ref}: ../benchmarks/results/2026-11-22-unicode-decimal-cpython/README.md\n"+guide[offset:]
save(guide_path,guide)
for line in table: print(line)
