from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
template = lab.parent / "json-direct-mapping-20261122/cpython"
source = lab / "comparison/quiet"
frozen = lab / "comparison/frozen-candidate"
evidence = lab / "cpython"
evidence.mkdir(exist_ok=True)

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, value):
    if not isinstance(value, str):
        value = json.dumps(value, indent=2)+"\n"
    if path.suffix==".py":
        compile(value, str(path), "exec")
    path.write_text(value, encoding="utf-8", newline="\n")

def published(name):
    return subprocess.check_output(["git","show","origin/master:"+name],cwd=repo)

def archive(folder):
    prefix = f"benchmarks/results/{folder}/"
    receipt = json.loads(published(prefix+"archive-receipt.json"))
    raw = published(prefix+"observations.tgz")
    assert all(receipt[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
    assert sha(raw)==receipt["archiveSHA256"]
    return receipt["archiveSHA256"], len(raw)

reference = read(repo/"benchmarks/results/2026-11-22-unicode-decimal-normalization/source.json")
image = reference["imageFiles"]["candidate"]
assert len(image)==32 and {name:sha((frozen/name).read_bytes()) for name in image}==image
receipt = read(source/"archive-receipt.json")
assert archive("2026-11-22-unicode-decimal-normalization")[0]==receipt["archiveSHA256"]
assert sha((source/"observations.tgz").read_bytes())==receipt["archiveSHA256"]
old = read(template/"config.json")
donor = read(source/"config.json")

typed = "scripts.csv-meter-report.typed-unicode"
quoted = "scripts.csv-invoice.method-policy.quoted-control"
report = "diagnostic.text-summary.nonlocal-computed-width.large"
catalog = read(lab/"catalog.json")
catalog["cases"] = [row for row in catalog["cases"] if row["id"] in (typed,quoted,report)]
assert {row["id"] for row in catalog["cases"]} == {typed,quoted,report}
catalog_file = evidence/"representative.json"
write(catalog_file,catalog)
catalog_hash = sha(catalog_file.read_bytes())

dotnet = Path.home()/".dotnet11/dotnet.exe"
env = dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent),PATH=str(dotnet.parent)+os.pathsep+os.environ["PATH"])
protocol = repo/"benchmarks/cpython-worker.py"
assert sha(protocol.read_bytes())==donor["protocolSHA256"]==old["protocolSHA256"]
proof_file = evidence/"verification.json"
subprocess.run([dotnet,frozen/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog_file,
    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",proof_file],
    check=True,env=env,timeout=85)
proof = read(proof_file)
assert proof["state"]=="Completed" and proof["caseCount"]==3 and proof["catalogSha256"]==catalog_hash

base = "/home/lokad/lython-bench-checks"
root = base+"/unicode-decimal-cpython-b1388-20261122"
unit = "lython-b1388-unicode-decimal-cpython-20261122"
catalogs = {catalog_file.name:dict(sha256=catalog_hash)}
core = "Lokad.Lython.dll"
identity = dict(sourceRevision=reference["candidate"], deliveryRevision="f17ba1c9f", qualifiedRevision="4eb84cf46",
    purpose="Report the retained Unicode CSV and text delivery against stock CPython",
    imageFiles={"candidate": image}, coreSHA256={name:image[core] for name in ("candidate","candidate-control")},
    auxiliaryFiles={n:h for n,h in image.items() if n!=core},
    catalogs=catalogs,cpythonWorkerSHA256=donor["protocolSHA256"],
    cpythonExecutableSHA256=old["identity"]["cpythonExecutableSHA256"])
write(evidence/"identity.json",identity)
jobs = [(typed,"warm"),(quoted,"warm"),(report,"warm"),(typed,"compile"),(typed,"compile-run")]
for name in ("collect.py","archive-owned.py","run.sh","retrieve.py"):
    code = (template/name).read_text(encoding="utf-8").replace(old["root"],root).replace(old["unit"],unit).replace("B1378","B1388")
    if name=="collect.py":
        code=code.replace("root / 'expansion.json'","root / 'representative.json'")
        start,end=code.index("    for case_id,lane in ["),code.index("        diagnostic = False")
        code=code[:start]+"    for case_id,lane in "+repr(jobs)+""":
        assert time.monotonic()-started<300,'Leave time for cleanup and archival'
        assert manifest_hash==identity['catalogs'][catalog.name]['sha256']
"""+code[end:]
    elif name in ("archive-owned.py","retrieve.py"):
        code=code.replace("jobs=7,","jobs=5,").replace("['jobs']==7","['jobs']==5").replace("len(raw['jobs'])==7","len(raw['jobs'])==5")
    write(evidence/name,code)
assert b"\r" not in (evidence/"run.sh").read_bytes()

parts = ("identity.json","collect.py","archive-owned.py","run.sh","representative.json")
payload = evidence/"payload.tgz"
with tarfile.open(payload,"w:gz") as bundle:
    for name in parts:
        bundle.add(evidence/name,arcname=name)
unpacked = sum((evidence/name).stat().st_size for name in parts)

# Identify exact, already published archive replicas under an idle lease.
known = {}
for witness in (repo/"benchmarks/results").glob("*/archive-receipt.json"):
    raw = witness.parent/"observations.tgz"
    info = read(witness)
    if raw.is_file() and all(info.get(k) for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease")):
        known.setdefault(raw.stat().st_size,[]).append((info["archiveSHA256"],witness.parent.name))
query = """
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat
b=Path(REMOTE);known=KNOWN
with (b/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not any(p.is_mount() for p in b.glob('*/guest-fixtures'))
 free=shutil.disk_usage(b).free
 found=[]
 for path in sorted(b.glob('*/observations.tgz'), key=lambda p:-p.stat().st_size):
  value=path.lstat()
  if not stat.S_ISREG(value.st_mode) or value.st_nlink!=1 or value.st_uid!=os.getuid() or path.resolve()!=path:continue
  if value.st_size not in known or str(path.parent)==DONOR:continue
  digest=hashlib.sha256(path.read_bytes()).hexdigest()
  match=next((name for expected,name in known[value.st_size] if expected==digest),None)
  if match is not None:found.append(dict(paths=[str(path.relative_to(b))],bytes=value.st_size,sha256=digest,links=1,archives={},published=match))
 print(json.dumps(dict(free=free,found=found)))
""".replace("REMOTE",repr(base)).replace("KNOWN",repr(known)).replace("DONOR",repr(donor["root"]))
ssh=["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),"-o","BatchMode=yes","-o","ConnectTimeout=15","lokad@20.166.121.73"]
result = subprocess.run(ssh+["python3 -"],input=query.encode(),capture_output=True,timeout=60)
assert result.returncode==0,result.stderr.decode()
(evidence/"inventory.json").write_bytes(result.stdout)
free=json.loads(result.stdout)
target=176160768+unpacked+640*1024
retire=[]
available=free["free"]
for match in free["found"]:
    if available>target:
        break
    assert archive(match["published"])==(match["sha256"],match["bytes"])
    retire.append(match)
    available+=match["bytes"]
assert available>target,(available,target)
stage=dict(root=root,unit=unit,identity=identity,source=donor["root"],donorArchiveSHA256=receipt["archiveSHA256"],
           protocolSource=donor["protocolSource"],protocolSHA256=donor["protocolSHA256"],
           payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload.read_bytes()),
           retireGroups=retire,catalogs=catalogs,unpackedBytes=unpacked)
write(evidence/"config.json",stage)
remote=(template/"remote-launch.py").read_text(encoding="utf-8")
start,end=remote.index("\nc=")+1,remote.index("\nb=Path(")
remote=remote[:start]+"c="+repr(stage)+remote[end:]
remote=remote.replace("RuntimeMaxSec=485","RuntimeMaxSec=380").replace("lython-b1378-fixtures","lython-b1388-fixtures")
write(evidence/"remote-launch.py",remote)
launcher=(template.parent/"launch-cpython.py").read_text(encoding="utf-8")
write(lab/"launch-cpython.py",launcher.replace("Combined JSON CPython checkpoint","CSV and text CPython checkpoint").replace("402","285"))
print(f"Verified three scripts for five bounded phases; planned archive replicas to retire {len(retire)}",flush=True)
