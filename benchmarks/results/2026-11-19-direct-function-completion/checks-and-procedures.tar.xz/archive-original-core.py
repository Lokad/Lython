from pathlib import Path
import gzip,hashlib,json
lab=Path(__file__).resolve().parent
previous=lab.parent/'direct-function-definitions-r593'
image=previous/'frozen/candidate'
manifest=json.loads((previous/'frozen-identity.json').read_text(encoding='utf-8-sig'))['images']['candidate']
sha=lambda data:hashlib.sha256(data).hexdigest()
assert len(manifest)==32 and all(sha((image/n).read_bytes())==h for n,h in manifest.items())
core=(image/'Lokad.Lython.dll').read_bytes()
assert sha(core).startswith('40d184d8')
target=Path('benchmarks/results/2026-11-19-direct-function-definitions/prototype-core.dll.gz')
archive=gzip.compress(core,6,mtime=0)
if target.exists(): assert target.read_bytes()==archive
else: target.write_bytes(archive)
assert gzip.decompress(target.read_bytes())==core
print('Archived the exact B1019 prototype core.')