from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / 'quiet'
out = Path('benchmarks/results/2026-11-19-direct-function-completion')
base = 'd8d0451e5'
candidate = (lab.parent / 'direct-function-definitions-r593' / 'refined-prototype-commit.txt').read_text(encoding='utf-8-sig').strip()
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
terminal, receipt = [load(quiet / f'{file}.json') for file in ('terminal-status', 'archive-receipt')]
assert terminal['receipt'] == receipt and terminal['exitCode'] == '0'
assert not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert all(receipt[field] for field in ['complete','allWorkersJoined','guestFixturesRemoved',
                                      'quietBeforeAndAfter','archivedAndVerifiedUnderLease'])
assert receipt['jobs'] == 6 and receipt['archiveSHA256'] == sha(quiet / 'observations.tgz')
identity = load(quiet / 'identity.json')
catalog = load(lab / 'catalog.json')
assert sha(lab / 'catalog.json') == identity['catalogSHA256']
cases = {case['id']: case for case in catalog['cases']}
raw = load(quiet / 'retrieved/confirmation/confirmation.json')
assert raw['complete'] and len(raw['jobs']) == 6
for job in raw['jobs']:
    case = cases[job['case']]
    assert job['workersJoinedAndFixturesRemoved'] and len(job['samples']) == 20
    assert set(job['identities']) == set(identity['coreSHA256'])
    for engine, info in job['identities'].items():
        native = next(lib for lib in info['libraries'] if Path(lib['path']).name == 'Lokad.Lython.dll')
        assert native['sha256'].lower() == identity['coreSHA256'][engine]
    for sample in job['samples']:
        response = sample['response']
        assert response['status'] == 'Completed' and response['completedInvocations'] > 0
        assert response['sourceSha256'] == case['sourceSha256'] and response['fixtureSha256'] == case['fixtureSha256']
        expected = case['expectedOutputSha256'] if job['lane'] != 'compile' else None
        assert response.get('actualOutputSha256') == expected
        expected = case.get('expectedFilesSha256') if job['lane'] != 'compile' else None
        assert response.get('actualFilesSha256') == expected
out.mkdir(exist_ok=True)
summary = load(lab / 'quiet-summary.json')
summary.update(referenceRuntime='d8d0451e5', candidateBase=base, measuredPrototype=candidate,
               cores=identity['coreSHA256'], archiveSHA256=receipt['archiveSHA256'], retentionDecisionPending=False, retainedCommit='934fe4a44')
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8', newline='\n')
for name in ['observations.tgz','archive-receipt.json','terminal-status.json']:
    shutil.copyfile(quiet / name, out / name)
diff = subprocess.check_output(['git','diff','--binary',base,candidate,'--','src','tests'])
assert b'-        private async ValueTask ExecutePreparedDefinitionOperationAsync' in diff and b'+    private static async ValueTask EvaluateFunctionAnnotationsAsync' in diff
(lab / 'measured-source.patch').write_bytes(diff)
with tarfile.open(out / 'checks-and-procedures.tar.xz','w:xz',preset=6) as archive:
    for name in ['measured-source.patch','verify-pair.py','reference-verify.json','candidate-verify.json',
                 'reference-allocation.json','candidate-allocation.json','quiet-space.json','stage-quiet.py',
                 'launch-quiet.py','archive-b1020.py','summarize-quiet.py',
                 'archive-original-core.py','canonical-space.py']:
        archive.add(lab / name, arcname=name)
    refinement=lab.parent/'direct-function-definitions-r593'
    for name in ['refined-public-win-net11.log','refined-public-wsl-net10.log',
                 'refined-probe-build-win-net11.log','refined-prototype-commit.txt']:
        archive.add(refinement/name,arcname='validation/'+name)
    archive.add(refinement/'refined-probes',arcname='validation/probes')
    for name in ['config.json','preflight.json','launch.log','remote-launch.py','retrieve.py','observe-not-before.json']:
        archive.add(quiet / name, arcname='quiet/' + name)
print('Verified B1020 against both hashes, all 120 golden responses, and the measured source patch.')

