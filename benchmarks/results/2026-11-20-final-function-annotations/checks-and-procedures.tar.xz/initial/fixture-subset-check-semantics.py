from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
cases={'eager-order': "events=[]\ndef mark(value):\n    events.append(value)\n    return value\ndef decorator(which):\n    events.append(which)\n    def apply(fn):\n        events.append(list(fn.__annotations__.values()))\n        return fn\n    return apply\ndef factory():\n    @decorator('outer')\n    @decorator('inner')\n    def f(value:mark('value')=mark('default'), *, flag:mark('flag')=mark('keyword'))->mark('return'):\n        return value,flag\n    return f\nf=factory()\nprint(events,f())\n", 'decorator-retained-alias': "held=[]\ndef publish(fn):\n    held.append((fn,fn.__annotations__))\n    raise ValueError('stop')\ndef factory():\n    value=[]\n    try:\n        @publish\n        def f(arg:value=value)->value: return arg\n    except ValueError:\n        return value\nvalue=factory()\nf,d=held[0]\nprint(d is f.__annotations__,d['return'] is value,f() is value)\nf.__annotations__={}\nvalue.append(42)\nprint(d,f.__annotations__)\n", 'catch-and-reuse': "def fail(): raise LookupError('annotation')\ndef factory():\n    for attempt in range(2):\n        try:\n            def f(value:(fail() if attempt == 0 else list)=7)->int: return value\n            print(f(),list(f.__annotations__))\n        except LookupError:\n            print('discarded')\nfactory()\n", 'generator-close': "events=[]\ndef use(fn):\n    events.append(fn)\n    return fn\ndef factory():\n    try:\n        @use\n        def f(value:(yield 'first')=1)->(yield 'next'): return value\n        events.append('published')\n    finally:\n        events.append('closed')\ng=factory()\nprint(next(g),g.send(3))\ng.close()\nprint(events)\n", 'postponed': 'from __future__ import annotations\ndef factory(seed):\n    def f(value:Missing[tuple[int, str]]=seed, *, flag:Unknown=True)->list[int]:\n        return value,flag\n    return f\nf=factory(3)\nprint(f(),f.__annotations__)\n', 'sparse-keyword-index': 'def factory(seed):\n    def f(arg:object=seed, *, first:int=seed, required:int, last:int=9)->int:\n        return arg,first,required,last\n    return f\nf=factory(3)\nprint(f(required=8),list(f.__kwdefaults__),list(f.__annotations__))\n'}
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
probe=lab.parent/'lexical-annotation-boundary/probe-build/bin/LythonProbe/release_net11.0'
pair=load(lab/'frozen-identity.json')
body=json.dumps(list(cases.values())).encode('utf-8')
(lab/'probe-cases.json').write_bytes(body)
for role,files in pair['images'].items():
    source=lab/'frozen'/role
    assert len(files)==32 and {n:sha(source/n) for n in files}==files
    image=lab/'probe'/role
    shutil.copytree(probe,image,dirs_exist_ok=True)
    for file in image.glob('Lokad.*.dll'):
        if file.name in files:
            shutil.copyfile(source/file.name,file)
            assert sha(file)==files[file.name]
    assert sha(image/'Lokad.Lython.dll')==files['Lokad.Lython.dll']
    for async_mode in (False,True):
        args=[sdk/'dotnet.exe',image/'LythonProbe.dll','--batch-json','--compare-python','--python','C:/Python313/python.exe']
        if async_mode:args.append('--async')
        process=subprocess.run(args,input=body,capture_output=True,timeout=55,env=env)
        (lab/f'probe-{role}-{async_mode}.jsonl').write_bytes(process.stdout)
        assert process.returncode==0,(role,async_mode,process.stderr.decode(),process.stdout.decode())
        reports=[json.loads(line) for line in process.stdout.splitlines()]
        assert len(reports)==len(cases) and all(row['Matches'] and row['Compared'] for row in reports)
print(f'{len(cases)} CPython semantic probes pass in sync and async modes for both source images.')
