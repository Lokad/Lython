from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=Path.cwd()
worktree=repo/'.git/agent-worktrees/final-function-annotations'
donor=lab.parent/'prepared-keyword-default-loop'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
def git(*args):
    return subprocess.check_output(['git',*args])

development_base=git('rev-parse','8fafe1a5a').decode().strip()
candidate=git('-C',worktree,'rev-parse','HEAD').decode().strip()
identity=load(donor/'frozen-identity.json')
reference=identity['candidateCommit']
assert git('merge-base',development_base,candidate).decode().strip()==development_base
assert not git('diff','--name-only',reference,development_base,'--','src','tests','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py','global.json','Directory.Build.props','Directory.Packages.props')
assert not git('-C',worktree,'status','--porcelain')
(lab/'measured-source.patch').write_bytes(git('diff','--binary',development_base,candidate))

catalog=load(lab.parent/'funded-definition-construction/catalog.json')
assert len(catalog['cases'])==5
manifest=lab/'catalog.json'
write(manifest,catalog)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
files=identity['images']['candidate']
origin=donor/'frozen/candidate'
core='Lokad.Lython.dll'
assert len(files)==32 and {name:sha(origin/name) for name in files}==files
images={}
for role in ('reference','candidate'):
    image=lab/'frozen'/role
    image.mkdir(parents=True,exist_ok=True)
    for name in files:
        shutil.copyfile(origin/name,image/name)
    expected=files.copy()
    if role=='candidate':
        built=worktree/'src/Lokad.Lython/bin/Release/net11.0'/core
        shutil.copyfile(built,image/core)
        expected[core]=sha(built)
    verify=lab/(role+'-verify.json')
    with (lab/(role+'-verify.log')).open('wb') as log:
        subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',manifest,
            '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',repo/'benchmarks/cpython-worker.py',
            '--out',verify],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=140)
    verified=load(verify)
    assert verified['state']=='Completed' and verified['catalogSha256']==sha(manifest)
    assert {name:sha(image/name) for name in expected}==expected
    images[role]=expected
assert images['reference'][core]!=images['candidate'][core]
write(lab/'frozen-identity.json',dict(referenceCommit=reference,developmentBase=development_base,
    candidateCommit=candidate,casesSHA256=sha(manifest),images=images))
