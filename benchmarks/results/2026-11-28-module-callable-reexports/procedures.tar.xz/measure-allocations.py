from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import subprocess

lab=Path(__file__).resolve().parent
compare=lab/'comparison'
identity=json.loads((compare/'identity.json').read_bytes())
dotnet=Path.home()/'.dotnet11/dotnet.exe'
probe=lab/'probe/bin/Release/net11.0/ModuleProbe.dll'
cases=('config.json','workbook.json')
samples={case:{'reference':[],'candidate':[]} for case in cases}
for iteration in range(7):
    roles=('reference','candidate') if iteration%2==0 else ('candidate','reference')
    for case in cases:
        for role in roles:
            core=compare/role/'Lokad.Lython.dll'
            assert sha256(core.read_bytes()).hexdigest()==identity['imageFiles'][role][core.name]
            payload=compare/case
            assert sha256(payload.read_bytes()).hexdigest()==identity['catalogs'][case]['sha256']
            item=json.loads(subprocess.check_output([dotnet,probe,core,'--allocate',payload],cwd=lab,timeout=12))
            assert item['after']==0
            samples[case][role].append(item)
rows=[]
for case,roles in samples.items():
    result={name:[median(row[name] for row in roles[role]) for role in ('reference','candidate')]
            for name in ('allocated','admitted','after')}
    assert result['admitted'][0]==result['admitted'][1] and result['after']==[0,0]
    rows.append(dict(case=case,**result))
    print(case,result)
output=dict(callerThreadClrBytes=samples,summary=rows,verifiedCompilations=28)
(lab/'allocation.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8',newline='\n')
