using System.Reflection;
using System.Text.Json;

var assembly = Assembly.LoadFrom(Path.GetFullPath(args[0]));
var engineType = assembly.GetType("Lokad.Lython.LythonEngine", throwOnError: true)!;
var engine = Activator.CreateInstance(engineType)!;
if (args[1] == "--allocate")
{
    var budgetType = assembly.GetType("Lokad.Lython.LythonMemoryBudget", throwOnError: true)!;
    var budgetInterface = assembly.GetType("Lokad.Lython.ILythonMemoryBudget", throwOnError: true)!;
    var budget = Activator.CreateInstance(budgetType, [null])!;
    var compileWithBudget = engineType.GetMethod("Compile", [typeof(string), budgetInterface])!;
    using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[2]));
    var source = catalog.RootElement.GetProperty("cases")[0].GetProperty("source").GetString()!;
    var before = GC.GetAllocatedBytesForCurrentThread();
    var script = (IDisposable)compileWithBudget.Invoke(engine, [source, budget])!;
    var allocated = GC.GetAllocatedBytesForCurrentThread() - before;
    var successful = (bool)Read(script, "IsValid")!;
    var admitted = (long)Read(budget, "ReservedBytes")!;
    script.Dispose();
    var after = (long)Read(budget, "ReservedBytes")!;
    if (!successful || admitted <= 0 || after != 0) throw new InvalidOperationException("Compilation or cleanup failed.");
    Console.WriteLine(JsonSerializer.Serialize(new { allocated, admitted, after }));
    return;
}

var contracts = assembly.GetType("Lokad.Lython.Frontend.StaticContracts", throwOnError: true)!;
var spanType = assembly.GetType("Lokad.Lython.LythonSourceSpan", throwOnError: true)!;
var span = Activator.CreateInstance(spanType, [0, 0, 1, 1])!;
var modules = (IReadOnlyList<string>)contracts.GetMethod("GetKnownBuiltinModuleNames")!.Invoke(null, null)!;
var members = contracts.GetMethod("GetModuleMemberNames")!;
var exported = contracts.GetMethod("GetModuleExportedMemberNames")!;
var lookup = contracts.GetMethod("TryGetModuleMemberValue")!;
string[] metadata = ["__dict__", "__name__", "__spec__", "__loader__", "__package__", "__path__", "__synthetic_absent__"];
var rows = modules.Append("__absent_module__").Select(module =>
{
    var names = (IReadOnlyList<string>)members.Invoke(null, [module])!;
    var exports = (IReadOnlyList<string>)exported.Invoke(null, [module])!;
    var queries = names.Concat(metadata).Distinct(StringComparer.Ordinal).Select(name =>
    {
        object?[] arguments = [module, name, span, null];
        var found = (bool)lookup.Invoke(null, arguments)!;
        var value = arguments[3]!;
        var kind = Read(value, "Kind")!.ToString()!;
        var detail = kind switch
        {
            "String" or "Module" or "KnownCallable" => Call(value, "RequireText"),
            "Integer" => Call(value, "RequireInteger")!.ToString(),
            "Boolean" => Call(value, "RequireBoolean"),
            _ => null
        };
        return new { name, found, kind, detail, span = Read(value, "Span") };
    }).ToArray();
    return new { module, exports, queries };
}).ToArray();

var compile = engineType.GetMethod("Compile", [typeof(string)])!;
var cases = new Dictionary<string, string>
{
    ["constructor-shape"] = "from openpyxl.workbook import Workbook\nreturn Workbook(0, 0, 0)",
    ["reader-shape"] = "import openpyxl.reader.excel as reader\nreturn reader.load_workbook()",
    ["utility-shape"] = "from openpyxl.utils.cell import get_column_letter\nreturn get_column_letter()",
    ["ordinary-utility"] = "from openpyxl.utils import get_column_letter\nreturn get_column_letter()",
    ["identity-alias"] = "from openpyxl.styles import Font\nreturn Font(does_not_exist=1)",
    ["unknown-member"] = "import openpyxl.utils.cell as tools\nreturn tools.__missing()",
    ["shadowed-callable"] = "from openpyxl.workbook import Workbook\nWorkbook = lambda x: x\nreturn Workbook(7)",
    ["shadowed-module"] = "import openpyxl.reader.excel as reader\nclass Reader:\n def load_workbook(self): return 7\nreader = Reader()\nreturn reader.load_workbook()",
    ["merged-callables"] = "from openpyxl.workbook import Workbook as external\nfrom openpyxl import Workbook as root\nif supplied:\n make=external\nelse:\n make=root\nreturn make(1, 2, 3)",
    ["module-metadata"] = "import openpyxl.workbook as wrapped\nreturn wrapped.__name__",
    ["colocated-submodules"] = "import xml, collections, openpyxl\nreturn xml.etree, collections.abc, openpyxl.workbook",
    ["direct-imports"] = "from openpyxl.reader.excel import load_workbook as reader\nfrom openpyxl.utils.cell import get_column_letter as column\nreturn callable(reader), column(3)",
    ["known-callable"] = "import openpyxl.utils.cell as tools\nreturn tools.range_boundaries('C4:D5')"
};
var diagnostics = cases.Select(pair =>
{
    using var script = (IDisposable)compile.Invoke(engine, [pair.Value])!;
    return new { id = pair.Key, valid = Read(script, "IsValid"),
        diagnostics = JsonSerializer.SerializeToElement(Read(script, "Diagnostics")) };
}).ToArray();
File.WriteAllText(args[1], JsonSerializer.Serialize(new { modules, rows, diagnostics }));

static object? Read(object target, string property) => target.GetType().GetProperty(property)!.GetValue(target);
static object? Call(object target, string method) => target.GetType().GetMethod(method)!.Invoke(target, null);
