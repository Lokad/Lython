from openpyxl.workbook import Workbook as WorkbookFactory
from openpyxl.utils.cell import get_column_letter, range_boundaries
import openpyxl.reader.excel as reader

workbook = WorkbookFactory()
sheet = workbook.active
sheet.title = 'Summary'
column = get_column_letter(3)
sheet[column + '4'] = 19
print(sheet.title, sheet['C4'].value, range_boundaries('C4:D5'), callable(reader.load_workbook))
