from hashlib import sha256
from pathlib import Path
from shutil import copyfile,copytree
import json
import subprocess
import sys

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/'numeric-callable-catalog-b1928-20261128'
ordinary=lab.parent/'frontend-contract-sections-20261123/comparison'
checkpoint=lab.parent/'direct-lexical-binding-slots-b1925-20261128/comparison'
pair=lab/'comparison'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
image=lambda folder:{p.name:digest(p) for p in folder.iterdir()}
hash_text=lambda text:sha256(text.encode('utf-8')).hexdigest()
def write(path,data):
    path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')

base=git('rev-parse','HEAD').decode().strip()
ref=read(prior/'comparison/identity.json')
assert sha256(git('diff','--binary',ref['sourceRevision'],base,'--','src')).hexdigest()==ref['sourcePatchSHA256']
patch=git('diff','--binary',base,'--','src')
assert patch.count(b'diff --git ')==1 and b'ReexportedMembers' in patch
(lab/'candidate.patch').write_bytes(patch)
(lab/'tests.patch').write_bytes(git('diff','--binary',base,'--','tests'))
pair.mkdir()
core='Lokad.Lython.dll'
assert image(prior/'comparison/candidate')==ref['imageFiles']['candidate'] and len(ref['imageFiles']['candidate'])==32
for role in ('reference','candidate'):
    copytree(prior/'comparison/candidate',pair/role)
compiled=repo/'src/Lokad.Lython/bin/Release/net11.0'/core
assert digest(compiled)!=ref['imageFiles']['candidate'][core]
copyfile(compiled,pair/'candidate'/core)
images={role:image(pair/role) for role in ('reference','candidate')}
assert {name for name in images['reference'] if images['reference'][name]!=images['candidate'][name]}=={core}
for name in ('cpython-worker.py','config.json','run.sh'):
    copyfile(prior/'comparison'/name,pair/name)
assert b'\r' not in (pair/'run.sh').read_bytes() and digest(pair/'cpython-worker.py')==ref['cpythonWorkerSHA256']

source="""from openpyxl.workbook import Workbook as WorkbookFactory
from openpyxl.utils.cell import get_column_letter, range_boundaries
import openpyxl.reader.excel as reader

workbook = WorkbookFactory()
sheet = workbook.active
sheet.title = 'Summary'
column = get_column_letter(3)
sheet[column + '4'] = 19
print(sheet.title, sheet['C4'].value, range_boundaries('C4:D5'), callable(reader.load_workbook))
"""
(lab/'workbook.py').write_text(source,encoding='utf-8',newline='\n')
library=subprocess.check_output([sys.executable,'-X','utf8','-c',
    'import openpyxl,sys; from pathlib import Path; print(Path(openpyxl.__file__).parent.parent); print(openpyxl.__version__); print(sys.version)'],cwd=repo)
package,version,python_version=library.decode('utf-8').splitlines()
assert Path(package).is_dir()
golden=subprocess.check_output([sys.executable,'-I','-S','-X','utf8','-c',
    'import runpy, sys; sys.path.append(sys.argv[1]); runpy.run_path(sys.argv[2],run_name="__main__")',package,str(lab/'workbook.py')],cwd=repo)
expected="Summary 19 (3, 4, 4, 5) True\n"
assert golden.decode('utf-8').replace('\r\n','\n')==expected
(lab/'workbook-golden.txt').write_text(expected,encoding='utf-8',newline='\n')
write(lab/'workbook-reference.json',dict(pythonVersion=python_version,packageVersion=version,
    sourceSHA256=hash_text(source),goldenSHA256=hash_text(expected)))
fixture='{"size":1,"text":null}'
workbook=dict(id='diagnostic.workbook-reexports',family='diagnostic',category='whole-script',scale='small',size=1,
             source=source,fixtureJson=fixture,expectedOutput=expected,
             sourceUtf8Bytes=len(source.encode('utf-8')),expectedOutputUtf8Bytes=len(expected.encode('utf-8')),
             fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=hash_text(source),
             fixtureSha256=hash_text(fixture),expectedOutputSha256=hash_text(expected),expectedFilesSha256=None)
write(pair/'workbook.json',{**read(pair/'config.json'),'cases':[workbook]})
catalog=read(ordinary/'representative.json')
csv=next(c for c in catalog['cases'] if c['id']=='scripts.csv-meter-report.typed-ascii')
control=next(c for c in read(checkpoint/'representative.json')['cases'] if c['id']=='diagnostic.generated-guarded-report')
config,=read(pair/'config.json')['cases']
catalog['cases']=[config,csv,control]
write(pair/'representative.json',catalog)
write(pair/'jobs.json',{'warm':[[config['id'],'compile'],[csv['id'],'compile-run'],[control['id'],'compile']]})
identity=dict(sourceRevision=base,sourcePatchSHA256=digest(lab/'candidate.patch'),imageFiles=images,
    coreSHA256={role+suffix:hashes[core] for role,hashes in images.items() for suffix in ('','-control')},
    cpythonWorkerSHA256=ref['cpythonWorkerSHA256'],expectedCPythonSHA256=ref['expectedCPythonSHA256'],cpythonPath=ref['cpythonPath'],
    purpose='Measure removal of the eager callable alias table with compatible reexport prefixes.',
    catalogs={name:{'sha256':digest(pair/name)} for name in ('representative.json','jobs.json','config.json','workbook.json')})
write(pair/'identity.json',identity)
collector=(prior/'comparison/collect.py').read_text(encoding='utf-8').replace('lython-numeric-callable-catalog-','lython-module-reexports-')
compile(collector,'collect.py','exec')
(pair/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
print('Frozen',base,identity['sourcePatchSHA256'],version)
