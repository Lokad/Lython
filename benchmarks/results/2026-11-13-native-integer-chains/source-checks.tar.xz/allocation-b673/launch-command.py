from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config={'root': '/home/lokad/lython-bench-checks/integer-chain-allocation-b673-20261113', 'unit': 'lython-b673-integer-allocation-20261113', 'sourceRoot': '/home/lokad/lython-bench-checks/integer-chain-b672-20261113', 'identity': {'purpose': 'R311 targeted original/rich invoice allocation with unchanged existing ALC driver; exact source pair8f versus91d, clocks diagnostic', 'coreSHA256': {'reference': '8f69261d79a3e32a563bb374d1ad9bc49b980b1b9884fbf697fea02996068aa2', 'candidate': '91d0540d439109dd35f3246c4c6234a69a2bc2b698012c83859e9d425d14cc78'}, 'catalogSHA256': '8540e010f8421b83ec41be0f1a69116340be12e20709e9d14bfb1a3ef6d3e327', 'sourceIdentitySHA256': '74425344d27a0ee2b0c355e8699670f49a039eced6b6f647a334e9455072b99d', 'driverSourceSHA256': 'a362f1ec590dfc128903d8152eccd4648bf83be7feb07214cc75e487f61e46da', 'driverSHA256': '794b87445e08139a12ff648ffd0463eb0aec361afad659a2a389f49d8f3b3052'}, 'payloadBytes': 2350, 'payloadSHA256': 'b2756310195df9f2e5c324051d6fabc835f01e48bc20a6f4fca1dacbfb4cfe8f', 'unpackedBytes': 4832}
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot'])
assert root.parent==base and source.parent==base and not root.exists()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(source/'guest-fixtures').exists()
 users=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True)
 assert users.returncode==1,users.stdout
 for role in ['reference','candidate']:assert digest(source/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]
 assert digest(source/'source-identity.json')==config['identity']['sourceIdentitySHA256']
 before=shutil.disk_usage(base).free
 assert before>252*1024*1024+config['unpackedBytes']+2*1024*1024
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as archive:archive.extractall(root,filter='data')
 prior=base/'tuple-allocation-b670-20261113'
 for name in ['catalog.json','witness.json','complete-jobs.dll','complete-jobs.deps.json','complete-jobs.runtimeconfig.json']:os.link(prior/name,root/name)
 assert digest(root/'catalog.json')==config['identity']['catalogSHA256']
 assert digest(root/'complete-jobs.dll')==config['identity']['driverSHA256']
 for name in ['collect.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 (root/'space-preflight.json').write_text(json.dumps(dict(freshIdleLease=True,beforeFreeBytes=before,afterStagingFreeBytes=shutil.disk_usage(base).free,osFloorMiB=240,evidenceHeadroomMiB=12,additionalArchiveHeadroomMiB=2,retired=[]),indent=2)+'\n')
 assert shutil.disk_usage(base).free>252*1024*1024+2*1024*1024
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b673-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live;print(live)
