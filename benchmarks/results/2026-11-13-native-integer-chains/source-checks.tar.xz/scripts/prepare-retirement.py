from pathlib import Path
import ast
r=Path(__file__).parent;old=r.parent/'invoice-current-r309/tuple-r310/inspect-vm.py'
code=old.read_text(encoding='utf-8');start=code.index('specs=');end=code.index('\nproofs=',start)
code=code[:start]+"specs=[('tuple-return-final-b669-20261113/reference/Lokad.Lython.dll','benchmarks/results/2026-11-13-immutable-repetition/source-checks.tar.xz',r.parent/'immutable-repeat-r307/index-corrected/Lokad.Lython.dll')]"+code[end:]
code=code.replace("m.name.endswith('candidate-core.dll')","m.name.endswith('.dll')").replace('len(aliases)==info.st_nlink==2','len(aliases)==info.st_nlink and info.st_nlink>=1')
code=code.replace('canonically preserved superseded/unqualified bytes','canonically preserved prior qualified bytes; current8f remains')
ast.parse(code);(r/'inspect-retirement.py').write_text(code,encoding='utf-8')
print('Read-only retirement inspection prepared; run only after B671 joins.')
