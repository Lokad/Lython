from pathlib import Path
import base64,json,subprocess,hashlib
r=Path(__file__).parent
specs=[('tuple-return-scratch-b667-20261113/observations.tgz','benchmarks/results/2026-11-13-native-tuple-return/scratch/observations.tgz'),('tuple-return-direct-b668-20261113/observations.tgz','benchmarks/results/2026-11-13-native-tuple-return/operands/observations.tgz'),('tuple-return-final-b669-20261113/observations.tgz','benchmarks/results/2026-11-13-native-tuple-return/final/observations.tgz'),('tuple-allocation-b670-20261113/observations.tgz','benchmarks/results/2026-11-13-native-tuple-return/final/allocation/observations.tgz')]
proofs=[]
for remote,local in specs:
    p=Path(local)
    if p.exists():
        data=p.read_bytes();assert subprocess.check_output(['git','show','HEAD:'+local])==data
        proofs.append(dict(path=remote,sha256=hashlib.sha256(data).hexdigest(),canonical=local))
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');rows=[]
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[d]otnet.*complete-jobs.dll|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 for row in PROOFS:
  p=base/row['path']
  if not p.exists():rows.append(dict(row,missing=True));continue
  s=p.lstat();assert p.resolve()==p and p.is_relative_to(base)and s.st_uid==os.getuid()and s.st_nlink==1
  assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
  rows.append(dict(row,device=s.st_dev,inode=s.st_ino,bytes=s.st_size,allocatedBytes=s.st_blocks*512))
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,archives=rows)))
'''.replace('PROOFS',repr(proofs))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
p=subprocess.run(ssh+[command],capture_output=True);(r/'vm-inspection.json').write_bytes(p.stdout);assert p.returncode==0,p.stderr.decode();print(p.stdout.decode())
