from pathlib import Path
import os,subprocess
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
project='tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj'
for phase in ['build','test']:
 p=r/('corrected-public-'+phase+'.log');assert not p.exists()
 args=[str(sdk/'dotnet.exe'),phase,project,'-c','Release','-f','net11.0','--disable-build-servers']
 args+=['-m:1']if phase=='build'else['--no-build','--filter','FullyQualifiedName~NativeIntegerChainTests|FullyQualifiedName~OperandReadFailureTests','--logger','console;verbosity=normal']
 with p.open('w',encoding='utf-8')as log:done=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 text=p.read_text(encoding='utf-8');print(p.name,done.returncode,text[-1600:],flush=True)
 if done.returncode or 'No test matches'in text:raise SystemExit(done.returncode or 1)
