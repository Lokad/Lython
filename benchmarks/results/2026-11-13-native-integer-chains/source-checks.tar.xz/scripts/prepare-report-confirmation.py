from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;old=r/'b672';out=r/'report-b674';out.mkdir()
root='/home/lokad/lython-bench-checks/integer-report-b674-20261113';oldroot='/home/lokad/lython-bench-checks/integer-chain-b672-20261113'
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'));identity['purpose']='Bounded report-control confirmation after moving candidate spread3.46% and elapsed range-0.68..+4.78%; exact unchanged source pair; originals retained'
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 code=(old/name).read_text(encoding='utf-8').replace(oldroot,root).replace('lython-b672-integer-chain-20261113','lython-b674-integer-report-20261113').replace('B672','B674')
 if name=='collect.py':
  a=code.index('jobs=');b=code.index('\nenv =',a)
  code=code[:a]+"jobs=[['scripts.report-render.large','warm']]\nassert len(jobs)==1 and all(case in cases for case,lane in jobs)\n"+code[b:]
  code=code.replace('rounds=5','rounds=7').replace('range(5)','range(7)').replace('else 8 if case_id in','else 12 if case_id in').replace('affectedWarmupSeconds=8','affectedWarmupSeconds=12')
  code=code.replace('Same-stream integer accumulation; invoice warm/fresh, captured-text/report controls; exact source-pair, no external ratio','Report-only confirmation, longer12s warmup and7rounds; original moving/adverse results retained; no pooled estimate or external ratio')
 elif name in ['archive-owned.py','summarize.py']:
  code=code.replace("len(raw['jobs'])==4","len(raw['jobs'])==1").replace('jobs=4','jobs=1')
 elif name=='retrieve.py':
  code=code.replace("status['receipt']['jobs']==4","status['receipt']['jobs']==1").replace('four-job','one-job')
 if name.endswith('.py'):ast.parse(code)
 (out/name).write_text(code,encoding='utf-8',newline='\n')
files={n:out/n for n in ['identity.json','collect.py','archive-owned.py','run.sh']}
with tarfile.open(out/'payload.tgz','w:gz')as a:
 for name,p in files.items():a.add(p,arcname=name)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
config=dict(root=root,unit='lython-b674-integer-report-20261113',sourceRoot=oldroot,identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=sha(out/'payload.tgz'),unpackedBytes=sum(p.stat().st_size for p in files.values()))
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
code=(r.parent/'invoice-current-r309/tuple-r310/external-b671/launch.py').read_text(encoding='utf-8')
a=code.index('terminal=json.loads(');b=code.index('code=',a)
code=code[:a]+"proof=json.loads(Path('benchmarks/results/2026-11-13-native-tuple-return/final/delivery/source-proof.json').read_text(encoding='utf-8'));assert proof['coreSHA256']==config['identity']['coreSHA256']['reference']\n"+code[b:]
code=code.replace("shutil.copytree(source/'candidate',root/role,copy_function=os.link)","shutil.copytree(source/role,root/role,copy_function=os.link)")
code=code.replace('b671','b674').replace('RuntimeMaxSec=360','RuntimeMaxSec=150').replace('ownerSeconds=360','ownerSeconds=150').replace('timedelta(seconds=240)','timedelta(seconds=90)').replace('observationSeconds=240','observationSeconds=90')
ast.parse(code);(out/'launch.py').write_text(code,encoding='utf-8')
print('B674 one report-only confirmation: unchanged images,12s warmups/7rounds; original adverse evidence stays separate.',flush=True)
