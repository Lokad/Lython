from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).parent.parent/'pytools'))
import psutil
for p in psutil.process_iter(['pid','ppid','name','cmdline','create_time']):
    try:
        a=p.info
        if any(x in ' '.join(a['cmdline']or[])for x in ['integer-chain-r311','read-source.py','git status --short']):
            print(json.dumps(a),p.cpu_times(),flush=True)
    except(psutil.NoSuchProcess,psutil.AccessDenied):pass
