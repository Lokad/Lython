from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk)
with(r/'inspect-build.log').open('w',encoding='utf-8')as log:
    subprocess.run([str(sdk/'dotnet.exe'),'build',str(r/'inspect/inspect.csproj'),'-c','Release','--disable-build-servers'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
p=subprocess.run([str(sdk/'dotnet.exe'),str(r/'inspect/bin/Release/net11.0/Lokad.Lython.WhiteBox.Tests.dll'),'benchmarks/scripts/csv-invoice.py'],env=env,capture_output=True,text=True,encoding='utf-8');assert p.returncode==0,p.stderr
(r/'compiled-facts.json').write_text(p.stdout,encoding='utf-8')
for f in json.loads(p.stdout):
    print(f['Name'],f['FirstTemporarySlot'],f['ValueStorageCapacity'])
    if f['Name']=='rounded_basis_points':print(json.dumps(f,indent=2))
