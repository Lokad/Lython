from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'invoice-current-r309/tuple-r310/final'
for name,count in [('focused-internal-test.log',133),('added-internal-test.log',2),('corrected-public-test.log',30)]:
 text=(r/name).read_text(encoding='utf-8');assert 'Test Run Successful.'in text and f'Total tests: {count}'in text
assert 'Passed: 192'in(r/'focused-public-test.log').read_text(encoding='utf-8')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
baseline=json.loads((old/'candidate-identity.json').read_text(encoding='utf-8'))
sources={p:sha(p)for p in [*baseline['sources'],'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeIntegers.cs']}
changed=[p for p in sources if p not in baseline['sources']or sha(p)!=baseline['sources'][p]]
assert changed==['src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeIntegers.cs']
for role in ['reference','candidate']:
 shutil.copytree(old/'candidate',r/role,copy_function=os.link)
 if role=='candidate':
  (r/role/'Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/role/'Lokad.Lython.dll')
shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),description='R311 existing native instruction stream, one local signed-long accumulator for adjacent unexposed same-slot integer operations; only final boxed value; no new storage or engine',coreSHA256=sha(r/'candidate-core.dll'),referenceSHA256=baseline['coreSHA256'],sources=sources,changed=changed)
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for p in sources:a.add(p,arcname=p)
shutil.copyfile(old/'catalog.json',r/'catalog.json')
print(identity['coreSHA256'],len(sources),'inputs;135internal/216public unique focused cases pass across targeted runs; invalid original fixture preserved.',flush=True)
