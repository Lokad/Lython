from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-13-native-integer-chains');out.mkdir(exist_ok=True)
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['sources'].items())
for src,dest in [(r/'b672',out),(r/'allocation-b673',out/'allocation'),(r/'report-b674',out/'report-confirmation')]:
 dest.mkdir(exist_ok=True)
 receipt=json.loads((src/'archive-receipt.json').read_text(encoding='utf-8'))
 assert receipt['complete']and receipt['allWorkersJoined']and hashlib.sha256((src/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
 for name in ['observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(src/name,dest/name)
 summary=src/'summary.json'if src.name!='allocation-b673'else src/'retrieved/summary.json'
 shutil.copyfile(summary,dest/('timing-summary.json'if dest==out else'summary.json'))
with tarfile.open(out/'source-checks.tar.xz','w:xz')as a:
 for name in ['candidate-core.dll','candidate-identity.json','candidate-sources.tar.xz','compiled-facts.json','retirement-canonical.json','retirement-inspection.json']:
  a.add(r/name,arcname=name)
 for p in sorted(r.glob('*.log')):a.add(p,arcname='checks/'+p.name)
 for p in sorted(r.glob('*.py')):a.add(p,arcname='scripts/'+p.name)
 for phase in ['b672','allocation-b673','report-b674']:
  for p in sorted((r/phase).iterdir()):
   if p.is_file()and p.name not in ['observations.tgz','payload.tgz']:a.add(p,arcname=phase+'/'+p.name)
 for p in [Path('tests/Lokad.Lython.Tests/NativeIntegerChainTests.cs'),Path('tests/Lokad.Lython.PublicApi.Tests/NativeIntegerChainTests.cs')]:a.add(p,arcname='tests/'+p.name+'.'+p.parent.name)
print('Retained91d:573source inputs;135internal/216public unique focused cases; B672/B673/B674 canonical exact-source evidence saved.',flush=True)
