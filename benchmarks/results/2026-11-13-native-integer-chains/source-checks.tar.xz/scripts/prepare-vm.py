from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;old=r.parent/'invoice-current-r309/tuple-r310/final/b669';out=r/'b672';out.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));assert all(sha(p)==h for p,h in source['sources'].items())
root='/home/lokad/lython-bench-checks/integer-chain-b672-20261113';oldroot='/home/lokad/lython-bench-checks/tuple-return-final-b669-20261113'
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='Qualified85c73469/8f69261d versus uncommitted91d0540d same-stream native integer accumulation',purpose='Complete invoice warm/fresh and captured-text/report controls; source-pair, not CPython',coreSHA256={k:source['referenceSHA256']if k.startswith('reference')else source['coreSHA256']for k in identity['coreSHA256']},referenceSourceIdentitySHA256=sha(old.parent/'candidate-identity.json'),sourceIdentitySHA256=sha(r/'candidate-identity.json'),productionSourceArchiveSHA256=sha(r/'candidate-sources.tar.xz'))
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 code=(old/name).read_text(encoding='utf-8').replace(oldroot,root).replace('lython-b669-tuple-return-final-20261113','lython-b672-integer-chain-20261113').replace('B668','B672')
 if name=='collect.py':code=code.replace('CSV shared long fields; text-rich invoice warm/fresh, original invoice/captured controls; exact source-pair, no external ratio','Same-stream integer accumulation; invoice warm/fresh, captured-text/report controls; exact source-pair, no external ratio')
 if name.endswith('.py'):ast.parse(code)
 (out/name).write_text(code,encoding='utf-8',newline='\n')
files={n:out/n for n in ['identity.json','collect.py','archive-owned.py','run.sh']};files.update({'current-core.dll':r/'candidate-core.dll','source-identity.json':r/'candidate-identity.json'})
with tarfile.open(out/'payload.tgz','w:gz')as a:
 for name,p in files.items():a.add(p,arcname=name)
retire=json.loads((r/'retirement-inspection.json').read_text(encoding='utf-8'))['groups'];assert len(retire)==1
assert retire[0]['sha256']=='93a6d13483515e82313ef9136ab3b96d5b432218d7b3461f95d79dbf12df417e'
config=dict(json.loads((old/'config.json').read_text(encoding='utf-8')),root=root,unit='lython-b672-integer-chain-20261113',sourceRoot='/home/lokad/lython-bench-checks/native-return-external-b671-20261113',sourceCoreSHA256=source['referenceSHA256'],identity=identity,retire=retire,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=sha(out/'payload.tgz'),unpackedBytes=sum(p.stat().st_size for p in files.values()))
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
code=(old/'launch.py').read_text(encoding='utf-8').replace('b669','b672')
code=code.replace("for name in ['reference-source-identity.json','cpython-worker.py']:os.link(source/name,root/name)","os.link(source/'source-identity.json',root/'reference-source-identity.json')\n for name in ['cpython-worker.py']:os.link(source/name,root/name)")
code=code.replace('current93 and external2e stay','current8f and external2e stay')
ast.parse(code);(out/'launch.py').write_text(code,encoding='utf-8')
print('B672 four source-pair jobs; exact8f reference, canonical prior93 working aliases retired under fresh lease; staged',config['unpackedBytes'],'bytes.',flush=True)
