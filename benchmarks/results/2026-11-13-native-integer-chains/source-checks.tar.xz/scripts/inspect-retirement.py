from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent
specs=[('tuple-return-final-b669-20261113/reference/Lokad.Lython.dll','benchmarks/results/2026-11-13-immutable-repetition/source-checks.tar.xz',r.parent/'immutable-repeat-r307/index-corrected/Lokad.Lython.dll')]
proofs=[]
for path,canonical,core in specs:
 expected=hashlib.sha256(core.read_bytes()).hexdigest();found=None
 with tarfile.open(canonical)as a:
  for m in a.getmembers():
   if m.isfile()and m.name.endswith('.dll')and hashlib.sha256(a.extractfile(m).read()).hexdigest()==expected:found=dict(canonical=canonical,member=m.name,bytes=m.size,sha256=expected);break
 assert found,(canonical,expected)
 proofs.append(dict(path=path,canonical=found,sha256=expected))
(r/'retirement-canonical.json').write_text(json.dumps(proofs,indent=2)+'\n',encoding='utf-8')
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();specs=SPECS
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 rows=[]
 for item in specs:
  path=base/item['path'];info=path.lstat();assert path.resolve(strict=True)==path and path.is_relative_to(base)and stat.S_ISREG(info.st_mode)and info.st_uid==os.getuid()
  assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']
  aliases=[]
  for folder,dirs,files in os.walk(base,followlinks=False):
   for name in files:
    other=Path(folder)/name;s=other.lstat()
    if(s.st_dev,s.st_ino)==(info.st_dev,info.st_ino):aliases.append(str(other.relative_to(base)))
  assert len(aliases)==info.st_nlink and info.st_nlink>=1,(path,aliases,info.st_nlink)
  rows.append(dict(**item,device=info.st_dev,inode=info.st_ino,links=info.st_nlink,bytes=info.st_size,allocatedBytes=info.st_blocks*512,allAliasesInBase=True,aliases=aliases))
 print(json.dumps(dict(freshIdleLease=True,readOnly=True,freeBytes=shutil.disk_usage(base).free,groups=rows)))
'''.replace('SPECS',repr(proofs))
(r/'inspect-vm-command.py').write_text(code,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
(r/'retirement-inspection.json').write_text(done.stdout,encoding='utf-8');d=json.loads(done.stdout);print('Read-only VM inspection: free',d['freeBytes'],'canonically preserved prior qualified bytes; current8f remains',sum(row['allocatedBytes']for row in d['groups']),flush=True)
