from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;old=r.parent/'invoice-current-r309/tuple-r310/allocation-vm';out=r/'allocation-b673';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(purpose='R311 targeted original/rich invoice allocation with unchanged existing ALC driver; exact source pair8f versus91d, clocks diagnostic',coreSHA256={'reference':source['referenceSHA256'],'candidate':source['coreSHA256']},sourceIdentitySHA256=sha(r/'candidate-identity.json'))
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
root='/home/lokad/lython-bench-checks/integer-chain-allocation-b673-20261113';oldroot='/home/lokad/lython-bench-checks/tuple-allocation-b670-20261113'
for name in ['collect.py','run.sh','retrieve.py','summarize.py']:
 code=(old/name).read_text(encoding='utf-8').replace(oldroot,root).replace('/home/lokad/lython-bench-checks/tuple-return-final-b669-20261113','/home/lokad/lython-bench-checks/integer-chain-b672-20261113').replace('lython-b670-tuple-allocation-20261113','lython-b673-integer-allocation-20261113').replace('B670','B673')
 if name.endswith('.py'):ast.parse(code)
 (out/name).write_text(code,encoding='utf-8',newline='\n')
files={n:out/n for n in ['collect.py','run.sh','identity.json']}
with tarfile.open(out/'payload.tgz','w:gz')as a:
 for name,p in files.items():a.add(p,arcname=name)
config=dict(root=root,unit='lython-b673-integer-allocation-20261113',sourceRoot='/home/lokad/lython-bench-checks/integer-chain-b672-20261113',identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=sha(out/'payload.tgz'),unpackedBytes=sum(p.stat().st_size for p in files.values()))
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
code=(old/'launch.py').read_text(encoding='utf-8').replace('b670','b673')
needle=" with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as archive:archive.extractall(root,filter='data')"
assert needle in code
code=code.replace(needle,needle+"\n prior=base/'tuple-allocation-b670-20261113'\n for name in ['catalog.json','witness.json','complete-jobs.dll','complete-jobs.deps.json','complete-jobs.runtimeconfig.json']:os.link(prior/name,root/name)")
code=code.replace('datetime.timedelta(seconds=120)','datetime.timedelta(seconds=45)').replace('observationSeconds=120','observationSeconds=45')
ast.parse(code);(out/'launch.py').write_text(code,encoding='utf-8')
print('B673 prepared: unchanged two-case driver/catalog/witness hard-linked on VM; payload',config['unpackedBytes'],'bytes.',flush=True)
