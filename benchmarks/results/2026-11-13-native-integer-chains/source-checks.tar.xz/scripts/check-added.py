from pathlib import Path
import hashlib,os,subprocess
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
core=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll');before=hashlib.sha256(core.read_bytes()).hexdigest()
project='tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj'
for phase in ['build','test']:
 p=r/('added-internal-'+phase+'.log');assert not p.exists()
 args=[str(sdk/'dotnet.exe'),phase,project,'-c','Release','-f','net11.0','--disable-build-servers']
 args+=['-m:1']if phase=='build'else['--no-build','--filter','FullyQualifiedName~NativeIntegerChainTests','--logger','console;verbosity=normal']
 with p.open('w',encoding='utf-8')as log:done=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 text=p.read_text(encoding='utf-8');print(p.name,done.returncode,text[-1400:],flush=True)
 if done.returncode or 'No test matches'in text:raise SystemExit(done.returncode or 1)
assert hashlib.sha256(core.read_bytes()).hexdigest()==before
print('Core unchanged by added ownership checks:',before,flush=True)
