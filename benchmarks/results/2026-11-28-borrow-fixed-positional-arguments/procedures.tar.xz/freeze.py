from hashlib import sha256
from pathlib import Path
from shutil import copy2,copytree
from subprocess import check_output
import json

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/'current-regex-cpython-b1985-20261128/comparison/quiet'
short=lab.parent/'current-mixed-cpython-b1978-20261128/comparison/quiet'
sample=lab.parent/'numeric-callable-catalog-b1928-20261128/comparison/numeric.json'
pair=lab/'comparison'
build=lab/'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
digest=lambda bytes_:sha256(bytes_).hexdigest()
file_digest=lambda path:digest(path.read_bytes())
files=lambda folder:{p.name:file_digest(p) for p in folder.iterdir()}
read=lambda path:json.loads(path.read_bytes())
git=lambda *args:check_output(['git',*args],cwd=repo)
prior_identity=read(prior/'identity.json')
head=git('rev-parse','HEAD').decode().strip()
assert head.startswith('3396752f6')
assert git('diff',prior_identity['sourceRevision'],head,'--','src','tests')==b''
patch=git('diff','--binary','HEAD','--','src','tests')
assert patch.count(b'diff --git ')==9
(lab/'candidate.patch').write_bytes(patch)
assert len(prior_identity['imageFiles']['candidate'])==32
assert prior_identity['imageFiles']['candidate']==files(prior/'local-image')
pair.mkdir()
for role in ('reference','candidate'): copytree(prior/'local-image',pair/role)
copy2(build,pair/'candidate/Lokad.Lython.dll')
assert not (pair/'candidate/Lokad.Lython.dll').samefile(build)
images={role:files(pair/role) for role in ('reference','candidate')}
assert {name for name in images['reference'] if images['reference'][name]!=images['candidate'][name]}=={'Lokad.Lython.dll'}
catalog=read(prior/'representative.json')
assert file_digest(prior/'representative.json')==prior_identity['catalogs']['representative.json']['sha256']
control_id='scripts.config-edit.small'
control=next(case for case in read(short/'representative.json')['cases'] if case['id']==control_id)
catalog['cases'].append(control)
source="""from math import sqrt, isclose
total = 0
for amount in range(1, 4097):
    measured = sqrt(amount * amount)
    if isclose(measured, amount):
        total += int(measured)
print(total)
"""
math_id='diagnostic.fixed-positional-math'
math_path=lab/'math-controls.py'
math_path.write_text(source,encoding='utf-8',newline='\n')
linux='/mnt/d/code/Lython/'+math_path.relative_to(repo).as_posix()
python='/mnt/d/code/Lython/.git/agent-notes/review-20261031/bench-cpython-3.13.16-runtime/runtime/bin/python3.13'
golden=check_output(['wsl',python,'-I','-S','-X','utf8',linux])
assert golden==f'{4096*4097//2}\n'.encode(),golden
copy=read(sample)['cases'][0]
assert not copy.get('expectedFilesSha256')
copy.update(id=math_id,source=source,sourceUtf8Bytes=len(source.encode()),sourceSha256=digest(source.encode()),
            expectedOutput=golden.decode(),expectedOutputSha256=digest(golden),size=4096)
fixture=json.loads(copy['fixtureJson'])
fixture['size']=copy['size']
copy['fixtureJson']=json.dumps(fixture,separators=(',', ':'))
copy['fixtureSha256']=digest(copy['fixtureJson'].encode())
catalog['cases'].append(copy)
ordered=['scripts.regex-log-search.module','scripts.regex-log-search.compiled',math_id,control_id]
assert sorted(case['id'] for case in catalog['cases'])==sorted(ordered)
def save(name,item):
 (pair/name).write_text(json.dumps(item,indent=2)+'\n',encoding='utf-8',newline='\n')
save('representative.json',catalog)
save('jobs.json',{'warm': [[case,'warm'] for case in ordered]})
copy2(prior/'cpython-worker.py',pair/'cpython-worker.py')
assert file_digest(pair/'cpython-worker.py')==prior_identity['cpythonWorkerSHA256']
save('identity.json',dict(sourceRevision=head,referenceRevision=head,sourcePatchSHA256=digest(patch),imageFiles=images,
    coreSHA256={role+suffix:image['Lokad.Lython.dll'] for role,image in images.items() for suffix in ('','-control')},
    expectedCPythonSHA256=prior_identity['expectedCPythonSHA256'],cpythonWorkerSHA256=prior_identity['cpythonWorkerSHA256'],
    catalogs={name:{'sha256':file_digest(pair/name)} for name in ('representative.json','jobs.json')},
    purpose='Borrow valid positional arguments directly for fixed builtin and regex calls.'))
print('Verified exact 32-file images and derived the independent fixed-math golden.')
