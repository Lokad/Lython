#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
lab=.git/agent-notes/review-20261031/borrow-fixed-arguments-b1986-20261128
dotnet="$HOME/.dotnet/dotnet"
unset DOTNET_BUNDLE_EXTRACT_BASE_DIR
"$dotnet" test tests/Lokad.Lython.PublicApi.Tests -c Release -f net11.0 --artifacts-path "$lab/ubuntu-tests" \
  --filter 'Category!=Stress&(FullyQualifiedName~Regex|FullyQualifiedName~Math|FullyQualifiedName~Sum|FullyQualifiedName~ExecutableCallLifetime|FullyQualifiedName~AdmissionFailureCommandTests)' > "$lab/ubuntu-net11.0-public.log" 2>&1
"$dotnet" test tests/Lokad.Lython.Tests -c Release -f net11.0 --artifacts-path "$lab/ubuntu-tests" \
  --filter 'Category!=Stress&(FullyQualifiedName~Regex|FullyQualifiedName~CallBinding|FullyQualifiedName~ExecutableCall|FullyQualifiedName~Sum|FullyQualifiedName~PositionalCallTransport|FullyQualifiedName~ExecutableStackAdmission)' > "$lab/ubuntu-net11.0-whitebox.log" 2>&1