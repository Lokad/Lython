from math import sqrt, isclose
total = 0
for amount in range(1, 4097):
    measured = sqrt(amount * amount)
    if isclose(measured, amount):
        total += int(measured)
print(total)
