from pathlib import Path
import fcntl,json,subprocess

root=Path('/home/lokad/lython-bench-checks/whitespace-checks-b284-20261105')
status=subprocess.check_output(['systemctl','show','lython-b284-whitespace-checks-20261105','--property=LoadState,ActiveState,MainPID,Result'],text=True)
assert 'ActiveState=inactive' in status and 'MainPID=0' in status and 'Result=success' in status,status
assert (root/'exit-code.txt').read_text().strip()=='0'
data=json.loads((root/'confirmation/confirmation.json').read_text())
assert data['complete'] and len(data['jobs'])==3
(root/'final-service-status.txt').write_text(status,encoding='utf-8')
with (root.parent/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    subprocess.run(['python3',str(root/'archive.py')],check=True)
