#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/bound-return-target-slot-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/bound-return-target-slot-20261122
white='Category!=Stress&(FullyQualifiedName~NativeIntegerChain|FullyQualifiedName~ComposedNativeCall|FullyQualifiedName~IntegerProtocol|FullyQualifiedName~ExecutableBinding|FullyQualifiedName~NativeTupleReturn|FullyQualifiedName~FormattedStringExecutable|FullyQualifiedName~SimpleFunctionExecutionBoundary)'
public='Category!=Stress&(FullyQualifiedName~Receiver|FullyQualifiedName~NativeIntegerChain|FullyQualifiedName~SharedIntegerChain|FullyQualifiedName~NativeCallback|FullyQualifiedName~OrdinaryMethodCall)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$white" --artifacts-path "$dir/ubuntu" --nologo > "$dir/white-ubuntu.log" 2>&1 || { tail -75 "$dir/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$public" --artifacts-path "$dir/ubuntu" --nologo > "$dir/public-ubuntu.log" 2>&1 || { tail -75 "$dir/public-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$dir/white-ubuntu.log" "$dir/public-ubuntu.log"
