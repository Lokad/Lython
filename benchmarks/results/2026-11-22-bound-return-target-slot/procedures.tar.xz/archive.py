from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
pair=lab/"comparison"
quiet=pair/"quiet"
dest=repo/"benchmarks/results/2026-11-22-bound-return-target-slot"
core="Lokad.Lython.dll"
def read(file): return json.loads(file.read_text(encoding="utf-8-sig"))
def sha(blob): return hashlib.sha256(blob).hexdigest()
def save(file,value): file.write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8",newline="\n")
receipt=read(quiet/"archive-receipt.json")
assert all(receipt[key] for key in ("complete","allWorkersJoined","quietBeforeAndAfter","guestFixturesRemoved","archivedAndVerifiedUnderLease"))
assert sha((quiet/"observations.tgz").read_bytes())==receipt["archiveSHA256"]
status=read(quiet/"terminal-status.json")
assert status["receipt"]==receipt and status["exitCode"]=="0" and not status["remainingWorkers"] and not status["remainingTrace"]
raw=read(quiet/"retrieved/confirmation/confirmation.json")
assert len(raw["jobs"])==receipt["jobs"]==5 and sum(len(row["samples"]) for row in raw["jobs"])==140
identity=read(quiet/"identity.json")
patch=(pair/"source.patch").read_bytes()
staged=subprocess.check_output(["git","diff",identity["reference"],identity["candidate"],"--","src","tests"],cwd=repo)
assert staged==patch and sha(patch)==identity["sourcePatchSHA256"]
decision=sys.argv[1]
assert decision in ("private","retained")
revision=sys.argv[2] if decision=="retained" else None
if revision:
    assert subprocess.check_output(["git","diff",revision+"^",revision,"--","src","tests"],cwd=repo)==patch
identity["productionRevision"]=revision
identity["outcome"]=decision
identity["protocolSHA256"]=read(quiet/"config.json")["protocolSHA256"]
dest.mkdir(exist_ok=True)
save(dest/"source.json",identity)
summary=read(quiet/"quiet-summary.json")
assert len(summary["rows"])==5 and summary["complete"]
del summary["retentionDecisionPending"]
summary["outcome"]=decision
save(dest/"summary.json",summary)
for name in ("observations.tgz","archive-receipt.json","terminal-status.json"):
    shutil.copyfile(quiet/name,dest/name)
shutil.copyfile(pair/"allocation-summary.json",dest/"allocation-summary.json")
data=(quiet/"candidate"/core).read_bytes()
assert sha(data)==identity["imageFiles"]["candidate"][core]
with (dest/"candidate-core.dll.gz").open("wb") as output:
    with gzip.GzipFile(filename="",fileobj=output,mode="wb",mtime=0) as payload:
        payload.write(data)
assert gzip.decompress((dest/"candidate-core.dll.gz").read_bytes())==data
for role in ("reference","candidate"):
    verification=read(pair/(role+"-verify.json"))
    assert verification["state"]=="Completed" and verification["caseCount"]==6 and verification["catalogSha256"]==identity["catalogs"]["representative.json"]["sha256"]
    assert all(row["sharedBudgetBaselineRestored"] for row in read(pair/(role+"-allocation.json"))["rows"])
files=("prepare.py","stage.py","frozen-build.log","test-ubuntu.sh","white-windows.log","public-windows.log",
       "white-ubuntu.log","public-ubuntu.log","white-initial-windows.log","white-initial-ubuntu.log","comparison/inventory.json","comparison/source.patch",
       "comparison/catalog.json","comparison/reference-verify.json","comparison/candidate-verify.json",
       "comparison/reference-allocation.json","comparison/candidate-allocation.json",
       "comparison/launch.py","comparison/summarize.py","comparison/quiet/identity.json","comparison/quiet/config.json",
       "comparison/quiet/run.sh","comparison/quiet/retrieve.py","comparison/quiet/collect.py",
       "comparison/quiet/remote-launch.py","comparison/quiet/archive-owned.py","comparison/quiet/observe-not-before.json",
       "comparison/quiet/launch.log","archive.py")
with tarfile.open(dest/"procedures.tar.xz","w:xz") as archive:
    for name in files:archive.add(lab/name,arcname=name)
with tarfile.open(dest/"procedures.tar.xz") as archive:
    assert set(archive.getnames())==set(files)
