from pathlib import Path
import hashlib
import json
import os
import statistics
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
notes = lab.parent
donor = notes / 'plain-class-fixed-20261123'
image = donor / 'candidate'
protocol = repo / 'benchmarks/cpython-worker.py'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(payload):
    return hashlib.sha256(payload).hexdigest()


identity = read(donor / 'comparison/identity.json')
files = identity['imageFiles']['candidate']
assert len(files) == 32
assert all(sha((image / name).read_bytes()) == value for name, value in files.items())
assert sha(protocol.read_bytes()) == identity['cpythonWorkerSHA256']
catalog = read(notes / 'retained-short-text-cpu-20261123/catalog.json')
original, mixed, quoted = catalog['cases']
assert original['id'] == 'diagnostic.text-summary.nonlocal-computed-width.large'
source = original['source']
compute = '''        nonlocal latest_width
        latest_width = len(line) * 2 + 1
'''
loop = '            for word in words_from_line(line):'
assert source.count(compute) == source.count(loop) == 1
update = '            latest_width = len(line) * 2 + 1\n'
no_cell = source.replace(compute, '').replace(loop, update + loop)
pure_helper = '    def words_from_line(line:str)->list:\n        return line.lower().split()\n\n'
assert no_cell.count(pure_helper) == 1
no_call = no_cell.replace(pure_helper, '').replace(loop, '            for word in line.lower().split():')


def case(name, text):
    encoded = text.encode('utf-8')
    return dict(original, id='diagnostic.text-summary.' + name, source=text,
                sourceUtf8Bytes=len(encoded), sourceSha256=sha(encoded))


catalog['cases'] = [original, case('computed-width-in-caller', no_cell), case('without-per-line-helper', no_call), mixed, quoted]
catalog_path = lab / 'catalog.json'
catalog_path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
verification = lab / 'verification.json'
subprocess.run([dotnet, image / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog', catalog_path,
                '--dotnet', dotnet, '--python', 'C:/Python313/python.exe', '--python-worker', protocol, '--out', verification],
               env=env, check=True, timeout=60)
proof = read(verification)
assert proof['state'] == 'Completed' and proof['caseCount'] == len(catalog['cases'])
assert proof['launched']['library']['sha256'] == files['Lokad.Lython.dll']
subprocess.run([dotnet, image / 'Inspect.dll', catalog_path, lab / 'tapes.json'], env=env, check=True, timeout=30)
subprocess.run([dotnet, image / 'ValidatedAllocation.dll', image, catalog_path, lab / 'allocations.json'],
               env=env, check=True, timeout=45)
for row in read(lab / 'allocations.json')['rows']:
    assert row['sharedBudgetBaselineRestored']
    print(row['id'], statistics.median(row['allocatedBytesPerInvocation']), row['peakExecutionMemoryBytes'])
