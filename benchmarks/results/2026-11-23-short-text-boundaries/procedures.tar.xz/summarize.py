from pathlib import Path
from statistics import median
import hashlib
import json
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / 'comparison/quiet'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


archive = quiet / 'observations.tar.xz'
status = read(quiet / 'terminal-status.json')
receipt = status['receipt']
assert status['exitCode'] == '0' and not status['live'] and not status['fixtures']
assert all(receipt[key] for key in ('complete', 'quietBeforeAndAfter', 'allWorkersJoined', 'guestFixturesRemoved', 'archivedAndVerifiedUnderLease'))
assert hashlib.sha256(archive.read_bytes()).hexdigest() == receipt['archiveSHA256']
identity = read(quiet / 'identity.json')
cases = {case['id']: case for case in read(quiet / 'representative.json')['cases']}
with tarfile.open(archive) as package:
    assert json.load(package.extractfile('identity.json')) == identity
    assert json.load(package.extractfile('jobs.json')) == read(quiet / 'jobs.json')
    raw = json.load(package.extractfile('confirmation/confirmation.json'))
job, = raw['jobs']
assert raw['complete'] and job['workersJoinedAndFixturesRemoved']
assert len(job['samples']) == 42
by_worker = {}
for label, proof in job['identities'].items():
    assert proof['runtimeVersion'] == '11.0.0'
    core, = (item['sha256'] for item in proof['libraries'] if Path(item['path']).name == 'Lokad.Lython.dll')
    assert core == identity['coreSHA256'][label]
    case = cases[identity['casesByRole'][label.removesuffix('-control')]]
    elapsed, cpu = [], []
    for row in job['samples']:
        if row['engine'] != label:
            continue
        response = row['response']
        assert row['lane'] == 'warm' and response['status'] == 'Completed'
        assert all(response[key] == case[key] for key in ('sourceSha256', 'fixtureSha256', 'expectedOutputSha256'))
        assert response['actualOutputSha256'] == case['expectedOutputSha256']
        assert response['actualFilesSha256'] == case['expectedFilesSha256']
        count = response['completedInvocations']
        assert count > 0
        elapsed.append(response['elapsedTicks'] * 1000 / response['clockFrequency'] / count)
        cpu.append(row['externalProcessCpuTicks'] * 1000 / row['externalCpuFrequency'] / count)
    assert len(elapsed) == len(cpu) == 7
    by_worker[label] = dict(elapsed=median(elapsed), cpu=median(cpu))


def pairs(later, earlier, metric):
    changes = [(by_worker[later + a][metric] / by_worker[earlier + b][metric] - 1) * 100
               for a in ('', '-control') for b in ('', '-control')]
    return [min(changes), max(changes)]


rows = {}
for earlier, later in (('representative', 'caller-update'), ('caller-update', 'inline'), ('representative', 'inline')):
    rows[later + ' vs ' + earlier] = dict(elapsed=pairs(later, earlier, 'elapsed'), cpu=pairs(later, earlier, 'cpu'))
summary = dict(source=identity['sourceRevision'], timedBatches=42, elapsedSeconds=raw['elapsedSeconds'],
               workerMediansMs=by_worker, percentChange=rows)
(quiet / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, indent=2))
