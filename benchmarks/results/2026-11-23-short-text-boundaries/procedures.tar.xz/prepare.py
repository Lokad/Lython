from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
base = lab.with_name('owned-class-cpython-20261123')
donor = lab.with_name('plain-class-fixed-20261123')
quiet = lab / 'comparison/quiet'
quiet.mkdir(parents=True, exist_ok=True)
worker_image = donor / 'candidate'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')


def adapt(src, dst, pairs):
    code = src.read_text(encoding='utf-8')
    for old, new in pairs:
        assert code.count(old) == 1, old
        code = code.replace(old, new)
    compile(code, str(dst), 'exec')
    dst.write_text(code, encoding='utf-8', newline='\n')


tracked = 'benchmarks/results/2026-11-23-owned-class-module-slots/'
def committed(name):
    return subprocess.check_output(['git', 'show', 'origin/master:' + tracked + name], cwd=repo)


identity = json.loads(committed('identity.json'))
retained = identity['retainedRevision']
assert not subprocess.check_output(['git', 'diff', '--name-only', retained, 'HEAD', '--', 'src', 'tests'], cwd=repo)
receipt = json.loads(committed('terminal-status.json'))['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archivedAndVerifiedUnderLease']
assert sha(committed('observations.tar.xz')) == receipt['archiveSHA256']
files = identity['imageFiles']['candidate']
assert len(files) == 32 and all(sha((worker_image / name).read_bytes()) == h for name, h in files.items())
catalog = read(lab.with_name('short-text-boundaries-20261123') / 'catalog.json')
catalog['cases'] = catalog['cases'][:3]
roles = dict(zip(('representative', 'caller-update', 'inline'), (case['id'] for case in catalog['cases']), strict=True))
assert len({case['fixtureSha256'] for case in catalog['cases']}) == 1
assert len({case['expectedFilesSha256'] for case in catalog['cases']}) == 1
assert len({case['expectedOutputSha256'] for case in catalog['cases']}) == 1
write(quiet / 'representative.json', catalog)
write(quiet / 'jobs.json', [[roles['representative'], 'warm']])
protocol = repo / 'benchmarks/cpython-worker.py'
assert sha(protocol.read_bytes()) == identity['cpythonWorkerSHA256']
dotnet = Path.home() / '.dotnet11/dotnet.exe'
verify = quiet / 'candidate-verify.json'
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
subprocess.run([dotnet, worker_image / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog', quiet / 'representative.json',
                '--dotnet', dotnet, '--python', 'C:/Python313/python.exe', '--python-worker', protocol, '--out', verify],
               env=env, check=True, timeout=60)
assert read(verify)['state'] == 'Completed' and read(verify)['caseCount'] == 3
assert read(verify)['launched']['library']['sha256'] == files['Lokad.Lython.dll']
assert all(sha((worker_image / name).read_bytes()) == h for name, h in files.items())

run = 'short-text-cpu-boundaries-b1535-20261123'
write(quiet / 'identity.json', dict(sourceRevision=retained, candidate=identity['candidate'],
    frozenImage='/home/lokad/lython-bench-checks/' + run + '/candidate', imageFiles=identity['imageFiles'],
    auxiliaryFiles={name: h for name, h in files.items() if name != 'Lokad.Lython.dll'},
    coreSHA256={label: files['Lokad.Lython.dll'] for role in roles for label in (role, role + '-control')}, casesByRole=roles,
    cpythonWorkerSHA256=identity['cpythonWorkerSHA256'], expectedCPythonSHA256=identity['expectedCPythonSHA256'],
    catalogs={name: dict(sha256=sha((quiet / name).read_bytes())) for name in ('representative.json', 'jobs.json')}))
adapt(base / 'comparison/quiet/collect.py', quiet / 'collect.py', (
    ("assert set(identity['coreSHA256']) == {'candidate','candidate-control'}",
     "assert set(identity['coreSHA256']) == {label for role in identity['casesByRole'] for label in (role, role+'-control')}"),
    ('len(jobs) == 3', 'len(jobs) == 1'),
    ("purpose='CPython checkpoint for the retained quote-heavy invoice'", "purpose='Same-image short text CPU boundaries'"),
    ("labels=['CPython-phases']if diagnostic else ['CPython','candidate-control','CPython-control','candidate']",
     "labels=['representative','caller-update','inline','inline-control','caller-update-control','representative-control']"),
    ("workers=[Worker(label,cases[case_id],'warm',stack)for label in labels]",
     "workers=[Worker(label,cases[identity['casesByRole'][label.removesuffix('-control')]],'warm',stack)for label in labels]"),
    ('math.ceil(n*.40/', 'math.ceil(n*.65/'),
    ("'lython-b1534-fixtures'", "'lython-b1535-fixtures'"),
))
shutil.copyfile(base / 'comparison/quiet/run.sh', quiet / 'run.sh')
assert b'\r' not in (quiet / 'run.sh').read_bytes()
payload = quiet / 'payload.tar.gz'
with tarfile.open(payload, 'w:gz') as archive:
    for name in ('identity.json', 'representative.json', 'jobs.json', 'run.sh', 'collect.py'):
        archive.add(quiet / name, arcname=name)
write(quiet / 'upload.json', dict(root=run, reference='terminal-tuple-reads-b1531-20261123',
    original='plain-class-namespace-b1533-20261123', originalArchive=receipt['archiveSHA256'],
    payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload.read_bytes())))
adapt(base / 'quiet.py', lab / 'quiet.py', (
    ('lython-b1534-owned-class-20261123', 'lython-b1535-short-text-boundaries-20261123'),
    ('.+b1534-', '.+b1535-'), ('lython-b1534-stage-', 'lython-b1535-stage-'),
    ('seconds=157', 'seconds=92'),
))
