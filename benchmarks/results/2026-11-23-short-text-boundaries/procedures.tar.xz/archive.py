from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
dest = repo / 'benchmarks/results/2026-11-23-short-text-boundaries'
status = json.loads((quiet / 'terminal-status.json').read_text(encoding='utf-8'))
receipt = status['receipt']
assert status['exitCode'] == '0' and not status['fixtures'] and not status['live']
assert all(receipt[key] for key in ('complete', 'quietBeforeAndAfter', 'allWorkersJoined', 'guestFixturesRemoved', 'archivedAndVerifiedUnderLease'))
assert hashlib.sha256((quiet / 'observations.tar.xz').read_bytes()).hexdigest() == receipt['archiveSHA256']
assert json.loads((quiet / 'summary.json').read_text(encoding='utf-8'))['timedBatches'] == 42
for name in ('observations.tar.xz', 'summary.json', 'terminal-status.json'):
    assert not (dest / name).exists()
    shutil.copyfile(quiet / name, dest / name)
with tarfile.open(dest / 'procedures.tar.xz', 'w:xz') as archive:
    for name in ('archive.py', 'prepare.py', 'quiet.py', 'summarize.py', 'comparison/quiet/launch.log',
                 'comparison/quiet/observe-not-before', 'comparison/quiet/candidate-verify.json'):
        archive.add(lab / name, arcname=name)
print(dest)
