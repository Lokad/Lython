from io import BytesIO
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
comparison = lab / 'comparison'
record = repo / 'benchmarks/results/2026-11-24-borrowed-regex-names'
record.mkdir(exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
identity = read(comparison / 'identity.json')
catalog = comparison / 'representative.json'
assert digest(catalog) == identity['catalogs']['representative.json']['sha256']
assert identity['candidate'].startswith('ccf11aac8')
cases = [item['id'] for item in read(catalog)['cases']]
assert len(cases) == 4
for role, files in identity['imageFiles'].items():
    assert len(files) == 32 and all(digest(lab / role / name) == checksum for name, checksum in files.items())
    smoke = read(comparison / (role + '-verify.json'))
    assert smoke['state'] == 'Completed' and smoke['caseCount'] == len(cases)
    assert smoke['launched']['library']['sha256'] == files['Lokad.Lython.dll']
    local = read(lab / (role + '-allocation-six.json'))['rows']
    assert [row['id'] for row in local] == cases and all(row['sharedBudgetBaselineRestored'] for row in local)
allocation = read(lab / 'allocation-summary-six.json')
for i, row in enumerate(allocation):
    assert row['case'] == cases[i]
    a, b = row['allocatedBytes']
    assert (b < a) if i < 2 else (a == b)
    a, b = row['peakAdmission']
    assert (b < a) if i < 2 else (a == b)
shutil.copyfile(lab / 'allocation-summary-six.json', record / 'allocation-summary.json')
shutil.copyfile(comparison / 'identity.json', record / 'identity.json')
inputs = ('prepare.py','allocations.py','archive.py','comparison/representative.json',
    'reference-allocation-six.json','candidate-allocation-six.json','comparison/reference-verify.json','comparison/candidate-verify.json')
source = subprocess.check_output(['git','diff','--binary',identity['sourceRevision'],identity['candidate'],'--','src','tests'],cwd=repo)
with tarfile.open(record / 'observations.tar.xz', 'w:xz') as archive:
    for name in inputs:
        archive.add(lab / name, arcname=name)
    entry = tarfile.TarInfo('changes.patch')
    entry.size = len(source)
    archive.addfile(entry, BytesIO(source))
with tarfile.open(record / 'observations.tar.xz') as archive:
    assert set(archive.getnames()) == set(inputs) | {'changes.patch'}
    assert archive.extractfile('changes.patch').read() == source
    assert all(hashlib.sha256(archive.extractfile(name).read()).hexdigest() == digest(lab / name) for name in inputs)
