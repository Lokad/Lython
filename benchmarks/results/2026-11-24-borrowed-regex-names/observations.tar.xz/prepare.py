from pathlib import Path
import contextlib
import hashlib
import io
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / '.git/agent-worktrees/borrow-regex-names-20261124'
comparison = lab / 'comparison'
comparison.mkdir(exist_ok=True)
donor = lab.with_name('regex-coordinate-tuples-20261124')
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
sha = lambda text: hashlib.sha256(text.encode('utf-8')).hexdigest()
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
write = lambda path, value: path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n',
    newline='\n', encoding='utf-8')

catalog = read(donor / 'comparison/representative.json')
fixture = '{"size":1024,"text":null}'
name = 'équipe_' + 'segment_' * 64 + '尾'
cases = []
for label, group, template in (
    ('short-name', 'équipe', r'[\g<équipe>]'),
    ('long-name', name, rf'[\g<{name}>]'),
    ('numeric', 'équipe', r'[\g<6>]'),
    ('literal', 'équipe', '[α]'),
):
    source = (
        "import re\n"
        f"pattern = re.compile(r'(a)(b)(c)(d)(e)(?P<{group}>α)')\n"
        "match = pattern.fullmatch('abcdeα')\n"
        "total = 0\n"
        "for _ in range(1024):\n"
        f"    expanded = match.expand(r'{template}')\n"
        "    total += len(expanded)\n"
        "print(total, expanded)\n"
    )
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        exec(compile(source, label + '.py', 'exec'), {'__name__': '__main__'})
    result = output.getvalue()
    assert result == '3072 [α]\n'
    cases.append(dict(id='scripts.regex-repeat-expansion.' + label, family='scripts', category='whole-script',
        scale='medium', size=1024, source=source, fixtureJson=fixture, expectedOutput=result,
        sourceUtf8Bytes=len(source.encode('utf-8')), expectedOutputUtf8Bytes=len(result.encode('utf-8')),
        fixtureTextUtf8Bytes=0, fixtureTextCodePoints=0, sourceSha256=sha(source), fixtureSha256=sha(fixture),
        expectedOutputSha256=sha(result)))
catalog['cases'] = cases
representative = comparison / 'representative.json'
write(representative, catalog)

metadata = read(donor / 'comparison/identity.json')
files = metadata['imageFiles']['candidate']
runtime = Path.home() / '.dotnet11'
dotnet = runtime / 'dotnet.exe'
cpython = 'C:/Python313/python.exe'
protocol = repo / 'benchmarks/cpython-worker.py'
env = dict(os.environ, DOTNET_ROOT=str(runtime), DOTNET_ROOT_X64=str(runtime))
assert metadata['candidate'].startswith('3e5826f7d')
assert digest(protocol) == metadata['cpythonWorkerSHA256']
assert len(files) == 32 and all(digest(donor / 'candidate' / name) == sha for name, sha in files.items())
images = {}
core = 'Lokad.Lython.dll'
for role in ('reference', 'candidate'):
    image = lab / role
    image.mkdir(exist_ok=True)
    for name in files:
        source = lab / 'frozen/bin/Lokad.Lython/release_net11.0' / core if role == 'candidate' and name == core else donor / 'candidate' / name
        shutil.copyfile(source, image / name)
    for suffix in ('.dll', '.deps.json', '.runtimeconfig.json'):
        helper = 'ValidatedAllocation' + suffix
        shutil.copyfile(donor / 'candidate' / helper, image / helper)
    files_verified = {name: digest(image / name) for name in files}
    result = comparison / (role + '-verify.json')
    subprocess.run([dotnet, image / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify',
        '--catalog', representative, '--dotnet', dotnet, '--python', cpython, '--python-worker', protocol, '--out', result],
        env=env, check=True, timeout=85)
    verified = read(result)
    assert verified['state'] == 'Completed' and verified['caseCount'] == len(cases)
    assert verified['launched']['library']['sha256'] == files_verified[core]
    assert all(digest(image / name) == expected for name, expected in files_verified.items())
    images[role] = files_verified
assert files == images['reference']
assert [name for name in files if images['reference'][name] != images['candidate'][name]] == [core]
candidate = subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree).decode().strip()
assert candidate.startswith('ccf11aac8')
write(comparison / 'identity.json', dict(sourceRevision=metadata['candidate'], candidate=candidate,
    purpose='Named UTF-8 replacement expansion without lookup copies', imageFiles=images,
    catalogs={'representative.json': {'sha256': digest(representative)}},
    cpythonWorkerSHA256=metadata['cpythonWorkerSHA256']))
