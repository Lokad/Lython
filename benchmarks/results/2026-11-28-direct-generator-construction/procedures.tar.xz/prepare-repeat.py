from hashlib import sha256
import json
from pathlib import Path
from shutil import copy2, copytree


lab = Path(__file__).resolve().parent
first = lab / 'comparison'
repeat = lab / 'control/comparison'


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


identity = read(first / 'identity.json')
assert read(first / 'archive-receipt.json')['archiveSHA256'] == digest(first / 'observations.tar.xz')
for role, files in identity['imageFiles'].items():
    assert {path.name: digest(path) for path in (first / role).iterdir()} == files
    copytree(first / role, repeat / role)
    assert {path.name: digest(path) for path in (repeat / role).iterdir()} == files
for name in ('representative.json', 'cpython-worker.py', 'run.sh'):
    copy2(first / name, repeat / name)
assert b'\r' not in (repeat / 'run.sh').read_bytes()

jobs = [job for job in reversed(read(first / 'jobs.json')['warm'])
        if job[0] == 'scripts.config-edit.small' or job == ['diagnostic.generator-call-defaults', 'warm-async']]
assert len(jobs) == 2
write(repeat / 'jobs.json', {'warm': jobs})
identity['catalogs']['jobs.json']['sha256'] = digest(repeat / 'jobs.json')
identity['purpose'] = 'Repeat default generator setup and configuration in reverse order on the same images.'
write(repeat / 'identity.json', identity)
collector = (first / 'collect.py').read_text(encoding='utf-8')
assert collector.count('len(jobs) == 5') == 1 and collector.count('if job_index % 2 != 0: labels.reverse()') == 1
collector = collector.replace('len(jobs) == 5', 'len(jobs) == 2').replace(
    'if job_index % 2 != 0: labels.reverse()', 'if job_index % 2 == 0: labels.reverse()')
(repeat / 'collect.py').write_text(collector, encoding='utf-8', newline='\n')
summary = (lab / 'summarize-warm.py').read_text(encoding='utf-8')
assert summary.count('== 140') == summary.count('== 5') == 1
(lab / 'control/summarize-warm.py').write_text(summary.replace('== 140', '== 56').replace('== 5', '== 2', 1),
    encoding='utf-8', newline='\n')
