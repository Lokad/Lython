from hashlib import sha256
import json
from pathlib import Path
from shutil import copy2
import tarfile


lab = Path(__file__).resolve().parent
out = lab.parents[3] / 'benchmarks/results/2026-11-28-direct-generator-construction'
comparison = lab / 'comparison'


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


identity = read(comparison / 'identity.json')
assert digest(lab / 'candidate.patch') == identity['sourcePatchSHA256']
for role, image in identity['imageFiles'].items():
    assert {path.name: digest(path) for path in (comparison / role).iterdir()} == image
    verification = read(comparison / f'{role}-verify.json')
    assert verification['state'] == 'Completed' and verification['caseCount'] == 4
    assert verification['launched']['library']['sha256'] == image['Lokad.Lython.dll']
    assert verification['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
assert read(comparison / 'summary.json')['verifiedTimedBatches'] == 140
receipt = read(comparison / 'archive-receipt.json')
assert receipt['archiveSHA256'] == digest(comparison / 'observations.tar.xz') and receipt['allWorkersJoined']
allocations = read(lab / 'allocation/summary.json')
admissions = read(lab / 'admission/summary.json')
assert len(allocations) == len(admissions) == 8
for row in allocations:
    assert all(row[field][0] == row[field][1] for field in ('clr', 'admittedPeak', 'compiled'))
for row in admissions:
    assert row['requests'][0] == row['requests'][1] and row['peak'][0] == row['peak'][1]
for log in lab.glob('*net*.log'):
    text = log.read_text(encoding='utf-8-sig')
    assert 'Failed:     0' in text and ('Passed:   525' if 'PublicApi' in log.name else 'Passed:   105') in text
assert len(list(lab.glob('*net*.log'))) == 6

out.mkdir(exist_ok=True)
for name, source in [('identity.json', comparison / 'identity.json'), ('warm-observations.tar.xz', comparison / 'observations.tar.xz'),
    ('warm-summary.json', comparison / 'summary.json'), ('allocation.json', lab / 'allocation/summary.json'),
    ('admission.json', lab / 'admission/summary.json')]:
    copy2(source, out / name)
    assert digest(out / name) == digest(source)

paths = {file.name: file for file in lab.iterdir() if file.is_file() and file.suffix in ('.py', '.ps1', '.sh', '.json', '.log', '.patch')}
for name in ('reference-verify.json', 'candidate-verify.json', 'archive-receipt.json'):
    paths[f'comparison/{name}'] = comparison / name
for name in ('admission', 'allocation'):
    for path in (lab / name).glob('*.json'):
        paths[f'{name}/{path.name}'] = path
repeat = lab / 'control/comparison'
if (repeat / 'summary.json').exists():
    repeat_identity = read(repeat / 'identity.json')
    assert repeat_identity['imageFiles'] == identity['imageFiles']
    assert repeat_identity['sourcePatchSHA256'] == identity['sourcePatchSHA256']
    assert read(repeat / 'summary.json')['verifiedTimedBatches'] == 56
    receipt = read(repeat / 'archive-receipt.json')
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
    assert receipt['archiveSHA256'] == digest(repeat / 'observations.tar.xz')
    for name in ('identity.json', 'summary.json', 'observations.tar.xz'):
        target = out / f'repeat-{name}'
        copy2(repeat / name, target)
        assert digest(target) == digest(repeat / name)
    for name in ('reference-verify.json', 'candidate-verify.json', 'archive-receipt.json', 'collect.py', 'run.sh', 'jobs.json'):
        paths[f'repeat/{name}'] = repeat / name
    paths['repeat/summarize-warm.py'] = lab / 'control/summarize-warm.py'
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in paths.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    assert all(sha256(archive.extractfile(name).read()).hexdigest() == digest(path) for name, path in paths.items())
print('Verified six test suites, five warm comparisons, allocation and admission in both APIs, and archive contents.')
