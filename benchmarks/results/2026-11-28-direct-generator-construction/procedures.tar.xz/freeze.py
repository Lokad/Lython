from hashlib import sha256
import json
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output


lab = Path(__file__).resolve().parent
repo = lab.parents[3]
reference = lab.parent / 'owner-type-new-slots-b1990-20261128'
shipment = lab.parent / 'deferred-starmap-row-b1980-20261128'
pair = lab / 'comparison'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def manifest(folder):
    return {path.name: digest(path) for path in folder.iterdir()}


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')


previous = read(reference / 'comparison/identity.json')
head = check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()
assert sha256(check_output(['git', 'diff', '--binary', previous['sourceRevision'], head, '--', 'src', 'tests'], cwd=repo)).hexdigest() == previous['sourcePatchSHA256']
image = reference / 'comparison/candidate'
assert len(previous['imageFiles']['candidate']) == 32 and manifest(image) == previous['imageFiles']['candidate']
for role in ('reference', 'candidate'):
    copytree(image, pair / role)
copy2(build, pair / 'candidate/Lokad.Lython.dll')
images = {role: manifest(pair / role) for role in ('reference', 'candidate')}
assert images['reference'] == previous['imageFiles']['candidate']
assert not (pair / 'candidate/Lokad.Lython.dll').samefile(build)
assert {name for name, value in images['reference'].items() if images['candidate'][name] != value} == {'Lokad.Lython.dll'}
patch = check_output(['git', 'diff', '--binary', 'HEAD', '--', 'src', 'tests'], cwd=repo)
assert patch.count(b'diff --git ') == 3
(lab / 'candidate.patch').write_bytes(patch)

catalog = read(reference / 'comparison/representative.json')
config, staged = 'scripts.config-edit.small', 'diagnostic.shipment-starmap-iterable-rows'
ordinary, positional = 'diagnostic.generator-call-defaults', 'diagnostic.generator-call-positional'
cases = {case['id']: case for case in catalog['cases']}
cases.update({case['id']: case for case in read(shipment / 'comparison/representative.json')['cases']})
assert config in cases and staged in cases
size = 512
fixture = '{"size":512,"text":null}'


def add(case_id, source, number):
    golden = f'{number}\n'
    cases[case_id] = dict(id=case_id, family='scripts', category='whole-script', scale='small', size=size,
        source=source, fixtureJson=fixture, expectedOutput=golden, sourceUtf8Bytes=len(source),
        expectedOutputUtf8Bytes=len(golden), fixtureTextUtf8Bytes=0, fixtureTextCodePoints=0,
        sourceSha256=sha256(source.encode()).hexdigest(), fixtureSha256=sha256(fixture.encode()).hexdigest(),
        expectedOutputSha256=sha256(golden.encode()).hexdigest(), expectedFilesSha256=None)


add(ordinary, '''def row(value, *, offset=2):
    yield value + offset
class Builder:
    def row(self, value, *, offset=3):
        yield value + offset
saved = Builder().row
total = 0
for i in range(512):
    total += next(row(i)) + next(saved(i))
    total += next(row(value=i, offset=4)) + next(saved(value=i, offset=5))
print(total)
''', 4 * (size * (size - 1) // 2) + 14 * size)
add(positional, '''def row(value):
    yield value
class Builder:
    def row(self, value):
        yield value + 1
saved = Builder().row
total = 0
for i in range(512):
    total += next(row(i)) + next(saved(i))
print(total)
''', size * size)
write(pair / 'representative.json', dict(catalog, cases=[cases[key] for key in (ordinary, positional, staged, config)]))
jobs = [(ordinary, 'warm'), (ordinary, 'warm-async'), (positional, 'warm-async'), (staged, 'warm-async'), (config, 'warm')]
write(pair / 'jobs.json', {'warm': jobs})
for name in ('collect.py', 'run.sh', 'cpython-worker.py'):
    copy2(reference / 'comparison' / name, pair / name)
assert b'\r' not in (pair / 'run.sh').read_bytes()
assert digest(pair / 'cpython-worker.py') == previous['cpythonWorkerSHA256']
write(pair / 'identity.json', dict(sourceRevision=head, sourcePatchSHA256=sha256(patch).hexdigest(), imageFiles=images,
    coreSHA256={role + suffix: files['Lokad.Lython.dll'] for role, files in images.items() for suffix in ('', '-control')},
    cpythonWorkerSHA256=previous['cpythonWorkerSHA256'], expectedCPythonSHA256=previous['expectedCPythonSHA256'],
    purpose='Ordinary generator calls pass bound arguments straight to construction.',
    catalogs={name: {'sha256': digest(pair / name)} for name in ('representative.json', 'jobs.json')}))

copy2(reference / 'summarize-warm.py', lab / 'summarize-warm.py')
previous_witness = lab.parent / 'borrow-fixed-arguments-b1986-20261128'
for name in ('measure-allocation.py', 'check-admission.py'):
    copy2(previous_witness / name, lab / name)
