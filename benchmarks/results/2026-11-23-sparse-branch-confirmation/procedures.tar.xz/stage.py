from pathlib import Path
import hashlib,io,json,shutil,subprocess,tarfile
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/"abstract-state-snapshots-20261123/comparison"
before=prior/"quiet"
out=lab/"comparison"
quiet=out/"quiet"
quiet.mkdir(parents=True,exist_ok=True)
assert not (quiet/"launch.log").exists()
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(b):return hashlib.sha256(b).hexdigest()
def h(p):return sha(p.read_bytes())
def save(p,v):write(p,json.dumps(v,ensure_ascii=False,indent=2)+"\n")
def write(p,s):
    if p.suffix==".py":compile(s,str(p),"exec")
    p.write_text(s,encoding="utf-8",newline="\n")
def published(folder,name):
    return subprocess.check_output(["git","show",f"origin/master:benchmarks/results/{folder}/{name}"],cwd=repo)
def archive(folder):
    receipt=json.loads(published(folder,"archive-receipt.json"))
    raw=published(folder,"observations.tgz")
    assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"] and sha(raw)==receipt["archiveSHA256"]
    return receipt,raw
previous=read(before/"config.json")
source=json.loads(published("2026-11-23-abstract-state-snapshots","source.json"))
receipt,_=archive("2026-11-23-abstract-state-snapshots")
assert source["imageFiles"]==previous["identity"]["imageFiles"]
files=source["imageFiles"]
catalog=quiet/"representative.json"
shutil.copyfile(before/"representative.json",catalog)
assert h(catalog)==source["catalogs"]["representative.json"]["sha256"]
cases=read(catalog)["cases"]
for role,manifest in files.items():
    image=prior/f"frozen-{role}"
    assert len(manifest)==32 and {n:h(image/n)for n in manifest}==manifest
    verify=read(prior/f"{role}-verify.json")
    assert verify["state"]=="Completed" and verify["caseCount"]==len(cases) and verify["catalogSha256"]==h(catalog)
sparse,= (x["id"] for x in cases if x["id"].endswith("sparse-lexical"))
config,= (x["id"] for x in cases if x["id"].endswith("config-edit.small"))
jobs=[(sparse,"compile-run"),(config,"compile-run"),(sparse,"compile")]
identity={**previous["identity"],"purpose":"Confirm sparse validator first result and compiler time on the exact B1442 pair, with worker order reversed."}
save(quiet/"identity.json",identity)
save(out/"jobs.json",jobs)
root="/home/lokad/lython-bench-checks/sparse-branch-confirmation-b1444-20261123"
unit="lython-b1444-sparse-branch-confirmation-20261123"
for name in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    s=(before/name).read_text(encoding="utf-8").replace(previous["root"],root).replace(previous["unit"],unit)
    if name=="collect.py":
        a,b=s.index("\njob_catalog ="),s.index("\nassert len(jobs)")
        s=s[:a]+"\njob_catalog = "+repr({id:"representative.json" for id,_ in jobs})+"\njobs = "+repr(jobs)+s[b:]
        s=s.replace("len(jobs)==8","len(jobs)==3").replace("if job_index % 2 == 0: labels.reverse()","if job_index % 2 != 0: labels.reverse()")
    elif name=="archive-owned.py":
        s=s.replace("len(raw['jobs'])==8","len(raw['jobs'])==3").replace("jobs=8,elapsedSeconds","jobs=3,elapsedSeconds")
    elif name=="retrieve.py":
        s=s.replace("status['receipt']['jobs']==8","status['receipt']['jobs']==3")
    write(quiet/name,s.replace("Abstract state snapshots","Sparse branch confirmation"))
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py")
assert b"\r" not in (quiet/"run.sh").read_bytes()
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz")as bundle:
    for n in parts:bundle.add(quiet/n,arcname=n)
historical="2026-11-23-nested-bound-operand"
old_root="nested-bound-operand-b1439-20261123"
old_receipt,old_raw=archive(historical)
with tarfile.open(fileobj=io.BytesIO(old_raw))as pack:old_catalog=pack.extractfile("representative.json").read()
old_id=json.loads(published(historical,"source.json"))
assert sha(old_catalog)==old_id["catalogs"]["representative.json"]["sha256"]
retire=[dict(paths=[old_root+"/representative.json"],bytes=len(old_catalog),sha256=sha(old_catalog),links=1,
    archives={old_root+"/observations.tgz":old_receipt["archiveSHA256"]})]
cfg={**previous,"root":root,"unit":unit,"identity":identity,"source":previous["root"],"sourceRole":"candidate",
    "sourceFiles":files["candidate"],"sourceCatalogSHA256":h(catalog),"donorArchiveSHA256":receipt["archiveSHA256"],
    "retireGroups":retire,"payloadBytes":payload.stat().st_size,"payloadSHA256":h(payload),
    "unpackedBytes":sum((quiet/n).stat().st_size for n in parts)}
save(quiet/"config.json",cfg)
s=(before/"remote-launch.py").read_text(encoding="utf-8")
a,b=s.index("\nc=")+1,s.index("\nb=Path(")
s=(s[:a]+"c="+repr(cfg)+s[b:]).replace("source/c['sourceRole']/n,p","source/role/n,p")
s=s.replace("RuntimeMaxSec=490","RuntimeMaxSec=215").replace("b1442-fixtures","b1444-fixtures")
write(quiet/"remote-launch.py",s)
s=(prior/"launch.py").read_text(encoding="utf-8").replace("seconds=465","seconds=195").replace("465 seconds","195 seconds")
write(out/"launch.py",s.replace("Abstract state snapshots","Sparse branch confirmation"))
s=(prior/"summarize.py").read_text(encoding="utf-8")
write(out/"summarize.py",s.replace("len(raw['jobs'])==8","len(raw['jobs'])==3"))
print(root,cfg["unpackedBytes"])
