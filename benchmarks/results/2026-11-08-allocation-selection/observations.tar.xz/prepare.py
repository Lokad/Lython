from pathlib import Path
import ast,hashlib,json,shutil
r=Path(__file__).parent;old=r.parent/'builtin-methods-r41';source=r.parent/'shared-cased-split-r92'
for n in ['identity.json','catalog.json']:shutil.copyfile(source/n,r/n)
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
s=(old/'profile-allocation.py').read_text(encoding='utf-8')
s=s.replace("home.parent/'regex-scalar-cursor-r40/images/candidate/Lokad.Lython.Benchmarks.dll'", "home.parent/'shared-cased-split-r92/images/candidate/Lokad.Lython.Benchmarks.dll'")
s=s.replace("[('regex','scripts.regex-capture-summary.large'),('json','scripts.json-summary-helpers.large')]", "[('text','scripts.text-summary-rsplit-helpers.large'),('csv','scripts.csv-summary-functions.large')]")
s=s.replace('eb6052d0992e1e7eb236b72d6d39cac59279a67ef2c8047604f047447a55692c','68f63d2969afd9953fc848926685daea5a951996b942fa05a416227b2ab4bdb3')
s=s.replace('Windows x64/.NET11RC3, current1971487a production/frozeneb6052d0','Windows x64/.NET11RC3, committed05d81b83/frozen68f63d29')
s=s.replace('Both R41 allocation profiles complete','Both R94 allocation profiles complete')
ast.parse(s);(r/'profile-allocation.py').write_text(s,encoding='utf-8')
collector=r.parent/'activation-allocation-d36/collector/bin/Release/net11.0/collector.dll'
(r/'collector-provenance.json').write_text(json.dumps(dict(source=str(r.parent/'activation-allocation-d36/collector/Program.cs'),collectorSHA256=hashlib.sha256(collector.read_bytes()).hexdigest(),noCollectorChange=True,normalGcAndTiering=True,diagnosticOnly=True),indent=2)+'\n',encoding='utf-8')
print('Existing unchanged allocation collector; two bounded complete scripts, no CPU timing claim.')
