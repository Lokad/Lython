from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-08-allocation-selection');out.mkdir(exist_ok=True)
records=json.loads((r/'allocation/records.json').read_text());assert records['complete']
for record in records['records']:
 assert all(record[k]for k in ['allGoldensPassed','collectorJoined','workerClosedAndJoined','ownedFixturesRemoved'])
 assert record['collector']['eventsLost']==0
collector=r.parent/'activation-allocation-d36/collector/Program.cs';shutil.copyfile(collector,r/'unchanged-collector.cs')
with tarfile.open(out/'observations.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if p.is_file()and '__pycache__'not in p.parts:a.add(p,arcname=p.relative_to(r).as_posix())
with tarfile.open(out/'observations.tar.xz')as a:
 for m in a.getmembers():assert m.isfile()and hashlib.sha256(a.extractfile(m).read()).digest()==hashlib.sha256((r/m.name).read_bytes()).digest()
shutil.copyfile(r/'assessment.json',out/'assessment.json')
print('Two original allocation captures/source/procedure/collector evidence archived and verified;', (out/'observations.tar.xz').stat().st_size,'bytes. No runtime change.')
