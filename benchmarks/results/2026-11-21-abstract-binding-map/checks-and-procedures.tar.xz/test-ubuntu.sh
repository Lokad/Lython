set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/compiler-construction-20261121
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/abstract-binding-map
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~AbstractState|FullyQualifiedName~StaticFact|FullyQualifiedName~StaticCallArgument|FullyQualifiedName~CompilationLifetime|FullyQualifiedName~ExpressionSyntaxTraversal)&Category!=Stress' | tee "$logs/white-ubuntu.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~StaticErrorDiagnostic|FullyQualifiedName~Annotation|FullyQualifiedName~GuardedDictionary|FullyQualifiedName~NestedSequenceFact|FullyQualifiedName~ComprehensionEffect|FullyQualifiedName~RegexAnalysis|FullyQualifiedName~CompilerCancellation|FullyQualifiedName~NameBinding|FullyQualifiedName~SyntaxCorpus)&Category!=Stress' | tee "$logs/public-ubuntu.log"
