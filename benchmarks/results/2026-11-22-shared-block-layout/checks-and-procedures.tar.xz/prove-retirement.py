from pathlib import Path
import gzip
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(bytes_):
    return hashlib.sha256(bytes_).hexdigest()
def pushed(tracked, name):
    return subprocess.check_output(["git", "show", "origin/master:" + tracked + name], cwd=repo)

core = "Lokad.Lython.dll"
retained = {}
previous = lab.parent / "executable-definition-inputs-r578"
tracked = "benchmarks/results/2026-11-18-executable-definition-inputs/"
old = read(previous / "quiet/config.json")
identity = read(previous / "quiet/identity.json")
files = identity["imageFiles"]["candidate"]
image = previous / "frozen/candidate"
assert len(files) == 32 and all(sha((image / n).read_bytes()) == h for n, h in files.items())
original = (image / core).read_bytes()
assert sha(original) == files[core]
receipt = read(previous / "quiet/archive-receipt.json")
assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["archivedAndVerifiedUnderLease"]
raw_sha = sha(pushed(tracked,"observations.tgz"))
assert raw_sha == receipt["archiveSHA256"]
retained[Path(old["root"]).name] = dict(archive=tracked,bytes=len(original),coreSHA256=files[core],
    archiveSHA256=raw_sha,authoritativeImageSHA256=files,authoritativeImage=str(image))
source = r'''
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat
base=Path('/home/lokad/lython-bench-checks')
copies=COPIES
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not any(p.is_mount() for p in base.glob('*/guest-fixtures'))
    for root_name,witness in copies.items():
        root=base/root_name
        core=root/'candidate/Lokad.Lython.dll'
        if core.exists(): break
    else: raise RuntimeError('No archived working replica is present')
    archive=root/'observations.tgz'
    assert core.resolve()==core and sha(core)==witness['coreSHA256'] and sha(archive)==witness['archiveSHA256']
    info=core.lstat()
    assert info.st_size==witness['bytes']
    paths=[]
    for folder,_,names in os.walk(base):
        for name in names:
            path=Path(folder)/name
            record=path.lstat()
            if (record.st_dev, record.st_ino)!=(info.st_dev, info.st_ino):continue
            assert path.resolve()==path and stat.S_ISREG(record.st_mode) and record.st_uid==os.getuid()
            paths.append(str(path.relative_to(base)))
    assert len(paths)==info.st_nlink
    proof=dict(paths=sorted(paths),bytes=info.st_size,links=info.st_nlink,sha256=witness['coreSHA256'],
        archives={str(archive.relative_to(base)):witness['archiveSHA256']},optional=False)
    print(json.dumps(dict(free=shutil.disk_usage(base).free,proof=[proof],selected=witness),indent=2))
'''.replace("COPIES", repr(retained))
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),
       "-o","BatchMode=yes","-o","ConnectTimeout=15","lokad@20.166.121.73","python3 -"]
proof = json.loads(subprocess.check_output(ssh, input=source, encoding="utf-8", timeout=35))
(lab/"retire-proof.json").write_text(json.dumps(proof,indent=2)+"\n",encoding="utf-8",newline="\n")
print(proof["free"], proof["proof"])
