from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab/"quiet"
out = Path("benchmarks/results/2026-11-22-shared-block-layout")
def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

identity = read(quiet/"identity.json")
before, _, after = identity["sourceRevision"].split()
assert before.startswith("fd41c741e") and after.startswith("46c7e347f")
cases = {c["id"]:c for c in read(quiet/"representative.json")["cases"]}
assert len(cases)==4
for role,files in identity["imageFiles"].items():
    image = lab/"frozen"/role
    assert len(files)==32 and {n:sha(image/n) for n in files}==files
    proof = read(lab/f"quiet-{role}-verify.json")
    assert proof["state"]=="Completed" and proof["caseCount"]==4 and proof["catalogSha256"]==sha(quiet/"representative.json")
    inspected = read(lab/f"{role}-inspection.json")
    assert inspected["coreSHA256"]==files["Lokad.Lython.dll"]
assert read(lab/"reference-inspection.json")["rows"]==read(lab/"candidate-inspection.json")["rows"]
allocation = read(lab/"compile-allocation-summary.json")
assert len(allocation["rows"])==11
for platform in ("win","ubuntu"):
    for suite,count in (("white",362),("public",1992)):
        text = (lab/f"{suite}-{platform}.log").read_text(encoding="utf-8-sig")
        assert "Passed!" in text and f"Passed: {count:5d}, Skipped:" in text
receipt = read(quiet/"archive-receipt.json")
terminal = read(quiet/"terminal-status.json")
assert receipt==terminal["receipt"] and terminal["exitCode"]=="0"
assert not terminal["remainingWorkers"] and not terminal["remainingTrace"]
assert all(receipt[k] for k in ("complete","allWorkersJoined","guestFixturesRemoved","quietBeforeAndAfter","archivedAndVerifiedUnderLease"))
assert sha(quiet/"observations.tgz")==receipt["archiveSHA256"]
raw = read(quiet/"retrieved/confirmation/confirmation.json")
assert raw["complete"] and raw["warmupSeconds"]==12 and raw["targetBatchSeconds"]==.65 and raw["rounds"]==7
assert len(raw["jobs"])==receipt["jobs"]==5
assert [(j["case"],j["lane"]) for j in raw["jobs"]]==[(case,"compile") for case in cases]+[(next(iter(cases)),"compile-run")]
for job in raw["jobs"]:
    case = cases[job["case"]]
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"])==28
    for sample in job["samples"]:
        response = sample["response"]
        assert response["completedInvocations"]>0 and response["status"]=="Completed"
        assert response["sourceSha256"]==case["sourceSha256"] and response["fixtureSha256"]==case["fixtureSha256"]
        if job["lane"]=="compile":
            assert response["actualOutputSha256"] is None
        else:
            assert response["actualOutputSha256"]==case["expectedOutputSha256"]
            assert response.get("actualFilesSha256")==case.get("expectedFilesSha256")
summary = read(quiet/"quiet-summary.json")
del summary["retentionDecisionPending"]
summary.update(collection="B1344",sourceRevision=identity["sourceRevision"],verifiedTimedBatches=140,
    coreSHA256=identity["coreSHA256"],archiveSHA256=receipt["archiveSHA256"],
    retentionDecision=read(lab/"decision.json")["decision"])
out.mkdir(exist_ok=False)
(out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
for name in ("README.md","compile-allocation-summary.json"):
    shutil.copyfile(lab/name,out/name)
for name in ("archive-receipt.json","terminal-status.json","observations.tgz"):
    shutil.copyfile(quiet/name,out/name)
authority = Path("benchmarks/results/2026-11-22-direct-default-instructions/candidate-core.dll.gz")
assert gzip.decompress(authority.read_bytes())==(quiet/"reference/Lokad.Lython.dll").read_bytes()
core = (quiet/"candidate/Lokad.Lython.dll").read_bytes()
(out/"candidate-core.dll.gz").write_bytes(gzip.compress(core,mtime=0))
(lab/"measured-source.patch").write_bytes(subprocess.check_output(["git","diff",before,after,"--","src","tests"]))
with tarfile.open(out/"checks-and-procedures.tar.xz","w:xz",preset=6) as archive:
    for folder in (lab,quiet,lab/"pilot-84132cb78"):
        for path in sorted(folder.iterdir()):
            if path.is_file() and path.suffix not in {".dll",".tgz"}:
                archive.add(path,arcname=path.relative_to(lab).as_posix())
print("140 verified timed batches, frozen images, 79 identical code objects and focused platform checks.")
