from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
root = lab / "confirmation"
out = Path("benchmarks/results/2026-11-21-native-method-lookup/confirmation")

def load(path):
    return json.loads(path.read_text(encoding="utf-8"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

base, fresh = (load(path / "identity.json") for path in (lab / "quiet", root))
for key in ("imageFiles", "sourceRevision", "coreSHA256", "normalAdapterPin"):
    assert base[key] == fresh[key]
assert fresh["catalogSHA256"] == sha(root / "representative.json")
for role, expected in fresh["imageFiles"].items():
    folder = lab / "frozen" / role
    assert len(expected) == 32 and {name: sha(folder / name) for name in expected} == expected
    proof = load(root / f"{role}-verify.json")
    assert proof["state"] == "Completed" and proof["caseCount"] == 1
    assert proof["catalogSha256"] == fresh["catalogSHA256"]

receipt = load(root / "archive-receipt.json")
terminal = load(root / "terminal-status.json")
assert terminal["receipt"] == receipt and terminal["exitCode"] == "0"
assert not terminal["remainingTrace"] and not terminal["remainingWorkers"]
assert all(receipt[key] for key in ("complete", "allWorkersJoined", "guestFixturesRemoved",
                                   "archivedAndVerifiedUnderLease", "quietBeforeAndAfter"))
assert sha(root / "observations.tgz") == receipt["archiveSHA256"]
raw = load(root / "retrieved/confirmation/confirmation.json")
assert raw["complete"] and raw["warmupSeconds"] == 8 and raw["targetBatchSeconds"] == .65 and raw["rounds"] == 7
assert len(raw["jobs"]) == receipt["jobs"] == 1
(case,) = load(root / "representative.json")["cases"]
(job,) = raw["jobs"]
assert job["case"] == case["id"] == "scripts.fully-supplied-methods" and job["lane"] == "warm"
assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"]) == 28
for sample in job["samples"]:
    response = sample["response"]
    assert response["completedInvocations"] > 0 and response["status"] == "Completed"
    assert response["sourceSha256"] == case["sourceSha256"] and response["fixtureSha256"] == case["fixtureSha256"]
    assert response.get("actualOutputSha256") == case["expectedOutputSha256"]
    assert response.get("actualFilesSha256") == case.get("expectedFilesSha256")
summary = load(root / "quiet-summary.json")
del summary["retentionDecisionPending"]
summary.update(collection="B1296", sourceRevision=fresh["sourceRevision"], verifiedTimedBatches=28,
    coreSHA256=fresh["coreSHA256"], archiveSHA256=receipt["archiveSHA256"],
    retentionDecision=load(lab / "confirmation-decision.json")["decision"])
out.mkdir(exist_ok=True)
(out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
shutil.copyfile(root / "README.md", out / "README.md")
for name in ("archive-receipt.json", "terminal-status.json", "observations.tgz"):
    shutil.copyfile(root / name, out / name)
with tarfile.open(out / "procedures.tar.xz", "w:xz", preset=6) as packed:
    for path in sorted(root.iterdir()):
        if path.is_file() and path.suffix != ".tgz":
            packed.add(path, arcname=path.name)
    for name in ("prepare-confirmation.py", "launch-confirmation.py", "summarize-confirmation.py",
                 "archive-confirmation.py", "confirmation-decision.json"):
        packed.add(lab / name, arcname=name)
print("28 timed batches and both complete frozen images verified.")
