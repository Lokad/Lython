from pathlib import Path
import hashlib
import subprocess
from io import BytesIO
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
prior = lab / "quiet"
quiet = lab / "confirmation"
quiet.mkdir()

def load(path):
    return json.loads(path.read_text(encoding="utf-8"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def emit(path, source):
    if path.suffix == ".py":
        compile(source, str(path), "exec")
    path.write_text(source, encoding="utf-8", newline="\n")

def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")

old = load(prior / "config.json")
receipt = load(prior / "archive-receipt.json")
terminal = load(prior / "terminal-status.json")
assert terminal["receipt"] == receipt and terminal["exitCode"] == "0"
assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
assert sha(prior / "observations.tgz") == receipt["archiveSHA256"]
identity = load(prior / "identity.json")
for role, expected in identity["imageFiles"].items():
    folder = lab / "frozen" / role
    assert len(expected) == 32 and {name: sha(folder / name) for name in expected} == expected
    proof = load(lab / f"quiet-{role}-verify.json")
    assert proof["state"] == "Completed" and proof["caseCount"] == 3
    assert proof["catalogSha256"] == identity["catalogSHA256"] == sha(prior / "representative.json")

root = "/home/lokad/lython-bench-checks/direct-method-control-b1296-20261121"
unit = "lython-b1296-direct-method-control-20261121"
jobs = [("scripts.fully-supplied-methods", "warm")]
full = load(lab / "representative.json")
full["cases"] = [case for case in full["cases"] if case["id"] == jobs[0][0]]
assert len(full["cases"]) == 1
catalog = quiet / "representative.json"
save(catalog, full)
lab_identity = load(lab / "identity.json")
identity["catalogSHA256"] = sha(catalog)
identity["purpose"] = "Confirm the unchanged direct-method control after enabling native caller method resolution"
from os import environ, pathsep
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + pathsep + environ["PATH"])
protocol = lab.parents[3] / "benchmarks/cpython-worker.py"
assert sha(protocol) == old["protocolSHA256"]
for role in identity["imageFiles"]:
    image = lab / "frozen" / role
    results = quiet / f"{role}-verify.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
        "--catalog", catalog, "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
        "--python-worker", protocol, "--out", results], env=env, check=True, timeout=95)
    proof = load(results)
    assert proof["state"] == "Completed" and proof["caseCount"] == 1 and proof["catalogSha256"] == sha(catalog)
save(quiet / "identity.json", identity)
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    source = (prior / name).read_text(encoding="utf-8").replace(old["root"], root).replace(old["unit"], unit)
    if name == "collect.py":
        begin = source.index("\njobs = ")
        end = source.index("\nassert len(jobs)", begin)
        source = (source[:begin] + "\njobs = " + repr(jobs) + source[end:]).replace("len(jobs)==3", "len(jobs)==1")
    if name == "archive-owned.py":
        source = source.replace("len(raw['jobs'])==3", "len(raw['jobs'])==1").replace("jobs=3,", "jobs=1,")
    if name == "retrieve.py":
        source = source.replace("['jobs']==3", "['jobs']==1")
    emit(quiet / name, source)
assert b"\r" not in (quiet / "run.sh").read_bytes()
parts = ("identity.json", "collect.py", "archive-owned.py", "run.sh", "representative.json")
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as packed:
    for name in parts:
        packed.add(quiet / name, arcname=name)
member = "confirmation/confirmation.json"
known = "benchmarks/results/2026-11-21-annotations-in-creation/observations.tgz"
packed = subprocess.check_output(["git", "show", "origin/master:" + known], cwd=lab.parents[3])
with tarfile.open(fileobj=BytesIO(packed), mode="r:gz") as archive:
    entry = archive.getmember(member)
    assert entry.isfile()
    payload_copy = archive.extractfile(entry).read()
    assert len(payload_copy) == entry.size and json.loads(payload_copy)["complete"]
old_root = "annotations-in-creation-b1291-20261121"
retire = [dict(paths=[old_root + "/" + member], bytes=len(payload_copy), links=1, optional=False,
    sha256=hashlib.sha256(payload_copy).hexdigest(),
    archives={old_root + "/observations.tgz": hashlib.sha256(packed).hexdigest()})]
stage = dict(root=root, unit=unit, identity=identity, source=old["root"], sourceRole="reference",
             sourceFiles=identity["imageFiles"]["reference"], sourceCatalogSHA256=old["catalogSHA256"],
             donorArchiveSHA256=receipt["archiveSHA256"], protocolSource=old["root"] + "/cpython-worker.py",
             protocolSHA256=old["protocolSHA256"], payloadBytes=payload.stat().st_size,
             payloadSHA256=sha(payload), retireGroups=retire, catalogSHA256=identity["catalogSHA256"],
             unpackedBytes=sum((quiet / name).stat().st_size for name in parts))
save(quiet / "config.json", stage)
source = (prior / "remote-launch.py").read_text(encoding="utf-8")
begin, end = source.index("\nc=") + 1, source.index("\nb=Path(")
source = source[:begin] + "c=" + repr(stage) + source[end:]
source = source.replace("lython-b1295-fixtures", "lython-b1296-fixtures")
assert "c['unpackedBytes']+640*1024" in source
source = source.replace("c['unpackedBytes']+640*1024", "c['unpackedBytes']+384*1024")
source = source.replace("if not p.exists():os.link(source/c['sourceRole']/n,p)",
                        "if not p.exists():\n    assert sha(source/role/n)==h,n\n    os.link(source/role/n,p)")
emit(quiet / "remote-launch.py", source)
emit(lab / "launch-confirmation.py", (lab / "launch.py").read_text(encoding="utf-8")
     .replace("/'quiet'", "/'confirmation'").replace("225", "95"))
emit(lab / "summarize-confirmation.py", (lab / "summarize.py").read_text(encoding="utf-8")
     .replace("'quiet/", "'confirmation/").replace("len(raw['jobs'])==3", "len(raw['jobs'])==1"))
print("Prepared three lanes using the existing immutable images.")
