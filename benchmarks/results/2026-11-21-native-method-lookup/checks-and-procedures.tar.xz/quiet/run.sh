set -eu
root=/home/lokad/lython-bench-checks/native-method-lookup-b1295-20261121
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
