set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/direct-positional-methods-20261121
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/native-instance-method-lookup-20261121
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter 'Category!=Stress&(FullyQualifiedName~Function|FullyQualifiedName~NativeCall|FullyQualifiedName~NativeTupleReturn|FullyQualifiedName~BoundBoxCleanup)' --verbosity quiet > "$logs/white-ubuntu.log" 2>&1
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter 'Category!=Stress&(FullyQualifiedName~Method|FullyQualifiedName~Default|FullyQualifiedName~HelperLocalLifetime|FullyQualifiedName~GovernedMemoryContract)' --verbosity quiet > "$logs/public-ubuntu.log" 2>&1
grep 'Passed!' "$logs/white-ubuntu.log" "$logs/public-ubuntu.log"