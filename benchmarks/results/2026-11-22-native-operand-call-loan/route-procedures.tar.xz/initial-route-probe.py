from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
source=repo/".git/agent-worktrees/native-operand-call-loan-20261122"
probe=lab/"route-probe"
probe.mkdir(exist_ok=True)
env=dict(os.environ)
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env.update(DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
def run(args,cwd=repo,**kw):
    return subprocess.run(args,cwd=cwd,env=env,check=True,timeout=70,**kw)
def write(p,s):p.write_text(s,encoding="utf-8",newline="\n")
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

required="cdb213d36"
assert subprocess.check_output(["git","rev-parse","--short=9","HEAD"],cwd=source,text=True).strip()==required
assert not subprocess.check_output(["git","status","--porcelain","--untracked-files=no"],cwd=source)
p=source/"src/Lokad.Lython/Runtime/PyExecutableFunction.cs"
original=p.read_bytes()
s=p.read_text(encoding="utf-8")
tag="    internal void StartNativeCallFromOperands("
a=s.index(tag)
field="    internal static int DiagnosticOperandLoanEntries;\n\n"
attribute=s.rfind("    [System.Runtime.CompilerServices.MethodImpl",0,a)
s=s[:attribute]+field+s[attribute:]
a=s.index("        // The caller's last operands",s.index(tag))
s=s[:a]+"        Interlocked.Increment(ref DiagnosticOperandLoanEntries);\n"+s[a:]
try:
    write(p,s)
    delta=subprocess.check_output(["git","diff","--",str(p)],cwd=source)
    assert b"DiagnosticOperandLoanEntries" in delta
    (probe/"instrumentation.patch").write_bytes(delta)
    with (probe/"core-build.log").open("w",encoding="utf-8") as log:
        run([dotnet,"build","src/Lokad.Lython/Lokad.Lython.csproj","-c","Release","-f","net11.0","--no-incremental",
             "--artifacts-path",probe/"instrumented","--nologo"],cwd=source,stdout=log,stderr=subprocess.STDOUT)
finally:
    p.write_bytes(original)
assert not subprocess.check_output(["git","status","--porcelain","--untracked-files=no"],cwd=source)
base=lab/"rebased/frozen-candidate"
identity=json.loads((lab/"rebased/images.json").read_text(encoding="utf-8"))
frozen=identity["imageFiles"]["candidate"]
assert len(frozen)==32 and {n:sha(base/n) for n in frozen}==frozen
image=probe/"image"
image.mkdir()
for name in frozen:shutil.copyfile(base/name,image/name)
shutil.copyfile(probe/"instrumented/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll",image/"Lokad.Lython.dll")
image_hashes={n:sha(image/n) for n in frozen}
assert [n for n in frozen if image_hashes[n]!=frozen[n]]==["Lokad.Lython.dll"]
donor=lab.parent/"native-consumers-r450/allocation-short"
cs=(donor/"Program.cs").read_text(encoding="utf-8")
cs=cs.replace("var rows = new List<object>();","""var rows = new List<object>();
var entries = typeof(LythonEngine).Assembly.GetType("Lokad.Lython.Runtime.PyExecutableFunction", true)!
    .GetField("DiagnosticOperandLoanEntries", all)!;""")
a=cs.index("        var warm = Stopwatch.StartNew();")
b=cs.index("        script.Dispose();",a)
cs=cs[:a]+"""        entries.SetValue(null, 0);
        Run();
        rows.Add(new { id = item.GetProperty("id").GetString(),
            loanEntries = (int)entries.GetValue(null)!, allowanceReturned = true });
"""+cs[b:]
a=cs.index('    boundary = "')
cs=cs[:a]+'''    boundary = "Portable route evidence only from separately instrumented core. No timing." }, new JsonSerializerOptions { WriteIndented = true }), new UTF8Encoding(false));
'''
write(probe/"Program.cs",cs)
project=(donor/"Allocation.csproj").read_text(encoding="utf-8").replace("ValidatedAllocation","RouteProbe").replace("../frozen/reference/","image/")
write(probe/"RouteProbe.csproj",project)
with (probe/"probe-build.log").open("w",encoding="utf-8") as log:
    run([dotnet,"build",probe/"RouteProbe.csproj","-c","Release","--no-incremental","--nologo"],stdout=log,stderr=subprocess.STDOUT)
for path in (probe/"bin/Release/net11.0").glob("RouteProbe.*"):shutil.copyfile(path,image/path.name)
catalog=lab/"rebased/catalog.json"
report=probe/"routes.json"
run([dotnet,image/"RouteProbe.dll",image,catalog,report])
assert {n:sha(image/n) for n in frozen}==image_hashes
write(probe/"identity.json",json.dumps(dict(source=required,baseHashes=frozen,probeHashes=image_hashes,
    catalogSHA256=sha(catalog),instrumentationSHA256=sha(probe/"instrumentation.patch")),indent=2)+"\n")
print(report.read_text(encoding="utf-8"))
