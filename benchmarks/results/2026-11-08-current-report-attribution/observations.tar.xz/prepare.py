from pathlib import Path
import ast,hashlib,json,math,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'invocation-setup-r101';sourceRoot=r.parent/'conditional-helpers-r106/refinement';vm=sourceRoot/'b465'
i=json.loads((sourceRoot/'identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
d=json.loads((r.parent/'operand-cpython-r97/representative.json').read_text(encoding='utf8'))
d['cases']=[c for c in d['cases'] if c['id']=='scripts.json-report.large'];assert len(d['cases'])==1,[c['id'] for c in d['cases']]
(r/'catalog.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
receipt=json.loads((vm/'archive-receipt.json').read_text(encoding='utf8'))
assert hashlib.sha256((vm/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(vm/'observations.tgz') as a:assert hashlib.sha256(a.extractfile('current-core.dll').read()).hexdigest()==i['coreSHA256']['candidate']
proof=dict(vmArchive='refined-conditional-helpers-b465-20261108/observations.tgz',archiveSHA256=receipt['archiveSHA256'],member='current-core.dll',coreSHA256=i['coreSHA256']['candidate'],immutableLocalArtifact='benchmarks/results/2026-11-08-native-conditional-helpers-final/observations.tar.xz (nested B465 archive)')
(r/'core-source.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
identity=dict(sourceRevision='7265538c4f73abe0b133851797acf733d39b36e6',files={'Lokad.Lython.dll':i['coreSHA256']['candidate']},auxiliaryFiles=json.loads((vm/'identity.json').read_text(encoding='utf8'))['auxiliaryFiles'],productionSources=i['productionSources'],qualification='205public/42internal peractual11/10 plus B465 pass; exact full platform/Stress/installed qualification active independently.',purpose='One complete current JSON-to-Markdown warm CPU profile, diagnostic settings, no normal-settings speed claim.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
for name in ['ops-profile.py','analyze-cpu-guest.py','retrieve.py','run.sh','archive.py','launch.py']:
 s=(old/name).read_text(encoding='utf8').replace('config-setup-cost-b460','report-cost-b466').replace('lython-b460-config-setup-cost','lython-b466-report-cost').replace('lython-b460','lython-b466').replace('config-warm','report-warm')
 if name=='ops-profile.py':
  s=s.replace('scripts.config-edit.small','scripts.json-report.large').replace('count = 256','count = 64').replace('else 2048','else 512').replace('CreateBuiltinVariables CreateModuleVariables','EvaluateNativeReturn FormatNativeReturnValue ExecuteInstructionPrefix')
 if name=='launch.py':s=s.replace("source=(base/'default-rsplit-b459-20261108/candidate').resolve()","source=(base/'refined-conditional-helpers-b465-20261108/candidate').resolve()")
 if name=='archive.py':s=s.replace('verified immutable B459 archive','verified immutable B465 archive')
 (r/name).write_text(s,encoding='utf8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
shutil.copyfile(sourceRoot/'source.patch',r/'source.patch');shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
selection='''R108 one current complete JSON-to-Markdown report CPU attribution at7265538c/core1aa68ce9. The maintained report is1.46–1.49xCPython at15c; that ratio and old allocation ticks do not identify today's dominant phase. Same source/fixtures/full stdout/file goldens and existing R101 perf worker/protocol. Six guest-second warmup in512-invocation chunks,2second settle, six-second wall capture cpu-clock/FP199Hz,64 complete invocations/request. All actual I/O/prior-result cleanup remains; no normal-settings elapsed claim with PerfMap/JIT diagnostics. Profile native guard/frame/call dispatch, text/format/storage, collection construction and JSON/I/O groups, report overlapping inclusive groups and unknowns. One profile then~20min source selection, stop without a prototype if data unresolved or phase already absent. No cache/tagged value/second engine selected from assumptions. No full CPython replay, regex/publication unchanged, exact R106 CI independent.
Ready/core/aux/pre-post full goldens/quiet/Closed/exit/join/fixture/map/archive/local gates.120sowner+30stop+30margin; persistent raw/maps/catalog, owned128MiB RAM only fixtures/temporary CLR maps copied+verified after users finish. Fresh actual payload+8MiBtrace/archive headroom above240MiBOSfloor; archived B465core/immutable auxiliaries reused. No evidence deleted or sibling producer build. Preserve cancellation, managed protection, refusal and funding.
'''
for n in ['selection.md','contract.md']:(r/n).write_text(selection,encoding='utf8')
raw=sum((p.stat().st_size+4095)//4096*4096 for p in(old/'retrieved').rglob('*') if p.is_file()and p.name!='current-core.dll')
estimate=math.ceil((raw+(old/'observations.tgz').stat().st_size)*1.5);assert estimate<8*1024*1024,estimate
(r/'sizing.json').write_text(json.dumps(dict(priorRoundedRawBytes=raw,priorArchiveBytes=(old/'observations.tgz').stat().st_size,estimateBytes=estimate,reservedHeadroomBytes=8*1024*1024,osFloorBytes=240*1024*1024),indent=2)+'\n',encoding='utf8')
with tarfile.open(r/'payload.tgz','w:gz') as a:
 for n in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','catalog.json','identity.json','source.patch','contract.md','selection.md','sizing.json','core-source.json','pre-measurement-plan.md']:a.add(r/n,arcname=n)
print('One existing complete-report profile prepared; actual core/aux reused, no speed comparison or new runtime prototype.')
