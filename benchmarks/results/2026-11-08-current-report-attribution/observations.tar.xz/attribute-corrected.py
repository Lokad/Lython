from pathlib import Path
r=Path(__file__).parent
s=(r/'attribute.py').read_text(encoding='utf8')
s=s.replace("['CallBindingFrame','CallableInvocation','PrepareExecutableInvocation','ExecutableInvocationFrame']","['CallBindingFrame','CallableInvocation','PrepareExecutableInvocation','ExecutableInvocationFrame','BeginBoundCall','BeginPendingCall','AdvanceCallFrames','ExecuteOrdinaryCall','InvokeExecutableGeneralTargetAsync']")
s=s.replace("core=collections.Counter(n for s in samples for _,n in set(s) if '[Lokad.Lython]' in n)","core=collections.Counter(n for s in samples for n in {name for _,name in s if '[Lokad.Lython]' in name})")
# Original grouping/count program is retained. No new collection or changed samples.
exec(compile(s,str(r/'attribute.py'),'exec'))
