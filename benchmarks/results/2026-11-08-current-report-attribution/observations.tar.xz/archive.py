from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/report-cost-b466-20261108')
assert all(json.loads((root/n).read_text())['gate']['quiet']for n in ['machine-before.json','machine-after.json'])
assert not Path('/dev/shm/lython-b466').exists()
assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
assert __import__('shutil').disk_usage(root).free>240*1024*1024
record=json.loads((root/'profiles/report-warm/record.json').read_text());assert record['exitCode']==0 and record['closed']['status']=='Closed'
assert record['verificationBefore']['status']=='Equivalent'and record['verificationAfter']['status']=='Equivalent'
assert (root/'profiles/report-warm/worker.stderr').stat().st_size==0
seconds=record['response']['elapsedTicks']/record['response']['clockFrequency'];assert seconds<8
with tarfile.open(root/'observations.tgz','w:gz',dereference=True)as a:
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.name!='observations.tgz'and 'candidate'not in p.relative_to(root).parts:a.add(p,arcname=p.relative_to(root).as_posix())
 # Exact core already preserved in verified immutable B465 archive (core-source.json).
with tarfile.open(root/'observations.tgz')as a:assert json.loads(a.extractfile('profiles/report-warm/record.json').read())['exitCode']==0
result=dict(complete=True,allWorkersJoined=True,guestFixturesRemoved=True,quietBeforeAndAfter=True,archivedAndVerifiedUnderLease=True,capturedSeconds=seconds,archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest(),performanceQualified=False)
(root/'archive-receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
