from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;i=json.loads((r/'identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf8'));assert receipt['complete']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
decision='''R108 gate closed without speculative runtime prototype. Current report1110guest samples/5.58CPU seconds,64unknown5.77%,56kernel5.05%. Formatting270inclusive/149leaf(24.32/13.42%), JSON parsing288/150(25.95/13.51%), dictionary299/147(26.94/13.24%); groups overlap. Prefix115leaf(10.36%) includes useful inlined work. Call/binding936inclusive/44leaf is not84%removable overhead; contexts8leaf(.72%). Current JSON record-prefix direct filling, completed parser loops, UTF8 string windows and direct final-buffer formatting already remove proposed copying/repackaging phases. R26/c4729a9f intentionally removed a separate native formatted evaluator after admission changed later globals and caused raw CLR casts. Preserve that correctness correction; do not revive an upfront mutable proof/cache or duplicate builder engine. R71 arena/control regressions remain relevant. Bulk token scan/integer formatter/local shortcuts are possible smaller work, not evidence for a substantial redesign; no automatic promotion or speed forecast.
Corrected offline classifier adds actual call-frame names and deduplicates names rather than instruction addresses within one stack. Original classifier retained; no profile recollection. Initial prepare guessed a catalog ID and failed before collection, corrected script/source retained. All Ready/core/aux/goldens/quiet/Closed/exit/join/map/fixture/archive/local gates pass, no remaining users/RAM. No normal-settings elapsed, startup, heap or latency claim. Full R106 delivery independent. Next combined CPython checkpoint at retained726; use it to state remaining product gaps, not another per-edit timing campaign.
'''
(r/'decision.md').write_text(decision,encoding='utf8')
out=Path('benchmarks/results/2026-11-08-current-report-attribution');out.mkdir()
with tarfile.open(out/'observations.tar.xz','w:xz') as a:
 for p in sorted(r.iterdir()):
  if p.name not in ['retrieved','payload.tgz']:a.add(p,arcname=p.name)
with tarfile.open(out/'observations.tar.xz') as a:assert hashlib.sha256(a.extractfile('observations.tgz').read()).hexdigest()==receipt['archiveSHA256']
for n in ['identity.json','archive-receipt.json','attribution.json']:shutil.copyfile(r/n,out/n)
(out/'README.md').write_text('''# Current complete-report CPU attribution

2026-11-08, committed `7265538c`, frozen core `1aa68ce9`. Same maintained
JSON-to-Markdown script, 3,072 records / 189,441 B, exact full output checks,
worker and optional0.4 adapter. Azure F4as_v7 / Ubuntu24.04.4 / .NET11 RC3.
Six-second warmup, two-second settle, six-second wall CPU-clock/FP199Hz capture.
5.786 guest-clock seconds, 5.58 guest CPU seconds, **1,110 samples, 64 unknown
leaves (5.77%)**. PerfMap/JIT diagnostics are enabled: attribution, no normal
elapsed or causal speed claim. Worker validation/protocol/reset are excluded from
guest samples; mediated I/O and prior-result cleanup remain in guest execution.

| Group | Leaf samples | Samples with any matching frame |
| --- | ---: | ---: |
| Formatting | 149 (13.42%) | 270 (24.32%) |
| JSON parsing | 150 (13.51%) | 288 (25.95%) |
| Dictionary work | 147 (13.24%) | 299 (26.94%) |
| Instruction prefix | 115 (10.36%) | 979 (88.20%) |
| String storage | 28 (2.52%) | 104 (9.37%) |
| Memory admission/storage | 43 (3.87%) | 117 (10.54%) |
| Call/frame/binding routing | 44 (3.96%) | 936 (84.32%) |
| Context constructors | 8 (0.72%) | 9 (0.81%) |

Inclusive groups overlap; **do not add them or call them removable overhead**.
Inlining and frame-pointer unwind loss limit attribution. Prefix leaves include
useful inlined work. Kernel leaves account for 56 samples (5.05%). No evidence
here establishes context/argument packaging as the dominant remaining phase.

The bounded source gate selects no speculative prototype. Ordered JSON records
already fill values directly; default parsing already handles completed work in
ordinary loops. UTF-8 token windows and final-buffer formatting are established.
Do not revive the old separate native formatted evaluator: the
[R26 correctness correction](../2026-11-07-canonical-formatting/README.md) removed
upfront mutable proofs that could become stale during admission and throw CLR
casts. Preserve slower arena/control lessons as well. This profile identifies
remaining useful work; it does not justify replacing it with another engine.

Original classifier omitted actual call-frame names and counted repeated method
addresses in inclusive ranking. Corrected offline classification deduplicates
method names per stack; all raw samples and the original classifier remain.
The initial guessed catalog ID failed before collection; only the ID was corrected
to the existing unchanged report. No second capture or favorable retiming.

All core/aux/Ready/pre-post full goldens/quiet/Closed/exit/join/maps/fixture/archive
gates pass. Persistent raw/maps archived under lease and independently verified
locally. All users joined; owned RAM unmounted. R106 full delivery is independent.
No startup/RSS/embedding-tail/pending-I/O or new CPython ratio claim.

[Attribution and exact names](attribution.json), [identity](identity.json),
[receipt](archive-receipt.json), [raw traces, maps, sources and failures](observations.tar.xz).
''',encoding='utf8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf8')+'''
## Current report attribution / bounded source gate (2026-11-08)

[R108/B466](results/2026-11-08-current-report-attribution/README.md) at7265538c:
1110guest samples/5.58CPU seconds,64unknown leaves. Formatting/JSON/dictionary work
material; call/frame inclusive84% contains useful callee work, leaf3.96%, context
constructors0.72%. No packaging-dominance claim or speculative runtime prototype.
Current direct record filling/token windows/completed parser/final-buffer formatting
already exist. Preserve R26's admission-reentry correctness deletion of the native
formatted evaluator; do not reintroduce upfront mutable proofs. Offline classifier
corrected actual call names/per-method deduplication; original/raw retained, no retime.
All gates/archive/local verification pass, no users/RAM. Full delivery independent;
next combined retained-source external checkpoint, no new framework/publication.
''';p.write_text(s,encoding='utf8')
p=Path('PLAN.md');s=p.read_text(encoding='utf8');a=s.index('2. **R108');z=s.index('3. **Substantial',a)
s=s[:a]+'''2. **R108 source/profile gate closed; R109 combined retained checkpoint next.**
   Current report1110guest samples/5.58CPU seconds/64unknown5.77%; formatting/JSON/
   dictionaries material, context0.72%leaf, call/frame3.96%leaf despite84%inclusive.
   Groups overlap; no packaging-dominance claim. Direct record prefix filling,
   completed parser loops, UTF8 windows and final-buffer formatting already exist.
   R26/c4729's native formatted-evaluator deletion fixes admission reentry changing
   later globals: preserve it, no upfront proof/cache/second engine revival.
   No speculative prototype selected; classifier corrected offline with originals
   retained, all gates/archive/local verification pass, no users/RAM. B466 cached.
   Refresh the maintained28-job CPython checkpoint at committed726/core1aa, grouping
   retained JSON-construction and guarded-return milestones. Same workers/catalog/
   protocol/settings; compilation/warm/compile-to-result boundaries unchanged.
   Preserve15c guide and adverse cases.620sowner+30stop+30margin. Fresh disk preflight
   with exact-byte maintenance only if needed; no deletion or new measurement suite.
   Qualification runs independently, not another completed-source CI replay.

'''+s[z:];p.write_text(s,encoding='utf8')
print('R108 archived; no speculative runtime prototype selected; prior correctness/sampling lessons recorded.')
