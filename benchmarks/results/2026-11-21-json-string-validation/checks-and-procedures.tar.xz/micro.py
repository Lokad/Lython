from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
identity = json.loads((lab / "identity.json").read_text(encoding="utf-8"))
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
python = Path(shutil.which("python.exe")).resolve()
manifest = lab / "catalog.json"
protocol = repo / "benchmarks/cpython-worker.py"

def verify():
    for role, expected in identity["imageFiles"].items():
        folder = lab / "workers" / role
        hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir() if p.is_file()}
        assert expected == hashes

verify()
rows = []
cases = (
    ("json-lines", "scripts.json-lines-shipment.expanded-options.large"),
    ("normalize", "scripts.json-normalized-records.large"),
    ("report", "scripts.report-render.large"),
    ("escaped-report", "diagnostic.report-render.escaped-unicode.large"),
    ("unicode-text-control", "scripts.text-summary-helpers.map-callback.large.mixed-unicode"),
)
lane = "warm"
for alias, case in cases:
    comparisons = ["candidate", "reference"] if len(rows) % 4 == 0 else ["reference", "candidate"]
    for role in comparisons:
        receipt = lab / f"{alias}-{role}-micro.json"
        worker = lab / "workers" / role / "Lokad.Lython.Benchmarks.dll"
        baseline = lab / "workers/reference/Lokad.Lython.Benchmarks.dll"
        result = subprocess.run(
            [dotnet, worker, "--compare", "micro", "--case", case, "--lane", lane,
             "--catalog", manifest, "--dotnet", dotnet, "--baseline-worker", baseline,
             "--python", python, "--python-worker", protocol, "--out", receipt],
            env=env, capture_output=True, encoding="utf-8", errors="replace",
        )
        (lab / f"{alias}-{role}-micro.log").write_text(result.stdout + result.stderr, encoding="utf-8")
        if result.returncode == 0:
            data = json.loads(receipt.read_text(encoding="utf-8"))
            summaries = {sample["engine"]: sample for sample in data["summaries"]}
            change = 100 * (summaries["candidate"]["medianMicroseconds"] / summaries["baseline"]["medianMicroseconds"] - 1)
            rows.append(dict(case=case, lane=lane, role=role, elapsedChangePercent=change, workers=summaries))
            print(f"{alias} vs {role} {change:+.2f}%", flush=True)
        else:
            rows.append(dict(case=case, lane=lane, role=role, exitCode=result.returncode))
            print(f"{alias} vs {role} exited {result.returncode}", flush=True)
        (lab / "micro-summary.json").write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8", newline="\n")
verify()
