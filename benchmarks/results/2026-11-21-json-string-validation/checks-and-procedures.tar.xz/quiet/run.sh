set -eu
root=/home/lokad/lython-bench-checks/json-string-validation-b1287-20261121
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
