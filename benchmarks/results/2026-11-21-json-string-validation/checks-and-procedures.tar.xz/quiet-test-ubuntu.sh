set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/pinned-unicode-casing-20261121
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/json-string-single-validation
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter 'Category!=Stress&FullyQualifiedName~Json' > "$logs/quiet-rebased-white-ubuntu.log" 2>&1
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter 'Category!=Stress&FullyQualifiedName~Json' > "$logs/quiet-rebased-public-ubuntu.log" 2>&1
if command -v rg >/dev/null; then
    rg 'Passed!' "$logs/quiet-rebased-white-ubuntu.log" "$logs/quiet-rebased-public-ubuntu.log"
else
    grep 'Passed!' "$logs/quiet-rebased-white-ubuntu.log" "$logs/quiet-rebased-public-ubuntu.log"
fi
