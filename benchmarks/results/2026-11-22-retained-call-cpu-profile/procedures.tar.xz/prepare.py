from pathlib import Path
import hashlib,json,gzip,os,shutil,subprocess,tarfile

lab=Path(os.environ["LYTHON_ATTR_LAB"])
repo=lab.parents[3]
donor=lab.parent/"native-fixed-return-refined-20261122"
external=lab.parent/"retained-call-transport-cpython-20261122"
template=lab.parent/"post-checked-local-call-profile-20261122"
def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,data):
    if path.suffix==".py":
        compile(data,str(path),"exec")
    path.write_text(data,encoding="utf-8",newline="\n")
def save(path,obj):
    write(path,json.dumps(obj,indent=2)+"\n")
config=read(donor/"quiet/config.json")
receipt=read(donor/"quiet/archive-receipt.json")
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
candidate="880c6d95883151114ca4fcbaf8558e59e425a2e9"
assert not subprocess.check_output(["git","diff",candidate,head,"--","src","tests","benchmarks/Lokad.Lython.Benchmarks"],cwd=repo)
assert receipt==read(donor/"quiet/terminal-status.json")["receipt"] and receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
assert sha(donor/"quiet/observations.tgz")==receipt["archiveSHA256"]
files=config["identity"]["imageFiles"]
for role in ("reference","candidate"):
    assert len(files[role])==32 and {key:sha(donor/"frozen"/role/key) for key in files[role]}==files[role]
    proof=read(donor/f"{role}-verify.json")
    assert proof["state"]=="Completed" and proof["caseCount"]==8 and proof["catalogSha256"]==config["catalogSHA256"]
    shutil.copyfile(donor/f"{role}-verify.json",lab/f"{role}-verify.json")
catalog=donor/"representative.json"
assert sha(catalog)==config["catalogSHA256"]
shutil.copyfile(catalog,lab/"catalog.json")
stock_core=repo/"benchmarks/results/2026-11-22-native-fixed-returns-refined/candidate-core.dll.gz"
assert gzip.decompress(stock_core.read_bytes())==(donor/"frozen/candidate/Lokad.Lython.dll").read_bytes()
identity=dict(sourceRevision=candidate,imageSource=read(donor/"identity.json")["candidate"],
    referenceSource=read(donor/"identity.json")["reference"],deliveryReference=read(donor/"identity.json")["deliveryReference"],
    purpose="Attribute mixed first use on both fixed-return images and the retained function helper",
    coreSHA256={role:files[role]["Lokad.Lython.dll"] for role in files},imageFiles=files,
    catalogSHA256=sha(catalog),diagnosticOnly=True)
save(lab/"identity.json",identity)
old=read(template/"config.json")
root="/home/lokad/lython-bench-checks/retained-call-profile-b1370-20261122"
unit="lython-b1370-retained-call-profile-20261122"
mixed="scripts.annotated-rule-closures.literal-positional-dynamic-keyword"
helper="diagnostic.helper-placement.function-call"
jobs=[("reference-mixed",mixed,"compile-run"),("candidate-function-helper",helper,"warm"),
      ("candidate-mixed",mixed,"compile-run")]
for n in ("ops-profile.py","collect.py","run.sh","retrieve.py","launch.py"):
    s=(template/n).read_text(encoding="utf-8").replace(old["root"],root).replace(old["unit"],unit).replace("B1366","B1370")
    if n=="ops-profile.py":
        start,end=s.index("    for name, case_id, lane in "),s.index("\n        role = ")
        s=s[:start]+f"    for name, case_id, lane in {jobs!r}:"+s[end:]
    elif n=="collect.py":
        s=s.replace("['candidate-function-helper', 'candidate-protected-invoice']",repr([name for name,_,_ in jobs]))
        s=s.replace("len(records)==2","len(records)==3").replace("Fully supplied helper and protected invoice CPU attribution",identity["purpose"])
    write(lab/n,s)
assert b"\r" not in (lab/"run.sh").read_bytes()
parts=("identity.json","collect.py","ops-profile.py","run.sh")
payload=lab/"payload.tgz"
with tarfile.open(payload,"w:gz")as archive:
    for n in parts:archive.add(lab/n,arcname=n)
stage=dict(root=root,unit=unit,identity=identity,source=config["root"],
    sourceFiles=files,sourceCatalogSHA256=config["catalogSHA256"],catalogSHA256=identity["catalogSHA256"],
    donorArchive=receipt["archiveSHA256"],retireGroups=[],payloadBytes=payload.stat().st_size,
    payloadSHA256=sha(payload),unpackedBytes=sum((lab/name).stat().st_size for name in parts))
save(lab/"config.json",stage)
s=(template/"remote-launch.py").read_text(encoding="utf-8").replace("lython-b1366-fixtures","lython-b1370-fixtures")
begin,end=s.index("\nc=")+1,s.index("\nb=Path(")
s=s[:begin]+"c="+repr(stage)+s[end:]
s=s.replace("for role in ['candidate']:","for role in ['candidate','reference']:").replace("os.link(source/'candidate'/n,p)","os.link(source/role/n,p)")
s=s.replace(" assert sha(root/'catalog.json')==c['catalogSHA256']"," os.link(source/'representative.json',root/'catalog.json')\n assert sha(root/'catalog.json')==c['catalogSHA256']")
write(lab/"remote-launch.py",s)
shutil.copyfile(external/"mixed-control-path.json",lab/"mixed-control-path.json")
print("Staged three bounded CPU profiles with verified frozen images and original catalog.")
