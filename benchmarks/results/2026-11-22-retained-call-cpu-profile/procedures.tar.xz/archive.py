from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, tarfile
lab=Path(".git/agent-notes/review-20261031/retained-call-cpu-profile-20261122").resolve()
out=Path("benchmarks/results/2026-11-22-retained-call-cpu-profile")
donor=lab.parent/"native-fixed-return-refined-20261122"/"frozen"
def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
identity=read(lab/"identity.json")
assert identity["sourceRevision"] == subprocess.check_output(["git","rev-parse","880c6d958"],text=True).strip()
for role,files in identity["imageFiles"].items():
    assert len(files)==32 and {name:sha(donor/role/name) for name in files}==files
    proof=read(lab/f"{role}-verify.json")
    assert proof["state"]=="Completed" and proof["caseCount"]==8 and proof["catalogSha256"]==sha(lab/"catalog.json")==identity["catalogSHA256"]
assert gzip.decompress(Path("benchmarks/results/2026-11-22-native-fixed-returns-refined/candidate-core.dll.gz").read_bytes())==(donor/"candidate/Lokad.Lython.dll").read_bytes()
receipt=read(lab/"archive-receipt.json")
status=read(lab/"terminal-status.json")
assert status["receipt"]==receipt and status["exitCode"]=="0" and not status["remainingWorkers"] and not status["remainingTrace"]
assert all(receipt[k] for k in ("complete","quietBeforeAndAfter","allWorkersJoined","archivedAndVerifiedUnderLease","guestFixturesRemoved","persistentTraceArchivedAndVerifiedBeforeUnmount"))
assert receipt["archiveSHA256"]==sha(lab/"observations.tgz")
catalog={c["id"]:c for c in read(lab/"catalog.json")["cases"]}
rows=read(lab/"attribution.json")["rows"]
assert len(rows)==3 and all(row["sampleCount"]>=700 for row in rows)
assert [r["lane"] for r in rows]==["compile-run","warm","compile-run"]
for row in rows:
    record=read(lab/"retrieved"/"profiles"/row["label"]/"record.json")
    assert record["workload"]==row["case"] and record["lane"]==row["lane"]
    assert record["exitCode"]==0 and record["closed"]["status"]=="Closed"
    role=row["label"].split("-",1)[0]
    worker=record["identity"]
    assert worker["catalogSha256"]==identity["catalogSHA256"]
    core=next(v for v in worker["libraries"] if Path(v["path"]).name=="Lokad.Lython.dll")
    assert core["sha256"].lower()==identity["coreSHA256"][role]
    case=catalog[row["case"]]
    for point in ("verificationBefore","verificationAfter"):
        assert record[point]["status"]=="Equivalent" and record[point]["actualOutputSha256"]==case["expectedOutputSha256"]
    assert record["response"]["completedInvocations"]>0 and record["warmupSeconds"]>=8
    for batch in record["batches"]:
        assert batch["status"]=="Completed"
        assert batch.get("actualOutputSha256")== (None if row["lane"]=="compile" else case["expectedOutputSha256"])
out.mkdir(exist_ok=False)
for name in ("README.md","attribution.json","archive-receipt.json","terminal-status.json","observations.tgz"):
    shutil.copyfile(lab/name,out/name)
with tarfile.open(out/"procedures.tar.xz","w:xz") as archive:
    for path in sorted(lab.iterdir()):
        if path.is_file() and path.suffix!=".tgz":
            archive.add(path,arcname=path.name)
print("All three profiles and complete frozen image custody verified.")
