from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json,tarfile

lab=Path(__file__).resolve().parent
pair=lab/'comparison'
quiet=pair/'quiet'
out=lab.parents[3]/'benchmarks/results/2026-11-28-first-line-host-boundary'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
assert identity['sourcePatchSHA256']==digest(lab/'observer.patch')
assert identity['observerSource']==read(lab/'source.json')
assert identity['observerSource']['sourceArchiveSha256']==digest(lab/'sources.tar')
for role,files in identity['imageFiles'].items():
    assert {p.name:digest(p) for p in (pair/role).iterdir()}==files
    assert read(pair/f'{role}-verify.json')['caseCount']==1
assert {name for name,value in identity['imageFiles']['reference'].items()
        if identity['imageFiles']['candidate'][name]!=value}=={'Lokad.Lython.Benchmarks.dll'}
earlier=pair/'quiet-first'
assert digest(earlier/'observations.tar.xz')==read(earlier/'terminal-status.json')['receipt']['archiveSHA256']
assert not read(earlier/'terminal-status.json')['receipt']['complete']
assert "KeyError: 'purpose'" in read(earlier/'terminal-status.json')['journal']
assert digest(quiet/'observations.tar.xz')==read(quiet/'terminal-status.json')['receipt']['archiveSHA256']
assert read(quiet/'summary.json')['verifiedTimedBatches']==56
assert [row['lane'] for row in read(quiet/'phases.json')['rows']]==['warm','warm-async']

out.mkdir(exist_ok=True)
for name in ('identity.json','observations.tar.xz','terminal-status.json','summary.json','phases.json'):
    copy2(quiet/name,out/name)
    assert digest(quiet/name)==digest(out/name)
procedures={p.name:p for p in lab.iterdir() if p.is_file() and p.suffix in ('.py','.patch','.sh','.log','.json')}
for folder,label,names in [
    (pair,'local',('reference-verify.json','candidate-verify.json')),
    (quiet,'quiet',('launch.log','reference-remote-verify.json','candidate-remote-verify.json','stage-custody.json','upload.json')),
    (earlier,'initial',('launch.log','observations.tar.xz','terminal-status.json','upload.json','stage-custody.json')),
]:
    procedures.update({f'{label}/{name}':folder/name for name in names})
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for name,path in procedures.items(): bundle.add(path,arcname=name)
with tarfile.open(out/'procedures.tar.xz') as bundle:
    for name,path in procedures.items(): assert sha256(bundle.extractfile(name).read()).hexdigest()==digest(path)
print('Verified both image manifests, first failed archive, two quiet lanes and phase counts.')
