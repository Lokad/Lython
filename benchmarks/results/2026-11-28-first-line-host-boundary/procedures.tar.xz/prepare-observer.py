from pathlib import Path
from subprocess import run
import difflib, hashlib, json, sys, tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
snapshot=lab/'repo'
archive=lab/'sources.tar'
revision=run(['git','rev-parse','HEAD'],cwd=repo,check=True,capture_output=True,text=True).stdout.strip()
assert revision.startswith('a1a9ee4a4')
paths=['src','benchmarks/Lokad.Lython.Benchmarks','benchmarks/scripts','Directory.Build.props',
       'Directory.Build.targets','Directory.Packages.props','global.json','NuGet.Config']
run(['git','archive','--format=tar','-o',str(archive),revision,*paths],cwd=repo,check=True)
snapshot.mkdir()
with tarfile.open(archive) as bundle:
    bundle.extractall(snapshot,filter='data')
folder=snapshot/'benchmarks/Lokad.Lython.Benchmarks/Comparison'
patch=[]
def change(name,fn):
    location=folder/name
    before=location.read_text(encoding='utf-8') if location.exists() else ''
    after=fn(before)
    assert before!=after
    location.write_text(after,encoding='utf-8',newline='\n')
    path=location.relative_to(snapshot).as_posix()
    patch.extend(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),
                                     fromfile=f'a/{path}' if before else '/dev/null',tofile=f'b/{path}'))
def replace_once(source,old,new):
    assert source.count(old)==1,old
    return source.replace(old,new)
def host(source):
    source=replace_once(source,'    public ComparisonFileFixture Fixture { get; }','    public ComparisonFileFixture Fixture { get; }\n    internal FileBoundaryTiming Timing { get; } = new();')
    source=replace_once(source,'        var actual = new Dictionary<string, byte[]>(StringComparer.Ordinal);',
        '        using var phase = Timing.Begin(FileBoundaryPhase.Verify);\n        var actual = new Dictionary<string, byte[]>(StringComparer.Ordinal);')
    start=source.index('    public ValueTask<ILythonByteFile> OpenFileAsync')
    end=source.index('    public ValueTask<bool> ExistsAsync',start)
    block=source[start:end]
    block=replace_once(block,'        var owner = budget.CreateScope();',
        '        using var phase = Timing.Begin(options.Access == LythonFileAccess.Read\n            ? FileBoundaryPhase.OpenRead : FileBoundaryPhase.OpenWrite);\n        var owner = budget.CreateScope();')
    block=replace_once(block,'            stream = new FileStream(Resolve(request, token).Entry.FullName, mode, access, FileShare.ReadWrite | FileShare.Delete,',
        '            string fullName;\n            using (Timing.Begin(FileBoundaryPhase.Resolve)) fullName = Resolve(request, token).Entry.FullName;\n            stream = new FileStream(fullName, mode, access, FileShare.ReadWrite | FileShare.Delete,')
    block=replace_once(block,'new PositionalByteFile(stream, owner) : new ByteFile(stream, owner, options.Append)',
        'new PositionalByteFile(stream, owner, Timing) : new ByteFile(stream, owner, options.Append, Timing)')
    block=replace_once(block,'private class ByteFile(FileStream stream, ILythonMemoryScope owner, bool append)',
        'private class ByteFile(FileStream stream, ILythonMemoryScope owner, bool append, FileBoundaryTiming timing)')
    block=replace_once(block,'            return ValueTask.FromResult(stream.Read(buffer.Span));','            using var phase = timing.Begin(FileBoundaryPhase.Read);\n            return ValueTask.FromResult(stream.Read(buffer.Span));')
    block=replace_once(block,'            try\n            {\n                // This trusted benchmark host',
        '            using var phase = timing.Begin(FileBoundaryPhase.Write);\n            try\n            {\n                // This trusted benchmark host')
    block=replace_once(block,'            token.ThrowIfCancellationRequested(); stream.Flush(); return ValueTask.CompletedTask;',
        '            token.ThrowIfCancellationRequested();\n            using var phase = timing.Begin(FileBoundaryPhase.Flush);\n            stream.Flush(); return ValueTask.CompletedTask;')
    block=replace_once(block,'            _closed = true;\n            try { stream.Dispose(); }',
        '            _closed = true;\n            using var phase = timing.Begin(FileBoundaryPhase.Close);\n            try { stream.Dispose(); }')
    block=replace_once(block,'internal PositionalByteFile(FileStream stream, ILythonMemoryScope owner) : base(stream, owner, false)',
        'internal PositionalByteFile(FileStream stream, ILythonMemoryScope owner, FileBoundaryTiming timing) : base(stream, owner, false, timing)')
    return source[:start]+block+source[end:]
def worker(source):
    source=replace_once(source,'        var started = Stopwatch.GetTimestamp();\n        var resetBefore',
        '        var phaseStart = files?.Timing.Snapshot();\n        var started = Stopwatch.GetTimestamp();\n        var resetBefore')
    source=replace_once(source,'            return Response(workload, requestId, "Completed", completed, elapsedTicks, actual);',
        '            return Response(workload, requestId, "Completed", completed, elapsedTicks, actual)\n                with { FilePhases = files?.Timing.Since(phaseStart!) };')
    source=replace_once(source,'        var result = asynchronous ? script.RunAsync(host).GetAwaiter().GetResult() : script.Run(host);',
        '        LythonExecutionResult result;\n        using (files?.Timing.Begin(FileBoundaryPhase.Run) ?? default)\n            result = asynchronous ? script.RunAsync(host).GetAwaiter().GetResult() : script.Run(host);')
    source=replace_once(source,'    string? ActualFilesSha256 = null);',
        '''    string? ActualFilesSha256 = null)
{
    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public IReadOnlyDictionary<string, FileBoundarySample>? FilePhases { get; init; }
}''')
    return source
change('ComparisonFileHost.cs',host)
change('LythonComparisonWorker.cs',worker)
change('FileBoundaryTiming.cs',lambda _ : '''using System.Diagnostics;

namespace Lokad.Lython.Benchmarks.Comparison;

internal enum FileBoundaryPhase
{
    OpenRead, OpenWrite, Resolve, Read, Write, Flush, Close, Verify, Run
}

internal readonly record struct FileBoundarySample(long Calls, long Ticks);

internal sealed class FileBoundaryTiming
{
    private static readonly FileBoundaryPhase[] Phases = Enum.GetValues<FileBoundaryPhase>();
    private readonly FileBoundarySample[] _totals = new FileBoundarySample[Phases.Length];

    internal Operation Begin(FileBoundaryPhase phase) => new(this, (int)phase, Stopwatch.GetTimestamp());
    internal FileBoundarySample[] Snapshot() => (FileBoundarySample[])_totals.Clone();

    internal IReadOnlyDictionary<string, FileBoundarySample> Since(FileBoundarySample[] previous)
    {
        var result = new Dictionary<string, FileBoundarySample>(Phases.Length);
        foreach (var phase in Phases)
        {
            var id = (int)phase;
            var (calls, ticks) = _totals[id];
            result.Add(phase.ToString(), new(calls - previous[id].Calls, ticks - previous[id].Ticks));
        }
        return result;
    }

    internal readonly struct Operation(FileBoundaryTiming? owner, int phase, long start) : IDisposable
    {
        public void Dispose()
        {
            if (owner is null) return;
            var elapsed = Stopwatch.GetTimestamp() - start;
            var (calls, ticks) = owner._totals[phase];
            owner._totals[phase] = new(calls + 1, ticks + elapsed);
        }
    }
}
''')
(lab/'observer.patch').write_text(''.join(patch),encoding='utf-8',newline='\n')
(lab/'source.json').write_text(json.dumps(dict(revision=revision,sourceArchiveSha256=hashlib.sha256(archive.read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8',newline='\n')
