from hashlib import sha256
from pathlib import Path
from statistics import median
import json, tarfile

lab=Path(__file__).resolve().parent
quiet=lab/'comparison/quiet'
read=lambda p:json.loads(p.read_bytes())
identity=read(quiet/'identity.json')
summary=read(quiet/'summary.json')
assert summary['verifiedTimedBatches']==56 and summary['quietGates']
receipt=read(quiet/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['archiveSHA256']==sha256((quiet/'observations.tar.xz').read_bytes()).hexdigest()
with tarfile.open(quiet/'observations.tar.xz') as bundle:
    raw=json.load(bundle.extractfile('confirmation/confirmation.json'))
expected_calls=dict(OpenRead=1,OpenWrite=1,Resolve=2,Read=1,Write=1,Flush=1,Close=2,Verify=1,Run=1)
host_parts=('OpenRead','OpenWrite','Read','Write','Flush','Close')
rows=[]
for job, comparison in zip(raw['jobs'],summary['rows'],strict=True):
    lane,=job['lanes']
    assert comparison['lane']==lane
    workers={}
    for sample in job['samples']:
        label=sample['engine']
        response=sample['response']
        assert 'filePhases' not in response if label.startswith('reference') else 'filePhases' in response
        if label.startswith('reference'): continue
        count=response['completedInvocations']
        phases=response['filePhases']
        assert phases.keys()==expected_calls.keys()
        assert all(phases[phase]['calls']==count*expected for phase,expected in expected_calls.items()), (lane,label,count,phases)
        outer=response['elapsedTicks']
        run=phases['Run']['ticks']
        verify=phases['Verify']['ticks']
        host=sum(phases[key]['ticks'] for key in host_parts)
        assert phases['Resolve']['ticks'] <= phases['OpenRead']['ticks']+phases['OpenWrite']['ticks']
        assert host <= run and run+verify <= outer
        units=1_000_000/response['clockFrequency']/count
        row={phase:observation['ticks']*units for phase,observation in phases.items()}
        row.update(Host=host*units,RunOutsideHostPhases=(run-host)*units,Verify=verify*units,
            OuterOutsideRunAndVerify=(outer-run-verify)*units,EndToEnd=outer*units)
        workers.setdefault(label,[]).append(row)
    assert len(workers)==2 and all(len(samples)==7 for samples in workers.values())
    medians={label:{phase:median(row[phase] for row in samples) for phase in samples[0]} for label,samples in workers.items()}
    ranges={phase:[min(result[phase] for result in medians.values()),max(result[phase] for result in medians.values())]
            for phase in next(iter(medians.values()))}
    row=dict(lane=lane,phaseCallsPerInvocation=expected_calls,workerMediansUs=medians,observerUs=ranges,
             elapsedObserverChangePercent=comparison['elapsedChangePercent'],cpuObserverChangePercent=comparison['cpuChangePercent'])
    rows.append(row)
    print(lane, {key: [round(n,2) for n in value] for key,value in ranges.items()})
(quiet/'phases.json').write_text(json.dumps(dict(source=identity['sourceRevision'],rows=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
