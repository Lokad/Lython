#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-notes/review-20261031/first-line-host-boundary-b1983-20261128
export DOTNET_ROOT="$HOME/.dotnet"
unset DOTNET_BUNDLE_EXTRACT_BASE_DIR
cd repo
"$DOTNET_ROOT/dotnet" build benchmarks/Lokad.Lython.Benchmarks -c Release -f net11.0 --artifacts-path ../observer-build --no-incremental --disable-build-servers > ../observer-build.log 2>&1