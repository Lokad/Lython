from pathlib import Path
from shutil import copy2,copytree
import hashlib,json,sys

lab=Path(__file__).resolve().parent
prior=lab.parent/'first-line-attribution-b1982-20261128'
sample=prior/'comparison/quiet'
known=json.loads((prior/'attribution/profile/identity.json').read_bytes())
pair=lab/'comparison'
pair.mkdir()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=lambda p:{entry.name:digest(entry) for entry in p.iterdir()}
assert known['imageFiles']['candidate']==files(sample/'local-image')
for role in ('candidate','reference'):
    copytree(sample/'local-image',pair/role)
assembly='Lokad.Lython.Benchmarks.dll'
built=lab/'observer-build/bin/Lokad.Lython.Benchmarks/release_net11.0'/assembly
copy2(built,pair/'candidate'/assembly)
images={role:files(pair/role) for role in ('candidate','reference')}
assert len(images['reference'])==32 and {name for name in images['reference'] if images['reference'][name]!=images['candidate'][name]}=={assembly}
assert digest(pair/'candidate'/assembly)==digest(built) and not (pair/'candidate'/assembly).samefile(built)
for name in ('representative.json','cpython-worker.py'):
    copy2(sample/name,pair/name)
assert digest(pair/'representative.json')==known['catalogs']['representative.json']['sha256']
assert digest(pair/'cpython-worker.py')==known['cpythonWorkerSHA256']
def save(name,data):
    (pair/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
save('jobs.json',dict(warm=[['diagnostic.file-search-first-line',lane] for lane in ('warm','warm-async')]))
save('identity.json',dict(sourceRevision=known['sourceRevision'],referenceRevision=known['sourceRevision'],
    purpose='Measure mediated file phases and observer overhead around the unchanged first-line command.', observerSource=json.loads((lab/'source.json').read_bytes()),sourcePatchSHA256=digest(lab/'observer.patch'),
    imageFiles=images,coreSHA256={role+suffix:row['Lokad.Lython.dll'] for role,row in images.items() for suffix in ('','-control')},
    expectedCPythonSHA256=known['expectedCPythonSHA256'],cpythonWorkerSHA256=known['cpythonWorkerSHA256'],
    catalogs={name:{'sha256':digest(pair/name)} for name in ('representative.json','jobs.json')}))
