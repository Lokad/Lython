from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
initial = lab / 'local'
repeat = lab / 'repeat'
target = repo / 'benchmarks/results/2026-11-26-json-matched-record-capacity/confirmation'

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

receipt = read(repeat / 'archive-receipt.json')
assert receipt['archiveSHA256'] == sha(repeat / 'observations.tar.xz')
assert receipt['warmJobs'] == 3 and read(repeat / 'summary.json')['timedBatches'] == 84
assert receipt['quietBeforeAndAfter'] is None
assert all(receipt[key] for key in ('complete', 'allWorkersJoined', 'guestFixturesRemoved', 'archivedAndVerifiedUnderLease'))
assert (repeat / 'exit-code.txt').read_text().strip() == '0'
a, b = (read(folder / 'identity.json') for folder in (initial, repeat))
assert a['imageFiles'] == b['imageFiles'] and a['sourceRevision'] == b['sourceRevision']
assert sha(initial / 'representative.json') == sha(repeat / 'representative.json')
assert b['confirmingLocalArchiveSHA256'] == sha(initial / 'observations.tar.xz')
target.mkdir(exist_ok=False)
for name in ('summary.json', 'identity.json', 'observations.tar.xz', 'archive-receipt.json'):
    shutil.copyfile(repeat / name, target / name)
with tarfile.open(target / 'procedures.tar.xz', 'w:xz') as archive:
    for name in ('prepare-repeat.py', 'summarize-repeat.py', 'run-repeat.log',
                 'prepare-quiet.py', 'verified-archive-copies.py', 'archive-repeat.py'):
        archive.add(lab / name, arcname=name)
    for name in ('upload.json', 'archive-copy-preview.log'):
        archive.add(lab / 'comparison/quiet' / name, arcname='vm-preview/' + name)
