from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
donor = lab.with_name('fixed-row-local-bindings-20261126')
local = lab / 'local'
quiet = lab / 'comparison/quiet'
quiet.mkdir(parents=True)
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
write = lambda path, text: path.write_text(text, encoding='utf-8', newline='\n')
save = lambda path, value: write(path, json.dumps(value, indent=2) + '\n')

def substitute(text, replacements):
    for previous, current in replacements:
        assert text.count(previous) == 1, previous
        text = text.replace(previous, current)
    return text

identity = read(local / 'identity.json')
source = donor / 'comparison/quiet'
receipt = read(source / 'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['archiveSHA256'] == sha(source / 'observations.tar.xz')
assert identity['imageFiles']['reference'] == read(source / 'identity.json')['imageFiles']['candidate']
candidate = local / 'candidate'
assert len(identity['imageFiles']['candidate']) == 32
assert {p.name:sha(p) for p in candidate.iterdir()} == identity['imageFiles']['candidate']
for name in ('representative.json', 'cpython-worker.py', 'run.sh'):
    shutil.copyfile(local / name, quiet / name)
jobs = read(local / 'jobs.json')['warm']
save(quiet / 'jobs.json', {'warm': [jobs[i] for i in (2, 1, 0)]})
identity['catalogs']['jobs.json']['sha256'] = sha(quiet / 'jobs.json')
identity['confirmingLocalArchiveSHA256'] = sha(local / 'observations.tar.xz')
identity['purpose'] = 'Confirm the adverse async JSON Lines timing and stable-shape document storage on a quiet VM.'
save(quiet / 'identity.json', identity)

collector = substitute((source / 'collect.py').read_text(encoding='utf-8'), [
    ('lython-b1783-fixtures', 'lython-b1785-fixtures'),
    ('len(jobs) == 5', 'len(jobs) == 3'),
    ("proof['caseCount']==4", "proof['caseCount']==3"),
] if "proof['caseCount']==4" in (source / 'collect.py').read_text(encoding='utf-8') else [
    ('lython-b1783-fixtures', 'lython-b1785-fixtures'),
    ('len(jobs) == 5', 'len(jobs) == 3'),
])
compile(collector, 'collect.py', 'exec')
write(quiet / 'collect.py', collector)
entries = [('new-core.dll', candidate / 'Lokad.Lython.dll')]
entries.extend((name, quiet / name) for name in (
    'identity.json', 'representative.json', 'jobs.json', 'collect.py', 'run.sh', 'cpython-worker.py'))
payload = quiet / 'stage.tar.gz'
with tarfile.open(payload, 'w:gz', compresslevel=6) as archive:
    for name, path in entries:
        archive.add(path, arcname=name, recursive=False)
save(quiet / 'upload.json', dict(root='json-matched-record-capacity-b1785-20261126',
    payloadSHA256=sha(payload), payloadBytes=payload.stat().st_size,
    expandedBytes=sum(p.stat().st_size for _, p in entries), donorSHA256=receipt['archiveSHA256']))

launcher = (donor / 'quiet.py').read_text(encoding='utf-8')
edits = [
    ('lython-b1783-fixed-row-local-bindings-20261126', 'lython-b1785-json-matched-record-capacity-20261126'),
    ('borrowed-loop-iterators-b1782-20261126', 'fixed-row-local-bindings-b1783-20261126'),
    ('RuntimeMaxSec=285', 'RuntimeMaxSec=235'),
    ('seconds=205', 'seconds=132'),
]
if "proof['caseCount']==4" in launcher:
    edits.append(("proof['caseCount']==4", "proof['caseCount']==3"))
if "verification['caseCount']==4" in launcher:
    edits.append(("verification['caseCount']==4", "verification['caseCount']==3"))
launcher = substitute(launcher, edits)
compile(launcher, 'quiet.py', 'exec')
write(lab / 'quiet.py', launcher)
shutil.copyfile(donor / 'verified-archive-copies.py', lab / 'verified-archive-copies.py')
summary = substitute((donor / 'summarize-quiet.py').read_text(encoding='utf-8'), [
    ("receipt['warmJobs'] == 5", "receipt['warmJobs'] == 3"),
    ("len(raw['jobs']) == 5", "len(raw['jobs']) == 3"),
    ('timedBatches=140', 'timedBatches=84'),
])
compile(summary, 'summarize-quiet.py', 'exec')
write(lab / 'summarize-quiet.py', summary)
