from pathlib import Path, PurePosixPath
import hashlib
import io
import tarfile
import json
import re
import subprocess
import sys

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / "comparison/quiet"
read = lambda p: json.loads(p.read_text(encoding="utf-8"))
assert sys.argv[1:] in (["preview"], ["compact"])
upload = read(quiet / "upload.json")
threshold = upload["payloadBytes"] + upload["expandedBytes"] + 5 * 1024 * 1024 + 512 * 1024
claims = []
directories = [d for day in range(15, 27) for d in (repo / "benchmarks/results").glob(f"2026-11-{day}-*")]
directories += [d / "confirmation" for d in directories if d.parent.name == "results"]
for directory in directories:
    status_path = directory / "terminal-status.json"
    file = directory / "observations.tar.xz"
    if not status_path.is_file() or not file.is_file():
        continue
    primary = directory.parent if directory.name == "confirmation" else directory
    day = int(primary.name.split("-", 3)[2])
    if day < 21 and file.stat().st_size < 340_000:
        continue
    status = read(status_path)
    if status.get("exitCode") != "0" or status.get("live") or status.get("fixtures"):
        continue
    receipt = status.get("receipt") or {}
    if not all(receipt.get(key) for key in ("complete", "allWorkersJoined", "guestFixturesRemoved",
                                            "archivedAndVerifiedUnderLease")):
        continue
    stage = set(re.findall(r"/home/lokad/lython-bench-checks/([a-z0-9-]+)/(?:run\.sh|guest-fixtures)",
                          status.get("journal", "")))
    unit = set(re.findall(r"lython-b[0-9][a-z0-9-]*\.service", status.get("journal", "")))
    if len(stage) != 1 or len(unit) != 1:
        continue
    stage = stage.pop()
    unit = unit.pop()
    local = file.relative_to(repo).as_posix()
    tracked = subprocess.check_output(["git", "show", "HEAD:" + local], cwd=repo)
    digest = hashlib.sha256(tracked).hexdigest()
    assert digest == receipt["archiveSHA256"] == hashlib.sha256(file.read_bytes()).hexdigest()
    pair = dict(stage=stage, unit=unit, local=local, archiveSHA256=digest)
    if len(tracked) >= 340_000:
        claims.append(dict(**pair, relative="observations.tar.xz", sha256=digest, length=len(tracked)))
    if day >= 21:
        with tarfile.open(fileobj=io.BytesIO(tracked), mode="r:xz") as archive:
            for member in archive:
                name = PurePosixPath(member.name)
                profile = len(name.parts) == 3 and name.parts[0] == "profiles"
                warm = name.parts == ("confirmation", "confirmation.json")
                if not (profile or warm) or not member.isfile() or member.size < 65_536:
                    continue
                assert not name.is_absolute() and ".." not in name.parts
                entry = hashlib.file_digest(archive.extractfile(member), "sha256").hexdigest()
                claims.append(dict(**pair, relative=name.as_posix(), sha256=entry, length=member.size))
assert len({(item["stage"], item["relative"]) for item in claims}) == len(claims)
claims.sort(key=lambda item: -item["length"])
configuration = dict(claims=claims, threshold=threshold, compact=sys.argv[1] == "compact")
remote = r'''
from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess

base=Path('/home/lokad/lython-bench-checks')
assert base.resolve()==base
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    before=shutil.disk_usage(base).free
    total=before
    verified=[]
    for claim in cfg['claims']:
        if total>=cfg['threshold']:break
        stage=base/claim['stage']
        archive=stage/claim['relative']
        receipt=stage/'archive-receipt.json'
        if not archive.is_file() or not receipt.is_file():continue
        assert stage.parent==base and stage.resolve()==stage and archive.resolve()==archive and archive.is_relative_to(stage)
        assert not (stage/'guest-fixtures').exists()
        status=subprocess.run(['systemctl','show',claim['unit'],'--property=ActiveState,MainPID'],
                              capture_output=True,text=True).stdout.splitlines()
        assert 'ActiveState=inactive' in status and 'MainPID=0' in status,status
        proof=json.loads(receipt.read_text())
        assert proof['complete'] and proof['allWorkersJoined'] and proof['guestFixturesRemoved']
        info=archive.lstat()
        assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_uid==os.getuid()
        assert info.st_size==claim['length'] and proof['archiveSHA256']==claim['archiveSHA256']
        assert hashlib.sha256(archive.read_bytes()).hexdigest()==claim['sha256']
        verified.append((archive,claim))
        total+=info.st_size
    assert total>=cfg['threshold'],(before,total,cfg['threshold'])
    if cfg['compact']:
        for archive,claim in verified:archive.unlink()
    print(json.dumps(dict(before=before,after=shutil.disk_usage(base).free,threshold=cfg['threshold'],
                          compact=cfg['compact'],copies=[claim for archive,claim in verified])))
'''
command = ["ssh", "-i", str(Path.home() / ".ssh/id_lython-bench.pem"),
           "-o", "BatchMode=yes", "-o", "ConnectTimeout=12", "lokad@20.166.121.73", "python3 -"]
result = subprocess.run(command, input="cfg=" + repr(configuration) + "\n" + remote, encoding="utf-8",
                        capture_output=True, timeout=45)
(quiet / f"archive-copy-{sys.argv[1]}.log").write_text(result.stdout + result.stderr, encoding="utf-8", newline="\n")
if result.returncode:
    print(result.stderr)
else:
    record = json.loads(result.stdout)
    print({key: value for key, value in record.items() if key != "copies"}, "copies:", len(record["copies"]))
result.check_returncode()
