from pathlib import Path
import hashlib
import json
import shutil

lab = Path(".git/agent-notes/review-20261031/json-matched-record-capacity-20261126")
initial = lab / "local"
repeat = lab / "repeat"
repeat.mkdir()
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
save = lambda path, data: path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8", newline="\n")
status = read(initial / "archive-receipt.json")
assert status["complete"] and status["archiveSHA256"] == sha(initial / "observations.tar.xz")
identity = read(initial / "identity.json")
for role, expected in identity["imageFiles"].items():
    shutil.copytree(initial / role, repeat / role)
    assert {p.name:sha(p) for p in (repeat / role).iterdir()} == expected
for name in ("representative.json", "cpython-worker.py", "run.sh"):
    shutil.copyfile(initial / name, repeat / name)
jobs = read(lab / "comparison/quiet/jobs.json")
assert len(jobs["warm"]) == 3
save(repeat / "jobs.json", jobs)
identity["catalogs"]["jobs.json"]["sha256"] = sha(repeat / "jobs.json")
identity["confirmingLocalArchiveSHA256"] = status["archiveSHA256"]
identity["purpose"] = "Confirm the JSON sizing result with longer warmup, longer batches and reordered lanes."
save(repeat / "identity.json", identity)
collector = (initial / "collect.py").read_text(encoding="utf-8")
for before, after in (
    ("len(jobs) == 5", "len(jobs) == 3"),
    ("3 seconds full-request time", "5 seconds full-request time"),
    ("warmupSeconds=3, targetBatchSeconds=.30", "warmupSeconds=5, targetBatchSeconds=.46"),
    ("lython-json-record-capacity-fixture-", "lython-json-record-capacity-repeat-fixture-"),
    ("time.monotonic()-started < 282", "time.monotonic()-started < 145"),
):
    assert collector.count(before) == 1
    collector = collector.replace(before, after)
compile(collector, "collect.py", "exec")
(repeat / "collect.py").write_text(collector, encoding="utf-8", newline="\n")
summary = (lab / "summarize.py").read_text(encoding="utf-8")
summary = summary.replace("lab / 'local'", "lab / 'repeat'").replace("receipt['warmJobs'] == 5", "receipt['warmJobs'] == 3")
summary = summary.replace("len(raw['jobs']) == 5", "len(raw['jobs']) == 3").replace("timedBatches=140", "timedBatches=84")
compile(summary, "summarize-repeat.py", "exec")
(lab / "summarize-repeat.py").write_text(summary, encoding="utf-8", newline="\n")
