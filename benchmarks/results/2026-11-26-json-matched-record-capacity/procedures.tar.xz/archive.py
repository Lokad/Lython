from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
local = lab / 'local'
target = repo / 'benchmarks/results/2026-11-26-json-matched-record-capacity'

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

receipt = read(local / 'archive-receipt.json')
timing = read(local / 'summary.json')
identity = read(local / 'identity.json')
assert receipt['archiveSHA256'] == sha(local / 'observations.tar.xz')
assert receipt['warmJobs'] == 5 and timing['timedBatches'] == 140
assert receipt['quietBeforeAndAfter'] is None
assert all(receipt[key] for key in ('complete', 'allWorkersJoined', 'guestFixturesRemoved', 'archivedAndVerifiedUnderLease'))
assert (local / 'exit-code.txt').read_text().strip() == '0'
assert identity['sourcePatchSHA256'] == sha(lab / 'candidate.patch')
assert (lab / 'candidate.patch').read_bytes() == subprocess.check_output(
    ['git', 'diff', '--binary', identity['sourceRevision'], '--', 'src'], cwd=repo)
assert len(identity['imageFiles']['candidate']) == len(identity['imageFiles']['reference']) == 32
for role in ('reference', 'candidate'):
    proof = read(lab / (role + '-verify.json'))
    assert proof['caseCount'] == 3 and proof['state'] == 'Completed'
    assert proof['launched']['library']['sha256'] == identity['coreSHA256'][role]
    assert all(row['sharedBudgetBaselineRestored'] for row in read(lab / (role + '-allocation.json'))['rows'])
assert [(row['peak'][0] - row['peak'][1]) for row in read(lab / 'allocation-summary.json')] == [
    2047 * 144, 0, 4095 * 144,
]
target.mkdir(exist_ok=False)
for name in ('summary.json', 'identity.json', 'observations.tar.xz', 'archive-receipt.json'):
    shutil.copyfile(local / name, target / name)
for name in ('candidate.patch', 'allocation-summary.json'):
    shutil.copyfile(lab / name, target / name)
(lab / 'tests.patch').write_bytes(subprocess.check_output(
    ['git', 'diff', '--binary', identity['sourceRevision'], '--', 'tests'], cwd=repo))
with tarfile.open(target / 'procedures.tar.xz', 'w:xz') as archive:
    for name in ('prepare.py', 'prepare.log', 'run-local.sh', 'run-local.log', 'summarize.py', 'archive.py',
                 'reference-allocation.json', 'candidate-allocation.json', 'reference-verify.json',
                 'candidate-verify.json', 'tests.patch', 'test-ubuntu.sh'):
        archive.add(lab / name, arcname=name)
    for suite in ('Lokad.Lython.Tests', 'Lokad.Lython.PublicApi.Tests'):
        for platform, count in (('win11', '238' if suite.endswith('Lokad.Lython.Tests') else '923'),
                                ('ubuntu10', '238' if suite.endswith('Lokad.Lython.Tests') else '923')):
            path = lab / f'{suite}-{platform}.log'
            assert 'Passed:' in path.read_text(encoding='utf-8') and count in path.read_text(encoding='utf-8').splitlines()[-1]
            archive.add(path, arcname=path.name)
