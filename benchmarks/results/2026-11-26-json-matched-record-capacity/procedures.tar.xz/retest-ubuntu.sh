set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/json-matched-record-capacity-20261126"
log="$lab/retained-shape-ubuntu10.log"
if dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter 'FullyQualifiedName~JsonRecordShapeTests' > "$log" 2>&1; then
    tail -9 "$log"
else
    tail -32 "$log"
    exit 1
fi
