from pathlib import Path
import hashlib, json, shutil, subprocess

root=Path(__file__).resolve().parent
repo=root.parents[3]
prior=repo/'.git/agent-notes/review-20261031/tuple-transport-r397/candidate'
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files={p.name:digest(p) for p in prior.iterdir() if p.is_file()}
assert files['Lokad.Lython.dll']=='22e5b72c3d02a987758a2c84d08c61b4345fb11e7acac0394b5fef9d98e18141'
for role in ('reference','candidate'):
    folder=root/role; folder.mkdir(exist_ok=False)
    for name in files: shutil.copyfile(prior/name,folder/name)
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',root/'candidate/Lokad.Lython.dll')
manifest={role:{p.name:digest(p) for p in (root/role).iterdir() if p.is_file()} for role in ('reference','candidate')}
assert [n for n in files if manifest['reference'][n]!=manifest['candidate'][n]]==['Lokad.Lython.dll']
catalog=json.loads((repo/'.git/agent-notes/review-20261031/host-cost-r401/catalog.json').read_text(encoding='utf-8'))
original=next(c for c in catalog['cases'] if c['id']=='scripts.file-search.large.protected')
wide=dict(original)
wide['id']='diagnostic.file-search.wide-keyword-default'
wide['source']=original['source'].replace("def wanted(line, *, prefix='NEEDLE:'):\n", "def wanted(line, *, prefix='NEEDLE:'):\n    "+'='.join('a'+str(i) for i in range(17))+'=line\n')
assert wide['source']!=original['source']
wide['sourceSha256']=hashlib.sha256(wide['source'].encode()).hexdigest()
catalog['cases']=[original,wide]
(root/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
changed=[]; checked=0
paths=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],cwd=repo,text=True,encoding='utf-8').splitlines()
for path in paths:
    if not path.endswith('.cs'):continue
    current=(repo/path).read_bytes().replace(b'\r\n',b'\n')
    old=subprocess.check_output(['git','show','51e3c2c1:'+path],cwd=repo).replace(b'\r\n',b'\n')
    checked+=1
    if current!=old:changed.append(path)
assert changed==['src/Lokad.Lython/Runtime/LythonRuntime.Calls.Binding.cs'],changed
(root/'identity.json').write_text(json.dumps(dict(referenceRevision='51e3c2c1',candidateBase='4bc4a47e',prototype=True,sourceInputsChecked=checked,changedProduction=changed,files=manifest,catalogSHA256=digest(root/'catalog.json')),indent=2)+'\n',encoding='utf-8')
print('Frozen copied images; one changed production input; both full output goldens unchanged.')
