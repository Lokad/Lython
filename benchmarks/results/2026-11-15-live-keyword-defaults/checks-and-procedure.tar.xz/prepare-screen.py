from pathlib import Path

root=Path(__file__).resolve().parent
source=(root.parent/'tuple-transport-r395/local-screen.py').read_text(encoding='utf-8')
source=source.replace('candidate-identity.json', 'identity.json')
source=source.replace("identity['coreSHA256']", "identity['files']['candidate']['Lokad.Lython.dll']")
source=source.replace("identity['frozenFiles']", "identity['files']")
source=source.replace('Tuple storage/transport prototype diagnostic', 'Live async defaults correctness correction diagnostic')
source=source.replace("jobs=[('scripts.csv-invoice.large','warm'),('scripts.csv-fulfillment.large','warm'),('scripts.text-summary-helpers.nonlocal-counter.large','warm'),('scripts.json-summary-helpers.large','warm')]", "jobs=[('diagnostic.file-search.wide-keyword-default','warm-async'),('diagnostic.file-search.wide-keyword-default','warm'),('scripts.file-search.large.protected','warm-async')]")
source=source.replace("<130,", "<75,")
source=source.replace("['reference','candidate','candidate-control','reference-control']", "['reference','candidate','reference-control']")
source=source.replace('time.monotonic()+2.5','time.monotonic()+1.5')
source=source.replace('count*.15/', 'count*.1/')
source=source.replace('%4 for offset in range(4)', '%3 for offset in range(3)')
source=source.replace("for a in ['candidate','candidate-control']", "for a in ['candidate']")
assert 'tuple' not in source.lower()
(root/'local-screen.py').write_text(source,encoding='utf-8')
print('Prepared the existing framed complete-script screen, three small controlled jobs.')
