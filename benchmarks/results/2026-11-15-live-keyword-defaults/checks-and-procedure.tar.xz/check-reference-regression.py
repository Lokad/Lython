from pathlib import Path
import hashlib, json, os, shutil, subprocess
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parent
repo=root.parents[3]
folder=root/'reference-regression'
folder.mkdir(exist_ok=False)
for path in (repo/'tests/Lokad.Lython.Tests/bin/Release/net11.0').iterdir():
    if path.is_file(): shutil.copyfile(path,folder/path.name)
shutil.copyfile(root/'reference/Lokad.Lython.dll',folder/'Lokad.Lython.dll')
files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir() if p.is_file()}
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
with (root/'reference-regression.log').open('w',encoding='utf-8') as log:
    result=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','vstest',str(folder/'Lokad.Lython.WhiteBox.Tests.dll'),
        '--TestCaseFilter:FullyQualifiedName~AdmissionCanReplaceNativeDefaultsWithSuspendingProtocols',
        '--ResultsDirectory:'+str(root/'reference-test-results'), '--Logger:trx;LogFileName=reference-minimal.trx'],
        cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=35)
assert result.returncode==1
tree=ET.parse(root/'reference-test-results/reference-minimal.trx')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
rows=tree.findall('.//t:UnitTestResult',ns)
assert len(rows)==3 and all(r.attrib['outcome']=='Failed' for r in rows)
assert all('Assert.Same() Failure' in ''.join(r.itertext()) and 'Faulted' in ''.join(r.itertext()) for r in rows)
(root/'reference-regression-proof.json').write_text(json.dumps(dict(expectedFailure=True,failed=3,fixture='Final seventeen-local fixture from6e276759; same test image with frozen51e3/22e5 runtime',allUsersJoined=True,files=files),indent=2)+'\n',encoding='utf-8')
print('All three final regression cases fail as expected on frozen51e3/22e5; all users joined.')
