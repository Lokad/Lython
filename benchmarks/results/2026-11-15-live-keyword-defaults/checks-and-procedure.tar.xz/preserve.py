from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parent
repo=root.parents[3]
target=repo/'benchmarks/results/2026-11-15-live-keyword-defaults'
target.mkdir(exist_ok=False)
checks=[]
for framework, short in (('net11.0','11'),('net10.0','10')):
    specs=[('internal',repo/f'tests/Lokad.Lython.Tests/TestResults/r402-after-net{short}.trx'),
           ('internal-minimal',repo/f'tests/Lokad.Lython.Tests/TestResults/r402-minimal-net{short}.trx'),
           ('public',repo/f'tests/Lokad.Lython.PublicApi.Tests/TestResults/r402-public-net{short}.trx'),
           ('public-extra',repo/f'tests/Lokad.Lython.PublicApi.Tests/TestResults/r402-extra-{framework}.trx')]
    unique={}
    for suite,path in specs:
        tree=ET.parse(path);ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
        rows=tree.findall('.//t:UnitTestResult',ns)
        assert rows and all(row.attrib['outcome']=='Passed' for row in rows)
        for row in rows:unique[row.attrib['testName']]=row.attrib['outcome']
        checks.append(dict(framework=framework,suite=suite,passed=len(rows),trx=path.relative_to(repo).as_posix(),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    assert len(unique)==204,len(unique)
with tarfile.open(target/'checks-and-procedure.tar.xz','w:xz') as archive:
    for check in checks:archive.add(repo/check['trx'],arcname=check['trx'],recursive=False)
    before=repo/'tests/Lokad.Lython.Tests/TestResults/r402-before.trx'
    archive.add(before,arcname='original-forty-local-reference.trx',recursive=False)
    for path in root.joinpath('reference-test-results').glob('*.trx'):archive.add(path,arcname=path.name,recursive=False)
    for name in ('prepare-diagnostic.py','prepare-screen.py','local-screen.py','check-reference-regression.py','preserve.py','reference-regression-proof.json','reference-regression.log','catalog.json'):
        archive.add(root/name,arcname=name,recursive=False)
    with subprocess.Popen(['git','diff','51e3c2c1','6e276759','--','src/Lokad.Lython','tests/Lokad.Lython.Tests/OrdinaryFunctionTransportTests.cs'],cwd=repo,stdout=subprocess.PIPE) as process:
        patch=process.communicate()[0];assert process.returncode==0
    info=tarfile.TarInfo('committed-change.patch');info.size=len(patch)
    import io
    archive.addfile(info,io.BytesIO(patch))
for name in ('identity.json','local-screen.json','reference-regression-proof.json'):
    shutil.copyfile(root/name,target/name)
screen=json.loads((root/'local-screen.json').read_text(encoding='utf-8'))
assert screen['complete'] and screen['allGoldensAndBudgetsPassed'] and screen['allUsersJoined']
summary=dict(runtimeRevision='6e276759',qualification='Focused Release passes; full43717654522 Windows/Ubuntu actual11/10/stress/installed-consumer checkpoint dispatched, not yet observed.',checks=checks,
    uniqueFocusedChecksPerTarget=204,newRegressionCasesPerTarget=3,
    reference='Final seventeen-local fixture fails all three cases on frozen51e3/22e5; final changed runtime passes. Original forty-local first failure also retained.',
    sourceChange='Remove pre-admission protocol-default snapshot; inspect actual live dictionary during binding, finish native lookups synchronously and defer protocol defaults in order.',
    compatibility='No public API or intended Python contract change. Synchronous binding unchanged. No new policy/cache/owner/retry or dispatch framework.',
    diagnostic=[dict(case=j['case'],lane=j['lane'],medians=j['medianMilliseconds'],changePercent=j['changePercent']) for j in screen['jobs']],
    limitation='Desktop I/O and moving unchanged controls (about5 to30percent) prevent CPU, quiet-machine or speedup claims. Candidate is retained for correctness.',
    setupCorrections=['Initial new test used protected BindingPlan; use ordinary function default-attribute mutation instead. No production change in that correction.', 'First screen launch referred to missing candidate-identity.json and stopped before workers; use the actual identity.json.'],
    publicationPostponed=True)
(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print('Preserved final source pair, all adverse controls, 204 unique checks per target and original/final reference failures.')
