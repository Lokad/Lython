from pathlib import Path
import hashlib, json, tarfile

root=Path(__file__).resolve().parent
repo=root.parents[3]
target=repo/'benchmarks/results/2026-11-15-live-keyword-defaults/source-and-images.tar.xz'
assert not target.exists()
identity=json.loads((root/'identity.json').read_text(encoding='utf-8'))
with tarfile.open(target,'w:xz') as archive:
    for name,expected in identity['files']['reference'].items():
        path=root/'reference'/name
        assert hashlib.sha256(path.read_bytes()).hexdigest()==expected
        archive.add(path,arcname='reference/'+name,recursive=False)
    archive.add(root/'candidate/Lokad.Lython.dll',arcname='candidate-core.dll',recursive=False)
    archive.add(root/'source-at-commit.tar.xz',arcname='source-at-commit.tar.xz',recursive=False)
    for name in ('verify-source.py','archive-images.py'):
        archive.add(root/name,arcname=name,recursive=False)
with tarfile.open(target) as archive:
    for role in ('reference','candidate'):
        for name,expected in identity['files'][role].items():
            member='candidate-core.dll' if role=='candidate' and name=='Lokad.Lython.dll' else 'reference/'+name
            assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==expected,(role,name)
print('Both complete measured images reconstruct byte-for-byte; archive bytes',target.stat().st_size)
