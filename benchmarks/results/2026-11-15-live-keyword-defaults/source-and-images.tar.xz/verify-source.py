from pathlib import Path
import hashlib, io, json, subprocess, tarfile

root=Path(__file__).resolve().parent
repo=root.parents[3]
target=repo/'benchmarks/results/2026-11-15-live-keyword-defaults'
build=['Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json']
test='tests/Lokad.Lython.Tests/OrdinaryFunctionTransportTests.cs'
raw=subprocess.check_output(['git','archive','--format=tar','6e276759','--','src/Lokad.Lython',*build,test],cwd=repo)
rows=[]
with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
    for entry in archive.getmembers():
        if not entry.isfile():continue
        committed=archive.extractfile(entry).read()
        current=(repo/entry.name).read_bytes()
        assert committed.replace(b'\r\n',b'\n')==current.replace(b'\r\n',b'\n'),entry.name
        rows.append(dict(path=entry.name,committedSHA256=hashlib.sha256(committed).hexdigest(),workingSHA256=hashlib.sha256(current).hexdigest(),explicitNewlineNormalizedEqual=True))
assert sum(r['path'].startswith('src/Lokad.Lython/') for r in rows)==585
assert len(rows)==590
identity=json.loads((root/'identity.json').read_text(encoding='utf-8'))
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for role in ('reference','candidate'):
    for name, expected in identity['files'][role].items():assert digest(root/role/name)==expected,(role,name)
assert digest(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll')==identity['files']['candidate']['Lokad.Lython.dll']
proof=dict(commit='6e276759ebeea586bbb0c33abb361ffb3a30eb34',productionInputs=585,additionalBuildInputs=4,changedTestInputs=1,
    sourceCheck='Current source matches committed source with explicit CRLF-to-LF normalization. Both copied measured images retain every frozen hash.',
    independentCiBinaryIdentityNotInferred=True, frozenCandidateCore=identity['files']['candidate']['Lokad.Lython.dll'],files=rows)
(target/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
with tarfile.open(root/'source-at-commit.tar.xz','w:xz') as archive:
    with tarfile.open(fileobj=io.BytesIO(raw)) as original:
        for entry in original.getmembers():
            if entry.isfile():archive.addfile(entry, original.extractfile(entry))
    archive.add(Path(__file__),arcname='verification/verify-source.py',recursive=False)
print('585 production +4 build +1 changed test inputs match6e276759; every reference/candidate image hash verifies.')
