set -eu
root=/home/lokad/lython-bench-checks/helper-pipeline-b874-20261117
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
