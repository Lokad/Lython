from pathlib import Path
import datetime,hashlib,json,shutil,subprocess

lab=Path(__file__).resolve().parent
quiet=lab/'comparison/quiet'
failure=lab/'initial-collector'
failure.mkdir(exist_ok=True)
for name in ('collect.py','launch.log','run.sh','upload.json'):
    shutil.copyfile(quiet/name,failure/name)
terminal=max(quiet.glob('status-*.json'))
shutil.copyfile(terminal,failure/'terminal-status.json')
state=json.loads(terminal.read_text(encoding='utf-8'))
assert not state['live'] and not state['fixtures'] and state['receipt'] is None and state['exitCode']=='1'
assert 'assert len(jobs) == 4' in state['journal']
source=(quiet/'collect.py').read_text(encoding='utf-8')
assert source.count('len(jobs) == 4')==1
amended=source.replace('len(jobs) == 4','len(jobs) == 5')
compile(amended,'collect.py','exec')
normalize=lambda text:text.encode('utf-8')
sha=lambda data:hashlib.sha256(data).hexdigest()
previous='lython-b1567-fixed-result-order-20261124'
unit=previous+'-corrected'
config=json.loads((quiet/'upload.json').read_text(encoding='utf-8'))
script=f"""
from pathlib import Path
import fcntl,hashlib,json,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
root=base/{config['root']!r}
reference=base/{config['reference']!r}
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 state=subprocess.check_output(['systemctl','show',{previous!r}+'.service','--property=ActiveState,Result,MainPID'],text=True)
 assert 'ActiveState=failed' in state and 'MainPID=0' in state
 assert not (root/'guest-fixtures').exists() and not list((root/'confirmation').iterdir())
 assert (root/'exit-code.txt').read_text().strip()=='1'
 collection=root/'collect.py'
 assert digest(collection)=={sha(normalize(source))!r}
 source=root/'identity.json'
 assert digest(source)=={sha((lab/'comparison/identity.json').read_bytes())!r}
 identity=json.loads(source.read_text())
 for role, files in identity['imageFiles'].items():
  image=(reference if role=='reference' else root)/'candidate'
  assert len(files)==32 and all(digest(image/name)==expected for name,expected in files.items())
 for name, proof in identity['catalogs'].items(): assert digest(root/name)==proof['sha256']
 assert digest(root/'run.sh')=={sha((quiet/'run.sh').read_bytes())!r}
 assert digest(root/'cpython-worker.py')==identity['cpythonWorkerSHA256']
 evidence=root/'initial-collector'
 evidence.mkdir()
 (root/'confirmation').rename(evidence/'confirmation')
 for name in ['collect.py','exit-code.txt']:
  (evidence/name).write_bytes((root/name).read_bytes())
 temporary=root/'collect.py.new'
 temporary.write_bytes({normalize(amended)!r})
 assert digest(temporary)=={sha(normalize(amended))!r}
 temporary.replace(collection)
subprocess.run(['sudo','-n','systemd-run','--unit='+{unit!r},'--property=User=lokad',
 '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=330','--property=TimeoutStopSec=20',
 '--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
"""
result=subprocess.run(['ssh','-i',Path.home()/'.ssh/id_lython-bench.pem','-o','BatchMode=yes',
    '-o','ConnectTimeout=10','lokad@20.166.121.73','python3 -'],input=script,encoding='utf-8',
    capture_output=True,timeout=35)
(quiet/'corrected-launch.log').write_text(result.stdout+result.stderr,encoding='utf-8',newline='\n')
result.check_returncode()
(quiet/'collect.py').write_bytes(normalize(amended))
launcher=lab/'quiet.py'
text=launcher.read_text(encoding='utf-8').replace(f'unit="{previous}"',f'unit="{unit}"')
compile(text,'quiet.py','exec')
launcher.write_text(text,encoding='utf-8',newline='\n')
until=datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(seconds=265)
(quiet/'observe-not-before').write_text(until.isoformat(),encoding='utf-8')
print(unit,result.stdout,result.stderr)

