; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 288
       lea      rbp, [rsp+0x120]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -240
 
G_M000_IG36:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG36
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0045
       mov      rcx, bword ptr [rbp+0x48]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG03
       cmp      gword ptr [rbp+0x50], 0
       jne      SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x58]
       cmp      gword ptr [rax], 0
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0064
       mov      rcx, gword ptr [rbp+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_DefinitionAnnotationKeys():Lokad.Lython.Runtime.PyDict+RecordKeys:this]
       mov      gword ptr [rbp-0xA0], rax
       mov      rdx, gword ptr [rbp-0xA0]
       mov      rcx, 0x7FFA02CDC4F8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x48], rax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0094
       xor      rax, rax
       mov      gword ptr [rbp-0x48], rax
 
G_M000_IG05:                ;; offset=0x009A
       mov      rax, gword ptr [rbp-0x48]
       mov      gword ptr [rbp-0x08], rax
       cmp      gword ptr [rbp-0x08], 0
       jne      SHORT G_M000_IG06
       xor      eax, eax
       mov      dword ptr [rbp-0x4C], eax
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00B0
       mov      rcx, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:get_PreparedValueCapacity():int:this]
       mov      dword ptr [rbp-0x4C], eax
 
G_M000_IG07:                ;; offset=0x00BD
       mov      eax, dword ptr [rbp-0x4C]
       mov      dword ptr [rbp-0x0C], eax
       cmp      gword ptr [rbp-0x08], 0
       je       SHORT G_M000_IG08
       mov      ecx, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:FunctionAndAnnotationBytes(int):long]
       mov      qword ptr [rbp-0x58], rax
       jmp      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x00D9
       mov      qword ptr [rbp-0x58], 160
 
G_M000_IG09:                ;; offset=0x00E1
       mov      rax, qword ptr [rbp-0x58]
       mov      qword ptr [rbp-0x18], rax
       movzx    rax, byte  ptr [rbp+0x60]
       test     eax, eax
       je       SHORT G_M000_IG10
       mov      rcx, 0x7FFA02A75928
       call     [CORINFO_HELP_GET_NONGCSTATIC_BASE]
       mov      rax, qword ptr [(reloc 0x7ffa0253b0d8)]
       add      rax, qword ptr [rbp-0x18]
       jo       G_M000_IG31
       mov      qword ptr [rbp-0x18], rax
 
G_M000_IG10:                ;; offset=0x0116
       mov      rcx, bword ptr [rbp+0x68]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG11
       mov      rax, qword ptr [rbp-0x18]
       add      rax, 96
       jo       G_M000_IG31
       mov      qword ptr [rbp-0x18], rax
 
G_M000_IG11:                ;; offset=0x0136
       mov      rcx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x20], rax
       mov      rax, bword ptr [rbp+0x58]
       cmp      gword ptr [rax], 0
       jne      SHORT G_M000_IG12
       mov      rcx, gword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       mov      r8, gword ptr [rbp+0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Reserve(long,Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG12:                ;; offset=0x0164
       nop      
 
G_M000_IG13:                ;; offset=0x0165
       mov      rcx, gword ptr [rbp+0x38]
       mov      rdx, gword ptr [rbp+0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       xor      rax, rax
       mov      gword ptr [rbp-0x28], rax
       mov      rcx, bword ptr [rbp+0x68]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG16
       mov      rcx, 0x7FFA02C97DA0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x90], rax
       mov      rax, bword ptr [rbp+0x68]
       cmp      dword ptr [rax+0x08], 0
       jbe      G_M000_IG19
       mov      rax, bword ptr [rbp+0x68]
       mov      rax, bword ptr [rax]
 
G_M000_IG14:                ;; offset=0x01B4
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG15:                ;; offset=0x01C0
       lea      rdx, [rbp-0xB0]
       mov      rcx, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:.ctor(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x28], rax
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp+0x20], rax
 
G_M000_IG16:                ;; offset=0x01EA
       movzx    rax, byte  ptr [rbp+0x30]
       test     eax, eax
       jne      SHORT G_M000_IG20
       mov      rcx, 0x7FFA02CB7368
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x88], rax
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG17:                ;; offset=0x020C
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
       mov      rcx, qword ptr [rax+0x10]
       mov      qword ptr [rbp-0xB8], rcx
 
G_M000_IG18:                ;; offset=0x0223
       lea      rax, [rbp-0xC8]
       mov      qword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       mov      r9, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x88]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:.ctor(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults):this]
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x68], rax
       jmp      SHORT G_M000_IG23
 
G_M000_IG19:                ;; offset=0x0255
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG20:                ;; offset=0x025B
       mov      rcx, 0x7FFA02CDC648
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x60], rax
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG21:                ;; offset=0x0272
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
       mov      rcx, qword ptr [rax+0x10]
       mov      qword ptr [rbp-0xD0], rcx
 
G_M000_IG22:                ;; offset=0x0289
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rax
       lea      r9, [rbp-0xE0]
       mov      rdx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.PyGeneratorFunction:.ctor(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.FunctionDefaults,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell]):this]
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x68], rax
 
G_M000_IG23:                ;; offset=0x02B3
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x30], rax
       mov      rcx, gword ptr [rbp+0x18]
       mov      rdx, gword ptr [rbp-0x20]
       mov      r8, gword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:ChargeClosureRetention(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan)]
       cmp      gword ptr [rbp-0x08], 0
       je       G_M000_IG27
       mov      rax, bword ptr [rbp+0x58]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x70], rax
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, gword ptr [rbp-0x70]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x70], 0
       jne      SHORT G_M000_IG26
       mov      rax, gword ptr [rbp+0x50]
       mov      gword ptr [rbp-0x38], rax
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x38], 0
       jne      SHORT G_M000_IG26
       mov      rax, bword ptr [rbp+0x48]
 
G_M000_IG24:                ;; offset=0x0315
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xF0], xmm0
 
G_M000_IG25:                ;; offset=0x0321
       mov      rax, gword ptr [rbp+0x40]
       mov      gword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0xF0]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:CopyAnnotationValues(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object[]:this]
       mov      gword ptr [rbp-0x80], rax
 
G_M000_IG26:                ;; offset=0x0349
       mov      rax, bword ptr [rbp+0x58]
       movzx    r9, byte  ptr [rax+0x0C]
       mov      rcx, gword ptr [rbp-0x78]
       mov      rdx, gword ptr [rbp-0x80]
       mov      r8, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyFunctionBase:AttachAdmittedAnnotations(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):this]
 
G_M000_IG27:                ;; offset=0x0366
       mov      rcx, gword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Commit(long):this]
       cmp      gword ptr [rbp-0x28], 0
       je       SHORT G_M000_IG28
       mov      rax, gword ptr [rbp-0x28]
       mov      byte  ptr [rax+0x29], 1
       mov      rax, bword ptr [rbp+0x68]
       cmp      dword ptr [rax+0x08], 0
       jbe      G_M000_IG19
       mov      rax, bword ptr [rbp+0x68]
       mov      rcx, bword ptr [rax]
       mov      rdx, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG28:                ;; offset=0x03A4
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG29:                ;; offset=0x03AC
       mov      rax, gword ptr [rbp-0x40]
 
G_M000_IG30:                ;; offset=0x03B0
       add      rsp, 288
       pop      rbp
       ret      
 
G_M000_IG31:                ;; offset=0x03B9
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG32:                ;; offset=0x03BF
       sub      rsp, 40
 
G_M000_IG33:                ;; offset=0x03C3
       mov      gword ptr [rbp-0x98], rcx
       mov      rax, bword ptr [rbp+0x58]
       cmp      gword ptr [rax], 0
       jne      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x03D4
       mov      rcx, gword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReleaseReserved(long):this]
 
G_M000_IG35:                ;; offset=0x03E4
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 1002

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 80
       lea      rbp, [rsp+0x50]
       xor      eax, eax
       mov      qword ptr [rbp-0x28], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0029
       mov      rax, bword ptr [rbp+0x28]
       mov      byte  ptr [rax], 0
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_CanStartInline():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x0040
       add      rsp, 80
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x0046
       mov      rax, bword ptr [rbp+0x28]
       mov      bword ptr [rbp-0x18], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rax, bword ptr [rbp-0x18]
       mov      bword ptr [rbp-0x20], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x2C], eax
       mov      edx, dword ptr [rbp-0x2C]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.PyFunctionBase:HasCompletePositionalSupply(int,System.Object):bool:this]
       mov      dword ptr [rbp-0x24], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x008B
       mov      rax, bword ptr [rbp-0x18]
       mov      bword ptr [rbp-0x20], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x24], eax
 
G_M000_IG06:                ;; offset=0x0098
       mov      rax, bword ptr [rbp-0x20]
       mov      ecx, dword ptr [rbp-0x24]
       mov      byte  ptr [rax], cl
       mov      rax, bword ptr [rbp+0x28]
       movzx    rax, byte  ptr [rax]
       test     eax, eax
       je       SHORT G_M000_IG08
       mov      eax, 1
 
G_M000_IG07:                ;; offset=0x00B1
       add      rsp, 80
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x00B7
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       cmp      eax, 16
       jg       G_M000_IG13
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jge      G_M000_IG13
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       test     eax, eax
       jge      SHORT G_M000_IG13
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalDefaults():System.Object:this]
       mov      gword ptr [rbp-0x08], rax
       cmp      gword ptr [rbp-0x08], 0
       je       SHORT G_M000_IG09
       mov      rdx, gword ptr [rbp-0x08]
       mov      rcx, 0x7FFA02C41128
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG13
 
G_M000_IG09:                ;; offset=0x0118
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0x10], rax
       cmp      gword ptr [rbp-0x10], 0
       je       SHORT G_M000_IG10
       mov      rcx, gword ptr [rbp-0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x28], eax
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0146
       xor      eax, eax
       mov      dword ptr [rbp-0x28], eax
 
G_M000_IG11:                ;; offset=0x014B
       cmp      dword ptr [rbp-0x28], 0
       sete     al
       movzx    rax, al
 
G_M000_IG12:                ;; offset=0x0155
       add      rsp, 80
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x015B
       xor      eax, eax
 
G_M000_IG14:                ;; offset=0x015D
       add      rsp, 80
       pop      rbp
       ret      
 
; Total bytes of code 355

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 704
       lea      rbp, [rsp+0x2C0]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -624
 
G_M000_IG32:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG32
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0045
       cmp      gword ptr [rbp+0x28], 0
       jne      G_M000_IG13
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       G_M000_IG13
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       jne      SHORT G_M000_IG05
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG03:                ;; offset=0x0079
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1C0], xmm0
 
G_M000_IG04:                ;; offset=0x0085
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x1C0]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x19C], eax
       jmp      G_M000_IG11
 
G_M000_IG05:                ;; offset=0x00BB
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x198], eax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x198]
       jne      SHORT G_M000_IG10
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG06:                ;; offset=0x00E9
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG07:                ;; offset=0x00F5
       lea      rdx, [rbp-0x1D0]
       lea      rcx, [rbp-0x1B0]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
 
G_M000_IG08:                ;; offset=0x0109
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
 
G_M000_IG09:                ;; offset=0x0119
       lea      rdx, [rbp-0x1E0]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, bword ptr [rbp+0x60]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x19C], eax
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x013A
       xor      eax, eax
       mov      dword ptr [rbp-0x19C], eax
 
G_M000_IG11:                ;; offset=0x0142
       cmp      dword ptr [rbp-0x19C], 0
       je       SHORT G_M000_IG13
       mov      rax, bword ptr [rbp+0x58]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x68]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG12:                ;; offset=0x015B
       vzeroupper 
       add      rsp, 704
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x0167
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
       vmovdqu  ymmword ptr [rbp-0xE0], ymm0
       vmovdqu  ymmword ptr [rbp-0xC0], ymm0
       vmovdqu  ymmword ptr [rbp-0xA0], ymm0
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  ymmword ptr [rbp-0x40], ymm0
       vmovdqu  ymmword ptr [rbp-0x20], ymm0
       lea      rdx, [rbp-0x100]
       lea      rcx, [rbp-0x110]
       mov      r8d, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       mov      r9d, dword ptr [rbp-0x1E4]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x110]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       je       G_M000_IG17
       xor      eax, eax
       mov      dword ptr [rbp-0x114], eax
       cmp      gword ptr [rbp+0x28], 0
       je       SHORT G_M000_IG14
       mov      eax, dword ptr [rbp-0x114]
       mov      dword ptr [rbp-0x194], eax
       mov      eax, dword ptr [rbp-0x114]
       inc      eax
       mov      dword ptr [rbp-0x114], eax
       mov      eax, dword ptr [rbp-0x108]
       cmp      dword ptr [rbp-0x194], eax
       jae      G_M000_IG31
       mov      eax, dword ptr [rbp-0x194]
       shl      rax, 4
       mov      rcx, rax
       add      rcx, bword ptr [rbp-0x110]
       mov      rdx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG14:                ;; offset=0x0257
       lea      rdx, [rbp-0x190]
       lea      rcx, [rbp-0x110]
       mov      r8d, dword ptr [rbp-0x114]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG15:                ;; offset=0x0272
       vmovdqu  xmm0, xmmword ptr [rbp-0x190]
       vmovdqu  xmmword ptr [rbp-0x1F8], xmm0
 
G_M000_IG16:                ;; offset=0x0282
       lea      rdx, [rbp-0x1F8]
       mov      rcx, bword ptr [rbp+0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG23
 
G_M000_IG17:                ;; offset=0x0298
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x1FC], eax
       mov      r9d, dword ptr [rbp-0x1FC]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x170]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG18:                ;; offset=0x02D2
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0x210], xmm0
 
G_M000_IG19:                ;; offset=0x02E2
       vmovdqu  xmm0, xmmword ptr [rbp-0x128]
       vmovdqu  xmmword ptr [rbp-0x220], xmm0
 
G_M000_IG20:                ;; offset=0x02F2
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG21:                ;; offset=0x0317
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x230], xmm0
 
G_M000_IG22:                ;; offset=0x0323
       lea      rcx, [rbp-0x210]
       lea      rdx, [rbp-0x220]
       lea      rax, [rbp-0x230]
       mov      qword ptr [rsp+0x40], rax
       mov      r9, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG23:                ;; offset=0x034B
       vmovdqu  xmm0, xmmword ptr [rbp-0x110]
       vmovdqu  xmmword ptr [rbp-0x180], xmm0
 
G_M000_IG24:                ;; offset=0x035B
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
 
G_M000_IG25:                ;; offset=0x0367
       vmovdqu  xmm0, xmmword ptr [rbp-0x180]
       vmovdqu  xmmword ptr [rbp-0x240], xmm0
 
G_M000_IG26:                ;; offset=0x0377
       vmovdqu  ymm0, ymmword ptr [rbp-0x160]
       vmovdqu  ymmword ptr [rbp-0x260], ymm0
 
G_M000_IG27:                ;; offset=0x0387
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG28:                ;; offset=0x0393
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x270], xmm0
 
G_M000_IG29:                ;; offset=0x039F
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rax
       lea      rax, [rbp-0x140]
       mov      qword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0x240]
       lea      r8, [rbp-0x260]
       lea      rax, [rbp-0x270]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp+0x38]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG30:                ;; offset=0x03EF
       vzeroupper 
       add      rsp, 704
       pop      rbp
       ret      
 
G_M000_IG31:                ;; offset=0x03FB
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1025

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 112
       lea      rbp, [rsp+0x70]
       xor      eax, eax
       mov      qword ptr [rbp-0x48], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
 
G_M000_IG02:                ;; offset=0x0025
       mov      rcx, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x30]Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterLayout():Lokad.Lython.Frontend.FunctionParameterLayout:this
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_KeywordOnlyCount():int:this]
       test     eax, eax
       je       SHORT G_M000_IG04
       mov      rax, gword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x18]
       test     eax, eax
       jne      SHORT G_M000_IG03
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x08]
       mov      rcx, 0x7FFA026028A8
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       je       G_M000_IG08
 
G_M000_IG03:                ;; offset=0x0078
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_Defaults():Lokad.Lython.Frontend.FunctionParameterLayout+DefaultSlot[]:this]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x38], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalDefaultCount():int:this]
       mov      ecx, dword ptr [rbp-0x38]
       sub      ecx, eax
       mov      dword ptr [rbp-0x3C], ecx
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_KeywordOnlyCount():int:this]
       cmp      eax, dword ptr [rbp-0x3C]
       jne      G_M000_IG08
 
G_M000_IG04:                ;; offset=0x00B3
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp+0x18]
       jl       G_M000_IG08
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalCount():int:this]
       mov      dword ptr [rbp-0x0C], eax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalDefaults():System.Object:this]
       mov      gword ptr [rbp-0x48], rax
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, 0x7FFA02C41128
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x18], rax
       mov      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x1C], eax
       mov      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x20], eax
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x28], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG05
       mov      eax, dword ptr [rbp-0x1C]
       mov      dword ptr [rbp-0x2C], eax
       mov      eax, dword ptr [rbp-0x20]
       mov      dword ptr [rbp-0x30], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x34], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x012B
       mov      eax, dword ptr [rbp-0x1C]
       mov      dword ptr [rbp-0x2C], eax
       mov      eax, dword ptr [rbp-0x20]
       mov      dword ptr [rbp-0x30], eax
       mov      rcx, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.PyTuple:get_Count():int:this]
       mov      dword ptr [rbp-0x34], eax
 
G_M000_IG06:                ;; offset=0x0144
       mov      eax, dword ptr [rbp-0x30]
       sub      eax, dword ptr [rbp-0x34]
       cmp      dword ptr [rbp-0x2C], eax
       setge    al
       movzx    rax, al
 
G_M000_IG07:                ;; offset=0x0153
       add      rsp, 112
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0159
       xor      eax, eax
 
G_M000_IG09:                ;; offset=0x015B
       add      rsp, 112
       pop      rbp
       ret      
 
; Total bytes of code 353

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:TryReadPreparedDefaultInteger(int,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 112
       lea      rbp, [rsp+0x70]
       xor      eax, eax
       mov      qword ptr [rbp-0x48], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      bword ptr [rbp+0x20], r8
 
G_M000_IG02:                ;; offset=0x0029
       mov      rcx, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x30]Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterLayout():Lokad.Lython.Frontend.FunctionParameterLayout:this
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp+0x18]
       jg       G_M000_IG06
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalCount():int:this]
       mov      ecx, dword ptr [rbp+0x18]
       sub      ecx, eax
       mov      dword ptr [rbp-0x4C], ecx
       mov      r8d, dword ptr [rbp-0x4C]
       lea      rdx, [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:KeywordDefaultAt(int):Lokad.Lython.Frontend.FunctionParameterLayout+KeywordDefault:this]
       lea      rcx, [rbp-0x30]
       call     [Lokad.Lython.Frontend.FunctionParameterLayout+KeywordDefault:get_RecordPosition():int:this]
       mov      dword ptr [rbp-0x1C], eax
       mov      rax, gword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x18]
       test     eax, eax
       jne      SHORT G_M000_IG03
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x08]
       mov      rcx, 0x7FFA026028A8
       call     [CORINFO_HELP_CHKCASTARRAY]
       mov      ecx, dword ptr [rbp-0x1C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG10
       mov      edx, ecx
       lea      rax, bword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x48], rax
       jmp      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x00C5
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x48], rax
 
G_M000_IG04:                ;; offset=0x00D1
       lea      rcx, [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      rcx, [rbp-0x40]
       mov      rdx, bword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
       nop      
 
G_M000_IG05:                ;; offset=0x00EE
       add      rsp, 112
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x00F4
       lea      r8, [rbp-0x18]
       mov      rcx, gword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG08
       lea      rcx, [rbp-0x18]
       mov      rdx, bword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
       nop      
 
G_M000_IG07:                ;; offset=0x0118
       add      rsp, 112
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x011E
       mov      rax, bword ptr [rbp+0x20]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       xor      eax, eax
 
G_M000_IG09:                ;; offset=0x0129
       add      rsp, 112
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x012F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 309

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0028
       mov      rax, bword ptr [rbp+0x28]
       mov      byte  ptr [rax], 0
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_CanStartInline():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       mov      rcx, 0x7FFA02D867A0
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x004E
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x0054
       mov      rax, bword ptr [rbp+0x28]
       mov      bword ptr [rbp-0x18], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rax, bword ptr [rbp-0x18]
       mov      bword ptr [rbp-0x20], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x34], eax
       mov      edx, dword ptr [rbp-0x34]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.PyFunctionBase:HasCompletePositionalSupply(int,System.Object):bool:this]
       mov      dword ptr [rbp-0x24], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0099
       mov      rcx, 0x7FFA02D867A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x18]
       mov      bword ptr [rbp-0x20], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x24], eax
 
G_M000_IG06:                ;; offset=0x00B5
       mov      rax, bword ptr [rbp-0x20]
       mov      ecx, dword ptr [rbp-0x24]
       mov      byte  ptr [rax], cl
       mov      rax, bword ptr [rbp+0x28]
       movzx    rax, byte  ptr [rax]
       test     eax, eax
       je       SHORT G_M000_IG08
       mov      rcx, 0x7FFA02D867A8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG07:                ;; offset=0x00DD
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x00E3
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       cmp      eax, 16
       jg       G_M000_IG17
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jge      G_M000_IG13
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       test     eax, eax
       jge      G_M000_IG12
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalDefaults():System.Object:this]
       mov      gword ptr [rbp-0x08], rax
       cmp      gword ptr [rbp-0x08], 0
       je       SHORT G_M000_IG10
       mov      rax, gword ptr [rbp-0x08]
       mov      gword ptr [rbp-0x30], rax
       mov      rcx, gword ptr [rbp-0x30]
       mov      rdx, 0x7FFA02D867B0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rbp-0x40], rax
       mov      rdx, gword ptr [rbp-0x40]
       mov      rcx, 0x7FFA02C41128
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x016B
       mov      rcx, 0x7FFA02D868B8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG10:                ;; offset=0x017A
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0x10], rax
       cmp      gword ptr [rbp-0x10], 0
       je       SHORT G_M000_IG14
       mov      rcx, gword ptr [rbp-0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x28], eax
       jmp      SHORT G_M000_IG15
 
G_M000_IG11:                ;; offset=0x01A8
       mov      rcx, 0x7FFA02D868BC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG17
 
G_M000_IG12:                ;; offset=0x01B9
       mov      rcx, 0x7FFA02D868C0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG17
 
G_M000_IG13:                ;; offset=0x01CA
       mov      rcx, 0x7FFA02D868C4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG17
 
G_M000_IG14:                ;; offset=0x01DB
       mov      rcx, 0x7FFA02D868C8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x28], eax
 
G_M000_IG15:                ;; offset=0x01EF
       mov      rcx, 0x7FFA02D868CC
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      dword ptr [rbp-0x28], 0
       sete     al
       movzx    rax, al
 
G_M000_IG16:                ;; offset=0x0208
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG17:                ;; offset=0x020E
       mov      rcx, 0x7FFA02D868D0
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG18:                ;; offset=0x021F
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 549

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 704
       lea      rbp, [rsp+0x2C0]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -624
 
G_M000_IG35:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG35
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0045
       cmp      gword ptr [rbp+0x28], 0
       jne      G_M000_IG15
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       jne      SHORT G_M000_IG06
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG03:                ;; offset=0x0075
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1C0], xmm0
 
G_M000_IG04:                ;; offset=0x0081
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x1C0]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x19C], eax
       jmp      G_M000_IG12
 
G_M000_IG05:                ;; offset=0x00B7
       mov      rcx, 0x7FFA02D86D60
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG15
 
G_M000_IG06:                ;; offset=0x00CB
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x198], eax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x198]
       jne      SHORT G_M000_IG11
       mov      rcx, 0x7FFA02D86D64
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG07:                ;; offset=0x0108
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG08:                ;; offset=0x0114
       lea      rdx, [rbp-0x1D0]
       lea      rcx, [rbp-0x1B0]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
 
G_M000_IG09:                ;; offset=0x0128
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
 
G_M000_IG10:                ;; offset=0x0138
       lea      rdx, [rbp-0x1E0]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, bword ptr [rbp+0x60]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x19C], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x0159
       mov      rcx, 0x7FFA02D86D68
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x19C], eax
 
G_M000_IG12:                ;; offset=0x0170
       cmp      dword ptr [rbp-0x19C], 0
       je       SHORT G_M000_IG14
       mov      rcx, 0x7FFA02D86D6C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x58]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x68]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG13:                ;; offset=0x0198
       vzeroupper 
       add      rsp, 704
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x01A4
       mov      rcx, 0x7FFA02D86D70
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG15:                ;; offset=0x01B3
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
       vmovdqu  ymmword ptr [rbp-0xE0], ymm0
       vmovdqu  ymmword ptr [rbp-0xC0], ymm0
       vmovdqu  ymmword ptr [rbp-0xA0], ymm0
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  ymmword ptr [rbp-0x40], ymm0
       vmovdqu  ymmword ptr [rbp-0x20], ymm0
       lea      rdx, [rbp-0x100]
       lea      rcx, [rbp-0x110]
       mov      r8d, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       mov      r9d, dword ptr [rbp-0x1E4]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x110]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       je       G_M000_IG19
       xor      eax, eax
       mov      dword ptr [rbp-0x114], eax
       cmp      gword ptr [rbp+0x28], 0
       je       SHORT G_M000_IG16
       mov      rcx, 0x7FFA02D86D74
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x114]
       mov      dword ptr [rbp-0x194], eax
       mov      eax, dword ptr [rbp-0x114]
       inc      eax
       mov      dword ptr [rbp-0x114], eax
       mov      eax, dword ptr [rbp-0x108]
       cmp      dword ptr [rbp-0x194], eax
       jae      G_M000_IG34
       mov      eax, dword ptr [rbp-0x194]
       shl      rax, 4
       mov      rcx, rax
       add      rcx, bword ptr [rbp-0x110]
       mov      rdx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG16:                ;; offset=0x02B2
       lea      rdx, [rbp-0x190]
       lea      rcx, [rbp-0x110]
       mov      r8d, dword ptr [rbp-0x114]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG17:                ;; offset=0x02CD
       vmovdqu  xmm0, xmmword ptr [rbp-0x190]
       vmovdqu  xmmword ptr [rbp-0x1F8], xmm0
 
G_M000_IG18:                ;; offset=0x02DD
       lea      rdx, [rbp-0x1F8]
       mov      rcx, bword ptr [rbp+0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG25
 
G_M000_IG19:                ;; offset=0x02F3
       mov      rcx, 0x7FFA02D86D78
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x1FC], eax
       mov      r9d, dword ptr [rbp-0x1FC]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x170]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG20:                ;; offset=0x033C
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0x210], xmm0
 
G_M000_IG21:                ;; offset=0x034C
       vmovdqu  xmm0, xmmword ptr [rbp-0x128]
       vmovdqu  xmmword ptr [rbp-0x220], xmm0
 
G_M000_IG22:                ;; offset=0x035C
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG23:                ;; offset=0x0381
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x230], xmm0
 
G_M000_IG24:                ;; offset=0x038D
       lea      rcx, [rbp-0x210]
       lea      rdx, [rbp-0x220]
       lea      rax, [rbp-0x230]
       mov      qword ptr [rsp+0x40], rax
       mov      r9, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG25:                ;; offset=0x03B5
       mov      rcx, 0x7FFA02D86D7C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG26:                ;; offset=0x03C4
       vmovdqu  xmm0, xmmword ptr [rbp-0x110]
       vmovdqu  xmmword ptr [rbp-0x180], xmm0
 
G_M000_IG27:                ;; offset=0x03D4
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
 
G_M000_IG28:                ;; offset=0x03E0
       vmovdqu  xmm0, xmmword ptr [rbp-0x180]
       vmovdqu  xmmword ptr [rbp-0x240], xmm0
 
G_M000_IG29:                ;; offset=0x03F0
       vmovdqu  ymm0, ymmword ptr [rbp-0x160]
       vmovdqu  ymmword ptr [rbp-0x260], ymm0
 
G_M000_IG30:                ;; offset=0x0400
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG31:                ;; offset=0x040C
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x270], xmm0
 
G_M000_IG32:                ;; offset=0x0418
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rax
       lea      rax, [rbp-0x140]
       mov      qword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0x240]
       lea      r8, [rbp-0x260]
       lea      rax, [rbp-0x270]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp+0x38]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG33:                ;; offset=0x0468
       vzeroupper 
       add      rsp, 704
       pop      rbp
       ret      
 
G_M000_IG34:                ;; offset=0x0474
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1146

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 288
       lea      rbp, [rsp+0x120]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -240
 
G_M000_IG39:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG39
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0045
       mov      rcx, bword ptr [rbp+0x48]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG04
       cmp      gword ptr [rbp+0x50], 0
       jne      SHORT G_M000_IG05
       mov      rax, bword ptr [rbp+0x58]
       cmp      gword ptr [rax], 0
       je       SHORT G_M000_IG06
 
G_M000_IG03:                ;; offset=0x0064
       mov      rcx, 0x7FFA02D87970
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x0073
       mov      rcx, gword ptr [rbp+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_DefinitionAnnotationKeys():Lokad.Lython.Runtime.PyDict+RecordKeys:this]
       mov      gword ptr [rbp-0xA0], rax
       mov      rdx, gword ptr [rbp-0xA0]
       mov      rcx, 0x7FFA02CDC4F8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x48], rax
       jmp      SHORT G_M000_IG07
 
G_M000_IG05:                ;; offset=0x00A3
       mov      rcx, 0x7FFA02D87974
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG04
 
G_M000_IG06:                ;; offset=0x00B4
       mov      rcx, 0x7FFA02D87978
       call     CORINFO_HELP_COUNTPROFILE32
       xor      rax, rax
       mov      gword ptr [rbp-0x48], rax
 
G_M000_IG07:                ;; offset=0x00C9
       mov      rax, gword ptr [rbp-0x48]
       mov      gword ptr [rbp-0x08], rax
       cmp      gword ptr [rbp-0x08], 0
       jne      SHORT G_M000_IG08
       xor      eax, eax
       mov      dword ptr [rbp-0x4C], eax
       jmp      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x00DF
       mov      rcx, 0x7FFA02D8797C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:get_PreparedValueCapacity():int:this]
       mov      dword ptr [rbp-0x4C], eax
 
G_M000_IG09:                ;; offset=0x00FB
       mov      eax, dword ptr [rbp-0x4C]
       mov      dword ptr [rbp-0x0C], eax
       cmp      gword ptr [rbp-0x08], 0
       je       SHORT G_M000_IG10
       mov      ecx, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:FunctionAndAnnotationBytes(int):long]
       mov      qword ptr [rbp-0x58], rax
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0117
       mov      rcx, 0x7FFA02D87980
       call     CORINFO_HELP_COUNTPROFILE32
       mov      qword ptr [rbp-0x58], 160
 
G_M000_IG11:                ;; offset=0x012E
       mov      rax, qword ptr [rbp-0x58]
       mov      qword ptr [rbp-0x18], rax
       movzx    rax, byte  ptr [rbp+0x60]
       test     eax, eax
       je       SHORT G_M000_IG12
       mov      rcx, 0x7FFA02D87984
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0x7FFA02A75928
       call     [CORINFO_HELP_GET_NONGCSTATIC_BASE]
       mov      rax, qword ptr [(reloc 0x7ffa0253b0d8)]
       add      rax, qword ptr [rbp-0x18]
       jo       G_M000_IG34
       mov      qword ptr [rbp-0x18], rax
 
G_M000_IG12:                ;; offset=0x0172
       mov      rcx, bword ptr [rbp+0x68]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG13
       mov      rcx, 0x7FFA02D87988
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, qword ptr [rbp-0x18]
       add      rax, 96
       jo       G_M000_IG34
       mov      qword ptr [rbp-0x18], rax
 
G_M000_IG13:                ;; offset=0x01A1
       mov      rcx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x20], rax
       mov      rax, bword ptr [rbp+0x58]
       cmp      gword ptr [rax], 0
       jne      SHORT G_M000_IG14
       mov      rcx, 0x7FFA02D8798C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       mov      r8, gword ptr [rbp+0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Reserve(long,Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG14:                ;; offset=0x01DE
       nop      
 
G_M000_IG15:                ;; offset=0x01DF
       mov      rcx, gword ptr [rbp+0x38]
       mov      rdx, gword ptr [rbp+0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       xor      rax, rax
       mov      gword ptr [rbp-0x28], rax
       mov      rcx, bword ptr [rbp+0x68]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG18
       mov      rcx, 0x7FFA02D87990
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0x7FFA02C97DA0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x90], rax
       mov      rax, bword ptr [rbp+0x68]
       cmp      dword ptr [rax+0x08], 0
       jbe      G_M000_IG31
       mov      rax, bword ptr [rbp+0x68]
       mov      rax, bword ptr [rax]
 
G_M000_IG16:                ;; offset=0x023D
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG17:                ;; offset=0x0249
       lea      rdx, [rbp-0xB0]
       mov      rcx, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:.ctor(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x28], rax
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp+0x20], rax
 
G_M000_IG18:                ;; offset=0x0273
       movzx    rax, byte  ptr [rbp+0x30]
       test     eax, eax
       jne      SHORT G_M000_IG21
       mov      rcx, 0x7FFA02CB7368
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x88], rax
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG19:                ;; offset=0x0295
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
       mov      rcx, qword ptr [rax+0x10]
       mov      qword ptr [rbp-0xB8], rcx
 
G_M000_IG20:                ;; offset=0x02AC
       lea      rax, [rbp-0xC8]
       mov      qword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       mov      r9, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x88]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:.ctor(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults):this]
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x68], rax
       jmp      SHORT G_M000_IG24
 
G_M000_IG21:                ;; offset=0x02DE
       mov      rcx, 0x7FFA02D87994
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0x7FFA02CDC648
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x60], rax
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG22:                ;; offset=0x0304
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
       mov      rcx, qword ptr [rax+0x10]
       mov      qword ptr [rbp-0xD0], rcx
 
G_M000_IG23:                ;; offset=0x031B
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rax
       lea      r9, [rbp-0xE0]
       mov      rdx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.PyGeneratorFunction:.ctor(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.FunctionDefaults,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell]):this]
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x68], rax
 
G_M000_IG24:                ;; offset=0x0345
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x30], rax
       mov      rcx, gword ptr [rbp+0x18]
       mov      rdx, gword ptr [rbp-0x20]
       mov      r8, gword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:ChargeClosureRetention(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan)]
       cmp      gword ptr [rbp-0x08], 0
       je       G_M000_IG28
       mov      rax, bword ptr [rbp+0x58]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x70], rax
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, gword ptr [rbp-0x70]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x70], 0
       jne      SHORT G_M000_IG27
       mov      rax, gword ptr [rbp+0x50]
       mov      gword ptr [rbp-0x38], rax
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x38], 0
       jne      G_M000_IG30
       mov      rcx, 0x7FFA02D87998
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x48]
 
G_M000_IG25:                ;; offset=0x03BA
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xF0], xmm0
 
G_M000_IG26:                ;; offset=0x03C6
       mov      rax, gword ptr [rbp+0x40]
       mov      gword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0xF0]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:CopyAnnotationValues(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object[]:this]
       mov      gword ptr [rbp-0x80], rax
 
G_M000_IG27:                ;; offset=0x03EE
       mov      rcx, 0x7FFA02D8799C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x58]
       movzx    r9, byte  ptr [rax+0x0C]
       mov      rcx, gword ptr [rbp-0x78]
       mov      rdx, gword ptr [rbp-0x80]
       mov      r8, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyFunctionBase:AttachAdmittedAnnotations(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):this]
 
G_M000_IG28:                ;; offset=0x041A
       mov      rcx, gword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Commit(long):this]
       cmp      gword ptr [rbp-0x28], 0
       je       SHORT G_M000_IG29
       mov      rcx, 0x7FFA02D879A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x28]
       mov      byte  ptr [rax+0x29], 1
       mov      rax, bword ptr [rbp+0x68]
       cmp      dword ptr [rax+0x08], 0
       jbe      SHORT G_M000_IG31
       mov      rax, bword ptr [rbp+0x68]
       mov      rcx, bword ptr [rax]
       mov      rdx, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG29:                ;; offset=0x0463
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rbp-0x40], rax
       jmp      SHORT G_M000_IG32
 
G_M000_IG30:                ;; offset=0x046D
       mov      rcx, 0x7FFA02D879A4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG27
 
G_M000_IG31:                ;; offset=0x0481
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG32:                ;; offset=0x0487
       mov      rcx, 0x7FFA02D879AC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
 
G_M000_IG33:                ;; offset=0x049A
       add      rsp, 288
       pop      rbp
       ret      
 
G_M000_IG34:                ;; offset=0x04A3
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG35:                ;; offset=0x04A9
       sub      rsp, 40
 
G_M000_IG36:                ;; offset=0x04AD
       mov      gword ptr [rbp-0x98], rcx
       mov      rax, bword ptr [rbp+0x58]
       cmp      gword ptr [rax], 0
       jne      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x04BE
       mov      rcx, 0x7FFA02D879A8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReleaseReserved(long):this]
 
G_M000_IG38:                ;; offset=0x04DD
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 1251

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:TryReadPreparedDefaultInteger(int,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 144
       lea      rbp, [rsp+0x90]
       xor      eax, eax
       mov      qword ptr [rbp-0x68], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      bword ptr [rbp+0x20], r8
 
G_M000_IG02:                ;; offset=0x0034
       mov      rax, gword ptr [rbp+0x10]
       mov      gword ptr [rbp-0x50], rax
       mov      rcx, gword ptr [rbp-0x50]
       mov      rdx, 0x7FFA02D88568
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rcx, gword ptr [rbp-0x50]
       mov      rax, gword ptr [rbp-0x50]
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x30]Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterLayout():Lokad.Lython.Frontend.FunctionParameterLayout:this
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp+0x18]
       jg       G_M000_IG06
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalCount():int:this]
       mov      ecx, dword ptr [rbp+0x18]
       sub      ecx, eax
       mov      dword ptr [rbp-0x5C], ecx
       mov      r8d, dword ptr [rbp-0x5C]
       lea      rdx, [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:KeywordDefaultAt(int):Lokad.Lython.Frontend.FunctionParameterLayout+KeywordDefault:this]
       lea      rcx, [rbp-0x30]
       call     [Lokad.Lython.Frontend.FunctionParameterLayout+KeywordDefault:get_RecordPosition():int:this]
       mov      dword ptr [rbp-0x1C], eax
       mov      rax, gword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x18]
       test     eax, eax
       jne      SHORT G_M000_IG03
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x58], rax
       mov      rcx, gword ptr [rbp-0x58]
       mov      rdx, 0x7FFA02D88670
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x68], rax
       mov      rdx, gword ptr [rbp-0x68]
       mov      rcx, 0x7FFA026028A8
       call     [CORINFO_HELP_CHKCASTARRAY]
       mov      ecx, dword ptr [rbp-0x1C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG10
       mov      edx, ecx
       lea      rax, bword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x48], rax
       jmp      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0112
       mov      rcx, 0x7FFA02D88778
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x48], rax
 
G_M000_IG04:                ;; offset=0x012D
       mov      rcx, 0x7FFA02D8877C
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      rcx, [rbp-0x40]
       mov      rdx, bword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
       nop      
 
G_M000_IG05:                ;; offset=0x0159
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x0162
       lea      r8, [rbp-0x18]
       mov      rcx, gword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG08
       mov      rcx, 0x7FFA02D88780
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x18]
       mov      rdx, bword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
       nop      
 
G_M000_IG07:                ;; offset=0x0195
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x019E
       mov      rcx, 0x7FFA02D88784
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       xor      eax, eax
 
G_M000_IG09:                ;; offset=0x01B8
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x01C1
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 455

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 144
       lea      rbp, [rsp+0x90]
       xor      eax, eax
       mov      qword ptr [rbp-0x68], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
 
G_M000_IG02:                ;; offset=0x0030
       mov      rax, gword ptr [rbp+0x10]
       mov      gword ptr [rbp-0x48], rax
       mov      rcx, gword ptr [rbp-0x48]
       mov      rdx, 0x7FFA02D89048
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rcx, gword ptr [rbp-0x48]
       mov      rax, gword ptr [rbp-0x48]
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x30]Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterLayout():Lokad.Lython.Frontend.FunctionParameterLayout:this
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_KeywordOnlyCount():int:this]
       test     eax, eax
       je       G_M000_IG06
       mov      rax, gword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x18]
       test     eax, eax
       jne      SHORT G_M000_IG04
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x50], rax
       mov      rcx, gword ptr [rbp-0x50]
       mov      rdx, 0x7FFA02D89150
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x60], rax
       mov      rdx, gword ptr [rbp-0x60]
       mov      rcx, 0x7FFA026028A8
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       je       G_M000_IG08
 
G_M000_IG03:                ;; offset=0x00C5
       mov      rcx, 0x7FFA02D89258
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00D4
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_Defaults():Lokad.Lython.Frontend.FunctionParameterLayout+DefaultSlot[]:this]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x38], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalDefaultCount():int:this]
       mov      ecx, dword ptr [rbp-0x38]
       sub      ecx, eax
       mov      dword ptr [rbp-0x3C], ecx
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_KeywordOnlyCount():int:this]
       cmp      eax, dword ptr [rbp-0x3C]
       jne      G_M000_IG07
 
G_M000_IG05:                ;; offset=0x010F
       mov      rcx, 0x7FFA02D8925C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG06:                ;; offset=0x011E
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp+0x18]
       jl       G_M000_IG12
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalCount():int:this]
       mov      dword ptr [rbp-0x0C], eax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalDefaults():System.Object:this]
       mov      gword ptr [rbp-0x58], rax
       mov      rcx, gword ptr [rbp-0x58]
       mov      rdx, 0x7FFA02D89260
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x68], rax
       mov      rdx, gword ptr [rbp-0x68]
       mov      rcx, 0x7FFA02C41128
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x18], rax
       mov      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x1C], eax
       mov      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x20], eax
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x28], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG09
       mov      eax, dword ptr [rbp-0x1C]
       mov      dword ptr [rbp-0x2C], eax
       mov      eax, dword ptr [rbp-0x20]
       mov      dword ptr [rbp-0x30], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x34], eax
       jmp      SHORT G_M000_IG10
 
G_M000_IG07:                ;; offset=0x01B1
       mov      rcx, 0x7FFA02D89368
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG12
 
G_M000_IG08:                ;; offset=0x01C2
       mov      rcx, 0x7FFA02D8936C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG12
 
G_M000_IG09:                ;; offset=0x01D3
       mov      rcx, 0x7FFA02D89370
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x1C]
       mov      dword ptr [rbp-0x2C], eax
       mov      eax, dword ptr [rbp-0x20]
       mov      dword ptr [rbp-0x30], eax
       mov      rcx, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.PyTuple:get_Count():int:this]
       mov      dword ptr [rbp-0x34], eax
 
G_M000_IG10:                ;; offset=0x01FB
       mov      rcx, 0x7FFA02D89374
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x30]
       sub      eax, dword ptr [rbp-0x34]
       cmp      dword ptr [rbp-0x2C], eax
       setge    al
       movzx    rax, al
 
G_M000_IG11:                ;; offset=0x0219
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG12:                ;; offset=0x0222
       mov      rcx, 0x7FFA02D89378
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG13:                ;; offset=0x0233
       add      rsp, 144
       pop      rbp
       ret      
 
; Total bytes of code 572

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 24299
; 8 inlinees with PGO data; 35 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbx
       sub      rsp, 32
       mov      rbx, rcx
 
G_M000_IG02:                ;; offset=0x0008
       mov      byte  ptr [r9], 0
       mov      rcx, gword ptr [rbx+0x38]
       cmp      byte  ptr [rcx+0xE6], 0
       je       G_M000_IG11
       mov      rax, gword ptr [rbx+0x20]
       cmp      byte  ptr [rax+0xFA], 0
       jne      G_M000_IG11
       cmp      byte  ptr [rax+0xFB], 0
       jne      G_M000_IG11
       cmp      byte  ptr [rax+0xFC], 0
       jne      G_M000_IG11
       cmp      gword ptr [rax+0xC0], 0
       jne      G_M000_IG11
       cmp      dword ptr [rcx+0xDC], 16
       jg       G_M000_IG11
       cmp      byte  ptr [rdx+0x34], 0
       je       G_M000_IG13
       mov      edx, dword ptr [rdx+0x28]
       mov      rcx, gword ptr [rcx+0xB0]
       cmp      byte  ptr [rcx+0x54], 0
       je       SHORT G_M000_IG07
 
G_M000_IG03:                ;; offset=0x007D
       mov      ecx, dword ptr [rcx+0x3C]
       test     r8, r8
       setne    al
       movzx    rax, al
       sub      ecx, eax
       cmp      ecx, edx
       sete     dl
       movzx    rdx, dl
 
G_M000_IG04:                ;; offset=0x0093
       mov      byte  ptr [r9], dl
       cmp      byte  ptr [r9], 0
       je       SHORT G_M000_IG08
 
G_M000_IG05:                ;; offset=0x009C
       mov      eax, 1
 
G_M000_IG06:                ;; offset=0x00A1
       add      rsp, 32
       pop      rbx
       ret      
 
G_M000_IG07:                ;; offset=0x00A7
       xor      edx, edx
       jmp      SHORT G_M000_IG04
 
G_M000_IG08:                ;; offset=0x00AB
       mov      rdx, gword ptr [rbx+0x38]
       mov      rdx, gword ptr [rdx+0xB0]
       mov      rcx, gword ptr [rdx+0x08]
       cmp      dword ptr [rcx+0x08], 16
       jg       SHORT G_M000_IG11
       cmp      dword ptr [rdx+0x4C], 0
       jge      SHORT G_M000_IG11
       cmp      dword ptr [rdx+0x50], 0
       jge      SHORT G_M000_IG11
       mov      rdx, gword ptr [rbx+0x10]
       test     rdx, rdx
       je       SHORT G_M000_IG10
       mov      rax, rdx
       mov      rcx, 0x7FFA02CEEAD8
       cmp      qword ptr [rax], rcx
       jne      SHORT G_M000_IG14
 
G_M000_IG09:                ;; offset=0x00E7
       test     rax, rax
       je       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00EC
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       test     rax, rax
       je       SHORT G_M000_IG05
       jmp      SHORT G_M000_IG15
 
G_M000_IG11:                ;; offset=0x00FC
       xor      eax, eax
 
G_M000_IG12:                ;; offset=0x00FE
       add      rsp, 32
       pop      rbx
       ret      
 
G_M000_IG13:                ;; offset=0x0104
       xor      edx, edx
       jmp      SHORT G_M000_IG04
 
G_M000_IG14:                ;; offset=0x0108
       mov      rcx, 0x7FFA02C41128
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       jmp      SHORT G_M000_IG09
 
G_M000_IG15:                ;; offset=0x0119
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       jne      G_M000_IG05
       jmp      SHORT G_M000_IG11
 
; Total bytes of code 300

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 26232
; 9 inlinees with PGO data; 28 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 504
       lea      rbp, [rsp+0x230]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x1D0], xmm4
       mov      rax, -384
 
G_M000_IG22:                ;; offset=0x0031
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG22
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r9
       mov      r15, bword ptr [rbp+0x50]
       mov      r14, bword ptr [rbp+0x60]
 
G_M000_IG02:                ;; offset=0x005E
       mov      r13, bword ptr [r8]
       mov      r12d, dword ptr [r8+0x08]
       test     rsi, rsi
       jne      SHORT G_M000_IG03
       mov      rcx, gword ptr [rbx+0x38]
       cmp      byte  ptr [rcx+0xE7], 0
       jne      G_M000_IG08
 
G_M000_IG03:                ;; offset=0x007B
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x138], ymm0
       vmovdqu  ymmword ptr [rbp-0x118], ymm0
       vmovdqu  ymmword ptr [rbp-0xF8], ymm0
       vmovdqu  ymmword ptr [rbp-0xD8], ymm0
       vmovdqu  ymmword ptr [rbp-0xB8], ymm0
       vmovdqu  ymmword ptr [rbp-0x98], ymm0
       vmovdqu  ymmword ptr [rbp-0x78], ymm0
       vmovdqu  ymmword ptr [rbp-0x58], ymm0
       mov      rcx, gword ptr [rbx+0x38]
       mov      eax, dword ptr [rcx+0xDC]
       mov      dword ptr [rbp-0x18C], eax
       cmp      eax, 16
       ja       G_M000_IG14
       cmp      byte  ptr [rbp+0x48], 0
       je       G_M000_IG19
       xor      ecx, ecx
       test     rsi, rsi
       jne      G_M000_IG15
 
G_M000_IG04:                ;; offset=0x00E7
       cmp      ecx, eax
       ja       G_M000_IG14
       lea      rdx, bword ptr [rbp-0x138]
       mov      r8d, ecx
       shl      r8, 4
       add      r8, rdx
       mov      edx, eax
       sub      edx, ecx
       cmp      r12d, edx
       ja       G_M000_IG18
       mov      ecx, r12d
       shl      rcx, 4
       mov      r10, rcx
       cmp      r10, 0x4000
       ja       G_M000_IG17
       mov      rcx, r8
       mov      rdx, r13
       mov      r8, r10
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa62542aa8)], 0
       jne      G_M000_IG16
 
G_M000_IG05:                ;; offset=0x013F
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x170], ymm0
       lea      rdx, bword ptr [rbp-0x138]
       mov      bword ptr [rbp-0x1B0], rdx
       mov      esi, dword ptr [rbp-0x18C]
       mov      dword ptr [rbp-0x1A8], esi
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      bword ptr [rsp+0x28], r15
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rsi
       mov      bword ptr [rsp+0x38], r14
       mov      r14, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], r14
       lea      rdx, [rbp-0x150]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x1B0]
       lea      r8, [rbp-0x170]
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
 
G_M000_IG06:                ;; offset=0x01B0
       nop      
 
G_M000_IG07:                ;; offset=0x01B1
       add      rsp, 504
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x01C5
       cmp      byte  ptr [rbp+0x48], 0
       jne      G_M000_IG13
       xor      ecx, ecx
       mov      qword ptr [r14], rcx
       mov      qword ptr [r14+0x08], rcx
       cmp      byte  ptr [rdi+0x34], 0
       je       G_M000_IG11
       mov      rcx, gword ptr [rbx+0x38]
       mov      rdx, gword ptr [rcx+0xB0]
       mov      rdx, gword ptr [rdx+0x08]
       mov      edx, dword ptr [rdx+0x08]
       cmp      edx, dword ptr [rcx+0xCC]
       jne      SHORT G_M000_IG11
       mov      rcx, rbx
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG11
       mov      rax, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [rax+0x98]
       mov      gword ptr [rbp-0x1D8], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG12
 
G_M000_IG09:                ;; offset=0x022D
       mov      gword ptr [rbp-0x188], rbx
       mov      bword ptr [rbp-0x180], r13
       mov      dword ptr [rbp-0x178], r12d
       lea      rdx, [rbp-0x188]
       mov      rcx, rbx
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
 
G_M000_IG10:                ;; offset=0x0259
       test     eax, eax
       je       G_M000_IG03
       mov      r14, bword ptr [rbp+0x58]
       mov      byte  ptr [r14], 0
       xor      rcx, rcx
       mov      r14, bword ptr [rbp+0x68]
       mov      gword ptr [r14], rcx
       jmp      G_M000_IG06
 
G_M000_IG11:                ;; offset=0x0277
       xor      edx, edx
       mov      eax, edx
       jmp      SHORT G_M000_IG10
 
G_M000_IG12:                ;; offset=0x027D
       mov      rcx, gword ptr [rbp-0x1D8]
       mov      rdx, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      SHORT G_M000_IG09
 
G_M000_IG13:                ;; offset=0x0290
       mov      rdx, gword ptr [rbx+0x38]
       cmp      r12d, dword ptr [rdx+0xCC]
       jne      G_M000_IG03
       mov      bword ptr [rbp-0x1A0], r13
       mov      dword ptr [rbp-0x198], r12d
       lea      rdx, [rbp-0x1A0]
       mov      rcx, rbx
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      SHORT G_M000_IG10
 
G_M000_IG14:                ;; offset=0x02C8
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG15:                ;; offset=0x02CF
       mov      ecx, 1
       test     eax, eax
       je       G_M000_IG21
       mov      gword ptr [rbp-0x138], rsi
       xor      edx, edx
       mov      qword ptr [rbp-0x130], rdx
       jmp      G_M000_IG04
 
G_M000_IG16:                ;; offset=0x02F1
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG05
 
G_M000_IG17:                ;; offset=0x02FB
       mov      rcx, r8
       mov      rdx, r13
       mov      r8, r10
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG05
 
G_M000_IG18:                ;; offset=0x030F
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG19:                ;; offset=0x0316
       mov      rcx, gword ptr [rbx+0x38]
       mov      rcx, gword ptr [rcx+0xB0]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      ecx, eax
       ja       SHORT G_M000_IG14
       lea      rdx, bword ptr [rbp-0x138]
       mov      bword ptr [rbp-0x1B0], rdx
       mov      dword ptr [rbp-0x1A8], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x1C0], rcx
 
G_M000_IG20:                ;; offset=0x0349
       mov      dword ptr [rbp-0x1B8], ecx
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], rsi
       mov      gword ptr [rsp+0x38], rdi
       mov      bword ptr [rbp-0x1D0], r13
       mov      dword ptr [rbp-0x1C8], r12d
       lea      rcx, [rbp-0x1B0]
       lea      rdx, [rbp-0x1C0]
       lea      r9, [rbp-0x1D0]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, rbx
       mov      r8, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
       jmp      G_M000_IG05
 
G_M000_IG21:                ;; offset=0x03A2
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 936

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 79760
; 8 inlinees with PGO data; 36 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 168
       lea      rbp, [rsp+0xE0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  xmmword ptr [rbp-0x68], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x58], rax
       mov      rdi, rcx
       mov      rsi, rdx
       mov      r14, r8
       mov      rbx, r9
       mov      r15, gword ptr [rbp+0x38]
       mov      r12, gword ptr [rbp+0x40]
       mov      r13, bword ptr [rbp+0x48]
       mov      rdx, gword ptr [rbp+0x50]
       mov      rcx, bword ptr [rbp+0x58]
       mov      rax, bword ptr [rbp+0x68]
 
G_M000_IG02:                ;; offset=0x004E
       mov      r8, bword ptr [rax]
       mov      bword ptr [rbp-0xA8], r8
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x70], eax
       mov      r10, gword ptr [rcx]
       mov      gword ptr [rbp-0xA0], r10
       movzx    r9, byte  ptr [rcx+0x0C]
       mov      byte  ptr [rbp-0x6C], r9b
       cmp      dword ptr [r13+0x08], 0
       jne      SHORT G_M000_IG06
 
G_M000_IG03:                ;; offset=0x0078
       mov      gword ptr [rbp+0x50], rdx
       mov      rcx, rdx
       or       rcx, r10
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0084
       xor      r11, r11
       mov      rdx, gword ptr [rbp+0x50]
       mov      r10, gword ptr [rbp-0xA0]
       jmp      SHORT G_M000_IG07
 
G_M000_IG05:                ;; offset=0x0094
       mov      rdx, gword ptr [rbp+0x50]
       mov      r10, gword ptr [rbp-0xA0]
 
G_M000_IG06:                ;; offset=0x009F
       mov      r11, gword ptr [rdi+0x08]
       test     r11, r11
       je       G_M000_IG42
 
G_M000_IG07:                ;; offset=0x00AC
       test     r11, r11
       je       G_M000_IG41
 
G_M000_IG08:                ;; offset=0x00B5
       mov      gword ptr [rbp+0x50], rdx
       mov      gword ptr [rbp-0x88], r11
       mov      ecx, dword ptr [r11+0x20]
       call     [Lokad.Lython.Runtime.PyDict:NativeCapacity(int):int]
       mov      dword ptr [rbp-0x44], eax
       mov      ecx, eax
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:RecordBytes(int):long]
       add      rax, 160
       jo       G_M000_IG44
 
G_M000_IG09:                ;; offset=0x00E1
       mov      qword ptr [rbp-0x50], rax
       mov      qword ptr [rbp-0x40], rax
       cmp      byte  ptr [rbp+0x60], 0
       jne      G_M000_IG43
 
G_M000_IG10:                ;; offset=0x00F3
       cmp      dword ptr [rbp-0x70], 0
       je       SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x00F9
       mov      rcx, qword ptr [rbp-0x40]
       add      rcx, 96
       jo       G_M000_IG44
       mov      qword ptr [rbp-0x40], rcx
 
G_M000_IG12:                ;; offset=0x010B
       mov      rcx, gword ptr [r15+0x98]
       mov      rcx, gword ptr [rcx+0x88]
       mov      gword ptr [rbp-0x78], rcx
       cmp      gword ptr [rbp-0xA0], 0
       jne      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x0127
       mov      rcx, gword ptr [rbp-0x78]
       mov      rdx, qword ptr [rbp-0x40]
       mov      r8, r12
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Reserve(long,Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG14:                ;; offset=0x013B
       mov      rcx, gword ptr [r15+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG31
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG30
 
G_M000_IG15:                ;; offset=0x0164
       xor      rdx, rdx
       cmp      dword ptr [rbp-0x70], 0
       je       SHORT G_M000_IG22
 
G_M000_IG16:                ;; offset=0x016C
       mov      rcx, 0x7FFA02C97DA0
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
 
G_M000_IG17:                ;; offset=0x017E
       mov      rax, bword ptr [rbp-0xA8]
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x60], xmm0
 
G_M000_IG18:                ;; offset=0x018E
       mov      rcx, gword ptr [rbp-0x60]
       mov      rdx, 0x1658DC01C18
       cmp      rcx, gword ptr [rdx]
       jne      G_M000_IG34
       mov      rcx, gword ptr [r14+0x10]
       mov      rdx, rcx
       test     rdx, rdx
       jne      G_M000_IG32
 
G_M000_IG19:                ;; offset=0x01B5
       test     rcx, rcx
       jne      G_M000_IG33
 
G_M000_IG20:                ;; offset=0x01BE
       mov      rcx, qword ptr [rbp-0x58]
       mov      qword ptr [rbp-0x68], rcx
       mov      qword ptr [r14+0x20], rcx
       mov      byte  ptr [r14+0x28], 1
       xor      rcx, rcx
       mov      gword ptr [r14+0x08], rcx
 
G_M000_IG21:                ;; offset=0x01D5
       mov      gword ptr [rbp-0x80], r14
       mov      rdx, r14
       mov      r14, rdx
       mov      rdx, gword ptr [rbp-0x80]
 
G_M000_IG22:                ;; offset=0x01E3
       cmp      byte  ptr [rbp+0x30], 0
       jne      G_M000_IG37
       mov      gword ptr [rbp-0x80], rdx
       mov      rcx, 0x7FFA02CB7368
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x98], rax
       mov      rdx, gword ptr [rbx]
       mov      r8, gword ptr [rbx+0x08]
       mov      gword ptr [rbp-0xB0], r8
       movzx    rbx, byte  ptr [rbx+0x10]
       lea      rcx, bword ptr [rax+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x98]
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, gword ptr [rbp-0xB0]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x98]
       mov      byte  ptr [rax+0x18], bl
       lea      rcx, bword ptr [rax+0x38]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       mov      rbx, gword ptr [rbp-0x98]
       lea      rcx, bword ptr [rbx+0x20]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rbx+0x48]
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG23:                ;; offset=0x026E
       mov      rcx, rsi
       mov      rdx, gword ptr [rbp-0x78]
       mov      r8, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:ChargeClosureRetention(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan)]
       mov      rsi, gword ptr [rbp-0x88]
       test     rsi, rsi
       je       SHORT G_M000_IG27
 
G_M000_IG24:                ;; offset=0x028A
       mov      r10, gword ptr [rbp-0xA0]
       mov      rdx, r10
       test     rdx, rdx
       jne      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x0299
       mov      rdi, gword ptr [rbp+0x50]
       mov      rdx, rdi
       test     rdx, rdx
       je       G_M000_IG38
 
G_M000_IG26:                ;; offset=0x02A9
       lea      rcx, bword ptr [rbx+0x30]
       call     CORINFO_HELP_ASSIGN_REF
       movzx    rsi, byte  ptr [rbp-0x6C]
       mov      byte  ptr [rbx+0x1B], sil
 
G_M000_IG27:                ;; offset=0x02BB
       mov      rdx, gword ptr [rbp-0x78]
       cmp      byte  ptr [rdx], dl
       cmp      qword ptr [rbp-0x40], 0
       jle      SHORT G_M000_IG28
       mov      rcx, qword ptr [rdx+0x28]
       mov      rax, rcx
       cmp      qword ptr [rbp-0x40], rax
       cmovle   rax, qword ptr [rbp-0x40]
       sub      rcx, rax
       mov      qword ptr [rdx+0x28], rcx
       add      rax, qword ptr [rdx+0x30]
       jo       G_M000_IG35
       mov      qword ptr [rdx+0x30], rax
       mov      rdx, gword ptr [rbp-0x78]
 
G_M000_IG28:                ;; offset=0x02F1
       mov      r14, gword ptr [rbp-0x80]
       test     r14, r14
       je       G_M000_IG39
 
G_M000_IG29:                ;; offset=0x02FE
       mov      byte  ptr [r14+0x29], 1
       cmp      dword ptr [rbp-0x70], 0
       jbe      G_M000_IG36
       mov      rcx, bword ptr [rbp-0xA8]
       mov      rdx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      rsi, bword ptr [rbp-0xA8]
       mov      qword ptr [rsi+0x08], rcx
       jmp      G_M000_IG39
 
G_M000_IG30:                ;; offset=0x032E
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG15
 
G_M000_IG31:                ;; offset=0x0340
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG15
 
G_M000_IG32:                ;; offset=0x034E
       cmp      byte  ptr [rdx+0x101], 0
       jne      SHORT G_M000_IG34
       jmp      G_M000_IG19
 
G_M000_IG33:                ;; offset=0x035C
       movzx    rcx, byte  ptr [rcx+0xFF]
       test     ecx, ecx
       je       G_M000_IG20
 
G_M000_IG34:                ;; offset=0x036B
       lea      rcx, [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG21
 
G_M000_IG35:                ;; offset=0x0386
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG36:                ;; offset=0x038C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG37:                ;; offset=0x0392
       mov      gword ptr [rbp-0x80], rdx
       mov      rcx, 0x7FFA02CDC648
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x90], rax
       mov      gword ptr [rsp+0x20], r14
       mov      rcx, rax
       mov      rdx, rdi
       mov      r8, rsi
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.PyGeneratorFunction:.ctor(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.FunctionDefaults,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell]):this]
       mov      rbx, gword ptr [rbp-0x90]
       jmp      G_M000_IG23
 
G_M000_IG38:                ;; offset=0x03CF
       mov      gword ptr [rsp+0x20], r12
       mov      rcx, rsi
       mov      rdx, r13
       mov      r8d, dword ptr [rbp-0x44]
       mov      r9, r15
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:CopyAnnotationValues(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object[]:this]
       mov      rdx, rax
       jmp      G_M000_IG26
 
G_M000_IG39:                ;; offset=0x03EF
       mov      rax, rbx
 
G_M000_IG40:                ;; offset=0x03F2
       add      rsp, 168
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG41:                ;; offset=0x0406
       xor      ecx, ecx
       mov      dword ptr [rbp-0x44], ecx
       mov      ecx, 160
       mov      gword ptr [rbp-0x88], r11
       mov      gword ptr [rbp+0x50], rdx
       mov      rax, rcx
       jmp      G_M000_IG09
 
G_M000_IG42:                ;; offset=0x0423
       mov      rcx, 0x7FFA0276A220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x185B47D9E98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG43:                ;; offset=0x0451
       mov      rcx, 0x7FFA02A75928
       call     [CORINFO_HELP_GET_NONGCSTATIC_BASE]
       mov      rcx, qword ptr [rbp-0x50]
       add      rcx, qword ptr [(reloc 0x7ffa0253b0d8)]
       jo       SHORT G_M000_IG44
       mov      qword ptr [rbp-0x40], rcx
       jmp      G_M000_IG10
 
G_M000_IG44:                ;; offset=0x0477
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG45:                ;; offset=0x047D
       sub      rsp, 40
 
G_M000_IG46:                ;; offset=0x0481
       cmp      gword ptr [rbp-0xA0], 0
       jne      SHORT G_M000_IG47
       mov      rcx, gword ptr [rbp-0x78]
       mov      rdx, qword ptr [rbp-0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReleaseReserved(long):this]
 
G_M000_IG47:                ;; offset=0x049B
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 1185

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:TryReadPreparedDefaultInteger(int,byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 17286
; 2 inlinees with PGO data; 8 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 56
       xor      eax, eax
       mov      qword ptr [rsp+0x28], rax
       mov      qword ptr [rsp+0x30], rax
       mov      rbx, rcx
       mov      esi, edx
       mov      rdi, r8
 
G_M000_IG02:                ;; offset=0x001C
       mov      rcx, 0x7FFA02CB7368
       cmp      qword ptr [rbx], rcx
       jne      G_M000_IG20
       mov      rcx, gword ptr [rbx+0x38]
       mov      rbp, gword ptr [rcx+0xB0]
 
G_M000_IG03:                ;; offset=0x003A
       mov      edx, dword ptr [rbp+0x3C]
       cmp      esi, edx
       jl       SHORT G_M000_IG11
 
G_M000_IG04:                ;; offset=0x0041
       mov      rcx, gword ptr [rbp+0x18]
       sub      esi, edx
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG28
       mov      edx, esi
       shl      rdx, 4
       mov      esi, dword ptr [rcx+rdx+0x18]
       cmp      byte  ptr [rbx+0x18], 0
       je       G_M000_IG21
 
G_M000_IG05:                ;; offset=0x0064
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG06:                ;; offset=0x0068
       mov      rdx, 0x1658DC01C18
       cmp      rcx, gword ptr [rdx]
       je       SHORT G_M000_IG10
 
G_M000_IG07:                ;; offset=0x0077
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
 
G_M000_IG08:                ;; offset=0x0080
       nop      
 
G_M000_IG09:                ;; offset=0x0081
       add      rsp, 56
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       ret      
 
G_M000_IG10:                ;; offset=0x008A
       xor      eax, eax
       mov      qword ptr [rdi], rax
       mov      eax, 1
       jmp      SHORT G_M000_IG08
 
G_M000_IG11:                ;; offset=0x0096
       lea      r8, [rsp+0x28]
       mov      rcx, rbx
       mov      edx, esi
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG26
       mov      rdx, gword ptr [rsp+0x28]
       mov      rcx, 0x1658DC01C18
       cmp      rdx, gword ptr [rcx]
       je       SHORT G_M000_IG19
 
G_M000_IG12:                ;; offset=0x00C2
       cmp      qword ptr [rsp+0x30], 0
       jg       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x00CA
       mov      rcx, gword ptr [rsp+0x28]
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
 
G_M000_IG14:                ;; offset=0x00D8
       nop      
 
G_M000_IG15:                ;; offset=0x00D9
       add      rsp, 56
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       ret      
 
G_M000_IG16:                ;; offset=0x00E2
       mov      rdx, gword ptr [rsp+0x28]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x00EF
       mov      rax, 0x7FFA02CEEAD8
       cmp      qword ptr [rcx], rax
       jne      SHORT G_M000_IG25
 
G_M000_IG18:                ;; offset=0x00FE
       test     rcx, rcx
       je       SHORT G_M000_IG13
       mov      edx, dword ptr [rsp+0x30]
       dec      edx
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.PyTuple:TryReadInteger(int,byref):bool:this]
       jmp      SHORT G_M000_IG14
 
G_M000_IG19:                ;; offset=0x0114
       mov      rax, qword ptr [rsp+0x30]
       mov      qword ptr [rdi], rax
       mov      eax, 1
       jmp      SHORT G_M000_IG14
 
G_M000_IG20:                ;; offset=0x0123
       mov      rcx, rbx
       mov      rax, qword ptr [rbx]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x30]Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterLayout():Lokad.Lython.Frontend.FunctionParameterLayout:this
       mov      rbp, rax
       jmp      G_M000_IG03
 
G_M000_IG21:                ;; offset=0x0138
       mov      rdx, gword ptr [rbx+0x08]
       mov      rbx, rdx
       test     rbx, rbx
       je       SHORT G_M000_IG24
 
G_M000_IG22:                ;; offset=0x0144
       mov      rcx, 0x7FFA026028A8
       cmp      qword ptr [rbx], rcx
       je       SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x0153
       call     [CORINFO_HELP_CHKCASTARRAY]
       mov      rbx, rax
 
G_M000_IG24:                ;; offset=0x015C
       cmp      esi, dword ptr [rbx+0x08]
       jae      SHORT G_M000_IG28
       mov      ecx, esi
       mov      rcx, gword ptr [rbx+8*rcx+0x10]
       jmp      G_M000_IG06
 
G_M000_IG25:                ;; offset=0x016D
       mov      rcx, 0x7FFA02C41128
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rcx, rax
       jmp      G_M000_IG18
 
G_M000_IG26:                ;; offset=0x0184
       xor      eax, eax
       mov      qword ptr [rdi], rax
 
G_M000_IG27:                ;; offset=0x0189
       add      rsp, 56
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       ret      
 
G_M000_IG28:                ;; offset=0x0192
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 408

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Dynamic PGO
; rsp based frame
; partially interruptible
; with Dynamic PGO: fgCalledCount is 39352
; 1 inlinees with PGO data; 11 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 40
       mov      rbx, rcx
       mov      esi, edx
 
G_M000_IG02:                ;; offset=0x000D
       mov      rcx, 0x7FFA02CB7368
       cmp      qword ptr [rbx], rcx
       jne      SHORT G_M000_IG13
       mov      rcx, gword ptr [rbx+0x38]
       mov      rdi, gword ptr [rcx+0xB0]
 
G_M000_IG03:                ;; offset=0x0027
       mov      ebp, dword ptr [rdi+0x40]
       test     ebp, ebp
       je       SHORT G_M000_IG06
 
G_M000_IG04:                ;; offset=0x002E
       cmp      byte  ptr [rbx+0x18], 0
       je       SHORT G_M000_IG14
 
G_M000_IG05:                ;; offset=0x0034
       mov      rdx, gword ptr [rdi+0x28]
       mov      edx, dword ptr [rdx+0x08]
       sub      edx, dword ptr [rdi+0x38]
       cmp      edx, ebp
       jne      G_M000_IG17
 
G_M000_IG06:                ;; offset=0x0046
       mov      edi, dword ptr [rdi+0x3C]
       cmp      esi, edi
       jg       G_M000_IG17
       mov      rdx, gword ptr [rbx+0x10]
       mov      rbx, rdx
       test     rbx, rbx
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x005D
       mov      rcx, 0x7FFA02CEEAD8
       cmp      qword ptr [rbx], rcx
       jne      SHORT G_M000_IG15
 
G_M000_IG08:                ;; offset=0x006C
       test     rbx, rbx
       je       SHORT G_M000_IG12
 
G_M000_IG09:                ;; offset=0x0071
       mov      rax, gword ptr [rbx+0x08]
       test     rax, rax
       jne      SHORT G_M000_IG16
       mov      ecx, 1
 
G_M000_IG10:                ;; offset=0x007F
       sub      edi, ecx
       cmp      edi, esi
       setle    al
       movzx    rax, al
 
G_M000_IG11:                ;; offset=0x0089
       add      rsp, 40
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       ret      
 
G_M000_IG12:                ;; offset=0x0092
       xor      ecx, ecx
       jmp      SHORT G_M000_IG10
 
G_M000_IG13:                ;; offset=0x0096
       mov      rcx, rbx
       mov      rax, qword ptr [rbx]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x30]Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterLayout():Lokad.Lython.Frontend.FunctionParameterLayout:this
       mov      rdi, rax
       jmp      G_M000_IG03
 
G_M000_IG14:                ;; offset=0x00AB
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, 0x7FFA026028A8
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       je       SHORT G_M000_IG17
       jmp      G_M000_IG05
 
G_M000_IG15:                ;; offset=0x00C8
       mov      rcx, 0x7FFA02C41128
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbx, rax
       jmp      SHORT G_M000_IG08
 
G_M000_IG16:                ;; offset=0x00DC
       mov      ecx, dword ptr [rax+0x08]
       test     ecx, ecx
       jl       SHORT G_M000_IG19
       jmp      SHORT G_M000_IG10
 
G_M000_IG17:                ;; offset=0x00E5
       xor      eax, eax
 
G_M000_IG18:                ;; offset=0x00E7
       add      rsp, 40
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       ret      
 
G_M000_IG19:                ;; offset=0x00F0
       call     CORINFO_HELP_OVERFLOW
       int3     
 
; Total bytes of code 246

