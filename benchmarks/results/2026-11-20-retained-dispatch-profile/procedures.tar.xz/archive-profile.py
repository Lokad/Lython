from pathlib import Path
import gzip
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
out = Path('benchmarks/results/2026-11-20-retained-dispatch-profile')
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
term = read(lab / 'terminal-status.json')
receipt = read(lab / 'archive-receipt.json')
assert term['receipt'] == receipt and term['exitCode'] == '0' and term['live'] is False
assert not term['remainingWorkers'] and not term['remainingTrace']
assert all(receipt[name] for name in ('complete','quietBeforeAndAfter','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert sha(lab / 'observations.tgz') == receipt['archiveSHA256']
identity = read(lab / 'identity.json')
assert identity['sourceRevision'].startswith('f1593aaf5') and identity['catalogSHA256'] == sha(lab / 'catalog.json')
files = identity['imageFiles']['candidate']
assert len(files) == 32 and {name: sha(lab / 'candidate' / name) for name in files} == files
verified = read(lab / 'verify.json')
assert verified['state'] == 'Completed' and verified['catalogSha256'] == identity['catalogSHA256']
rows = read(lab / 'attribution.json')['rows']
assert len(rows) == 4
for row in rows:
    run = read(lab / 'retrieved' / 'profiles' / row['label'] / 'record.json')
    assert run['exitCode'] == 0 and run['closed']['status'] == 'Closed' and run['warmupSeconds'] >= 8
    assert row['sampleCount'] > 500
    libraries = {Path(lib['path']).name: lib['sha256'].lower() for lib in run['identity']['libraries']}
    assert libraries['Lokad.Lython.dll'] == files['Lokad.Lython.dll']
    assert all(libraries[name] == files[name] for name in libraries.keys() & files.keys())
    case = next(case for case in read(lab / 'catalog.json')['cases'] if case['id'] == row['case'])
    for check in ('verificationBefore','response','verificationAfter'):
        assert run[check]['actualOutputSha256'] == case['expectedOutputSha256']
        assert run[check].get('actualFilesSha256') == case.get('expectedFilesSha256')

for name in ('attribution.json', 'archive-receipt.json', 'terminal-status.json', 'observations.tgz'):
    shutil.copyfile(lab / name, out / name)
(out / 'measured-core.dll.gz').write_bytes(gzip.compress((lab / 'candidate' / 'Lokad.Lython.dll').read_bytes(), mtime=0))
with tarfile.open(out / 'procedures.tar.xz', 'w:xz', preset=6) as archive:
    for name in ('identity.json','config.json','catalog.json','quiet-space.json','prepare.py','prepare.log','verify.json','verify.log',
                 'analyze.py','analysis.log','archive-profile.py','build.log','launch.py','launch.log','ops-profile.py','prove-quiet-space.py',
                 'collect.py','run.sh','retrieve.py','remote-launch.py','observe-not-before.json'):
        archive.add(lab / name, arcname=name)
print('Verified four cases, all image files and the archived traces.')
