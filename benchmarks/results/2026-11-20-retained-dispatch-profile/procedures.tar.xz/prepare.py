import ast
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = Path.cwd()
prior = lab.parent / 'factory-profile-b1153'
donor = lab.parent / 'direct-class-header' / 'quiet'
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert revision.startswith('f1593aaf5')
assert not subprocess.check_output(['git', 'status', '--porcelain'])
read = lambda path: path.read_text(encoding='utf-8-sig')
load = lambda path: json.loads(read(path))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def write(name, source):
    if name.endswith('.py'):
        ast.parse(source)
    (lab / name).write_text(source, encoding='utf-8', newline='\n')

def save(name, value):
    write(name, json.dumps(value, ensure_ascii=False, indent=2) + '\n')

catalog_path = lab / 'catalog.json'
catalog_sources = [lab.parent / name for name in (
    'factory-cpython-b1151/representative.json',
    'retained-factories-cpython-b1109/representative.json',
    'native-format-selectors-r615/catalog.json',
)]
catalog = load(catalog_sources[0])
cases = {case['id']: case for path in catalog_sources for case in load(path)['cases']}
jobs = [
    ('candidate-annotated', 'scripts.annotated-rule-closures', 'warm'),
    ('candidate-nested', 'scripts.annotated-rule-closures.nested-factories', 'warm'),
    ('candidate-forwarding', 'scripts.report-forwarding.expanded', 'warm'),
    ('candidate-report', 'scripts.report-render.format-selectors.large', 'warm'),
]
catalog['cases'] = [cases[case] for _, case, _ in jobs]
save('catalog.json', catalog)

old = load(donor / 'config.json')
terminal = load(donor / 'terminal-status.json')
receipt = load(donor / 'archive-receipt.json')
assert terminal['exitCode'] == '0' and terminal['receipt'] == receipt
assert all(receipt[name] for name in ('complete', 'allWorkersJoined', 'quietBeforeAndAfter', 'archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256'] == sha(donor / 'observations.tgz')
expected = old['identity']['imageFiles']['candidate']
image = lab / 'candidate'
image.mkdir(exist_ok=True)
build = repo / 'benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0'
donor_image = donor.parent / 'frozen' / 'candidate'
donor_revision = old['identity']['sourceRevision'].split(' versus ')[-1]
subprocess.run(['git', 'diff', '--exit-code', donor_revision, revision, '--', 'global.json', 'Directory.Build.props',
                'Directory.Packages.props', 'benchmarks/cpython-worker.py', 'benchmarks/Lokad.Lython.Benchmarks',
                'src/Lokad.Lython.Utf8Regex'], check=True)
core = 'Lokad.Lython.dll'
for name, digest in expected.items():
    if name != core:
        assert sha(donor_image / name) == digest, name
    shutil.copyfile((build if name == core else donor_image) / name, image / name)
files = {name: sha(image / name) for name in expected}
assert len(files) == 32 and files[core] != expected[core]

sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ['PATH'])
with (lab / 'verify.log').open('wb') as output:
    subprocess.run([dotnet, image / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog', catalog_path,
                    '--dotnet', dotnet, '--python', 'C:/Python313/python.exe', '--python-worker', repo / 'benchmarks/cpython-worker.py',
                    '--out', lab / 'verify.json'], env=env, stdout=output, stderr=subprocess.STDOUT, check=True, timeout=140)
verified = load(lab / 'verify.json')
assert verified['state'] == 'Completed' and verified['catalogSha256'] == sha(catalog_path)
assert {name: sha(image / name) for name in expected} == files

root = '/home/lokad/lython-bench-checks/retained-dispatch-profile-b1159-20261120'
unit = 'lython-b1159-retained-dispatch-profile-20261120'
original = load(prior / 'config.json')
purpose = 'B1159 retained factory, forwarding and report attribution'
identity = dict(sourceRevision=revision, purpose=purpose, diagnosticOnly=True, imageFiles={'candidate': files},
                catalogSHA256=sha(catalog_path), coreSHA256={'candidate': files[core]})
save('identity.json', identity)
labels = [label for label, _, _ in jobs]
old_labels = ['candidate-annotated', 'candidate-nested']
profile_floor = 174 * 1024 * 1024
for name in ('ops-profile.py', 'collect.py', 'run.sh', 'launch.py', 'retrieve.py', 'analyze.py'):
    source = read(prior / name).replace(original['root'], root).replace(original['identity']['purpose'], purpose)
    source = source.replace(repr(old_labels), repr(labels)).replace('len(records)==2', 'len(records)==4')
    source = source.replace('182452224', str(profile_floor))
    if name == 'ops-profile.py':
        a = source.index('    for name, case_id, lane in ')
        b = source.index('        role = name', a)
        source = source[:a] + '    for name, case_id, lane in ' + repr(jobs) + ':\n' + source[b:]
        source = source.replace('        count = 512', '        count = 128 if name in {"candidate-forwarding", "candidate-report"} else 512')
        source = source.replace('total_capture_seconds > 14', 'total_capture_seconds > 26')
    if name == 'analyze.py':
        a = source.index(' focused={')
        source = source[:a] + ''' focus.update({
     'entry materialization':('TryStartBoundInvocation','StartNativeCall','StartInline','EnterFunctionCall'),
     'operand retirement':('PublishInstructionResult','PublishResult','RetireTo','ClearNativeSlot'),
     'selector evaluation':('SelectFormat','RenderMethodFormat','ResolveFormat','PrepareFormat'),
     'keyword ownership':('PrepareExpandedKeywords','BindPreparedKeywords','TransferInlineKeywords','InvokeWithKeywordMapping'),
     'split sizing and replay':('BuildSplitResult','TryCountBulkSplit','TryReadSplitRange'),
     'final default owner':('PendingFunctionDefaults',),
 })
''' + source[a:]
    if name == 'launch.py':
        source = source.replace('seconds=62','seconds=90').replace('before 62 seconds','before 90 seconds')
        source = re.sub(r"print\('B1153 .*?\.'\)", f'print({purpose!r})', source)
    write(name, source)
assert repr(jobs) in read(lab / 'ops-profile.py')

payload = lab / 'payload.tgz'
names = ['identity.json', 'catalog.json', 'ops-profile.py', 'collect.py', 'run.sh', f'candidate/{core}']
with tarfile.open(payload, 'w:gz') as output:
    for name in names:
        output.add(lab / name, arcname=name)
expanded = sum((lab / name).stat().st_size for name in names)
space = load(lab / 'quiet-space.json')
available = space['freeBytes']
selected = []
needed = profile_floor + expanded + 3145728
for proof in space['replicas']:
    if available > needed + 131072:
        break
    assert proof['committedBlobVerified'] and proof['paths'] == [old['root'].split('/')[-1] + '/reference/' + core]
    selected.append(proof)
    available += proof['bytes']
assert available > needed, (available, needed)
config = dict(root=root, unit=unit, source=old['root'], sourceFiles={'candidate': {name: digest for name, digest in files.items() if name != core}},
    sourceCatalogSHA256=old['catalogSHA256'], catalogSHA256=sha(catalog_path), identity=identity, retireGroups=selected,
    payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload), unpackedBytes=expanded, donorArchive=receipt['archiveSHA256'])
save('config.json', config)
launcher = read(prior / 'remote-launch.py')
a, b = launcher.index('\nc=') + 1, launcher.index('\nb=Path(')
launcher = launcher[:a] + 'c=' + repr(config) + launcher[b:]
launcher = launcher.replace('lython-b1153-fixtures', 'lython-b1159-fixtures')
launcher = launcher.replace('182452224', str(profile_floor)).replace('RuntimeMaxSec=175', 'RuntimeMaxSec=205')
write('remote-launch.py', launcher)
print('Full current image and four unchanged CPython goldens verified. Profile staging headroom', available - needed, 'bytes.')
