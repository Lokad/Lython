from hashlib import sha256
from pathlib import Path
from shutil import copy2
from subprocess import check_output
import json
import re
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
pair = lab / 'comparison'
out = repo / 'benchmarks/results/2026-11-28-borrowed-sum-subtotal'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
identity = read(pair / 'identity.json')
assert identity['sourceRevision'].startswith('6ee258ff8') and identity['referenceRevision'].startswith('09cecc9ce')
patch = lab / 'candidate.patch'
assert check_output(['git','diff','--binary','HEAD'], cwd=lab/'source') == patch.read_bytes()
assert digest(patch) == identity['sourcePatchSHA256']
for role, files in identity['imageFiles'].items():
    assert len(files) == 32 and {p.name: digest(p) for p in (pair/role).iterdir()} == files
    proof = read(pair/f'{role}-verify.json')
    assert proof['state'] == 'Completed' and proof['caseCount'] == 4
    assert proof['launched']['library']['sha256'] == files['Lokad.Lython.dll']
    assert proof['launched']['python']['sha256'] == identity['expectedCPythonSHA256']
assert {name for name, digest in identity['imageFiles']['reference'].items()
    if digest != identity['imageFiles']['candidate'][name]} == {'Lokad.Lython.dll'}
assert read(pair/'summary.json')['verifiedTimedBatches'] == 84
receipt = read(pair/'archive-receipt.json')
assert receipt['archiveSHA256'] == digest(pair/'observations.tar.xz')
assert all(receipt[name] for name in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
allocation = read(lab/'allocation/summary.json')
admission = read(lab/'admission/summary.json')
assert len(allocation) == len(admission) == 8
for row in allocation:
    assert row['compiled'][0] == row['compiled'][1] and row['admittedPeak'][0] == row['admittedPeak'][1]
    if 'generator-reduction' in row['case']:
        assert 163840 <= row['clr'][0] - row['clr'][1] <= 164014
for row in admission:
    assert row['peak'][0] == row['peak'][1]
    assert row['requests'][0] - row['requests'][1] == (2048 if 'generator-reduction' in row['case'] else 0)
logs = sorted(lab.glob('*-public-net*.log'))
assert len(logs) == 3
for log in logs:
    assert re.search(r'Failed: +0, Passed: +415, Skipped: +0', log.read_text(encoding='utf-8-sig'))
files = {name: lab/name for name in ('candidate.patch','freeze.py','measure-allocation.py','check-admission.py',
    'summarize.py','ubuntu-core-build.log','publish.py')}
for log in logs: files[log.name] = log
for folder in ('allocation','admission'):
    for path in (lab/folder).glob('*.json'): files[f'{folder}/{path.name}'] = path
for name in ('reference-verify.json','candidate-verify.json','archive-receipt.json','run.log','exit-code.txt'):
    files[name] = pair/name
out.mkdir()
public = {name: pair/name for name in ('identity.json','summary.json','observations.tar.xz','archive-receipt.json')}
public.update({'allocation.json':lab/'allocation/summary.json','admission.json':lab/'admission/summary.json'})
for name, path in public.items():
    copy2(path, out/name)
    assert digest(out/name) == digest(path)
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name,path in files.items(): archive.add(path,arcname=name)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert all(sha256(archive.extractfile(name).read()).hexdigest() == digest(path) for name,path in files.items())
print('Verified both 32-file images, measured patch, three lanes, ownership witnesses and tests.')
