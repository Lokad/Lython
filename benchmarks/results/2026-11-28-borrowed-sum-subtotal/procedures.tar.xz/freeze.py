from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import json

lab = Path(__file__).resolve().parent
source = lab / 'source'
base = lab.parent / 'current-cpython-b1958-20261128/comparison/quiet'
prior = lab.parent / 'call-bound-sum-b1959-20261128'
catalog = prior / 'comparison'
pair = lab / 'comparison'
core = 'Lokad.Lython.dll'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0' / core
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
hashes = lambda path: {p.name: digest(p) for p in path.iterdir()}

def git(*args):
    return check_output(['git', *args], cwd=source)

def save(path, content):
    path.write_text(content, encoding='utf-8', newline='\n')
    assert b'\r' not in path.read_bytes()

old = read(base / 'identity.json')
head = git('rev-parse', 'HEAD').decode().strip()
assert head.startswith('6ee258ff8') and old['sourceRevision'].startswith('09cecc9ce')
assert not git('diff', old['sourceRevision'], head, '--', 'src', 'Directory.Packages.props',
    'Directory.Build.props', 'Directory.Build.targets', 'benchmarks/Lokad.Lython.Benchmarks')
patch = git('diff', '--binary', 'HEAD')
assert patch.count(b'diff --git ') == 3 and not git('ls-files','--others','--exclude-standard')
changed = git('diff', '--name-only', 'HEAD').decode().splitlines()
assert set(changed) == {'src/Lokad.Lython/Runtime/' + suffix for suffix in
    ('LythonRuntime.BuiltinIterables.Aggregates.cs', 'LythonRuntime.Executable.GeneratorSum.cs',
     'LythonRuntime.Executable.Interpreter.Dispatch.cs')}
frozen = old['imageFiles']['candidate']
assert len(frozen) == 32 and hashes(base / 'local-image') == frozen
pair.mkdir()
for role in ('reference','candidate'):
    copytree(base / 'local-image', pair / role)
copy2(build, pair / 'candidate' / core)
assert not (pair / 'candidate' / core).samefile(build)
images = {role: hashes(pair / role) for role in ('reference', 'candidate')}
assert images['reference'] == frozen
assert {name for name, checksum in images['candidate'].items() if frozen[name] != checksum} == {core}
catalogue = read(catalog / 'identity.json')
for name in ('representative.json','cpython-worker.py'):
    copy2(catalog / name, pair / name)
assert digest(pair / 'representative.json') == catalogue['catalogs']['representative.json']['sha256']
assert digest(pair / 'cpython-worker.py') == old['cpythonWorkerSHA256']
jobs = [['diagnostic.shipment-file-fed-map','warm-async'],
    ['diagnostic.shipment-row-generator-reduction','warm-async'],
    ['diagnostic.shipment-row-range-generator-reduction','warm-async']]
save(pair / 'jobs.json', json.dumps({'warm':jobs}, indent=2)+'\n')
collector = (catalog / 'collect.py').read_text(encoding='utf-8')
assert collector.count('len(jobs) == 5') == 1
save(pair / 'collect.py', collector.replace('len(jobs) == 5', 'len(jobs) == 3'))
runner = (catalog / 'run.sh').read_text(encoding='utf-8')
assert runner.count('270s') == 1
save(pair / 'run.sh', runner.replace('270s', '180s'))
(lab / 'candidate.patch').write_bytes(patch)
identity = dict(sourceRevision=head, referenceRevision=old['sourceRevision'],
    sourcePatchSHA256=sha256(patch).hexdigest(), imageFiles=images,
    coreSHA256={role+suffix: image[core] for role,image in images.items() for suffix in ('','-control')},
    expectedCPythonSHA256=old['expectedCPythonSHA256'], cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    catalogs={name: {'sha256':digest(pair/name)} for name in ('representative.json','jobs.json')},
    purpose='Share the borrowed sum accumulator admission with the producer operand.')
save(pair / 'identity.json', json.dumps(identity, indent=2)+'\n')
for name in ('measure-allocation.py','check-admission.py'):
    copy2(prior / name, lab / name)
summary = (prior / 'summarize.py').read_text(encoding='utf-8')
save(lab / 'summarize.py', summary.replace('== 5', '== 3').replace('== 140','== 84'))
print(head, 'two full-image snapshots and three matched lanes')
