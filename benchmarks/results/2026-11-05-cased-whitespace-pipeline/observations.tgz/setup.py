from pathlib import Path
import shutil
root=Path('/home/lokad/lython-bench-checks/cased-whitespace-b239-20261105')
base=Path('/home/lokad/lython-bench-checks/parser-reassessment-b238-20261105/candidate')
(root/'baseline').symlink_to(base,target_is_directory=True)
for f in base.iterdir():
 if f.name in ['Lokad.Lython.dll','Lokad.Lython.pdb']:continue
 if f.name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json']:shutil.copyfile(f,root/'candidate'/f.name)
 else:(root/'candidate'/f.name).symlink_to(f.resolve(),target_is_directory=f.is_dir())
assert shutil.disk_usage(root).free>64*1024*1024
