from pathlib import Path
import ast
import hashlib
import json
import tarfile

lab=Path(__file__).resolve().parent
prior=lab.parent/'invoice-call-profile-b1148'
donor=lab.parent/'factory-cpython-b1151'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=load(donor/'config.json')
receipt=load(donor/'archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease'] and receipt['allWorkersJoined']
assert sha(donor/'observations.tgz')==receipt['archiveSHA256']
identity=load(donor/'identity.json')
identity.update(purpose='B1153 retained annotated and nested factory attribution',diagnosticOnly=True)
files=identity['imageFiles']['candidate']
assert len(files)==32 and {n:sha(donor/'frozen/candidate'/n) for n in files}==files
catalog=donor/'representative.json'
assert sha(catalog)==identity['catalogSHA256']==load(donor/'verify.json')['catalogSha256']
jobs=[('candidate-annotated','scripts.annotated-rule-closures','warm'),
      ('candidate-nested','scripts.annotated-rule-closures.nested-factories','warm')]
labels=[job[0] for job in jobs]
assert {job[1] for job in jobs}<={case['id'] for case in load(catalog)['cases']}
root='/home/lokad/lython-bench-checks/factory-profile-b1153-20261119'
unit='lython-b1153-factory-profile-20261119'
original=load(prior/'config.json')
def write(name,value):
    if name.endswith('.py'):ast.parse(value)
    (lab/name).write_text(value,encoding='utf8',newline='\n')
def save(name,value):write(name,json.dumps(value,indent=2,ensure_ascii=False)+'\n')
save('identity.json',identity)
(lab/'catalog.json').write_bytes(catalog.read_bytes())
old_labels=['reference-invoice','candidate-annotated','candidate-invoice','reference-annotated']
for name in ('ops-profile.py','collect.py','run.sh','launch.py','retrieve.py','analyze.py'):
    source=(prior/name).read_text(encoding='utf8').replace(original['root'],root)
    source=source.replace('B1148 invoice and annotated call attribution',identity['purpose'])
    source=source.replace(repr(old_labels),repr(labels)).replace("len(records)==4","len(records)==2")
    if name=='ops-profile.py':
        start,end=source.index('    for name, case_id, lane in '),source.index('        role = name')
        source=source[:start]+'    for name, case_id, lane in '+repr(jobs)+':\n'+source[end:]
        source=source.replace('128 if name.endswith("-invoice") else 512','512')
        source=source.replace('total_capture_seconds > 26','total_capture_seconds > 14')
    if name=='analyze.py':
        source=source.replace("     'keyword default lookup':",
          "     'scope promotion':('CreateNativeContinuation','CreateFunctionFrame','CreateBorrowedFunctionContext'),\n"
          "     'default storage and attachment':('PendingFunctionDefaults','AttachTypeMetadataAsync','AddDefinitionValue','CreateRecord'),\n"
          "     'binding and workspace entry':('StartNativeCall','BeginBoundCall','CreateExecutableWorkState','RentFunctionArgumentStorage'),\n"
          "     'keyword default lookup':")
    if name=='launch.py':source=source.replace('seconds=95','seconds=62').replace('before 95 seconds','before 62 seconds')
    write(name,source)
assert repr(jobs) in (lab/'ops-profile.py').read_text()
assert repr(labels) in (lab/'analyze.py').read_text()
names=('identity.json','catalog.json','ops-profile.py','collect.py','run.sh')
payload=lab/'payload.tgz'
with tarfile.open(payload,'w:gz')as a:
    for name in names:a.add(lab/name,arcname=name)
config=dict(root=root,unit=unit,source=base['root'],sourceFiles={'candidate':files},
    sourceCatalogSHA256=identity['catalogSHA256'],catalogSHA256=identity['catalogSHA256'],
    identity=identity,retireGroups=[],payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),
    unpackedBytes=sum((lab/name).stat().st_size for name in names),donorArchive=receipt['archiveSHA256'])
save('config.json',config)
launcher=(prior/'remote-launch.py').read_text(encoding='utf8')
a,b=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=launcher[:a]+'c='+repr(config)+launcher[b:]
launcher=launcher.replace("['reference','candidate']","['candidate']").replace('+5242880,','+3145728,')
launcher=launcher.replace('lython-b1148-fixtures','lython-b1153-fixtures')
write('remote-launch.py',launcher)
print('Two retained workload profiles use the exact complete image and verified CPython outputs.')
