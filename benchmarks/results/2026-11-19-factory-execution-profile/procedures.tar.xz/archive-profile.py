from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
donor=lab.parent/'factory-cpython-b1151'
out=Path('benchmarks/results/2026-11-19-factory-execution-profile')
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
identity=read(lab/'identity.json')
files=identity['imageFiles']['candidate']
assert identity['sourceRevision'].startswith('0d74b5b18') and identity['imageSource'].startswith('249d5522b')
assert len(files)==32 and {n:digest(donor/'frozen/candidate'/n) for n in files}==files
assert read(donor/'verify.json')['state']=='Completed'
assert identity['catalogSHA256']==digest(lab/'catalog.json')==read(donor/'verify.json')['catalogSha256']
receipt=read(lab/'archive-receipt.json')
terminal=read(lab/'terminal-status.json')
assert terminal['exitCode']=='0' and terminal['receipt']==receipt
assert not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert all(receipt[k] for k in ('complete','allWorkersJoined','quietBeforeAndAfter','guestFixturesRemoved',
    'archivedAndVerifiedUnderLease','persistentTraceArchivedAndVerifiedBeforeUnmount'))
assert receipt['archiveSHA256']==digest(lab/'observations.tgz')
cases={case['id']:case for case in read(lab/'catalog.json')['cases']}
rows=read(lab/'attribution.json')['rows']
assert [row['label'] for row in rows]==['candidate-annotated','candidate-nested']
for row in rows:
    record=read(lab/'retrieved/profiles'/row['label']/'record.json')
    case=cases[row['case']]
    assert record['workload']==row['case'] and record['lane']=='warm' and record['warmupSeconds']>=8
    assert record['exitCode']==0 and record['closed']['status']=='Closed'
    observed={Path(lib['path']).name:lib['sha256'].lower() for lib in record['identity']['libraries']}
    assert observed['Lokad.Lython.dll']==files['Lokad.Lython.dll']
    assert all(observed[n]==files[n] for n in observed.keys() & files.keys())
    assert record['verificationBefore']['status']==record['verificationAfter']['status']=='Equivalent'
    for check in (record['verificationBefore'],*record['batches'],record['verificationAfter']):
        assert check['completedInvocations']>0
        for name in ('sourceSha256','fixtureSha256','expectedOutputSha256'):assert check[name]==case[name]
        assert check['actualOutputSha256']==case['expectedOutputSha256']
        assert check.get('actualFilesSha256')==case.get('expectedFilesSha256')
out.mkdir(exist_ok=True)
for name in ('archive-receipt.json','terminal-status.json','observations.tgz','attribution.json'):
    shutil.copyfile(lab/name,out/name)
with tarfile.open(out/'procedures.tar.xz','w:xz',preset=6) as tar:
    for name in ('prepare.py','identity.json','catalog.json','config.json','ops-profile.py','collect.py','run.sh','analyze.py',
                 'remote-launch.py','launch.py','launch.log','observe-not-before.json','retrieve.py','retrieval.log',
                 'analysis.log','archive-profile.py'):
        tar.add(lab/name,arcname=name)
print('Verified two retained-image stacks, their exact outcomes and archive.')
for row in rows:
    print(row['label'], row['guestRuntimeAncestry'],
          {k:v for k,v in row['guestRuntimeFocus'].items() if k in (
           'definition execution','native prefix and unpack','scope promotion','default storage and attachment',
           'binding and workspace entry','borrowed invocation','governor resize and admission',
           'general binder','keyword default lookup')})
    for name, count in row['nearestGuestRuntime'][:10]:
        print(count,name.split('::',1)[-1].split('(')[0])
