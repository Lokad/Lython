from pathlib import Path
import hashlib,json,shutil,tarfile
lab=Path(__file__).parent; quiet=lab/'comparison/quiet'; external=lab.with_name('post-zip-cpython-20261125')/'external'; donor=lab.with_name('zip-unpack-20261125')
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,d:write(p,json.dumps(d,indent=2)+'\n')
proof=read(quiet/'identity.json'); before=read(external/'identity.json'); images=proof['images']
assert proof['lythonSource']==before['productionSource'] and images['reference']==before['imageFiles']['candidate']
for role,files in images.items():
 assert len(files)==32 and {p.name:sha(p)for p in (lab/role).iterdir()}==files
 checked=read(quiet/f'{role}-verify.json'); assert checked['state']=='Completed' and checked['caseCount']==4
 assert checked['catalogSha256']==proof['catalogSHA256']==sha(quiet/'representative.json')
receipt=read(external/'terminal-status.json')['receipt'];assert receipt['complete'] and sha(external/'observations.tar.xz')==receipt['archiveSHA256']
compiled='scripts.regex-log-search.compiled'; module='scripts.regex-log-search.module'; invoice='scripts.csv-invoice.method-policy.quoted-control'
save(quiet/'jobs.json',dict(warm=[[compiled,'warm'],[module,'warm'],[invoice,'warm'],[compiled,'compile-run']]))
identity=dict(sourceRevision=proof['lythonSource'],comparisonRevision=proof['lythonSource'],producerSource=proof['producerSource'],
 sourcePatchSHA256=sha(lab.with_name('regex-050-funded-20261125')/'adapter-bridge.patch'),imageFiles=images,
 coreSHA256={role+s:files['Lokad.Lython.dll']for role,files in images.items()for s in ('','-control')},
 expectedCPythonSHA256=before['expectedCPythonSHA256'],cpythonWorkerSHA256=before['cpythonWorkerSHA256'],
 catalogs={n:dict(sha256=sha(quiet/n))for n in ['jobs.json','representative.json']},
 purpose='Compare frozen 0.4.0 and admitted immutable 0.5.0 development adapter with the same Lython core and worker')
save(quiet/'timing-identity.json',identity)
shutil.copyfile(donor/'comparison/quiet/run.sh',quiet/'run.sh');assert b'\r' not in (quiet/'run.sh').read_bytes()
collector=(donor/'comparison/quiet/collect.py').read_text(encoding='utf-8').replace('len(jobs) == 5','len(jobs) == 4').replace('b1665-fixtures','b1671-fixtures')
compile(collector,'collect.py','exec');write(quiet/'collect.py',collector)
payload=quiet/'payload.tar.gz'; replacements={name for name,hash in images['candidate'].items()if images['reference'][name]!=hash}
assert replacements=={'Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll'}
with tarfile.open(payload,'w:gz',compresslevel=3) as bundle:
 for n in ['jobs.json','representative.json','run.sh','collect.py']:bundle.add(quiet/n,arcname=n)
 bundle.add(quiet/'timing-identity.json',arcname='identity.json')
 for n in sorted(replacements):bundle.add(lab/'candidate'/n,arcname='replacement-'+n)
save(quiet/'upload.json',dict(root='regex-funded-b1671-20261125',reference='post-zip-cpython-b1669-20261125',payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
save(lab/'verified-raw-replicas.json',[])
launcher=(donor/'quiet.py').read_text(encoding='utf-8').replace('b1665','b1671').replace('lython-b1671-zip-unpack','lython-b1671-regex-funded')
launcher=launcher.replace('683fcdfa4dbd7f3c12ffadc461698d86584d2a4fce926626a9c7f08954bef52b',receipt['archiveSHA256']).replace('seconds=241','seconds=196').replace('RuntimeMaxSec=305','RuntimeMaxSec=245')
launcher=launcher.replace("'identity.json','representative.json','jobs.json','run.sh','collect.py','candidate-core.dll'", "'identity.json','representative.json','jobs.json','run.sh','collect.py',"+','.join(repr('replacement-'+name)for name in sorted(replacements)))
launcher=launcher.replace("if name=='Lokad.Lython.dll' and role=='candidate':\n    (root/(role+'-core.dll')).rename(image/name)","if role=='candidate' and (root/('replacement-'+name)).is_file():\n    (root/('replacement-'+name)).rename(image/name)")
assert 'candidate-core.dll' not in launcher
compile(launcher,'quiet.py','exec');write(lab/'quiet.py',launcher)
report=(donor/'archive.py').read_text(encoding='utf-8').replace('2026-11-25-zip-unpack','2026-11-25-regex-050-funded-allocation/timing').replace('receipt["warmJobs"]==5','receipt["warmJobs"]==4').replace('timedBatches=140,lanes=5','timedBatches=112,lanes=4').replace('staged==read(quiet/"identity.json")','staged==read(quiet/"timing-identity.json")')
compile(report,'archive-timing.py','exec');write(lab/'archive-timing.py',report)
