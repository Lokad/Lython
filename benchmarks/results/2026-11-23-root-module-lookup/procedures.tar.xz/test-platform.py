from pathlib import Path
import os
import subprocess
import sys

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
role=sys.argv[1]
filters={
  "white": ("Lokad.Lython.Tests", "Category!=Stress&(FullyQualifiedName~Import|FullyQualifiedName~Namespace|FullyQualifiedName~StaticName|FullyQualifiedName~LocalBinding|FullyQualifiedName~Compilation|FullyQualifiedName~CapturedScalar|FullyQualifiedName~NativeClosure|FullyQualifiedName~LambdaExecutable|FullyQualifiedName~ComprehensionLambda|FullyQualifiedName~ManagedStackGuard|FullyQualifiedName~ExecutableArchitecture|FullyQualifiedName~OperandStackBoundary)"),
  "public": ("Lokad.Lython.PublicApi.Tests", "Category!=Stress&(FullyQualifiedName~GlobalBindingPipeline|FullyQualifiedName~Import|FullyQualifiedName~CoreBuiltins|FullyQualifiedName~HelperLocalLifetime|FullyQualifiedName~BoundCallable|FullyQualifiedName~ExecutableCleanup|FullyQualifiedName~TransitiveClosure|FullyQualifiedName~CapturedScalar|FullyQualifiedName~Namespace|FullyQualifiedName~FunctionDefault|FullyQualifiedName~Comprehension|FullyQualifiedName~Generator|FullyQualifiedName~ClassMethod|FullyQualifiedName~StaticErrorDiagnostics|FullyQualifiedName~CooperativeCancellation|FullyQualifiedName~VariableAnnotations)"),
}


tree=repo/".git/agent-worktrees/root-module-lookup-20261123"
windows_dotnet=Path.home()/".dotnet11/dotnet.exe"
linux_dotnet="/home/vermorel/.dotnet/dotnet"
args = ["test","-c","Release"]
if role=="windows":
    command=[str(windows_dotnet)]
    env=dict(os.environ,DOTNET_ROOT=str(windows_dotnet.parent),DOTNET_HOST_PATH=str(windows_dotnet))
    target="net11.0"
    artifacts=lab/"windows"
else:
    def linux(path): return "/mnt/d/"+path.relative_to(path.anchor).as_posix()
    command=["wsl.exe","--cd",linux(tree),"--exec","env","DOTNET_ROOT=/home/vermorel/.dotnet",
             "DOTNET_HOST_PATH="+linux_dotnet,linux_dotnet]
    env=None
    target="net10.0"
    artifacts=linux(lab/"ubuntu")
for kind,(project,query) in filters.items():
    log=lab/(role+"-"+kind+".log")
    with log.open("wb") as out:
        result=subprocess.run(command+args+["tests/"+project, "-f",target,"--artifacts-path",str(artifacts),"--filter",query],
                              cwd=tree,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=200)
    lines=log.read_text(encoding="utf-8").splitlines()
    print("\n".join(lines[-(9 if result.returncode==0 else 25):]),flush=True)
    result.check_returncode()
