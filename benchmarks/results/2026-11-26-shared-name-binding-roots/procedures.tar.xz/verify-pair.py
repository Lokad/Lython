from pathlib import Path
from statistics import median
import ast,hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.with_name('shared-regex-group-validation-20261126')/'parity'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda bytes:hashlib.sha256(bytes).hexdigest()
digest=lambda p:sha(p.read_bytes())
save=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
catalog=read(lab.with_name('shared-assignment-bindings-20261125')/'representative.json')
selected={'scripts.config-generated-guards.medium.bad-0.sparse-lexical','scripts.file-manifest.small',
          'diagnostic.generated-record-rules-bindings'}
catalog['cases']=[row for row in catalog['cases'] if row['id'] in selected]
assert {row['id'] for row in catalog['cases']}==selected
source='\n'
fixture='{"size":1,"text":null}'
catalog['cases'].append(dict(id='diagnostic.empty-compile-control',family='scripts',category='whole-script',scale='small',
    size=1,source=source,fixtureJson=fixture,expectedOutput='',sourceUtf8Bytes=len(source),expectedOutputUtf8Bytes=0,
    fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=sha(source.encode()),
    fixtureSha256=sha(fixture.encode()),expectedOutputSha256=sha(b'')))
path=lab/'representative.json'
save(path,catalog)
# The fixture statements use precisely these compound suites across both
# parsers. Count the discovery walk through the first named function in each
# branch. Keep CPython topology counts separate from elapsed measurements.
def discovery(suite):
    visited=roots=0
    for node in suite:
        visited+=1
        if isinstance(node,ast.FunctionDef):
            roots+=1
            continue
        if isinstance(node,(ast.If,ast.For,ast.While,ast.With,ast.ClassDef)):
            groups=[node.body,getattr(node,'orelse',[])]
        elif isinstance(node,ast.Try):
            groups=[node.body,*[handler.body for handler in node.handlers],node.orelse,node.finalbody]
        else:
            assert not any(isinstance(child,ast.stmt) for child in ast.iter_child_nodes(node)),type(node).__name__
            groups=[]
        for body in groups:
            count,found=discovery(body)
            visited+=count
            roots+=found
    return visited,roots
inventory=[]
for item in catalog['cases']:
    statements,roots=discovery(ast.parse(item['source']).body)
    inventory.append(dict(case=item['id'],originalDiscoveryStatements=statements,selectedRoots=roots,
                          separateDiscoveryStatementsAfter=0))
save(lab/'discovery-inventory.json',inventory)
known=read(prior/'candidate-files.json')
assert len(known)==32 and {p.name:digest(p) for p in (prior/'candidate').iterdir()}==known
candidate=lab/'candidate-source/src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
worker=repo/'benchmarks/cpython-worker.py'
compiler=lab.with_name('shared-literal-decoding-20261124')/'refinement/compiler-owner'
images={}
measurement={}
for role in ('reference','candidate'):
    image=lab/'frozen'/role
    shutil.copytree(prior/'candidate',image)
    if role=='candidate': shutil.copyfile(candidate,image/candidate.name)
    files={p.name:digest(p) for p in image.iterdir()}
    assert len(files)==32 and {name for name in files if files[name]!=known[name]}==({'Lokad.Lython.dll'} if role=='candidate' else set())
    images[role]=files
    proof=lab/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',path,'--dotnet',dotnet,
        '--python','C:/Python313/python.exe','--python-worker',worker,'--out',proof],cwd=repo,env=env,check=True,timeout=70)
    report=read(proof)
    assert report['state']=='Completed' and report['caseCount']==4
    assert report['catalogSha256']==digest(path) and report['launched']['library']['sha256'].lower()==files[candidate.name].lower()
    run=lab/(role+'-compiler-owner')
    run.mkdir()
    for file in compiler.glob('Inspect*'): shutil.copyfile(file,run/file.name)
    shutil.copyfile(image/candidate.name,run/candidate.name)
    result=lab/(role+'-compiler-allocation.json')
    subprocess.run([dotnet,run/'Inspect.dll',path,result],cwd=repo,env=env,check=True,timeout=60)
    data=read(result)
    assert data['coreSHA256']==files[candidate.name]
    measurement[role]=data['rows']
save(lab/'frozen-identity.json',dict(sourceRevision='4f7c085cd',sourcePatchSHA256=digest(lab/'candidate.patch'),
     imageFiles=images,coreSHA256={role+extra:image[candidate.name] for role,image in images.items() for extra in ('','-control')},
     cpythonWorkerSHA256=digest(worker),catalogs={'representative.json':dict(sha256=digest(path))}))
summary=[]
for before,after in zip(measurement['reference'],measurement['candidate'],strict=True):
    assert before['id']==after['id']
    summary.append(dict(case=before['id'],allocatedBytes=[median(row['allocatedBytes']) for row in (before,after)],
                        retainedAdmission=[row['retainedAdmission'] for row in (before,after)]))
save(lab/'allocation-summary.json',summary)
print(json.dumps(dict(inventory=inventory,memory=summary)))
