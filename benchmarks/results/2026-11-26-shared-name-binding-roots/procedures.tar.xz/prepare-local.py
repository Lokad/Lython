from pathlib import Path
import hashlib,json,shutil

lab=Path(__file__).resolve().parent
old=lab.with_name('ready-json-decoder-entry-20261126')
local=lab/'local'
local.mkdir()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,t:p.write_text(t,encoding='utf-8',newline='\n')
save=lambda p,v:write(p,json.dumps(v,indent=2)+'\n')
identity=json.loads((lab/'frozen-identity.json').read_text(encoding='utf-8'))
for role,files in identity['imageFiles'].items():
    source=lab/'frozen'/role
    assert len(files)==32 and {p.name:digest(p) for p in source.iterdir()}==files
    shutil.copytree(source,local/role)
    assert {p.name:digest(p) for p in (local/role).iterdir()}==files
for path in (lab/'representative.json',old/'local/cpython-worker.py',old/'local/run.sh'):
    shutil.copyfile(path,local/path.name)
assert digest(local/'cpython-worker.py')==identity['cpythonWorkerSHA256']
manifest='scripts.file-manifest.small'
sparse='scripts.config-generated-guards.medium.bad-0.sparse-lexical'
rules='diagnostic.generated-record-rules-bindings'
save(local/'jobs.json',{'warm':[['diagnostic.empty-compile-control','compile'],
   [manifest,'compile'],[rules,'compile'],[sparse,'compile'],[manifest,'compile-run']]})
identity['catalogs']={name:{'sha256':digest(local/name)} for name in ('representative.json','jobs.json')}
identity['purpose']='Check sharing first function discovery with syntax validity across compile phases.'
save(local/'identity.json',identity)
collector=(old/'local/collect.py').read_text(encoding='utf-8')
for before,after in (('len(jobs) == 4','len(jobs) == 5'),
                     ('lython-json-ready-fixture-','lython-name-binding-fixture-')):
    assert collector.count(before)==1
    collector=collector.replace(before,after)
compile(collector,'collect.py','exec')
write(local/'collect.py',collector)
runner=(old/'run-local.sh').read_text(encoding='utf-8').replace(old.name,lab.name).replace('150s','205s')
write(lab/'run-local.sh',runner)
assert all(b'\r' not in p.read_bytes() for p in (lab/'run-local.sh',local/'run.sh'))
summarizer=(old/'summarize.py').read_text(encoding='utf-8').replace('== 4','== 5').replace('timedBatches=112','timedBatches=140')
compile(summarizer,'summarize.py','exec')
write(lab/'summarize.py',summarizer)
