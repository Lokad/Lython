from pathlib import Path
from difflib import unified_diff
import subprocess,zipfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
source=lab/'candidate-source'
source.mkdir()
archive=lab/'source.zip'
subprocess.run(['git','archive','--format=zip','--output',archive,'4f7c085cd','--','src','tests','tools/LythonProbe',
                'benchmarks/Lokad.Lython.Benchmarks','benchmarks/scripts','Directory.Build.props',
                'Directory.Build.targets','Directory.Build.rsp','Directory.Packages.props','global.json','NuGet.Config'],
               cwd=repo,check=True)
with zipfile.ZipFile(archive) as packed:
    assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in packed.namelist())
    packed.extractall(source)
changes=[]
def edit(file,replacements):
    name='src/Lokad.Lython/Frontend/'+file
    path=source/name
    old=path.read_text(encoding='utf-8')
    new=old
    for a,b in replacements:
        assert new.count(a)==1,(name,a)
        new=new.replace(a,b)
    path.write_text(new,encoding='utf-8',newline='\n')
    changes.extend(unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),'a/'+name,'b/'+name))
edit('SyntaxValidityDiagnostics.cs',[
('        bool lexicalScope, bool annotatedReturn)','        bool lexicalScope, bool annotatedReturn, bool insideFunction = false)'),
('        public readonly bool AnnotatedReturn = annotatedReturn;\n','        public readonly bool AnnotatedReturn = annotatedReturn;\n        public readonly bool InsideFunction = insideFunction;\n'),
('        out Dictionary<IReadOnlyList<StatementSyntax>, int>? annotationChecks, out bool importsRegex,',
 '        out Dictionary<IReadOnlyList<StatementSyntax>, int>? annotationChecks, out bool importsRegex,\n        out List<FunctionDefinitionStatementSyntax>? nameBindingRoots,'),
('        annotationChecks = null;\n        importsRegex = false;','        annotationChecks = null;\n        nameBindingRoots = null;\n        importsRegex = false;'),
('''            if (statement is FunctionDefinitionStatementSyntax function)
            {
                Parameters''','''            if (statement is FunctionDefinitionStatementSyntax function)
            {
                // The name-binding walk starts at the first function in each
                // branch. Function bodies still run their own assignment flow.
                if (!work.InsideFunction) (nameBindingRoots ??= []).Add(function);
                Parameters'''),
('''                suites.Add(new SuiteVisit(body, depth, current,
                    statement is FunctionDefinitionStatementSyntax or ClassDefinitionStatementSyntax, annotatedReturn));''',
'''                suites.Add(new SuiteVisit(body, depth, current,
                    statement is FunctionDefinitionStatementSyntax or ClassDefinitionStatementSyntax, annotatedReturn,
                    work.InsideFunction || statement is FunctionDefinitionStatementSyntax));''')])
edit('LythonFrontend.cs',[
('            out var statementFacts, out var annotationChecks, out var importsRegex, cancellationToken);',
 '            out var statementFacts, out var annotationChecks, out var importsRegex, out var nameBindingRoots, cancellationToken);'),
('                .Concat(StaticAnalyzer.Analyze(analysis, hasScopeDirectives))',
 '                .Concat(StaticAnalyzer.Analyze(analysis, hasScopeDirectives, nameBindingRoots))')])
edit('StaticAnalyzer.cs',[
('    internal static IReadOnlyList<LythonDiagnostic> Analyze(StaticAnalysisContext context, bool hasScopeDirectives = true)',
 '    internal static IReadOnlyList<LythonDiagnostic> Analyze(StaticAnalysisContext context, bool hasScopeDirectives,\n        IReadOnlyList<FunctionDefinitionStatementSyntax>? nameBindingRoots)'),
('        StaticNameBindingDiagnostics.Analyze(context);','        StaticNameBindingDiagnostics.Analyze(context, nameBindingRoots);')])
edit('StaticNameBindingDiagnostics.cs',[
('''    public static void Analyze(StaticAnalysisContext context)
    {
        AnalyzeNestedFunctionDefinitions(context.Script.Statements, context);
    }''',
'''    public static void Analyze(StaticAnalysisContext context, IReadOnlyList<FunctionDefinitionStatementSyntax>? roots)
    {
        if (roots is null) return;
        // Validation visits sibling suites and statements in reverse order.
        // The selected functions have no selected ancestor, so reading the
        // roots backwards restores the original diagnostic discovery order.
        for (var i = roots.Count - 1; i >= 0; i--)
        {
            context.CheckExecution();
            var function = roots[i];
            AnalyzeFunctionHeaderLambdas(function, context);
            AnalyzeFunctionBody(function, context);
        }
    }''')])
(lab/'candidate.patch').write_text(''.join(changes),encoding='utf-8',newline='\n')
