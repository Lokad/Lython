from collections import defaultdict
from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
from statistics import median, quantiles
from resource import RUSAGE_CHILDREN, getrusage
from tempfile import TemporaryDirectory
from time import perf_counter_ns
import json
import os
import platform
import subprocess

lab=Path(__file__).resolve().parent
reference=lab/'reference'
instrumented=lab/'instrumented'
historical=lab/'historical'
dotnet=Path.home()/'.dotnet/dotnet'
python=lab.parent/'bench-cpython-3.13.16-runtime/runtime/bin/python3.13'
worker='Lokad.Lython.Benchmarks.dll'
python_worker=lab/'cpython-worker.py'
payload=lab/'config.json'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
manifest=lambda folder:{p.name:digest(p) for p in folder.iterdir()}
setup=read(lab/'setup.json')

def write(name,value):
    (lab/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')

assert manifest(reference)==setup['reference'] and len(setup['reference'])==32
assert digest(dotnet)==setup['dotnetSHA256'] and digest(python)==setup['pythonSHA256']
assert digest(python_worker)==setup['pythonWorkerSHA256'] and digest(payload)==setup['payloadSHA256']
if not instrumented.exists():
    copytree(reference,instrumented)
    copyfile(lab/'worker-source/bin/Release/net11.0'/worker,instrumented/worker)
other=manifest(instrumented)
assert {name for name in setup['reference'] if setup['reference'][name]!=other[name]}=={worker}

assert manifest(historical)==setup['historical']
historical_timed=lab/'historical-timed'
if not historical_timed.exists():
    copytree(historical,historical_timed)
    copyfile(instrumented/worker,historical_timed/worker)
assert manifest(historical_timed)=={**setup['historical'],worker:other[worker]}
case,=read(payload)['cases']
env={k:v for k,v in os.environ.items() if not k.startswith(('DOTNET_','COMPlus_'))}
env['DOTNET_ROOT']=str(dotnet.parent)
env['LC_ALL']='C.UTF-8'
env['TMPDIR']='/dev/shm'
commands={
    'frozen': [dotnet,reference/worker,'--compare','once','--catalog',payload],
    'instrumented': [dotnet,instrumented/worker,'--compare','once','--catalog',payload],
    'historical': [dotnet,historical_timed/worker,'--compare','once','--catalog',payload],
    'CPython': [python,'-I','-S','-X','utf8',python_worker,'--once','--catalog',payload],
}
machine=dict(system=platform.platform(),kernel=platform.release(),cpuAffinity=sorted(os.sched_getaffinity(0)))
conditions=tuple(commands)
orders=(range(4),(1,3,0,2),(2,0,3,1),(3,2,1,0))
schedule=[tuple(conditions[i] for i in order) for order in orders]*3
phase_names=['dispatch','consoleSetup','catalog','onceEntry','hostSetup','compile','fixtureReset','run','verify','protocol','cleanup']

def child_cpu():
    usage=getrusage(RUSAGE_CHILDREN)
    return usage.ru_utime+usage.ru_stime

def run(label, index):
    with TemporaryDirectory(prefix='lython-comparison-files-',dir='/dev/shm') as folder:
        assert os.stat(folder).st_dev!=os.stat(lab).st_dev
        before_cpu=child_cpu()
        start=perf_counter_ns()
        process=subprocess.run(commands[label],cwd=folder,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE,timeout=40,check=False)
        elapsed_ms=(perf_counter_ns()-start)/1e6
        cpu_ms=(child_cpu()-before_cpu)*1000
        assert process.returncode==0,(label, process.returncode, process.stderr.decode()[:1000])
        assert len(process.stdout)>4 and int.from_bytes(process.stdout[:4],'big')==len(process.stdout)-4
        frame=json.loads(process.stdout[4:])
        identity=frame['identity']
        response=frame['response']
        assert identity['catalogSha256']==setup['payloadSHA256'] and identity['status']=='Ready'
        assert response['status']=='Equivalent' and response['completedInvocations']==1,(label,response)
        assert all(response[key]==case[key] for key in ('sourceSha256','fixtureSha256','expectedOutputSha256'))
        assert response['actualOutputSha256']==case['expectedOutputSha256']
        assert response['actualFilesSha256']==case['expectedFilesSha256']
        if label=='CPython':
            assert identity['engine']=='CPython' and identity['version'].startswith('3.13.16')
            assert identity['isolated'] and identity['noSite']
        else:
            assert identity['engine']=='Lython' and identity['runtimeVersion']=='11.0.0'
            assert not identity['benchmarkDotNetLoaded']
            libraries={Path(info['path']).name:Path(info['path']) for info in identity['libraries']}
            expected={'frozen':reference,'instrumented':instrumented,'historical':historical_timed}[label].resolve()
            assert set(libraries)=={'Lokad.Lython.dll',worker,'System.Private.CoreLib.dll'}
            assert libraries['Lokad.Lython.dll'].parent.resolve()==expected
            assert libraries[worker].parent.resolve()==expected
            assert libraries['System.Private.CoreLib.dll'].resolve().is_relative_to(dotnet.parent.resolve()/'shared/Microsoft.NETCore.App')
        record=dict(order=index,engine=label,elapsed=elapsed_ms,cpu=cpu_ms,frame=frame)
        if label in ('instrumented','historical'):
            tag,frequency,*values=process.stderr.decode('utf-8').split()
            stamps=list(map(int,values))
            assert tag=='LYTHON_PHASES' and len(stamps)==len(phase_names)+1
            assert stamps==sorted(stamps) and stamps[0]>0
            phases={name:(right-left)*1000/int(frequency) for name,left,right in zip(phase_names,stamps,stamps[1:])}
            phases['launchAndExitResidual']=elapsed_ms-sum(phases.values())
            assert phases['launchAndExitResidual']>=0
            record.update(phases=phases,markers=stamps,clockFrequency=int(frequency))
        else: assert not process.stderr
    assert not Path(folder).exists()
    return record

warm=[run(label,-1) for label in commands]
rows=[]
for index,order in enumerate(schedule):
    for label in order: rows.append(run(label,index))
    write('observations.json',dict(warm=warm,rows=rows,machine=machine,orders=schedule,completedRounds=index+1))
assert manifest(reference)==setup['reference'] and manifest(instrumented)==other
assert digest(dotnet)==setup['dotnetSHA256'] and digest(python)==setup['pythonSHA256']
assert digest(python_worker)==setup['pythonWorkerSHA256'] and digest(payload)==setup['payloadSHA256']

def describe(series):
    a,b,c=quantiles(series,n=4,method='inclusive')
    return dict(count=len(series),min=min(series),median=median(series),q1=a,q3=c,max=max(series))

summary={}
for label in commands:
    samples=[row for row in rows if row['engine']==label]
    summary[label]={name:describe([row[name] for row in samples]) for name in ('elapsed','cpu')}
phases={label:{name:describe([r['phases'][name] for r in rows if r['engine']==label])
        for name in phase_names+['launchAndExitResidual']} for label in ('instrumented','historical')}
write('summary.json',dict(productionSource=setup['productionSource'],reference=setup['reference'],instrumented=other,
    case=case['id'],payloadSHA256=setup['payloadSHA256'],verifiedInvocations=len(rows),machine=machine,measurements=summary,phases=phases))
for label,item in summary.items(): print(label,round(item['elapsed']['median'],2),round(item['cpu']['median'],2),'ms',flush=True)
for label,values in phases.items():
    for phase,detail in values.items(): print(label,phase,round(detail['median'],2),'ms',flush=True)
assert manifest(historical)==setup['historical']
assert manifest(historical_timed)=={**setup['historical'],worker:other[worker]}
