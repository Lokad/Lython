from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile, copytree
from subprocess import check_output


lab = Path(__file__).resolve().parent
repo = lab.parents[3]
previous = lab.parent / 'first-command-phases-b1927-20261128'
current = lab.parent / 'borrow-fixed-arguments-b1986-20261128' / 'comparison'


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def manifest(folder):
    return {path.name: digest(path) for path in folder.iterdir()}


def git(*arguments):
    return check_output(['git', *arguments], cwd=repo)


revision = git('rev-parse', 'HEAD').decode().strip()
assert revision.startswith('5d1cbb1f3')
assert not git('diff', '--name-only', '486b6bb60', revision, '--', 'benchmarks/Lokad.Lython.Benchmarks')
before = read(previous / 'setup.json')
identity = read(current / 'identity.json')
assert manifest(current / 'candidate') == identity['imageFiles']['candidate']
assert manifest(previous / 'reference') == before['reference']

for path in ('config.json', 'cpython-worker.py', 'collect-trace.py'):
    copyfile(previous / path, lab / path)
for origin, destination in ((current / 'candidate', 'reference'), (previous / 'reference', 'historical')):
    copytree(origin, lab / destination)
    assert manifest(origin) == manifest(lab / destination)

# Reuse the same instrumentation against the same checked-in worker source.
for relative in before['originalSources']:
    source = previous / 'worker-source' / relative
    target = lab / 'worker-source' / relative
    target.parent.mkdir(exist_ok=True, parents=True)
    copyfile(source, target)
copyfile(previous / 'worker-source/FreshPhaseClock.cs', lab / 'worker-source/FreshPhaseClock.cs')
(lab / 'setup.json').write_text(json.dumps({**before, 'reference': identity['imageFiles']['candidate'],
    'historical': before['reference'], 'productionSource': revision,
    'historicalSource': before['productionSource']}, indent=2) + '\n', encoding='utf-8', newline='\n')

collector = (previous / 'collect.py').read_text(encoding='utf-8')
changes = (
    ('from itertools import permutations\n', ''),
    ("instrumented=lab/'instrumented'", "instrumented=lab/'instrumented'\nhistorical=lab/'historical'"),
    ("case,=read(payload)['cases']", """assert manifest(historical)==setup['historical']
historical_timed=lab/'historical-timed'
if not historical_timed.exists():
    copytree(historical,historical_timed)
    copyfile(instrumented/worker,historical_timed/worker)
assert manifest(historical_timed)=={**setup['historical'],worker:other[worker]}
case,=read(payload)['cases']"""),
    ("    'CPython':", "    'historical': [dotnet,historical_timed/worker,'--compare','once','--catalog',payload],\n    'CPython':"),
    ('schedule=list(permutations(commands))*2', """conditions=tuple(commands)
orders=(range(4),(1,3,0,2),(2,0,3,1),(3,2,1,0))
schedule=[tuple(conditions[i] for i in order) for order in orders]*3"""),
    ("expected=(reference if label=='frozen' else instrumented).resolve()", "expected={'frozen':reference,'instrumented':instrumented,'historical':historical_timed}[label].resolve()"),
    ("if label=='instrumented':", "if label in ('instrumented','historical'):"),
    ("phases={name:describe([r['phases'][name] for r in rows if r['engine']=='instrumented'])\n        for name in phase_names+['launchAndExitResidual']}", """phases={label:{name:describe([r['phases'][name] for r in rows if r['engine']==label])
        for name in phase_names+['launchAndExitResidual']} for label in ('instrumented','historical')}"""),
    ("for phase,values in phases.items(): print(phase,round(values['median'],2),'ms',flush=True)", """for label,values in phases.items():
    for phase,detail in values.items(): print(label,phase,round(detail['median'],2),'ms',flush=True)
assert manifest(historical)==setup['historical']
assert manifest(historical_timed)=={**setup['historical'],worker:other[worker]}"""),
)
for old, new in changes:
    assert collector.count(old) == 1, old
    collector = collector.replace(old, new)
(lab / 'collect.py').write_text(collector, encoding='utf-8', newline='\n')
