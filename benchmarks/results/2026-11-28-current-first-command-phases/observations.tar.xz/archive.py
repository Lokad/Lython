from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile
from statistics import median
import tarfile


lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / 'first-command-phases-b1927-20261128'
out = repo / 'benchmarks/results/2026-11-28-current-first-command-phases'


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def manifest(folder):
    return {path.name: digest(path) for path in folder.iterdir()}


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


summary = read(lab / 'summary.json')
setup = read(lab / 'setup.json')
rows = read(lab / 'observations.json')
worker = 'Lokad.Lython.Benchmarks.dll'
assert summary['productionSource'] == setup['productionSource']
assert rows['completedRounds'] == 12 and len(rows['rows']) == summary['verifiedInvocations'] == 48
assert all(row['frame']['response']['status'] == 'Equivalent' for row in rows['warm'] + rows['rows'])
assert manifest(lab / 'reference') == summary['reference'] == setup['reference']
assert manifest(lab / 'historical') == setup['historical']
assert manifest(lab / 'instrumented') == summary['instrumented']
assert manifest(lab / 'historical-timed') == {**setup['historical'], worker: summary['instrumented'][worker]}
assert {name for name in setup['reference'] if summary['instrumented'][name] != setup['reference'][name]} == {worker}
assert digest(lab / 'config.json') == summary['payloadSHA256'] == setup['payloadSHA256']
proof = read(lab / 'trace-receipt.json')
assert len(proof) == 2 and all(digest(lab / row['trace']) == row['traceSha256'] and row['workerAndTracerJoined'] for row in proof)
traces = [json.loads(line) for line in (lab / 'jit-intervals.jsonl').read_text(encoding='utf-8-sig').splitlines()]
assert len(traces) == 2 and all(t['starts'] == t['completed'] == len(t['intervals']) == 2665
                               and not t['unmatched'] and t['overwritten'] == 0 for t in traces)

out.mkdir(exist_ok=True)
jit = []
for trace, prior_proof in zip(traces, proof):
    assert trace['trace'] == prior_proof['trace']
    methods = [row for row in trace['intervals'] if row['Namespace'].startswith('Lokad.Lython')]
    longest = sorted(methods, key=lambda row: row['End'] - row['Start'], reverse=True)[:25]
    jit.append(dict(trace=trace['trace'], matched=trace['completed'], longest=longest))
write(out / 'jit-summary.json', jit)
summary['historicalSource'] = setup['historicalSource']
summary['historicalImage'] = setup['historical']
summary['historicalTimedImage'] = manifest(lab / 'historical-timed')
timed = ['instrumented', 'historical']
samples = {name: [row['phases'] for row in rows['rows'] if row['engine'] == name] for name in timed}
paired = {}
for phase in samples['instrumented'][0]:
    values = [after[phase] - before[phase] for after, before in zip(*[samples[name] for name in timed])]
    paired[phase] = dict(minimum=min(values), median=median(values), maximum=max(values))
summary['pairedCurrentMinusHistoricalMilliseconds'] = paired
write(out / 'summary.json', summary)

files = {path.name: path for path in lab.iterdir() if path.is_file() and path.suffix in
         ('.py', '.json', '.jsonl', '.log', '.nettrace', '.stderr', '.frame')}
for name in ('FreshPhaseClock.cs', 'Program.cs', 'Lokad.Lython.Benchmarks.csproj',
             'Comparison/ComparisonCatalogCommand.cs', 'Comparison/LythonOnceWorker.cs'):
    files[f'worker-source/{name}'] = lab / 'worker-source' / name
for name in ('TraceReader.csproj', 'Program.cs'):
    files[f'trace-reader/{name}'] = prior / 'trace-reader' / name
with tarfile.open(out / 'observations.tar.xz', 'w:xz') as archive:
    for name, path in files.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'observations.tar.xz') as archive:
    assert all(sha256(archive.extractfile(name).read()).hexdigest() == digest(path) for name, path in files.items())
print(f'Archived and verified {len(files)} evidence files.')
print(json.dumps(paired, indent=2))
