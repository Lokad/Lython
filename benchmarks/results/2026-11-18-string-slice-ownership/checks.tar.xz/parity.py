for value in ['', 'abcdef', '🌍éxα🍎', '\u0301a中é😀', 'a\x00b🌟é']:
    for start in [None, -21, -2, 0, 1, 8]:
        for end in [None, -12, -1, 0, 2, 31]:
            for step in [None, -2147483648, -3, -1, 1, 2, 2147483647]:
                print(repr(value[start:end:step]))
    for chars in ['', 'a', 'é', '😀', '🌍é', value]:
        print(repr(value.removeprefix(chars)), repr(value.removesuffix(chars)))
