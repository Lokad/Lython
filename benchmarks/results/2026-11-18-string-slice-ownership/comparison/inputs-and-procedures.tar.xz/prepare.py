from pathlib import Path
import base64
import hashlib
import json
import os
import importlib.util
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = Path.cwd()
donor_lab = lab.parent / "strip-owner-r538"
sha = lambda data: hashlib.sha256(data).hexdigest()
read_json = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
pinned = Path.home() / ".dotnet11"
dotnet = pinned / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(pinned), DOTNET_ROOT_X64=str(pinned),
           PATH=str(pinned) + os.pathsep + os.environ["PATH"])

def git(work, *args):
    return subprocess.check_output(["git", "-C", str(work), *args])

def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n",
                    encoding="utf-8", newline="\n")

spec = importlib.util.spec_from_file_location("protocol", repo / "benchmarks/cpython-worker.py")
protocol = importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)

core_name = "Lokad.Lython.dll"
candidate = repo / ".git/agent-worktrees/shared-strip-entry"
candidate_core = candidate / "src/Lokad.Lython/bin/Release/net11.0" / core_name
reference = donor_lab / "frozen/candidate"
donor_id = read_json(donor_lab / "frozen-identity.json")
donor_files = donor_id["imageFiles"]["candidate"]
assert len(donor_files) == 32 and all(sha((reference / n).read_bytes()) == h for n, h in donor_files.items())
recorded = read_json(repo / "benchmarks/results/2026-11-18-string-slice-ownership/identity.json")
assert sha(candidate_core.read_bytes()) == recorded["localCoreSHA256"]["net11.0"]
assert sha(candidate_core.read_bytes()) == sha((candidate / "benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0" / core_name).read_bytes())
assert git(candidate, "diff", "227d80b47", "--", "src") == b""
images = {}
for role, core in [("reference", reference / core_name), ("candidate", candidate_core)]:
    dest = lab / "frozen" / role
    dest.mkdir(parents=True, exist_ok=True)
    for name in donor_files:
        shutil.copyfile(core if name == core_name else reference / name, dest / name)
    images[role] = {name: sha((dest / name).read_bytes()) for name in donor_files}
    assert images[role] == donor_files | {core_name: sha(core.read_bytes())}

source = """def extract(line):
    payload = line.removeprefix('EVENT ').removesuffix(' | accepted\\n')
    return payload[:20] + '\\t' + payload[22::2] + '\\n'

count = 0
with open('events.log', encoding='utf-8') as source:
    with open('events.tsv', 'w', encoding='utf-8', newline='') as report:
        for line in source:
            if line.startswith('EVENT '):
                report.write(extract(line))
                count += 1
print(count)
"""
task = "scripts.event-extraction.large"
records = []
output = []
for index in range(2048):
    if index % 17 == 0:
        records.append("DEBUG receive heartbeat\n")
        continue
    key = ("gateway-" if index % 2 else "dépôt-🚚-") + str(index).zfill(6)
    payload = "cafés | " if index % 5 == 0 else " status "
    interleaved = "".join(c + "." for c in ("parcel" + str(index % 37)).ljust(19, "."))
    records.append(f"EVENT {key:<20}  {interleaved} | accepted\n")
    output.append(f"{key:<20}\t{('parcel' + str(index % 37)).ljust(19, '.')}\n")
record_bytes = "".join(records).encode()
out_bytes = "".join(output).encode()
fixture = dict(size=len(records), text=None, inputFiles={"events.log": base64.b64encode(record_bytes).decode()},
               outputFiles={"events.tsv": base64.b64encode(out_bytes).decode()})
fixture_json = json.dumps(fixture, ensure_ascii=False, separators=(",", ":"))
expected = f"{len(output)}\n"
case = dict(id=task, category="file-processing", family="scripts", scale="large", runAsync=False,
            size=len(records), source=source, sourceUtf8Bytes=len(source.encode()), sourceSha256=sha(source.encode()),
            fixtureJson=fixture_json, fixtureSha256=sha(fixture_json.encode()), fixtureTextCodePoints=0,
            fixtureTextUtf8Bytes=0, expectedFilesSha256=protocol.file_digest({"events.tsv": out_bytes}),
            expectedOutput=expected, expectedOutputSha256=sha(expected.encode()),
            expectedOutputUtf8Bytes=len(expected.encode()))
catalog = read_json(donor_lab / "representative.json")
assert sha((donor_lab / "representative.json").read_bytes()) == donor_id["catalogSHA256"]
control = "calls.positional.large"
catalog["cases"] = [case, next(row for row in catalog["cases"] if row["id"] == control)]
catalog["performanceQualified"] = False
catalog_path = lab / "representative.json"
write(catalog_path, catalog)
write(lab / "jobs.json", [(task, "warm"), (task, "compile-run"), (control, "warm")])
print("Workload", len(records), len(record_bytes), "input bytes and", len(output), len(out_bytes), "output bytes", flush=True)
for role, hashes in images.items():
    frozen = lab / "frozen" / role
    with (lab / (role + "-verification.log")).open("w", encoding="utf-8") as log:
        subprocess.run([dotnet, frozen / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
                        "--catalog", catalog_path, "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
                        "--python-worker", repo / "benchmarks/cpython-worker.py",
                        "--out", lab / (role + "-verification.json")], cwd=repo, env=env, stdout=log,
                       stderr=subprocess.STDOUT, timeout=120, check=True)
    assert all(sha((frozen / n).read_bytes()) == digest for n, digest in hashes.items())
    print(role, "passed both goldens", hashes[core_name], flush=True)
write(lab / "frozen-identity.json", {
    "sourceRevision": "98b9f87f7 / 27cb473e versus 227d80b47 / f2824fea0",
    "purpose": "Admission before UTF-8 slice and affix construction across a complete excerpt extraction script plus positional call control",
    "imageFiles": images, "catalogSHA256": sha(catalog_path.read_bytes()),
    "coreSHA256": {label: images[role][core_name] for role in images for label in (role, role + "-control")},
    "normalAdapterPin": "0.4.0",
})
