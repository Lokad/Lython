from pathlib import Path
import hashlib,json,subprocess,tarfile,xml.etree.ElementTree as E

r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');w=repo/'.git/agent-worktrees/cased-word-stream-r440'
identity=json.loads((r/'refined/frozen/identity.json').read_text(encoding='utf-8'))
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=['src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs','tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs']
dirty=subprocess.check_output(['git','-C',str(w),'diff','--name-only'],text=True).splitlines()
with tarfile.open(repo/'benchmarks/results/2026-11-16-cased-word-stream/refined/sources-and-checks.tar.xz')as t:
 for n,h in identity['sources'].items():
  assert h==sha(t.extractfile(n).read()),n
  if dirty:assert sha((w/n).read_bytes())==h,n
if dirty:
 assert sorted(dirty)==sorted(paths)
 subprocess.run(['git','-C',str(w),'restore','--',*paths],check=True)
assert not subprocess.check_output(['git','-C',str(w),'status','--porcelain'],text=True)
assert (repo/paths[0]).read_text(encoding='utf-8')==(w/paths[0]).read_text(encoding='utf-8')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
checks=[dict(file=p.name,**E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib)for p in(r/'retained-tests').glob('*.trx')]
assert len(checks)==2 and all(x['passed']=='28'and x['failed']=='0'for x in checks)
proof=dict(bothShapesWithdrawn=True,all609InputsVerifiedAgainstCanonicalArchiveBeforeRestore=True,privateWorktreeClean=True,qualifiedProductionSourceUnchanged=True,independentTests=4,retainedFocusedChecks=checks,originalRangeGrowthFixturePreserved=True,fullQualificationNotRepeatedForWithdrawnRuntime=True)
(repo/'benchmarks/results/2026-11-16-cased-word-stream/refined/withdrawal.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(repo/'benchmarks/results/2026-11-16-cased-word-stream/refined/retained-checks.tar.xz','w:xz')as t:
 t.add(repo/paths[1],arcname=paths[1]);t.add(r/'retained-tests',arcname='retained-tests');t.add(r/'retained-tests-build.log',arcname='retained-tests-build.log');t.add(Path(__file__),arcname='close-withdrawal.py')
 t.add(r/'close-withdrawal-initial.py',arcname='close-withdrawal-initial.py')
info=tarfile.TarInfo('initial-restoration-condition.txt')
condition=b'Initial closure verified all609source bytes against the canonical archive, then restored the two tracked changes. Its final raw-byte equality check failed because git restore changed LF to CRLF. Both production sources are text-identical and private git status is clean; the correction normalizes text for this restored-source check only. Frozen measured source/image hashes and raw observations are unchanged.\n'
import io
with tarfile.open(repo/'benchmarks/results/2026-11-16-cased-word-stream/refined/restoration-condition.tar.xz','w:xz')as t:
 info.size=len(condition);t.addfile(info,io.BytesIO(condition));t.add(r/'close-withdrawal-initial.py',arcname='close-withdrawal-initial.py')
p=repo/'tests/README.md';s=p.read_text(encoding='utf-8');needle='Counting-loop refund callbacks observe completed word/total bindings and preserve\nthe first refusal before subsequent guest effects.'
assert needle in s;s=s.replace(needle,needle+'\nCased-word ownership cases also dispose a foreign source owner before iteration\nand retain the completed words. Advancement uses prepaid storage and completes\nwithout new admission; cleanup returns the shared allowance to baseline.');p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');a=s.index('| Active text redesign |');b=s.index('\n| Independent adapter prototype |',a)
s=s[:a]+'''| Withdrawn text redesign | [R440/B842–B843](benchmarks/results/2026-11-16-cased-word-stream/refined/README.md),1427→ce36 versus0443. First shape allocation−71.54%/accounted peak−27.02%; bulk refinement−46.31%/−15.82%,but long-line elapsed+6.26..8.01% with1.20/0.45%controls. Both withdrawn; all sources/adverse controls preserved. Independent four ownership cases retained;28internal eachactual11/10 pass on qualified production,original range-growth fixture preserved. No repeated full qualification. |'''+s[b:]
a=s.index('### 1. R440:');b=s.index('### 2. Remaining substantial roadmap',a)
s=s[:a]+'''### 1. R441: establish the next complete-script redesign from file-search costs

**Completed checkpoint.** R440's full snapshot/range deletion and bulk-snapshot
refinement are both withdrawn. One removes storage; the other restores bulk work
but adds a scan. Neither justifies its remaining CPU debt. Exact source/images,
nine allocation jobs,seven VM jobs per shape,all adverse controls and original
staging refusal remain linked above. Main production stays qualified0443; four
independent ownership cases pass28checks eachactual11/10. No unchanged retiming or
full qualification for withdrawn code. No permanent architecture ban.

**Selected bounded assessment.** R437 still shows protected file search1.76–1.80×
CPython,with compilation around0.85×; execution is the material remaining gap.
Current source already consolidates imports onto executable code(840621405),so
the old later import-consolidation entry was stale and is removed. R439 sampled
captured-text costs,not this protected early-exit workload. Use one short existing
CPU-attribution capture of the qualified search script/current fixed seven-case
catalog. Separate useful scanning/host I/O,call/frame/operand transport,checks and
cleanup; retain inlining/unknown limitations. No inferred removable percentages.

**Decision/completion.** One bounded capture with full-image/golden/quiet/join/
archive gates,then select a complete displaced stage or explicitly record that
dominance is unresolved. Do not launch another broad campaign or resurrect a
shared carrier merely from dispatch sample totals. Before implementation record
work/storage eliminated,affected whole scripts,semantic acceptance and one short
controlled source comparison. Keep measured native function gains; preserve
evaluation/error order,first refusal,current cancellation,pending borrows,managed
stack and cleanup. Full platform/stress/installed consumers at retained delivery.
This assessment advances the roadmap; it does not complete the performance goal.

'''+s[b:]
s=s.replace('R438materialization and R439shared-kernel shapes are archived and\nwithdrawn.','R438materialization,R439shared-kernel and R440cased-stream shapes are\narchived and withdrawn.')
s=s.replace('| Text/conversions | R440selects an actual whole-line representation. Casing,final sinks,layouts,line construction and immutable shared subtext already delivered. |','| Text/conversions | R440 removes real storage but adds CPU; both shapes withdrawn with independent ownership coverage retained. Casing,final sinks,layouts,line construction and immutable shared subtext already delivered. |')
s=s.replace('Import execution consolidation remains later and separate; retain the lowered\nevaluator for real import/class/annotation and opcode consumers. Before every new','Import execution consolidation is already delivered(840621405); retain the lowered\nevaluator for real class/annotation and opcode consumers. Before every new')
s=s.replace('Updated2026-11-16UTC.','Updated2026-11-16UTC(R440withdrawal/R441selected).')
p.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(proof))
