from pathlib import Path
import json
r=Path(__file__).parent;repo=Path('D:/code/Lython');w=repo/'.git/agent-worktrees/cased-word-stream-r440';p=w/'src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs';s=p.read_text(encoding='utf-8')
a=s.index('        context.CheckExecution(span);',s.index('internal static CasedWhitespaceIteration PrepareCasedWhitespaceIteration('));b=s.index('\n    internal sealed class CasedWhitespaceIteration',a)
s=s[:a]+'''        context.CheckExecution(span);
        var governor = context.MemoryGovernor;
        var mapping = upper ? CaseMapping.Upper : CaseMapping.Lower;
        var prepared = governor.RentWordRanges(8, span);
        var previousScratchCapacity = prepared.EncodedCapacity;
        try
        {
            var encoding = new WhitespaceRangeState(-1, mapping);
            // Keep casing bulk and the input lifetime confined to preparation.
            // All mapped bytes and word charges precede the first loop effect.
            var encoded = prepared.PrepareEncoded(CheckCaseOutputCapacity(
                (long)value.ByteLength * encoding.MaximumCaseWidth, span), context, span);
            context.CheckExecution(span);
            long outputBytes = 0;
            while (TryReadWhitespaceRange(value.Utf8Span, ref encoding, context, span, out var range, encoded))
            {
                outputBytes = checked(outputBytes + PyString.EstimateApproximateBytes(range.Capacity));
                // Casing preserves whitespace boundaries. One separator reuses
                // capacity already admitted for the original whitespace; the
                // cursor can discover words without a separate range inventory.
                if (encoding.Position < value.ByteLength) encoded[encoding.Written++] = (byte)' ';
            }
            governor.Reserve(outputBytes, span);
            try
            {
                context.CheckExecution(span);
                var result = prepared;
                result.Initialize(context, span, encoding.Written);
                governor.Commit(outputBytes);
                prepared = null;
                return result;
            }
            catch { governor.ReleaseReserved(outputBytes); throw; }
        }
        finally
        {
            if (prepared is not null)
            {
                try
                {
                    if (prepared.EncodedCapacity > previousScratchCapacity)
                        prepared.ReleaseEncoded();
                }
                finally { governor.ReturnWordRanges(prepared, 0); }
            }
        }
    }
''' +s[b:]
s=s.replace('        private PyString? _source;', '        private int _encodedLength;').replace('            _source = null;', '            _encodedLength = 0;')
a=s.index('        internal void Initialize(LythonRuntime.ExecutionContext context, LythonSourceSpan span,');b=s.index('        internal PyIterationResult MoveNext()',a)
s=s[:a]+'''        internal void Initialize(LythonRuntime.ExecutionContext context, LythonSourceSpan span, int encodedLength)
        {
            _context = context;
            _span = span;
            _encodedLength = encodedLength;
            _scan = new WhitespaceRangeState(-1, null);
        }

        private bool TryReadRange(out (int Start, int End, int Capacity) range)
            => TryReadWhitespaceRange(_encoded.AsSpan(0, _encodedLength), ref _scan, _context, _span, out range);

'''+s[b:]
assert '_source'not in s and 'maximumWordCapacity'not in s and 'AdoptScratchFrom'not in s
p.write_text(s,encoding='utf-8',newline='\n')
decision=dict(hypothesis='B842 removes both snapshot and range inventory with strong memory savings,but captured-text CPU is consistently adverse. Keep the existing bulk mapped snapshot and exact eager word prepayment; remove the private range inventory only. Scan prepared separated bytes during advancement,without retaining/copying source or mapping during per-word heap cursor state.',eliminated='Private per-word tuple ranges and their growth/clear/adoption dependency. Cursor count/position pair becomes existing scanner state plus encoded extent. Foreign source-copy branch and source-retention field from1427 are removed. No new mode,pool,cursor class,owner or controller.',tradeoff='Retain conservative whole-line encoded capacity for bulk work and source lifetime simplicity. Expect smaller allocation/accounted-memory benefit than1427; do not claim CPU correction before one changed-source comparison. General split ranges remain genuine and funded.',semantics='Same original subject/position in bulk casing,Python whitespace boundaries,exact eager all-word prepayment,checked capacity,first-refusal propagation,cancellation,retained words,nested loans and safe unwind. Internal separators occupy capacity already admitted for original whitespace. Cursor output remains immutable words,not the prepared stream.',acceptance='Existing focused both-target Release regressions and new foreign-source/prepaid-advancement coverage; short allocation then one controlled same-seven-case source pair. Preserve all1427/B842 controls and initial staging refusal. Explicit retain/refine/remove with residual-debt decision; full qualification at retained delivery.',retained=False,CPUClaim=False)
(r/'refined-decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');a=s.index('| Selected implementation |');b=s.index('\n| Independent adapter',a)
s=s[:a]+'''| Active text redesign | [R440/B842](benchmarks/results/2026-11-16-cased-word-stream/README.md),1427/0443,seven jobs213.199s/all gates. Long-line allocation−71.54%/accounted peak−27.02%,but captured CPU+7.58..12.07%,long-line+1.95..7.76%.243internal/623public eachactual11/10 pass. Bulk-snapshot/private-range deletion refinement active; no promotion/full qualification. |'''+s[b:]
a=s.index('### 1. R440:');b=s.index('### 2. Remaining substantial roadmap',a)
s=s[:a]+'''### 1. R440: remove private word-range inventory while keeping bulk casing

**Status/evidence.** Main34dba8c4 retains qualified0443runtime. First1427/B842
removes whole-line staging and private ranges: long-line allocation−71.54% and
accounted peak−27.02%,but captured text CPU+7.58..12.07% and long-line+1.95..7.76%
are adverse. Moving controls remain explicit. Source,all nine allocation jobs,
seven VM jobs and original staging refusal are committed separately.243internal/
623public eachactual11/10 pass. No promotion or repeated broad qualification.

**Selected refinement.** Keep one existing bulk encoded snapshot and exact eager
word prepayment; delete the private per-word range inventory only. The same
scanner maps words during preparation and inserts internal ASCII separators using
capacity already admitted for original whitespace. The existing cursor discovers
words in those prepared bytes without ranges,source retention/copy or per-word
casing. Remove private range growth/clear/adoption dependencies and cursor count/
position pair. General split/splitlines range consumers and existing loan/cache
remain. No second mode,pool,class,controller,owner or memory subsystem. Preserve
the qualified native/function engine. This is a CPU/locality hypothesis,not an
established causal explanation or speedup. Keep all1427/B842 originals.

**Contract/tradeoff.** Retain conservative whole-line encoded capacity to keep
casing bulk and the source lifetime confined to preparation. Smaller memory benefit
than full snapshot deletion is acceptable if demonstrated. Before first loop effect,
fund mapped snapshot and every eventual immutable word. No new admission during
advancement/unwind,no uncharged retained aliases or retry after refusal. Original
subject/position still governs Unicode context; case preserves whitespace word
boundaries. Public list-returning splits remain ordinary eager lists. Existing
managed safety,source snapshots,current token,first-refusal and cleanup apply.

**Acceptance.** Both-target focused Release Unicode/all Python whitespace,
empty/exhausted cursors,expansion/final sigma/combining marks,long/inline words,
both directions,helpers/closures/identity,foreign-source cleanup,nested/returned
loans/idle shutdown,prepaid advancement,first-loop refusal and cancellation. Keep
independent funding/side-effect assertions; the old65word fixture is two words,
without loosening checks. No exact tiny-budget or checkpoint-count requirement.
Then one short allocation/accounted-capacity diagnostic and one bounded changed-
source comparison against0443 using the same named seven-case catalog for every
process(normalization,captured/long-line text,CSV,JSON,search and ordinary calls).
Four-second warmups keep seven jobs within240s; retain all adverse/moving controls
and catalog/init differences. No causal cross-collection gain or unchanged retiming.

**Stop/completion.** Private range inventory gone,bulk snapshot/prepaid words and
ownership working,focused checks plus controlled comparison,then explicitly
retain/refine/remove and decide residual regression debt. Batch full platform,
original stress and installed Release consumers at retention. Publication held;
finishing this item does not finish the substantial performance objective.

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print('Refined to one bulk separated snapshot without private ranges/source retention. Original1427 source and full tradeoff evidence remain archived.')
