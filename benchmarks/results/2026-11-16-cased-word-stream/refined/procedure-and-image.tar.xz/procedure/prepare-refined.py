from pathlib import Path
import ast, hashlib, io, json, shutil, subprocess, tarfile
import xml.etree.ElementTree as E

parent = Path(__file__).resolve().parent
r = parent / 'refined'
r.mkdir()
repo = Path('D:/code/Lython')
w = repo / '.git/agent-worktrees/cased-word-stream-r440'
sha = lambda b: hashlib.sha256(b).hexdigest()
prior = json.loads((parent / 'frozen/identity.json').read_text(encoding='utf-8'))
f = r / 'frozen'; f.mkdir()
images = {}
for role in ['reference', 'candidate']:
    shutil.copytree(parent / 'frozen/reference', f / role)
    if role == 'candidate':
        shutil.copyfile(w / 'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll', f / role / 'Lokad.Lython.dll')
    images[role] = {p.name: sha(p.read_bytes()) for p in (f / role).iterdir() if p.is_file()}
assert images['reference'] == prior['images']['reference']
assert all(images['candidate'][n] == h for n, h in images['reference'].items() if n != 'Lokad.Lython.dll')
sources = {n: sha((w / n).read_bytes()) for n in prior['sources']}
assert len(sources) == 609
identity = dict(prior, images=images, sources=sources,
    contract='Keep bulk mapped snapshot and exact eager word prepayment. Remove private per-word range inventory/growth/adoption; scan internal separated mapped bytes. Source lifetime ends after preparation. No new mode, pool, owner or controller. Qualified executable engine unchanged.')
(f / 'identity.json').write_text(json.dumps(identity, indent=2)+'\n', encoding='utf-8', newline='\n')
ns = {'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
checks = [dict(file=p.name, **E.parse(p).find('t:ResultSummary/t:Counters', ns).attrib) for p in (parent/'refined-checks').glob('*.trx')]
assert len(checks) == 4 and sorted(int(x['passed']) for x in checks) == [243,243,623,623] and all(x['failed']=='0' for x in checks)
(r/'focused-checks.json').write_text(json.dumps(dict(checks=checks, nonincrementalBothTargetReleaseBuild=True, fullQualificationPending=True),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz') as t:
    for n in sources: t.add(w/n,arcname=n)
    t.add(parent/'refined-checks',arcname='refined-checks')
    t.add(parent/'refined-build.log',arcname='refined-build.log')
    t.add(parent/'refined-decision.json',arcname='refined-decision.json')
a = r/'allocation-short'; a.mkdir()
for n in ['Program.cs','Allocation.csproj','catalog.json']: shutil.copyfile(parent/'allocation-short'/n,a/n)
shutil.copytree(parent/'allocation-short/bin',a/'bin')
for n in ['measure-allocation.py','summarize.py','launch-quiet.py']: shutil.copyfile(parent/n,r/n)
q = r/'quiet'; q.mkdir()
before = json.loads((parent/'quiet/config.json').read_text(encoding='utf-8'))
root = '/home/lokad/lython-bench-checks/cased-word-ranges-b843-20261116'
unit = 'lython-b843-cased-word-ranges-20261116'
imageFiles = {role:{n:images[role][n] for n in before['sourceFiles']} for role in ['reference','candidate']}
ident = dict(before['identity'],sourceRevision='R440 bulk snapshot/private-range deletion '+images['candidate']['Lokad.Lython.dll'][:8]+' versus qualified312f5911/0443b5cf',purpose='Remove private per-word range inventory only, retain bulk mapping. Same seven-case B842 catalog/warmups. Allocation/accounted storage and CPU are separate.',imageFiles=imageFiles,coreSHA256={label:imageFiles['candidate' if label.startswith('candidate') else 'reference']['Lokad.Lython.dll'] for label in ['reference','reference-control','candidate','candidate-control']},candidateFocusedChecks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8')),candidateSourceIdentitySHA256=sha((f/'identity.json').read_bytes()))
(q/'identity.json').write_text(json.dumps(ident,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(parent/'quiet/representative.json',q/'representative.json')
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
    s=(parent/'quiet'/n).read_text(encoding='utf-8')
    if n=='run.sh': s=s.replace('root='+before['root'],'root='+root)
    if n=='collect.py': s=s.replace('warmupSeconds=5,','warmupSeconds=4,')
    s=s.replace('B842','B843')
    assert before['root'] not in s and before['unit'] not in s,n
    if n.endswith('.py'): ast.parse(s)
    (q/n).write_text(s,encoding='utf-8',newline='\n')
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
proofs=[]
for archive,member,paths in [
 ('benchmarks/results/2026-11-16-cased-word-stream/procedure-and-image.tar.xz','frozen/candidate/Lokad.Lython.dll',['cased-word-stream-b842-20261116/candidate/Lokad.Lython.dll']),
 ('benchmarks/results/2026-11-16-cased-word-stream/observations.tgz',None,['cased-word-stream-b842-20261116/observations.tgz']),
 ('benchmarks/results/2026-11-16-cased-word-stream/observations.tgz','confirmation/confirmation.json',['cased-word-stream-b842-20261116/confirmation/confirmation.json'])]:
    raw=(repo/archive).read_bytes()
    assert raw==subprocess.check_output(['git','-C',str(repo),'show',head+':'+archive])
    if member:
        with tarfile.open(fileobj=io.BytesIO(raw)) as t: content=t.extractfile(member).read()
    else: content=raw
    proofs.append(dict(bytes=len(content),sha256=sha(content),links=len(paths),paths=paths,custody=dict(commit=head,archive=archive,archiveSHA256=sha(raw),member=member)))
payload={n:(q/n).read_bytes() for n in ['identity.json','collect.py','archive-owned.py','run.sh']}
payload['candidate/Lokad.Lython.dll']=(f/'candidate/Lokad.Lython.dll').read_bytes()
with tarfile.open(q/'payload.tgz','w:gz') as t:
    for n,b in payload.items(): m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
c=dict(root=root,unit=unit,source=before['root'],sourceFiles=before['sourceFiles'],sourceCatalogSHA256=before['catalogSHA256'],catalogSHA256=before['catalogSHA256'],identity=ident,retireGroups=proofs,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(map(len,payload.values())))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(parent/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:]
s=s.replace('lython-b842-fixtures','lython-b843-fixtures')
s=s.replace(" os.link(source/'cpython-worker.py',root/'cpython-worker.py')", " os.link(source/'cpython-worker.py',root/'cpython-worker.py')\n os.link(source/'representative.json',root/'representative.json')")
ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
for n in ['collect.py','archive-owned.py']:
    s=(q/n).read_text(encoding='utf-8');assert 'Path(__file__).resolve().parent' in s and '/lython-bench-checks/' not in s
assert 'root='+root in (q/'run.sh').read_text(encoding='utf-8')
assert "config=json.loads((r/'config.json')" in (q/'retrieve.py').read_text(encoding='utf-8')
assert sha((q/'representative.json').read_bytes())==c['catalogSHA256']
assert len(json.loads((q/'representative.json').read_text(encoding='utf-8'))['cases'])==7
with tarfile.open(q/'payload.tgz') as t:
    for n,b in payload.items(): assert t.extractfile(n).read()==b
print(json.dumps(dict(core=images['candidate']['Lokad.Lython.dll'],sources=len(sources),checks=4,jobs=7,allConcretePathsValidated=True,catalogUnchanged=True,retireBytes=sum(p['bytes'] for p in proofs),unpackedBytes=c['unpackedBytes'])))
