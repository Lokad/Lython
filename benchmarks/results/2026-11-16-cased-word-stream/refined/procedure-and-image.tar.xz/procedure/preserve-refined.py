from pathlib import Path
import hashlib, json, shutil, tarfile

parent=Path(__file__).resolve().parent;r=parent/'refined';q=r/'quiet';repo=Path('D:/code/Lython')
out=repo/'benchmarks/results/2026-11-16-cased-word-stream/refined';out.mkdir()
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and receipt['jobs']==7 and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter']
assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for n in ['identity.json','observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(q/n,out/n)
summary=json.loads((r/'summary.json').read_text(encoding='utf-8'))
summary.update(retained=False,activePrototype=False,retentionDecisionPending=False,decision='Withdraw both cased-stream shapes. This refinement removes private ranges but adds a second byte scan, long-line elapsed+6.26..8.01% with1.20/0.45%controls and captured CPU+3.65..8.73%. Long-line allocation-46.31%/accounted peak-15.82% does not justify retaining the extra scan in this performance milestone. Keep independent foreign-source/prepaid-advancement checks; preserve original range-growth fixture and qualified runtime. No permanent design prohibition.')
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['summary.json','allocation-summary.json','focused-checks.json']:shutil.copyfile(r/n,out/n)
shutil.copyfile(r/'frozen/sources-and-checks.tar.xz',out/'sources-and-checks.tar.xz')
with tarfile.open(out/'procedure-and-image.tar.xz','w:xz')as t:
 for n in ['identity.json','candidate/Lokad.Lython.dll']:t.add(r/'frozen'/n,arcname='frozen/'+n)
 for p in r.glob('*.py'):t.add(p,arcname='procedure/'+p.name)
 for n in ['prepare-refined.py','refine-snapshot.py','preserve-refined.py']:t.add(parent/n,arcname='procedure/'+n)
 for p in q.iterdir():
  if p.is_file()and p.name not in ['observations.tgz','payload.tgz']:t.add(p,arcname='quiet/'+p.name)
 for n in ['Program.cs','Allocation.csproj','catalog.json','reference.json','candidate.json','image-hashes.json']:t.add(r/'allocation-short'/n,arcname='allocation/'+n)
rows=[]
names=['Normalization','Ordinary calls control','Long-line text','Captured-helper text','Protected search','CSV invoice','JSON helpers']
for name,x in zip(names,summary['rows']):
 e=x['elapsedChangePercent'];c=x['cpuChangePercent'];rows.append(f"| {name} | {min(e):+.2f}..{max(e):+.2f}% | {min(c):+.2f}..{max(c):+.2f}% | {x['referenceSpreadPercent']:.2f}/{x['candidateSpreadPercent']:.2f}% |")
(out/'README.md').write_text('''# Bulk cased snapshot without private word ranges: withdrawn

R440/B843,2026-11-16UTC,ce368f52 versus qualified0443b5cf. Refinement of
[B842](../README.md): keep bulk mapped bytes and exact eager word prepayment;
replace the private tuple-range inventory with scanning prepared separated bytes.
Delete private range growth/adoption and foreign-source retention/copy. General
eager split ranges remain genuine. No new cursor,mode,pool,owner or controller.

| Complete warm job | Elapsed change | Wider CPU change | Ref/candidate control spread |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'''

All four independent source-process pairings remain. Long-line elapsed adversity
is stable against1.20/0.45%controls; captured text is adverse with moving controls.
Ordinary-call elapsed and wider CPU disagree; neither demonstrates a gain. Other
unchanged controls move and remain uncertain. No cross-collection causal claim.

Nine local complete warm diagnostics pass stdout/file goldens and shared-budget
baseline cleanup. Long-line CLR allocation568030→304976bytes(−46.31%); accounted
peak1242767→1046159bytes(−15.82%). Short-line allocation/peaks essentially flat.
These are allocation/accounting estimates,not physical heap/RSS or tail latency.

Withdraw both shapes. Keeping bulk casing avoids source-lifetime/copy complexity,
but removing boundaries adds a scan and does not remove the general range store.
The CPU debt is not justified for this milestone despite the real memory benefit.
Preserve independent foreign-source cleanup and prepaid-advancement regressions;
restore the original inventory-growth fixture and qualified runtime. This is a
bounded decision on these shapes,not a rigid percentage veto or permanent ban.
Do not retime unchanged shapes or repeat full qualification for withdrawn code.

Nonincremental both-target Release and243internal/623public per actual11/10 pass;
609inputs are frozen. Full platform/stress/installed consumers remain at the next
retained runtime delivery. Native engine/current runtime0443 remains unchanged.
Publication held; broader whole-script objective and regex track remain open.

Same seven-case catalog and four-second per-process warmup as B842 for all workers;
recorded warmup metadata corrected from5to4 to match actual code. Normal tiering/
workstation GC on quiet F4as_v7/.NET11RC3. Warm includes mediated RAM I/O,output/file
goldens and prior-result cleanup; excludes compilation/startup,reset/protocol and
final cache teardown. Wider CPU includes reset/protocol. All image,quiet,golden,
join/archive gates pass. Seven jobs212.918s; users joined/RAM fixtures gone,terminal
cached. Canonical evidence and current images preserved; only exact committed B842
working replicas retired after fresh idle-lease UID/path/hash/inode/all-alias proof.
Unchanged254/252MiBfloors. Own-directory collectors/config-based retrieval prevent
stale roots. The first B842 staging refusal and all original adversity remain.

[Raw](observations.tgz),[summary](summary.json),[allocation](allocation-summary.json),
[checks](focused-checks.json),[sources](sources-and-checks.tar.xz),
[procedures/image](procedure-and-image.tar.xz).
''',encoding='utf-8',newline='\n')
p=repo/'benchmarks/EXPERIMENTS.md';s=p.read_text(encoding='utf-8');a=s.index('[R440 private word stream]');s=s[:a]+'''[R440 bulk-snapshot refinement](results/2026-11-16-cased-word-stream/refined/README.md)
recordsce368f52/0443,B843seven jobs212.918s/all gates. Long-line allocation−46.31%/
accounted peak−15.82%,but elapsed+6.26..8.01% with1.20/0.45%controls; captured CPU
+3.65..8.73% with moving controls. Withdraw both shapes: added scan does not justify
CPU debt.243internal/623public eachactual11/10 pass; source/full adverse evidence
preserved. Keep independent ownership cases,restore original range-growth fixture
and qualified engine. No unchanged full qualification or permanent design ban.

'''+s[a:];p.write_text(s,encoding='utf-8',newline='\n')
# Retain only independent regressions on the unchanged qualified implementation.
path='tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs';candidate=(repo/'.git/agent-worktrees/cased-word-stream-r440'/path).read_text(encoding='utf-8')
start=candidate.index('    [Theory]');end=candidate.index('    [Theory]\n    [InlineData(0), InlineData(1), InlineData(2)]')
baseline=(repo/path).read_text(encoding='utf-8');assert 'ForeignSourceCleanupKeepsCursorAndRetainedWordsFunded' not in baseline
position=baseline.index('    [Theory]');(repo/path).write_text(baseline[:position]+candidate[start:end]+baseline[position:],encoding='utf-8',newline='\n')
print('Both cased-stream shapes withdrawn with immutable evidence; independent ownership cases retained on qualified runtime.')
