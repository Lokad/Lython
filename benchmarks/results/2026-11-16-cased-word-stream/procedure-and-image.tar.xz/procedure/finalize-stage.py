from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;q=r/'quiet';repo=Path('D:/code/Lython');c=json.loads((q/'config.json').read_text(encoding='utf-8'));head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip();sha=lambda b:hashlib.sha256(b).hexdigest()
for archive,remote in [('benchmarks/results/2026-11-16-shared-executable-kernel/attribution/initial-failed-observations.tgz','shared-kernel-attribution-b839-20261116/initial-failed-observations.tgz'),('benchmarks/results/2026-11-16-shared-executable-kernel/direct/initial-failed-observations.tgz','shared-kernel-direct-b841-20261116/initial-failed-observations.tgz')]:
 raw=(repo/archive).read_bytes();assert raw==subprocess.check_output(['git','-C',str(repo),'show',head+':'+archive])
 c['retireGroups'].append(dict(bytes=len(raw),sha256=sha(raw),links=1,paths=[remote],custody=dict(commit=head,archive=archive,archiveSHA256=sha(raw),member=None)))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
p=q/'remote-launch.py';s=p.read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:];ast.parse(s);p.write_text(s,encoding='utf-8',newline='\n')
# Validate concrete execution paths independently of the generator/template.
for n in ['collect.py','archive-owned.py']:
 s=(q/n).read_text(encoding='utf-8');assert 'Path(__file__).resolve().parent'in s
 assert '/lython-bench-checks/'not in s,n
assert 'root='+c['root']in(q/'run.sh').read_text(encoding='utf-8')
assert "config=json.loads((r/'config.json')"in(q/'retrieve.py').read_text(encoding='utf-8')
with tarfile.open(q/'payload.tgz')as t:
 for n in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh']:assert t.extractfile(n).read()==(q/n).read_bytes(),n
assert json.loads((q/'identity.json').read_text(encoding='utf-8'))['warmupSecondsPerProcess']==4
print(json.dumps(dict(allConcretePathsValidated=True,catalogCases=7,jobs=7,retireBytes=sum(x['bytes']for x in c['retireGroups']),unpackedBytes=c['unpackedBytes'],onlyCommittedRedundantReplicas=True)))
