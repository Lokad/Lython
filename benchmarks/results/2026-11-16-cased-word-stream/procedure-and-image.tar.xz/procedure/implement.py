from pathlib import Path
w=Path('D:/code/Lython/.git/agent-worktrees/cased-word-stream-r440');p=w/'src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs';s=p.read_text(encoding='utf-8')
a=s.index('        context.CheckExecution(span);',s.index('internal static CasedWhitespaceIteration PrepareCasedWhitespaceIteration('));b=s.index('\n    internal sealed class CasedWhitespaceIteration',a)
s=s[:a]+'''        context.CheckExecution(span);
        var governor = context.MemoryGovernor;
        // The cursor retains immutable input. Same-owner storage already lasts
        // through this command; foreign/unowned input gets one admitted copy.
        if (value.ByteLength != 0 && !ReferenceEquals(value.OwnerMemoryGovernor, governor))
        {
            var bytes = PyString.EstimateApproximateBytes(value.ByteLength);
            using var sourceStorage = governor.ReserveTemporary(bytes, span);
            context.CheckExecution(span);
            var source = PyString.CreateReservedUtf8(value.ByteLength, governor);
            for (var copied = 0; copied < value.ByteLength;)
            {
                context.CheckExecution(span);
                var count = Math.Min(4096, value.ByteLength - copied);
                value.Utf8Span.Slice(copied, count).CopyTo(source.UnpublishedUtf8.Slice(copied, count));
                copied += count;
            }
            source.CompleteUnpublishedUtf8(value.ByteLength);
            sourceStorage.Commit(bytes);
            value = source;
        }
        var mapping = upper ? CaseMapping.Upper : CaseMapping.Lower;
        var prepared = governor.RentWordRanges(8, span);
        var previousScratchCapacity = prepared.EncodedCapacity;
        try
        {
            var sizing = new WhitespaceRangeState(-1, mapping);
            long outputBytes = 0;
            var maximumWordCapacity = 0;
            while (TryReadWhitespaceRange(value.Utf8Span, ref sizing, context, span, out var range))
            {
                maximumWordCapacity = Math.Max(maximumWordCapacity, range.Capacity);
                outputBytes = checked(outputBytes + PyString.EstimateApproximateBytes(range.Capacity));
            }
            // Fund every eventual word and maximum scratch before the first
            // loop effect. Conservative case bounds may reject earlier; neither
            // later advancement nor unwind needs a new storage admission.
            prepared.PrepareEncoded(maximumWordCapacity, context, span);
            governor.Reserve(outputBytes, span);
            try
            {
                context.CheckExecution(span);
                var result = prepared;
                result.Initialize(context, span, value, mapping);
                governor.Commit(outputBytes);
                prepared = null;
                return result;
            }
            catch { governor.ReleaseReserved(outputBytes); throw; }
        }
        finally
        {
            if (prepared is not null)
            {
                try
                {
                    if (prepared.EncodedCapacity > previousScratchCapacity)
                        prepared.ReleaseEncoded();
                }
                finally { governor.ReturnWordRanges(prepared, 0); }
            }
        }
    }
''' + s[b:]
s=s.replace('''        private int _count;
        private int _position;''','''        private PyString? _source;
        private WhitespaceRangeState _scan;''')
s=s.replace('''        internal void AdoptScratchFrom(CasedWhitespaceIteration previous)
            => (_encoded, previous._encoded) = (previous._encoded, _encoded);

''','')
s=s.replace('''            _count = _position = 0;''','''            _source = null;
            _scan = default;''')
a=s.index('        internal void Initialize(LythonRuntime.ExecutionContext context, LythonSourceSpan span, int count)');b=s.index('        internal MemoryGovernor MemoryGovernor => _owner;',a)
s=s[:a]+'''        internal void Initialize(LythonRuntime.ExecutionContext context, LythonSourceSpan span,
            PyString source, CaseMapping mapping)
        {
            _context = context;
            _span = span;
            _source = source;
            _scan = new WhitespaceRangeState(-1, mapping);
        }

        private bool TryReadRange(out (int Start, int End, int Capacity) range)
        {
            range = default;
            if (_source is null) return false;
            // One word reuses the prepaid buffer. The scanner still receives
            // the original subject/position for context-sensitive Unicode case.
            _scan.Written = 0;
            return TryReadWhitespaceRange(_source.Utf8Span, ref _scan, _context, _span, out range, _encoded);
        }

        internal PyIterationResult MoveNext()
        {
            if (!TryReadRange(out var range)) return PyIterationResult.End;
            var word = CreateSplitFragment(_encoded.AsSpan(), range, null,
                _owner, _span, _context);
            return PyIterationResult.Yield(word);
        }

'''+s[b:]
s=s.replace('''            if (_position == _count) return false;
            var range = Ranges[_position++];''','''            if (!TryReadRange(out var range)) return false;''')
s=s.replace('''            => _owner.ReturnWordRanges(this, _count);''','''            => _owner.ReturnWordRanges(this, 0);''')
s=s.replace('''        LythonSourceSpan? span, LythonRuntime.ExecutionContext? context, CaseMapping? casing,
        CasedWhitespaceIteration? encoded = null)''','''        LythonSourceSpan? span, LythonRuntime.ExecutionContext? context, CaseMapping? casing)''')
a=s.index('        // The source byte count bounds its scalar count.',s.index('private static void CollectWhitespaceForward('));b=s.index('        context?.CheckExecution(span);',a)
s=s[:a]+s[b:];s=s.replace('out var range, encodedBytes))','out var range))')
s=s.replace('''                // The scanner keeps this same byte builder while range capacity
                // grows; transfer it before the old cursor can reenter the cache.
                replacement?.AdoptScratchFrom(previous);
''','')
assert '_count'not in s and '_position'not in s and 'AdoptScratchFrom'not in s and 'encodedBytes = encoded'not in s
p.write_text(s,encoding='utf-8',newline='\n')
print('Removed private whole-line case staging and word-range inventory. Existing scanner maps one word into prepaid max-word scratch; all eventual words funded eagerly,foreign input copied cooperatively. General split ranges/cache retained.')
