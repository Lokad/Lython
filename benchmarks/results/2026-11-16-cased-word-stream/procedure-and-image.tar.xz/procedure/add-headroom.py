from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;q=r/'quiet';repo=Path('D:/code/Lython');c=json.loads((q/'config.json').read_text(encoding='utf-8'));sha=lambda b:hashlib.sha256(b).hexdigest()
for n in ['launch.log','config.json','remote-launch.py']:
 p=q/n;assert p.exists();(q/('initial-staging-'+n)).write_bytes(p.read_bytes())
(q/'launch.log').unlink()
archive='benchmarks/results/2026-11-16-iteration-slot-transport/refined/observations.tgz';raw=(repo/archive).read_bytes();head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip();assert raw==subprocess.check_output(['git','-C',str(repo),'show',head+':'+archive])
with tarfile.open(fileobj=io.BytesIO(raw))as t:content=t.extractfile('confirmation/confirmation.json').read()
proof=dict(bytes=len(content),sha256=sha(content),links=1,paths=['iteration-refine-b834-20261116/confirmation/confirmation.json'],custody=dict(commit=head,archive=archive,archiveSHA256=sha(raw),member='confirmation/confirmation.json'))
c['retireGroups'].append(proof);(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
p=q/'remote-launch.py';s=p.read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:];ast.parse(s);p.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(originalRefusalPreserved=True,noOriginalMutation=True,additionalExactCommittedWorkingReplica=proof['paths'],bytes=proof['bytes'],same254and252MiBFloors=True)))
