from pathlib import Path
import ast,base64,collections,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;q=r/'quiet';repo=Path('D:/code/Lython');sha=lambda b:hashlib.sha256(b).hexdigest();c=json.loads((q/'config.json').read_text(encoding='utf-8'))
catalog=json.loads((q/'representative.json').read_text(encoding='utf-8'));case=dict(next(x for x in catalog['cases']if x['id']=='scripts.text-summary-helpers.nonlocal-counter.large'))
case['id']='scripts.text-summary-helpers.long-line';source=case['source']
for line in ['    processed=0\n','        nonlocal processed\n','        processed += 1\n','    assert processed == 3072\n']:
 assert source.count(line)==1,line
 source=source.replace(line,'')
case['source']=source;case['sourceSha256']=sha(source.encode());fixture=json.loads(case['fixtureJson']);original=base64.b64decode(fixture['inputFiles']['input.txt']);flat=original.replace(b'\n',b' ')
fixture['inputFiles']['input.txt']=base64.b64encode(flat).decode();case['fixtureJson']=json.dumps(fixture,ensure_ascii=False,separators=(',',':'));case['fixtureSha256']=sha(case['fixtureJson'].encode())
# Independent plain-Python count/render algorithm validates unchanged goldens;
# no interpreter output is accepted as a new golden for the candidate.
words=flat.decode().lower().split();counts=collections.Counter(words);report=''.join(k+'='+str(counts[k])+'\n'for k in sorted(counts))
assert str(len(words))+'\n'==case['expectedOutput'];assert report.encode()==base64.b64decode(fixture['outputFiles']['report.txt'])
catalog['cases'].append(case);assert len(catalog['cases'])==7
(q/'representative.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
p=r/'allocation-short/catalog.json';allocation=json.loads(p.read_text(encoding='utf-8'));allocation['cases'].append(dict(case,runAsync=False));p.write_text(json.dumps(allocation,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
p=q/'collect.py';s=p.read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nassert len(jobs)',a);jobs=ast.literal_eval(s[a+5:b]);jobs.insert(2,[case['id'],'warm']);s=s[:a]+'jobs='+repr(jobs)+s[b:];s=s.replace('len(jobs)==6','len(jobs)==7').replace("(8 if lane=='compile'else 5)","(8 if lane=='compile'else 4)");assert len(jobs)==7 and "else 4)"in s;ast.parse(s);p.write_text(s,encoding='utf-8',newline='\n')
p=q/'archive-owned.py';s=p.read_text(encoding='utf-8').replace("len(raw['jobs'])==6","len(raw['jobs'])==7").replace('jobs=6','jobs=7');ast.parse(s);p.write_text(s,encoding='utf-8',newline='\n')
p=q/'retrieve.py';s=p.read_text(encoding='utf-8').replace("['jobs']==6","['jobs']==7");ast.parse(s);p.write_text(s,encoding='utf-8',newline='\n')
p=r/'summarize.py';s=p.read_text(encoding='utf-8').replace("len(raw['jobs'])==6","len(raw['jobs'])==7");p.write_text(s,encoding='utf-8',newline='\n')
identity=json.loads((q/'identity.json').read_text(encoding='utf-8'));identity.update(purpose='R440 private whole-line/range storage deletion. Seven warm jobs include existing text data flattened into one long line; independent goldens,unchanged script behavior without optional diagnostic counter. Four-second per-process warmup keeps seven jobs within existing240second owned boundary.',longLine=dict(inputBytes=len(flat),sourceLinesBefore=original.count(b'\n'),sourceLinesAfter=1,wordCount=len(words),sameWordMultisetAndOutputsVerified=True),catalogChanges='Adds one whole-file long-line shape; no causal comparisons across collections. Same seven-case catalog in all processes.',warmupSecondsPerProcess=4)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n');c['identity']=identity;c['catalogSHA256']=sha((q/'representative.json').read_bytes())
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip();archive='benchmarks/results/2026-11-16-shared-executable-kernel/direct/observations.tgz';raw=(repo/archive).read_bytes();assert raw==subprocess.check_output(['git','-C',str(repo),'show',head+':'+archive])
with tarfile.open(fileobj=io.BytesIO(raw))as t:content=t.extractfile('representative.json').read()
assert sha(content)==c['sourceCatalogSHA256']
c['retireGroups'].append(dict(bytes=len(content),sha256=sha(content),links=1,paths=['shared-kernel-direct-b841-20261116/representative.json'],custody=dict(commit=head,archive=archive,archiveSHA256=sha(raw),member='representative.json')))
payload={n:(q/n).read_bytes()for n in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh']};payload['candidate/Lokad.Lython.dll']=(r/'frozen/candidate/Lokad.Lython.dll').read_bytes()
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n,b in payload.items():m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
c.update(payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(map(len,payload.values())))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
p=q/'remote-launch.py';s=p.read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace(" os.link(source/'representative.json',root/'representative.json');assert sha(root/'representative.json')==c['catalogSHA256']", " assert sha(root/'representative.json')==c['catalogSHA256']");ast.parse(s);p.write_text(s,encoding='utf-8',newline='\n')
p=r/'launch-quiet.py';s=p.read_text(encoding='utf-8').replace('Six-job shared-kernel comparison launched','Seven-job cased-word comparison launched');p.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(jobs=7,catalogCases=7,allocationJobs=len(allocation['cases']),longLine=identity['longLine'],independentGoldens=True,warmupSecondsPerProcess=4,ownedMaxSeconds=240,unpackedBytes=c['unpackedBytes'],retireBytes=sum(x['bytes']for x in c['retireGroups']))))
