from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
r=Path(__file__).parent;repo=Path('D:/code/Lython');w=repo/'.git/agent-worktrees/cased-word-stream-r440';old=r.parent/'shared-kernel-r439/direct';sha=lambda b:hashlib.sha256(b).hexdigest();f=r/'frozen';f.mkdir();images={}
prior=json.loads((old/'frozen/identity.json').read_text(encoding='utf-8'))
for role in ['reference','candidate']:
 shutil.copytree(old/'frozen/reference',f/role)
 if role=='candidate':shutil.copyfile(w/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',f/role/'Lokad.Lython.dll')
 images[role]={p.name:sha(p.read_bytes())for p in(f/role).iterdir()if p.is_file()}
assert images['reference']==prior['images']['reference']and all(images['candidate'][n]==h for n,h in images['reference'].items()if n!='Lokad.Lython.dll')
base=json.loads((r.parent/'kernel-r436/refined/frozen/identity.json').read_text(encoding='utf-8'));paths=list(base['sources'])+['tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs','tests/Lokad.Lython.Tests/DrainCleanupOwnershipTests.cs'];assert len(paths)==len(set(paths))==609
identity=dict(buildSourceCommit=subprocess.check_output(['git','-C',str(w),'rev-parse','HEAD'],text=True).strip(),prototype=True,images=images,sources={n:sha((w/n).read_bytes())for n in paths},contract='Existing private cased cursor first sizes/prepays all words and maximum-word scratch. Same scanner maps one word from execution-owned immutable input. No whole encoded line/private range inventory. General ranges/pool remain; cross-owner input copied with preflight and cancellation. Conservative capacity can reject earlier. Measured native engine unchanged.',referenceQualification='312f5911/measured0443b5cf full43828954661 GREEN,607inputs/16summaries; terminal cached forever.',publicationHeld=True)
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};checks=[dict(file=p.name,**E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib)for p in(r/'ownership-checks').glob('*.trx')];assert len(checks)==4 and sorted(int(x['passed'])for x in checks)==[243,243,623,623]and all(x['failed']=='0'for x in checks)
(r/'focused-checks.json').write_text(json.dumps(dict(checks=checks,nonincrementalBothTargetReleaseBuild=True,additionalOwnershipCases=4,earlierOverlappingFiltersNotSummed=True,fullQualificationPending=True),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz')as t:
 for n in paths:t.add(w/n,arcname=n)
 for n in ['initial-checks','ownership-checks']:t.add(r/n,arcname=n)
 for p in r.glob('*.log'):t.add(p,arcname=p.name)
a=r/'allocation-short';a.mkdir()
for n in ['Program.cs','Allocation.csproj','catalog.json']:shutil.copyfile(old/'allocation-short'/n,a/n)
shutil.copytree(old/'allocation-short/bin',a/'bin');shutil.copyfile(old/'measure-allocation.py',r/'measure-allocation.py')
q=r/'quiet';q.mkdir();before=json.loads((old/'quiet/config.json').read_text(encoding='utf-8'));root='/home/lokad/lython-bench-checks/cased-word-stream-b842-20261116';unit='lython-b842-cased-word-stream-20261116';files=before['identity']['imageFiles']['reference'];imageFiles={role:{n:images[role][n]for n in files}for role in ['reference','candidate']}
ident=dict(sourceRevision='R440 cased-word streaming '+images['candidate']['Lokad.Lython.dll'][:8]+' versus qualified312f5911/0443b5cf',purpose='Remove complete private transformed-line/range representations. Six warm complete jobs including native-call control; same catalog per process. Allocation/accounted memory and CPU are separate.',coreSHA256={label:imageFiles['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['reference','reference-control','candidate','candidate-control']},imageFiles=imageFiles,prototype=True,publicationHeld=True,candidateFocusedChecks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8')),candidateSourceIdentitySHA256=sha((f/'identity.json').read_bytes()),referenceQualification=identity['referenceQualification'])
(q/'identity.json').write_text(json.dumps(ident,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(old/'quiet/representative.json',q/'representative.json')
for n in ['collect.py','archive-owned.py','run.sh']:
 s=(old/'quiet'/n).read_text(encoding='utf-8')
 if n=='collect.py':s=s.replace("root = Path('"+before['root']+"')",'root = Path(__file__).resolve().parent')
 if n=='archive-owned.py':s=s.replace("r=Path('"+before['root']+"')",'r=Path(__file__).resolve().parent')
 if n=='run.sh':s=s.replace('root='+before['root'],'root='+root)
 s=s.replace('B841','B842')
 assert before['root']not in s and before['unit']not in s,n
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
# Retrieval reads the concrete configuration,never a copied old run identifier.
s=(r.parent/'matched-calls-r414/profile/retrieve.py').read_text(encoding='utf-8');s=s.replace("assert status['receipt']['ramTraceArchivedAndVerifiedBeforeUnmount']and status['receipt']['quietBeforeAndAfter']", "assert status['receipt']['archivedAndVerifiedUnderLease']and status['receipt']['quietBeforeAndAfter']and status['receipt']['allWorkersJoined']and status['receipt']['jobs']==6")
s=s.replace('Paired CPU profiles preserved and SHA-verified; terminal cached, all users joined and RAM traces archived before unmount.','B842 complete-source observations SHA-verified; terminal cached,all users joined and guest fixtures removed.')
ast.parse(s);(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip();proofs=[]
specs=[('benchmarks/results/2026-11-16-shared-executable-kernel/direct/procedure-and-image.tar.xz','frozen/candidate/Lokad.Lython.dll',['shared-kernel-direct-b841-20261116/candidate/Lokad.Lython.dll']),('benchmarks/results/2026-11-16-shared-executable-kernel/direct/observations.tgz',None,['shared-kernel-direct-b841-20261116/observations.tgz']),('benchmarks/results/2026-11-16-shared-executable-kernel/direct/observations.tgz','confirmation/confirmation.json',['shared-kernel-direct-b841-20261116/confirmation/confirmation.json'])]
for archive,member,pathsToRetire in specs:
 raw=(repo/archive).read_bytes();assert raw==subprocess.check_output(['git','-C',str(repo),'show',head+':'+archive])
 if member:
  with tarfile.open(fileobj=io.BytesIO(raw))as t:content=t.extractfile(member).read()
 else:content=raw
 proofs.append(dict(bytes=len(content),sha256=sha(content),links=len(pathsToRetire),paths=pathsToRetire,custody=dict(commit=head,archive=archive,archiveSHA256=sha(raw),member=member)))
payload={n:(q/n).read_bytes()for n in ['identity.json','collect.py','archive-owned.py','run.sh']};payload['candidate/Lokad.Lython.dll']=(f/'candidate/Lokad.Lython.dll').read_bytes()
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n,b in payload.items():m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
c=dict(root=root,unit=unit,source=before['root'],sourceFiles=files,sourceCatalogSHA256=before['catalogSHA256'],catalogSHA256=before['catalogSHA256'],identity=ident,retireGroups=proofs,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(map(len,payload.values())))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(r.parent/'shared-kernel-r439/quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace("source/'candidate'","source/'reference'")
s=s.replace(" os.link(source/'cpython-worker.py',root/'cpython-worker.py');assert sha(root/'representative.json')==c['catalogSHA256']", " os.link(source/'cpython-worker.py',root/'cpython-worker.py')\n os.link(source/'representative.json',root/'representative.json');assert sha(root/'representative.json')==c['catalogSHA256']")
s=s.replace('lython-b838-fixtures','lython-b842-fixtures');ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
shutil.copyfile(r.parent/'shared-kernel-r439/launch-quiet.py',r/'launch-quiet.py');shutil.copyfile(old/'summarize.py',r/'summarize.py')
print(json.dumps(dict(core=images['candidate']['Lokad.Lython.dll'],sources=len(identity['sources']),checks=4,jobs=6,catalogUnchanged=True,sourceEngine='Qualified native/ordinary engine restored; only cased iteration changes.',retireBytes=sum(x['bytes']for x in proofs),unpackedBytes=c['unpackedBytes'],collectorUsesOwnDirectory=True,retrieverUsesConcreteConfig=True)))
