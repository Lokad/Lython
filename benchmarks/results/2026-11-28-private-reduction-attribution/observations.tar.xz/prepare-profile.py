from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json

lab=Path(__file__).resolve().parent
prior=lab.parent/'current-shipment-checkpoint-b1943-20261128/attribution/profile'
quiet=lab/'comparison/quiet'
profile=lab/'attribution/profile'
read=lambda path:json.loads(path.read_bytes())
digest=lambda path:sha256(path.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
summary=read(quiet/'summary.json')
assert summary['source']==identity['sourceRevision'] and summary['timedBatches']==168
assert summary['passedQuietCheck']
image=identity['imageFiles']['candidate']
assert len(image)==32 and {p.name:digest(p) for p in (quiet/'local-image').iterdir()}==image
assert digest(quiet/'representative.json')==identity['catalogs']['representative.json']['sha256']
assert digest(quiet/'cpython-worker.py')==identity['cpythonWorkerSHA256']
roles=[('generator-async','diagnostic.shipment-row-generator-reduction','warm-async'),
       ('explicit-async','diagnostic.shipment-row-explicit-reduction','warm-async')]
identity.update(inspectedHead=identity['sourceRevision'],profiles=roles)
profile.mkdir(parents=True)
(profile/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ('representative.json','cpython-worker.py'):
    copy2(quiet/name,profile.parent/name)
copy2(quiet/'candidate-local-verify.json',profile.parent/'candidate-verify.json')
collect=(prior/'collect.py').read_text(encoding='utf-8')
assert collect.count('verification["caseCount"]==4')==1
collect=collect.replace('verification["caseCount"]==4','verification["caseCount"]==5')
analysis=(prior/'analyze-managed.py').read_text(encoding='utf-8')
analysis=analysis.replace("('reduction-async', 'iterable-async', 'map-async')",repr(tuple(role for role,_,_ in roles)))
analysis=analysis.replace("'numeric reduction':","'sum calls': ('<SumAsync>', 'SumBuiltin'), 'closure charge': ('ChargeClosureRetention',), 'numeric reduction':")
for name,code in [('collect.py',collect),('analyze-managed.py',analysis)]:
    compile(code,name,'exec')
    (profile/name).write_text(code,encoding='utf-8',newline='\n')
copy2(prior/'run.sh',profile/'run.sh')
assert b'\r' not in (profile/'run.sh').read_bytes()
print(identity['sourceRevision'],'paired shipment workloads ready for managed attribution')
