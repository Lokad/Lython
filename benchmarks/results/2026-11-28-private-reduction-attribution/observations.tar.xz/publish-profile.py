from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab=Path(__file__).resolve().parent
capture=lab/'attribution/profile'
layout=lab/'attribution/layout'
quiet=lab/'comparison/quiet'
out=lab.parents[3]/'benchmarks/results/2026-11-28-private-reduction-attribution'
read=lambda path:json.loads(path.read_bytes())
digest=lambda path:sha256(path.read_bytes()).hexdigest()
identity=read(capture/'identity.json')
current=read(quiet/'identity.json')
assert identity['sourceRevision']==current['sourceRevision']=='2806d7d7519afc6ea5498639f35d5608881fb4da'
assert identity['imageFiles']==current['imageFiles']
image=identity['imageFiles']['candidate']
assert len(image)==32 and {p.name:digest(p) for p in (quiet/'local-image').iterdir()}==image
summary=read(capture/'run-summary.json')
assert summary['allProcessesJoined'] and summary['sourceRevision']==identity['sourceRevision']
assert summary['catalogSha']==identity['catalogs']['representative.json']['sha256']
observed=read(layout/'layout.json')
assert observed['core']==image['Lokad.Lython.dll'] and observed['catalog']==summary['catalogSha']
workloads={row['id']:row['layouts'] for row in observed['observations']}
ordinary=workloads['diagnostic.shipment-row-generator-reduction']
explicit=workloads['diagnostic.shipment-row-explicit-reduction']
assert ordinary[1]['name']==explicit[1]['name']=='shipment_cost'
assert not ordinary[1]['canRunNative'] and explicit[1]['canRunNative']
assert ordinary[1]['opcodes'][2:4]==['ApplyOperation','Call']
assert ordinary[1]['generatorOperands'][0]['target']==2
assert ordinary[2]['name']=='<genexpr>' and 'Yield' in ordinary[2]['opcodes']
assert explicit[1]['opcodes'][1:4]==['GetIter','Jump','ForNext']
procedures={name:capture/name for name in ('run.sh','collect.py','analyze-managed.py','collection.log','identity.json','run-summary.json')}
procedures['prepare-profile.py']=lab/'prepare-profile.py'
procedures['publish-profile.py']=lab/'publish-profile.py'
for name in ('representative.json','cpython-worker.py','candidate-verify.json'):
    procedures[name]=capture.parent/name
for name in ('InspectLayout.csproj','Program.cs','build.log'):
    procedures[f'layout/{name}']=layout/name
batches=0
for role,case,lane in identity['profiles']:
    folder=capture/role
    record=read(folder/'record.json')
    assert record['allProcessesJoined'] and record['role']==role and record['workload']==case and record['lane']==lane
    assert record['coreSha']==image['Lokad.Lython.dll'] and record['nettraceSha']==digest(folder/'run.nettrace')
    assert record['before']['status']==record['after']['status']=='Equivalent'
    assert record['closed']['status']=='Closed'
    assert record['batches'] and all(batch['status']=='Completed' for batch in record['batches'])
    batches+=len(record['batches'])
    for name in ('record.json','run.nettrace','run.speedscope.json','exclusive.txt','inclusive.txt','capture.log','worker.stderr'):
        procedures[f'{role}/{name}']=folder/name
assert batches==summary['totalVerifiedBatches']==90
out.mkdir(exist_ok=True)
for name,path in {'managed-attribution.json':capture/'managed-attribution.json','run-summary.json':capture/'run-summary.json',
                  'layout.json':layout/'layout.json'}.items():
    copy2(path,out/name)
    assert digest(path)==digest(out/name)
with tarfile.open(out/'observations.tar.xz','w:xz') as archive:
    for name,path in procedures.items(): archive.add(path,arcname=name)
with tarfile.open(out/'observations.tar.xz') as archive:
    assert all(digest(path)==sha256(archive.extractfile(name).read()).hexdigest() for name,path in procedures.items())
print('Matching managed traces, layouts and 90 verified batches archived.')
